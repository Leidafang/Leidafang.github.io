<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_375d2071-69d0-40f4-b26e-494823b66e77">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">42</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>3</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.670569396620756 139.74984901637504 0 35.67058037383225 139.7498208369108 0 35.67073691579656 139.74991257915067 0 35.67075316562521 139.74987077404603 0 35.67078941727814 139.74977752748802 0 35.67074269809808 139.74975009295642 0 35.6705290391166 139.74962393519374 0 35.67047425202456 139.74964752095656 0 35.670423955207895 139.749777035696 0 35.670569396620756 139.74984901637504 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670569396620756 139.74984901637504 6.59 35.670423955207895 139.749777035696 6.59 35.67047425202456 139.74964752095656 6.59 35.6705290391166 139.74962393519374 6.59 35.67074269809808 139.74975009295642 6.59 35.67078941727814 139.74977752748802 6.59 35.67075316562521 139.74987077404603 6.59 35.67073691579656 139.74991257915067 6.59 35.67058037383225 139.7498208369108 6.59 35.670569396620756 139.74984901637504 6.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670569396620756 139.74984901637504 6.59 35.67058037383225 139.7498208369108 6.59 35.67058037383225 139.7498208369108 38.07 35.670569396620756 139.74984901637504 38.07 35.670569396620756 139.74984901637504 6.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67058037383225 139.7498208369108 6.59 35.67073691579656 139.74991257915067 6.59 35.67073691579656 139.74991257915067 38.07 35.67058037383225 139.7498208369108 38.07 35.67058037383225 139.7498208369108 6.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67073691579656 139.74991257915067 6.59 35.67075316562521 139.74987077404603 6.59 35.67075316562521 139.74987077404603 38.07 35.67073691579656 139.74991257915067 38.07 35.67073691579656 139.74991257915067 6.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67075316562521 139.74987077404603 6.59 35.67078941727814 139.74977752748802 6.59 35.67078941727814 139.74977752748802 38.07 35.67075316562521 139.74987077404603 38.07 35.67075316562521 139.74987077404603 6.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67078941727814 139.74977752748802 6.59 35.67074269809808 139.74975009295642 6.59 35.67074269809808 139.74975009295642 38.07 35.67078941727814 139.74977752748802 38.07 35.67078941727814 139.74977752748802 6.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67074269809808 139.74975009295642 6.59 35.6705290391166 139.74962393519374 6.59 35.6705290391166 139.74962393519374 38.07 35.67074269809808 139.74975009295642 38.07 35.67074269809808 139.74975009295642 6.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6705290391166 139.74962393519374 6.59 35.67047425202456 139.74964752095656 6.59 35.67047425202456 139.74964752095656 38.07 35.6705290391166 139.74962393519374 38.07 35.6705290391166 139.74962393519374 6.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67047425202456 139.74964752095656 6.59 35.670423955207895 139.749777035696 6.59 35.670423955207895 139.749777035696 38.07 35.67047425202456 139.74964752095656 38.07 35.67047425202456 139.74964752095656 6.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670423955207895 139.749777035696 6.59 35.670569396620756 139.74984901637504 6.59 35.670569396620756 139.74984901637504 38.07 35.670423955207895 139.749777035696 38.07 35.670423955207895 139.749777035696 6.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670569396620756 139.74984901637504 38.07 35.67058037383225 139.7498208369108 38.07 35.67073691579656 139.74991257915067 38.07 35.67075316562521 139.74987077404603 38.07 35.67078941727814 139.74977752748802 38.07 35.67074269809808 139.74975009295642 38.07 35.6705290391166 139.74962393519374 38.07 35.67047425202456 139.74964752095656 38.07 35.670423955207895 139.749777035696 38.07 35.670569396620756 139.74984901637504 38.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-6fc0c907-6ae9-46ea-b7fd-6a1f27cd7a76"/>
							<gml:surfaceMember xlink:href="#poly-88997bd2-0a40-4570-b532-2dbfad093240"/>
							<gml:surfaceMember xlink:href="#poly-e3a570cc-fd80-4ee6-9da5-c368ce5eb1a2"/>
							<gml:surfaceMember xlink:href="#poly-77a08f72-8198-4b37-9f40-a6991e339ff4"/>
							<gml:surfaceMember xlink:href="#poly-c495bd6d-f074-45be-a28a-6d24d8cfc3e0"/>
							<gml:surfaceMember xlink:href="#poly-a0c1cbdf-048e-4f0a-afb3-4e533489e8f2"/>
							<gml:surfaceMember xlink:href="#poly-babfa10b-19ce-4ea0-a4e7-35864d1496ef"/>
							<gml:surfaceMember xlink:href="#poly-9ac4772e-9491-4978-90b4-6d27026a06d8"/>
							<gml:surfaceMember xlink:href="#poly-00f4c0a3-1ab3-4900-a01f-5edfa7ec94d8"/>
							<gml:surfaceMember xlink:href="#poly-3b576e7d-e56a-45b1-af79-3100d9eb084b"/>
							<gml:surfaceMember xlink:href="#poly-9dc2a2ed-41c9-4c12-92be-c0a4e928cbea"/>
							<gml:surfaceMember xlink:href="#poly-ec6bb524-dcbf-4714-999d-d27156f5de28"/>
							<gml:surfaceMember xlink:href="#poly-1bb806f2-4a01-4f59-a3fe-b7e5133266bd"/>
							<gml:surfaceMember xlink:href="#poly-36282577-7a32-4a32-92f2-601163dc860a"/>
							<gml:surfaceMember xlink:href="#poly-e0ccef2d-27dd-4250-9471-31816b88bc58"/>
							<gml:surfaceMember xlink:href="#poly-babb516f-a0b5-4214-ac31-6bf839728f46"/>
							<gml:surfaceMember xlink:href="#poly-75798910-f15e-4cde-8cdd-7cd445bb2274"/>
							<gml:surfaceMember xlink:href="#poly-9c0011b8-1261-427b-96fc-696e04f8cd77"/>
							<gml:surfaceMember xlink:href="#poly-77dfb463-a1de-4a27-8aa8-6454d4ff44c5"/>
							<gml:surfaceMember xlink:href="#poly-2a6137c4-e9c5-4a25-bd13-52804c112b71"/>
							<gml:surfaceMember xlink:href="#poly-0265b358-4c02-4134-b8ff-9f02c8df6ac0"/>
							<gml:surfaceMember xlink:href="#poly-b8c9064b-0a58-4168-8652-3db1d2d3345c"/>
							<gml:surfaceMember xlink:href="#poly-7d7351d0-fec6-4cc3-8eea-ab75ab696d35"/>
							<gml:surfaceMember xlink:href="#poly-2b1585fd-b37c-4a0f-9499-3a5e19880660"/>
							<gml:surfaceMember xlink:href="#poly-fc77b240-9150-46ec-9327-9ce1bd341070"/>
							<gml:surfaceMember xlink:href="#poly-c5d1b9a9-82f7-421c-af98-cb9e58c4399f"/>
							<gml:surfaceMember xlink:href="#poly-57ec7890-153f-4656-93f9-a1070fd0a682"/>
							<gml:surfaceMember xlink:href="#poly-16eac517-fafc-43f9-953b-f5e45a4fe7ee"/>
							<gml:surfaceMember xlink:href="#poly-6e511395-bc3e-43b9-9b50-3e41425d2107"/>
							<gml:surfaceMember xlink:href="#poly-df366e7e-f0fd-47fb-bcab-b1b0e18058f6"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-6fc0c907-6ae9-46ea-b7fd-6a1f27cd7a76">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6fc0c907-6ae9-46ea-b7fd-6a1f27cd7a76">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6fc0c907-6ae9-46ea-b7fd-6a1f27cd7a76">
											<gml:posList>35.6705803738322 139.7498208369108 6.59 35.670569396620756 139.749849016375 6.59 35.67042395520791 139.749777035696 6.59 35.67047425202455 139.74964752095653 6.59 35.67052903911659 139.74962393519374 6.59 35.67074348261416 139.7497505560836 6.59 35.67078947127618 139.74977740592226 6.59 35.67073691579656 139.74991257915067 6.59 35.6705803738322 139.7498208369108 6.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-88997bd2-0a40-4570-b532-2dbfad093240">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-88997bd2-0a40-4570-b532-2dbfad093240">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-88997bd2-0a40-4570-b532-2dbfad093240">
											<gml:posList>35.67047425202455 139.74964752095653 37.3 35.670534448884695 139.74972992966366 37.3 35.67052903911659 139.74962393519374 37.3 35.67047425202455 139.74964752095653 37.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e3a570cc-fd80-4ee6-9da5-c368ce5eb1a2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e3a570cc-fd80-4ee6-9da5-c368ce5eb1a2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e3a570cc-fd80-4ee6-9da5-c368ce5eb1a2">
											<gml:posList>35.67052903911659 139.74962393519374 37.3 35.670534448884695 139.74972992966366 37.3 35.67056149204974 139.74974575288422 37.3 35.67074269809808 139.74975009295642 37.3 35.67052903911659 139.74962393519374 37.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-77a08f72-8198-4b37-9f40-a6991e339ff4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-77a08f72-8198-4b37-9f40-a6991e339ff4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-77a08f72-8198-4b37-9f40-a6991e339ff4">
											<gml:posList>35.67047425202455 139.74964752095653 37.3 35.67042395520791 139.749777035696 37.3 35.670516777404025 139.74977529306625 37.3 35.670534448884695 139.74972992966366 37.3 35.67047425202455 139.74964752095653 37.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c495bd6d-f074-45be-a28a-6d24d8cfc3e0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c495bd6d-f074-45be-a28a-6d24d8cfc3e0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c495bd6d-f074-45be-a28a-6d24d8cfc3e0">
											<gml:posList>35.670534448884695 139.74972992966366 41.05 35.670516777404025 139.74977529306625 41.05 35.67052565953315 139.74978048660762 41.05 35.6705438205632 139.74979111629864 41.05 35.67055974650796 139.74975025054206 41.05 35.67056149204974 139.74974575288422 41.05 35.670534448884695 139.74972992966366 41.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a0c1cbdf-048e-4f0a-afb3-4e533489e8f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a0c1cbdf-048e-4f0a-afb3-4e533489e8f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a0c1cbdf-048e-4f0a-afb3-4e533489e8f2">
											<gml:posList>35.670554920972165 139.74979761099382 42.55 35.6705708469191 139.74975674523287 42.55 35.67055974650796 139.74975025054206 42.55 35.6705438205632 139.74979111629864 42.55 35.670554920972165 139.74979761099382 42.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-babfa10b-19ce-4ea0-a4e7-35864d1496ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-babfa10b-19ce-4ea0-a4e7-35864d1496ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-babfa10b-19ce-4ea0-a4e7-35864d1496ef">
											<gml:posList>35.67058301916311 139.7498140517344 37.3 35.6707063924756 139.74984347208425 37.3 35.67074269809808 139.74975009295642 37.3 35.67056149204974 139.74974575288422 37.3 35.67055974650796 139.74975025054206 37.3 35.6705708469191 139.74975674523287 37.3 35.670554920972165 139.74979761099382 37.3 35.67058301916311 139.7498140517344 37.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9ac4772e-9491-4978-90b4-6d27026a06d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ac4772e-9491-4978-90b4-6d27026a06d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ac4772e-9491-4978-90b4-6d27026a06d8">
											<gml:posList>35.67078947127618 139.74977740592226 48.6 35.67074269809808 139.74975009295642 48.6 35.6707063924756 139.74984347208425 48.6 35.67075316562521 139.74987077404603 48.6 35.67078947127618 139.74977740592226 48.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-00f4c0a3-1ab3-4900-a01f-5edfa7ec94d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-00f4c0a3-1ab3-4900-a01f-5edfa7ec94d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-00f4c0a3-1ab3-4900-a01f-5edfa7ec94d8">
											<gml:posList>35.67051203700804 139.74981546227517 37.3 35.67052565953315 139.74978048660762 37.3 35.670516777404025 139.74977529306625 37.3 35.67042395520791 139.749777035696 37.3 35.670569396620756 139.749849016375 37.3 35.67051203700804 139.74981546227517 37.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3b576e7d-e56a-45b1-af79-3100d9eb084b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3b576e7d-e56a-45b1-af79-3100d9eb084b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3b576e7d-e56a-45b1-af79-3100d9eb084b">
											<gml:posList>35.67058301916311 139.7498140517344 44.3 35.67052565953315 139.74978048660762 44.3 35.67051203700804 139.74981546227517 44.3 35.670569396620756 139.749849016375 44.3 35.67058301916311 139.7498140517344 44.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9dc2a2ed-41c9-4c12-92be-c0a4e928cbea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9dc2a2ed-41c9-4c12-92be-c0a4e928cbea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9dc2a2ed-41c9-4c12-92be-c0a4e928cbea">
											<gml:posList>35.67073691579656 139.74991257915067 37.3 35.67075316562521 139.74987077404603 37.3 35.6707063924756 139.74984347208425 37.3 35.67058301916311 139.7498140517344 37.3 35.6705803738322 139.7498208369108 37.3 35.67073691579656 139.74991257915067 37.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ec6bb524-dcbf-4714-999d-d27156f5de28">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec6bb524-dcbf-4714-999d-d27156f5de28">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec6bb524-dcbf-4714-999d-d27156f5de28">
											<gml:posList>35.67052903911659 139.74962393519374 6.59 35.67047425202455 139.74964752095653 6.59 35.67047425202455 139.74964752095653 37.3 35.67052903911659 139.74962393519374 37.3 35.67052903911659 139.74962393519374 6.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1bb806f2-4a01-4f59-a3fe-b7e5133266bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1bb806f2-4a01-4f59-a3fe-b7e5133266bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1bb806f2-4a01-4f59-a3fe-b7e5133266bd">
											<gml:posList>35.67074348261416 139.7497505560836 6.59 35.67052903911659 139.74962393519374 6.59 35.67052903911659 139.74962393519374 37.3 35.67074269809808 139.74975009295642 37.3 35.67074269809808 139.74975009295642 48.6 35.67078947127618 139.74977740592226 48.6 35.67078947127618 139.74977740592226 6.59 35.67074348261416 139.7497505560836 6.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-36282577-7a32-4a32-92f2-601163dc860a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36282577-7a32-4a32-92f2-601163dc860a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36282577-7a32-4a32-92f2-601163dc860a">
											<gml:posList>35.67047425202455 139.74964752095653 6.59 35.67042395520791 139.749777035696 6.59 35.67042395520791 139.749777035696 37.3 35.67047425202455 139.74964752095653 37.3 35.67047425202455 139.74964752095653 6.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e0ccef2d-27dd-4250-9471-31816b88bc58">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e0ccef2d-27dd-4250-9471-31816b88bc58">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e0ccef2d-27dd-4250-9471-31816b88bc58">
											<gml:posList>35.670534448884695 139.74972992966366 41.05 35.67056149204974 139.74974575288422 41.05 35.67056149204974 139.74974575288422 37.3 35.670534448884695 139.74972992966366 37.3 35.670534448884695 139.74972992966366 41.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-babb516f-a0b5-4214-ac31-6bf839728f46">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-babb516f-a0b5-4214-ac31-6bf839728f46">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-babb516f-a0b5-4214-ac31-6bf839728f46">
											<gml:posList>35.67055974650796 139.74975025054206 37.3 35.67056149204974 139.74974575288422 37.3 35.67056149204974 139.74974575288422 41.05 35.67055974650796 139.74975025054206 41.05 35.67055974650796 139.74975025054206 37.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-75798910-f15e-4cde-8cdd-7cd445bb2274">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-75798910-f15e-4cde-8cdd-7cd445bb2274">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-75798910-f15e-4cde-8cdd-7cd445bb2274">
											<gml:posList>35.670516777404025 139.74977529306625 41.05 35.670534448884695 139.74972992966366 41.05 35.670534448884695 139.74972992966366 37.3 35.670516777404025 139.74977529306625 37.3 35.670516777404025 139.74977529306625 41.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9c0011b8-1261-427b-96fc-696e04f8cd77">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c0011b8-1261-427b-96fc-696e04f8cd77">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c0011b8-1261-427b-96fc-696e04f8cd77">
											<gml:posList>35.6705708469191 139.74975674523287 37.3 35.67055974650796 139.74975025054206 37.3 35.67055974650796 139.74975025054206 41.05 35.67055974650796 139.74975025054206 42.55 35.6705708469191 139.74975674523287 42.55 35.6705708469191 139.74975674523287 37.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-77dfb463-a1de-4a27-8aa8-6454d4ff44c5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-77dfb463-a1de-4a27-8aa8-6454d4ff44c5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-77dfb463-a1de-4a27-8aa8-6454d4ff44c5">
											<gml:posList>35.6705438205632 139.74979111629864 42.55 35.67055974650796 139.74975025054206 42.55 35.67055974650796 139.74975025054206 41.05 35.6705438205632 139.74979111629864 41.05 35.6705438205632 139.74979111629864 42.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2a6137c4-e9c5-4a25-bd13-52804c112b71">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a6137c4-e9c5-4a25-bd13-52804c112b71">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a6137c4-e9c5-4a25-bd13-52804c112b71">
											<gml:posList>35.6705708469191 139.74975674523287 42.55 35.670554920972165 139.74979761099382 42.55 35.670554920972165 139.74979761099382 37.3 35.6705708469191 139.74975674523287 37.3 35.6705708469191 139.74975674523287 42.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0265b358-4c02-4134-b8ff-9f02c8df6ac0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0265b358-4c02-4134-b8ff-9f02c8df6ac0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0265b358-4c02-4134-b8ff-9f02c8df6ac0">
											<gml:posList>35.67052565953315 139.74978048660762 41.05 35.670516777404025 139.74977529306625 41.05 35.670516777404025 139.74977529306625 37.3 35.67052565953315 139.74978048660762 37.3 35.67052565953315 139.74978048660762 41.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b8c9064b-0a58-4168-8652-3db1d2d3345c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8c9064b-0a58-4168-8652-3db1d2d3345c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8c9064b-0a58-4168-8652-3db1d2d3345c">
											<gml:posList>35.6707063924756 139.74984347208425 48.6 35.67074269809808 139.74975009295642 48.6 35.67074269809808 139.74975009295642 37.3 35.6707063924756 139.74984347208425 37.3 35.6707063924756 139.74984347208425 48.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7d7351d0-fec6-4cc3-8eea-ab75ab696d35">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d7351d0-fec6-4cc3-8eea-ab75ab696d35">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d7351d0-fec6-4cc3-8eea-ab75ab696d35">
											<gml:posList>35.67058301916311 139.7498140517344 37.3 35.670554920972165 139.74979761099382 37.3 35.670554920972165 139.74979761099382 42.55 35.6705438205632 139.74979111629864 42.55 35.6705438205632 139.74979111629864 41.05 35.67052565953315 139.74978048660762 41.05 35.67052565953315 139.74978048660762 44.3 35.67058301916311 139.7498140517344 44.3 35.67058301916311 139.7498140517344 37.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2b1585fd-b37c-4a0f-9499-3a5e19880660">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b1585fd-b37c-4a0f-9499-3a5e19880660">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b1585fd-b37c-4a0f-9499-3a5e19880660">
											<gml:posList>35.67051203700804 139.74981546227517 44.3 35.67052565953315 139.74978048660762 44.3 35.67052565953315 139.74978048660762 41.05 35.67052565953315 139.74978048660762 37.3 35.67051203700804 139.74981546227517 37.3 35.67051203700804 139.74981546227517 44.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fc77b240-9150-46ec-9327-9ce1bd341070">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc77b240-9150-46ec-9327-9ce1bd341070">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc77b240-9150-46ec-9327-9ce1bd341070">
											<gml:posList>35.67042395520791 139.749777035696 6.59 35.670569396620756 139.749849016375 6.59 35.670569396620756 139.749849016375 37.3 35.67042395520791 139.749777035696 37.3 35.67042395520791 139.749777035696 6.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c5d1b9a9-82f7-421c-af98-cb9e58c4399f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c5d1b9a9-82f7-421c-af98-cb9e58c4399f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c5d1b9a9-82f7-421c-af98-cb9e58c4399f">
											<gml:posList>35.67058301916311 139.7498140517344 37.3 35.67058301916311 139.7498140517344 44.3 35.670569396620756 139.749849016375 44.3 35.670569396620756 139.749849016375 37.3 35.670569396620756 139.749849016375 6.59 35.6705803738322 139.7498208369108 6.59 35.6705803738322 139.7498208369108 37.3 35.67058301916311 139.7498140517344 37.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-57ec7890-153f-4656-93f9-a1070fd0a682">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-57ec7890-153f-4656-93f9-a1070fd0a682">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-57ec7890-153f-4656-93f9-a1070fd0a682">
											<gml:posList>35.670569396620756 139.749849016375 44.3 35.67051203700804 139.74981546227517 44.3 35.67051203700804 139.74981546227517 37.3 35.670569396620756 139.749849016375 37.3 35.670569396620756 139.749849016375 44.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-16eac517-fafc-43f9-953b-f5e45a4fe7ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16eac517-fafc-43f9-953b-f5e45a4fe7ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16eac517-fafc-43f9-953b-f5e45a4fe7ee">
											<gml:posList>35.67078947127618 139.74977740592226 48.6 35.67075316562521 139.74987077404603 48.6 35.67075316562521 139.74987077404603 37.3 35.67073691579656 139.74991257915067 37.3 35.67073691579656 139.74991257915067 6.59 35.67078947127618 139.74977740592226 6.59 35.67078947127618 139.74977740592226 48.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6e511395-bc3e-43b9-9b50-3e41425d2107">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e511395-bc3e-43b9-9b50-3e41425d2107">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e511395-bc3e-43b9-9b50-3e41425d2107">
											<gml:posList>35.6705803738322 139.7498208369108 6.59 35.67073691579656 139.74991257915067 6.59 35.67073691579656 139.74991257915067 37.3 35.6705803738322 139.7498208369108 37.3 35.6705803738322 139.7498208369108 6.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-df366e7e-f0fd-47fb-bcab-b1b0e18058f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df366e7e-f0fd-47fb-bcab-b1b0e18058f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df366e7e-f0fd-47fb-bcab-b1b0e18058f6">
											<gml:posList>35.67075316562521 139.74987077404603 48.6 35.6707063924756 139.74984347208425 48.6 35.6707063924756 139.74984347208425 37.3 35.67075316562521 139.74987077404603 37.3 35.67075316562521 139.74987077404603 48.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4465</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">545.6186</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>8</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>