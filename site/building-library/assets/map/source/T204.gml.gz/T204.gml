<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_378ff297-9bd0-432c-bdd9-3bb1a46a9bf7">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">422</bldg:usage>
			<bldg:measuredHeight uom="m">7.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66789935376632 139.74226976765044 0 35.667952467585245 139.74230008362483 0 35.66796290271229 139.7422725674206 0 35.667979314794756 139.74228193782196 0 35.66804804272109 139.74210092730993 0 35.667978516754154 139.74206124107175 0 35.66789935376632 139.74226976765044 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66789935376632 139.74226976765044 28.34 35.667978516754154 139.74206124107175 28.34 35.66804804272109 139.74210092730993 28.34 35.667979314794756 139.74228193782196 28.34 35.66796290271229 139.7422725674206 28.34 35.667952467585245 139.74230008362483 28.34 35.66789935376632 139.74226976765044 28.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66789935376632 139.74226976765044 28.34 35.667952467585245 139.74230008362483 28.34 35.667952467585245 139.74230008362483 36.07 35.66789935376632 139.74226976765044 36.07 35.66789935376632 139.74226976765044 28.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667952467585245 139.74230008362483 28.34 35.66796290271229 139.7422725674206 28.34 35.66796290271229 139.7422725674206 36.07 35.667952467585245 139.74230008362483 36.07 35.667952467585245 139.74230008362483 28.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66796290271229 139.7422725674206 28.34 35.667979314794756 139.74228193782196 28.34 35.667979314794756 139.74228193782196 36.07 35.66796290271229 139.7422725674206 36.07 35.66796290271229 139.7422725674206 28.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667979314794756 139.74228193782196 28.34 35.66804804272109 139.74210092730993 28.34 35.66804804272109 139.74210092730993 36.07 35.667979314794756 139.74228193782196 36.07 35.667979314794756 139.74228193782196 28.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66804804272109 139.74210092730993 28.34 35.667978516754154 139.74206124107175 28.34 35.667978516754154 139.74206124107175 36.07 35.66804804272109 139.74210092730993 36.07 35.66804804272109 139.74210092730993 28.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667978516754154 139.74206124107175 28.34 35.66789935376632 139.74226976765044 28.34 35.66789935376632 139.74226976765044 36.07 35.667978516754154 139.74206124107175 36.07 35.667978516754154 139.74206124107175 28.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66789935376632 139.74226976765044 36.07 35.667952467585245 139.74230008362483 36.07 35.66796290271229 139.7422725674206 36.07 35.667979314794756 139.74228193782196 36.07 35.66804804272109 139.74210092730993 36.07 35.667978516754154 139.74206124107175 36.07 35.66789935376632 139.74226976765044 36.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-79782ea3-7851-41ac-ab97-3f29e703be3a"/>
							<gml:surfaceMember xlink:href="#poly-0a96f7aa-3c4e-41b0-9e17-85feb890a5ac"/>
							<gml:surfaceMember xlink:href="#poly-fdd98a21-1704-4053-ac67-ad25e5fdb0b7"/>
							<gml:surfaceMember xlink:href="#poly-330529de-b3e0-41c7-b9d2-eb54e5fb0138"/>
							<gml:surfaceMember xlink:href="#poly-d293caa8-01cc-4bc8-ae5d-6becff4cc4ba"/>
							<gml:surfaceMember xlink:href="#poly-93e6576d-cd9b-42e4-9c0e-d0994931d5e8"/>
							<gml:surfaceMember xlink:href="#poly-6a7ffc5e-0744-4a08-9cb9-d1e545953116"/>
							<gml:surfaceMember xlink:href="#poly-96cbd228-7ebd-4403-a275-e6da683bf375"/>
							<gml:surfaceMember xlink:href="#poly-4dcdc024-fad6-43b9-ade3-47551e3be43d"/>
							<gml:surfaceMember xlink:href="#poly-8d0a5fdb-6987-44c6-8531-aab08a37bf88"/>
							<gml:surfaceMember xlink:href="#poly-0ddd3b03-a203-4b67-9e14-5f51b452e765"/>
							<gml:surfaceMember xlink:href="#poly-51bb1a4b-5b53-49a2-b0b0-37ce0fc08a3b"/>
							<gml:surfaceMember xlink:href="#poly-465d2c33-7f2b-4cd7-b5df-00481b5b8e43"/>
							<gml:surfaceMember xlink:href="#poly-329ea38f-06cd-44e1-be5b-39fd83212907"/>
							<gml:surfaceMember xlink:href="#poly-e04359fa-64aa-43f2-8de4-3e4d1d151ddb"/>
							<gml:surfaceMember xlink:href="#poly-ccf9615d-4ec9-45aa-aabc-a8257d3ed49b"/>
							<gml:surfaceMember xlink:href="#poly-7f0aab48-1a1a-4c21-bbc6-4be84da77f35"/>
							<gml:surfaceMember xlink:href="#poly-4cd789fb-154a-4ca1-83a7-a71b9106abc4"/>
							<gml:surfaceMember xlink:href="#poly-5ad6e1a9-ab7c-4333-8ccc-a032c580a7e3"/>
							<gml:surfaceMember xlink:href="#poly-384000c7-9924-4afe-a57f-6d57a875ae27"/>
							<gml:surfaceMember xlink:href="#poly-d688768a-428b-4864-b66a-0c8f07456dc4"/>
							<gml:surfaceMember xlink:href="#poly-ef7bfb1e-16f5-4025-80fa-689acf065658"/>
							<gml:surfaceMember xlink:href="#poly-d2db7ab3-af36-43de-8fd2-63e6f86879d0"/>
							<gml:surfaceMember xlink:href="#poly-af2bf7d2-9e69-471b-90e0-e405af0f4291"/>
							<gml:surfaceMember xlink:href="#poly-caeb91a1-5906-44d4-ae74-56bcd730b135"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_378ff297-9bd0-432c-bdd9-3bb1a46a9bf7_BuildingInstallation_1061">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e7f5e75a-df5a-4456-9cef-544e73cb7e64">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66795799711483 139.74226975628045 32.1 35.66795028823719 139.74229077438434 32.1 35.66790521880383 139.7422659280559 32.1 35.667913224536946 139.74224412536395 32.1 35.66791461326084 139.74224493013853 32.1 35.6679073811209 139.7422646332276 32.1 35.66794950183815 139.74228785915307 32.1 35.66795647313509 139.74226888538308 32.1 35.66795799711483 139.74226975628045 32.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f6636ee-f851-4a73-821f-7859c4497b80">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66796666995163 139.74210518420875 32.1 35.667977185127974 139.74207630923402 32.1 35.668035140403646 139.7421079892975 32.1 35.66802422044704 139.74213798038875 32.1 35.66802250710281 139.7421370102951 32.1 35.66803274343854 139.74210889779127 32.1 35.667978142659 139.7420790475346 32.1 35.66796829312539 139.74210611021994 32.1 35.66796666995163 139.74210518420875 32.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-31ea1f53-1de0-4d0b-9509-faf77a646637">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-31ea1f53-1de0-4d0b-9509-faf77a646637_0">
											<gml:posList>35.66796666995163 139.74210518420875 34.016 35.667977185127974 139.74207630923402 34.016 35.667977185127974 139.74207630923402 32.1 35.66796666995163 139.74210518420875 32.1 35.66796666995163 139.74210518420875 34.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8ff0ec1b-99e5-4529-848d-5a3fab92d330">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8ff0ec1b-99e5-4529-848d-5a3fab92d330_0">
											<gml:posList>35.667977185127974 139.74207630923402 32.1 35.667977185127974 139.74207630923402 34.016 35.668035140403646 139.7421079892975 34.016 35.668035140403646 139.7421079892975 32.1 35.667977185127974 139.74207630923402 32.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-985e2d99-6af2-4942-9ecb-20a1bf611e7e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-985e2d99-6af2-4942-9ecb-20a1bf611e7e_0">
											<gml:posList>35.66796829312539 139.74210611021994 34.016 35.66796829312539 139.74210611021994 32.1 35.667978142659 139.7420790475346 32.1 35.667978142659 139.7420790475346 34.016 35.66796829312539 139.74210611021994 34.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eff1703e-ede9-4351-bd25-62c22ed7fc95">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eff1703e-ede9-4351-bd25-62c22ed7fc95_0">
											<gml:posList>35.66803274343854 139.74210889779127 32.1 35.66803274343854 139.74210889779127 34.016 35.667978142659 139.7420790475346 34.016 35.667978142659 139.7420790475346 32.1 35.66803274343854 139.74210889779127 32.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-620cc34c-0bcc-4306-b3c1-f87fc5c20491">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-620cc34c-0bcc-4306-b3c1-f87fc5c20491_0">
											<gml:posList>35.66796666995163 139.74210518420875 32.1 35.66796829312539 139.74210611021994 32.1 35.66796829312539 139.74210611021994 34.016 35.66796666995163 139.74210518420875 34.016 35.66796666995163 139.74210518420875 32.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c44445e-3a80-42e4-bcbb-7f0e411e3e16">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6c44445e-3a80-42e4-bcbb-7f0e411e3e16_0">
											<gml:posList>35.667978142659 139.7420790475346 34.016 35.66803274343854 139.74210889779127 34.016 35.66802250710281 139.7421370102951 34.016 35.66802422044704 139.74213798038875 34.016 35.668035140403646 139.7421079892975 34.016 35.667977185127974 139.74207630923402 34.016 35.66796666995163 139.74210518420875 34.016 35.66796829312539 139.74210611021994 34.016 35.667978142659 139.7420790475346 34.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75fd74b2-7b75-4dc5-8522-5e2219fe7f28">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-75fd74b2-7b75-4dc5-8522-5e2219fe7f28_0">
											<gml:posList>35.66803274343854 139.74210889779127 34.016 35.66803274343854 139.74210889779127 32.1 35.66802250710281 139.7421370102951 32.1 35.66802250710281 139.7421370102951 33.1 35.66802250710281 139.7421370102951 34.016 35.66803274343854 139.74210889779127 34.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fd387d56-9fb2-48b3-917b-cc56eac52997">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fd387d56-9fb2-48b3-917b-cc56eac52997_0">
											<gml:posList>35.66802422044704 139.74213798038875 33.1 35.66802422044704 139.74213798038875 32.1 35.668035140403646 139.7421079892975 32.1 35.668035140403646 139.7421079892975 34.016 35.66802422044704 139.74213798038875 34.016 35.66802422044704 139.74213798038875 33.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-22b17720-8ef5-40e2-9590-0a72c3ddc9ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-22b17720-8ef5-40e2-9590-0a72c3ddc9ca_0">
											<gml:posList>35.66802422044704 139.74213798038875 32.1 35.66802422044704 139.74213798038875 33.1 35.66802250710281 139.7421370102951 33.1 35.66802250710281 139.7421370102951 32.1 35.66802422044704 139.74213798038875 32.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3aa748a3-2aa4-4a53-9767-b2c5a3102726">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3aa748a3-2aa4-4a53-9767-b2c5a3102726_0">
											<gml:posList>35.66802422044704 139.74213798038875 34.016 35.66802250710281 139.7421370102951 34.016 35.66802250710281 139.7421370102951 33.1 35.66802422044704 139.74213798038875 33.1 35.66802422044704 139.74213798038875 34.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-043412d5-be11-461b-9ba2-dc437e0cd9b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-043412d5-be11-461b-9ba2-dc437e0cd9b0_0">
											<gml:posList>35.66791461326084 139.74224493013853 34.016 35.66791461326084 139.74224493013853 32.1 35.667913224536946 139.74224412536395 32.1 35.667913224536946 139.74224412536395 34.016 35.66791461326084 139.74224493013853 34.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d5d03ee-7d25-4e7a-8f22-1b520459ec33">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4d5d03ee-7d25-4e7a-8f22-1b520459ec33_0">
											<gml:posList>35.66791461326084 139.74224493013853 32.1 35.66791461326084 139.74224493013853 34.016 35.6679073811209 139.7422646332276 34.016 35.6679073811209 139.7422646332276 32.1 35.66791461326084 139.74224493013853 32.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ce82c4b-21da-42f9-b60a-9870a06cd989">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7ce82c4b-21da-42f9-b60a-9870a06cd989_0">
											<gml:posList>35.667913224536946 139.74224412536395 32.1 35.66790521880383 139.7422659280559 32.1 35.66790521880383 139.7422659280559 34.016 35.667913224536946 139.74224412536395 34.016 35.667913224536946 139.74224412536395 32.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-027497b5-0104-49d5-a77e-174511cf49b7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-027497b5-0104-49d5-a77e-174511cf49b7_0">
											<gml:posList>35.66794950183815 139.74228785915307 34.016 35.6679073811209 139.7422646332276 34.016 35.66791461326084 139.74224493013853 34.016 35.667913224536946 139.74224412536395 34.016 35.66790521880383 139.7422659280559 34.016 35.66795028823719 139.74229077438434 34.016 35.66795799711483 139.74226975628045 34.016 35.66795647313509 139.74226888538308 34.016 35.66794950183815 139.74228785915307 34.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-638bd650-0831-4169-b3fa-f56a22affaf9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-638bd650-0831-4169-b3fa-f56a22affaf9_0">
											<gml:posList>35.66795647313509 139.74226888538308 33.564 35.66795647313509 139.74226888538308 34.016 35.66795799711483 139.74226975628045 34.016 35.66795799711483 139.74226975628045 33.418 35.66795647313509 139.74226888538308 33.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bcf26ec6-8512-4dc8-b348-4e8457c037fa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bcf26ec6-8512-4dc8-b348-4e8457c037fa_0">
											<gml:posList>35.66795799711483 139.74226975628045 32.1 35.66795647313509 139.74226888538308 32.1 35.66795647313509 139.74226888538308 33.1 35.66795799711483 139.74226975628045 33.1 35.66795799711483 139.74226975628045 32.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a284d22-747b-4a65-ac31-a25ac0f1f118">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9a284d22-747b-4a65-ac31-a25ac0f1f118_0">
											<gml:posList>35.66795799711483 139.74226975628045 33.418 35.66795799711483 139.74226975628045 33.1 35.66795647313509 139.74226888538308 33.1 35.66795647313509 139.74226888538308 33.564 35.66795799711483 139.74226975628045 33.418</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c913305-809e-4710-8b3e-665b7f07f833">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c913305-809e-4710-8b3e-665b7f07f833_0">
											<gml:posList>35.6679073811209 139.7422646332276 34.016 35.66794950183815 139.74228785915307 34.016 35.66794950183815 139.74228785915307 32.1 35.6679073811209 139.7422646332276 32.1 35.6679073811209 139.7422646332276 34.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-55599e45-fe6a-4675-906f-ea1c5d697005">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-55599e45-fe6a-4675-906f-ea1c5d697005_0">
											<gml:posList>35.66790521880383 139.7422659280559 32.1 35.66795028823719 139.74229077438434 32.1 35.66795028823719 139.74229077438434 34.016 35.66790521880383 139.7422659280559 34.016 35.66790521880383 139.7422659280559 32.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75f11634-c30e-4c96-a3f3-ad9e419d7b7d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-75f11634-c30e-4c96-a3f3-ad9e419d7b7d_0">
											<gml:posList>35.66794950183815 139.74228785915307 32.1 35.66794950183815 139.74228785915307 34.016 35.66795647313509 139.74226888538308 34.016 35.66795647313509 139.74226888538308 33.564 35.66795647313509 139.74226888538308 33.1 35.66795647313509 139.74226888538308 32.1 35.66794950183815 139.74228785915307 32.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a0d9d583-b09d-4a7f-b82f-25c9774715b7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a0d9d583-b09d-4a7f-b82f-25c9774715b7_0">
											<gml:posList>35.66795028823719 139.74229077438434 34.016 35.66795028823719 139.74229077438434 32.1 35.66795799711483 139.74226975628045 32.1 35.66795799711483 139.74226975628045 33.1 35.66795799711483 139.74226975628045 33.418 35.66795799711483 139.74226975628045 34.016 35.66795028823719 139.74229077438434 34.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-79782ea3-7851-41ac-ab97-3f29e703be3a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79782ea3-7851-41ac-ab97-3f29e703be3a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79782ea3-7851-41ac-ab97-3f29e703be3a">
											<gml:posList>35.66797851675414 139.74206124107172 28.34 35.668048042721054 139.74210092730993 28.34 35.667979314794756 139.74228193782196 28.34 35.667962902712276 139.7422725674206 28.34 35.66795246758523 139.7423000836248 28.34 35.6678993537663 139.74226976765044 28.34 35.66797851675414 139.74206124107172 28.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0a96f7aa-3c4e-41b0-9e17-85feb890a5ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a96f7aa-3c4e-41b0-9e17-85feb890a5ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a96f7aa-3c4e-41b0-9e17-85feb890a5ac">
											<gml:posList>35.66790982489132 139.74224218514414 33.1 35.6678993537663 139.74226976765044 33.1 35.66790175060737 139.74226869347436 33.1 35.66791145708611 139.7422431221931 33.1 35.66790982489132 139.74224218514414 33.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fdd98a21-1704-4053-ac67-ad25e5fdb0b7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fdd98a21-1704-4053-ac67-ad25e5fdb0b7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fdd98a21-1704-4053-ac67-ad25e5fdb0b7">
											<gml:posList>35.6678993537663 139.74226976765044 33.1 35.66795246758523 139.7423000836248 33.1 35.66795159103245 139.7422971464039 33.1 35.66790175060737 139.74226869347436 33.1 35.6678993537663 139.74226976765044 33.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-330529de-b3e0-41c7-b9d2-eb54e5fb0138">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-330529de-b3e0-41c7-b9d2-eb54e5fb0138">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-330529de-b3e0-41c7-b9d2-eb54e5fb0138">
											<gml:posList>35.66795159103245 139.7422971464039 32.1 35.667961270517715 139.74227163037045 32.1 35.66791145708611 139.7422431221931 32.1 35.66790175060737 139.74226869347436 32.1 35.66795159103245 139.7422971464039 32.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d293caa8-01cc-4bc8-ae5d-6becff4cc4ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d293caa8-01cc-4bc8-ae5d-6becff4cc4ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d293caa8-01cc-4bc8-ae5d-6becff4cc4ba">
											<gml:posList>35.66795246758523 139.7423000836248 33.1 35.667962902712276 139.7422725674206 33.1 35.667961270517715 139.74227163037045 33.1 35.66795159103245 139.7422971464039 33.1 35.66795246758523 139.7423000836248 33.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-93e6576d-cd9b-42e4-9c0e-d0994931d5e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-93e6576d-cd9b-42e4-9c0e-d0994931d5e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-93e6576d-cd9b-42e4-9c0e-d0994931d5e8">
											<gml:posList>35.66790982489132 139.74224218514414 35.934 35.667979314794756 139.74228193782196 35.934 35.6680322371216 139.74214255533474 35.934 35.66796269317421 139.74210291327236 35.934 35.66790982489132 139.74224218514414 35.934</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6a7ffc5e-0744-4a08-9cb9-d1e545953116">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a7ffc5e-0744-4a08-9cb9-d1e545953116">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a7ffc5e-0744-4a08-9cb9-d1e545953116">
											<gml:posList>35.66797851675414 139.74206124107172 33.1 35.66796269317421 139.74210291327236 33.1 35.667964325370086 139.7421038503191 33.1 35.66797939331268 139.74206417829106 33.1 35.66797851675414 139.74206124107172 33.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-96cbd228-7ebd-4403-a275-e6da683bf375">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96cbd228-7ebd-4403-a275-e6da683bf375">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96cbd228-7ebd-4403-a275-e6da683bf375">
											<gml:posList>35.66797939331268 139.74206417829106 32.1 35.667964325370086 139.7421038503191 32.1 35.668030604934415 139.74214162933234 32.1 35.66804564588154 139.742102001493 32.1 35.66797939331268 139.74206417829106 32.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4dcdc024-fad6-43b9-ade3-47551e3be43d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4dcdc024-fad6-43b9-ade3-47551e3be43d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4dcdc024-fad6-43b9-ade3-47551e3be43d">
											<gml:posList>35.668048042721054 139.74210092730993 33.1 35.66797851675414 139.74206124107172 33.1 35.66797939331268 139.74206417829106 33.1 35.66804564588154 139.742102001493 33.1 35.668048042721054 139.74210092730993 33.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8d0a5fdb-6987-44c6-8531-aab08a37bf88">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d0a5fdb-6987-44c6-8531-aab08a37bf88">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d0a5fdb-6987-44c6-8531-aab08a37bf88">
											<gml:posList>35.6680322371216 139.74214255533474 33.1 35.668048042721054 139.74210092730993 33.1 35.66804564588154 139.742102001493 33.1 35.668030604934415 139.74214162933234 33.1 35.6680322371216 139.74214255533474 33.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0ddd3b03-a203-4b67-9e14-5f51b452e765">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ddd3b03-a203-4b67-9e14-5f51b452e765">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ddd3b03-a203-4b67-9e14-5f51b452e765">
											<gml:posList>35.667961270517715 139.74227163037045 33.1 35.66791145708611 139.7422431221931 33.1 35.66791145708611 139.7422431221931 32.1 35.667961270517715 139.74227163037045 32.1 35.667961270517715 139.74227163037045 33.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-51bb1a4b-5b53-49a2-b0b0-37ce0fc08a3b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-51bb1a4b-5b53-49a2-b0b0-37ce0fc08a3b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-51bb1a4b-5b53-49a2-b0b0-37ce0fc08a3b">
											<gml:posList>35.66795159103245 139.7422971464039 33.1 35.667961270517715 139.74227163037045 33.1 35.667961270517715 139.74227163037045 32.1 35.66795159103245 139.7422971464039 32.1 35.66795159103245 139.7422971464039 33.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-465d2c33-7f2b-4cd7-b5df-00481b5b8e43">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-465d2c33-7f2b-4cd7-b5df-00481b5b8e43">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-465d2c33-7f2b-4cd7-b5df-00481b5b8e43">
											<gml:posList>35.66797939331268 139.74206417829106 33.1 35.667964325370086 139.7421038503191 33.1 35.667964325370086 139.7421038503191 32.1 35.66797939331268 139.74206417829106 32.1 35.66797939331268 139.74206417829106 33.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-329ea38f-06cd-44e1-be5b-39fd83212907">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-329ea38f-06cd-44e1-be5b-39fd83212907">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-329ea38f-06cd-44e1-be5b-39fd83212907">
											<gml:posList>35.667964325370086 139.7421038503191 33.1 35.668030604934415 139.74214162933234 33.1 35.668030604934415 139.74214162933234 32.1 35.667964325370086 139.7421038503191 32.1 35.667964325370086 139.7421038503191 33.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e04359fa-64aa-43f2-8de4-3e4d1d151ddb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e04359fa-64aa-43f2-8de4-3e4d1d151ddb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e04359fa-64aa-43f2-8de4-3e4d1d151ddb">
											<gml:posList>35.668048042721054 139.74210092730993 28.34 35.66797851675414 139.74206124107172 28.34 35.66797851675414 139.74206124107172 33.1 35.668048042721054 139.74210092730993 33.1 35.668048042721054 139.74210092730993 28.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ccf9615d-4ec9-45aa-aabc-a8257d3ed49b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ccf9615d-4ec9-45aa-aabc-a8257d3ed49b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ccf9615d-4ec9-45aa-aabc-a8257d3ed49b">
											<gml:posList>35.66804564588154 139.742102001493 33.1 35.66797939331268 139.74206417829106 33.1 35.66797939331268 139.74206417829106 32.1 35.66804564588154 139.742102001493 32.1 35.66804564588154 139.742102001493 33.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7f0aab48-1a1a-4c21-bbc6-4be84da77f35">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f0aab48-1a1a-4c21-bbc6-4be84da77f35">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f0aab48-1a1a-4c21-bbc6-4be84da77f35">
											<gml:posList>35.668030604934415 139.74214162933234 33.1 35.66804564588154 139.742102001493 33.1 35.66804564588154 139.742102001493 32.1 35.668030604934415 139.74214162933234 32.1 35.668030604934415 139.74214162933234 33.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4cd789fb-154a-4ca1-83a7-a71b9106abc4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4cd789fb-154a-4ca1-83a7-a71b9106abc4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4cd789fb-154a-4ca1-83a7-a71b9106abc4">
											<gml:posList>35.66796269317421 139.74210291327236 35.934 35.6680322371216 139.74214255533474 35.934 35.6680322371216 139.74214255533474 33.1 35.668030604934415 139.74214162933234 33.1 35.667964325370086 139.7421038503191 33.1 35.66796269317421 139.74210291327236 33.1 35.66796269317421 139.74210291327236 35.934</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5ad6e1a9-ab7c-4333-8ccc-a032c580a7e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5ad6e1a9-ab7c-4333-8ccc-a032c580a7e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5ad6e1a9-ab7c-4333-8ccc-a032c580a7e3">
											<gml:posList>35.66790982489132 139.74224218514414 33.1 35.66790982489132 139.74224218514414 35.934 35.66796269317421 139.74210291327236 35.934 35.66796269317421 139.74210291327236 33.1 35.66797851675414 139.74206124107172 33.1 35.66797851675414 139.74206124107172 28.34 35.6678993537663 139.74226976765044 28.34 35.6678993537663 139.74226976765044 33.1 35.66790982489132 139.74224218514414 33.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-384000c7-9924-4afe-a57f-6d57a875ae27">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-384000c7-9924-4afe-a57f-6d57a875ae27">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-384000c7-9924-4afe-a57f-6d57a875ae27">
											<gml:posList>35.667979314794756 139.74228193782196 28.34 35.668048042721054 139.74210092730993 28.34 35.668048042721054 139.74210092730993 33.1 35.6680322371216 139.74214255533474 33.1 35.6680322371216 139.74214255533474 35.934 35.667979314794756 139.74228193782196 35.934 35.667979314794756 139.74228193782196 28.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d688768a-428b-4864-b66a-0c8f07456dc4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d688768a-428b-4864-b66a-0c8f07456dc4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d688768a-428b-4864-b66a-0c8f07456dc4">
											<gml:posList>35.66791145708611 139.7422431221931 33.1 35.66790175060737 139.74226869347436 33.1 35.66790175060737 139.74226869347436 32.1 35.66791145708611 139.7422431221931 32.1 35.66791145708611 139.7422431221931 33.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ef7bfb1e-16f5-4025-80fa-689acf065658">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef7bfb1e-16f5-4025-80fa-689acf065658">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef7bfb1e-16f5-4025-80fa-689acf065658">
											<gml:posList>35.66790982489132 139.74224218514414 35.934 35.66790982489132 139.74224218514414 33.1 35.66791145708611 139.7422431221931 33.1 35.667961270517715 139.74227163037045 33.1 35.667962902712276 139.7422725674206 33.1 35.667962902712276 139.7422725674206 28.34 35.667979314794756 139.74228193782196 28.34 35.667979314794756 139.74228193782196 35.934 35.66790982489132 139.74224218514414 35.934</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d2db7ab3-af36-43de-8fd2-63e6f86879d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d2db7ab3-af36-43de-8fd2-63e6f86879d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d2db7ab3-af36-43de-8fd2-63e6f86879d0">
											<gml:posList>35.66790175060737 139.74226869347436 33.1 35.66795159103245 139.7422971464039 33.1 35.66795159103245 139.7422971464039 32.1 35.66790175060737 139.74226869347436 32.1 35.66790175060737 139.74226869347436 33.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-af2bf7d2-9e69-471b-90e0-e405af0f4291">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af2bf7d2-9e69-471b-90e0-e405af0f4291">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af2bf7d2-9e69-471b-90e0-e405af0f4291">
											<gml:posList>35.6678993537663 139.74226976765044 28.34 35.66795246758523 139.7423000836248 28.34 35.66795246758523 139.7423000836248 33.1 35.6678993537663 139.74226976765044 33.1 35.6678993537663 139.74226976765044 28.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-caeb91a1-5906-44d4-ae74-56bcd730b135">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-caeb91a1-5906-44d4-ae74-56bcd730b135">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-caeb91a1-5906-44d4-ae74-56bcd730b135">
											<gml:posList>35.66795246758523 139.7423000836248 28.34 35.667962902712276 139.7422725674206 28.34 35.667962902712276 139.7422725674206 33.1 35.66795246758523 139.7423000836248 33.1 35.66795246758523 139.7423000836248 28.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-11073</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">171.63775</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1002</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">6</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1123</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.04</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">12</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>