<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_37b44d91-fe3b-496b-b2e0-b3a437a521b1">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">22.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.672918929445515 139.73877355877391 0 35.67289363375621 139.73870068101314 0 35.67293889121285 139.73867715354115 0 35.67290419981615 139.73857711224144 0 35.67280400826041 139.73862933744178 0 35.67286173682642 139.73879585199356 0 35.67288693794489 139.73878276518943 0 35.67288910618147 139.73878905919707 0 35.672918929445515 139.73877355877391 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672918929445515 139.73877355877391 8.09 35.67288910618147 139.73878905919707 8.09 35.67288693794489 139.73878276518943 8.09 35.67286173682642 139.73879585199356 8.09 35.67280400826041 139.73862933744178 8.09 35.67290419981615 139.73857711224144 8.09 35.67293889121285 139.73867715354115 8.09 35.67289363375621 139.73870068101314 8.09 35.672918929445515 139.73877355877391 8.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672918929445515 139.73877355877391 8.09 35.67289363375621 139.73870068101314 8.09 35.67289363375621 139.73870068101314 30.32 35.672918929445515 139.73877355877391 30.32 35.672918929445515 139.73877355877391 8.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67289363375621 139.73870068101314 8.09 35.67293889121285 139.73867715354115 8.09 35.67293889121285 139.73867715354115 30.32 35.67289363375621 139.73870068101314 30.32 35.67289363375621 139.73870068101314 8.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67293889121285 139.73867715354115 8.09 35.67290419981615 139.73857711224144 8.09 35.67290419981615 139.73857711224144 30.32 35.67293889121285 139.73867715354115 30.32 35.67293889121285 139.73867715354115 8.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67290419981615 139.73857711224144 8.09 35.67280400826041 139.73862933744178 8.09 35.67280400826041 139.73862933744178 30.32 35.67290419981615 139.73857711224144 30.32 35.67290419981615 139.73857711224144 8.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67280400826041 139.73862933744178 8.09 35.67286173682642 139.73879585199356 8.09 35.67286173682642 139.73879585199356 30.32 35.67280400826041 139.73862933744178 30.32 35.67280400826041 139.73862933744178 8.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67286173682642 139.73879585199356 8.09 35.67288693794489 139.73878276518943 8.09 35.67288693794489 139.73878276518943 30.32 35.67286173682642 139.73879585199356 30.32 35.67286173682642 139.73879585199356 8.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67288693794489 139.73878276518943 8.09 35.67288910618147 139.73878905919707 8.09 35.67288910618147 139.73878905919707 30.32 35.67288693794489 139.73878276518943 30.32 35.67288693794489 139.73878276518943 8.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67288910618147 139.73878905919707 8.09 35.672918929445515 139.73877355877391 8.09 35.672918929445515 139.73877355877391 30.32 35.67288910618147 139.73878905919707 30.32 35.67288910618147 139.73878905919707 8.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672918929445515 139.73877355877391 30.32 35.67289363375621 139.73870068101314 30.32 35.67293889121285 139.73867715354115 30.32 35.67290419981615 139.73857711224144 30.32 35.67280400826041 139.73862933744178 30.32 35.67286173682642 139.73879585199356 30.32 35.67288693794489 139.73878276518943 30.32 35.67288910618147 139.73878905919707 30.32 35.672918929445515 139.73877355877391 30.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-7c6f72ef-2c01-4f39-8629-e78db8a5ffe5"/>
							<gml:surfaceMember xlink:href="#poly-bc072ebc-6795-4b70-a9ea-fc572fd10a16"/>
							<gml:surfaceMember xlink:href="#poly-4aada7a2-c4e0-495d-b434-504cdb28fce5"/>
							<gml:surfaceMember xlink:href="#poly-50294c53-5059-4f44-a136-ab88a8e97a04"/>
							<gml:surfaceMember xlink:href="#poly-6c37008b-e1e0-4b63-b447-893e50c7a3c9"/>
							<gml:surfaceMember xlink:href="#poly-5ba9d30b-1f87-405d-b961-06b032c2dac8"/>
							<gml:surfaceMember xlink:href="#poly-054be07c-ba1d-43bf-9ac2-6401adf17f7c"/>
							<gml:surfaceMember xlink:href="#poly-3ae497f9-7726-41e2-a187-18b74a930108"/>
							<gml:surfaceMember xlink:href="#poly-68feb449-5e7d-4c45-90ed-da70e5f62f80"/>
							<gml:surfaceMember xlink:href="#poly-09f81b06-1b0c-4862-9cc3-a7f94a1b7b1a"/>
							<gml:surfaceMember xlink:href="#poly-bd7b9898-7e61-4da2-89b9-8f26479a21f6"/>
							<gml:surfaceMember xlink:href="#poly-8af17da6-f77f-47fe-bf47-e2a48c7bc597"/>
							<gml:surfaceMember xlink:href="#poly-2cbbd431-848d-45aa-a8b4-7d7d111ca469"/>
							<gml:surfaceMember xlink:href="#poly-11e73c82-ade2-47d3-b8ba-29deda1e4e85"/>
							<gml:surfaceMember xlink:href="#poly-4c5a7935-b4ff-403f-80d0-384fe7a880c4"/>
							<gml:surfaceMember xlink:href="#poly-7d644270-d569-4ef8-87a5-88e5da0c4db3"/>
							<gml:surfaceMember xlink:href="#poly-a91617e3-c034-4be3-878a-729672395ba4"/>
							<gml:surfaceMember xlink:href="#poly-e9c051bb-dbf9-4139-acd9-317335c3f8c0"/>
							<gml:surfaceMember xlink:href="#poly-2ef49600-d063-4bce-af04-5a69210df76e"/>
							<gml:surfaceMember xlink:href="#poly-c52dd82e-bc7a-40c1-83d8-1920023b03a5"/>
							<gml:surfaceMember xlink:href="#poly-78d84c82-02dc-4b5c-8643-bbfdd0dfc054"/>
							<gml:surfaceMember xlink:href="#poly-8d01ac8d-b8de-4c1b-b436-ec6bcba2e95f"/>
							<gml:surfaceMember xlink:href="#poly-f4b0d7c0-6bac-4619-8602-4572a3c22bfc"/>
							<gml:surfaceMember xlink:href="#poly-4f2bee07-9518-4595-bf11-233aefde7d23"/>
							<gml:surfaceMember xlink:href="#poly-ff387a11-c9bd-4cd0-9420-bed672d349c4"/>
							<gml:surfaceMember xlink:href="#poly-654dceab-cc0b-400c-bd9f-8e55c1dc6829"/>
							<gml:surfaceMember xlink:href="#poly-259edf49-90fb-404c-a815-ef61340c87d8"/>
							<gml:surfaceMember xlink:href="#poly-9a44e8bc-6383-49b6-bf32-8a2528aeaa42"/>
							<gml:surfaceMember xlink:href="#poly-44726774-a75f-41f5-b067-8319ad71688b"/>
							<gml:surfaceMember xlink:href="#poly-a14476e0-e604-49ac-99eb-857dfa682c79"/>
							<gml:surfaceMember xlink:href="#poly-9498c0e3-4533-48e8-a92c-446ef272552a"/>
							<gml:surfaceMember xlink:href="#poly-11c1d6d4-6e85-4b0a-a371-489c6cec7e77"/>
							<gml:surfaceMember xlink:href="#poly-0e86d867-4ebe-4078-93b8-cdb09a742271"/>
							<gml:surfaceMember xlink:href="#poly-f7663555-8dd9-479d-80ca-2cb73b6d003e"/>
							<gml:surfaceMember xlink:href="#poly-78f044e2-e4a3-49bf-bb91-7b12a239827e"/>
							<gml:surfaceMember xlink:href="#poly-a92afe1d-6c57-4cc1-b159-e851632d185d"/>
							<gml:surfaceMember xlink:href="#poly-bd3eecfa-e9f1-49fc-95bf-104d33914393"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_37b44d91-fe3b-496b-b2e0-b3a437a521b1_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-425745d3-440e-4ac4-b906-164e3237a559">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6729002085027 139.73863664712118 30.381 35.67290748838139 139.73863256232406 30.381 35.67292282595297 139.73867359340778 30.381 35.67291554607291 139.73867767820198 30.381 35.6729002085027 139.73863664712118 30.381</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-541d6016-02d4-469b-b9d2-053a1a454443">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67288529737491 139.73864502701372 30.381 35.67289237002525 139.73864105292893 30.381 35.672904175805314 139.73867264332728 30.381 35.67289710315394 139.73867661740988 30.381 35.67288529737491 139.73864502701372 30.381</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dec150d6-4724-4ba5-9de7-9c41f421cae9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dec150d6-4724-4ba5-9de7-9c41f421cae9_0">
											<gml:posList>35.67289237002525 139.73864105292893 30.381 35.67289237002525 139.73864105292893 32.497 35.672904175805314 139.73867264332728 32.497 35.672904175805314 139.73867264332728 30.381 35.67289237002525 139.73864105292893 30.381</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26036972-05eb-403c-9832-b0c1159cc9a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-26036972-05eb-403c-9832-b0c1159cc9a6_0">
											<gml:posList>35.67289237002525 139.73864105292893 30.381 35.67288529737491 139.73864502701372 30.381 35.67288529737491 139.73864502701372 32.497 35.67289237002525 139.73864105292893 32.497 35.67289237002525 139.73864105292893 30.381</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46572bb0-57a8-4242-8cf1-16f6dd152f52">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46572bb0-57a8-4242-8cf1-16f6dd152f52_0">
											<gml:posList>35.67288529737491 139.73864502701372 30.381 35.67289710315394 139.73867661740988 30.381 35.67289710315394 139.73867661740988 32.497 35.67288529737491 139.73864502701372 32.497 35.67288529737491 139.73864502701372 30.381</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-86bdbcdd-0d67-4df3-b259-040411582aea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-86bdbcdd-0d67-4df3-b259-040411582aea_0">
											<gml:posList>35.672904175805314 139.73867264332728 32.497 35.67289237002525 139.73864105292893 32.497 35.67288529737491 139.73864502701372 32.497 35.67289710315394 139.73867661740988 32.497 35.672904175805314 139.73867264332728 32.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0be330e9-2de0-42de-abbb-b1c4acaa81e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0be330e9-2de0-42de-abbb-b1c4acaa81e4_0">
											<gml:posList>35.67289710315394 139.73867661740988 30.381 35.672904175805314 139.73867264332728 30.381 35.672904175805314 139.73867264332728 32.497 35.67289710315394 139.73867661740988 32.497 35.67289710315394 139.73867661740988 30.381</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-98c9df26-c5f5-4436-9802-3ca9819d79de">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-98c9df26-c5f5-4436-9802-3ca9819d79de_0">
											<gml:posList>35.67290748838139 139.73863256232406 30.381 35.6729002085027 139.73863664712118 30.381 35.6729002085027 139.73863664712118 32.497 35.67290748838139 139.73863256232406 32.497 35.67290748838139 139.73863256232406 30.381</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94eadc84-b4bf-42cf-b8f0-fe05f3ce412d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-94eadc84-b4bf-42cf-b8f0-fe05f3ce412d_0">
											<gml:posList>35.6729002085027 139.73863664712118 30.381 35.67291554607291 139.73867767820198 30.381 35.67291554607291 139.73867767820198 32.497 35.6729002085027 139.73863664712118 32.497 35.6729002085027 139.73863664712118 30.381</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-967db3d3-2a73-471c-baa7-d83a5d2756db">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-967db3d3-2a73-471c-baa7-d83a5d2756db_0">
											<gml:posList>35.67292282595297 139.73867359340778 32.497 35.67290748838139 139.73863256232406 32.497 35.6729002085027 139.73863664712118 32.497 35.67291554607291 139.73867767820198 32.497 35.67292282595297 139.73867359340778 32.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d1d1575-891c-4b62-8cfb-479fa5089b61">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d1d1575-891c-4b62-8cfb-479fa5089b61_0">
											<gml:posList>35.67290748838139 139.73863256232406 30.381 35.67290748838139 139.73863256232406 32.497 35.67292282595297 139.73867359340778 32.497 35.67292282595297 139.73867359340778 30.381 35.67290748838139 139.73863256232406 30.381</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-79642238-8e6d-49b2-a82a-17a136bbb381">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-79642238-8e6d-49b2-a82a-17a136bbb381_0">
											<gml:posList>35.67291554607291 139.73867767820198 30.381 35.67292282595297 139.73867359340778 30.381 35.67292282595297 139.73867359340778 32.497 35.67291554607291 139.73867767820198 32.497 35.67291554607291 139.73867767820198 30.381</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_37b44d91-fe3b-496b-b2e0-b3a437a521b1_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-06ac51bd-ccec-4322-a8ba-d5be6104ba30">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-06ac51bd-ccec-4322-a8ba-d5be6104ba30_0">
											<gml:posList>35.67287935546283 139.73866558071435 30.381 35.67286052518907 139.73867628501299 33.066 35.67287935546283 139.73866558071435 33.066 35.67287935546283 139.73866558071435 30.381</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-71584138-6887-4157-a6e7-f9e40762edf3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-71584138-6887-4157-a6e7-f9e40762edf3_0">
											<gml:posList>35.67287935546283 139.73866558071435 30.381 35.67286052518907 139.73867628501299 30.381 35.67286052518907 139.73867628501299 33.066 35.67287935546283 139.73866558071435 30.381</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2bec8f32-2b34-4276-88e2-1d47ed283eba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2bec8f32-2b34-4276-88e2-1d47ed283eba_0">
											<gml:posList>35.67287935546283 139.73866558071435 30.381 35.672886843397315 139.73868536738783 33.066 35.672886843397315 139.73868536738783 30.381 35.67287935546283 139.73866558071435 30.381</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-afb927a2-30d7-4599-93af-d0f4050f8f80">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-afb927a2-30d7-4599-93af-d0f4050f8f80_0">
											<gml:posList>35.67287935546283 139.73866558071435 30.381 35.67287935546283 139.73866558071435 33.066 35.672886843397315 139.73868536738783 33.066 35.67287935546283 139.73866558071435 30.381</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-98f932f5-51e9-4211-81ee-6b774845fb1e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-98f932f5-51e9-4211-81ee-6b774845fb1e_0">
											<gml:posList>35.67287935546283 139.73866558071435 33.066 35.67286802213554 139.73869607167217 33.066 35.672886843397315 139.73868536738783 33.066 35.67287935546283 139.73866558071435 33.066</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-15a9b04c-bf0b-4b84-b748-5538fd9d9348">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-15a9b04c-bf0b-4b84-b748-5538fd9d9348_0">
											<gml:posList>35.67287935546283 139.73866558071435 33.066 35.67286052518907 139.73867628501299 33.066 35.67286802213554 139.73869607167217 33.066 35.67287935546283 139.73866558071435 33.066</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8ae7919-b25a-4692-a7a7-d8bcef1ad1a7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d8ae7919-b25a-4692-a7a7-d8bcef1ad1a7_0">
											<gml:posList>35.67286802213554 139.73869607167217 33.066 35.67286052518907 139.73867628501299 30.381 35.67286802213554 139.73869607167217 30.381 35.67286802213554 139.73869607167217 33.066</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b002737-f980-43a7-ba0c-1fce55123df2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7b002737-f980-43a7-ba0c-1fce55123df2_0">
											<gml:posList>35.67286802213554 139.73869607167217 33.066 35.67286052518907 139.73867628501299 33.066 35.67286052518907 139.73867628501299 30.381 35.67286802213554 139.73869607167217 33.066</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c609a08c-b67b-495d-92ee-3775a8c1079e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c609a08c-b67b-495d-92ee-3775a8c1079e_0">
											<gml:posList>35.67286802213554 139.73869607167217 30.381 35.672886843397315 139.73868536738783 33.066 35.67286802213554 139.73869607167217 33.066 35.67286802213554 139.73869607167217 30.381</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-66dcdd88-4daa-4f1f-b959-a715368aba7b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-66dcdd88-4daa-4f1f-b959-a715368aba7b_0">
											<gml:posList>35.67286802213554 139.73869607167217 30.381 35.672886843397315 139.73868536738783 30.381 35.672886843397315 139.73868536738783 33.066 35.67286802213554 139.73869607167217 30.381</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73a9f653-4b3d-41ff-8241-3185bae1ff13">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73a9f653-4b3d-41ff-8241-3185bae1ff13_0">
											<gml:posList>35.67289315638507 139.73870113448746 30.845 35.67289071464839 139.73870238563603 30.845 35.67289315638507 139.73870113448746 34.446 35.67289315638507 139.73870113448746 30.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f8786fb-2b79-4547-9796-753d262939e1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f8786fb-2b79-4547-9796-753d262939e1_0">
											<gml:posList>35.67289315638507 139.73870113448746 34.446 35.67289071464839 139.73870238563603 30.845 35.67285706200393 139.73871972433525 34.446 35.67289315638507 139.73870113448746 34.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d2a19a69-0876-449b-a789-16385b346209">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d2a19a69-0876-449b-a789-16385b346209_0">
											<gml:posList>35.67285706200393 139.73871972433525 34.446 35.67289071464839 139.73870238563603 30.845 35.67285706200393 139.73871972433525 30.381 35.67285706200393 139.73871972433525 34.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-adb34981-8e2e-47ef-8df7-85cd09d2b5c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-adb34981-8e2e-47ef-8df7-85cd09d2b5c3_0">
											<gml:posList>35.67289071464839 139.73870238563603 30.845 35.67289071464839 139.73870238563603 30.381 35.67285706200393 139.73871972433525 30.381 35.67289071464839 139.73870238563603 30.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-68382f9c-6d4e-444d-b497-d76e990e4e95">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-68382f9c-6d4e-444d-b497-d76e990e4e95_0">
											<gml:posList>35.6729027958627 139.73872891637185 30.845 35.67289315638507 139.73870113448746 34.446 35.6729027958627 139.73872891637185 34.446 35.6729027958627 139.73872891637185 30.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14cac9c5-98dd-4ebd-be92-3b8d4c21ef14">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-14cac9c5-98dd-4ebd-be92-3b8d4c21ef14_0">
											<gml:posList>35.6729027958627 139.73872891637185 30.845 35.67289315638507 139.73870113448746 30.845 35.67289315638507 139.73870113448746 34.446 35.6729027958627 139.73872891637185 30.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c195be3-9507-4814-a109-dad9ec20a02d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c195be3-9507-4814-a109-dad9ec20a02d_0">
											<gml:posList>35.67289071464839 139.73870238563603 30.381 35.67290033605491 139.73873011230805 30.845 35.67290033605491 139.73873011230805 30.381 35.67289071464839 139.73870238563603 30.381</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a993ad46-8402-4406-a8ac-f42184133925">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a993ad46-8402-4406-a8ac-f42184133925_0">
											<gml:posList>35.67289071464839 139.73870238563603 30.381 35.67289071464839 139.73870238563603 30.845 35.67290033605491 139.73873011230805 30.845 35.67289071464839 139.73870238563603 30.381</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af8698a2-46f1-4b95-9c0c-615ace684b0f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-af8698a2-46f1-4b95-9c0c-615ace684b0f_0">
											<gml:posList>35.67285047251996 139.73873062405912 33.125 35.67285926633342 139.73872606248267 34.446 35.67285926633342 139.73872606248267 30.381 35.67285047251996 139.73873062405912 33.125</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-91bc09e2-be49-48ff-aac2-8f881a968b76">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-91bc09e2-be49-48ff-aac2-8f881a968b76_0">
											<gml:posList>35.67285047251996 139.73873062405912 30.381 35.67285047251996 139.73873062405912 33.125 35.67285926633342 139.73872606248267 30.381 35.67285047251996 139.73873062405912 30.381</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-86a8276d-e7b4-41ab-8a5b-c80152091969">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-86a8276d-e7b4-41ab-8a5b-c80152091969_0">
											<gml:posList>35.67290033605491 139.73873011230805 30.381 35.67290033605491 139.73873011230805 30.845 35.67289693017116 139.73873177331802 30.381 35.67290033605491 139.73873011230805 30.381</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7afeab6f-1e20-4dc0-b845-a2d1e7cd94e3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7afeab6f-1e20-4dc0-b845-a2d1e7cd94e3_0">
											<gml:posList>35.67289693017116 139.73873177331802 30.381 35.67290033605491 139.73873011230805 30.845 35.67289693017116 139.73873177331802 34.446 35.67289693017116 139.73873177331802 30.381</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a63315c-6185-4b51-9ed1-c375def1a532">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5a63315c-6185-4b51-9ed1-c375def1a532_0">
											<gml:posList>35.67289693017116 139.73873177331802 34.446 35.67290033605491 139.73873011230805 30.845 35.6729027958627 139.73872891637185 34.446 35.67289693017116 139.73873177331802 34.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f3cc6f91-e77a-4038-87b9-5be759df4f94">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f3cc6f91-e77a-4038-87b9-5be759df4f94_0">
											<gml:posList>35.67290033605491 139.73873011230805 30.845 35.6729027958627 139.73872891637185 30.845 35.6729027958627 139.73872891637185 34.446 35.67290033605491 139.73873011230805 30.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82dda713-8205-44e4-b25d-9406608ea7f9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-82dda713-8205-44e4-b25d-9406608ea7f9_0">
											<gml:posList>35.6729027958627 139.73872891637185 34.446 35.67289315638507 139.73870113448746 34.446 35.67289693017116 139.73873177331802 34.446 35.6729027958627 139.73872891637185 34.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c97076e7-ce88-4334-83fc-4788479e885a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c97076e7-ce88-4334-83fc-4788479e885a_0">
											<gml:posList>35.67290915340418 139.73876698652646 34.446 35.67289693017116 139.73873177331802 34.446 35.6728789517556 139.73878273042172 34.446 35.67290915340418 139.73876698652646 34.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c81cd146-b23b-4e0d-94ef-7437005fbc1a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c81cd146-b23b-4e0d-94ef-7437005fbc1a_0">
											<gml:posList>35.6728789517556 139.73878273042172 34.446 35.67289693017116 139.73873177331802 34.446 35.67285706200393 139.73871972433525 34.446 35.6728789517556 139.73878273042172 34.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bcf64e96-42e3-4e08-9dac-93987dc58c20">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bcf64e96-42e3-4e08-9dac-93987dc58c20_0">
											<gml:posList>35.67289693017116 139.73873177331802 34.446 35.67289315638507 139.73870113448746 34.446 35.67285706200393 139.73871972433525 34.446 35.67289693017116 139.73873177331802 34.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-34ea4665-3a6f-4c4d-9cef-727cfd122683">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-34ea4665-3a6f-4c4d-9cef-727cfd122683_0">
											<gml:posList>35.67290915340418 139.73876698652646 30.381 35.67289693017116 139.73873177331802 34.446 35.67290915340418 139.73876698652646 34.446 35.67290915340418 139.73876698652646 30.381</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-950ddcee-3cbb-4daf-934b-bb5d4e101e04">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-950ddcee-3cbb-4daf-934b-bb5d4e101e04_0">
											<gml:posList>35.67290915340418 139.73876698652646 30.381 35.67289693017116 139.73873177331802 30.381 35.67289693017116 139.73873177331802 34.446 35.67290915340418 139.73876698652646 30.381</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b87e884b-cf5e-4f03-b8dc-3e63efe4323f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b87e884b-cf5e-4f03-b8dc-3e63efe4323f_0">
											<gml:posList>35.67285926633342 139.73872606248267 34.446 35.67285047251996 139.73873062405912 33.125 35.6728789517556 139.73878273042172 34.446 35.67285926633342 139.73872606248267 34.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d7797db-168f-438b-a74b-0ef4f18422d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3d7797db-168f-438b-a74b-0ef4f18422d4_0">
											<gml:posList>35.67285047251996 139.73873062405912 33.125 35.67287117891018 139.73879037279113 33.125 35.6728789517556 139.73878273042172 34.446 35.67285047251996 139.73873062405912 33.125</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e35258c5-04f7-4f81-9149-7888ec2c91fe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e35258c5-04f7-4f81-9149-7888ec2c91fe_0">
											<gml:posList>35.67287117891018 139.73879037279113 33.125 35.67288000876339 139.73878578908435 34.446 35.6728789517556 139.73878273042172 34.446 35.67287117891018 139.73879037279113 33.125</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a7eb8af2-024f-400f-836c-c7e3569a6094">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a7eb8af2-024f-400f-836c-c7e3569a6094_0">
											<gml:posList>35.67287008577823 139.73878722579857 30.381 35.67287008577823 139.73878722579857 30.845 35.67285047251996 139.73873062405912 30.381 35.67287008577823 139.73878722579857 30.381</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-93220457-fd39-45d9-8afc-4c86bc6b29d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-93220457-fd39-45d9-8afc-4c86bc6b29d7_0">
											<gml:posList>35.67285047251996 139.73873062405912 30.381 35.67287008577823 139.73878722579857 30.845 35.67285047251996 139.73873062405912 33.125 35.67285047251996 139.73873062405912 30.381</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4816d1fd-5436-4f8b-b074-b505ca7e1350">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4816d1fd-5436-4f8b-b074-b505ca7e1350_0">
											<gml:posList>35.67285047251996 139.73873062405912 33.125 35.67287008577823 139.73878722579857 30.845 35.67287117891018 139.73879037279113 33.125 35.67285047251996 139.73873062405912 33.125</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-30d1b30c-884c-4fe1-ad6f-209e5a522b23">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-30d1b30c-884c-4fe1-ad6f-209e5a522b23_0">
											<gml:posList>35.67287008577823 139.73878722579857 30.845 35.67287117891018 139.73879037279113 30.845 35.67287117891018 139.73879037279113 33.125 35.67287008577823 139.73878722579857 30.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70e1e169-a5d8-4439-871c-27f9f7d54cb7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-70e1e169-a5d8-4439-871c-27f9f7d54cb7_0">
											<gml:posList>35.672888637478046 139.73877759337392 30.845 35.67287008577823 139.73878722579857 30.381 35.672888637478046 139.73877759337392 30.381 35.672888637478046 139.73877759337392 30.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74b0a253-4531-4ca9-a36b-607024e994a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-74b0a253-4531-4ca9-a36b-607024e994a8_0">
											<gml:posList>35.672888637478046 139.73877759337392 30.845 35.67287008577823 139.73878722579857 30.845 35.67287008577823 139.73878722579857 30.381 35.672888637478046 139.73877759337392 30.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7675c9de-bfd9-4154-b390-49360a4481c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7675c9de-bfd9-4154-b390-49360a4481c1_0">
											<gml:posList>35.67288000876339 139.73878578908435 30.845 35.6728789517556 139.73878273042172 34.446 35.67288000876339 139.73878578908435 34.446 35.67288000876339 139.73878578908435 30.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8ff8be61-3b02-4342-810e-5a1d83c6824b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8ff8be61-3b02-4342-810e-5a1d83c6824b_0">
											<gml:posList>35.67288000876339 139.73878578908435 30.845 35.6728789517556 139.73878273042172 30.845 35.6728789517556 139.73878273042172 34.446 35.67288000876339 139.73878578908435 30.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f4dbfa2-2746-4387-9530-6e041816d847">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0f4dbfa2-2746-4387-9530-6e041816d847_0">
											<gml:posList>35.67288000876339 139.73878578908435 30.845 35.67288000876339 139.73878578908435 34.446 35.67287117891018 139.73879037279113 33.125 35.67288000876339 139.73878578908435 30.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f32309e6-d01f-48f1-8f59-58b0ab097b09">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f32309e6-d01f-48f1-8f59-58b0ab097b09_0">
											<gml:posList>35.67287117891018 139.73879037279113 30.845 35.67288000876339 139.73878578908435 30.845 35.67287117891018 139.73879037279113 33.125 35.67287117891018 139.73879037279113 30.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a0ea44f0-cd07-4b2e-bc68-32ab7a41dd5d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a0ea44f0-cd07-4b2e-bc68-32ab7a41dd5d_0">
											<gml:posList>35.67285926633342 139.73872606248267 30.381 35.67285926633342 139.73872606248267 34.446 35.67285706200393 139.73871972433525 30.381 35.67285926633342 139.73872606248267 30.381</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24a7bcfc-343c-4a46-9781-e59965bd0200">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-24a7bcfc-343c-4a46-9781-e59965bd0200_0">
											<gml:posList>35.67285706200393 139.73871972433525 30.381 35.67285926633342 139.73872606248267 34.446 35.67285706200393 139.73871972433525 34.446 35.67285706200393 139.73871972433525 30.381</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-05f0d913-6d7b-4fb6-a03e-48eb234f812d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-05f0d913-6d7b-4fb6-a03e-48eb234f812d_0">
											<gml:posList>35.67285926633342 139.73872606248267 34.446 35.6728789517556 139.73878273042172 34.446 35.67285706200393 139.73871972433525 34.446 35.67285926633342 139.73872606248267 34.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ee45f89-d081-4958-b286-945e136a0702">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9ee45f89-d081-4958-b286-945e136a0702_0">
											<gml:posList>35.672888664579915 139.7387776706682 30.381 35.67290915340418 139.73876698652646 30.381 35.672888664579915 139.7387776706682 30.845 35.672888664579915 139.7387776706682 30.381</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aaf5ca46-04af-4db1-b1fd-86ea980cf512">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aaf5ca46-04af-4db1-b1fd-86ea980cf512_0">
											<gml:posList>35.6728789517556 139.73878273042172 30.845 35.672888664579915 139.7387776706682 30.845 35.6728789517556 139.73878273042172 34.446 35.6728789517556 139.73878273042172 30.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ee9a6064-a884-426f-af68-dfe9204d3997">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ee9a6064-a884-426f-af68-dfe9204d3997_0">
											<gml:posList>35.6728789517556 139.73878273042172 34.446 35.672888664579915 139.7387776706682 30.845 35.67290915340418 139.73876698652646 34.446 35.6728789517556 139.73878273042172 34.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de3eb189-a05d-46f4-b340-76434f8afed2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de3eb189-a05d-46f4-b340-76434f8afed2_0">
											<gml:posList>35.672888664579915 139.7387776706682 30.845 35.67290915340418 139.73876698652646 30.381 35.67290915340418 139.73876698652646 34.446 35.672888664579915 139.7387776706682 30.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2fe89918-e3ee-40d1-86ea-3be92f829e39">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67286802213554 139.73869607167217 30.381 35.67287935546283 139.73866558071435 30.381 35.672886843397315 139.73868536738783 30.381 35.67286802213554 139.73869607167217 30.381</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac0343bb-ed26-43e1-864a-d7a13be8f1dd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67286802213554 139.73869607167217 30.381 35.67286052518907 139.73867628501299 30.381 35.67287935546283 139.73866558071435 30.381 35.67286802213554 139.73869607167217 30.381</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c290aa5-f082-44e0-a5a6-7caa3c4a46ab">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67290033605491 139.73873011230805 30.845 35.67289315638507 139.73870113448746 30.845 35.6729027958627 139.73872891637185 30.845 35.67290033605491 139.73873011230805 30.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c444788f-563c-42ed-bf66-1443cbd19adc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67290033605491 139.73873011230805 30.845 35.67289071464839 139.73870238563603 30.845 35.67289315638507 139.73870113448746 30.845 35.67290033605491 139.73873011230805 30.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f649a5b-5a98-4545-9456-a440d705fd03">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67290915340418 139.73876698652646 30.381 35.672888637478046 139.73877759337392 30.381 35.67289693017116 139.73873177331802 30.381 35.67290915340418 139.73876698652646 30.381</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f221ef1-86c2-4466-911a-9c3de60da504">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67289071464839 139.73870238563603 30.381 35.67290033605491 139.73873011230805 30.381 35.67289693017116 139.73873177331802 30.381 35.67289071464839 139.73870238563603 30.381</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd431e65-28d1-41a4-b16a-3959f121bd0e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67285706200393 139.73871972433525 30.381 35.67289071464839 139.73870238563603 30.381 35.67285926633342 139.73872606248267 30.381 35.67285706200393 139.73871972433525 30.381</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f5348235-0db6-46d0-a941-61e8e36b693c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67285926633342 139.73872606248267 30.381 35.672888637478046 139.73877759337392 30.381 35.67287008577823 139.73878722579857 30.381 35.67285926633342 139.73872606248267 30.381</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a96504e8-55f0-47c5-a981-98aeda20e3d2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67285926633342 139.73872606248267 30.381 35.67287008577823 139.73878722579857 30.381 35.67285047251996 139.73873062405912 30.381 35.67285926633342 139.73872606248267 30.381</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aaa98ed7-bef6-4540-836c-232d74331582">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67289693017116 139.73873177331802 30.381 35.672888637478046 139.73877759337392 30.381 35.67285926633342 139.73872606248267 30.381 35.67289693017116 139.73873177331802 30.381</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d26503d0-4be0-4601-8b2b-54b73fc3918c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67289071464839 139.73870238563603 30.381 35.67289693017116 139.73873177331802 30.381 35.67285926633342 139.73872606248267 30.381 35.67289071464839 139.73870238563603 30.381</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bedffcbe-09b5-4c82-9560-20c6bbe5e43e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67287008577823 139.73878722579857 30.845 35.6728789517556 139.73878273042172 30.845 35.67287117891018 139.73879037279113 30.845 35.67287008577823 139.73878722579857 30.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c976ac89-a9d5-4649-ac8f-834f8c43d7a9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67287117891018 139.73879037279113 30.845 35.6728789517556 139.73878273042172 30.845 35.67288000876339 139.73878578908435 30.845 35.67287117891018 139.73879037279113 30.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6339196a-fdda-4855-b293-f08461982e66">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672888664579915 139.7387776706682 30.845 35.6728789517556 139.73878273042172 30.845 35.67287008577823 139.73878722579857 30.845 35.672888664579915 139.7387776706682 30.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-7c6f72ef-2c01-4f39-8629-e78db8a5ffe5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c6f72ef-2c01-4f39-8629-e78db8a5ffe5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c6f72ef-2c01-4f39-8629-e78db8a5ffe5">
											<gml:posList>35.67289363375619 139.7387006810131 8.09 35.672918929445515 139.73877355877391 8.09 35.67288910618148 139.73878905919707 8.09 35.672886937944895 139.73878276518943 8.09 35.67286173682642 139.73879585199356 8.09 35.67280400826038 139.73862933744178 8.09 35.672904199816124 139.73857711224144 8.09 35.67293889121284 139.73867715354115 8.09 35.67289363375619 139.7387006810131 8.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bc072ebc-6795-4b70-a9ea-fc572fd10a16">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc072ebc-6795-4b70-a9ea-fc572fd10a16">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc072ebc-6795-4b70-a9ea-fc572fd10a16">
											<gml:posList>35.672818173919566 139.73867020415682 30.845 35.67282778763176 139.73866519974356 30.845 35.67290910085882 139.73861985682046 30.845 35.672818173919566 139.73867020415682 30.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4aada7a2-c4e0-495d-b434-504cdb28fce5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4aada7a2-c4e0-495d-b434-504cdb28fce5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4aada7a2-c4e0-495d-b434-504cdb28fce5">
											<gml:posList>35.672904199816124 139.73857711224144 24.077 35.67280400826038 139.73862933744178 24.077 35.672811091096065 139.73864977632076 24.077 35.67291029793159 139.73859471332676 24.077 35.672904199816124 139.73857711224144 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-50294c53-5059-4f44-a136-ab88a8e97a04">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50294c53-5059-4f44-a136-ab88a8e97a04">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50294c53-5059-4f44-a136-ab88a8e97a04">
											<gml:posList>35.67291750722579 139.7386154834786 27.182 35.67291029793159 139.73859471332676 27.182 35.672811091096065 139.73864977632076 27.182 35.672818173919566 139.73867020415682 27.182 35.67291750722579 139.7386154834786 27.182</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6c37008b-e1e0-4b63-b447-893e50c7a3c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c37008b-e1e0-4b63-b447-893e50c7a3c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c37008b-e1e0-4b63-b447-893e50c7a3c9">
											<gml:posList>35.67282778763176 139.73866519974356 30.845 35.67282908845587 139.73866882149122 30.845 35.67291042870804 139.73862345644588 30.845 35.67290910085882 139.73861985682046 30.845 35.67282778763176 139.73866519974356 30.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5ba9d30b-1f87-405d-b961-06b032c2dac8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5ba9d30b-1f87-405d-b961-06b032c2dac8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5ba9d30b-1f87-405d-b961-06b032c2dac8">
											<gml:posList>35.67290910085882 139.73861985682046 30.845 35.67291042870804 139.73862345644588 30.845 35.672915789680886 139.73862066636727 30.845 35.67291750722579 139.7386154834786 30.845 35.67290910085882 139.73861985682046 30.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-054be07c-ba1d-43bf-9ac2-6401adf17f7c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-054be07c-ba1d-43bf-9ac2-6401adf17f7c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-054be07c-ba1d-43bf-9ac2-6401adf17f7c">
											<gml:posList>35.67291750722579 139.7386154834786 30.845 35.672915789680886 139.73862066636727 30.845 35.67293466213762 139.73867507072487 30.845 35.67293889121284 139.73867715354115 30.845 35.67291750722579 139.7386154834786 30.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3ae497f9-7726-41e2-a187-18b74a930108">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ae497f9-7726-41e2-a187-18b74a930108">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ae497f9-7726-41e2-a187-18b74a930108">
											<gml:posList>35.67282778763176 139.73866519974356 30.845 35.672818173919566 139.73867020415682 30.845 35.6728223939986 139.73867230907362 30.845 35.67282908845587 139.73866882149122 30.845 35.67282778763176 139.73866519974356 30.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-68feb449-5e7d-4c45-90ed-da70e5f62f80">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-68feb449-5e7d-4c45-90ed-da70e5f62f80">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-68feb449-5e7d-4c45-90ed-da70e5f62f80">
											<gml:posList>35.67286173682642 139.73879585199356 30.845 35.67286344537386 139.73879068016936 30.845 35.6728223939986 139.73867230907362 30.845 35.672818173919566 139.73867020415682 30.845 35.67286173682642 139.73879585199356 30.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-09f81b06-1b0c-4862-9cc3-a7f94a1b7b1a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-09f81b06-1b0c-4862-9cc3-a7f94a1b7b1a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-09f81b06-1b0c-4862-9cc3-a7f94a1b7b1a">
											<gml:posList>35.672886937944895 139.73878276518943 30.845 35.672888637478046 139.73877759337392 30.845 35.67286344537386 139.73879068016936 30.845 35.67286173682642 139.73879585199356 30.845 35.672886937944895 139.73878276518943 30.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bd7b9898-7e61-4da2-89b9-8f26479a21f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd7b9898-7e61-4da2-89b9-8f26479a21f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd7b9898-7e61-4da2-89b9-8f26479a21f6">
											<gml:posList>35.67282908845587 139.73866882149122 30.381 35.6728223939986 139.73867230907362 30.381 35.67286344537386 139.73879068016936 30.381 35.672888637478046 139.73877759337392 30.381 35.67289080571489 139.7387838873816 30.381 35.67291469134956 139.73877146491708 30.381 35.672889395667646 139.73869859820743 30.381 35.67293466213762 139.73867507072487 30.381 35.672915789680886 139.73862066636727 30.381 35.67291042870804 139.73862345644588 30.381 35.67282908845587 139.73866882149122 30.381</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8af17da6-f77f-47fe-bf47-e2a48c7bc597">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8af17da6-f77f-47fe-bf47-e2a48c7bc597">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8af17da6-f77f-47fe-bf47-e2a48c7bc597">
											<gml:posList>35.672886937944895 139.73878276518943 30.845 35.67288910618148 139.73878905919707 30.845 35.67289080571489 139.7387838873816 30.845 35.672888637478046 139.73877759337392 30.845 35.672886937944895 139.73878276518943 30.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2cbbd431-848d-45aa-a8b4-7d7d111ca469">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2cbbd431-848d-45aa-a8b4-7d7d111ca469">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2cbbd431-848d-45aa-a8b4-7d7d111ca469">
											<gml:posList>35.672918929445515 139.73877355877391 30.845 35.67291469134956 139.73877146491708 30.845 35.67289080571489 139.7387838873816 30.845 35.67288910618148 139.73878905919707 30.845 35.672918929445515 139.73877355877391 30.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-11e73c82-ade2-47d3-b8ba-29deda1e4e85">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11e73c82-ade2-47d3-b8ba-29deda1e4e85">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11e73c82-ade2-47d3-b8ba-29deda1e4e85">
											<gml:posList>35.67289363375619 139.7387006810131 30.845 35.672889395667646 139.73869859820743 30.845 35.67291469134956 139.73877146491708 30.845 35.672918929445515 139.73877355877391 30.845 35.67289363375619 139.7387006810131 30.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4c5a7935-b4ff-403f-80d0-384fe7a880c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c5a7935-b4ff-403f-80d0-384fe7a880c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c5a7935-b4ff-403f-80d0-384fe7a880c4">
											<gml:posList>35.67289363375619 139.7387006810131 30.845 35.67293889121284 139.73867715354115 30.845 35.67293466213762 139.73867507072487 30.845 35.672889395667646 139.73869859820743 30.845 35.67289363375619 139.7387006810131 30.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7d644270-d569-4ef8-87a5-88e5da0c4db3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d644270-d569-4ef8-87a5-88e5da0c4db3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d644270-d569-4ef8-87a5-88e5da0c4db3">
											<gml:posList>35.6728223939986 139.73867230907362 30.845 35.6728223939986 139.73867230907362 30.381 35.67282908845587 139.73866882149122 30.381 35.67282908845587 139.73866882149122 30.845 35.6728223939986 139.73867230907362 30.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a91617e3-c034-4be3-878a-729672395ba4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a91617e3-c034-4be3-878a-729672395ba4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a91617e3-c034-4be3-878a-729672395ba4">
											<gml:posList>35.67286173682642 139.73879585199356 30.845 35.672818173919566 139.73867020415682 30.845 35.672818173919566 139.73867020415682 27.182 35.672811091096065 139.73864977632076 27.182 35.672811091096065 139.73864977632076 24.077 35.67280400826038 139.73862933744178 24.077 35.67280400826038 139.73862933744178 8.09 35.67286173682642 139.73879585199356 8.09 35.67286173682642 139.73879585199356 30.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e9c051bb-dbf9-4139-acd9-317335c3f8c0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e9c051bb-dbf9-4139-acd9-317335c3f8c0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e9c051bb-dbf9-4139-acd9-317335c3f8c0">
											<gml:posList>35.67286344537386 139.73879068016936 30.845 35.67286344537386 139.73879068016936 30.381 35.6728223939986 139.73867230907362 30.381 35.6728223939986 139.73867230907362 30.845 35.67286344537386 139.73879068016936 30.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2ef49600-d063-4bce-af04-5a69210df76e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2ef49600-d063-4bce-af04-5a69210df76e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2ef49600-d063-4bce-af04-5a69210df76e">
											<gml:posList>35.67280400826038 139.73862933744178 8.09 35.67280400826038 139.73862933744178 24.077 35.672904199816124 139.73857711224144 24.077 35.672904199816124 139.73857711224144 8.09 35.67280400826038 139.73862933744178 8.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c52dd82e-bc7a-40c1-83d8-1920023b03a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c52dd82e-bc7a-40c1-83d8-1920023b03a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c52dd82e-bc7a-40c1-83d8-1920023b03a5">
											<gml:posList>35.67291029793159 139.73859471332676 24.077 35.672811091096065 139.73864977632076 24.077 35.672811091096065 139.73864977632076 27.182 35.67291029793159 139.73859471332676 27.182 35.67291029793159 139.73859471332676 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-78d84c82-02dc-4b5c-8643-bbfdd0dfc054">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78d84c82-02dc-4b5c-8643-bbfdd0dfc054">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78d84c82-02dc-4b5c-8643-bbfdd0dfc054">
											<gml:posList>35.67291750722579 139.7386154834786 27.182 35.672818173919566 139.73867020415682 27.182 35.672818173919566 139.73867020415682 30.845 35.67291750722579 139.7386154834786 27.182</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8d01ac8d-b8de-4c1b-b436-ec6bcba2e95f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d01ac8d-b8de-4c1b-b436-ec6bcba2e95f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d01ac8d-b8de-4c1b-b436-ec6bcba2e95f">
											<gml:posList>35.67291750722579 139.7386154834786 27.182 35.672818173919566 139.73867020415682 30.845 35.67290910085882 139.73861985682046 30.845 35.67291750722579 139.7386154834786 27.182</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f4b0d7c0-6bac-4619-8602-4572a3c22bfc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4b0d7c0-6bac-4619-8602-4572a3c22bfc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4b0d7c0-6bac-4619-8602-4572a3c22bfc">
											<gml:posList>35.67282908845587 139.73866882149122 30.845 35.67282908845587 139.73866882149122 30.381 35.67291042870804 139.73862345644588 30.381 35.67291042870804 139.73862345644588 30.845 35.67282908845587 139.73866882149122 30.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4f2bee07-9518-4595-bf11-233aefde7d23">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f2bee07-9518-4595-bf11-233aefde7d23">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f2bee07-9518-4595-bf11-233aefde7d23">
											<gml:posList>35.672889395667646 139.73869859820743 30.845 35.672889395667646 139.73869859820743 30.381 35.67291469134956 139.73877146491708 30.381 35.67291469134956 139.73877146491708 30.845 35.672889395667646 139.73869859820743 30.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ff387a11-c9bd-4cd0-9420-bed672d349c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff387a11-c9bd-4cd0-9420-bed672d349c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff387a11-c9bd-4cd0-9420-bed672d349c4">
											<gml:posList>35.672918929445515 139.73877355877391 8.09 35.67289363375619 139.7387006810131 8.09 35.67289363375619 139.7387006810131 30.845 35.672918929445515 139.73877355877391 30.845 35.672918929445515 139.73877355877391 8.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-654dceab-cc0b-400c-bd9f-8e55c1dc6829">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-654dceab-cc0b-400c-bd9f-8e55c1dc6829">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-654dceab-cc0b-400c-bd9f-8e55c1dc6829">
											<gml:posList>35.67293466213762 139.73867507072487 30.845 35.67293466213762 139.73867507072487 30.381 35.672889395667646 139.73869859820743 30.381 35.672889395667646 139.73869859820743 30.845 35.67293466213762 139.73867507072487 30.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-259edf49-90fb-404c-a815-ef61340c87d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-259edf49-90fb-404c-a815-ef61340c87d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-259edf49-90fb-404c-a815-ef61340c87d8">
											<gml:posList>35.67291042870804 139.73862345644588 30.845 35.67291042870804 139.73862345644588 30.381 35.672915789680886 139.73862066636727 30.381 35.672915789680886 139.73862066636727 30.845 35.67291042870804 139.73862345644588 30.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9a44e8bc-6383-49b6-bf32-8a2528aeaa42">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a44e8bc-6383-49b6-bf32-8a2528aeaa42">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a44e8bc-6383-49b6-bf32-8a2528aeaa42">
											<gml:posList>35.67291750722579 139.7386154834786 27.182 35.67290910085882 139.73861985682046 30.845 35.67291750722579 139.7386154834786 30.845 35.67291750722579 139.7386154834786 27.182</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-44726774-a75f-41f5-b067-8319ad71688b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44726774-a75f-41f5-b067-8319ad71688b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44726774-a75f-41f5-b067-8319ad71688b">
											<gml:posList>35.67289363375619 139.7387006810131 30.845 35.67289363375619 139.7387006810131 8.09 35.67293889121284 139.73867715354115 8.09 35.67293889121284 139.73867715354115 30.845 35.67289363375619 139.7387006810131 30.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a14476e0-e604-49ac-99eb-857dfa682c79">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a14476e0-e604-49ac-99eb-857dfa682c79">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a14476e0-e604-49ac-99eb-857dfa682c79">
											<gml:posList>35.672904199816124 139.73857711224144 8.09 35.672904199816124 139.73857711224144 24.077 35.67291029793159 139.73859471332676 24.077 35.67291029793159 139.73859471332676 27.182 35.67291750722579 139.7386154834786 27.182 35.67291750722579 139.7386154834786 30.845 35.67293889121284 139.73867715354115 30.845 35.67293889121284 139.73867715354115 8.09 35.672904199816124 139.73857711224144 8.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9498c0e3-4533-48e8-a92c-446ef272552a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9498c0e3-4533-48e8-a92c-446ef272552a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9498c0e3-4533-48e8-a92c-446ef272552a">
											<gml:posList>35.672915789680886 139.73862066636727 30.845 35.672915789680886 139.73862066636727 30.381 35.67293466213762 139.73867507072487 30.381 35.67293466213762 139.73867507072487 30.845 35.672915789680886 139.73862066636727 30.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-11c1d6d4-6e85-4b0a-a371-489c6cec7e77">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11c1d6d4-6e85-4b0a-a371-489c6cec7e77">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11c1d6d4-6e85-4b0a-a371-489c6cec7e77">
											<gml:posList>35.67291469134956 139.73877146491708 30.845 35.67291469134956 139.73877146491708 30.381 35.67289080571489 139.7387838873816 30.381 35.67289080571489 139.7387838873816 30.845 35.67291469134956 139.73877146491708 30.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0e86d867-4ebe-4078-93b8-cdb09a742271">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e86d867-4ebe-4078-93b8-cdb09a742271">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e86d867-4ebe-4078-93b8-cdb09a742271">
											<gml:posList>35.67289080571489 139.7387838873816 30.845 35.67289080571489 139.7387838873816 30.381 35.672888637478046 139.73877759337392 30.381 35.672888637478046 139.73877759337392 30.845 35.67289080571489 139.7387838873816 30.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f7663555-8dd9-479d-80ca-2cb73b6d003e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f7663555-8dd9-479d-80ca-2cb73b6d003e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f7663555-8dd9-479d-80ca-2cb73b6d003e">
											<gml:posList>35.67288910618148 139.73878905919707 8.09 35.672918929445515 139.73877355877391 8.09 35.672918929445515 139.73877355877391 30.845 35.67288910618148 139.73878905919707 30.845 35.67288910618148 139.73878905919707 8.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-78f044e2-e4a3-49bf-bb91-7b12a239827e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78f044e2-e4a3-49bf-bb91-7b12a239827e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78f044e2-e4a3-49bf-bb91-7b12a239827e">
											<gml:posList>35.672888637478046 139.73877759337392 30.845 35.672888637478046 139.73877759337392 30.381 35.67286344537386 139.73879068016936 30.381 35.67286344537386 139.73879068016936 30.845 35.672888637478046 139.73877759337392 30.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a92afe1d-6c57-4cc1-b159-e851632d185d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a92afe1d-6c57-4cc1-b159-e851632d185d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a92afe1d-6c57-4cc1-b159-e851632d185d">
											<gml:posList>35.672886937944895 139.73878276518943 8.09 35.67288910618148 139.73878905919707 8.09 35.67288910618148 139.73878905919707 30.845 35.672886937944895 139.73878276518943 30.845 35.672886937944895 139.73878276518943 8.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bd3eecfa-e9f1-49fc-95bf-104d33914393">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd3eecfa-e9f1-49fc-95bf-104d33914393">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd3eecfa-e9f1-49fc-95bf-104d33914393">
											<gml:posList>35.67286173682642 139.73879585199356 30.845 35.67286173682642 139.73879585199356 8.09 35.672886937944895 139.73878276518943 8.09 35.672886937944895 139.73878276518943 30.845 35.67286173682642 139.73879585199356 30.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6784</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">135.4799</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1242</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.09</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>