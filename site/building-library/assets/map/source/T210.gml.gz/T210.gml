<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_3a55f478-5559-4eed-a0a9-ca93cb6f9c28">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">40.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>13</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.6706983065958 139.73881858459174 0 35.67067403115147 139.73871341929583 0 35.67069273855984 139.73870693513155 0 35.670722784393064 139.73883710248506 0 35.670749169418194 139.73882795818176 0 35.67074524410185 139.73881094044555 0 35.67080996308963 139.73878849535137 0 35.67076792411675 139.73860634704278 0 35.67067199010942 139.73863961033155 0 35.67068193005218 139.73868266811877 0 35.67066662891161 139.73868797735926 0 35.670658986282106 139.73865486958064 0 35.67064471242034 139.73865981308415 0 35.67064247843128 139.7386501502136 0 35.67055976394503 139.73867882463017 0 35.670599026131875 139.73884891322805 0 35.67060481137253 139.7388469070319 0 35.67060749759198 139.73885855770283 0 35.670685967810684 139.7388313576152 0 35.67068414987978 139.73882349479155 0 35.6706983065958 139.73881858459174 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6706983065958 139.73881858459174 17.936 35.67068414987978 139.73882349479155 17.936 35.670685967810684 139.7388313576152 17.936 35.67060749759198 139.73885855770283 17.936 35.67060481137253 139.7388469070319 17.936 35.670599026131875 139.73884891322805 17.936 35.67055976394503 139.73867882463017 17.936 35.67064247843128 139.7386501502136 17.936 35.67064471242034 139.73865981308415 17.936 35.670658986282106 139.73865486958064 17.936 35.67066662891161 139.73868797735926 17.936 35.67068193005218 139.73868266811877 17.936 35.67067199010942 139.73863961033155 17.936 35.67076792411675 139.73860634704278 17.936 35.67080996308963 139.73878849535137 17.936 35.67074524410185 139.73881094044555 17.936 35.670749169418194 139.73882795818176 17.936 35.670722784393064 139.73883710248506 17.936 35.67069273855984 139.73870693513155 17.936 35.67067403115147 139.73871341929583 17.936 35.6706983065958 139.73881858459174 17.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6706983065958 139.73881858459174 17.936 35.67067403115147 139.73871341929583 17.936 35.67067403115147 139.73871341929583 58.07 35.6706983065958 139.73881858459174 58.07 35.6706983065958 139.73881858459174 17.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67067403115147 139.73871341929583 17.936 35.67069273855984 139.73870693513155 17.936 35.67069273855984 139.73870693513155 58.07 35.67067403115147 139.73871341929583 58.07 35.67067403115147 139.73871341929583 17.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67069273855984 139.73870693513155 17.936 35.670722784393064 139.73883710248506 17.936 35.670722784393064 139.73883710248506 58.07 35.67069273855984 139.73870693513155 58.07 35.67069273855984 139.73870693513155 17.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670722784393064 139.73883710248506 17.936 35.670749169418194 139.73882795818176 17.936 35.670749169418194 139.73882795818176 58.07 35.670722784393064 139.73883710248506 58.07 35.670722784393064 139.73883710248506 17.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670749169418194 139.73882795818176 17.936 35.67074524410185 139.73881094044555 17.936 35.67074524410185 139.73881094044555 58.07 35.670749169418194 139.73882795818176 58.07 35.670749169418194 139.73882795818176 17.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67074524410185 139.73881094044555 17.936 35.67080996308963 139.73878849535137 17.936 35.67080996308963 139.73878849535137 58.07 35.67074524410185 139.73881094044555 58.07 35.67074524410185 139.73881094044555 17.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67080996308963 139.73878849535137 17.936 35.67076792411675 139.73860634704278 17.936 35.67076792411675 139.73860634704278 58.07 35.67080996308963 139.73878849535137 58.07 35.67080996308963 139.73878849535137 17.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67076792411675 139.73860634704278 17.936 35.67067199010942 139.73863961033155 17.936 35.67067199010942 139.73863961033155 58.07 35.67076792411675 139.73860634704278 58.07 35.67076792411675 139.73860634704278 17.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67067199010942 139.73863961033155 17.936 35.67068193005218 139.73868266811877 17.936 35.67068193005218 139.73868266811877 58.07 35.67067199010942 139.73863961033155 58.07 35.67067199010942 139.73863961033155 17.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67068193005218 139.73868266811877 17.936 35.67066662891161 139.73868797735926 17.936 35.67066662891161 139.73868797735926 58.07 35.67068193005218 139.73868266811877 58.07 35.67068193005218 139.73868266811877 17.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67066662891161 139.73868797735926 17.936 35.670658986282106 139.73865486958064 17.936 35.670658986282106 139.73865486958064 58.07 35.67066662891161 139.73868797735926 58.07 35.67066662891161 139.73868797735926 17.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670658986282106 139.73865486958064 17.936 35.67064471242034 139.73865981308415 17.936 35.67064471242034 139.73865981308415 58.07 35.670658986282106 139.73865486958064 58.07 35.670658986282106 139.73865486958064 17.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67064471242034 139.73865981308415 17.936 35.67064247843128 139.7386501502136 17.936 35.67064247843128 139.7386501502136 58.07 35.67064471242034 139.73865981308415 58.07 35.67064471242034 139.73865981308415 17.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67064247843128 139.7386501502136 17.936 35.67055976394503 139.73867882463017 17.936 35.67055976394503 139.73867882463017 58.07 35.67064247843128 139.7386501502136 58.07 35.67064247843128 139.7386501502136 17.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67055976394503 139.73867882463017 17.936 35.670599026131875 139.73884891322805 17.936 35.670599026131875 139.73884891322805 58.07 35.67055976394503 139.73867882463017 58.07 35.67055976394503 139.73867882463017 17.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670599026131875 139.73884891322805 17.936 35.67060481137253 139.7388469070319 17.936 35.67060481137253 139.7388469070319 58.07 35.670599026131875 139.73884891322805 58.07 35.670599026131875 139.73884891322805 17.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67060481137253 139.7388469070319 17.936 35.67060749759198 139.73885855770283 17.936 35.67060749759198 139.73885855770283 58.07 35.67060481137253 139.7388469070319 58.07 35.67060481137253 139.7388469070319 17.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67060749759198 139.73885855770283 17.936 35.670685967810684 139.7388313576152 17.936 35.670685967810684 139.7388313576152 58.07 35.67060749759198 139.73885855770283 58.07 35.67060749759198 139.73885855770283 17.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670685967810684 139.7388313576152 17.936 35.67068414987978 139.73882349479155 17.936 35.67068414987978 139.73882349479155 58.07 35.670685967810684 139.7388313576152 58.07 35.670685967810684 139.7388313576152 17.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67068414987978 139.73882349479155 17.936 35.6706983065958 139.73881858459174 17.936 35.6706983065958 139.73881858459174 58.07 35.67068414987978 139.73882349479155 58.07 35.67068414987978 139.73882349479155 17.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6706983065958 139.73881858459174 58.07 35.67067403115147 139.73871341929583 58.07 35.67069273855984 139.73870693513155 58.07 35.670722784393064 139.73883710248506 58.07 35.670749169418194 139.73882795818176 58.07 35.67074524410185 139.73881094044555 58.07 35.67080996308963 139.73878849535137 58.07 35.67076792411675 139.73860634704278 58.07 35.67067199010942 139.73863961033155 58.07 35.67068193005218 139.73868266811877 58.07 35.67066662891161 139.73868797735926 58.07 35.670658986282106 139.73865486958064 58.07 35.67064471242034 139.73865981308415 58.07 35.67064247843128 139.7386501502136 58.07 35.67055976394503 139.73867882463017 58.07 35.670599026131875 139.73884891322805 58.07 35.67060481137253 139.7388469070319 58.07 35.67060749759198 139.73885855770283 58.07 35.670685967810684 139.7388313576152 58.07 35.67068414987978 139.73882349479155 58.07 35.6706983065958 139.73881858459174 58.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-b33aad33-ae3c-499f-9b0f-2302b7b3ae57"/>
							<gml:surfaceMember xlink:href="#poly-9add618e-005e-4b7e-8902-dc2134e321fe"/>
							<gml:surfaceMember xlink:href="#poly-5a4cd502-fd4f-4f2d-b73c-6fd2f25a5f99"/>
							<gml:surfaceMember xlink:href="#poly-e2f9cfba-943a-4c68-99fd-66d5e3d52437"/>
							<gml:surfaceMember xlink:href="#poly-99402400-2534-4ad0-9588-e26bf0f84dda"/>
							<gml:surfaceMember xlink:href="#poly-86368b9b-a8fd-4ce5-985e-96150bfa18b8"/>
							<gml:surfaceMember xlink:href="#poly-c2c5f54c-30aa-4bcd-a8d4-5468e001463e"/>
							<gml:surfaceMember xlink:href="#poly-679131aa-dc58-4fda-a04a-3f9778acb0c9"/>
							<gml:surfaceMember xlink:href="#poly-80d9b587-f250-4be1-bcd1-bfaa0896aea7"/>
							<gml:surfaceMember xlink:href="#poly-a75fa8c8-6133-48b3-849f-5e5510a8b852"/>
							<gml:surfaceMember xlink:href="#poly-598cae8c-aa36-4581-9149-0dfb0c0ab712"/>
							<gml:surfaceMember xlink:href="#poly-992aa36e-a3cc-4f4f-86f4-e6a1baa3aa6f"/>
							<gml:surfaceMember xlink:href="#poly-20a64815-3be4-44f7-adaa-55c5f1c8737e"/>
							<gml:surfaceMember xlink:href="#poly-275b8549-746f-4e73-a782-2b1daa9ae82b"/>
							<gml:surfaceMember xlink:href="#poly-e9b4de13-1722-4da4-85a4-1a5ccfeff83f"/>
							<gml:surfaceMember xlink:href="#poly-9be84514-632c-429d-8aac-e56232183f70"/>
							<gml:surfaceMember xlink:href="#poly-ba1e4a0d-c661-4466-b4f3-ae7508451099"/>
							<gml:surfaceMember xlink:href="#poly-4e0de761-350d-40aa-a6d2-d3d5fd4e1861"/>
							<gml:surfaceMember xlink:href="#poly-a28178c0-31d2-408a-b603-3f1f65daa09b"/>
							<gml:surfaceMember xlink:href="#poly-a8e7f5c4-ffdf-49d0-a1e9-f633f217c361"/>
							<gml:surfaceMember xlink:href="#poly-50bbd3b7-d494-496a-ba45-6a0ddad853a3"/>
							<gml:surfaceMember xlink:href="#poly-f4f6677f-6a78-415f-8959-0b50703d157f"/>
							<gml:surfaceMember xlink:href="#poly-ecf9b251-7593-476c-bee4-d015c4118729"/>
							<gml:surfaceMember xlink:href="#poly-91185782-c5cf-48fc-862a-7736000535fe"/>
							<gml:surfaceMember xlink:href="#poly-e56ce6ab-bb03-4555-9212-752db1e46166"/>
							<gml:surfaceMember xlink:href="#poly-27bbb3ce-4fd7-46da-9054-0cbb29da3957"/>
							<gml:surfaceMember xlink:href="#poly-8c14d5c1-0c02-4d2c-95f1-05befd48f56c"/>
							<gml:surfaceMember xlink:href="#poly-e342c504-9f4b-4687-b2ad-ae95c04a64c8"/>
							<gml:surfaceMember xlink:href="#poly-6881a326-c810-4f34-b706-040196306663"/>
							<gml:surfaceMember xlink:href="#poly-5b635923-bc46-463a-b59a-476ec584ca01"/>
							<gml:surfaceMember xlink:href="#poly-e39611e5-e7c6-426f-a230-e83b761db129"/>
							<gml:surfaceMember xlink:href="#poly-868ce551-d7b7-4fb9-a66f-c5cd27706330"/>
							<gml:surfaceMember xlink:href="#poly-9fafd388-53b1-4092-aba0-ba13f055a9ec"/>
							<gml:surfaceMember xlink:href="#poly-c67968d7-ee9a-4d2f-a13e-abe70881dd40"/>
							<gml:surfaceMember xlink:href="#poly-d94bd5c6-7f09-4174-b173-ffaff81432cc"/>
							<gml:surfaceMember xlink:href="#poly-6ddeaa61-3ad6-488b-ab75-5776bd7104e5"/>
							<gml:surfaceMember xlink:href="#poly-436d9aa4-65fe-4c60-8ab4-e28cc2c805e0"/>
							<gml:surfaceMember xlink:href="#poly-61486030-a9dc-4454-9467-20c7ac8404f9"/>
							<gml:surfaceMember xlink:href="#poly-6d406596-595e-4e87-b172-621ff31b58de"/>
							<gml:surfaceMember xlink:href="#poly-4573719f-d427-4798-84cb-bb2ba7d2db51"/>
							<gml:surfaceMember xlink:href="#poly-56825fa9-fd22-40d3-af59-7259ab1b10b5"/>
							<gml:surfaceMember xlink:href="#poly-3ffc6b78-a833-4f51-84b5-2004c51aed08"/>
							<gml:surfaceMember xlink:href="#poly-c13349fa-3eaa-4b1c-9040-45b57607011f"/>
							<gml:surfaceMember xlink:href="#poly-e6562963-56ee-43c1-be62-a91767e99a16"/>
							<gml:surfaceMember xlink:href="#poly-f4ea3722-b343-454b-b6dc-f7687bf383d1"/>
							<gml:surfaceMember xlink:href="#poly-dc7e5902-beec-4452-b80f-433349e7b003"/>
							<gml:surfaceMember xlink:href="#poly-8d136f4a-b906-4401-80b3-824006d634fc"/>
							<gml:surfaceMember xlink:href="#poly-fb846de3-9a8f-4596-a346-0416ed5f3d90"/>
							<gml:surfaceMember xlink:href="#poly-528edd9b-f6e0-4825-9fa6-632d7b79966c"/>
							<gml:surfaceMember xlink:href="#poly-1ad178a9-1167-403b-ad30-94989b1512f7"/>
							<gml:surfaceMember xlink:href="#poly-d68fa828-5068-43fd-bfe9-6a1ac8a31beb"/>
							<gml:surfaceMember xlink:href="#poly-412c4015-5225-4c89-9c79-de42494749bf"/>
							<gml:surfaceMember xlink:href="#poly-2de8131b-d217-4654-a6df-0cc1745b3a75"/>
							<gml:surfaceMember xlink:href="#poly-9619e6d6-3234-4b91-8255-78088ceae1af"/>
							<gml:surfaceMember xlink:href="#poly-ed6aa030-4ee3-4923-b97e-672a44743da6"/>
							<gml:surfaceMember xlink:href="#poly-683035cf-39ae-46bc-a809-f54c2b0c347c"/>
							<gml:surfaceMember xlink:href="#poly-a22efc01-cce4-4bc4-bcaa-dec8671927e2"/>
							<gml:surfaceMember xlink:href="#poly-8db6df93-b81c-4749-be26-9e4be1379841"/>
							<gml:surfaceMember xlink:href="#poly-8726a361-29ac-4e54-be5c-58f681a0b25e"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_3a55f478-5559-4eed-a0a9-ca93cb6f9c28_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-390ae661-df05-4a2c-a28c-bca5e3f3d6d1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67076873107837 139.7388533085046 17.936 35.67074447271771 139.73886172123957 17.936 35.67073760795155 139.73883197057316 17.936 35.6707491694182 139.73882795818176 17.936 35.67074523508812 139.73881094045618 17.936 35.670757940984515 139.73880652904492 17.936 35.67076873107837 139.7388533085046 17.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-51f0491a-1bec-4425-a1c0-558e168ed89d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-51f0491a-1bec-4425-a1c0-558e168ed89d_0">
											<gml:posList>35.67073760795155 139.73883197057316 58.759 35.67073760795155 139.73883197057316 17.936 35.67074447271771 139.73886172123957 17.936 35.67074447271771 139.73886172123957 58.759 35.67073760795155 139.73883197057316 58.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c8c8082b-d6c9-452d-8380-fd135c0df61a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c8c8082b-d6c9-452d-8380-fd135c0df61a_0">
											<gml:posList>35.6707491694182 139.73882795818176 58.759 35.6707491694182 139.73882795818176 17.936 35.67073760795155 139.73883197057316 17.936 35.67073760795155 139.73883197057316 58.759 35.6707491694182 139.73882795818176 58.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f0b93db-80e4-4b61-9e1e-f12915232903">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f0b93db-80e4-4b61-9e1e-f12915232903_0">
											<gml:posList>35.67074523508812 139.73881094045618 58.759 35.67074523508812 139.73881094045618 17.936 35.6707491694182 139.73882795818176 17.936 35.6707491694182 139.73882795818176 58.759 35.67074523508812 139.73881094045618 58.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a3c00ac6-522e-49f3-b9bb-8a1ef3f5a7e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a3c00ac6-522e-49f3-b9bb-8a1ef3f5a7e4_0">
											<gml:posList>35.670757940984515 139.73880652904492 58.759 35.670757940984515 139.73880652904492 17.936 35.67074523508812 139.73881094045618 17.936 35.67074523508812 139.73881094045618 58.759 35.670757940984515 139.73880652904492 58.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf01489b-bd64-48f5-a4f6-f52c2e5c81a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bf01489b-bd64-48f5-a4f6-f52c2e5c81a6_0">
											<gml:posList>35.67076873107837 139.7388533085046 58.759 35.670757940984515 139.73880652904492 58.759 35.67074523508812 139.73881094045618 58.759 35.6707491694182 139.73882795818176 58.759 35.67073760795155 139.73883197057316 58.759 35.67074447271771 139.73886172123957 58.759 35.67076873107837 139.7388533085046 58.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99444494-7476-4d6f-a5f3-95ddedcc6f5d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-99444494-7476-4d6f-a5f3-95ddedcc6f5d_0">
											<gml:posList>35.67074447271771 139.73886172123957 58.759 35.67074447271771 139.73886172123957 17.936 35.67076873107837 139.7388533085046 17.936 35.67076873107837 139.7388533085046 58.759 35.67074447271771 139.73886172123957 58.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-795b8528-0209-44ca-ad87-10240df8ffd5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-795b8528-0209-44ca-ad87-10240df8ffd5_0">
											<gml:posList>35.67076873107837 139.7388533085046 58.759 35.67076873107837 139.7388533085046 17.936 35.670757940984515 139.73880652904492 17.936 35.670757940984515 139.73880652904492 58.759 35.67076873107837 139.7388533085046 58.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_3a55f478-5559-4eed-a0a9-ca93cb6f9c28_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c339fa6-f96e-4f6c-9f0c-4fd5b478da33">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67071829530826 139.73871052815713 58.297 35.670723088915516 139.73873131164868 58.297 35.67071333871548 139.7387346922762 58.297 35.67070854510881 139.738713908787 58.297 35.67071829530826 139.73871052815713 58.297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-480f3ed4-9937-44bd-b299-b460cd336a90">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670728001749204 139.73880062142953 58.297 35.670723913644224 139.7387829190201 58.297 35.67073485333592 139.73877912828178 58.297 35.67073893242773 139.73879683070405 58.297 35.670728001749204 139.73880062142953 58.297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb0e6fbf-a091-41e0-b695-55269f4d288c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb0e6fbf-a091-41e0-b695-55269f4d288c_0">
											<gml:posList>35.67071829530826 139.73871052815713 58.297 35.67070854510881 139.738713908787 58.297 35.67070854510881 139.738713908787 59.384 35.67071829530826 139.73871052815713 59.384 35.67071829530826 139.73871052815713 58.297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad372451-6110-46bc-a02c-4ab72cfeaa94">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ad372451-6110-46bc-a02c-4ab72cfeaa94_0">
											<gml:posList>35.670723088915516 139.73873131164868 58.297 35.67071829530826 139.73871052815713 58.297 35.67071829530826 139.73871052815713 59.384 35.670723088915516 139.73873131164868 59.384 35.670723088915516 139.73873131164868 58.297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bdd0e66d-2f04-416a-9fd8-223691626f18">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bdd0e66d-2f04-416a-9fd8-223691626f18_0">
											<gml:posList>35.67071829530826 139.73871052815713 59.384 35.67070854510881 139.738713908787 59.384 35.67071333871548 139.7387346922762 59.384 35.670723088915516 139.73873131164868 59.384 35.67071829530826 139.73871052815713 59.384</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca6aa0ca-4625-4093-bb2c-7e8e8876bc3f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ca6aa0ca-4625-4093-bb2c-7e8e8876bc3f_0">
											<gml:posList>35.67070854510881 139.738713908787 58.297 35.67071333871548 139.7387346922762 58.297 35.67071333871548 139.7387346922762 59.384 35.67070854510881 139.738713908787 59.384 35.67070854510881 139.738713908787 58.297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4bca6d89-0c48-4e15-9692-38db6501c4e1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4bca6d89-0c48-4e15-9692-38db6501c4e1_0">
											<gml:posList>35.67071333871548 139.7387346922762 58.297 35.670723088915516 139.73873131164868 58.297 35.670723088915516 139.73873131164868 59.384 35.67071333871548 139.7387346922762 59.384 35.67071333871548 139.7387346922762 58.297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b119418-c9ce-4c79-b269-59e25c4021f1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4b119418-c9ce-4c79-b269-59e25c4021f1_0">
											<gml:posList>35.67073485333592 139.73877912828178 58.297 35.670723913644224 139.7387829190201 58.297 35.670723913644224 139.7387829190201 59.82 35.67073485333592 139.73877912828178 59.82 35.67073485333592 139.73877912828178 58.297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a2567a2-33eb-4ff4-9744-c76f3e3d1e77">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6a2567a2-33eb-4ff4-9744-c76f3e3d1e77_0">
											<gml:posList>35.67073893242773 139.73879683070405 58.297 35.67073485333592 139.73877912828178 58.297 35.67073485333592 139.73877912828178 59.82 35.67073893242773 139.73879683070405 59.82 35.67073893242773 139.73879683070405 58.297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-54edbf60-7da7-4ee1-8921-028748491c3a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-54edbf60-7da7-4ee1-8921-028748491c3a_0">
											<gml:posList>35.670728001749204 139.73880062142953 59.82 35.67073893242773 139.73879683070405 59.82 35.67073485333592 139.73877912828178 59.82 35.670723913644224 139.7387829190201 59.82 35.670728001749204 139.73880062142953 59.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5862a0f3-7d19-4e3f-ae0f-17350872f658">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5862a0f3-7d19-4e3f-ae0f-17350872f658_0">
											<gml:posList>35.670723913644224 139.7387829190201 58.297 35.670728001749204 139.73880062142953 58.297 35.670728001749204 139.73880062142953 59.82 35.670723913644224 139.7387829190201 59.82 35.670723913644224 139.7387829190201 58.297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7fb92e3-3316-4f3e-9b47-77a35f9da403">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d7fb92e3-3316-4f3e-9b47-77a35f9da403_0">
											<gml:posList>35.67073893242773 139.73879683070405 58.297 35.67073893242773 139.73879683070405 59.82 35.670728001749204 139.73880062142953 59.82 35.670728001749204 139.73880062142953 58.297 35.67073893242773 139.73879683070405 58.297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-b33aad33-ae3c-499f-9b0f-2302b7b3ae57">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b33aad33-ae3c-499f-9b0f-2302b7b3ae57">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b33aad33-ae3c-499f-9b0f-2302b7b3ae57">
											<gml:posList>35.67060481137249 139.7388469070319 17.936 35.67059902613188 139.73884891322805 17.936 35.67055976394499 139.73867882463017 17.936 35.67064247843124 139.7386501502136 17.936 35.67064471242034 139.73865981308415 17.936 35.670658986282085 139.73865486958064 17.936 35.6706666289116 139.73868797735923 17.936 35.67068193005218 139.73868266811877 17.936 35.6706719901094 139.73863961033152 17.936 35.670767924116724 139.73860634704278 17.936 35.6708099630896 139.73878849535134 17.936 35.670745244101845 139.73881094044555 17.936 35.6707491694182 139.73882795818176 17.936 35.67072278439304 139.73883710248506 17.936 35.67069273855985 139.73870693513152 17.936 35.67067403115147 139.73871341929583 17.936 35.670698306595796 139.73881858459174 17.936 35.67068414987977 139.73882349479152 17.936 35.67068596781066 139.73883135761523 17.936 35.670607497591966 139.73885855770283 17.936 35.67060481137249 139.7388469070319 17.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9add618e-005e-4b7e-8902-dc2134e321fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9add618e-005e-4b7e-8902-dc2134e321fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9add618e-005e-4b7e-8902-dc2134e321fe">
											<gml:posList>35.67064471242034 139.73865981308415 58.759 35.67064247843124 139.7386501502136 58.759 35.67063979699765 139.73865607419432 58.759 35.67064203098628 139.7386657370647 58.759 35.67064471242034 139.73865981308415 58.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5a4cd502-fd4f-4f2d-b73c-6fd2f25a5f99">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a4cd502-fd4f-4f2d-b73c-6fd2f25a5f99">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a4cd502-fd4f-4f2d-b73c-6fd2f25a5f99">
											<gml:posList>35.6706719901094 139.73863961033152 58.759 35.67067682407899 139.73864292955864 58.759 35.67076522465792 139.73861227105553 58.759 35.670767924116724 139.73860634704278 58.759 35.6706719901094 139.73863961033152 58.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e2f9cfba-943a-4c68-99fd-66d5e3d52437">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e2f9cfba-943a-4c68-99fd-66d5e3d52437">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e2f9cfba-943a-4c68-99fd-66d5e3d52437">
											<gml:posList>35.67056554918281 139.73867681842273 58.759 35.67057038315145 139.73868013764772 58.759 35.67063979699765 139.73865607419432 58.759 35.67064247843124 139.7386501502136 58.759 35.67056554918281 139.73867681842273 58.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-99402400-2534-4ad0-9588-e26bf0f84dda">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-99402400-2534-4ad0-9588-e26bf0f84dda">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-99402400-2534-4ad0-9588-e26bf0f84dda">
											<gml:posList>35.67056554918281 139.73867681842273 41.534 35.67055976394499 139.73867882463017 41.534 35.67059902613188 139.73884891322805 41.534 35.67060481137249 139.7388469070319 41.534 35.67056554918281 139.73867681842273 41.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-86368b9b-a8fd-4ce5-985e-96150bfa18b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-86368b9b-a8fd-4ce5-985e-96150bfa18b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-86368b9b-a8fd-4ce5-985e-96150bfa18b8">
											<gml:posList>35.670607497591966 139.73885855770283 58.759 35.67061020608538 139.7388526447457 58.759 35.67057038315145 139.73868013764772 58.759 35.67056554918281 139.73867681842273 58.759 35.670607497591966 139.73885855770283 58.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c2c5f54c-30aa-4bcd-a8d4-5468e001463e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c2c5f54c-30aa-4bcd-a8d4-5468e001463e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c2c5f54c-30aa-4bcd-a8d4-5468e001463e">
											<gml:posList>35.67068596781066 139.73883135761523 58.759 35.67068115189104 139.7388280604477 58.759 35.67061020608538 139.7388526447457 58.759 35.670607497591966 139.73885855770283 58.759 35.67068596781066 139.73883135761523 58.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-679131aa-dc58-4fda-a04a-3f9778acb0c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-679131aa-dc58-4fda-a04a-3f9778acb0c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-679131aa-dc58-4fda-a04a-3f9778acb0c9">
											<gml:posList>35.67064471242034 139.73865981308415 58.759 35.67064203098628 139.7386657370647 58.759 35.67065629583453 139.73866079357308 58.759 35.670658986282085 139.73865486958064 58.759 35.67064471242034 139.73865981308415 58.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-80d9b587-f250-4be1-bcd1-bfaa0896aea7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-80d9b587-f250-4be1-bcd1-bfaa0896aea7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-80d9b587-f250-4be1-bcd1-bfaa0896aea7">
											<gml:posList>35.6706666289116 139.73868797735923 58.759 35.670658986282085 139.73865486958064 58.759 35.67065629583453 139.73866079357308 58.759 35.67066393846243 139.73869390135113 58.759 35.6706666289116 139.73868797735923 58.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a75fa8c8-6133-48b3-849f-5e5510a8b852">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a75fa8c8-6133-48b3-849f-5e5510a8b852">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a75fa8c8-6133-48b3-849f-5e5510a8b852">
											<gml:posList>35.6706666289116 139.73868797735923 58.759 35.67066393846243 139.73869390135113 58.759 35.67068676401191 139.7386859763026 58.759 35.67068193005218 139.73868266811877 58.759 35.6706666289116 139.73868797735923 58.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-598cae8c-aa36-4581-9149-0dfb0c0ab712">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-598cae8c-aa36-4581-9149-0dfb0c0ab712">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-598cae8c-aa36-4581-9149-0dfb0c0ab712">
											<gml:posList>35.67068193005218 139.73868266811877 58.759 35.67068676401191 139.7386859763026 58.759 35.67067682407899 139.73864292955864 58.759 35.6706719901094 139.73863961033152 58.759 35.67068193005218 139.73868266811877 58.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-992aa36e-a3cc-4f4f-86f4-e6a1baa3aa6f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-992aa36e-a3cc-4f4f-86f4-e6a1baa3aa6f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-992aa36e-a3cc-4f4f-86f4-e6a1baa3aa6f">
											<gml:posList>35.67069273855985 139.73870693513152 58.759 35.670695438040724 139.7387010332199 58.759 35.67066921522863 139.73871012213587 58.759 35.67067403115147 139.73871341929583 58.759 35.67069273855985 139.73870693513152 58.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-20a64815-3be4-44f7-adaa-55c5f1c8737e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20a64815-3be4-44f7-adaa-55c5f1c8737e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20a64815-3be4-44f7-adaa-55c5f1c8737e">
											<gml:posList>35.67068414987977 139.73882349479152 58.759 35.67067933395993 139.73882019762456 58.759 35.67068115189104 139.7388280604477 58.759 35.67068596781066 139.73883135761523 58.759 35.67068414987977 139.73882349479152 58.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-275b8549-746f-4e73-a782-2b1daa9ae82b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-275b8549-746f-4e73-a782-2b1daa9ae82b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-275b8549-746f-4e73-a782-2b1daa9ae82b">
											<gml:posList>35.67067403115147 139.73871341929583 58.759 35.67066921522863 139.73871012213587 58.759 35.670693481662106 139.7388152874351 58.759 35.670698306595796 139.73881858459174 58.759 35.67067403115147 139.73871341929583 58.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e9b4de13-1722-4da4-85a4-1a5ccfeff83f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e9b4de13-1722-4da4-85a4-1a5ccfeff83f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e9b4de13-1722-4da4-85a4-1a5ccfeff83f">
											<gml:posList>35.670695438040724 139.7387010332199 58.297 35.67072548387162 139.7388311895293 58.297 35.67074435348986 139.73882464996555 58.297 35.670740419159316 139.73880763224113 58.297 35.670805138146505 139.73878518714562 58.297 35.67076522465792 139.73861227105553 58.297 35.67067682407899 139.73864292955864 58.297 35.67068676401191 139.7386859763026 58.297 35.67066393846243 139.73869390135113 58.297 35.67065629583453 139.73866079357308 58.297 35.67064203098628 139.7386657370647 58.297 35.67063979699765 139.73865607419432 58.297 35.67057038315145 139.73868013764772 58.297 35.67061020608538 139.7388526447457 58.297 35.67068115189104 139.7388280604477 58.297 35.67067933395993 139.73882019762456 58.297 35.670693481662106 139.7388152874351 58.297 35.67066921522863 139.73871012213587 58.297 35.670695438040724 139.7387010332199 58.297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9be84514-632c-429d-8aac-e56232183f70">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9be84514-632c-429d-8aac-e56232183f70">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9be84514-632c-429d-8aac-e56232183f70">
											<gml:posList>35.67068414987977 139.73882349479152 58.759 35.670698306595796 139.73881858459174 58.759 35.670693481662106 139.7388152874351 58.759 35.67067933395993 139.73882019762456 58.759 35.67068414987977 139.73882349479152 58.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ba1e4a0d-c661-4466-b4f3-ae7508451099">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba1e4a0d-c661-4466-b4f3-ae7508451099">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba1e4a0d-c661-4466-b4f3-ae7508451099">
											<gml:posList>35.67069273855985 139.73870693513152 58.759 35.67072278439304 139.73883710248506 58.759 35.67072548387162 139.7388311895293 58.759 35.670695438040724 139.7387010332199 58.759 35.67069273855985 139.73870693513152 58.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4e0de761-350d-40aa-a6d2-d3d5fd4e1861">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4e0de761-350d-40aa-a6d2-d3d5fd4e1861">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4e0de761-350d-40aa-a6d2-d3d5fd4e1861">
											<gml:posList>35.6707491694182 139.73882795818176 58.759 35.67074435348986 139.73882464996555 58.759 35.67072548387162 139.7388311895293 58.759 35.67072278439304 139.73883710248506 58.759 35.6707491694182 139.73882795818176 58.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a28178c0-31d2-408a-b603-3f1f65daa09b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a28178c0-31d2-408a-b603-3f1f65daa09b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a28178c0-31d2-408a-b603-3f1f65daa09b">
											<gml:posList>35.670745244101845 139.73881094044555 58.759 35.670740419159316 139.73880763224113 58.759 35.67074435348986 139.73882464996555 58.759 35.6707491694182 139.73882795818176 58.759 35.670745244101845 139.73881094044555 58.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a8e7f5c4-ffdf-49d0-a1e9-f633f217c361">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a8e7f5c4-ffdf-49d0-a1e9-f633f217c361">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a8e7f5c4-ffdf-49d0-a1e9-f633f217c361">
											<gml:posList>35.670745244101845 139.73881094044555 58.759 35.6708099630896 139.73878849535134 58.759 35.670805138146505 139.73878518714562 58.759 35.670740419159316 139.73880763224113 58.759 35.670745244101845 139.73881094044555 58.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-50bbd3b7-d494-496a-ba45-6a0ddad853a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50bbd3b7-d494-496a-ba45-6a0ddad853a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50bbd3b7-d494-496a-ba45-6a0ddad853a3">
											<gml:posList>35.670767924116724 139.73860634704278 58.759 35.67076522465792 139.73861227105553 58.759 35.670805138146505 139.73878518714562 58.759 35.6708099630896 139.73878849535134 58.759 35.670767924116724 139.73860634704278 58.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f4f6677f-6a78-415f-8959-0b50703d157f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4f6677f-6a78-415f-8959-0b50703d157f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4f6677f-6a78-415f-8959-0b50703d157f">
											<gml:posList>35.670698306595796 139.73881858459174 17.936 35.67067403115147 139.73871341929583 17.936 35.67067403115147 139.73871341929583 58.759 35.670698306595796 139.73881858459174 58.759 35.670698306595796 139.73881858459174 17.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ecf9b251-7593-476c-bee4-d015c4118729">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ecf9b251-7593-476c-bee4-d015c4118729">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ecf9b251-7593-476c-bee4-d015c4118729">
											<gml:posList>35.67064247843124 139.7386501502136 58.759 35.67064247843124 139.7386501502136 17.936 35.67055976394499 139.73867882463017 17.936 35.67055976394499 139.73867882463017 41.534 35.67056554918281 139.73867681842273 41.534 35.67056554918281 139.73867681842273 58.759 35.67064247843124 139.7386501502136 58.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-91185782-c5cf-48fc-862a-7736000535fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-91185782-c5cf-48fc-862a-7736000535fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-91185782-c5cf-48fc-862a-7736000535fe">
											<gml:posList>35.67057038315145 139.73868013764772 58.759 35.67057038315145 139.73868013764772 58.297 35.67063979699765 139.73865607419432 58.297 35.67063979699765 139.73865607419432 58.759 35.67057038315145 139.73868013764772 58.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e56ce6ab-bb03-4555-9212-752db1e46166">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e56ce6ab-bb03-4555-9212-752db1e46166">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e56ce6ab-bb03-4555-9212-752db1e46166">
											<gml:posList>35.67063979699765 139.73865607419432 58.759 35.67063979699765 139.73865607419432 58.297 35.67064203098628 139.7386657370647 58.297 35.67064203098628 139.7386657370647 58.759 35.67063979699765 139.73865607419432 58.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-27bbb3ce-4fd7-46da-9054-0cbb29da3957">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-27bbb3ce-4fd7-46da-9054-0cbb29da3957">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-27bbb3ce-4fd7-46da-9054-0cbb29da3957">
											<gml:posList>35.67064471242034 139.73865981308415 17.936 35.67064247843124 139.7386501502136 17.936 35.67064247843124 139.7386501502136 58.759 35.67064471242034 139.73865981308415 58.759 35.67064471242034 139.73865981308415 17.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8c14d5c1-0c02-4d2c-95f1-05befd48f56c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c14d5c1-0c02-4d2c-95f1-05befd48f56c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c14d5c1-0c02-4d2c-95f1-05befd48f56c">
											<gml:posList>35.67064203098628 139.7386657370647 58.759 35.67064203098628 139.7386657370647 58.297 35.67065629583453 139.73866079357308 58.297 35.67065629583453 139.73866079357308 58.759 35.67064203098628 139.7386657370647 58.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e342c504-9f4b-4687-b2ad-ae95c04a64c8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e342c504-9f4b-4687-b2ad-ae95c04a64c8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e342c504-9f4b-4687-b2ad-ae95c04a64c8">
											<gml:posList>35.670658986282085 139.73865486958064 17.936 35.67064471242034 139.73865981308415 17.936 35.67064471242034 139.73865981308415 58.759 35.670658986282085 139.73865486958064 58.759 35.670658986282085 139.73865486958064 17.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6881a326-c810-4f34-b706-040196306663">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6881a326-c810-4f34-b706-040196306663">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6881a326-c810-4f34-b706-040196306663">
											<gml:posList>35.67065629583453 139.73866079357308 58.759 35.67065629583453 139.73866079357308 58.297 35.67066393846243 139.73869390135113 58.297 35.67066393846243 139.73869390135113 58.759 35.67065629583453 139.73866079357308 58.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5b635923-bc46-463a-b59a-476ec584ca01">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b635923-bc46-463a-b59a-476ec584ca01">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b635923-bc46-463a-b59a-476ec584ca01">
											<gml:posList>35.6706666289116 139.73868797735923 17.936 35.670658986282085 139.73865486958064 17.936 35.670658986282085 139.73865486958064 58.759 35.6706666289116 139.73868797735923 58.759 35.6706666289116 139.73868797735923 17.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e39611e5-e7c6-426f-a230-e83b761db129">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e39611e5-e7c6-426f-a230-e83b761db129">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e39611e5-e7c6-426f-a230-e83b761db129">
											<gml:posList>35.67068193005218 139.73868266811877 17.936 35.6706666289116 139.73868797735923 17.936 35.6706666289116 139.73868797735923 58.759 35.67068193005218 139.73868266811877 58.759 35.67068193005218 139.73868266811877 17.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-868ce551-d7b7-4fb9-a66f-c5cd27706330">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-868ce551-d7b7-4fb9-a66f-c5cd27706330">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-868ce551-d7b7-4fb9-a66f-c5cd27706330">
											<gml:posList>35.67066393846243 139.73869390135113 58.759 35.67066393846243 139.73869390135113 58.297 35.67068676401191 139.7386859763026 58.297 35.67068676401191 139.7386859763026 58.759 35.67066393846243 139.73869390135113 58.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9fafd388-53b1-4092-aba0-ba13f055a9ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9fafd388-53b1-4092-aba0-ba13f055a9ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9fafd388-53b1-4092-aba0-ba13f055a9ec">
											<gml:posList>35.6706719901094 139.73863961033152 17.936 35.67068193005218 139.73868266811877 17.936 35.67068193005218 139.73868266811877 58.759 35.6706719901094 139.73863961033152 58.759 35.6706719901094 139.73863961033152 17.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c67968d7-ee9a-4d2f-a13e-abe70881dd40">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c67968d7-ee9a-4d2f-a13e-abe70881dd40">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c67968d7-ee9a-4d2f-a13e-abe70881dd40">
											<gml:posList>35.67068676401191 139.7386859763026 58.759 35.67068676401191 139.7386859763026 58.297 35.67067682407899 139.73864292955864 58.297 35.67067682407899 139.73864292955864 58.759 35.67068676401191 139.7386859763026 58.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d94bd5c6-7f09-4174-b173-ffaff81432cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d94bd5c6-7f09-4174-b173-ffaff81432cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d94bd5c6-7f09-4174-b173-ffaff81432cc">
											<gml:posList>35.670695438040724 139.7387010332199 58.759 35.670695438040724 139.7387010332199 58.297 35.67066921522863 139.73871012213587 58.297 35.67066921522863 139.73871012213587 58.759 35.670695438040724 139.7387010332199 58.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6ddeaa61-3ad6-488b-ab75-5776bd7104e5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ddeaa61-3ad6-488b-ab75-5776bd7104e5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ddeaa61-3ad6-488b-ab75-5776bd7104e5">
											<gml:posList>35.67067403115147 139.73871341929583 17.936 35.67069273855985 139.73870693513152 17.936 35.67069273855985 139.73870693513152 58.759 35.67067403115147 139.73871341929583 58.759 35.67067403115147 139.73871341929583 17.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-436d9aa4-65fe-4c60-8ab4-e28cc2c805e0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-436d9aa4-65fe-4c60-8ab4-e28cc2c805e0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-436d9aa4-65fe-4c60-8ab4-e28cc2c805e0">
											<gml:posList>35.670767924116724 139.73860634704278 17.936 35.6706719901094 139.73863961033152 17.936 35.6706719901094 139.73863961033152 58.759 35.670767924116724 139.73860634704278 58.759 35.670767924116724 139.73860634704278 17.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-61486030-a9dc-4454-9467-20c7ac8404f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61486030-a9dc-4454-9467-20c7ac8404f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61486030-a9dc-4454-9467-20c7ac8404f9">
											<gml:posList>35.67067682407899 139.73864292955864 58.759 35.67067682407899 139.73864292955864 58.297 35.67076522465792 139.73861227105553 58.297 35.67076522465792 139.73861227105553 58.759 35.67067682407899 139.73864292955864 58.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6d406596-595e-4e87-b172-621ff31b58de">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d406596-595e-4e87-b172-621ff31b58de">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d406596-595e-4e87-b172-621ff31b58de">
											<gml:posList>35.67076522465792 139.73861227105553 58.759 35.67076522465792 139.73861227105553 58.297 35.670805138146505 139.73878518714562 58.297 35.670805138146505 139.73878518714562 58.759 35.67076522465792 139.73861227105553 58.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4573719f-d427-4798-84cb-bb2ba7d2db51">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4573719f-d427-4798-84cb-bb2ba7d2db51">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4573719f-d427-4798-84cb-bb2ba7d2db51">
											<gml:posList>35.6708099630896 139.73878849535134 17.936 35.670767924116724 139.73860634704278 17.936 35.670767924116724 139.73860634704278 58.759 35.6708099630896 139.73878849535134 58.759 35.6708099630896 139.73878849535134 17.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-56825fa9-fd22-40d3-af59-7259ab1b10b5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56825fa9-fd22-40d3-af59-7259ab1b10b5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56825fa9-fd22-40d3-af59-7259ab1b10b5">
											<gml:posList>35.67055976394499 139.73867882463017 17.936 35.67059902613188 139.73884891322805 17.936 35.67059902613188 139.73884891322805 41.534 35.67055976394499 139.73867882463017 41.534 35.67055976394499 139.73867882463017 17.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3ffc6b78-a833-4f51-84b5-2004c51aed08">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ffc6b78-a833-4f51-84b5-2004c51aed08">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ffc6b78-a833-4f51-84b5-2004c51aed08">
											<gml:posList>35.67060481137249 139.7388469070319 41.534 35.67060481137249 139.7388469070319 17.936 35.670607497591966 139.73885855770283 17.936 35.670607497591966 139.73885855770283 58.759 35.67056554918281 139.73867681842273 58.759 35.67056554918281 139.73867681842273 41.534 35.67060481137249 139.7388469070319 41.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c13349fa-3eaa-4b1c-9040-45b57607011f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c13349fa-3eaa-4b1c-9040-45b57607011f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c13349fa-3eaa-4b1c-9040-45b57607011f">
											<gml:posList>35.67061020608538 139.7388526447457 58.759 35.67061020608538 139.7388526447457 58.297 35.67057038315145 139.73868013764772 58.297 35.67057038315145 139.73868013764772 58.759 35.67061020608538 139.7388526447457 58.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e6562963-56ee-43c1-be62-a91767e99a16">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e6562963-56ee-43c1-be62-a91767e99a16">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e6562963-56ee-43c1-be62-a91767e99a16">
											<gml:posList>35.67059902613188 139.73884891322805 17.936 35.67060481137249 139.7388469070319 17.936 35.67060481137249 139.7388469070319 41.534 35.67059902613188 139.73884891322805 41.534 35.67059902613188 139.73884891322805 17.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f4ea3722-b343-454b-b6dc-f7687bf383d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4ea3722-b343-454b-b6dc-f7687bf383d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4ea3722-b343-454b-b6dc-f7687bf383d1">
											<gml:posList>35.67068115189104 139.7388280604477 58.759 35.67068115189104 139.7388280604477 58.297 35.67061020608538 139.7388526447457 58.297 35.67061020608538 139.7388526447457 58.759 35.67068115189104 139.7388280604477 58.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dc7e5902-beec-4452-b80f-433349e7b003">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc7e5902-beec-4452-b80f-433349e7b003">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc7e5902-beec-4452-b80f-433349e7b003">
											<gml:posList>35.670607497591966 139.73885855770283 17.936 35.67068596781066 139.73883135761523 17.936 35.67068596781066 139.73883135761523 58.759 35.670607497591966 139.73885855770283 58.759 35.670607497591966 139.73885855770283 17.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8d136f4a-b906-4401-80b3-824006d634fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d136f4a-b906-4401-80b3-824006d634fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d136f4a-b906-4401-80b3-824006d634fc">
											<gml:posList>35.67067933395993 139.73882019762456 58.759 35.67067933395993 139.73882019762456 58.297 35.67068115189104 139.7388280604477 58.297 35.67068115189104 139.7388280604477 58.759 35.67067933395993 139.73882019762456 58.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fb846de3-9a8f-4596-a346-0416ed5f3d90">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb846de3-9a8f-4596-a346-0416ed5f3d90">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb846de3-9a8f-4596-a346-0416ed5f3d90">
											<gml:posList>35.67066921522863 139.73871012213587 58.759 35.67066921522863 139.73871012213587 58.297 35.670693481662106 139.7388152874351 58.297 35.670693481662106 139.7388152874351 58.759 35.67066921522863 139.73871012213587 58.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-528edd9b-f6e0-4825-9fa6-632d7b79966c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-528edd9b-f6e0-4825-9fa6-632d7b79966c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-528edd9b-f6e0-4825-9fa6-632d7b79966c">
											<gml:posList>35.67068596781066 139.73883135761523 17.936 35.67068414987977 139.73882349479152 17.936 35.67068414987977 139.73882349479152 58.759 35.67068596781066 139.73883135761523 58.759 35.67068596781066 139.73883135761523 17.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1ad178a9-1167-403b-ad30-94989b1512f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ad178a9-1167-403b-ad30-94989b1512f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ad178a9-1167-403b-ad30-94989b1512f7">
											<gml:posList>35.670693481662106 139.7388152874351 58.759 35.670693481662106 139.7388152874351 58.297 35.67067933395993 139.73882019762456 58.297 35.67067933395993 139.73882019762456 58.759 35.670693481662106 139.7388152874351 58.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d68fa828-5068-43fd-bfe9-6a1ac8a31beb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d68fa828-5068-43fd-bfe9-6a1ac8a31beb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d68fa828-5068-43fd-bfe9-6a1ac8a31beb">
											<gml:posList>35.67068414987977 139.73882349479152 17.936 35.670698306595796 139.73881858459174 17.936 35.670698306595796 139.73881858459174 58.759 35.67068414987977 139.73882349479152 58.759 35.67068414987977 139.73882349479152 17.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-412c4015-5225-4c89-9c79-de42494749bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-412c4015-5225-4c89-9c79-de42494749bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-412c4015-5225-4c89-9c79-de42494749bf">
											<gml:posList>35.67069273855985 139.73870693513152 17.936 35.67072278439304 139.73883710248506 17.936 35.67072278439304 139.73883710248506 58.759 35.67069273855985 139.73870693513152 58.759 35.67069273855985 139.73870693513152 17.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2de8131b-d217-4654-a6df-0cc1745b3a75">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2de8131b-d217-4654-a6df-0cc1745b3a75">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2de8131b-d217-4654-a6df-0cc1745b3a75">
											<gml:posList>35.67072548387162 139.7388311895293 58.759 35.67072548387162 139.7388311895293 58.297 35.670695438040724 139.7387010332199 58.297 35.670695438040724 139.7387010332199 58.759 35.67072548387162 139.7388311895293 58.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9619e6d6-3234-4b91-8255-78088ceae1af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9619e6d6-3234-4b91-8255-78088ceae1af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9619e6d6-3234-4b91-8255-78088ceae1af">
											<gml:posList>35.67074435348986 139.73882464996555 58.759 35.67074435348986 139.73882464996555 58.297 35.67072548387162 139.7388311895293 58.297 35.67072548387162 139.7388311895293 58.759 35.67074435348986 139.73882464996555 58.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ed6aa030-4ee3-4923-b97e-672a44743da6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed6aa030-4ee3-4923-b97e-672a44743da6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed6aa030-4ee3-4923-b97e-672a44743da6">
											<gml:posList>35.67072278439304 139.73883710248506 17.936 35.6707491694182 139.73882795818176 17.936 35.6707491694182 139.73882795818176 58.759 35.67072278439304 139.73883710248506 58.759 35.67072278439304 139.73883710248506 17.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-683035cf-39ae-46bc-a809-f54c2b0c347c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-683035cf-39ae-46bc-a809-f54c2b0c347c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-683035cf-39ae-46bc-a809-f54c2b0c347c">
											<gml:posList>35.670740419159316 139.73880763224113 58.759 35.670740419159316 139.73880763224113 58.297 35.67074435348986 139.73882464996555 58.297 35.67074435348986 139.73882464996555 58.759 35.670740419159316 139.73880763224113 58.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a22efc01-cce4-4bc4-bcaa-dec8671927e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a22efc01-cce4-4bc4-bcaa-dec8671927e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a22efc01-cce4-4bc4-bcaa-dec8671927e2">
											<gml:posList>35.6707491694182 139.73882795818176 17.936 35.670745244101845 139.73881094044555 17.936 35.670745244101845 139.73881094044555 58.759 35.6707491694182 139.73882795818176 58.759 35.6707491694182 139.73882795818176 17.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8db6df93-b81c-4749-be26-9e4be1379841">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8db6df93-b81c-4749-be26-9e4be1379841">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8db6df93-b81c-4749-be26-9e4be1379841">
											<gml:posList>35.670805138146505 139.73878518714562 58.759 35.670805138146505 139.73878518714562 58.297 35.670740419159316 139.73880763224113 58.297 35.670740419159316 139.73880763224113 58.759 35.670805138146505 139.73878518714562 58.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8726a361-29ac-4e54-be5c-58f681a0b25e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8726a361-29ac-4e54-be5c-58f681a0b25e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8726a361-29ac-4e54-be5c-58f681a0b25e">
											<gml:posList>35.6708099630896 139.73878849535134 58.759 35.670745244101845 139.73881094044555 58.759 35.670745244101845 139.73881094044555 17.936 35.6708099630896 139.73878849535134 17.936 35.6708099630896 139.73878849535134 58.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6747</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">477.728</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>