<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_3aab38b9-c395-4e0d-bee3-a5f81c4ea9bf">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門駅南地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">22.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66920088334383 139.74939036027027 0 35.66920613680202 139.7493752105692 0 35.669065606762935 139.74930208907546 0 35.669060128425336 139.74931789070897 0 35.66905948821953 139.74931755999745 0 35.669028948079024 139.74940572862354 0 35.66918184938139 139.7494852882473 0 35.669192464253655 139.749454657367 0 35.669210119539606 139.74946384029806 0 35.6692302787721 139.74940565043894 0 35.66920088334383 139.74939036027027 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66920088334383 139.74939036027027 6.37 35.6692302787721 139.74940565043894 6.37 35.669210119539606 139.74946384029806 6.37 35.669192464253655 139.749454657367 6.37 35.66918184938139 139.7494852882473 6.37 35.669028948079024 139.74940572862354 6.37 35.66905948821953 139.74931755999745 6.37 35.669060128425336 139.74931789070897 6.37 35.669065606762935 139.74930208907546 6.37 35.66920613680202 139.7493752105692 6.37 35.66920088334383 139.74939036027027 6.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66920088334383 139.74939036027027 6.37 35.66920613680202 139.7493752105692 6.37 35.66920613680202 139.7493752105692 28.65 35.66920088334383 139.74939036027027 28.65 35.66920088334383 139.74939036027027 6.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66920613680202 139.7493752105692 6.37 35.669065606762935 139.74930208907546 6.37 35.669065606762935 139.74930208907546 28.65 35.66920613680202 139.7493752105692 28.65 35.66920613680202 139.7493752105692 6.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669065606762935 139.74930208907546 6.37 35.669060128425336 139.74931789070897 6.37 35.669060128425336 139.74931789070897 28.65 35.669065606762935 139.74930208907546 28.65 35.669065606762935 139.74930208907546 6.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669060128425336 139.74931789070897 6.37 35.66905948821953 139.74931755999745 6.37 35.66905948821953 139.74931755999745 28.65 35.669060128425336 139.74931789070897 28.65 35.669060128425336 139.74931789070897 6.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66905948821953 139.74931755999745 6.37 35.669028948079024 139.74940572862354 6.37 35.669028948079024 139.74940572862354 28.65 35.66905948821953 139.74931755999745 28.65 35.66905948821953 139.74931755999745 6.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669028948079024 139.74940572862354 6.37 35.66918184938139 139.7494852882473 6.37 35.66918184938139 139.7494852882473 28.65 35.669028948079024 139.74940572862354 28.65 35.669028948079024 139.74940572862354 6.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66918184938139 139.7494852882473 6.37 35.669192464253655 139.749454657367 6.37 35.669192464253655 139.749454657367 28.65 35.66918184938139 139.7494852882473 28.65 35.66918184938139 139.7494852882473 6.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669192464253655 139.749454657367 6.37 35.669210119539606 139.74946384029806 6.37 35.669210119539606 139.74946384029806 28.65 35.669192464253655 139.749454657367 28.65 35.669192464253655 139.749454657367 6.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669210119539606 139.74946384029806 6.37 35.6692302787721 139.74940565043894 6.37 35.6692302787721 139.74940565043894 28.65 35.669210119539606 139.74946384029806 28.65 35.669210119539606 139.74946384029806 6.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6692302787721 139.74940565043894 6.37 35.66920088334383 139.74939036027027 6.37 35.66920088334383 139.74939036027027 28.65 35.6692302787721 139.74940565043894 28.65 35.6692302787721 139.74940565043894 6.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66920088334383 139.74939036027027 28.65 35.66920613680202 139.7493752105692 28.65 35.669065606762935 139.74930208907546 28.65 35.669060128425336 139.74931789070897 28.65 35.66905948821953 139.74931755999745 28.65 35.669028948079024 139.74940572862354 28.65 35.66918184938139 139.7494852882473 28.65 35.669192464253655 139.749454657367 28.65 35.669210119539606 139.74946384029806 28.65 35.6692302787721 139.74940565043894 28.65 35.66920088334383 139.74939036027027 28.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-94a44a18-f5ce-495a-8683-1aebbc5f0d87"/>
							<gml:surfaceMember xlink:href="#poly-32c110e2-e355-4e0e-9166-0a17f758e620"/>
							<gml:surfaceMember xlink:href="#poly-3dfa7edb-9992-4f9a-a644-ad41dfff8078"/>
							<gml:surfaceMember xlink:href="#poly-dffba6a4-5bb2-4cad-8208-9ed12df4dbbc"/>
							<gml:surfaceMember xlink:href="#poly-fa1d3587-866b-49ff-8fb7-4dd04e051a51"/>
							<gml:surfaceMember xlink:href="#poly-827b62ea-f2d3-4043-9652-9c3ac865fae2"/>
							<gml:surfaceMember xlink:href="#poly-788abaaf-5251-46c5-a95b-db2485d5135c"/>
							<gml:surfaceMember xlink:href="#poly-b33ede9f-b0b4-4717-a807-0ab36e6364ec"/>
							<gml:surfaceMember xlink:href="#poly-f4b38ef9-0c84-4787-af94-87c58c85cae3"/>
							<gml:surfaceMember xlink:href="#poly-4443c6a8-d000-4cf2-85cc-05c84ee7c4c9"/>
							<gml:surfaceMember xlink:href="#poly-29b5de30-b45f-4453-8d87-142a8994774d"/>
							<gml:surfaceMember xlink:href="#poly-a3270789-b37d-4f44-805b-60b23e9227ee"/>
							<gml:surfaceMember xlink:href="#poly-f55d2b32-f64f-4c5d-981a-7c89f304129d"/>
							<gml:surfaceMember xlink:href="#poly-cb1319a9-8595-4535-8c9b-7c705b1f35f9"/>
							<gml:surfaceMember xlink:href="#poly-e26b585d-678c-454b-bee0-630fdd16e460"/>
							<gml:surfaceMember xlink:href="#poly-64445d56-d1bc-4e83-a04a-616298e8b5d4"/>
							<gml:surfaceMember xlink:href="#poly-79ec436a-3481-4294-bb17-29f671ec72c5"/>
							<gml:surfaceMember xlink:href="#poly-11cb8066-7885-4144-a66c-087cbd6cb3f0"/>
							<gml:surfaceMember xlink:href="#poly-645bdf9a-eba1-4731-ac3e-bf46fd860bf4"/>
							<gml:surfaceMember xlink:href="#poly-c366cb4e-3886-48a6-9706-da66a18a304d"/>
							<gml:surfaceMember xlink:href="#poly-8731caad-a160-4ba6-b4a4-3912549168c0"/>
							<gml:surfaceMember xlink:href="#poly-4cca8909-ff46-4621-8b7a-bbf34157a6f2"/>
							<gml:surfaceMember xlink:href="#poly-3fce2d44-c9bf-4c5d-947b-074ae1805981"/>
							<gml:surfaceMember xlink:href="#poly-b753ba98-6272-46b8-833d-b9b15d4ece02"/>
							<gml:surfaceMember xlink:href="#poly-853f9cac-88bf-45ef-87fa-dbca6019a41b"/>
							<gml:surfaceMember xlink:href="#poly-8137fd51-df48-48b8-9ed9-88dfaa8fe4c4"/>
							<gml:surfaceMember xlink:href="#poly-2d9feeeb-2a56-4107-bf48-cc9fc41bb812"/>
							<gml:surfaceMember xlink:href="#poly-38acaaaf-9ec3-44bb-a28b-dc5868ecde5c"/>
							<gml:surfaceMember xlink:href="#poly-eed627fa-ad40-4710-b29c-d06b524d678f"/>
							<gml:surfaceMember xlink:href="#poly-03611d27-b1f3-4530-a694-b86aeacac29b"/>
							<gml:surfaceMember xlink:href="#poly-7a9813ff-1d34-4f1c-8f2e-84620f75ff83"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_3aab38b9-c395-4e0d-bee3-a5f81c4ea9bf_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-819ef7b7-671c-4a49-8b1f-e425f9844934">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-819ef7b7-671c-4a49-8b1f-e425f9844934_0">
											<gml:posList>35.6690863850755 139.74936907283322 28.596 35.669092429189085 139.74935026607088 30.116 35.6690863850755 139.74936907283322 30.116 35.6690863850755 139.74936907283322 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b16d613-06bb-4c74-aaab-e84b510fc323">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4b16d613-06bb-4c74-aaab-e84b510fc323_0">
											<gml:posList>35.6690863850755 139.74936907283322 28.596 35.669092429189085 139.74935026607088 28.596 35.669092429189085 139.74935026607088 30.116 35.6690863850755 139.74936907283322 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0c64210c-3d1e-4256-964e-56a8f49bf682">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0c64210c-3d1e-4256-964e-56a8f49bf682_0">
											<gml:posList>35.66909528331063 139.7493714826074 28.596 35.66910761863295 139.7493779868806 29.645 35.66910761863295 139.7493779868806 28.596 35.66909528331063 139.7493714826074 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7bad2d42-6282-4ee0-85cc-faf97b565f09">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7bad2d42-6282-4ee0-85cc-faf97b565f09_0">
											<gml:posList>35.66909528331063 139.7493714826074 28.596 35.66909528331063 139.7493714826074 29.645 35.66910761863295 139.7493779868806 29.645 35.66909528331063 139.7493714826074 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a3c8369-68e5-4d72-a53a-45f270bf64ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2a3c8369-68e5-4d72-a53a-45f270bf64ce_0">
											<gml:posList>35.669192824174424 139.74944081623127 28.596 35.669196080670986 139.7494315230563 29.1 35.669192824174424 139.74944081623127 29.1 35.669192824174424 139.74944081623127 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d2acacf-11e5-476c-b48e-34c043ba1428">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4d2acacf-11e5-476c-b48e-34c043ba1428_0">
											<gml:posList>35.669192824174424 139.74944081623127 28.596 35.669196080670986 139.7494315230563 28.596 35.669196080670986 139.7494315230563 29.1 35.669192824174424 139.74944081623127 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-383b9a1e-03e4-4b83-acea-028e574597bf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-383b9a1e-03e4-4b83-acea-028e574597bf_0">
											<gml:posList>35.66907359929742 139.74936290041722 28.596 35.6690863850755 139.74936907283322 30.116 35.66907359929742 139.74936290041722 30.116 35.66907359929742 139.74936290041722 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ccf0387d-3d66-4e7a-8a18-461efe053659">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ccf0387d-3d66-4e7a-8a18-461efe053659_0">
											<gml:posList>35.66907359929742 139.74936290041722 28.596 35.6690863850755 139.74936907283322 28.596 35.6690863850755 139.74936907283322 30.116 35.66907359929742 139.74936290041722 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4fc9b491-fa19-47f8-ac09-1676b17aec59">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4fc9b491-fa19-47f8-ac09-1676b17aec59_0">
											<gml:posList>35.66904860421044 139.7493499695453 29.1 35.66903711679657 139.74938313084928 29.754 35.66904860421044 139.7493499695453 29.754 35.66904860421044 139.7493499695453 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-340abf83-1c5c-4ad4-acdd-1b86aefc42fe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-340abf83-1c5c-4ad4-acdd-1b86aefc42fe_0">
											<gml:posList>35.66904860421044 139.7493499695453 29.1 35.66903711679657 139.74938313084928 29.1 35.66903711679657 139.74938313084928 29.754 35.66904860421044 139.7493499695453 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-86f432d2-e531-48f1-a055-f76ee4fac039">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-86f432d2-e531-48f1-a055-f76ee4fac039_0">
											<gml:posList>35.669051949535735 139.74935173341373 29.1 35.66904046212139 139.74938489471884 28.596 35.66904046212139 139.74938489471884 29.1 35.669051949535735 139.74935173341373 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f773e2c3-6f86-4fad-800b-eaf81697c4ac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f773e2c3-6f86-4fad-800b-eaf81697c4ac_0">
											<gml:posList>35.669051949535735 139.74935173341373 29.1 35.669051949535735 139.74935173341373 28.596 35.66904046212139 139.74938489471884 28.596 35.669051949535735 139.74935173341373 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-471b45f9-ac75-499b-8166-dff04b2f5335">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-471b45f9-ac75-499b-8166-dff04b2f5335_0">
											<gml:posList>35.66909246097436 139.7493699943416 28.596 35.66908802458788 139.74936765721782 29.645 35.66909246097436 139.7493699943416 29.645 35.66909246097436 139.7493699943416 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58576825-d9ac-4865-a34b-b838cf049f06">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-58576825-d9ac-4865-a34b-b838cf049f06_0">
											<gml:posList>35.66909246097436 139.7493699943416 28.596 35.66908802458788 139.74936765721782 28.596 35.66908802458788 139.74936765721782 29.645 35.66909246097436 139.7493699943416 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9da6132b-3c30-473c-adf0-db6d19841cc6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9da6132b-3c30-473c-adf0-db6d19841cc6_0">
											<gml:posList>35.66905928039197 139.74935559186287 29.754 35.66903711679657 139.74938313084928 29.754 35.66904779297658 139.74938875317045 29.754 35.66905928039197 139.74935559186287 29.754</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ed96b2c-3c3e-49f3-a43c-cc155d99d8a1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9ed96b2c-3c3e-49f3-a43c-cc155d99d8a1_0">
											<gml:posList>35.66905928039197 139.74935559186287 29.754 35.66904860421044 139.7493499695453 29.754 35.66903711679657 139.74938313084928 29.754 35.66905928039197 139.74935559186287 29.754</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0acaed10-f7ca-4659-b407-11030c5188f1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0acaed10-f7ca-4659-b407-11030c5188f1_0">
											<gml:posList>35.669124376501216 139.7493669784771 28.596 35.66912106609668 139.74937651471672 31.792 35.669124376501216 139.7493669784771 31.792 35.669124376501216 139.7493669784771 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d9a3968-05d3-4922-a2f6-4bd4ad47ad54">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6d9a3968-05d3-4922-a2f6-4bd4ad47ad54_0">
											<gml:posList>35.669124376501216 139.7493669784771 28.596 35.66912106609668 139.74937651471672 28.596 35.66912106609668 139.74937651471672 31.792 35.669124376501216 139.7493669784771 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f07810eb-bdb9-4d41-8054-a9957dcfb5eb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f07810eb-bdb9-4d41-8054-a9957dcfb5eb_0">
											<gml:posList>35.66904779297658 139.74938875317045 28.596 35.66905928039197 139.74935559186287 29.754 35.66904779297658 139.74938875317045 29.754 35.66904779297658 139.74938875317045 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16559378-d839-40fd-8dd6-03320751b2f7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16559378-d839-40fd-8dd6-03320751b2f7_0">
											<gml:posList>35.66904779297658 139.74938875317045 28.596 35.66905928039197 139.74935559186287 28.596 35.66905928039197 139.74935559186287 29.754 35.66904779297658 139.74938875317045 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c49866f-5ab3-4f5a-b8f9-c8755ce775f1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8c49866f-5ab3-4f5a-b8f9-c8755ce775f1_0">
											<gml:posList>35.66909246097436 139.7493699943416 28.596 35.66909246097436 139.7493699943416 29.645 35.66910324700893 139.74933926388616 28.596 35.66909246097436 139.7493699943416 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cab62b99-31c8-4f9c-a1cc-b443c2f4d4e8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cab62b99-31c8-4f9c-a1cc-b443c2f4d4e8_0">
											<gml:posList>35.66910324700893 139.74933926388616 28.596 35.66909246097436 139.7493699943416 29.645 35.66910324700893 139.74933926388616 31.601 35.66910324700893 139.74933926388616 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c536e0d-491e-4f85-9912-ab00e3102651">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8c536e0d-491e-4f85-9912-ab00e3102651_0">
											<gml:posList>35.66910324700893 139.74933926388616 31.601 35.66909246097436 139.7493699943416 29.645 35.669078679273746 139.7494092113148 31.601 35.66910324700893 139.74933926388616 31.601</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8350c13-f8b8-422f-8ee2-a66265a22658">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b8350c13-f8b8-422f-8ee2-a66265a22658_0">
											<gml:posList>35.66909246097436 139.7493699943416 29.645 35.669078679273746 139.7494092113148 29.645 35.669078679273746 139.7494092113148 31.601 35.66909246097436 139.7493699943416 29.645</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-05ec88da-bf86-47cf-9543-143e5c93717b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-05ec88da-bf86-47cf-9543-143e5c93717b_0">
											<gml:posList>35.66909528331063 139.7493714826074 28.596 35.66910495386243 139.74934393459193 28.596 35.66909528331063 139.7493714826074 29.645 35.66909528331063 139.7493714826074 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c8878b39-990e-4f91-802d-6b46aa8cc62f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c8878b39-990e-4f91-802d-6b46aa8cc62f_0">
											<gml:posList>35.669081501609554 139.74941069958172 29.645 35.66909528331063 139.7493714826074 29.645 35.669081501609554 139.74941069958172 31.601 35.669081501609554 139.74941069958172 29.645</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4463733-ff5a-41a8-987c-284ccb355263">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b4463733-ff5a-41a8-987c-284ccb355263_0">
											<gml:posList>35.669081501609554 139.74941069958172 31.601 35.66909528331063 139.7493714826074 29.645 35.66910495386243 139.74934393459193 31.601 35.669081501609554 139.74941069958172 31.601</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1ecdd642-9281-4e39-9ba2-6cbe58fccaca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1ecdd642-9281-4e39-9ba2-6cbe58fccaca_0">
											<gml:posList>35.66909528331063 139.7493714826074 29.645 35.66910495386243 139.74934393459193 28.596 35.66910495386243 139.74934393459193 31.601 35.66909528331063 139.7493714826074 29.645</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0dd4efaa-42c8-4d72-a8a0-d84abb331c92">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0dd4efaa-42c8-4d72-a8a0-d84abb331c92_0">
											<gml:posList>35.6691829059411 139.74939752591482 28.596 35.669124376501216 139.7493669784771 31.792 35.6691829059411 139.74939752591482 31.792 35.6691829059411 139.74939752591482 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc681756-1e81-4344-ac60-86f26ef1d9fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc681756-1e81-4344-ac60-86f26ef1d9fd_0">
											<gml:posList>35.6691829059411 139.74939752591482 28.596 35.669124376501216 139.7493669784771 28.596 35.669124376501216 139.7493669784771 31.792 35.6691829059411 139.74939752591482 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e45e1d47-9727-4a6f-beaa-7383c6c1db32">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e45e1d47-9727-4a6f-beaa-7383c6c1db32_0">
											<gml:posList>35.66904046212139 139.74938489471884 28.596 35.66904779297658 139.74938875317045 28.596 35.66904046212139 139.74938489471884 29.1 35.66904046212139 139.74938489471884 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-03824db5-9402-4d93-a8b6-c6a9cc6232f4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-03824db5-9402-4d93-a8b6-c6a9cc6232f4_0">
											<gml:posList>35.66903711679657 139.74938313084928 29.1 35.66904046212139 139.74938489471884 29.1 35.66903711679657 139.74938313084928 29.754 35.66903711679657 139.74938313084928 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-be5f6856-76e0-4775-8b2f-9432240f2d13">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-be5f6856-76e0-4775-8b2f-9432240f2d13_0">
											<gml:posList>35.66903711679657 139.74938313084928 29.754 35.66904046212139 139.74938489471884 29.1 35.66904779297658 139.74938875317045 29.754 35.66903711679657 139.74938313084928 29.754</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c574905-4f06-4f30-91a6-1d08e6591c69">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2c574905-4f06-4f30-91a6-1d08e6591c69_0">
											<gml:posList>35.66904046212139 139.74938489471884 29.1 35.66904779297658 139.74938875317045 28.596 35.66904779297658 139.74938875317045 29.754 35.66904046212139 139.74938489471884 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-239a4b2b-b316-4983-acca-9b57a0ce3f39">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-239a4b2b-b316-4983-acca-9b57a0ce3f39_0">
											<gml:posList>35.6691829059411 139.74939752591482 31.792 35.669124376501216 139.7493669784771 31.792 35.66912106609668 139.74937651471672 31.792 35.6691829059411 139.74939752591482 31.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4428a28c-1ada-4f59-9d20-b2896b1e6ed0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4428a28c-1ada-4f59-9d20-b2896b1e6ed0_0">
											<gml:posList>35.66917958652816 139.74940707321565 31.792 35.6691829059411 139.74939752591482 31.792 35.66912106609668 139.74937651471672 31.792 35.66917958652816 139.74940707321565 31.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73f96d1a-1e57-4911-b764-1986f1a14865">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73f96d1a-1e57-4911-b764-1986f1a14865_0">
											<gml:posList>35.66908802458788 139.74936765721782 28.596 35.66907425190174 139.7494068741798 29.645 35.66908802458788 139.74936765721782 29.645 35.66908802458788 139.74936765721782 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dfd57060-981c-4cf7-971a-d70f69d5bdc7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dfd57060-981c-4cf7-971a-d70f69d5bdc7_0">
											<gml:posList>35.66908802458788 139.74936765721782 28.596 35.66907425190174 139.7494068741798 28.596 35.66907425190174 139.7494068741798 29.645 35.66908802458788 139.74936765721782 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e90fd7e7-5205-4449-9a65-bd2b21615126">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e90fd7e7-5205-4449-9a65-bd2b21615126_0">
											<gml:posList>35.66908802458788 139.74936765721782 29.645 35.66907425190174 139.7494068741798 29.645 35.669078679273746 139.7494092113148 29.645 35.66908802458788 139.74936765721782 29.645</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61167ca4-c6d4-40b1-9e18-0d1be5e6ca5a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-61167ca4-c6d4-40b1-9e18-0d1be5e6ca5a_0">
											<gml:posList>35.66909246097436 139.7493699943416 29.645 35.66908802458788 139.74936765721782 29.645 35.669078679273746 139.7494092113148 29.645 35.66909246097436 139.7493699943416 29.645</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1cc7691a-780c-41dd-be51-af24f8817511">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1cc7691a-780c-41dd-be51-af24f8817511_0">
											<gml:posList>35.66919717752402 139.74938867409708 29.1 35.66919592712634 139.7493922764338 28.596 35.66919717752402 139.74938867409708 28.596 35.66919717752402 139.74938867409708 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b6ed524e-9a8c-4795-9246-348eac727dac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b6ed524e-9a8c-4795-9246-348eac727dac_0">
											<gml:posList>35.66919717752402 139.74938867409708 29.1 35.66919592712634 139.7493922764338 29.1 35.66919592712634 139.7493922764338 28.596 35.66919717752402 139.74938867409708 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-21ee6b11-8340-4905-b43d-fe1287545d1b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-21ee6b11-8340-4905-b43d-fe1287545d1b_0">
											<gml:posList>35.66912106609668 139.74937651471672 28.596 35.66917958652816 139.74940707321565 31.792 35.66912106609668 139.74937651471672 31.792 35.66912106609668 139.74937651471672 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-732cbda7-5b70-4934-a8cf-5cd70895ad97">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-732cbda7-5b70-4934-a8cf-5cd70895ad97_0">
											<gml:posList>35.66912106609668 139.74937651471672 28.596 35.66917958652816 139.74940707321565 28.596 35.66917958652816 139.74940707321565 31.792 35.66912106609668 139.74937651471672 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8a911cc-eeea-4c73-aced-fbaa822a65e0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8a911cc-eeea-4c73-aced-fbaa822a65e0_0">
											<gml:posList>35.669093836929775 139.74941720385985 29.645 35.66910761863295 139.7493779868806 29.645 35.66909528331063 139.7493714826074 29.645 35.669093836929775 139.74941720385985 29.645</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-818e19e6-d9c1-42a5-af7f-85db2fda006c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-818e19e6-d9c1-42a5-af7f-85db2fda006c_0">
											<gml:posList>35.669081501609554 139.74941069958172 29.645 35.669093836929775 139.74941720385985 29.645 35.66909528331063 139.7493714826074 29.645 35.669081501609554 139.74941069958172 29.645</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5df7a598-0882-4a70-8471-050fe8f36b68">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5df7a598-0882-4a70-8471-050fe8f36b68_0">
											<gml:posList>35.66910761863295 139.7493779868806 28.596 35.669093836929775 139.74941720385985 29.645 35.669093836929775 139.74941720385985 28.596 35.66910761863295 139.7493779868806 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a2bc4ab-9bda-44e6-bbd4-efa7e61d40cd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1a2bc4ab-9bda-44e6-bbd4-efa7e61d40cd_0">
											<gml:posList>35.66910761863295 139.7493779868806 28.596 35.66910761863295 139.7493779868806 29.645 35.669093836929775 139.74941720385985 29.645 35.66910761863295 139.7493779868806 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3dee7e40-889b-42b0-bc88-63a195d3a615">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3dee7e40-889b-42b0-bc88-63a195d3a615_0">
											<gml:posList>35.66922989140512 139.74940597118137 29.1 35.66920869242668 139.74939493622585 31.601 35.66922989140512 139.74940597118137 31.601 35.66922989140512 139.74940597118137 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-134fa272-d10c-459b-bc21-81d1d8707bef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-134fa272-d10c-459b-bc21-81d1d8707bef_0">
											<gml:posList>35.66922989140512 139.74940597118137 29.1 35.66920869242668 139.74939493622585 29.1 35.66920869242668 139.74939493622585 31.601 35.66922989140512 139.74940597118137 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7346dec-df48-474d-b10f-2b15b93c611f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c7346dec-df48-474d-b10f-2b15b93c611f_0">
											<gml:posList>35.66910495386243 139.74934393459193 31.601 35.669078679273746 139.7494092113148 31.601 35.669081501609554 139.74941069958172 31.601 35.66910495386243 139.74934393459193 31.601</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f1a699a4-1bd8-4a17-ab38-4c75c570a275">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f1a699a4-1bd8-4a17-ab38-4c75c570a275_0">
											<gml:posList>35.669078679273746 139.7494092113148 31.601 35.66910495386243 139.74934393459193 31.601 35.66910324700893 139.74933926388616 31.601 35.669078679273746 139.7494092113148 31.601</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-330396c7-d75a-4948-ace3-0c963e22c4bc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-330396c7-d75a-4948-ace3-0c963e22c4bc_0">
											<gml:posList>35.669196080670986 139.7494315230563 31.601 35.669210119539585 139.74946384029806 31.601 35.66922989140512 139.74940597118137 31.601 35.669196080670986 139.7494315230563 31.601</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-419deb40-50cd-48e2-b88b-5a19c0c7b38a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-419deb40-50cd-48e2-b88b-5a19c0c7b38a_0">
											<gml:posList>35.66918847871678 139.74945255173196 31.601 35.669210119539585 139.74946384029806 31.601 35.669192824174424 139.74944081623127 31.601 35.66918847871678 139.74945255173196 31.601</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18187843-f0fb-4fa0-8feb-b0ff0c4adfd5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-18187843-f0fb-4fa0-8feb-b0ff0c4adfd5_0">
											<gml:posList>35.66920869242668 139.74939493622585 31.601 35.66910324700893 139.74933926388616 31.601 35.66910495386243 139.74934393459193 31.601 35.66920869242668 139.74939493622585 31.601</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04cb9715-c8a2-48ce-a0ea-49c4f250a07e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-04cb9715-c8a2-48ce-a0ea-49c4f250a07e_0">
											<gml:posList>35.66922989140512 139.74940597118137 31.601 35.66920869242668 139.74939493622585 31.601 35.669207468977596 139.74939840598162 31.601 35.66922989140512 139.74940597118137 31.601</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5be2cf39-3e8b-4c6b-9021-f18782e26bfa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5be2cf39-3e8b-4c6b-9021-f18782e26bfa_0">
											<gml:posList>35.669192824174424 139.74944081623127 31.601 35.669210119539585 139.74946384029806 31.601 35.669196080670986 139.7494315230563 31.601 35.669192824174424 139.74944081623127 31.601</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1998aa92-5732-4666-a5d1-d968eccaff8c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1998aa92-5732-4666-a5d1-d968eccaff8c_0">
											<gml:posList>35.669196080670986 139.7494315230563 31.601 35.66922989140512 139.74940597118137 31.601 35.669207468977596 139.74939840598162 31.601 35.669196080670986 139.7494315230563 31.601</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01d4574d-59eb-464c-ab31-f34909174d4c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01d4574d-59eb-464c-ab31-f34909174d4c_0">
											<gml:posList>35.669207468977596 139.74939840598162 31.601 35.66920869242668 139.74939493622585 31.601 35.66910495386243 139.74934393459193 31.601 35.669207468977596 139.74939840598162 31.601</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a99639a-c262-41a4-a9fb-b7ff6222cca1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5a99639a-c262-41a4-a9fb-b7ff6222cca1_0">
											<gml:posList>35.66917958652816 139.74940707321565 28.596 35.6691829059411 139.74939752591482 31.792 35.66917958652816 139.74940707321565 31.792 35.66917958652816 139.74940707321565 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c94612e-55cd-4043-b714-7575b7fa9587">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c94612e-55cd-4043-b714-7575b7fa9587_0">
											<gml:posList>35.66917958652816 139.74940707321565 28.596 35.6691829059411 139.74939752591482 28.596 35.6691829059411 139.74939752591482 31.792 35.66917958652816 139.74940707321565 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7248dc60-c198-4195-825f-d540f750cedb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7248dc60-c198-4195-825f-d540f750cedb_0">
											<gml:posList>35.669081501609554 139.74941069958172 29.645 35.669078679273746 139.7494092113148 31.601 35.669078679273746 139.7494092113148 29.645 35.669081501609554 139.74941069958172 29.645</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-32d6ca3b-1d86-4252-9698-793f5e05014d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-32d6ca3b-1d86-4252-9698-793f5e05014d_0">
											<gml:posList>35.669081501609554 139.74941069958172 29.645 35.669081501609554 139.74941069958172 31.601 35.669078679273746 139.7494092113148 31.601 35.669081501609554 139.74941069958172 29.645</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b9c88d9-7d5f-4a1e-aa82-beab961853a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2b9c88d9-7d5f-4a1e-aa82-beab961853a5_0">
											<gml:posList>35.66907425190174 139.7494068741798 29.645 35.66907425190174 139.7494068741798 28.596 35.669078679273746 139.7494092113148 29.645 35.66907425190174 139.7494068741798 29.645</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5006f811-188d-45d2-bb85-4026f5b3801a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5006f811-188d-45d2-bb85-4026f5b3801a_0">
											<gml:posList>35.66907425190174 139.7494068741798 28.596 35.669093836929775 139.74941720385985 28.596 35.669081501609554 139.74941069958172 29.645 35.66907425190174 139.7494068741798 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe986ca0-6124-4434-8929-fb98a996312a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe986ca0-6124-4434-8929-fb98a996312a_0">
											<gml:posList>35.669078679273746 139.7494092113148 29.645 35.66907425190174 139.7494068741798 28.596 35.669081501609554 139.74941069958172 29.645 35.669078679273746 139.7494092113148 29.645</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97ab8ae9-7d39-4abf-966b-08c2f6340bb2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-97ab8ae9-7d39-4abf-966b-08c2f6340bb2_0">
											<gml:posList>35.669093836929775 139.74941720385985 28.596 35.669093836929775 139.74941720385985 29.645 35.669081501609554 139.74941069958172 29.645 35.669093836929775 139.74941720385985 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc19045f-7c2e-4edf-be1d-f002df96ef1f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dc19045f-7c2e-4edf-be1d-f002df96ef1f_0">
											<gml:posList>35.669207468977596 139.74939840598162 31.601 35.669196080670986 139.7494315230563 29.1 35.669196080670986 139.7494315230563 31.601 35.669207468977596 139.74939840598162 31.601</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29eea4ab-e2eb-4e93-8b97-85a361acd47b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29eea4ab-e2eb-4e93-8b97-85a361acd47b_0">
											<gml:posList>35.669207468977596 139.74939840598162 31.601 35.669207468977596 139.74939840598162 29.1 35.669196080670986 139.7494315230563 29.1 35.669207468977596 139.74939840598162 31.601</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bcb57169-c03c-422a-964c-614e49981a0e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bcb57169-c03c-422a-964c-614e49981a0e_0">
											<gml:posList>35.669178028555336 139.7494220202125 28.596 35.6691747720595 139.74943131338574 31.717 35.669178028555336 139.7494220202125 31.717 35.669178028555336 139.7494220202125 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-71ad891a-61ad-4421-acfb-0763409ff68e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-71ad891a-61ad-4421-acfb-0763409ff68e_0">
											<gml:posList>35.669178028555336 139.7494220202125 28.596 35.6691747720595 139.74943131338574 28.596 35.6691747720595 139.74943131338574 31.717 35.669178028555336 139.7494220202125 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d6aabfc-5da4-4325-801b-3e432d6f12bb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d6aabfc-5da4-4325-801b-3e432d6f12bb_0">
											<gml:posList>35.669196080670986 139.7494315230563 31.717 35.669196080670986 139.7494315230563 31.601 35.669178028555336 139.7494220202125 31.717 35.669196080670986 139.7494315230563 31.717</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-98585829-a203-4fb2-8f95-b2399eb7520a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-98585829-a203-4fb2-8f95-b2399eb7520a_0">
											<gml:posList>35.669178028555336 139.7494220202125 31.717 35.669196080670986 139.7494315230563 29.1 35.669178028555336 139.7494220202125 28.596 35.669178028555336 139.7494220202125 31.717</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78450a7f-3af0-4051-af03-f54d1bed39b6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78450a7f-3af0-4051-af03-f54d1bed39b6_0">
											<gml:posList>35.669196080670986 139.7494315230563 29.1 35.669196080670986 139.7494315230563 28.596 35.669178028555336 139.7494220202125 28.596 35.669196080670986 139.7494315230563 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7155305d-ad84-406c-8bc6-e8088a6c856e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7155305d-ad84-406c-8bc6-e8088a6c856e_0">
											<gml:posList>35.669178028555336 139.7494220202125 31.717 35.669196080670986 139.7494315230563 31.601 35.669196080670986 139.7494315230563 29.1 35.669178028555336 139.7494220202125 31.717</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e91e9ba1-fb18-4753-8ec3-53d807aaf8ef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e91e9ba1-fb18-4753-8ec3-53d807aaf8ef_0">
											<gml:posList>35.6691747720595 139.74943131338574 31.717 35.669196080670986 139.7494315230563 31.717 35.669178028555336 139.7494220202125 31.717 35.6691747720595 139.74943131338574 31.717</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60bf35da-2e6f-4ec9-8da0-68854ee5e465">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-60bf35da-2e6f-4ec9-8da0-68854ee5e465_0">
											<gml:posList>35.6691747720595 139.74943131338574 31.717 35.669192824174424 139.74944081623127 31.717 35.669196080670986 139.7494315230563 31.717 35.6691747720595 139.74943131338574 31.717</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec01e84f-534c-4d53-94d5-ed22d2b6a586">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ec01e84f-534c-4d53-94d5-ed22d2b6a586_0">
											<gml:posList>35.669210119539585 139.74946384029806 29.1 35.66922989140512 139.74940597118137 31.601 35.669210119539585 139.74946384029806 31.601 35.669210119539585 139.74946384029806 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0666ec33-3e5a-4823-a597-b46b1e1ba0ee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0666ec33-3e5a-4823-a597-b46b1e1ba0ee_0">
											<gml:posList>35.669210119539585 139.74946384029806 29.1 35.66922989140512 139.74940597118137 29.1 35.66922989140512 139.74940597118137 31.601 35.669210119539585 139.74946384029806 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e26dd824-9600-4050-ad65-b0440aa1ce15">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e26dd824-9600-4050-ad65-b0440aa1ce15_0">
											<gml:posList>35.669192824174424 139.74944081623127 31.717 35.6691747720595 139.74943131338574 31.717 35.669192824174424 139.74944081623127 31.601 35.669192824174424 139.74944081623127 31.717</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e28a39f3-09c8-4bb0-9d9d-e9468f8f86da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e28a39f3-09c8-4bb0-9d9d-e9468f8f86da_0">
											<gml:posList>35.669192824174424 139.74944081623127 31.601 35.6691747720595 139.74943131338574 31.717 35.669192824174424 139.74944081623127 29.1 35.669192824174424 139.74944081623127 31.601</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0867c2ce-6206-4172-9977-39d1acfde6a7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0867c2ce-6206-4172-9977-39d1acfde6a7_0">
											<gml:posList>35.669192824174424 139.74944081623127 29.1 35.6691747720595 139.74943131338574 28.596 35.669192824174424 139.74944081623127 28.596 35.669192824174424 139.74944081623127 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4f5ed318-9271-48ea-a3f2-dde4d3012e4e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4f5ed318-9271-48ea-a3f2-dde4d3012e4e_0">
											<gml:posList>35.669192824174424 139.74944081623127 29.1 35.6691747720595 139.74943131338574 31.717 35.6691747720595 139.74943131338574 28.596 35.669192824174424 139.74944081623127 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a0a639b-eaa0-438d-9f0c-40f2cdd32a88">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4a0a639b-eaa0-438d-9f0c-40f2cdd32a88_0">
											<gml:posList>35.669192824174424 139.74944081623127 31.601 35.669196080670986 139.7494315230563 31.717 35.669192824174424 139.74944081623127 31.717 35.669192824174424 139.74944081623127 31.601</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f7fc76b-0dd6-40fd-9b35-ced549f6e054">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f7fc76b-0dd6-40fd-9b35-ced549f6e054_0">
											<gml:posList>35.669192824174424 139.74944081623127 31.601 35.669196080670986 139.7494315230563 31.601 35.669196080670986 139.7494315230563 31.717 35.669192824174424 139.74944081623127 31.601</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ac584b6-7c93-4803-b861-fa4c70292b42">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2ac584b6-7c93-4803-b861-fa4c70292b42_0">
											<gml:posList>35.669192824174424 139.74944081623127 29.1 35.66918847871678 139.74945255173196 31.601 35.669192824174424 139.74944081623127 31.601 35.669192824174424 139.74944081623127 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7eb79ffe-e650-4285-b75c-69366a8458a7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7eb79ffe-e650-4285-b75c-69366a8458a7_0">
											<gml:posList>35.669192824174424 139.74944081623127 29.1 35.66918847871678 139.74945255173196 29.1 35.66918847871678 139.74945255173196 31.601 35.669192824174424 139.74944081623127 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d84c4dd8-7cb5-40c9-876f-eaa4e7e571e9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d84c4dd8-7cb5-40c9-876f-eaa4e7e571e9_0">
											<gml:posList>35.66918847871678 139.74945255173196 29.1 35.669210119539585 139.74946384029806 31.601 35.66918847871678 139.74945255173196 31.601 35.66918847871678 139.74945255173196 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c0a3094-3479-445f-923f-fc8c4c695472">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c0a3094-3479-445f-923f-fc8c4c695472_0">
											<gml:posList>35.66918847871678 139.74945255173196 29.1 35.669210119539585 139.74946384029806 29.1 35.669210119539585 139.74946384029806 31.601 35.66918847871678 139.74945255173196 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac26f7e1-aa37-4281-b715-1f2bf101b1ef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ac26f7e1-aa37-4281-b715-1f2bf101b1ef_0">
											<gml:posList>35.669157437111764 139.7494549812078 28.596 35.66917661627153 139.7494649578598 29.704 35.66917661627153 139.7494649578598 28.596 35.669157437111764 139.7494549812078 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c6c0f0ed-180f-414a-8ffb-92299ccdc57d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c6c0f0ed-180f-414a-8ffb-92299ccdc57d_0">
											<gml:posList>35.669157437111764 139.7494549812078 28.596 35.669157437111764 139.7494549812078 29.704 35.66917661627153 139.7494649578598 29.704 35.669157437111764 139.7494549812078 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de8d0f64-8bf3-46cb-8c24-5068dc55fbcc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de8d0f64-8bf3-46cb-8c24-5068dc55fbcc_0">
											<gml:posList>35.66915239028222 139.7494691586223 29.1 35.66915239028222 139.7494691586223 29.704 35.66915373070408 139.74946539050313 29.1 35.66915239028222 139.7494691586223 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-805e8ef2-fdf9-4e82-a959-1b3b8cd0eab4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-805e8ef2-fdf9-4e82-a959-1b3b8cd0eab4_0">
											<gml:posList>35.66915373070408 139.74946539050313 28.596 35.66915373070408 139.74946539050313 29.1 35.669157437111764 139.7494549812078 28.596 35.66915373070408 139.74946539050313 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4505cd6f-c41d-4015-bb06-55fb7ca8063a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4505cd6f-c41d-4015-bb06-55fb7ca8063a_0">
											<gml:posList>35.669157437111764 139.7494549812078 28.596 35.66915373070408 139.74946539050313 29.1 35.669157437111764 139.7494549812078 29.704 35.669157437111764 139.7494549812078 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7960e1fd-e9dc-4e10-8d47-1b45ad71e387">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7960e1fd-e9dc-4e10-8d47-1b45ad71e387_0">
											<gml:posList>35.66915373070408 139.74946539050313 29.1 35.66915239028222 139.7494691586223 29.704 35.669157437111764 139.7494549812078 29.704 35.66915373070408 139.74946539050313 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-586c766e-90c6-4c75-9d62-8a064f55fb07">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-586c766e-90c6-4c75-9d62-8a064f55fb07_0">
											<gml:posList>35.669157437111764 139.7494549812078 29.704 35.66917156944084 139.74947913527703 29.704 35.66917661627153 139.7494649578598 29.704 35.669157437111764 139.7494549812078 29.704</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8208da29-8993-4c8a-ab91-a4b39abded08">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8208da29-8993-4c8a-ab91-a4b39abded08_0">
											<gml:posList>35.669157437111764 139.7494549812078 29.704 35.66915239028222 139.7494691586223 29.704 35.66917156944084 139.74947913527703 29.704 35.669157437111764 139.7494549812078 29.704</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26e9ad1c-ef9a-49ca-8d07-0a0a1074fe91">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-26e9ad1c-ef9a-49ca-8d07-0a0a1074fe91_0">
											<gml:posList>35.669172909870696 139.74947537820327 29.1 35.66915373070408 139.74946539050313 28.596 35.669172909870696 139.74947537820327 28.596 35.669172909870696 139.74947537820327 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3dbd41dc-d1fc-4b64-8a94-c7c2fdc6e5f9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3dbd41dc-d1fc-4b64-8a94-c7c2fdc6e5f9_0">
											<gml:posList>35.669172909870696 139.74947537820327 29.1 35.66915373070408 139.74946539050313 29.1 35.66915373070408 139.74946539050313 28.596 35.669172909870696 139.74947537820327 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fd43c641-20c3-4f45-8827-0fc6be9de2dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fd43c641-20c3-4f45-8827-0fc6be9de2dc_0">
											<gml:posList>35.669172909870696 139.74947537820327 28.596 35.66917661627153 139.7494649578598 28.596 35.669172909870696 139.74947537820327 29.1 35.669172909870696 139.74947537820327 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c32e853-7735-4b38-adaa-888123c36971">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c32e853-7735-4b38-adaa-888123c36971_0">
											<gml:posList>35.66917156944084 139.74947913527703 29.1 35.669172909870696 139.74947537820327 29.1 35.66917156944084 139.74947913527703 29.704 35.66917156944084 139.74947913527703 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fbd63ac9-29a5-499c-b5ed-5f9b62868891">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fbd63ac9-29a5-499c-b5ed-5f9b62868891_0">
											<gml:posList>35.66917156944084 139.74947913527703 29.704 35.669172909870696 139.74947537820327 29.1 35.66917661627153 139.7494649578598 29.704 35.66917156944084 139.74947913527703 29.704</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb2e5be9-ea01-4f87-877d-04ce5f277377">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb2e5be9-ea01-4f87-877d-04ce5f277377_0">
											<gml:posList>35.669172909870696 139.74947537820327 29.1 35.66917661627153 139.7494649578598 28.596 35.66917661627153 139.7494649578598 29.704 35.669172909870696 139.74947537820327 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eb57d602-c19e-44b1-b32e-bb15ad45d72a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eb57d602-c19e-44b1-b32e-bb15ad45d72a_0">
											<gml:posList>35.66915239028222 139.7494691586223 29.1 35.66917156944084 139.74947913527703 29.704 35.66915239028222 139.7494691586223 29.704 35.66915239028222 139.7494691586223 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc73be2d-0de3-43b0-bea1-a21edf09793b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bc73be2d-0de3-43b0-bea1-a21edf09793b_0">
											<gml:posList>35.66915239028222 139.7494691586223 29.1 35.66917156944084 139.74947913527703 29.1 35.66917156944084 139.74947913527703 29.704 35.66915239028222 139.7494691586223 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4de84023-d0f4-42f6-a65a-dce174a30040">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4de84023-d0f4-42f6-a65a-dce174a30040_0">
											<gml:posList>35.669092429189085 139.74935026607088 28.596 35.66907964341006 139.7493440936574 30.116 35.669092429189085 139.74935026607088 30.116 35.669092429189085 139.74935026607088 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-746a5cca-6cc4-47f0-9398-763dbee5936d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-746a5cca-6cc4-47f0-9398-763dbee5936d_0">
											<gml:posList>35.669092429189085 139.74935026607088 28.596 35.66907964341006 139.7493440936574 28.596 35.66907964341006 139.7493440936574 30.116 35.669092429189085 139.74935026607088 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61ecc2fb-98fa-4da6-be3d-dcd0d80ade46">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-61ecc2fb-98fa-4da6-be3d-dcd0d80ade46_0">
											<gml:posList>35.66904860421044 139.7493499695453 29.1 35.66904860421044 139.7493499695453 29.754 35.669051949535735 139.74935173341373 29.1 35.66904860421044 139.7493499695453 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5bef6334-7e1e-49a7-9d2e-4590e102a308">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5bef6334-7e1e-49a7-9d2e-4590e102a308_0">
											<gml:posList>35.669051949535735 139.74935173341373 28.596 35.669051949535735 139.74935173341373 29.1 35.66905928039197 139.74935559186287 28.596 35.669051949535735 139.74935173341373 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-08910756-73a5-4692-b7ae-a3df6a17071c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-08910756-73a5-4692-b7ae-a3df6a17071c_0">
											<gml:posList>35.66905928039197 139.74935559186287 28.596 35.669051949535735 139.74935173341373 29.1 35.66905928039197 139.74935559186287 29.754 35.66905928039197 139.74935559186287 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe3848a0-dd01-455c-a31e-a18c0bb57339">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe3848a0-dd01-455c-a31e-a18c0bb57339_0">
											<gml:posList>35.669051949535735 139.74935173341373 29.1 35.66904860421044 139.7493499695453 29.754 35.66905928039197 139.74935559186287 29.754 35.669051949535735 139.74935173341373 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f47ad8c-d1cc-44c5-81ea-394e1ed53117">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f47ad8c-d1cc-44c5-81ea-394e1ed53117_0">
											<gml:posList>35.66907359929742 139.74936290041722 28.596 35.66907964341006 139.7493440936574 30.116 35.66907964341006 139.7493440936574 28.596 35.66907359929742 139.74936290041722 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43a6e82e-cf4c-4a9a-b8cf-d25f55b6ef62">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-43a6e82e-cf4c-4a9a-b8cf-d25f55b6ef62_0">
											<gml:posList>35.66907359929742 139.74936290041722 28.596 35.66907359929742 139.74936290041722 30.116 35.66907964341006 139.7493440936574 30.116 35.66907359929742 139.74936290041722 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-98e3e137-0ae4-40d9-b18c-1ab29ed64e5b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-98e3e137-0ae4-40d9-b18c-1ab29ed64e5b_0">
											<gml:posList>35.669092429189085 139.74935026607088 30.116 35.66907964341006 139.7493440936574 30.116 35.66907359929742 139.74936290041722 30.116 35.669092429189085 139.74935026607088 30.116</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-96cce50b-1526-453d-aca8-57a733418089">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-96cce50b-1526-453d-aca8-57a733418089_0">
											<gml:posList>35.6690863850755 139.74936907283322 30.116 35.669092429189085 139.74935026607088 30.116 35.66907359929742 139.74936290041722 30.116 35.6690863850755 139.74936907283322 30.116</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c10c294-8f0c-4219-97d1-97428c91be9e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8c10c294-8f0c-4219-97d1-97428c91be9e_0">
											<gml:posList>35.66920869242668 139.74939493622585 29.1 35.66919717752402 139.74938867409708 29.1 35.66920869242668 139.74939493622585 31.601 35.66920869242668 139.74939493622585 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-429a5f3a-0d70-4f39-a8ae-2ec02d7742c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-429a5f3a-0d70-4f39-a8ae-2ec02d7742c1_0">
											<gml:posList>35.66920869242668 139.74939493622585 31.601 35.66919717752402 139.74938867409708 29.1 35.66910324700893 139.74933926388616 31.601 35.66920869242668 139.74939493622585 31.601</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59708a57-5ee5-4a23-a1d4-b44c882e21f7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-59708a57-5ee5-4a23-a1d4-b44c882e21f7_0">
											<gml:posList>35.66910324700893 139.74933926388616 31.601 35.66919717752402 139.74938867409708 29.1 35.66910324700893 139.74933926388616 28.596 35.66910324700893 139.74933926388616 31.601</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8aed170c-9585-49bf-ad94-1a9605bc001b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8aed170c-9585-49bf-ad94-1a9605bc001b_0">
											<gml:posList>35.66919717752402 139.74938867409708 29.1 35.66919717752402 139.74938867409708 28.596 35.66910324700893 139.74933926388616 28.596 35.66919717752402 139.74938867409708 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f310366d-a528-4249-a531-36eab307fafb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f310366d-a528-4249-a531-36eab307fafb_0">
											<gml:posList>35.66910495386243 139.74934393459193 28.596 35.66919592712634 139.7493922764338 28.596 35.66919592712634 139.7493922764338 29.1 35.66910495386243 139.74934393459193 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-892ba796-cba5-4de2-8c57-4123203466c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-892ba796-cba5-4de2-8c57-4123203466c6_0">
											<gml:posList>35.66910495386243 139.74934393459193 28.596 35.66919592712634 139.7493922764338 29.1 35.66910495386243 139.74934393459193 31.601 35.66910495386243 139.74934393459193 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e7f14d56-3c37-4f8c-bf91-0b9acacccd32">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e7f14d56-3c37-4f8c-bf91-0b9acacccd32_0">
											<gml:posList>35.66919592712634 139.7493922764338 29.1 35.669207468977596 139.74939840598162 31.601 35.66910495386243 139.74934393459193 31.601 35.66919592712634 139.7493922764338 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-17a2442f-4078-423e-b312-4562e22840c0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-17a2442f-4078-423e-b312-4562e22840c0_0">
											<gml:posList>35.66919592712634 139.7493922764338 29.1 35.669207468977596 139.74939840598162 29.1 35.669207468977596 139.74939840598162 31.601 35.66919592712634 139.7493922764338 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8418d863-bf45-4429-8099-5933a6abc527">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66903711679657 139.74938313084928 29.1 35.669051949535735 139.74935173341373 29.1 35.66904046212139 139.74938489471884 29.1 35.66903711679657 139.74938313084928 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-045bc6bd-0083-4a7b-8c1f-f29472cf743c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66903711679657 139.74938313084928 29.1 35.66904860421044 139.7493499695453 29.1 35.669051949535735 139.74935173341373 29.1 35.66903711679657 139.74938313084928 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57166aab-819d-4f43-9e7c-166a1c4afb0f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66904046212139 139.74938489471884 28.596 35.66905928039197 139.74935559186287 28.596 35.66904779297658 139.74938875317045 28.596 35.66904046212139 139.74938489471884 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14b7a227-fe7b-4982-aa6a-f76db66ea836">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66904046212139 139.74938489471884 28.596 35.669051949535735 139.74935173341373 28.596 35.66905928039197 139.74935559186287 28.596 35.66904046212139 139.74938489471884 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-41a7a6ec-92f8-4e5b-9929-3bbbdafd5329">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669092429189085 139.74935026607088 28.596 35.6690863850755 139.74936907283322 28.596 35.66907359929742 139.74936290041722 28.596 35.669092429189085 139.74935026607088 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-abf5ba02-d619-4f6e-8994-8fc429d6fd3e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66907964341006 139.7493440936574 28.596 35.669092429189085 139.74935026607088 28.596 35.66907359929742 139.74936290041722 28.596 35.66907964341006 139.7493440936574 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8bf2722-9184-40a0-819a-aea781b7593c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66907425190174 139.7494068741798 28.596 35.66909528331063 139.7493714826074 28.596 35.669093836929775 139.74941720385985 28.596 35.66907425190174 139.7494068741798 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c7b2a94-178d-41da-9021-1c6064db9a09">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669093836929775 139.74941720385985 28.596 35.66909528331063 139.7493714826074 28.596 35.66910761863295 139.7493779868806 28.596 35.669093836929775 139.74941720385985 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa689a26-ffa6-46d1-b731-6324dfa1d59d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66919592712634 139.7493922764338 28.596 35.66910495386243 139.74934393459193 28.596 35.66919717752402 139.74938867409708 28.596 35.66919592712634 139.7493922764338 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb5da5f2-5ef2-4204-acde-8885a345edbf">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66908802458788 139.74936765721782 28.596 35.66909246097436 139.7493699943416 28.596 35.66907425190174 139.7494068741798 28.596 35.66908802458788 139.74936765721782 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4be33851-d9d3-4dbc-8e67-9bab8b9bfce0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66910495386243 139.74934393459193 28.596 35.66910324700893 139.74933926388616 28.596 35.66919717752402 139.74938867409708 28.596 35.66910495386243 139.74934393459193 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6528341-8f1e-43d8-9023-279da4edb52e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66909246097436 139.7493699943416 28.596 35.66910495386243 139.74934393459193 28.596 35.66909528331063 139.7493714826074 28.596 35.66909246097436 139.7493699943416 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-68328e96-7d56-433a-92f4-9b40885d27a5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66909246097436 139.7493699943416 28.596 35.66910324700893 139.74933926388616 28.596 35.66910495386243 139.74934393459193 28.596 35.66909246097436 139.7493699943416 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c913414-e60a-4891-803c-5222ab1e35bc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66907425190174 139.7494068741798 28.596 35.66909246097436 139.7493699943416 28.596 35.66909528331063 139.7493714826074 28.596 35.66907425190174 139.7494068741798 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f5a3c24-24d1-4e54-9367-3d725d70690f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6691829059411 139.74939752591482 28.596 35.66917958652816 139.74940707321565 28.596 35.66912106609668 139.74937651471672 28.596 35.6691829059411 139.74939752591482 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa42a356-09df-4f5d-9793-0cf97ffeae98">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669124376501216 139.7493669784771 28.596 35.6691829059411 139.74939752591482 28.596 35.66912106609668 139.74937651471672 28.596 35.669124376501216 139.7493669784771 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9aa7a56d-f410-4554-9edf-d8daae4646b6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66915373070408 139.74946539050313 29.1 35.66917156944084 139.74947913527703 29.1 35.66915239028222 139.7494691586223 29.1 35.66915373070408 139.74946539050313 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f955c66f-4ead-4f67-94b0-52dd57c8657a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66915373070408 139.74946539050313 29.1 35.669172909870696 139.74947537820327 29.1 35.66917156944084 139.74947913527703 29.1 35.66915373070408 139.74946539050313 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc2b32cf-7fdb-4963-b5d4-48e02bec6662">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669172909870696 139.74947537820327 28.596 35.669157437111764 139.7494549812078 28.596 35.66917661627153 139.7494649578598 28.596 35.669172909870696 139.74947537820327 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca540bd6-dfd1-40e2-9e7f-3aa50ce88539">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669172909870696 139.74947537820327 28.596 35.66915373070408 139.74946539050313 28.596 35.669157437111764 139.7494549812078 28.596 35.669172909870696 139.74947537820327 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f63c1be2-44b7-4624-8720-d5bcaae2a366">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6691747720595 139.74943131338574 28.596 35.669196080670986 139.7494315230563 28.596 35.669192824174424 139.74944081623127 28.596 35.6691747720595 139.74943131338574 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f853cc4f-8039-4de5-9a56-6a86ffc5e852">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6691747720595 139.74943131338574 28.596 35.669178028555336 139.7494220202125 28.596 35.669196080670986 139.7494315230563 28.596 35.6691747720595 139.74943131338574 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9fc279e5-1eb8-422e-87f3-ba88c7ebe072">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66920869242668 139.74939493622585 29.1 35.66919592712634 139.7493922764338 29.1 35.66919717752402 139.74938867409708 29.1 35.66920869242668 139.74939493622585 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-be3d5971-91e7-4ff4-988e-701e2fac11f1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66920869242668 139.74939493622585 29.1 35.669207468977596 139.74939840598162 29.1 35.66919592712634 139.7493922764338 29.1 35.66920869242668 139.74939493622585 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37652308-059c-427d-a5d9-a1508c272205">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669192824174424 139.74944081623127 29.1 35.669210119539585 139.74946384029806 29.1 35.66918847871678 139.74945255173196 29.1 35.669192824174424 139.74944081623127 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-765754a9-7537-4edd-812b-c70a1130679f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66922989140512 139.74940597118137 29.1 35.669210119539585 139.74946384029806 29.1 35.669196080670986 139.7494315230563 29.1 35.66922989140512 139.74940597118137 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c596bdd0-a100-42ad-ae4c-fc5d7f87078a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669207468977596 139.74939840598162 29.1 35.66920869242668 139.74939493622585 29.1 35.66922989140512 139.74940597118137 29.1 35.669207468977596 139.74939840598162 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e194d433-0d0a-479a-8948-616e13e74dca">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669207468977596 139.74939840598162 29.1 35.66922989140512 139.74940597118137 29.1 35.669196080670986 139.7494315230563 29.1 35.669207468977596 139.74939840598162 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d4f9bbd-77cb-4558-9ba2-979445d01581">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669210119539585 139.74946384029806 29.1 35.669192824174424 139.74944081623127 29.1 35.669196080670986 139.7494315230563 29.1 35.669210119539585 139.74946384029806 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_3aab38b9-c395-4e0d-bee3-a5f81c4ea9bf_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da06b4f2-926f-4fba-b1bf-249e77f7e0af">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66916050704782 139.74941079362722 28.596 35.669152608359965 139.7494328498925 28.596 35.66911897452791 139.74941475845839 28.596 35.66912686419878 139.74939270221006 28.596 35.66916050704782 139.74941079362722 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9eb735af-6df3-4dcf-94c7-aacabe9c0b80">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9eb735af-6df3-4dcf-94c7-aacabe9c0b80_0">
											<gml:posList>35.66912686419878 139.74939270221006 31.567 35.66912686419878 139.74939270221006 28.596 35.66911897452791 139.74941475845839 28.596 35.66911897452791 139.74941475845839 31.567 35.66912686419878 139.74939270221006 31.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40827a3f-491b-45e1-acee-12376e5f9054">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40827a3f-491b-45e1-acee-12376e5f9054_0">
											<gml:posList>35.66911897452791 139.74941475845839 31.567 35.66911897452791 139.74941475845839 28.596 35.669152608359965 139.7494328498925 28.596 35.669152608359965 139.7494328498925 31.567 35.66911897452791 139.74941475845839 31.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-012b861a-9168-4afc-ab0d-b09f9685f9ae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-012b861a-9168-4afc-ab0d-b09f9685f9ae_0">
											<gml:posList>35.66912686419878 139.74939270221006 31.567 35.66911897452791 139.74941475845839 31.567 35.669152608359965 139.7494328498925 31.567 35.66916050704782 139.74941079362722 31.567 35.66912686419878 139.74939270221006 31.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0f0a96e-e254-4c57-ad0b-ac8bc0388bd9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d0f0a96e-e254-4c57-ad0b-ac8bc0388bd9_0">
											<gml:posList>35.66916050704782 139.74941079362722 31.567 35.66916050704782 139.74941079362722 28.596 35.66912686419878 139.74939270221006 28.596 35.66912686419878 139.74939270221006 31.567 35.66916050704782 139.74941079362722 31.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a5ef539-407f-4274-9b04-db384465da8b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4a5ef539-407f-4274-9b04-db384465da8b_0">
											<gml:posList>35.669152608359965 139.7494328498925 31.567 35.669152608359965 139.7494328498925 28.596 35.66916050704782 139.74941079362722 28.596 35.66916050704782 139.74941079362722 31.567 35.669152608359965 139.7494328498925 31.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-94a44a18-f5ce-495a-8683-1aebbc5f0d87">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-94a44a18-f5ce-495a-8683-1aebbc5f0d87">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-94a44a18-f5ce-495a-8683-1aebbc5f0d87">
											<gml:posList>35.66906012842534 139.74931789070897 6.37 35.669065606762906 139.74930208907546 6.37 35.669206136802 139.7493752105692 6.37 35.669200883343834 139.74939036027027 6.37 35.66923027877208 139.74940565043894 6.37 35.669210119539585 139.74946384029806 6.37 35.66919246425363 139.749454657367 6.37 35.66918184938139 139.7494852882473 6.37 35.669028948079024 139.74940572862357 6.37 35.669059488219524 139.74931755999745 6.37 35.66906012842534 139.74931789070897 6.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-32c110e2-e355-4e0e-9166-0a17f758e620">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-32c110e2-e355-4e0e-9166-0a17f758e620">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-32c110e2-e355-4e0e-9166-0a17f758e620">
											<gml:posList>35.669028948079024 139.74940572862357 29.1 35.66903412918581 139.74940316051104 29.1 35.66906159284155 139.74932389824133 29.1 35.669059488219524 139.74931755999745 29.1 35.669028948079024 139.74940572862357 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3dfa7edb-9992-4f9a-a644-ad41dfff8078">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3dfa7edb-9992-4f9a-a644-ad41dfff8078">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3dfa7edb-9992-4f9a-a644-ad41dfff8078">
											<gml:posList>35.66906012842534 139.74931789070897 29.1 35.669059488219524 139.74931755999745 29.1 35.66906159284155 139.74932389824133 29.1 35.66906223304735 139.7493242289529 29.1 35.66906012842534 139.74931789070897 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dffba6a4-5bb2-4cad-8208-9ed12df4dbbc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dffba6a4-5bb2-4cad-8208-9ed12df4dbbc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dffba6a4-5bb2-4cad-8208-9ed12df4dbbc">
											<gml:posList>35.66906012842534 139.74931789070897 29.1 35.66906223304735 139.7493242289529 29.1 35.66906770238744 139.74930844942097 29.1 35.669065606762906 139.74930208907546 29.1 35.66906012842534 139.74931789070897 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fa1d3587-866b-49ff-8fb7-4dd04e051a51">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa1d3587-866b-49ff-8fb7-4dd04e051a51">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa1d3587-866b-49ff-8fb7-4dd04e051a51">
											<gml:posList>35.66918184938139 139.7494852882473 29.1 35.66917975377392 139.74947893893417 29.1 35.66903412918581 139.74940316051104 29.1 35.669028948079024 139.74940572862357 29.1 35.66918184938139 139.7494852882473 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-827b62ea-f2d3-4043-9652-9c3ac865fae2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-827b62ea-f2d3-4043-9652-9c3ac865fae2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-827b62ea-f2d3-4043-9652-9c3ac865fae2">
											<gml:posList>35.66919570223749 139.749392928389 28.596 35.66920095569598 139.74937777868908 28.596 35.66906770238744 139.74930844942097 28.596 35.66906223304735 139.7493242289529 28.596 35.66906159284155 139.74932389824133 28.596 35.66903412918581 139.74940316051104 28.596 35.66917975377392 139.74947893893417 28.596 35.66918883039831 139.7494527612399 28.596 35.6692074423676 139.749399024591 28.596 35.66919570223749 139.749392928389 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-788abaaf-5251-46c5-a95b-db2485d5135c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-788abaaf-5251-46c5-a95b-db2485d5135c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-788abaaf-5251-46c5-a95b-db2485d5135c">
											<gml:posList>35.669065606762906 139.74930208907546 29.1 35.66906770238744 139.74930844942097 29.1 35.66920095569598 139.74937777868908 29.1 35.669206136802 139.7493752105692 29.1 35.669065606762906 139.74930208907546 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b33ede9f-b0b4-4717-a807-0ab36e6364ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b33ede9f-b0b4-4717-a807-0ab36e6364ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b33ede9f-b0b4-4717-a807-0ab36e6364ec">
											<gml:posList>35.66919246425363 139.749454657367 29.1 35.66918883039831 139.7494527612399 29.1 35.66917975377392 139.74947893893417 29.1 35.66918184938139 139.7494852882473 29.1 35.66919246425363 139.749454657367 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f4b38ef9-0c84-4787-af94-87c58c85cae3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4b38ef9-0c84-4787-af94-87c58c85cae3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4b38ef9-0c84-4787-af94-87c58c85cae3">
											<gml:posList>35.66919246425363 139.749454657367 29.1 35.669212623481776 139.7493964675184 29.1 35.6692074423676 139.749399024591 29.1 35.66918883039831 139.7494527612399 29.1 35.66919246425363 139.749454657367 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4443c6a8-d000-4cf2-85cc-05c84ee7c4c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4443c6a8-d000-4cf2-85cc-05c84ee7c4c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4443c6a8-d000-4cf2-85cc-05c84ee7c4c9">
											<gml:posList>35.669200883343834 139.74939036027027 29.1 35.669206136802 139.7493752105692 29.1 35.66920095569598 139.74937777868908 29.1 35.66919570223749 139.749392928389 29.1 35.669200883343834 139.74939036027027 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-29b5de30-b45f-4453-8d87-142a8994774d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-29b5de30-b45f-4453-8d87-142a8994774d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-29b5de30-b45f-4453-8d87-142a8994774d">
											<gml:posList>35.669200883343834 139.74939036027027 29.1 35.66919570223749 139.749392928389 29.1 35.6692074423676 139.749399024591 29.1 35.669212623481776 139.7493964675184 29.1 35.669200883343834 139.74939036027027 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a3270789-b37d-4f44-805b-60b23e9227ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a3270789-b37d-4f44-805b-60b23e9227ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a3270789-b37d-4f44-805b-60b23e9227ee">
											<gml:posList>35.669210119539585 139.74946384029806 29.1 35.66923027877208 139.74940565043894 29.1 35.669212623481776 139.7493964675184 29.1 35.66919246425363 139.749454657367 29.1 35.669210119539585 139.74946384029806 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f55d2b32-f64f-4c5d-981a-7c89f304129d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f55d2b32-f64f-4c5d-981a-7c89f304129d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f55d2b32-f64f-4c5d-981a-7c89f304129d">
											<gml:posList>35.669059488219524 139.74931755999745 6.37 35.669028948079024 139.74940572862357 6.37 35.669028948079024 139.74940572862357 29.1 35.669059488219524 139.74931755999745 29.1 35.669059488219524 139.74931755999745 6.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cb1319a9-8595-4535-8c9b-7c705b1f35f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb1319a9-8595-4535-8c9b-7c705b1f35f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb1319a9-8595-4535-8c9b-7c705b1f35f9">
											<gml:posList>35.66903412918581 139.74940316051104 29.1 35.66903412918581 139.74940316051104 28.596 35.66906159284155 139.74932389824133 28.596 35.66906159284155 139.74932389824133 29.1 35.66903412918581 139.74940316051104 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e26b585d-678c-454b-bee0-630fdd16e460">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e26b585d-678c-454b-bee0-630fdd16e460">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e26b585d-678c-454b-bee0-630fdd16e460">
											<gml:posList>35.66906012842534 139.74931789070897 6.37 35.669059488219524 139.74931755999745 6.37 35.669059488219524 139.74931755999745 29.1 35.66906012842534 139.74931789070897 29.1 35.66906012842534 139.74931789070897 6.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-64445d56-d1bc-4e83-a04a-616298e8b5d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-64445d56-d1bc-4e83-a04a-616298e8b5d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-64445d56-d1bc-4e83-a04a-616298e8b5d4">
											<gml:posList>35.66906159284155 139.74932389824133 29.1 35.66906159284155 139.74932389824133 28.596 35.66906223304735 139.7493242289529 28.596 35.66906223304735 139.7493242289529 29.1 35.66906159284155 139.74932389824133 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-79ec436a-3481-4294-bb17-29f671ec72c5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79ec436a-3481-4294-bb17-29f671ec72c5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79ec436a-3481-4294-bb17-29f671ec72c5">
											<gml:posList>35.669065606762906 139.74930208907546 6.37 35.66906012842534 139.74931789070897 6.37 35.66906012842534 139.74931789070897 29.1 35.669065606762906 139.74930208907546 29.1 35.669065606762906 139.74930208907546 6.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-11cb8066-7885-4144-a66c-087cbd6cb3f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11cb8066-7885-4144-a66c-087cbd6cb3f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11cb8066-7885-4144-a66c-087cbd6cb3f0">
											<gml:posList>35.66906223304735 139.7493242289529 29.1 35.66906223304735 139.7493242289529 28.596 35.66906770238744 139.74930844942097 28.596 35.66906770238744 139.74930844942097 29.1 35.66906223304735 139.7493242289529 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-645bdf9a-eba1-4731-ac3e-bf46fd860bf4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-645bdf9a-eba1-4731-ac3e-bf46fd860bf4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-645bdf9a-eba1-4731-ac3e-bf46fd860bf4">
											<gml:posList>35.66918184938139 139.7494852882473 29.1 35.669028948079024 139.74940572862357 29.1 35.669028948079024 139.74940572862357 6.37 35.66918184938139 139.7494852882473 6.37 35.66918184938139 139.7494852882473 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c366cb4e-3886-48a6-9706-da66a18a304d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c366cb4e-3886-48a6-9706-da66a18a304d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c366cb4e-3886-48a6-9706-da66a18a304d">
											<gml:posList>35.66917975377392 139.74947893893417 29.1 35.66917975377392 139.74947893893417 28.596 35.66903412918581 139.74940316051104 28.596 35.66903412918581 139.74940316051104 29.1 35.66917975377392 139.74947893893417 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8731caad-a160-4ba6-b4a4-3912549168c0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8731caad-a160-4ba6-b4a4-3912549168c0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8731caad-a160-4ba6-b4a4-3912549168c0">
											<gml:posList>35.66906770238744 139.74930844942097 29.1 35.66906770238744 139.74930844942097 28.596 35.66920095569598 139.74937777868908 28.596 35.66920095569598 139.74937777868908 29.1 35.66906770238744 139.74930844942097 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4cca8909-ff46-4621-8b7a-bbf34157a6f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4cca8909-ff46-4621-8b7a-bbf34157a6f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4cca8909-ff46-4621-8b7a-bbf34157a6f2">
											<gml:posList>35.669206136802 139.7493752105692 6.37 35.669065606762906 139.74930208907546 6.37 35.669065606762906 139.74930208907546 29.1 35.669206136802 139.7493752105692 29.1 35.669206136802 139.7493752105692 6.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3fce2d44-c9bf-4c5d-947b-074ae1805981">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3fce2d44-c9bf-4c5d-947b-074ae1805981">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3fce2d44-c9bf-4c5d-947b-074ae1805981">
											<gml:posList>35.66918883039831 139.7494527612399 29.1 35.66918883039831 139.7494527612399 28.596 35.66917975377392 139.74947893893417 28.596 35.66917975377392 139.74947893893417 29.1 35.66918883039831 139.7494527612399 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b753ba98-6272-46b8-833d-b9b15d4ece02">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b753ba98-6272-46b8-833d-b9b15d4ece02">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b753ba98-6272-46b8-833d-b9b15d4ece02">
											<gml:posList>35.66918184938139 139.7494852882473 6.37 35.66919246425363 139.749454657367 6.37 35.66919246425363 139.749454657367 29.1 35.66918184938139 139.7494852882473 29.1 35.66918184938139 139.7494852882473 6.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-853f9cac-88bf-45ef-87fa-dbca6019a41b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-853f9cac-88bf-45ef-87fa-dbca6019a41b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-853f9cac-88bf-45ef-87fa-dbca6019a41b">
											<gml:posList>35.6692074423676 139.749399024591 29.1 35.6692074423676 139.749399024591 28.596 35.66918883039831 139.7494527612399 28.596 35.66918883039831 139.7494527612399 29.1 35.6692074423676 139.749399024591 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8137fd51-df48-48b8-9ed9-88dfaa8fe4c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8137fd51-df48-48b8-9ed9-88dfaa8fe4c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8137fd51-df48-48b8-9ed9-88dfaa8fe4c4">
											<gml:posList>35.66920095569598 139.74937777868908 29.1 35.66920095569598 139.74937777868908 28.596 35.66919570223749 139.749392928389 28.596 35.66919570223749 139.749392928389 29.1 35.66920095569598 139.74937777868908 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2d9feeeb-2a56-4107-bf48-cc9fc41bb812">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d9feeeb-2a56-4107-bf48-cc9fc41bb812">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d9feeeb-2a56-4107-bf48-cc9fc41bb812">
											<gml:posList>35.66919246425363 139.749454657367 6.37 35.669210119539585 139.74946384029806 6.37 35.669210119539585 139.74946384029806 29.1 35.66919246425363 139.749454657367 29.1 35.66919246425363 139.749454657367 6.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-38acaaaf-9ec3-44bb-a28b-dc5868ecde5c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38acaaaf-9ec3-44bb-a28b-dc5868ecde5c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38acaaaf-9ec3-44bb-a28b-dc5868ecde5c">
											<gml:posList>35.66919570223749 139.749392928389 29.1 35.66919570223749 139.749392928389 28.596 35.6692074423676 139.749399024591 28.596 35.6692074423676 139.749399024591 29.1 35.66919570223749 139.749392928389 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eed627fa-ad40-4710-b29c-d06b524d678f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eed627fa-ad40-4710-b29c-d06b524d678f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eed627fa-ad40-4710-b29c-d06b524d678f">
											<gml:posList>35.669200883343834 139.74939036027027 6.37 35.669206136802 139.7493752105692 6.37 35.669206136802 139.7493752105692 29.1 35.669200883343834 139.74939036027027 29.1 35.669200883343834 139.74939036027027 6.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-03611d27-b1f3-4530-a694-b86aeacac29b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03611d27-b1f3-4530-a694-b86aeacac29b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03611d27-b1f3-4530-a694-b86aeacac29b">
											<gml:posList>35.66923027877208 139.74940565043894 6.37 35.669200883343834 139.74939036027027 6.37 35.669200883343834 139.74939036027027 29.1 35.669212623481776 139.7493964675184 29.1 35.66923027877208 139.74940565043894 29.1 35.66923027877208 139.74940565043894 6.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7a9813ff-1d34-4f1c-8f2e-84620f75ff83">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a9813ff-1d34-4f1c-8f2e-84620f75ff83">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a9813ff-1d34-4f1c-8f2e-84620f75ff83">
											<gml:posList>35.669210119539585 139.74946384029806 6.37 35.66923027877208 139.74940565043894 6.37 35.66923027877208 139.74940565043894 29.1 35.669210119539585 139.74946384029806 29.1 35.669210119539585 139.74946384029806 6.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5318</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">193.17625</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>