<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_3af387f3-0d9e-47c5-87e7-5d5a4cd570e8">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>霞が関三丁目南地区</gen:value>
			</gen:stringAttribute>
			<bldg:measuredHeight uom="m">14.7</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67079457607033 139.7469460195986 0 35.670807169668784 139.74694799436682 0 35.6708087004747 139.74693330111305 0 35.67081512798092 139.74693429940174 0 35.67082483767009 139.74684905552306 0 35.67076008476183 139.74683891857777 0 35.67075274458712 139.74691006474177 0 35.67069856592295 139.74690150702452 0 35.67069614894543 139.74692481733067 0 35.67067866033944 139.74692207460333 0 35.670677783018846 139.74693047073768 0 35.67075878895609 139.74694239078238 0 35.67075834133691 139.74694666618748 0 35.67079392253005 139.7469522393793 0 35.67079457607033 139.7469460195986 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67079457607033 139.7469460195986 9.09 35.67079392253005 139.7469522393793 9.09 35.67075834133691 139.74694666618748 9.09 35.67075878895609 139.74694239078238 9.09 35.670677783018846 139.74693047073768 9.09 35.67067866033944 139.74692207460333 9.09 35.67069614894543 139.74692481733067 9.09 35.67069856592295 139.74690150702452 9.09 35.67075274458712 139.74691006474177 9.09 35.67076008476183 139.74683891857777 9.09 35.67082483767009 139.74684905552306 9.09 35.67081512798092 139.74693429940174 9.09 35.6708087004747 139.74693330111305 9.09 35.670807169668784 139.74694799436682 9.09 35.67079457607033 139.7469460195986 9.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67079457607033 139.7469460195986 9.09 35.670807169668784 139.74694799436682 9.09 35.670807169668784 139.74694799436682 23.79 35.67079457607033 139.7469460195986 23.79 35.67079457607033 139.7469460195986 9.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670807169668784 139.74694799436682 9.09 35.6708087004747 139.74693330111305 9.09 35.6708087004747 139.74693330111305 23.79 35.670807169668784 139.74694799436682 23.79 35.670807169668784 139.74694799436682 9.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6708087004747 139.74693330111305 9.09 35.67081512798092 139.74693429940174 9.09 35.67081512798092 139.74693429940174 23.79 35.6708087004747 139.74693330111305 23.79 35.6708087004747 139.74693330111305 9.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67081512798092 139.74693429940174 9.09 35.67082483767009 139.74684905552306 9.09 35.67082483767009 139.74684905552306 23.79 35.67081512798092 139.74693429940174 23.79 35.67081512798092 139.74693429940174 9.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67082483767009 139.74684905552306 9.09 35.67076008476183 139.74683891857777 9.09 35.67076008476183 139.74683891857777 23.79 35.67082483767009 139.74684905552306 23.79 35.67082483767009 139.74684905552306 9.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67076008476183 139.74683891857777 9.09 35.67075274458712 139.74691006474177 9.09 35.67075274458712 139.74691006474177 23.79 35.67076008476183 139.74683891857777 23.79 35.67076008476183 139.74683891857777 9.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67075274458712 139.74691006474177 9.09 35.67069856592295 139.74690150702452 9.09 35.67069856592295 139.74690150702452 23.79 35.67075274458712 139.74691006474177 23.79 35.67075274458712 139.74691006474177 9.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67069856592295 139.74690150702452 9.09 35.67069614894543 139.74692481733067 9.09 35.67069614894543 139.74692481733067 23.79 35.67069856592295 139.74690150702452 23.79 35.67069856592295 139.74690150702452 9.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67069614894543 139.74692481733067 9.09 35.67067866033944 139.74692207460333 9.09 35.67067866033944 139.74692207460333 23.79 35.67069614894543 139.74692481733067 23.79 35.67069614894543 139.74692481733067 9.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67067866033944 139.74692207460333 9.09 35.670677783018846 139.74693047073768 9.09 35.670677783018846 139.74693047073768 23.79 35.67067866033944 139.74692207460333 23.79 35.67067866033944 139.74692207460333 9.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670677783018846 139.74693047073768 9.09 35.67075878895609 139.74694239078238 9.09 35.67075878895609 139.74694239078238 23.79 35.670677783018846 139.74693047073768 23.79 35.670677783018846 139.74693047073768 9.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67075878895609 139.74694239078238 9.09 35.67075834133691 139.74694666618748 9.09 35.67075834133691 139.74694666618748 23.79 35.67075878895609 139.74694239078238 23.79 35.67075878895609 139.74694239078238 9.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67075834133691 139.74694666618748 9.09 35.67079392253005 139.7469522393793 9.09 35.67079392253005 139.7469522393793 23.79 35.67075834133691 139.74694666618748 23.79 35.67075834133691 139.74694666618748 9.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67079392253005 139.7469522393793 9.09 35.67079457607033 139.7469460195986 9.09 35.67079457607033 139.7469460195986 23.79 35.67079392253005 139.7469522393793 23.79 35.67079392253005 139.7469522393793 9.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67079457607033 139.7469460195986 23.79 35.670807169668784 139.74694799436682 23.79 35.6708087004747 139.74693330111305 23.79 35.67081512798092 139.74693429940174 23.79 35.67082483767009 139.74684905552306 23.79 35.67076008476183 139.74683891857777 23.79 35.67075274458712 139.74691006474177 23.79 35.67069856592295 139.74690150702452 23.79 35.67069614894543 139.74692481733067 23.79 35.67067866033944 139.74692207460333 23.79 35.670677783018846 139.74693047073768 23.79 35.67075878895609 139.74694239078238 23.79 35.67075834133691 139.74694666618748 23.79 35.67079392253005 139.7469522393793 23.79 35.67079457607033 139.7469460195986 23.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-7b9354d7-0cdc-47d7-be15-afca3794739a"/>
							<gml:surfaceMember xlink:href="#poly-e1cfe4c7-f9cd-4bf7-9937-46692f7f0747"/>
							<gml:surfaceMember xlink:href="#poly-1d095949-f454-43ba-ac1c-6f0da040e2db"/>
							<gml:surfaceMember xlink:href="#poly-55d7523c-55b7-4dc5-9e72-c17ff48d09e3"/>
							<gml:surfaceMember xlink:href="#poly-02d0fdd1-1440-4c30-aca0-dd8158f48a7b"/>
							<gml:surfaceMember xlink:href="#poly-a35b8d27-9beb-4d4b-92ef-ecf41d8bd164"/>
							<gml:surfaceMember xlink:href="#poly-27fc166b-e804-40ec-899a-e96935fdb082"/>
							<gml:surfaceMember xlink:href="#poly-f6775f8e-5f58-4572-a4ad-de1223e59876"/>
							<gml:surfaceMember xlink:href="#poly-a69e3a54-9dc5-42e2-aed1-c634713b0c35"/>
							<gml:surfaceMember xlink:href="#poly-18a47306-e9e9-4a92-b4c2-0fe317011bb6"/>
							<gml:surfaceMember xlink:href="#poly-e10c216a-27f9-4d13-91d8-8b02d2cf000f"/>
							<gml:surfaceMember xlink:href="#poly-e68de8f2-6d3a-49ad-8dde-ec0b34142016"/>
							<gml:surfaceMember xlink:href="#poly-30050272-e4cb-44fd-9553-2b7593ec0a22"/>
							<gml:surfaceMember xlink:href="#poly-496d6faa-e6e3-439a-86fb-5c3562bc56ef"/>
							<gml:surfaceMember xlink:href="#poly-180540f7-c71f-403f-beeb-9a5acecad88a"/>
							<gml:surfaceMember xlink:href="#poly-9e505ae5-51c7-4e26-9ec9-ec85650fa097"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-7b9354d7-0cdc-47d7-be15-afca3794739a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b9354d7-0cdc-47d7-be15-afca3794739a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b9354d7-0cdc-47d7-be15-afca3794739a">
											<gml:posList>35.67079457607033 139.74694601959862 9.09 35.670793922530066 139.7469522393793 9.09 35.67075834133691 139.74694666618748 9.09 35.67075878895609 139.74694239078235 9.09 35.67067778301881 139.74693047073765 9.09 35.67067866033944 139.7469220746033 9.09 35.670696148945424 139.74692481733067 9.09 35.67069856592294 139.74690150702452 9.09 35.670752744587105 139.74691006474174 9.09 35.67076008476181 139.74683891857777 9.09 35.6708248376701 139.74684905552303 9.09 35.67081512798092 139.74693429940172 9.09 35.6708087004747 139.74693330111305 9.09 35.670807169668755 139.74694799436682 9.09 35.67079457607033 139.74694601959862 9.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e1cfe4c7-f9cd-4bf7-9937-46692f7f0747">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e1cfe4c7-f9cd-4bf7-9937-46692f7f0747">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e1cfe4c7-f9cd-4bf7-9937-46692f7f0747">
											<gml:posList>35.670696148945424 139.74692481733067 23.1 35.67067866033944 139.7469220746033 23.1 35.67067778301881 139.74693047073765 23.1 35.67075878895609 139.74694239078235 23.1 35.67075834133691 139.74694666618748 23.1 35.670793922530066 139.7469522393793 23.1 35.67079457607033 139.74694601959862 23.1 35.670807169668755 139.74694799436682 23.1 35.6708087004747 139.74693330111305 23.1 35.67081512798092 139.74693429940172 23.1 35.6708248376701 139.74684905552303 23.1 35.67076008476181 139.74683891857777 23.1 35.670752744587105 139.74691006474174 23.1 35.67069856592294 139.74690150702452 23.1 35.670696148945424 139.74692481733067 23.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1d095949-f454-43ba-ac1c-6f0da040e2db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d095949-f454-43ba-ac1c-6f0da040e2db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d095949-f454-43ba-ac1c-6f0da040e2db">
											<gml:posList>35.67076008476181 139.74683891857777 23.1 35.6708248376701 139.74684905552303 23.1 35.6708248376701 139.74684905552303 9.09 35.67076008476181 139.74683891857777 9.09 35.67076008476181 139.74683891857777 23.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-55d7523c-55b7-4dc5-9e72-c17ff48d09e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-55d7523c-55b7-4dc5-9e72-c17ff48d09e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-55d7523c-55b7-4dc5-9e72-c17ff48d09e3">
											<gml:posList>35.67076008476181 139.74683891857777 9.09 35.670752744587105 139.74691006474174 9.09 35.670752744587105 139.74691006474174 23.1 35.67076008476181 139.74683891857777 23.1 35.67076008476181 139.74683891857777 9.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-02d0fdd1-1440-4c30-aca0-dd8158f48a7b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-02d0fdd1-1440-4c30-aca0-dd8158f48a7b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-02d0fdd1-1440-4c30-aca0-dd8158f48a7b">
											<gml:posList>35.67081512798092 139.74693429940172 9.09 35.6708248376701 139.74684905552303 9.09 35.6708248376701 139.74684905552303 23.1 35.67081512798092 139.74693429940172 23.1 35.67081512798092 139.74693429940172 9.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a35b8d27-9beb-4d4b-92ef-ecf41d8bd164">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a35b8d27-9beb-4d4b-92ef-ecf41d8bd164">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a35b8d27-9beb-4d4b-92ef-ecf41d8bd164">
											<gml:posList>35.670752744587105 139.74691006474174 9.09 35.67069856592294 139.74690150702452 9.09 35.67069856592294 139.74690150702452 23.1 35.670752744587105 139.74691006474174 23.1 35.670752744587105 139.74691006474174 9.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-27fc166b-e804-40ec-899a-e96935fdb082">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-27fc166b-e804-40ec-899a-e96935fdb082">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-27fc166b-e804-40ec-899a-e96935fdb082">
											<gml:posList>35.67069856592294 139.74690150702452 9.09 35.670696148945424 139.74692481733067 9.09 35.670696148945424 139.74692481733067 23.1 35.67069856592294 139.74690150702452 23.1 35.67069856592294 139.74690150702452 9.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f6775f8e-5f58-4572-a4ad-de1223e59876">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f6775f8e-5f58-4572-a4ad-de1223e59876">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f6775f8e-5f58-4572-a4ad-de1223e59876">
											<gml:posList>35.670696148945424 139.74692481733067 9.09 35.67067866033944 139.7469220746033 9.09 35.67067866033944 139.7469220746033 23.1 35.670696148945424 139.74692481733067 23.1 35.670696148945424 139.74692481733067 9.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a69e3a54-9dc5-42e2-aed1-c634713b0c35">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a69e3a54-9dc5-42e2-aed1-c634713b0c35">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a69e3a54-9dc5-42e2-aed1-c634713b0c35">
											<gml:posList>35.67067866033944 139.7469220746033 9.09 35.67067778301881 139.74693047073765 9.09 35.67067778301881 139.74693047073765 23.1 35.67067866033944 139.7469220746033 23.1 35.67067866033944 139.7469220746033 9.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-18a47306-e9e9-4a92-b4c2-0fe317011bb6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18a47306-e9e9-4a92-b4c2-0fe317011bb6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18a47306-e9e9-4a92-b4c2-0fe317011bb6">
											<gml:posList>35.6708087004747 139.74693330111305 9.09 35.67081512798092 139.74693429940172 9.09 35.67081512798092 139.74693429940172 23.1 35.6708087004747 139.74693330111305 23.1 35.6708087004747 139.74693330111305 9.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e10c216a-27f9-4d13-91d8-8b02d2cf000f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e10c216a-27f9-4d13-91d8-8b02d2cf000f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e10c216a-27f9-4d13-91d8-8b02d2cf000f">
											<gml:posList>35.67067778301881 139.74693047073765 9.09 35.67075878895609 139.74694239078235 9.09 35.67075878895609 139.74694239078235 23.1 35.67067778301881 139.74693047073765 23.1 35.67067778301881 139.74693047073765 9.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e68de8f2-6d3a-49ad-8dde-ec0b34142016">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e68de8f2-6d3a-49ad-8dde-ec0b34142016">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e68de8f2-6d3a-49ad-8dde-ec0b34142016">
											<gml:posList>35.670807169668755 139.74694799436682 9.09 35.6708087004747 139.74693330111305 9.09 35.6708087004747 139.74693330111305 23.1 35.670807169668755 139.74694799436682 23.1 35.670807169668755 139.74694799436682 9.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-30050272-e4cb-44fd-9553-2b7593ec0a22">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-30050272-e4cb-44fd-9553-2b7593ec0a22">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-30050272-e4cb-44fd-9553-2b7593ec0a22">
											<gml:posList>35.67075878895609 139.74694239078235 9.09 35.67075834133691 139.74694666618748 9.09 35.67075834133691 139.74694666618748 23.1 35.67075878895609 139.74694239078235 23.1 35.67075878895609 139.74694239078235 9.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-496d6faa-e6e3-439a-86fb-5c3562bc56ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-496d6faa-e6e3-439a-86fb-5c3562bc56ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-496d6faa-e6e3-439a-86fb-5c3562bc56ef">
											<gml:posList>35.67079457607033 139.74694601959862 9.09 35.670807169668755 139.74694799436682 9.09 35.670807169668755 139.74694799436682 23.1 35.67079457607033 139.74694601959862 23.1 35.67079457607033 139.74694601959862 9.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-180540f7-c71f-403f-beeb-9a5acecad88a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-180540f7-c71f-403f-beeb-9a5acecad88a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-180540f7-c71f-403f-beeb-9a5acecad88a">
											<gml:posList>35.670793922530066 139.7469522393793 9.09 35.67079457607033 139.74694601959862 9.09 35.67079457607033 139.74694601959862 23.1 35.670793922530066 139.7469522393793 23.1 35.670793922530066 139.7469522393793 9.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9e505ae5-51c7-4e26-9ec9-ec85650fa097">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e505ae5-51c7-4e26-9ec9-ec85650fa097">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e505ae5-51c7-4e26-9ec9-ec85650fa097">
											<gml:posList>35.67075834133691 139.74694666618748 9.09 35.670793922530066 139.7469522393793 9.09 35.670793922530066 139.7469522393793 23.1 35.67075834133691 139.74694666618748 23.1 35.67075834133691 139.74694666618748 9.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-1625</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>