<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_3c3fc157-aefa-4f91-b24b-4442bcc59918">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">29.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.670523071162506 139.74395410695735 0 35.67040595886664 139.74392187195892 0 35.670335142169236 139.7442071651992 0 35.670357862541366 139.7442149606928 0 35.67041529459318 139.74423466967005 0 35.67046542366205 139.74425186823933 0 35.670523071162506 139.74395410695735 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670523071162506 139.74395410695735 7.41 35.67046542366205 139.74425186823933 7.41 35.67041529459318 139.74423466967005 7.41 35.670357862541366 139.7442149606928 7.41 35.670335142169236 139.7442071651992 7.41 35.67040595886664 139.74392187195892 7.41 35.670523071162506 139.74395410695735 7.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670523071162506 139.74395410695735 7.41 35.67040595886664 139.74392187195892 7.41 35.67040595886664 139.74392187195892 35.62 35.670523071162506 139.74395410695735 35.62 35.670523071162506 139.74395410695735 7.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67040595886664 139.74392187195892 7.41 35.670335142169236 139.7442071651992 7.41 35.670335142169236 139.7442071651992 35.62 35.67040595886664 139.74392187195892 35.62 35.67040595886664 139.74392187195892 7.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670335142169236 139.7442071651992 7.41 35.670357862541366 139.7442149606928 7.41 35.670357862541366 139.7442149606928 35.62 35.670335142169236 139.7442071651992 35.62 35.670335142169236 139.7442071651992 7.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670357862541366 139.7442149606928 7.41 35.67041529459318 139.74423466967005 7.41 35.67041529459318 139.74423466967005 35.62 35.670357862541366 139.7442149606928 35.62 35.670357862541366 139.7442149606928 7.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67041529459318 139.74423466967005 7.41 35.67046542366205 139.74425186823933 7.41 35.67046542366205 139.74425186823933 35.62 35.67041529459318 139.74423466967005 35.62 35.67041529459318 139.74423466967005 7.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67046542366205 139.74425186823933 7.41 35.670523071162506 139.74395410695735 7.41 35.670523071162506 139.74395410695735 35.62 35.67046542366205 139.74425186823933 35.62 35.67046542366205 139.74425186823933 7.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670523071162506 139.74395410695735 35.62 35.67040595886664 139.74392187195892 35.62 35.670335142169236 139.7442071651992 35.62 35.670357862541366 139.7442149606928 35.62 35.67041529459318 139.74423466967005 35.62 35.67046542366205 139.74425186823933 35.62 35.670523071162506 139.74395410695735 35.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-cea22877-b638-4a97-93fc-cfa865645c63"/>
							<gml:surfaceMember xlink:href="#poly-c48cf134-8f8c-41e6-819b-04ab03a4ba0c"/>
							<gml:surfaceMember xlink:href="#poly-fe0d5e21-58e7-43ea-a83f-47821f054a23"/>
							<gml:surfaceMember xlink:href="#poly-0b0a76a4-c0c7-4dd3-9ec1-a649ab84a348"/>
							<gml:surfaceMember xlink:href="#poly-ca7c6dff-e833-4995-a478-1ce104335d9b"/>
							<gml:surfaceMember xlink:href="#poly-6caa5a7c-b17a-4032-aa04-e09db7441be4"/>
							<gml:surfaceMember xlink:href="#poly-4ce56c8d-ab0e-4019-b316-b869313758a4"/>
							<gml:surfaceMember xlink:href="#poly-0cff73ba-165b-4a09-92d8-23725265c947"/>
							<gml:surfaceMember xlink:href="#poly-8f7f8ffd-e8cf-46c9-9572-96e9eb3e92a1"/>
							<gml:surfaceMember xlink:href="#poly-ec607f44-2ef0-41d3-a4e4-72febe4d1671"/>
							<gml:surfaceMember xlink:href="#poly-2ed125d2-38a8-436b-9269-103df1990fa0"/>
							<gml:surfaceMember xlink:href="#poly-b0ecea27-d78a-4919-b4b2-7b7267f56ee9"/>
							<gml:surfaceMember xlink:href="#poly-01f1f3be-8764-4385-875a-384d38f112b2"/>
							<gml:surfaceMember xlink:href="#poly-02667add-1227-476e-9ad9-9e8c8e826b9a"/>
							<gml:surfaceMember xlink:href="#poly-cdb8df33-2e68-420e-95c2-00ab73d480b8"/>
							<gml:surfaceMember xlink:href="#poly-846a7925-a6ae-4157-8fae-006558c2ce1d"/>
							<gml:surfaceMember xlink:href="#poly-f7eed222-52c0-449e-8dd2-5f2cb5f5761c"/>
							<gml:surfaceMember xlink:href="#poly-5c45c56c-b10b-4e2a-96ed-6a6afe046278"/>
							<gml:surfaceMember xlink:href="#poly-e10accb0-db89-49e6-9c01-8ab1fff968b2"/>
							<gml:surfaceMember xlink:href="#poly-a960889b-642e-4afb-a984-0312ae0d2f76"/>
							<gml:surfaceMember xlink:href="#poly-7c7d63ba-9ce1-4c28-a91a-73234525c55e"/>
							<gml:surfaceMember xlink:href="#poly-f8dcf2e8-7e64-42c6-82c8-507424483006"/>
							<gml:surfaceMember xlink:href="#poly-829a8253-e83b-428d-9360-3349bc7b226e"/>
							<gml:surfaceMember xlink:href="#poly-0163704e-7845-4f12-bece-4a8098d8cff2"/>
							<gml:surfaceMember xlink:href="#poly-073e24a9-56ab-4d02-84cb-355c70e786a2"/>
							<gml:surfaceMember xlink:href="#poly-cb13861e-c51b-4576-86ea-c97db220a2a5"/>
							<gml:surfaceMember xlink:href="#poly-3c511957-e1c6-4817-a560-84321d17f32c"/>
							<gml:surfaceMember xlink:href="#poly-be5cff21-21da-4737-bfbd-92cba3357a57"/>
							<gml:surfaceMember xlink:href="#poly-25d5ff8b-7fa3-4fc5-afd5-a26bff53b564"/>
							<gml:surfaceMember xlink:href="#poly-6e087d06-72b2-47ea-b3e0-08ff32182dce"/>
							<gml:surfaceMember xlink:href="#poly-ed602d1e-6398-440c-90ca-e97072540a89"/>
							<gml:surfaceMember xlink:href="#poly-83c8f954-236f-42d7-a533-05049d003b44"/>
							<gml:surfaceMember xlink:href="#poly-7fc4bb07-0997-4197-85c8-535e15efaa5f"/>
							<gml:surfaceMember xlink:href="#poly-35e0b4f0-57ea-479f-a7bb-539777377c2d"/>
							<gml:surfaceMember xlink:href="#poly-96675ca9-ea91-436d-b6d9-cbc71688f525"/>
							<gml:surfaceMember xlink:href="#poly-bc8963be-4156-4223-8c46-4310e0c2bb8c"/>
							<gml:surfaceMember xlink:href="#poly-6f2048c1-4936-4ed1-a20d-a7afd091d66e"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_3c3fc157-aefa-4f91-b24b-4442bcc59918_BuildingInstallation_1051">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b463a99-98ab-442c-8f18-23d857607939">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67046542366205 139.7442518682393 36.8 35.67041529459318 139.74423466967002 36.8 35.670415932565 139.74423196262623 36.8 35.67046314915549 139.7442477505072 36.8 35.67051995177468 139.743953248825 36.8 35.670523071162506 139.74395410695735 36.8 35.67046542366205 139.7442518682393 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35c2de96-bc48-46d6-b407-f418c68d0add">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-35c2de96-bc48-46d6-b407-f418c68d0add_0">
											<gml:posList>35.670523071162506 139.74395410695735 39.367 35.670523071162506 139.74395410695735 36.8 35.67051995177468 139.743953248825 36.8 35.67051995177468 139.743953248825 39.367 35.670523071162506 139.74395410695735 39.367</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-018fe423-2f70-4a36-8c0e-7547cccc927f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-018fe423-2f70-4a36-8c0e-7547cccc927f_0">
											<gml:posList>35.67051995177468 139.743953248825 39.367 35.67051995177468 139.743953248825 36.8 35.67046314915549 139.7442477505072 36.8 35.67046314915549 139.7442477505072 39.367 35.67051995177468 139.743953248825 39.367</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8eeb9bc4-89dc-41f2-9f9c-ef46093e1723">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8eeb9bc4-89dc-41f2-9f9c-ef46093e1723_0">
											<gml:posList>35.67046542366205 139.7442518682393 39.367 35.670523071162506 139.74395410695735 39.367 35.67051995177468 139.743953248825 39.367 35.67046314915549 139.7442477505072 39.367 35.670415932565 139.74423196262623 39.367 35.67041529459318 139.74423466967002 39.367 35.67046542366205 139.7442518682393 39.367</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0622ab71-d8a4-4d14-97b1-f1ce3bdeb8cc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0622ab71-d8a4-4d14-97b1-f1ce3bdeb8cc_0">
											<gml:posList>35.67046542366205 139.7442518682393 39.367 35.67046542366205 139.7442518682393 36.8 35.670523071162506 139.74395410695735 36.8 35.670523071162506 139.74395410695735 39.367 35.67046542366205 139.7442518682393 39.367</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-91a3af6c-232b-4294-ad66-e0230ea3a26a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-91a3af6c-232b-4294-ad66-e0230ea3a26a_0">
											<gml:posList>35.670415932565 139.74423196262623 39.367 35.670415932565 139.74423196262623 36.8 35.67041529459318 139.74423466967002 36.8 35.67041529459318 139.74423466967002 39.367 35.670415932565 139.74423196262623 39.367</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5354b1c4-27dc-4238-b0ed-7f4135aa1791">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5354b1c4-27dc-4238-b0ed-7f4135aa1791_0">
											<gml:posList>35.67046314915549 139.7442477505072 39.367 35.67046314915549 139.7442477505072 36.8 35.670415932565 139.74423196262623 36.8 35.670415932565 139.74423196262623 39.367 35.67046314915549 139.7442477505072 39.367</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76c62d32-db74-435e-bd89-f9eb894c4fbe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-76c62d32-db74-435e-bd89-f9eb894c4fbe_0">
											<gml:posList>35.67041529459318 139.74423466967002 39.367 35.67041529459318 139.74423466967002 36.8 35.67046542366205 139.7442518682393 36.8 35.67046542366205 139.7442518682393 39.367 35.67041529459318 139.74423466967002 39.367</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_3c3fc157-aefa-4f91-b24b-4442bcc59918_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-353dac1a-8843-495d-8500-19837663186f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670415736039274 139.74397891501283 34.802 35.6704209875304 139.743949890621 34.802 35.67046871585744 139.74396287201336 34.802 35.670463455341334 139.74399188538538 34.802 35.670415736039274 139.74397891501283 34.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1998a8b-c5db-47ba-9ece-9d11969e734b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670486446313525 139.74395133098568 34.802 35.670506082335564 139.74395687641902 34.802 35.670495676486624 139.7440122188138 34.802 35.67047604046709 139.7440066733676 34.802 35.670486446313525 139.74395133098568 34.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5fa3377-c099-4279-9f05-1bc3d1556aad">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67039467660269 139.74413242629035 34.802 35.67041806239938 139.74413806700656 34.802 35.67041332496414 139.74416752161767 34.802 35.670389939152436 139.74416185880065 34.802 35.67039467660269 139.74413242629035 34.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e739ddb3-a30b-43be-aff5-e0448873eba5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e739ddb3-a30b-43be-aff5-e0448873eba5_0">
											<gml:posList>35.67039467660269 139.74413242629035 34.802 35.670389939152436 139.74416185880065 34.802 35.670389939152436 139.74416185880065 38.483 35.67039467660269 139.74413242629035 38.483 35.67039467660269 139.74413242629035 34.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d1fcd2a-1797-4ae4-936e-754fa0306fc4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d1fcd2a-1797-4ae4-936e-754fa0306fc4_0">
											<gml:posList>35.670389939152436 139.74416185880065 34.802 35.67041332496414 139.74416752161767 34.802 35.67041332496414 139.74416752161767 38.483 35.670389939152436 139.74416185880065 38.483 35.670389939152436 139.74416185880065 34.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1803fc55-30ff-4172-9e0a-b0ab87443dd8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1803fc55-30ff-4172-9e0a-b0ab87443dd8_0">
											<gml:posList>35.67041332496414 139.74416752161767 38.483 35.67041806239938 139.74413806700656 38.483 35.67039467660269 139.74413242629035 38.483 35.670389939152436 139.74416185880065 38.483 35.67041332496414 139.74416752161767 38.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f8ea3aa8-a483-42b9-a7df-ff5138107830">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f8ea3aa8-a483-42b9-a7df-ff5138107830_0">
											<gml:posList>35.67041806239938 139.74413806700656 34.802 35.67039467660269 139.74413242629035 34.802 35.67039467660269 139.74413242629035 38.483 35.67041806239938 139.74413806700656 38.483 35.67041806239938 139.74413806700656 34.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d9dcf8e8-673b-4492-89f6-2d841288bd9e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d9dcf8e8-673b-4492-89f6-2d841288bd9e_0">
											<gml:posList>35.67041332496414 139.74416752161767 34.802 35.67041806239938 139.74413806700656 34.802 35.67041806239938 139.74413806700656 38.483 35.67041332496414 139.74416752161767 38.483 35.67041332496414 139.74416752161767 34.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cbe0288d-7fa5-4a43-a988-d54774309b6c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cbe0288d-7fa5-4a43-a988-d54774309b6c_0">
											<gml:posList>35.670415736039274 139.74397891501283 38.195 35.6704209875304 139.743949890621 38.195 35.6704209875304 139.743949890621 34.802 35.670415736039274 139.74397891501283 34.802 35.670415736039274 139.74397891501283 38.195</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e93f8a1b-04ea-42e3-ba56-e335f699bc5f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e93f8a1b-04ea-42e3-ba56-e335f699bc5f_0">
											<gml:posList>35.670463455341334 139.74399188538538 34.802 35.670463455341334 139.74399188538538 38.195 35.670415736039274 139.74397891501283 38.195 35.670415736039274 139.74397891501283 34.802 35.670463455341334 139.74399188538538 34.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-485fbe4d-f21f-4599-b5bb-351e41fd3570">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-485fbe4d-f21f-4599-b5bb-351e41fd3570_0">
											<gml:posList>35.670415736039274 139.74397891501283 38.195 35.670463455341334 139.74399188538538 38.195 35.67046871585744 139.74396287201336 38.195 35.6704209875304 139.743949890621 38.195 35.670415736039274 139.74397891501283 38.195</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-793c67c4-f654-42c2-9194-ae23f8fcbe16">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-793c67c4-f654-42c2-9194-ae23f8fcbe16_0">
											<gml:posList>35.6704209875304 139.743949890621 34.802 35.6704209875304 139.743949890621 38.195 35.67046871585744 139.74396287201336 38.195 35.67046871585744 139.74396287201336 34.802 35.6704209875304 139.743949890621 34.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40de3e57-e629-4b97-b3ff-18913c22e956">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40de3e57-e629-4b97-b3ff-18913c22e956_0">
											<gml:posList>35.670463455341334 139.74399188538538 34.802 35.67046871585744 139.74396287201336 34.802 35.67046871585744 139.74396287201336 38.195 35.670463455341334 139.74399188538538 38.195 35.670463455341334 139.74399188538538 34.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f600d956-3876-484f-a010-2c2597ebdbb5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f600d956-3876-484f-a010-2c2597ebdbb5_0">
											<gml:posList>35.670486446313525 139.74395133098568 34.802 35.67047604046709 139.7440066733676 34.802 35.67047604046709 139.7440066733676 39.091 35.670486446313525 139.74395133098568 39.091 35.670486446313525 139.74395133098568 34.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9df1f967-6fef-45dd-bb54-0798a1ef3d45">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9df1f967-6fef-45dd-bb54-0798a1ef3d45_0">
											<gml:posList>35.67047604046709 139.7440066733676 34.802 35.670495676486624 139.7440122188138 34.802 35.670495676486624 139.7440122188138 39.091 35.67047604046709 139.7440066733676 39.091 35.67047604046709 139.7440066733676 34.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-648dc2d4-a6b1-4dc8-ab6f-88ac9e6314ec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-648dc2d4-a6b1-4dc8-ab6f-88ac9e6314ec_0">
											<gml:posList>35.670495676486624 139.7440122188138 39.091 35.670506082335564 139.74395687641902 39.091 35.670486446313525 139.74395133098568 39.091 35.67047604046709 139.7440066733676 39.091 35.670495676486624 139.7440122188138 39.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea4151d2-8723-475c-b849-1eb601a0b23b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea4151d2-8723-475c-b849-1eb601a0b23b_0">
											<gml:posList>35.670506082335564 139.74395687641902 34.802 35.670486446313525 139.74395133098568 34.802 35.670486446313525 139.74395133098568 39.091 35.670506082335564 139.74395687641902 39.091 35.670506082335564 139.74395687641902 34.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5ad46554-af00-46ec-a1b8-0a08b7d75e31">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5ad46554-af00-46ec-a1b8-0a08b7d75e31_0">
											<gml:posList>35.670495676486624 139.7440122188138 34.802 35.670506082335564 139.74395687641902 34.802 35.670506082335564 139.74395687641902 39.091 35.670495676486624 139.7440122188138 39.091 35.670495676486624 139.7440122188138 34.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_3c3fc157-aefa-4f91-b24b-4442bcc59918_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a36a36f-974f-4868-a4ae-c99a10d44bee">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6703752541061 139.74407443294578 34.802 35.670392623380614 139.74400125421914 34.802 35.67040292880372 139.7440049321889 34.802 35.67038556854072 139.74407811091407 34.802 35.6703752541061 139.74407443294578 34.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b63dfcd8-9e45-4b66-a584-18bae94dd9e2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67040969535486 139.74411062634894 39.755 35.67039704646508 139.74410708352843 39.755 35.67040176894491 139.74408179337746 39.755 35.670414417835424 139.74408533619422 39.755 35.67040969535486 139.74411062634894 39.755</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6cf275b8-a570-4292-836c-c25a1516152b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67042392391554 139.74419025409185 34.802 35.67042114695269 139.74418926301547 34.802 35.670433276390526 139.74412429747883 34.802 35.67043608024777 139.74412508969039 34.802 35.67042392391554 139.74419025409185 34.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bbcaee1b-8916-4700-8fbf-c24d458825cc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670412987780615 139.7442234381827 41.563 35.67040343069942 139.74422002446298 41.563 35.67040907373941 139.74419626872387 41.563 35.67041863082126 139.74419968244098 41.563 35.670412987780615 139.7442234381827 41.563</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa412d10-1fee-42ca-a9e9-9c6be95b6ffe">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67045460446112 139.74419946570853 34.802 35.67045610305579 139.7441904171472 34.802 35.670460403403304 139.74419149490052 34.802 35.67045344867148 139.7442332575331 34.802 35.67044235973172 139.74423048619644 34.802 35.670447806846155 139.7441977610938 34.802 35.67045460446112 139.74419946570853 34.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f48941a6-7475-4f62-bcd0-6eec4e575b7a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f48941a6-7475-4f62-bcd0-6eec4e575b7a_0">
											<gml:posList>35.67040292880372 139.7440049321889 34.802 35.670392623380614 139.74400125421914 34.802 35.670392623380614 139.74400125421914 37.26 35.67040292880372 139.7440049321889 37.26 35.67040292880372 139.7440049321889 34.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46bb432a-9e1a-43d8-8733-8586f7cc4f16">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46bb432a-9e1a-43d8-8733-8586f7cc4f16_0">
											<gml:posList>35.670392623380614 139.74400125421914 34.802 35.6703752541061 139.74407443294578 34.802 35.6703752541061 139.74407443294578 37.26 35.670392623380614 139.74400125421914 37.26 35.670392623380614 139.74400125421914 34.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f00869e1-653c-4d5a-ad32-6eb1eb83168d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f00869e1-653c-4d5a-ad32-6eb1eb83168d_0">
											<gml:posList>35.67040292880372 139.7440049321889 37.26 35.670392623380614 139.74400125421914 37.26 35.6703752541061 139.74407443294578 37.26 35.67038556854072 139.74407811091407 37.26 35.67040292880372 139.7440049321889 37.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8558e2cf-dde1-4712-a288-1bf854f74d90">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8558e2cf-dde1-4712-a288-1bf854f74d90_0">
											<gml:posList>35.67038556854072 139.74407811091407 34.802 35.67040292880372 139.7440049321889 34.802 35.67040292880372 139.7440049321889 37.26 35.67038556854072 139.74407811091407 37.26 35.67038556854072 139.74407811091407 34.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78b42ba6-fc84-472a-bfda-afb3d72fe1df">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78b42ba6-fc84-472a-bfda-afb3d72fe1df_0">
											<gml:posList>35.6703752541061 139.74407443294578 34.802 35.67038556854072 139.74407811091407 34.802 35.67038556854072 139.74407811091407 37.26 35.6703752541061 139.74407443294578 37.26 35.6703752541061 139.74407443294578 34.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ca5c91b-20f7-4d77-9a71-3cb698488879">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9ca5c91b-20f7-4d77-9a71-3cb698488879_0">
											<gml:posList>35.670414417835424 139.74408533619422 39.755 35.67040176894491 139.74408179337746 39.755 35.67040176894491 139.74408179337746 40.842 35.670414417835424 139.74408533619422 40.842 35.670414417835424 139.74408533619422 39.755</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b28c3ff8-fa22-41d0-a9d6-855a083db241">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b28c3ff8-fa22-41d0-a9d6-855a083db241_0">
											<gml:posList>35.67040176894491 139.74408179337746 39.755 35.67039704646508 139.74410708352843 39.755 35.67039704646508 139.74410708352843 40.842 35.67040176894491 139.74408179337746 40.842 35.67040176894491 139.74408179337746 39.755</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-71f0d72e-a667-4792-ad48-649832f12034">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-71f0d72e-a667-4792-ad48-649832f12034_0">
											<gml:posList>35.67040969535486 139.74411062634894 40.842 35.670414417835424 139.74408533619422 40.842 35.67040176894491 139.74408179337746 40.842 35.67039704646508 139.74410708352843 40.842 35.67040969535486 139.74411062634894 40.842</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d53874e-e055-4a7c-940e-b661ab012373">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d53874e-e055-4a7c-940e-b661ab012373_0">
											<gml:posList>35.67040969535486 139.74411062634894 39.755 35.670414417835424 139.74408533619422 39.755 35.670414417835424 139.74408533619422 40.842 35.67040969535486 139.74411062634894 40.842 35.67040969535486 139.74411062634894 39.755</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a326b02-636e-40b8-95ad-ab5a86ccda4c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7a326b02-636e-40b8-95ad-ab5a86ccda4c_0">
											<gml:posList>35.67039704646508 139.74410708352843 39.755 35.67040969535486 139.74411062634894 39.755 35.67040969535486 139.74411062634894 40.842 35.67039704646508 139.74410708352843 40.842 35.67039704646508 139.74410708352843 39.755</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f4eab17b-008e-479a-88b9-1489c8b67e5c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f4eab17b-008e-479a-88b9-1489c8b67e5c_0">
											<gml:posList>35.670433276390526 139.74412429747883 34.802 35.670433276390526 139.74412429747883 37.26 35.67043608024777 139.74412508969039 37.26 35.67043608024777 139.74412508969039 34.802 35.670433276390526 139.74412429747883 34.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a806bdbd-6ea6-4ce2-a277-463506ba3259">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a806bdbd-6ea6-4ce2-a277-463506ba3259_0">
											<gml:posList>35.670433276390526 139.74412429747883 34.802 35.67042114695269 139.74418926301547 34.802 35.67042114695269 139.74418926301547 37.26 35.670433276390526 139.74412429747883 37.26 35.670433276390526 139.74412429747883 34.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cad28f71-5c56-4f7a-acc6-8d48e37d8c0b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cad28f71-5c56-4f7a-acc6-8d48e37d8c0b_0">
											<gml:posList>35.670433276390526 139.74412429747883 37.26 35.67042114695269 139.74418926301547 37.26 35.67042392391554 139.74419025409185 37.26 35.67043608024777 139.74412508969039 37.26 35.670433276390526 139.74412429747883 37.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f1a11e45-87b9-42a5-befc-69ceec5abda6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f1a11e45-87b9-42a5-befc-69ceec5abda6_0">
											<gml:posList>35.67042392391554 139.74419025409185 34.802 35.67043608024777 139.74412508969039 34.802 35.67043608024777 139.74412508969039 37.26 35.67042392391554 139.74419025409185 37.26 35.67042392391554 139.74419025409185 34.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8f2d993-b277-4d02-92f5-a0dd6b1ac33b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b8f2d993-b277-4d02-92f5-a0dd6b1ac33b_0">
											<gml:posList>35.67042114695269 139.74418926301547 34.802 35.67042392391554 139.74419025409185 34.802 35.67042392391554 139.74419025409185 37.26 35.67042114695269 139.74418926301547 37.26 35.67042114695269 139.74418926301547 34.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f8868c0-f34b-4934-a308-8d2ba8051dfa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f8868c0-f34b-4934-a308-8d2ba8051dfa_0">
											<gml:posList>35.67045610305579 139.7441904171472 34.802 35.67045610305579 139.7441904171472 37.26 35.670460403403304 139.74419149490052 37.26 35.670460403403304 139.74419149490052 34.802 35.67045610305579 139.7441904171472 34.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-45faad26-e66a-42e7-8aa1-dadfe4cf45e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-45faad26-e66a-42e7-8aa1-dadfe4cf45e2_0">
											<gml:posList>35.67045460446112 139.74419946570853 37.26 35.67045610305579 139.7441904171472 37.26 35.67045610305579 139.7441904171472 34.802 35.67045460446112 139.74419946570853 34.802 35.67045460446112 139.74419946570853 37.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa6962b2-51d0-4576-81d3-b61ef7cf3f12">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aa6962b2-51d0-4576-81d3-b61ef7cf3f12_0">
											<gml:posList>35.67041863082126 139.74419968244098 41.563 35.67040907373941 139.74419626872387 41.563 35.67040907373941 139.74419626872387 43.941 35.67041863082126 139.74419968244098 43.941 35.67041863082126 139.74419968244098 41.563</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf048f3d-3923-4e48-b4a1-865037305170">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bf048f3d-3923-4e48-b4a1-865037305170_0">
											<gml:posList>35.670447806846155 139.7441977610938 34.802 35.670447806846155 139.7441977610938 37.26 35.67045460446112 139.74419946570853 37.26 35.67045460446112 139.74419946570853 34.802 35.670447806846155 139.7441977610938 34.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8a84df5-029b-44bc-9673-76f3b5159c54">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b8a84df5-029b-44bc-9673-76f3b5159c54_0">
											<gml:posList>35.67040907373941 139.74419626872387 41.563 35.67040343069942 139.74422002446298 41.563 35.67040343069942 139.74422002446298 43.941 35.67040907373941 139.74419626872387 43.941 35.67040907373941 139.74419626872387 41.563</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-67d107a2-5bc3-4c4d-8a12-88a72af05656">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-67d107a2-5bc3-4c4d-8a12-88a72af05656_0">
											<gml:posList>35.67040907373941 139.74419626872387 43.941 35.67040343069942 139.74422002446298 43.941 35.670412987780615 139.7442234381827 43.941 35.67041863082126 139.74419968244098 43.941 35.67040907373941 139.74419626872387 43.941</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-edd78e82-af16-47db-8400-7eba7d6c29b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-edd78e82-af16-47db-8400-7eba7d6c29b8_0">
											<gml:posList>35.67041863082126 139.74419968244098 41.563 35.67041863082126 139.74419968244098 43.941 35.670412987780615 139.7442234381827 43.941 35.670412987780615 139.7442234381827 41.563 35.67041863082126 139.74419968244098 41.563</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f5184db8-bbdb-468a-b006-588e82db38e9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f5184db8-bbdb-468a-b006-588e82db38e9_0">
											<gml:posList>35.67044235973172 139.74423048619644 37.26 35.67045344867148 139.7442332575331 37.26 35.670460403403304 139.74419149490052 37.26 35.67045610305579 139.7441904171472 37.26 35.67045460446112 139.74419946570853 37.26 35.670447806846155 139.7441977610938 37.26 35.67044235973172 139.74423048619644 37.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-716d5fee-61ba-41ac-86ff-087134cc223e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-716d5fee-61ba-41ac-86ff-087134cc223e_0">
											<gml:posList>35.670460403403304 139.74419149490052 34.802 35.670460403403304 139.74419149490052 37.26 35.67045344867148 139.7442332575331 37.26 35.67045344867148 139.7442332575331 34.802 35.670460403403304 139.74419149490052 34.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57c0e747-48ec-48a9-8895-ef983211322b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-57c0e747-48ec-48a9-8895-ef983211322b_0">
											<gml:posList>35.67044235973172 139.74423048619644 34.802 35.67044235973172 139.74423048619644 37.26 35.670447806846155 139.7441977610938 37.26 35.670447806846155 139.7441977610938 34.802 35.67044235973172 139.74423048619644 34.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-71c42c9f-16ab-48ab-a9b0-88b0a442457c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-71c42c9f-16ab-48ab-a9b0-88b0a442457c_0">
											<gml:posList>35.670412987780615 139.7442234381827 41.563 35.670412987780615 139.7442234381827 43.941 35.67040343069942 139.74422002446298 43.941 35.67040343069942 139.74422002446298 41.563 35.670412987780615 139.7442234381827 41.563</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8c543a9-b9af-46ef-a072-c7c7db75c838">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b8c543a9-b9af-46ef-a072-c7c7db75c838_0">
											<gml:posList>35.67045344867148 139.7442332575331 37.26 35.67044235973172 139.74423048619644 37.26 35.67044235973172 139.74423048619644 34.802 35.67045344867148 139.7442332575331 34.802 35.67045344867148 139.7442332575331 37.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-cea22877-b638-4a97-93fc-cfa865645c63">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cea22877-b638-4a97-93fc-cfa865645c63">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cea22877-b638-4a97-93fc-cfa865645c63">
											<gml:posList>35.67035786254135 139.7442149606928 7.41 35.67033514216923 139.7442071651992 7.41 35.670405958866624 139.74392187195892 7.41 35.670523071162506 139.74395410695735 7.41 35.67046542366205 139.7442518682393 7.41 35.67041529459318 139.74423466967002 7.41 35.67035786254135 139.7442149606928 7.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c48cf134-8f8c-41e6-819b-04ab03a4ba0c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c48cf134-8f8c-41e6-819b-04ab03a4ba0c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c48cf134-8f8c-41e6-819b-04ab03a4ba0c">
											<gml:posList>35.6704072510607 139.74392622274573 36.8 35.67051921683913 139.7439588942928 36.8 35.670523071162506 139.74395410695735 36.8 35.670405958866624 139.74392187195892 36.8 35.6704072510607 139.74392622274573 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fe0d5e21-58e7-43ea-a83f-47821f054a23">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe0d5e21-58e7-43ea-a83f-47821f054a23">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe0d5e21-58e7-43ea-a83f-47821f054a23">
											<gml:posList>35.67033514216923 139.7442071651992 36.8 35.67033805179505 139.74420472074272 36.8 35.6704072510607 139.74392622274573 36.8 35.670405958866624 139.74392187195892 36.8 35.67033514216923 139.7442071651992 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0b0a76a4-c0c7-4dd3-9ec1-a649ab84a348">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b0a76a4-c0c7-4dd3-9ec1-a649ab84a348">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b0a76a4-c0c7-4dd3-9ec1-a649ab84a348">
											<gml:posList>35.67039338429062 139.74407925102463 34.802 35.67039817157675 139.7440805933394 34.802 35.670401251066735 139.7440641088874 34.802 35.6704072510607 139.74392622274573 34.802 35.67033805179505 139.74420472074272 34.802 35.67035862633695 139.74421175642937 34.802 35.670364332299705 139.74418776866156 34.802 35.670400076129795 139.74419369390148 34.802 35.67040269097005 139.7441826778702 34.802 35.670425700093396 139.7441908928005 34.802 35.67041606735398 139.74423139911693 34.802 35.67046313995381 139.7442474964532 34.802 35.67045644648819 139.7441307889982 34.802 35.67038736894268 139.74411143547866 34.802 35.67039338429062 139.74407925102463 34.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ca7c6dff-e833-4995-a478-1ce104335d9b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca7c6dff-e833-4995-a478-1ce104335d9b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca7c6dff-e833-4995-a478-1ce104335d9b">
											<gml:posList>35.67051921683913 139.7439588942928 34.802 35.6704072510607 139.74392622274573 34.802 35.670401251066735 139.7440641088874 34.802 35.67046553232806 139.74408213110962 34.802 35.67045644648819 139.7441307889982 34.802 35.67046313995381 139.7442474964532 34.802 35.67051921683913 139.7439588942928 34.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6caa5a7c-b17a-4032-aa04-e09db7441be4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6caa5a7c-b17a-4032-aa04-e09db7441be4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6caa5a7c-b17a-4032-aa04-e09db7441be4">
											<gml:posList>35.67046553232806 139.74408213110962 39.755 35.670401251066735 139.7440641088874 39.755 35.67039817157675 139.7440805933394 39.755 35.67039338429062 139.74407925102463 39.755 35.67038736894268 139.74411143547866 39.755 35.67045644648819 139.7441307889982 39.755 35.67046553232806 139.74408213110962 39.755</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4ce56c8d-ab0e-4019-b316-b869313758a4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ce56c8d-ab0e-4019-b316-b869313758a4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ce56c8d-ab0e-4019-b316-b869313758a4">
											<gml:posList>35.67051921683913 139.7439588942928 36.8 35.67046313995381 139.7442474964532 36.8 35.67046542366205 139.7442518682393 36.8 35.670523071162506 139.74395410695735 36.8 35.67051921683913 139.7439588942928 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0cff73ba-165b-4a09-92d8-23725265c947">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0cff73ba-165b-4a09-92d8-23725265c947">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0cff73ba-165b-4a09-92d8-23725265c947">
											<gml:posList>35.670400076129795 139.74419369390148 41.563 35.670364332299705 139.74418776866156 41.563 35.67035786254135 139.7442149606928 41.563 35.67041530360691 139.74423466966002 41.563 35.670425700093396 139.7441908928005 41.563 35.67040269097005 139.7441826778702 41.563 35.670400076129795 139.74419369390148 41.563</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8f7f8ffd-e8cf-46c9-9572-96e9eb3e92a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f7f8ffd-e8cf-46c9-9572-96e9eb3e92a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f7f8ffd-e8cf-46c9-9572-96e9eb3e92a1">
											<gml:posList>35.67033514216923 139.7442071651992 36.8 35.67035786254135 139.7442149606928 36.8 35.67035862633695 139.74421175642937 36.8 35.67033805179505 139.74420472074272 36.8 35.67033514216923 139.7442071651992 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ec607f44-2ef0-41d3-a4e4-72febe4d1671">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec607f44-2ef0-41d3-a4e4-72febe4d1671">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec607f44-2ef0-41d3-a4e4-72febe4d1671">
											<gml:posList>35.67046313995381 139.7442474964532 36.8 35.67041606735398 139.74423139911693 36.8 35.67041530360691 139.74423466966002 36.8 35.67046542366205 139.7442518682393 36.8 35.67046313995381 139.7442474964532 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2ed125d2-38a8-436b-9269-103df1990fa0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2ed125d2-38a8-436b-9269-103df1990fa0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2ed125d2-38a8-436b-9269-103df1990fa0">
											<gml:posList>35.670405958866624 139.74392187195892 7.41 35.670405958866624 139.74392187195892 36.8 35.670523071162506 139.74395410695735 36.8 35.670523071162506 139.74395410695735 7.41 35.670405958866624 139.74392187195892 7.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b0ecea27-d78a-4919-b4b2-7b7267f56ee9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b0ecea27-d78a-4919-b4b2-7b7267f56ee9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b0ecea27-d78a-4919-b4b2-7b7267f56ee9">
											<gml:posList>35.67051921683913 139.7439588942928 36.8 35.6704072510607 139.74392622274573 36.8 35.6704072510607 139.74392622274573 34.802 35.67051921683913 139.7439588942928 34.802 35.67051921683913 139.7439588942928 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-01f1f3be-8764-4385-875a-384d38f112b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-01f1f3be-8764-4385-875a-384d38f112b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-01f1f3be-8764-4385-875a-384d38f112b2">
											<gml:posList>35.67033514216923 139.7442071651992 36.8 35.670405958866624 139.74392187195892 36.8 35.670405958866624 139.74392187195892 7.41 35.67033514216923 139.7442071651992 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-02667add-1227-476e-9ad9-9e8c8e826b9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-02667add-1227-476e-9ad9-9e8c8e826b9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-02667add-1227-476e-9ad9-9e8c8e826b9a">
											<gml:posList>35.67033514216923 139.7442071651992 36.8 35.670405958866624 139.74392187195892 7.41 35.67033514216923 139.7442071651992 7.41 35.67033514216923 139.7442071651992 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cdb8df33-2e68-420e-95c2-00ab73d480b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cdb8df33-2e68-420e-95c2-00ab73d480b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cdb8df33-2e68-420e-95c2-00ab73d480b8">
											<gml:posList>35.67033805179505 139.74420472074272 36.8 35.67033805179505 139.74420472074272 34.802 35.6704072510607 139.74392622274573 34.802 35.6704072510607 139.74392622274573 36.8 35.67033805179505 139.74420472074272 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-846a7925-a6ae-4157-8fae-006558c2ce1d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-846a7925-a6ae-4157-8fae-006558c2ce1d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-846a7925-a6ae-4157-8fae-006558c2ce1d">
											<gml:posList>35.67039817157675 139.7440805933394 34.802 35.67039817157675 139.7440805933394 39.755 35.670401251066735 139.7440641088874 39.755 35.670401251066735 139.7440641088874 34.802 35.67039817157675 139.7440805933394 34.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f7eed222-52c0-449e-8dd2-5f2cb5f5761c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f7eed222-52c0-449e-8dd2-5f2cb5f5761c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f7eed222-52c0-449e-8dd2-5f2cb5f5761c">
											<gml:posList>35.67046553232806 139.74408213110962 39.755 35.67046553232806 139.74408213110962 34.802 35.670401251066735 139.7440641088874 34.802 35.670401251066735 139.7440641088874 39.755 35.67046553232806 139.74408213110962 39.755</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5c45c56c-b10b-4e2a-96ed-6a6afe046278">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5c45c56c-b10b-4e2a-96ed-6a6afe046278">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5c45c56c-b10b-4e2a-96ed-6a6afe046278">
											<gml:posList>35.67039338429062 139.74407925102463 34.802 35.67039338429062 139.74407925102463 39.755 35.67039817157675 139.7440805933394 39.755 35.67039817157675 139.7440805933394 34.802 35.67039338429062 139.74407925102463 34.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e10accb0-db89-49e6-9c01-8ab1fff968b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e10accb0-db89-49e6-9c01-8ab1fff968b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e10accb0-db89-49e6-9c01-8ab1fff968b2">
											<gml:posList>35.67039338429062 139.74407925102463 34.802 35.67038736894268 139.74411143547866 34.802 35.67038736894268 139.74411143547866 39.755 35.67039338429062 139.74407925102463 39.755 35.67039338429062 139.74407925102463 34.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a960889b-642e-4afb-a984-0312ae0d2f76">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a960889b-642e-4afb-a984-0312ae0d2f76">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a960889b-642e-4afb-a984-0312ae0d2f76">
											<gml:posList>35.67046542366205 139.7442518682393 7.41 35.670523071162506 139.74395410695735 7.41 35.670523071162506 139.74395410695735 36.8 35.67046542366205 139.7442518682393 36.8 35.67046542366205 139.7442518682393 7.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7c7d63ba-9ce1-4c28-a91a-73234525c55e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c7d63ba-9ce1-4c28-a91a-73234525c55e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c7d63ba-9ce1-4c28-a91a-73234525c55e">
											<gml:posList>35.67051921683913 139.7439588942928 36.8 35.67051921683913 139.7439588942928 34.802 35.67046313995381 139.7442474964532 34.802 35.67046313995381 139.7442474964532 36.8 35.67051921683913 139.7439588942928 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f8dcf2e8-7e64-42c6-82c8-507424483006">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f8dcf2e8-7e64-42c6-82c8-507424483006">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f8dcf2e8-7e64-42c6-82c8-507424483006">
											<gml:posList>35.67046553232806 139.74408213110962 34.802 35.67046553232806 139.74408213110962 39.755 35.67045644648819 139.7441307889982 39.755 35.67045644648819 139.7441307889982 34.802 35.67046553232806 139.74408213110962 34.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-829a8253-e83b-428d-9360-3349bc7b226e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-829a8253-e83b-428d-9360-3349bc7b226e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-829a8253-e83b-428d-9360-3349bc7b226e">
											<gml:posList>35.67045644648819 139.7441307889982 39.755 35.67038736894268 139.74411143547866 39.755 35.67038736894268 139.74411143547866 34.802 35.67045644648819 139.7441307889982 34.802 35.67045644648819 139.7441307889982 39.755</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0163704e-7845-4f12-bece-4a8098d8cff2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0163704e-7845-4f12-bece-4a8098d8cff2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0163704e-7845-4f12-bece-4a8098d8cff2">
											<gml:posList>35.67040269097005 139.7441826778702 34.802 35.67040269097005 139.7441826778702 41.563 35.670425700093396 139.7441908928005 41.563 35.670425700093396 139.7441908928005 34.802 35.67040269097005 139.7441826778702 34.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-073e24a9-56ab-4d02-84cb-355c70e786a2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-073e24a9-56ab-4d02-84cb-355c70e786a2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-073e24a9-56ab-4d02-84cb-355c70e786a2">
											<gml:posList>35.67040269097005 139.7441826778702 34.802 35.670400076129795 139.74419369390148 34.802 35.670400076129795 139.74419369390148 41.563 35.67040269097005 139.7441826778702 41.563 35.67040269097005 139.7441826778702 34.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cb13861e-c51b-4576-86ea-c97db220a2a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb13861e-c51b-4576-86ea-c97db220a2a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb13861e-c51b-4576-86ea-c97db220a2a5">
											<gml:posList>35.670364332299705 139.74418776866156 34.802 35.670364332299705 139.74418776866156 41.563 35.670400076129795 139.74419369390148 41.563 35.670400076129795 139.74419369390148 34.802 35.670364332299705 139.74418776866156 34.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3c511957-e1c6-4817-a560-84321d17f32c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c511957-e1c6-4817-a560-84321d17f32c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c511957-e1c6-4817-a560-84321d17f32c">
											<gml:posList>35.67035862633695 139.74421175642937 36.8 35.67035786254135 139.7442149606928 36.8 35.67035786254135 139.7442149606928 41.563 35.670364332299705 139.74418776866156 41.563 35.670364332299705 139.74418776866156 34.802 35.67035862633695 139.74421175642937 34.802 35.67035862633695 139.74421175642937 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-be5cff21-21da-4737-bfbd-92cba3357a57">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-be5cff21-21da-4737-bfbd-92cba3357a57">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-be5cff21-21da-4737-bfbd-92cba3357a57">
											<gml:posList>35.67035862633695 139.74421175642937 34.802 35.67033805179505 139.74420472074272 34.802 35.67033805179505 139.74420472074272 36.8 35.67035862633695 139.74421175642937 36.8 35.67035862633695 139.74421175642937 34.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-25d5ff8b-7fa3-4fc5-afd5-a26bff53b564">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25d5ff8b-7fa3-4fc5-afd5-a26bff53b564">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25d5ff8b-7fa3-4fc5-afd5-a26bff53b564">
											<gml:posList>35.67033514216923 139.7442071651992 7.41 35.67035786254135 139.7442149606928 7.41 35.67035786254135 139.7442149606928 36.8 35.67033514216923 139.7442071651992 36.8 35.67033514216923 139.7442071651992 7.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6e087d06-72b2-47ea-b3e0-08ff32182dce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e087d06-72b2-47ea-b3e0-08ff32182dce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e087d06-72b2-47ea-b3e0-08ff32182dce">
											<gml:posList>35.67041606735398 139.74423139911693 36.8 35.670425700093396 139.7441908928005 34.802 35.670425700093396 139.7441908928005 41.563 35.67041606735398 139.74423139911693 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ed602d1e-6398-440c-90ca-e97072540a89">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed602d1e-6398-440c-90ca-e97072540a89">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed602d1e-6398-440c-90ca-e97072540a89">
											<gml:posList>35.67041606735398 139.74423139911693 36.8 35.67041606735398 139.74423139911693 34.802 35.670425700093396 139.7441908928005 34.802 35.67041606735398 139.74423139911693 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-83c8f954-236f-42d7-a533-05049d003b44">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83c8f954-236f-42d7-a533-05049d003b44">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83c8f954-236f-42d7-a533-05049d003b44">
											<gml:posList>35.67041606735398 139.74423139911693 36.8 35.670425700093396 139.7441908928005 41.563 35.67041530360691 139.74423466966002 41.563 35.67041606735398 139.74423139911693 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7fc4bb07-0997-4197-85c8-535e15efaa5f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7fc4bb07-0997-4197-85c8-535e15efaa5f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7fc4bb07-0997-4197-85c8-535e15efaa5f">
											<gml:posList>35.67041530360691 139.74423466966002 41.563 35.67035786254135 139.7442149606928 41.563 35.67035786254135 139.7442149606928 36.8 35.67041530360691 139.74423466966002 36.8 35.67041530360691 139.74423466966002 41.563</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-35e0b4f0-57ea-479f-a7bb-539777377c2d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-35e0b4f0-57ea-479f-a7bb-539777377c2d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-35e0b4f0-57ea-479f-a7bb-539777377c2d">
											<gml:posList>35.67035786254135 139.7442149606928 7.41 35.67041529459318 139.74423466967002 7.41 35.67041530360691 139.74423466966002 36.8 35.67035786254135 139.7442149606928 36.8 35.67035786254135 139.7442149606928 7.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-96675ca9-ea91-436d-b6d9-cbc71688f525">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96675ca9-ea91-436d-b6d9-cbc71688f525">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96675ca9-ea91-436d-b6d9-cbc71688f525">
											<gml:posList>35.67041606735398 139.74423139911693 36.8 35.67041530360691 139.74423466966002 41.563 35.67041530360691 139.74423466966002 36.8 35.67041606735398 139.74423139911693 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bc8963be-4156-4223-8c46-4310e0c2bb8c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc8963be-4156-4223-8c46-4310e0c2bb8c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc8963be-4156-4223-8c46-4310e0c2bb8c">
											<gml:posList>35.67041606735398 139.74423139911693 36.8 35.67046313995381 139.7442474964532 36.8 35.67046313995381 139.7442474964532 34.802 35.67041606735398 139.74423139911693 34.802 35.67041606735398 139.74423139911693 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6f2048c1-4936-4ed1-a20d-a7afd091d66e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f2048c1-4936-4ed1-a20d-a7afd091d66e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f2048c1-4936-4ed1-a20d-a7afd091d66e">
											<gml:posList>35.67041529459318 139.74423466967002 7.41 35.67046542366205 139.7442518682393 7.41 35.67046542366205 139.7442518682393 36.8 35.67041530360691 139.74423466966002 36.8 35.67041529459318 139.74423466967002 7.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-11395</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">386.99145</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.22</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>