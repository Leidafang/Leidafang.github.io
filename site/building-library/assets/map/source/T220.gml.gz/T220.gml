<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_3ce75eae-5f95-4a84-bdab-0397d998fbb6">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">32.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>12</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.672750661294494 139.73839567679622 0 35.67271892716578 139.73829690270446 0 35.672575654444145 139.73836604727467 0 35.672587627011495 139.73840330419725 0 35.67255775997022 139.73842038440358 0 35.67257814643999 139.73847430063105 0 35.6726491531889 139.73843567512588 0 35.67267392974929 139.73851300496466 0 35.672831109696666 139.73843110738497 0 35.67281045362984 139.73836681856605 0 35.672750661294494 139.73839567679622 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
							<gml:interior>
								<gml:LinearRing>
									<gml:posList>35.67267554278881 139.7383752191207 0 35.67268166957371 139.7383719862636 0 35.67267960981098 139.7383661119249 0 35.67270642350247 139.73835196263346 0 35.672722205908016 139.73839688143065 0 35.67268925641164 139.73841426357527 0 35.67267554278881 139.7383752191207 0</gml:posList>
								</gml:LinearRing>
							</gml:interior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672750661294494 139.73839567679622 8.98 35.67281045362984 139.73836681856605 8.98 35.672831109696666 139.73843110738497 8.98 35.67267392974929 139.73851300496466 8.98 35.6726491531889 139.73843567512588 8.98 35.67257814643999 139.73847430063105 8.98 35.67255775997022 139.73842038440358 8.98 35.672587627011495 139.73840330419725 8.98 35.672575654444145 139.73836604727467 8.98 35.67271892716578 139.73829690270446 8.98 35.672750661294494 139.73839567679622 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
									<gml:interior>
										<gml:LinearRing>
											<gml:posList>35.67267554278881 139.7383752191207 8.98 35.67268925641164 139.73841426357527 8.98 35.672722205908016 139.73839688143065 8.98 35.67270642350247 139.73835196263346 8.98 35.67267960981098 139.7383661119249 8.98 35.67268166957371 139.7383719862636 8.98 35.67267554278881 139.7383752191207 8.98</gml:posList>
										</gml:LinearRing>
									</gml:interior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672750661294494 139.73839567679622 8.98 35.67271892716578 139.73829690270446 8.98 35.67271892716578 139.73829690270446 41.150000000000006 35.672750661294494 139.73839567679622 41.150000000000006 35.672750661294494 139.73839567679622 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67271892716578 139.73829690270446 8.98 35.672575654444145 139.73836604727467 8.98 35.672575654444145 139.73836604727467 41.150000000000006 35.67271892716578 139.73829690270446 41.150000000000006 35.67271892716578 139.73829690270446 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672575654444145 139.73836604727467 8.98 35.672587627011495 139.73840330419725 8.98 35.672587627011495 139.73840330419725 41.150000000000006 35.672575654444145 139.73836604727467 41.150000000000006 35.672575654444145 139.73836604727467 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672587627011495 139.73840330419725 8.98 35.67255775997022 139.73842038440358 8.98 35.67255775997022 139.73842038440358 41.150000000000006 35.672587627011495 139.73840330419725 41.150000000000006 35.672587627011495 139.73840330419725 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67255775997022 139.73842038440358 8.98 35.67257814643999 139.73847430063105 8.98 35.67257814643999 139.73847430063105 41.150000000000006 35.67255775997022 139.73842038440358 41.150000000000006 35.67255775997022 139.73842038440358 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67257814643999 139.73847430063105 8.98 35.6726491531889 139.73843567512588 8.98 35.6726491531889 139.73843567512588 41.150000000000006 35.67257814643999 139.73847430063105 41.150000000000006 35.67257814643999 139.73847430063105 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6726491531889 139.73843567512588 8.98 35.67267392974929 139.73851300496466 8.98 35.67267392974929 139.73851300496466 41.150000000000006 35.6726491531889 139.73843567512588 41.150000000000006 35.6726491531889 139.73843567512588 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67267392974929 139.73851300496466 8.98 35.672831109696666 139.73843110738497 8.98 35.672831109696666 139.73843110738497 41.150000000000006 35.67267392974929 139.73851300496466 41.150000000000006 35.67267392974929 139.73851300496466 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672831109696666 139.73843110738497 8.98 35.67281045362984 139.73836681856605 8.98 35.67281045362984 139.73836681856605 41.150000000000006 35.672831109696666 139.73843110738497 41.150000000000006 35.672831109696666 139.73843110738497 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67281045362984 139.73836681856605 8.98 35.672750661294494 139.73839567679622 8.98 35.672750661294494 139.73839567679622 41.150000000000006 35.67281045362984 139.73836681856605 41.150000000000006 35.67281045362984 139.73836681856605 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67267554278881 139.7383752191207 8.98 35.67268166957371 139.7383719862636 8.98 35.67268166957371 139.7383719862636 41.150000000000006 35.67267554278881 139.7383752191207 41.150000000000006 35.67267554278881 139.7383752191207 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67268166957371 139.7383719862636 8.98 35.67267960981098 139.7383661119249 8.98 35.67267960981098 139.7383661119249 41.150000000000006 35.67268166957371 139.7383719862636 41.150000000000006 35.67268166957371 139.7383719862636 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67267960981098 139.7383661119249 8.98 35.67270642350247 139.73835196263346 8.98 35.67270642350247 139.73835196263346 41.150000000000006 35.67267960981098 139.7383661119249 41.150000000000006 35.67267960981098 139.7383661119249 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67270642350247 139.73835196263346 8.98 35.672722205908016 139.73839688143065 8.98 35.672722205908016 139.73839688143065 41.150000000000006 35.67270642350247 139.73835196263346 41.150000000000006 35.67270642350247 139.73835196263346 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672722205908016 139.73839688143065 8.98 35.67268925641164 139.73841426357527 8.98 35.67268925641164 139.73841426357527 41.150000000000006 35.672722205908016 139.73839688143065 41.150000000000006 35.672722205908016 139.73839688143065 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67268925641164 139.73841426357527 8.98 35.67267554278881 139.7383752191207 8.98 35.67267554278881 139.7383752191207 41.150000000000006 35.67268925641164 139.73841426357527 41.150000000000006 35.67268925641164 139.73841426357527 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672750661294494 139.73839567679622 41.150000000000006 35.67271892716578 139.73829690270446 41.150000000000006 35.672575654444145 139.73836604727467 41.150000000000006 35.672587627011495 139.73840330419725 41.150000000000006 35.67255775997022 139.73842038440358 41.150000000000006 35.67257814643999 139.73847430063105 41.150000000000006 35.6726491531889 139.73843567512588 41.150000000000006 35.67267392974929 139.73851300496466 41.150000000000006 35.672831109696666 139.73843110738497 41.150000000000006 35.67281045362984 139.73836681856605 41.150000000000006 35.672750661294494 139.73839567679622 41.150000000000006</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
									<gml:interior>
										<gml:LinearRing>
											<gml:posList>35.67267554278881 139.7383752191207 41.150000000000006 35.67268166957371 139.7383719862636 41.150000000000006 35.67267960981098 139.7383661119249 41.150000000000006 35.67270642350247 139.73835196263346 41.150000000000006 35.672722205908016 139.73839688143065 41.150000000000006 35.67268925641164 139.73841426357527 41.150000000000006 35.67267554278881 139.7383752191207 41.150000000000006</gml:posList>
										</gml:LinearRing>
									</gml:interior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-2eef256e-f8b4-475d-8657-5b5d2732c330"/>
							<gml:surfaceMember xlink:href="#poly-9a38b112-e743-44fc-ab27-fa437215258d"/>
							<gml:surfaceMember xlink:href="#poly-3f13afa2-dac0-4b9d-a1ad-8e833458a129"/>
							<gml:surfaceMember xlink:href="#poly-9868aa54-24d5-46c9-a1b5-0357d7d70dce"/>
							<gml:surfaceMember xlink:href="#poly-dbbc5cc7-b4a5-4aca-8a24-4f5ae3899a33"/>
							<gml:surfaceMember xlink:href="#poly-539c4290-8190-4c94-94e9-ef602cdf7db8"/>
							<gml:surfaceMember xlink:href="#poly-1d2fd360-c826-4ead-b35d-90247726d939"/>
							<gml:surfaceMember xlink:href="#poly-da7ed1db-9fb8-49e3-935f-e83ea549cc08"/>
							<gml:surfaceMember xlink:href="#poly-5c022347-b638-4d9a-9f88-0c870220952f"/>
							<gml:surfaceMember xlink:href="#poly-23372a63-3744-493a-836f-e55a919bd196"/>
							<gml:surfaceMember xlink:href="#poly-39132143-d6b1-433b-acd1-524fbcc83e20"/>
							<gml:surfaceMember xlink:href="#poly-962e90af-4416-480a-85ab-da7a6525ff5f"/>
							<gml:surfaceMember xlink:href="#poly-ab533daf-5b37-4eb4-82b8-002fd55e86e5"/>
							<gml:surfaceMember xlink:href="#poly-3de902c0-d655-4d54-9e7b-6e2e5c1cc453"/>
							<gml:surfaceMember xlink:href="#poly-6642584b-8158-4ba1-80db-c9498201af45"/>
							<gml:surfaceMember xlink:href="#poly-6956220c-0193-49dc-bdc8-d325711bed81"/>
							<gml:surfaceMember xlink:href="#poly-74cc64fe-ed0a-459b-acc4-bf30d8b9d879"/>
							<gml:surfaceMember xlink:href="#poly-e76a0a76-d430-4644-babc-4515c44e4301"/>
							<gml:surfaceMember xlink:href="#poly-2c22256e-14c7-4c70-8949-085649911cc4"/>
							<gml:surfaceMember xlink:href="#poly-17e45cb8-709c-42d7-a686-7904113c221b"/>
							<gml:surfaceMember xlink:href="#poly-61094050-abef-4dc5-bf30-08e4484d24bd"/>
							<gml:surfaceMember xlink:href="#poly-10b2e10e-8611-473b-af7c-811c8191c61c"/>
							<gml:surfaceMember xlink:href="#poly-9f1dd6db-d8cc-40c9-a414-1c9574947f10"/>
							<gml:surfaceMember xlink:href="#poly-1339fecb-c1eb-46c4-bf7e-38cbbef98271"/>
							<gml:surfaceMember xlink:href="#poly-1ec31001-5cbc-43fa-9252-c82154495c4d"/>
							<gml:surfaceMember xlink:href="#poly-50884058-d5d9-49b2-a90b-f9d3b8948e2f"/>
							<gml:surfaceMember xlink:href="#poly-283e9db5-b184-4f98-843c-b147a3f2eba1"/>
							<gml:surfaceMember xlink:href="#poly-2e11c44c-74a0-450b-8746-21cd3b09a1d2"/>
							<gml:surfaceMember xlink:href="#poly-106f39ca-a3e8-4ba1-b3ee-267bba280bd8"/>
							<gml:surfaceMember xlink:href="#poly-8d6cb693-83de-4fda-aa38-be8969530aa2"/>
							<gml:surfaceMember xlink:href="#poly-c53c27b4-6865-4f56-8aab-1559151eed2f"/>
							<gml:surfaceMember xlink:href="#poly-ef51848a-6041-4191-b238-8b41b3bad748"/>
							<gml:surfaceMember xlink:href="#poly-4844d8f2-7e32-46cf-805b-c2cc3f059910"/>
							<gml:surfaceMember xlink:href="#poly-18566194-941b-4403-87a1-244b2f1c8b83"/>
							<gml:surfaceMember xlink:href="#poly-09bfc1b1-bfe5-4b8e-936b-9cac48c6b6e7"/>
							<gml:surfaceMember xlink:href="#poly-24058fb0-381f-4d2f-b7c0-0cfa1f64530d"/>
							<gml:surfaceMember xlink:href="#poly-d8cb323a-e4b0-49b7-9d26-4612c8d89f54"/>
							<gml:surfaceMember xlink:href="#poly-52c546be-62b6-48b2-a312-32da0ff614b0"/>
							<gml:surfaceMember xlink:href="#poly-077bdd36-ea8e-49a4-8cb7-977346f7adaf"/>
							<gml:surfaceMember xlink:href="#poly-b5d4413f-d4a9-4242-9f36-0bddcce4b100"/>
							<gml:surfaceMember xlink:href="#poly-9aa5f6cc-c95a-4fa7-8b59-a6706c04d21e"/>
							<gml:surfaceMember xlink:href="#poly-631dbd9e-5430-4308-be79-7ab961c6a17e"/>
							<gml:surfaceMember xlink:href="#poly-5a7223c1-402e-4c50-9e6e-7000367d947a"/>
							<gml:surfaceMember xlink:href="#poly-91b67d5f-66a6-4dfd-bba4-c6ebef176b03"/>
							<gml:surfaceMember xlink:href="#poly-2c54e560-fa51-4a9f-a156-85c458f0c034"/>
							<gml:surfaceMember xlink:href="#poly-6a0cac40-5363-412d-b2c6-885e60279913"/>
							<gml:surfaceMember xlink:href="#poly-390b2878-75a7-480d-b0dd-0393da6ca4c7"/>
							<gml:surfaceMember xlink:href="#poly-1087b452-dd4d-4e84-ac72-1d133fa9740b"/>
							<gml:surfaceMember xlink:href="#poly-1edd8b67-3d19-474c-aad2-66cb13e81c4c"/>
							<gml:surfaceMember xlink:href="#poly-1b87dadc-09c4-4de2-9323-5d47390fae3c"/>
							<gml:surfaceMember xlink:href="#poly-a6e487be-acd2-4652-85a9-a47e3a41e43d"/>
							<gml:surfaceMember xlink:href="#poly-29b9d318-e07a-4372-850d-fbdb1f30015a"/>
							<gml:surfaceMember xlink:href="#poly-71c8b8f0-d171-4cf7-af03-95f52367036b"/>
							<gml:surfaceMember xlink:href="#poly-f868e7e5-4c06-461d-b058-a96c016e12aa"/>
							<gml:surfaceMember xlink:href="#poly-443d36e8-b5e5-4cb9-9d3d-302c0daf3093"/>
							<gml:surfaceMember xlink:href="#poly-8f13e024-7d41-44c6-ba82-aecb5f1d720e"/>
							<gml:surfaceMember xlink:href="#poly-449407b2-1e73-42be-ab1e-a12b6b00b209"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_3ce75eae-5f95-4a84-bdab-0397d998fbb6_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82368630-04b0-4c15-85f5-5544fe4b259a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67264727475709 139.7383511158438 43.417 35.67265485241023 139.73834745045065 43.417 35.67265774391933 139.73835647207497 43.417 35.67265016626592 139.73836013746742 43.417 35.67264727475709 139.7383511158438 43.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc5aace8-09f4-418b-ac0d-7c42db59b789">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bc5aace8-09f4-418b-ac0d-7c42db59b789_0">
											<gml:posList>35.67265016626592 139.73836013746742 43.417 35.67265016626592 139.73836013746742 45.497 35.67264727475709 139.7383511158438 45.497 35.67264727475709 139.7383511158438 43.417 35.67265016626592 139.73836013746742 43.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6a2acd4-604f-48cc-b8a5-3e59883f988a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d6a2acd4-604f-48cc-b8a5-3e59883f988a_0">
											<gml:posList>35.67264727475709 139.7383511158438 43.417 35.67264727475709 139.7383511158438 45.497 35.67265485241023 139.73834745045065 45.497 35.67265485241023 139.73834745045065 43.417 35.67264727475709 139.7383511158438 43.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cbdb9690-6660-4451-85a4-ae5d13c0728e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cbdb9690-6660-4451-85a4-ae5d13c0728e_0">
											<gml:posList>35.67265774391933 139.73835647207497 45.497 35.67265485241023 139.73834745045065 45.497 35.67264727475709 139.7383511158438 45.497 35.67265016626592 139.73836013746742 45.497 35.67265774391933 139.73835647207497 45.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58f1feec-6ab1-4965-95f6-458f87c50a54">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-58f1feec-6ab1-4965-95f6-458f87c50a54_0">
											<gml:posList>35.67265774391933 139.73835647207497 43.417 35.67265774391933 139.73835647207497 45.497 35.67265016626592 139.73836013746742 45.497 35.67265016626592 139.73836013746742 43.417 35.67265774391933 139.73835647207497 43.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-83a22636-851c-4d13-a608-0a63ccaf73de">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-83a22636-851c-4d13-a608-0a63ccaf73de_0">
											<gml:posList>35.67265485241023 139.73834745045065 43.417 35.67265485241023 139.73834745045065 45.497 35.67265774391933 139.73835647207497 45.497 35.67265774391933 139.73835647207497 43.417 35.67265485241023 139.73834745045065 43.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-2eef256e-f8b4-475d-8657-5b5d2732c330">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2eef256e-f8b4-475d-8657-5b5d2732c330">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2eef256e-f8b4-475d-8657-5b5d2732c330">
											<gml:posList>35.67268925641163 139.73841426357524 8.98 35.672673929749244 139.73851300496466 8.98 35.6726491531889 139.73843567512586 8.98 35.6726755427888 139.7383752191207 8.98 35.67268925641163 139.73841426357524 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-9a38b112-e743-44fc-ab27-fa437215258d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a38b112-e743-44fc-ab27-fa437215258d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a38b112-e743-44fc-ab27-fa437215258d">
											<gml:posList>35.672706423502476 139.73835196263346 8.98 35.67271892716576 139.73829690270446 8.98 35.67275066129449 139.73839567679622 8.98 35.67272220590801 139.73839688143065 8.98 35.672706423502476 139.73835196263346 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-3f13afa2-dac0-4b9d-a1ad-8e833458a129">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f13afa2-dac0-4b9d-a1ad-8e833458a129">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f13afa2-dac0-4b9d-a1ad-8e833458a129">
											<gml:posList>35.672673929749244 139.73851300496466 8.98 35.67268925641163 139.73841426357524 8.98 35.67272220590801 139.73839688143065 8.98 35.67275066129449 139.73839567679622 8.98 35.67281045362984 139.73836681856605 8.98 35.67283110969666 139.73843110738497 8.98 35.672673929749244 139.73851300496466 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-9868aa54-24d5-46c9-a1b5-0357d7d70dce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9868aa54-24d5-46c9-a1b5-0357d7d70dce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9868aa54-24d5-46c9-a1b5-0357d7d70dce">
											<gml:posList>35.6726755427888 139.7383752191207 8.98 35.6726491531889 139.73843567512586 8.98 35.67257814643996 139.73847430063103 8.98 35.67255775997019 139.73842038440355 8.98 35.6725876270115 139.73840330419725 8.98 35.672575654444145 139.73836604727467 8.98 35.67271892716576 139.73829690270446 8.98 35.672706423502476 139.73835196263346 8.98 35.67267960981098 139.73836611192488 8.98 35.672681669573706 139.7383719862636 8.98 35.6726755427888 139.7383752191207 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dbbc5cc7-b4a5-4aca-8a24-4f5ae3899a33">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dbbc5cc7-b4a5-4aca-8a24-4f5ae3899a33">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dbbc5cc7-b4a5-4aca-8a24-4f5ae3899a33">
											<gml:posList>35.67257814643996 139.73847430063103 43.681 35.67257964791054 139.73846944941363 43.681 35.672561772485686 139.73842216919593 43.681 35.67255775997019 139.73842038440355 43.681 35.67257814643996 139.73847430063103 43.681</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-539c4290-8190-4c94-94e9-ef602cdf7db8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-539c4290-8190-4c94-94e9-ef602cdf7db8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-539c4290-8190-4c94-94e9-ef602cdf7db8">
											<gml:posList>35.6725876270115 139.73840330419725 43.681 35.67255775997019 139.73842038440355 43.681 35.672561772485686 139.73842216919593 43.681 35.6725914863724 139.73840518858984 43.681 35.6725876270115 139.73840330419725 43.681</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1d2fd360-c826-4ead-b35d-90247726d939">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d2fd360-c826-4ead-b35d-90247726d939">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d2fd360-c826-4ead-b35d-90247726d939">
											<gml:posList>35.6725876270115 139.73840330419725 43.681 35.6725914863724 139.73840518858984 43.681 35.672579568053465 139.73836814148558 43.681 35.672575654444145 139.73836604727467 43.681 35.6725876270115 139.73840330419725 43.681</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-da7ed1db-9fb8-49e3-935f-e83ea549cc08">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da7ed1db-9fb8-49e3-935f-e83ea549cc08">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da7ed1db-9fb8-49e3-935f-e83ea549cc08">
											<gml:posList>35.6726491531889 139.73843567512586 43.681 35.67265081683518 139.7384307353389 43.681 35.67257964791054 139.73846944941363 43.681 35.67257814643996 139.73847430063103 43.681 35.6726491531889 139.73843567512586 43.681</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5c022347-b638-4d9a-9f88-0c870220952f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5c022347-b638-4d9a-9f88-0c870220952f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5c022347-b638-4d9a-9f88-0c870220952f">
											<gml:posList>35.672575654444145 139.73836604727467 43.681 35.672579568053465 139.73836814148558 43.681 35.67271722735679 139.73830169893571 43.681 35.67271892716576 139.73829690270446 43.681 35.672575654444145 139.73836604727467 43.681</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-23372a63-3744-493a-836f-e55a919bd196">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-23372a63-3744-493a-836f-e55a919bd196">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-23372a63-3744-493a-836f-e55a919bd196">
											<gml:posList>35.6726755427888 139.7383752191207 43.417 35.672681669573706 139.7383719862636 43.417 35.67267960981098 139.73836611192488 43.417 35.672706423502476 139.73835196263346 43.417 35.67272220590801 139.73839688143065 43.417 35.67268925641163 139.73841426357524 43.417 35.67269682617269 139.73843488962143 43.417 35.672750326437345 139.73840539818823 43.417 35.672747822974735 139.73839695051464 43.417 35.67271722735679 139.73830169893571 43.417 35.672579568053465 139.73836814148558 43.417 35.6725914863724 139.73840518858984 43.417 35.672561772485686 139.73842216919593 43.417 35.67257964791054 139.73846944941363 43.417 35.67265081683518 139.7384307353389 43.417 35.67265664500458 139.73844890005216 43.417 35.67265843458672 139.73845507296855 43.417 35.6726755427888 139.7383752191207 43.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-39132143-d6b1-433b-acd1-524fbcc83e20">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-39132143-d6b1-433b-acd1-524fbcc83e20">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-39132143-d6b1-433b-acd1-524fbcc83e20">
											<gml:posList>35.67266995143738 139.73848597870156 41.379 35.672660979327766 139.7384587153262 41.379 35.67265720421592 139.73846079654942 41.379 35.67266755939169 139.73849309552543 41.379 35.67266995143738 139.73848597870156 41.379</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-962e90af-4416-480a-85ab-da7a6525ff5f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-962e90af-4416-480a-85ab-da7a6525ff5f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-962e90af-4416-480a-85ab-da7a6525ff5f">
											<gml:posList>35.67265843458672 139.73845507296855 43.417 35.67269682617269 139.73843488962143 43.417 35.67268925641163 139.73841426357524 43.417 35.6726755427888 139.7383752191207 43.417 35.67265843458672 139.73845507296855 43.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ab533daf-5b37-4eb4-82b8-002fd55e86e5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab533daf-5b37-4eb4-82b8-002fd55e86e5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab533daf-5b37-4eb4-82b8-002fd55e86e5">
											<gml:posList>35.67269682617269 139.73843488962143 43.417 35.67265843458672 139.73845507296855 43.417 35.67265893141188 139.73845643110909 43.417 35.67269682617269 139.73843488962143 43.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3de902c0-d655-4d54-9e7b-6e2e5c1cc453">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3de902c0-d655-4d54-9e7b-6e2e5c1cc453">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3de902c0-d655-4d54-9e7b-6e2e5c1cc453">
											<gml:posList>35.67265081683518 139.7384307353389 43.681 35.6726491531889 139.73843567512586 43.681 35.67265720421592 139.73846079654942 43.681 35.67275411374931 139.73840735999613 43.681 35.672750326437345 139.73840539818823 43.681 35.67269682617269 139.73843488962143 43.681 35.67265893141188 139.73845643110909 43.681 35.67265843458672 139.73845507296855 43.681 35.67265664500458 139.73844890005216 43.681 35.67265081683518 139.7384307353389 43.681</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6642584b-8158-4ba1-80db-c9498201af45">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6642584b-8158-4ba1-80db-c9498201af45">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6642584b-8158-4ba1-80db-c9498201af45">
											<gml:posList>35.67275066129449 139.73839567679622 43.681 35.67271892716576 139.73829690270446 43.681 35.67271722735679 139.73830169893571 43.681 35.672747822974735 139.73839695051464 43.681 35.67275066129449 139.73839567679622 43.681</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6956220c-0193-49dc-bdc8-d325711bed81">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6956220c-0193-49dc-bdc8-d325711bed81">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6956220c-0193-49dc-bdc8-d325711bed81">
											<gml:posList>35.672808007343455 139.7383737255849 41.039 35.672752134467316 139.73840066810857 41.039 35.67275411374931 139.73840735999613 41.039 35.672660979327766 139.7384587153262 41.039 35.67266995143738 139.73848597870156 41.039 35.67281813658109 139.73840524056962 41.039 35.672808007343455 139.7383737255849 41.039</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-74cc64fe-ed0a-459b-acc4-bf30d8b9d879">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74cc64fe-ed0a-459b-acc4-bf30d8b9d879">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74cc64fe-ed0a-459b-acc4-bf30d8b9d879">
											<gml:posList>35.6728236912263 139.73840801773463 41.379 35.67281813658109 139.73840524056962 41.379 35.67266995143738 139.73848597870156 41.379 35.67266755939169 139.73849309552543 41.379 35.6728236912263 139.73840801773463 41.379</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e76a0a76-d430-4644-babc-4515c44e4301">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e76a0a76-d430-4644-babc-4515c44e4301">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e76a0a76-d430-4644-babc-4515c44e4301">
											<gml:posList>35.67283110969666 139.73843110738497 38.271 35.6728236912263 139.73840801773463 40.856 35.67266755939169 139.73849309552543 40.856 35.67283110969666 139.73843110738497 38.271</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2c22256e-14c7-4c70-8949-085649911cc4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c22256e-14c7-4c70-8949-085649911cc4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c22256e-14c7-4c70-8949-085649911cc4">
											<gml:posList>35.67266755939169 139.73849309552543 40.856 35.672673929749244 139.73851300496466 38.271 35.67283110969666 139.73843110738497 38.271 35.67266755939169 139.73849309552543 40.856</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-17e45cb8-709c-42d7-a686-7904113c221b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17e45cb8-709c-42d7-a686-7904113c221b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17e45cb8-709c-42d7-a686-7904113c221b">
											<gml:posList>35.67275066129449 139.73839567679622 43.681 35.672747822974735 139.73839695051464 43.681 35.672750326437345 139.73840539818823 43.681 35.67275411374931 139.73840735999613 43.681 35.67275066129449 139.73839567679622 43.681</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-61094050-abef-4dc5-bf30-08e4484d24bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61094050-abef-4dc5-bf30-08e4484d24bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61094050-abef-4dc5-bf30-08e4484d24bd">
											<gml:posList>35.672808007343455 139.7383737255849 41.379 35.67281045362984 139.73836681856605 41.379 35.67275066129449 139.73839567679622 41.379 35.672752134467316 139.73840066810857 41.379 35.672808007343455 139.7383737255849 41.379</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-10b2e10e-8611-473b-af7c-811c8191c61c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-10b2e10e-8611-473b-af7c-811c8191c61c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-10b2e10e-8611-473b-af7c-811c8191c61c">
											<gml:posList>35.6728236912263 139.73840801773463 41.379 35.67281045362984 139.73836681856605 41.379 35.672808007343455 139.7383737255849 41.379 35.67281813658109 139.73840524056962 41.379 35.6728236912263 139.73840801773463 41.379</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9f1dd6db-d8cc-40c9-a414-1c9574947f10">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f1dd6db-d8cc-40c9-a414-1c9574947f10">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f1dd6db-d8cc-40c9-a414-1c9574947f10">
											<gml:posList>35.67255775997019 139.73842038440355 8.98 35.67257814643996 139.73847430063103 8.98 35.67257814643996 139.73847430063103 43.681 35.67255775997019 139.73842038440355 43.681 35.67255775997019 139.73842038440355 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1339fecb-c1eb-46c4-bf7e-38cbbef98271">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1339fecb-c1eb-46c4-bf7e-38cbbef98271">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1339fecb-c1eb-46c4-bf7e-38cbbef98271">
											<gml:posList>35.67257964791054 139.73846944941363 43.681 35.67257964791054 139.73846944941363 43.417 35.672561772485686 139.73842216919593 43.417 35.672561772485686 139.73842216919593 43.681 35.67257964791054 139.73846944941363 43.681</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1ec31001-5cbc-43fa-9252-c82154495c4d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ec31001-5cbc-43fa-9252-c82154495c4d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ec31001-5cbc-43fa-9252-c82154495c4d">
											<gml:posList>35.6725876270115 139.73840330419725 8.98 35.67255775997019 139.73842038440355 8.98 35.67255775997019 139.73842038440355 43.681 35.6725876270115 139.73840330419725 43.681 35.6725876270115 139.73840330419725 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-50884058-d5d9-49b2-a90b-f9d3b8948e2f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50884058-d5d9-49b2-a90b-f9d3b8948e2f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50884058-d5d9-49b2-a90b-f9d3b8948e2f">
											<gml:posList>35.672561772485686 139.73842216919593 43.681 35.672561772485686 139.73842216919593 43.417 35.6725914863724 139.73840518858984 43.417 35.6725914863724 139.73840518858984 43.681 35.672561772485686 139.73842216919593 43.681</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-283e9db5-b184-4f98-843c-b147a3f2eba1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-283e9db5-b184-4f98-843c-b147a3f2eba1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-283e9db5-b184-4f98-843c-b147a3f2eba1">
											<gml:posList>35.672575654444145 139.73836604727467 8.98 35.6725876270115 139.73840330419725 8.98 35.6725876270115 139.73840330419725 43.681 35.672575654444145 139.73836604727467 43.681 35.672575654444145 139.73836604727467 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2e11c44c-74a0-450b-8746-21cd3b09a1d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2e11c44c-74a0-450b-8746-21cd3b09a1d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2e11c44c-74a0-450b-8746-21cd3b09a1d2">
											<gml:posList>35.6725914863724 139.73840518858984 43.681 35.6725914863724 139.73840518858984 43.417 35.672579568053465 139.73836814148558 43.417 35.672579568053465 139.73836814148558 43.681 35.6725914863724 139.73840518858984 43.681</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-106f39ca-a3e8-4ba1-b3ee-267bba280bd8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-106f39ca-a3e8-4ba1-b3ee-267bba280bd8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-106f39ca-a3e8-4ba1-b3ee-267bba280bd8">
											<gml:posList>35.67257814643996 139.73847430063103 8.98 35.6726491531889 139.73843567512586 8.98 35.6726491531889 139.73843567512586 43.681 35.67257814643996 139.73847430063103 43.681 35.67257814643996 139.73847430063103 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8d6cb693-83de-4fda-aa38-be8969530aa2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d6cb693-83de-4fda-aa38-be8969530aa2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d6cb693-83de-4fda-aa38-be8969530aa2">
											<gml:posList>35.67265081683518 139.7384307353389 43.681 35.67265081683518 139.7384307353389 43.417 35.67257964791054 139.73846944941363 43.417 35.67257964791054 139.73846944941363 43.681 35.67265081683518 139.7384307353389 43.681</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c53c27b4-6865-4f56-8aab-1559151eed2f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c53c27b4-6865-4f56-8aab-1559151eed2f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c53c27b4-6865-4f56-8aab-1559151eed2f">
											<gml:posList>35.67271892716576 139.73829690270446 8.98 35.672575654444145 139.73836604727467 8.98 35.672575654444145 139.73836604727467 43.681 35.67271892716576 139.73829690270446 43.681 35.67271892716576 139.73829690270446 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ef51848a-6041-4191-b238-8b41b3bad748">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef51848a-6041-4191-b238-8b41b3bad748">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef51848a-6041-4191-b238-8b41b3bad748">
											<gml:posList>35.672579568053465 139.73836814148558 43.681 35.672579568053465 139.73836814148558 43.417 35.67271722735679 139.73830169893571 43.417 35.67271722735679 139.73830169893571 43.681 35.672579568053465 139.73836814148558 43.681</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4844d8f2-7e32-46cf-805b-c2cc3f059910">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4844d8f2-7e32-46cf-805b-c2cc3f059910">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4844d8f2-7e32-46cf-805b-c2cc3f059910">
											<gml:posList>35.67265664500458 139.73844890005216 43.681 35.67265664500458 139.73844890005216 43.417 35.67265081683518 139.7384307353389 43.417 35.67265081683518 139.7384307353389 43.681 35.67265664500458 139.73844890005216 43.681</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-18566194-941b-4403-87a1-244b2f1c8b83">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18566194-941b-4403-87a1-244b2f1c8b83">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18566194-941b-4403-87a1-244b2f1c8b83">
											<gml:posList>35.67265843458672 139.73845507296855 43.681 35.67265843458672 139.73845507296855 43.417 35.67265664500458 139.73844890005216 43.417 35.67265664500458 139.73844890005216 43.681 35.67265843458672 139.73845507296855 43.681</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-09bfc1b1-bfe5-4b8e-936b-9cac48c6b6e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-09bfc1b1-bfe5-4b8e-936b-9cac48c6b6e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-09bfc1b1-bfe5-4b8e-936b-9cac48c6b6e7">
											<gml:posList>35.67265893141188 139.73845643110909 43.681 35.67265893141188 139.73845643110909 43.417 35.67265843458672 139.73845507296855 43.417 35.67265843458672 139.73845507296855 43.681 35.67265893141188 139.73845643110909 43.681</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-24058fb0-381f-4d2f-b7c0-0cfa1f64530d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-24058fb0-381f-4d2f-b7c0-0cfa1f64530d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-24058fb0-381f-4d2f-b7c0-0cfa1f64530d">
											<gml:posList>35.672673929749244 139.73851300496466 8.98 35.672673929749244 139.73851300496466 38.271 35.67266755939169 139.73849309552543 40.856 35.67266755939169 139.73849309552543 41.379 35.67265720421592 139.73846079654942 41.379 35.67265720421592 139.73846079654942 43.681 35.6726491531889 139.73843567512586 43.681 35.6726491531889 139.73843567512586 8.98 35.672673929749244 139.73851300496466 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d8cb323a-e4b0-49b7-9d26-4612c8d89f54">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d8cb323a-e4b0-49b7-9d26-4612c8d89f54">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d8cb323a-e4b0-49b7-9d26-4612c8d89f54">
											<gml:posList>35.67266995143738 139.73848597870156 41.379 35.67266995143738 139.73848597870156 41.039 35.672660979327766 139.7384587153262 41.039 35.672660979327766 139.7384587153262 41.379 35.67266995143738 139.73848597870156 41.379</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-52c546be-62b6-48b2-a312-32da0ff614b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-52c546be-62b6-48b2-a312-32da0ff614b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-52c546be-62b6-48b2-a312-32da0ff614b0">
											<gml:posList>35.67269682617269 139.73843488962143 43.681 35.67269682617269 139.73843488962143 43.417 35.67265893141188 139.73845643110909 43.417 35.67265893141188 139.73845643110909 43.681 35.67269682617269 139.73843488962143 43.681</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-077bdd36-ea8e-49a4-8cb7-977346f7adaf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-077bdd36-ea8e-49a4-8cb7-977346f7adaf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-077bdd36-ea8e-49a4-8cb7-977346f7adaf">
											<gml:posList>35.672681669573706 139.7383719862636 8.98 35.672681669573706 139.7383719862636 43.417 35.6726755427888 139.7383752191207 43.417 35.6726755427888 139.7383752191207 8.98 35.672681669573706 139.7383719862636 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b5d4413f-d4a9-4242-9f36-0bddcce4b100">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b5d4413f-d4a9-4242-9f36-0bddcce4b100">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b5d4413f-d4a9-4242-9f36-0bddcce4b100">
											<gml:posList>35.67267960981098 139.73836611192488 8.98 35.67267960981098 139.73836611192488 43.417 35.672681669573706 139.7383719862636 43.417 35.672681669573706 139.7383719862636 8.98 35.67267960981098 139.73836611192488 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9aa5f6cc-c95a-4fa7-8b59-a6706c04d21e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9aa5f6cc-c95a-4fa7-8b59-a6706c04d21e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9aa5f6cc-c95a-4fa7-8b59-a6706c04d21e">
											<gml:posList>35.67268925641163 139.73841426357524 8.98 35.6726755427888 139.7383752191207 8.98 35.6726755427888 139.7383752191207 43.417 35.67268925641163 139.73841426357524 43.417 35.67268925641163 139.73841426357524 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-631dbd9e-5430-4308-be79-7ab961c6a17e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-631dbd9e-5430-4308-be79-7ab961c6a17e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-631dbd9e-5430-4308-be79-7ab961c6a17e">
											<gml:posList>35.672706423502476 139.73835196263346 8.98 35.672706423502476 139.73835196263346 43.417 35.67267960981098 139.73836611192488 43.417 35.67267960981098 139.73836611192488 8.98 35.672706423502476 139.73835196263346 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5a7223c1-402e-4c50-9e6e-7000367d947a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a7223c1-402e-4c50-9e6e-7000367d947a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a7223c1-402e-4c50-9e6e-7000367d947a">
											<gml:posList>35.67265720421592 139.73846079654942 43.681 35.67265720421592 139.73846079654942 41.379 35.672660979327766 139.7384587153262 41.379 35.672660979327766 139.7384587153262 41.039 35.67275411374931 139.73840735999613 41.039 35.67275411374931 139.73840735999613 43.681 35.67265720421592 139.73846079654942 43.681</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-91b67d5f-66a6-4dfd-bba4-c6ebef176b03">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-91b67d5f-66a6-4dfd-bba4-c6ebef176b03">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-91b67d5f-66a6-4dfd-bba4-c6ebef176b03">
											<gml:posList>35.67268925641163 139.73841426357524 43.417 35.67272220590801 139.73839688143065 43.417 35.67272220590801 139.73839688143065 8.98 35.67268925641163 139.73841426357524 8.98 35.67268925641163 139.73841426357524 43.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2c54e560-fa51-4a9f-a156-85c458f0c034">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c54e560-fa51-4a9f-a156-85c458f0c034">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c54e560-fa51-4a9f-a156-85c458f0c034">
											<gml:posList>35.67272220590801 139.73839688143065 43.417 35.672706423502476 139.73835196263346 43.417 35.672706423502476 139.73835196263346 8.98 35.67272220590801 139.73839688143065 8.98 35.67272220590801 139.73839688143065 43.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6a0cac40-5363-412d-b2c6-885e60279913">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a0cac40-5363-412d-b2c6-885e60279913">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a0cac40-5363-412d-b2c6-885e60279913">
											<gml:posList>35.67269682617269 139.73843488962143 43.417 35.67269682617269 139.73843488962143 43.681 35.672750326437345 139.73840539818823 43.681 35.672750326437345 139.73840539818823 43.417 35.67269682617269 139.73843488962143 43.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-390b2878-75a7-480d-b0dd-0393da6ca4c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-390b2878-75a7-480d-b0dd-0393da6ca4c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-390b2878-75a7-480d-b0dd-0393da6ca4c7">
											<gml:posList>35.67271722735679 139.73830169893571 43.681 35.67271722735679 139.73830169893571 43.417 35.672747822974735 139.73839695051464 43.417 35.672747822974735 139.73839695051464 43.681 35.67271722735679 139.73830169893571 43.681</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1087b452-dd4d-4e84-ac72-1d133fa9740b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1087b452-dd4d-4e84-ac72-1d133fa9740b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1087b452-dd4d-4e84-ac72-1d133fa9740b">
											<gml:posList>35.67271892716576 139.73829690270446 43.681 35.67275066129449 139.73839567679622 43.681 35.67275066129449 139.73839567679622 41.379 35.67275066129449 139.73839567679622 8.98 35.67271892716576 139.73829690270446 8.98 35.67271892716576 139.73829690270446 43.681</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1edd8b67-3d19-474c-aad2-66cb13e81c4c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1edd8b67-3d19-474c-aad2-66cb13e81c4c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1edd8b67-3d19-474c-aad2-66cb13e81c4c">
											<gml:posList>35.67281813658109 139.73840524056962 41.379 35.67281813658109 139.73840524056962 41.039 35.67266995143738 139.73848597870156 41.039 35.67266995143738 139.73848597870156 41.379 35.67281813658109 139.73840524056962 41.379</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b87dadc-09c4-4de2-9323-5d47390fae3c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b87dadc-09c4-4de2-9323-5d47390fae3c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b87dadc-09c4-4de2-9323-5d47390fae3c">
											<gml:posList>35.6728236912263 139.73840801773463 40.856 35.6728236912263 139.73840801773463 41.379 35.67266755939169 139.73849309552543 41.379 35.67266755939169 139.73849309552543 40.856 35.6728236912263 139.73840801773463 40.856</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a6e487be-acd2-4652-85a9-a47e3a41e43d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a6e487be-acd2-4652-85a9-a47e3a41e43d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a6e487be-acd2-4652-85a9-a47e3a41e43d">
											<gml:posList>35.672747822974735 139.73839695051464 43.681 35.672747822974735 139.73839695051464 43.417 35.672750326437345 139.73840539818823 43.417 35.672750326437345 139.73840539818823 43.681 35.672747822974735 139.73839695051464 43.681</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-29b9d318-e07a-4372-850d-fbdb1f30015a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-29b9d318-e07a-4372-850d-fbdb1f30015a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-29b9d318-e07a-4372-850d-fbdb1f30015a">
											<gml:posList>35.672752134467316 139.73840066810857 41.379 35.67275066129449 139.73839567679622 41.379 35.67275066129449 139.73839567679622 43.681 35.67275411374931 139.73840735999613 43.681 35.67275411374931 139.73840735999613 41.039 35.672752134467316 139.73840066810857 41.039 35.672752134467316 139.73840066810857 41.379</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-71c8b8f0-d171-4cf7-af03-95f52367036b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-71c8b8f0-d171-4cf7-af03-95f52367036b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-71c8b8f0-d171-4cf7-af03-95f52367036b">
											<gml:posList>35.672673929749244 139.73851300496466 8.98 35.67283110969666 139.73843110738497 8.98 35.67283110969666 139.73843110738497 38.271 35.672673929749244 139.73851300496466 38.271 35.672673929749244 139.73851300496466 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f868e7e5-4c06-461d-b058-a96c016e12aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f868e7e5-4c06-461d-b058-a96c016e12aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f868e7e5-4c06-461d-b058-a96c016e12aa">
											<gml:posList>35.672752134467316 139.73840066810857 41.379 35.672752134467316 139.73840066810857 41.039 35.672808007343455 139.7383737255849 41.039 35.672808007343455 139.7383737255849 41.379 35.672752134467316 139.73840066810857 41.379</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-443d36e8-b5e5-4cb9-9d3d-302c0daf3093">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-443d36e8-b5e5-4cb9-9d3d-302c0daf3093">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-443d36e8-b5e5-4cb9-9d3d-302c0daf3093">
											<gml:posList>35.67281045362984 139.73836681856605 8.98 35.67275066129449 139.73839567679622 8.98 35.67275066129449 139.73839567679622 41.379 35.67281045362984 139.73836681856605 41.379 35.67281045362984 139.73836681856605 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8f13e024-7d41-44c6-ba82-aecb5f1d720e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f13e024-7d41-44c6-ba82-aecb5f1d720e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f13e024-7d41-44c6-ba82-aecb5f1d720e">
											<gml:posList>35.672808007343455 139.7383737255849 41.379 35.672808007343455 139.7383737255849 41.039 35.67281813658109 139.73840524056962 41.039 35.67281813658109 139.73840524056962 41.379 35.672808007343455 139.7383737255849 41.379</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-449407b2-1e73-42be-ab1e-a12b6b00b209">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-449407b2-1e73-42be-ab1e-a12b6b00b209">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-449407b2-1e73-42be-ab1e-a12b6b00b209">
											<gml:posList>35.67281045362984 139.73836681856605 8.98 35.67281045362984 139.73836681856605 41.379 35.6728236912263 139.73840801773463 41.379 35.6728236912263 139.73840801773463 40.856 35.67283110969666 139.73843110738497 38.271 35.67283110969666 139.73843110738497 8.98 35.67281045362984 139.73836681856605 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10486</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">234.00475</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>