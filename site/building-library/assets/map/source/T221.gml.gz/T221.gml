<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_3d0ebf32-06d9-4747-a323-534359e459b3">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">25.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.668775936245304 139.7385283625896 0 35.66879587240301 139.7385484428123 0 35.66881829022704 139.7385149467982 0 35.668803919959956 139.7385004824304 0 35.66881809991511 139.73847931248523 0 35.66881528542294 139.73847651011963 0 35.66882032658226 139.73846821962258 0 35.66874464127659 139.7383919810729 0 35.66867243554925 139.73849910254143 0 35.66874586613996 139.73857379734363 0 35.668775936245304 139.7385283625896 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668775936245304 139.7385283625896 16.5 35.66874586613996 139.73857379734363 16.5 35.66867243554925 139.73849910254143 16.5 35.66874464127659 139.7383919810729 16.5 35.66882032658226 139.73846821962258 16.5 35.66881528542294 139.73847651011963 16.5 35.66881809991511 139.73847931248523 16.5 35.668803919959956 139.7385004824304 16.5 35.66881829022704 139.7385149467982 16.5 35.66879587240301 139.7385484428123 16.5 35.668775936245304 139.7385283625896 16.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668775936245304 139.7385283625896 16.5 35.66879587240301 139.7385484428123 16.5 35.66879587240301 139.7385484428123 41.71 35.668775936245304 139.7385283625896 41.71 35.668775936245304 139.7385283625896 16.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66879587240301 139.7385484428123 16.5 35.66881829022704 139.7385149467982 16.5 35.66881829022704 139.7385149467982 41.71 35.66879587240301 139.7385484428123 41.71 35.66879587240301 139.7385484428123 16.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66881829022704 139.7385149467982 16.5 35.668803919959956 139.7385004824304 16.5 35.668803919959956 139.7385004824304 41.71 35.66881829022704 139.7385149467982 41.71 35.66881829022704 139.7385149467982 16.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668803919959956 139.7385004824304 16.5 35.66881809991511 139.73847931248523 16.5 35.66881809991511 139.73847931248523 41.71 35.668803919959956 139.7385004824304 41.71 35.668803919959956 139.7385004824304 16.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66881809991511 139.73847931248523 16.5 35.66881528542294 139.73847651011963 16.5 35.66881528542294 139.73847651011963 41.71 35.66881809991511 139.73847931248523 41.71 35.66881809991511 139.73847931248523 16.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66881528542294 139.73847651011963 16.5 35.66882032658226 139.73846821962258 16.5 35.66882032658226 139.73846821962258 41.71 35.66881528542294 139.73847651011963 41.71 35.66881528542294 139.73847651011963 16.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66882032658226 139.73846821962258 16.5 35.66874464127659 139.7383919810729 16.5 35.66874464127659 139.7383919810729 41.71 35.66882032658226 139.73846821962258 41.71 35.66882032658226 139.73846821962258 16.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66874464127659 139.7383919810729 16.5 35.66867243554925 139.73849910254143 16.5 35.66867243554925 139.73849910254143 41.71 35.66874464127659 139.7383919810729 41.71 35.66874464127659 139.7383919810729 16.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66867243554925 139.73849910254143 16.5 35.66874586613996 139.73857379734363 16.5 35.66874586613996 139.73857379734363 41.71 35.66867243554925 139.73849910254143 41.71 35.66867243554925 139.73849910254143 16.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66874586613996 139.73857379734363 16.5 35.668775936245304 139.7385283625896 16.5 35.668775936245304 139.7385283625896 41.71 35.66874586613996 139.73857379734363 41.71 35.66874586613996 139.73857379734363 16.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668775936245304 139.7385283625896 41.71 35.66879587240301 139.7385484428123 41.71 35.66881829022704 139.7385149467982 41.71 35.668803919959956 139.7385004824304 41.71 35.66881809991511 139.73847931248523 41.71 35.66881528542294 139.73847651011963 41.71 35.66882032658226 139.73846821962258 41.71 35.66874464127659 139.7383919810729 41.71 35.66867243554925 139.73849910254143 41.71 35.66874586613996 139.73857379734363 41.71 35.668775936245304 139.7385283625896 41.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-a6e95699-de53-4293-99b7-0b2dd8d9ec50"/>
							<gml:surfaceMember xlink:href="#poly-66e0742e-dc8f-4aee-a4e6-b8a3f711790e"/>
							<gml:surfaceMember xlink:href="#poly-65262687-989d-4332-99a6-ff40445da197"/>
							<gml:surfaceMember xlink:href="#poly-72693590-4243-4fdc-9763-070da61d2694"/>
							<gml:surfaceMember xlink:href="#poly-509d553e-5c9d-4472-b739-d1cc7b1ed831"/>
							<gml:surfaceMember xlink:href="#poly-12a8bbf4-e84a-4486-8d74-ebe589474601"/>
							<gml:surfaceMember xlink:href="#poly-a6095712-de3f-4d48-8791-c20ec68017b6"/>
							<gml:surfaceMember xlink:href="#poly-264143f4-353a-4e86-aee1-11919ee8f71d"/>
							<gml:surfaceMember xlink:href="#poly-7b0ecdcc-9fde-4c4e-901b-8817399e25b3"/>
							<gml:surfaceMember xlink:href="#poly-7fa21c4e-61be-4d1a-ae9c-ed35e5bf736d"/>
							<gml:surfaceMember xlink:href="#poly-43dfb114-6098-4411-8e7c-928b823fa677"/>
							<gml:surfaceMember xlink:href="#poly-7ea8b76f-3da0-40d3-9ff6-1bd0e4445cbd"/>
							<gml:surfaceMember xlink:href="#poly-08292c7f-fdc2-4513-968e-ed420e8818b4"/>
							<gml:surfaceMember xlink:href="#poly-1cec4044-ab03-45e0-a266-8be00333bb2c"/>
							<gml:surfaceMember xlink:href="#poly-a70509f0-30f1-4b44-a1fd-2a777999e113"/>
							<gml:surfaceMember xlink:href="#poly-552776c3-fa5b-4a13-8f22-5bc527466648"/>
							<gml:surfaceMember xlink:href="#poly-376eff56-47af-4048-bb36-f3b72723e6dd"/>
							<gml:surfaceMember xlink:href="#poly-308bf11d-9b00-4894-9090-955294dfeaea"/>
							<gml:surfaceMember xlink:href="#poly-1bb532d1-dd90-480c-9725-a5ac204d7761"/>
							<gml:surfaceMember xlink:href="#poly-aad3f849-7739-4aa8-b772-3055e10b02d0"/>
							<gml:surfaceMember xlink:href="#poly-372c30d6-8870-4f5f-8ff4-bcbce552293f"/>
							<gml:surfaceMember xlink:href="#poly-fef7401c-c5c7-4d04-bec1-2f1796e27647"/>
							<gml:surfaceMember xlink:href="#poly-c51570a4-3036-4ff7-b1a1-96ef696d50a6"/>
							<gml:surfaceMember xlink:href="#poly-69d8c35b-18d4-493e-870d-b0b103e24f76"/>
							<gml:surfaceMember xlink:href="#poly-c9c2830d-2e59-4b19-8cc9-35acae07d80e"/>
							<gml:surfaceMember xlink:href="#poly-f8dc8a86-d039-4109-a56c-1a55ddaf399e"/>
							<gml:surfaceMember xlink:href="#poly-3e565b4f-c043-4099-8b78-1fdafd7b873d"/>
							<gml:surfaceMember xlink:href="#poly-3cac2fbb-9968-489b-bb50-adb94d644b9a"/>
							<gml:surfaceMember xlink:href="#poly-0facc333-59e5-40b4-8745-2ba23ee78099"/>
							<gml:surfaceMember xlink:href="#poly-0bb5ca1d-f75a-44d0-9d4c-c55c92121e9c"/>
							<gml:surfaceMember xlink:href="#poly-2f5f09eb-3713-4822-b3c1-31dadf54cae1"/>
							<gml:surfaceMember xlink:href="#poly-86cfca5d-b8dc-4a6a-9bcb-4f30828b5ff4"/>
							<gml:surfaceMember xlink:href="#poly-30827cd7-fbdf-4f2e-962f-d54500ef716f"/>
							<gml:surfaceMember xlink:href="#poly-4140b4f3-60ad-4d76-b3e2-e653f5517dbc"/>
							<gml:surfaceMember xlink:href="#poly-4eb66371-c694-4a9d-895b-1e18f8ca601c"/>
							<gml:surfaceMember xlink:href="#poly-be3f35e7-835b-451e-997c-c98f99ea1ac8"/>
							<gml:surfaceMember xlink:href="#poly-19aba00c-7f5d-4eb4-843f-edcbcb77a571"/>
							<gml:surfaceMember xlink:href="#poly-be7f7e23-5728-40ca-a08c-a7697d8068b1"/>
							<gml:surfaceMember xlink:href="#poly-29eec5c0-9cb1-47bb-a631-ed494e37c934"/>
							<gml:surfaceMember xlink:href="#poly-8c822e3d-5256-4aca-a345-385d2908f867"/>
							<gml:surfaceMember xlink:href="#poly-f4c39b19-6f5e-42fd-b99c-3b0b691164a5"/>
							<gml:surfaceMember xlink:href="#poly-770a4ffa-30cd-4dfb-b64c-2c2470a19e7c"/>
							<gml:surfaceMember xlink:href="#poly-a9b50b71-307b-4bf4-8ca8-165206408d88"/>
							<gml:surfaceMember xlink:href="#poly-15c27d9b-287e-45af-b8da-3f8400ad058b"/>
							<gml:surfaceMember xlink:href="#poly-d45b27c2-a2c4-4f84-af4d-096ea9f65b2c"/>
							<gml:surfaceMember xlink:href="#poly-9e75d096-55b4-4466-92fa-9c9008f728e9"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_3d0ebf32-06d9-4747-a323-534359e459b3_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c620daf9-5203-4f95-a7d1-0a480695b9f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c620daf9-5203-4f95-a7d1-0a480695b9f8_0">
											<gml:posList>35.668803919959934 139.7385004824304 42.076 35.668803919959934 139.7385004824304 40.921 35.66882695027364 139.73852366293315 40.922 35.668803919959934 139.7385004824304 42.076</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1fdde6a-605b-4453-b1b9-009d572215ac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d1fdde6a-605b-4453-b1b9-009d572215ac_0">
											<gml:posList>35.66881100543549 139.73848990298708 39.273 35.66881100543549 139.73848990298708 42.076 35.66883406272277 139.73851299508854 40.922 35.66881100543549 139.73848990298708 39.273</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bbd7550d-5d6f-44c9-82cb-d57ea2584ae8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bbd7550d-5d6f-44c9-82cb-d57ea2584ae8_0">
											<gml:posList>35.66877376325933 139.7385275035679 41.772 35.66877376325933 139.7385275035679 42.295 35.66876632102248 139.73852000106234 41.772 35.66877376325933 139.7385275035679 41.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b5295186-c5f0-4057-9562-f1600ada58c0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b5295186-c5f0-4057-9562-f1600ada58c0_0">
											<gml:posList>35.66876632102248 139.73852000106234 41.772 35.66877376325933 139.7385275035679 42.295 35.66876632102248 139.73852000106234 42.347 35.66876632102248 139.73852000106234 41.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-92f01838-5c20-47b7-8240-e76efd5dac3f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-92f01838-5c20-47b7-8240-e76efd5dac3f_0">
											<gml:posList>35.66876632102248 139.73852000106234 42.347 35.66877376325933 139.7385275035679 42.295 35.66877451198986 139.7385282538132 42.347 35.66876632102248 139.73852000106234 42.347</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c1fe915-370c-41da-a185-03518cf79abc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c1fe915-370c-41da-a185-03518cf79abc_0">
											<gml:posList>35.66877376325933 139.7385275035679 42.295 35.66877451198986 139.7385282538132 42.295 35.66877451198986 139.7385282538132 42.347 35.66877376325933 139.7385275035679 42.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d0787d4-70f3-4819-90f0-f806111acf95">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d0787d4-70f3-4819-90f0-f806111acf95_0">
											<gml:posList>35.66877376325933 139.7385275035679 41.772 35.668774510528806 139.73852639808055 42.295 35.66877376325933 139.7385275035679 42.295 35.66877376325933 139.7385275035679 41.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b993013-87a9-4fe4-b313-ca62efd68ed5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b993013-87a9-4fe4-b313-ca62efd68ed5_0">
											<gml:posList>35.66877376325933 139.7385275035679 41.772 35.668774510528806 139.73852639808055 41.772 35.668774510528806 139.73852639808055 42.295 35.66877376325933 139.7385275035679 41.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b358b9dc-e800-4836-b700-a337a2a3a829">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b358b9dc-e800-4836-b700-a337a2a3a829_0">
											<gml:posList>35.6687752502543 139.73852715938253 41.772 35.668774510528806 139.73852639808055 42.295 35.668774510528806 139.73852639808055 41.772 35.6687752502543 139.73852715938253 41.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5ac06272-ad60-43f4-b0e5-0883fb6cf839">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5ac06272-ad60-43f4-b0e5-0883fb6cf839_0">
											<gml:posList>35.6687752502543 139.73852715938253 41.772 35.6687752502543 139.73852715938253 42.295 35.668774510528806 139.73852639808055 42.295 35.6687752502543 139.73852715938253 41.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-41731fa1-c877-4310-bcd3-de2cef4b4dd3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-41731fa1-c877-4310-bcd3-de2cef4b4dd3_0">
											<gml:posList>35.66876632102248 139.73852000106234 41.772 35.66878560578629 139.73849123646372 42.347 35.66878560578629 139.73849123646372 41.772 35.66876632102248 139.73852000106234 41.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf50a70f-6a4d-4b26-84bc-df87d636537f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cf50a70f-6a4d-4b26-84bc-df87d636537f_0">
											<gml:posList>35.66876632102248 139.73852000106234 41.772 35.66876632102248 139.73852000106234 42.347 35.66878560578629 139.73849123646372 42.347 35.66876632102248 139.73852000106234 41.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b2601d6-846f-4222-898e-2c2c3845c2af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6b2601d6-846f-4222-898e-2c2c3845c2af_0">
											<gml:posList>35.66879379676431 139.73849950025962 42.347 35.66876632102248 139.73852000106234 42.347 35.66877451198986 139.7385282538132 42.347 35.66879379676431 139.73849950025962 42.347</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-50dbb524-c932-44ac-885a-b4f11eaa7df8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-50dbb524-c932-44ac-885a-b4f11eaa7df8_0">
											<gml:posList>35.66879379676431 139.73849950025962 42.347 35.66878560578629 139.73849123646372 42.347 35.66876632102248 139.73852000106234 42.347 35.66879379676431 139.73849950025962 42.347</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5282f837-23ed-44a4-b4d6-a5fddce085ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5282f837-23ed-44a4-b4d6-a5fddce085ce_0">
											<gml:posList>35.66877451198986 139.7385282538132 42.347 35.6687752502543 139.73852715938253 42.295 35.66879379676431 139.73849950025962 42.347 35.66877451198986 139.7385282538132 42.347</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac6c75ce-a2f8-451a-876e-a78b967e4901">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ac6c75ce-a2f8-451a-876e-a78b967e4901_0">
											<gml:posList>35.66879379676431 139.73849950025962 42.347 35.6687752502543 139.73852715938253 42.295 35.66879379676431 139.73849950025962 41.772 35.66879379676431 139.73849950025962 42.347</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ecee7ff8-1d71-48d2-aa82-5f6b476bd8e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ecee7ff8-1d71-48d2-aa82-5f6b476bd8e4_0">
											<gml:posList>35.66877451198986 139.7385282538132 42.347 35.66877451198986 139.7385282538132 42.295 35.6687752502543 139.73852715938253 42.295 35.66877451198986 139.7385282538132 42.347</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b81f980-3566-495b-b35e-41e2fc1b2aae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6b81f980-3566-495b-b35e-41e2fc1b2aae_0">
											<gml:posList>35.66879379676431 139.73849950025962 41.772 35.6687752502543 139.73852715938253 42.295 35.6687752502543 139.73852715938253 41.772 35.66879379676431 139.73849950025962 41.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f9a05a69-7fe0-4ffa-a134-7b4588848c74">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f9a05a69-7fe0-4ffa-a134-7b4588848c74_0">
											<gml:posList>35.66878560578629 139.73849123646372 41.772 35.66879379676431 139.73849950025962 42.347 35.66879379676431 139.73849950025962 41.772 35.66878560578629 139.73849123646372 41.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13816ddd-2a36-44b1-8cff-16735a9fdc1e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-13816ddd-2a36-44b1-8cff-16735a9fdc1e_0">
											<gml:posList>35.66878560578629 139.73849123646372 41.772 35.66878560578629 139.73849123646372 42.347 35.66879379676431 139.73849950025962 42.347 35.66878560578629 139.73849123646372 41.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-95693e8a-7224-4e7a-bbf6-5c234ba8671c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-95693e8a-7224-4e7a-bbf6-5c234ba8671c_0">
											<gml:posList>35.668803919959934 139.7385004824304 42.076 35.66881100543549 139.73848990298708 42.076 35.668803919959934 139.7385004824304 40.921 35.668803919959934 139.7385004824304 42.076</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2bf3e8b7-27bc-4fcd-bacb-896fc0a40626">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2bf3e8b7-27bc-4fcd-bacb-896fc0a40626_0">
											<gml:posList>35.668803919959934 139.7385004824304 40.921 35.66881100543549 139.73848990298708 39.273 35.668803919959934 139.7385004824304 16.5 35.668803919959934 139.7385004824304 40.921</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ccfe678b-3960-4b62-8446-f06df7a9af02">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ccfe678b-3960-4b62-8446-f06df7a9af02_0">
											<gml:posList>35.66881100543549 139.73848990298708 39.273 35.668818099915114 139.7384793124852 39.272 35.668818099915114 139.7384793124852 16.5 35.66881100543549 139.73848990298708 39.273</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4cd33fa-30e2-4023-b024-3f149907adee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4cd33fa-30e2-4023-b024-3f149907adee_0">
											<gml:posList>35.66881100543549 139.73848990298708 42.076 35.66881100543549 139.73848990298708 39.273 35.668803919959934 139.7385004824304 40.921 35.66881100543549 139.73848990298708 42.076</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-23117220-4887-4933-b99b-235d91992662">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-23117220-4887-4933-b99b-235d91992662_0">
											<gml:posList>35.668803919959934 139.7385004824304 16.5 35.66881100543549 139.73848990298708 39.273 35.668818099915114 139.7384793124852 16.5 35.668803919959934 139.7385004824304 16.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b912e465-ce13-4a76-b2ee-38b46668da33">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b912e465-ce13-4a76-b2ee-38b46668da33_0">
											<gml:posList>35.66882695027364 139.73852366293315 40.922 35.668803919959934 139.7385004824304 16.5 35.66882695027364 139.73852366293315 16.37 35.66882695027364 139.73852366293315 40.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26aa7778-ccea-4100-b96f-3d8e52cf5bda">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-26aa7778-ccea-4100-b96f-3d8e52cf5bda_0">
											<gml:posList>35.66882695027364 139.73852366293315 16.37 35.668803919959934 139.7385004824304 16.5 35.6688039109462 139.73850048244108 16.37 35.66882695027364 139.73852366293315 16.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61e1be5e-080d-4b01-8add-9d85e75dc4c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-61e1be5e-080d-4b01-8add-9d85e75dc4c6_0">
											<gml:posList>35.66882695027364 139.73852366293315 40.922 35.668803919959934 139.7385004824304 40.921 35.668803919959934 139.7385004824304 16.5 35.66882695027364 139.73852366293315 40.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70eb9ab3-fa37-4203-9d31-020ee3f9f92d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-70eb9ab3-fa37-4203-9d31-020ee3f9f92d_0">
											<gml:posList>35.6688039109462 139.73850048244108 16.37 35.668803919959934 139.7385004824304 16.5 35.668818099915114 139.7384793124852 16.37 35.6688039109462 139.73850048244108 16.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c045c33b-aa40-4046-adf8-0940bc198dbe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c045c33b-aa40-4046-adf8-0940bc198dbe_0">
											<gml:posList>35.668818099915114 139.7384793124852 16.37 35.668803919959934 139.7385004824304 16.5 35.668818099915114 139.7384793124852 16.5 35.668818099915114 139.7384793124852 16.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f77f202-782c-4623-a066-aebaccf69154">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f77f202-782c-4623-a066-aebaccf69154_0">
											<gml:posList>35.668803919959934 139.7385004824304 42.076 35.66883406272277 139.73851299508854 40.922 35.66881100543549 139.73848990298708 42.076 35.668803919959934 139.7385004824304 42.076</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac858df0-95a8-4ea6-8bd2-162a7acc79e7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ac858df0-95a8-4ea6-8bd2-162a7acc79e7_0">
											<gml:posList>35.668803919959934 139.7385004824304 42.076 35.66882695027364 139.73852366293315 40.922 35.66883406272277 139.73851299508854 40.922 35.668803919959934 139.7385004824304 42.076</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1936711-8616-4d4f-ace6-04bd0c752208">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a1936711-8616-4d4f-ace6-04bd0c752208_0">
											<gml:posList>35.66883406272277 139.73851299508854 40.922 35.66884117517096 139.73850232724206 40.922 35.668818099915114 139.7384793124852 39.272 35.66883406272277 139.73851299508854 40.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-552bd2e9-0923-471a-b5bf-c15f81f93909">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-552bd2e9-0923-471a-b5bf-c15f81f93909_0">
											<gml:posList>35.66881100543549 139.73848990298708 39.273 35.66883406272277 139.73851299508854 40.922 35.668818099915114 139.7384793124852 39.272 35.66881100543549 139.73848990298708 39.273</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c83b598-e466-4727-97a1-4eb64c0384ad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8c83b598-e466-4727-97a1-4eb64c0384ad_0">
											<gml:posList>35.66882695027364 139.73852366293315 40.922 35.66882695027364 139.73852366293315 16.37 35.66883406272277 139.73851299508854 40.922 35.66882695027364 139.73852366293315 40.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-895513f0-a171-49bc-ab3a-0abef7e37ba1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-895513f0-a171-49bc-ab3a-0abef7e37ba1_0">
											<gml:posList>35.66883406272277 139.73851299508854 40.922 35.66884117517096 139.73850232724206 16.37 35.66884117517096 139.73850232724206 40.922 35.66883406272277 139.73851299508854 40.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f48e407-3a70-4407-a80c-a064be5e8d6c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5f48e407-3a70-4407-a80c-a064be5e8d6c_0">
											<gml:posList>35.66883406272277 139.73851299508854 40.922 35.66882695027364 139.73852366293315 16.37 35.66884117517096 139.73850232724206 16.37 35.66883406272277 139.73851299508854 40.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-386973eb-f821-46ba-9a43-8051f22bf537">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-386973eb-f821-46ba-9a43-8051f22bf537_0">
											<gml:posList>35.66884117517096 139.73850232724206 40.922 35.66884117517096 139.73850232724206 16.37 35.668818099915114 139.7384793124852 39.272 35.66884117517096 139.73850232724206 40.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5fa36623-8ed9-4308-acff-0ed0c662110c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5fa36623-8ed9-4308-acff-0ed0c662110c_0">
											<gml:posList>35.668818099915114 139.7384793124852 39.272 35.66884117517096 139.73850232724206 16.37 35.668818099915114 139.7384793124852 16.5 35.668818099915114 139.7384793124852 39.272</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dad8e4f4-318b-449a-ab97-031440f1fd09">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dad8e4f4-318b-449a-ab97-031440f1fd09_0">
											<gml:posList>35.66884117517096 139.73850232724206 16.37 35.668818099915114 139.7384793124852 16.37 35.668818099915114 139.7384793124852 16.5 35.66884117517096 139.73850232724206 16.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dbef9b78-8358-4e58-a24a-bd6359858b0b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66882695027364 139.73852366293315 16.37 35.668818099915114 139.7384793124852 16.37 35.66884117517096 139.73850232724206 16.37 35.66882695027364 139.73852366293315 16.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43d2527b-ff27-4fe9-ab6f-c7fff3e14261">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66882695027364 139.73852366293315 16.37 35.6688039109462 139.73850048244108 16.37 35.668818099915114 139.7384793124852 16.37 35.66882695027364 139.73852366293315 16.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b792480-a373-4125-bc95-cedbb8e93a44">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6687752502543 139.73852715938253 41.772 35.668774510528806 139.73852639808055 41.772 35.66879379676431 139.73849950025962 41.772 35.6687752502543 139.73852715938253 41.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37b898f7-9ffc-4264-a64a-347d6a6c3fd2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66879379676431 139.73849950025962 41.772 35.668774510528806 139.73852639808055 41.772 35.66878560578629 139.73849123646372 41.772 35.66879379676431 139.73849950025962 41.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a307071e-dd95-4095-997d-e9a593696a9b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66878560578629 139.73849123646372 41.772 35.668774510528806 139.73852639808055 41.772 35.66876632102248 139.73852000106234 41.772 35.66878560578629 139.73849123646372 41.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a271658-bfbe-4ebe-81c7-e90d2f68cb40">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668774510528806 139.73852639808055 41.772 35.66877376325933 139.7385275035679 41.772 35.66876632102248 139.73852000106234 41.772 35.668774510528806 139.73852639808055 41.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-014df0fa-ec0c-43bc-82b7-5c8692d8708d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66877376325933 139.7385275035679 42.295 35.6687752502543 139.73852715938253 42.295 35.66877451198986 139.7385282538132 42.295 35.66877376325933 139.7385275035679 42.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-34b1fdce-3ab2-450a-8d02-71b071a4fd4b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66877376325933 139.7385275035679 42.295 35.668774510528806 139.73852639808055 42.295 35.6687752502543 139.73852715938253 42.295 35.66877376325933 139.7385275035679 42.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-a6e95699-de53-4293-99b7-0b2dd8d9ec50">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a6e95699-de53-4293-99b7-0b2dd8d9ec50">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a6e95699-de53-4293-99b7-0b2dd8d9ec50">
											<gml:posList>35.668672435549226 139.73849910254143 16.5 35.668744641276554 139.73839198107288 16.5 35.66882032658226 139.73846821962258 16.5 35.668815285422916 139.73847651011963 16.5 35.668818099915114 139.7384793124852 16.5 35.668803919959934 139.7385004824304 16.5 35.668818290227016 139.7385149467982 16.5 35.66879587240301 139.7385484428123 16.5 35.66877593624531 139.7385283625896 16.5 35.668745866139965 139.73857379734363 16.5 35.668672435549226 139.73849910254143 16.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-66e0742e-dc8f-4aee-a4e6-b8a3f711790e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66e0742e-dc8f-4aee-a4e6-b8a3f711790e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66e0742e-dc8f-4aee-a4e6-b8a3f711790e">
											<gml:posList>35.6687742328079 139.73852856343234 42.295 35.66877593624531 139.7385283625896 42.295 35.66877523261821 139.7385276564751 42.295 35.66877352918079 139.73852785731788 42.295 35.6687742328079 139.73852856343234 42.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-65262687-989d-4332-99a6-ff40445da197">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65262687-989d-4332-99a6-ff40445da197">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65262687-989d-4332-99a6-ff40445da197">
											<gml:posList>35.66874480516962 139.73839406857925 42.295 35.668744641276554 139.73839198107288 42.295 35.668672435549226 139.73849910254143 42.295 35.66867413898662 139.7384989016983 42.295 35.66874480516962 139.73839406857925 42.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-72693590-4243-4fdc-9763-070da61d2694">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-72693590-4243-4fdc-9763-070da61d2694">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-72693590-4243-4fdc-9763-070da61d2694">
											<gml:posList>35.66867413898662 139.7384989016983 42.295 35.668672435549226 139.73849910254143 42.295 35.668745866139965 139.73857379734363 42.295 35.6687456932189 139.73857168775547 42.295 35.66867413898662 139.7384989016983 42.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-509d553e-5c9d-4472-b739-d1cc7b1ed831">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-509d553e-5c9d-4472-b739-d1cc7b1ed831">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-509d553e-5c9d-4472-b739-d1cc7b1ed831">
											<gml:posList>35.66881360907029 139.73847676616174 41.772 35.668818659234674 139.73846846460822 41.772 35.66874480516962 139.73839406857925 41.772 35.66867413898662 139.7384989016983 41.772 35.6687456932189 139.73857168775547 41.772 35.6687742328079 139.73852856343234 41.772 35.66877352918079 139.73852785731788 41.772 35.668774510528806 139.73852639808055 41.772 35.66877543969036 139.73852734694117 41.772 35.66878872836155 139.73850753672525 41.772 35.66880841193836 139.73852736318563 41.772 35.668816577767224 139.738515136606 41.772 35.66880220750016 139.73850067223847 41.772 35.66881637845905 139.73847952439647 41.772 35.66881360907029 139.73847676616174 41.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-12a8bbf4-e84a-4486-8d74-ebe589474601">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-12a8bbf4-e84a-4486-8d74-ebe589474601">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-12a8bbf4-e84a-4486-8d74-ebe589474601">
											<gml:posList>35.6687456932189 139.73857168775547 42.295 35.668745866139965 139.73857379734363 42.295 35.66877593624531 139.7385283625896 42.295 35.6687742328079 139.73852856343234 42.295 35.6687456932189 139.73857168775547 42.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a6095712-de3f-4d48-8791-c20ec68017b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a6095712-de3f-4d48-8791-c20ec68017b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a6095712-de3f-4d48-8791-c20ec68017b6">
											<gml:posList>35.66877523261821 139.7385276564751 42.295 35.66877543969036 139.73852734694117 42.295 35.668774510528806 139.73852639808055 42.295 35.66877352918079 139.73852785731788 42.295 35.66877523261821 139.7385276564751 42.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-264143f4-353a-4e86-aee1-11919ee8f71d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-264143f4-353a-4e86-aee1-11919ee8f71d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-264143f4-353a-4e86-aee1-11919ee8f71d">
											<gml:posList>35.668788955957574 139.73851039738045 46.308 35.66878872836155 139.73850753672525 46.308 35.66877523261821 139.7385276564751 46.308 35.66877755795043 139.73852738862075 46.308 35.668788955957574 139.73851039738045 46.308</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7b0ecdcc-9fde-4c4e-901b-8817399e25b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b0ecdcc-9fde-4c4e-901b-8817399e25b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b0ecdcc-9fde-4c4e-901b-8817399e25b3">
											<gml:posList>35.668818659234674 139.73846846460822 42.295 35.66882032658226 139.73846821962258 42.295 35.668744641276554 139.73839198107288 42.295 35.66874480516962 139.73839406857925 42.295 35.668818659234674 139.73846846460822 42.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7fa21c4e-61be-4d1a-ae9c-ed35e5bf736d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7fa21c4e-61be-4d1a-ae9c-ed35e5bf736d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7fa21c4e-61be-4d1a-ae9c-ed35e5bf736d">
											<gml:posList>35.66877755795043 139.73852738862075 46.308 35.66877523261821 139.7385276564751 46.308 35.66879587240301 139.7385484428123 46.308 35.66879563580286 139.73854559321342 46.308 35.66877755795043 139.73852738862075 46.308</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-43dfb114-6098-4411-8e7c-928b823fa677">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-43dfb114-6098-4411-8e7c-928b823fa677">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-43dfb114-6098-4411-8e7c-928b823fa677">
											<gml:posList>35.66877755795043 139.73852738862075 45.827 35.66879563580286 139.73854559321342 45.827 35.66880701577638 139.73852859094714 45.827 35.668788955957574 139.73851039738045 45.827 35.66877755795043 139.73852738862075 45.827</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7ea8b76f-3da0-40d3-9ff6-1bd0e4445cbd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ea8b76f-3da0-40d3-9ff6-1bd0e4445cbd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ea8b76f-3da0-40d3-9ff6-1bd0e4445cbd">
											<gml:posList>35.66880701577638 139.73852859094714 46.308 35.668809350113634 139.738528312036 46.308 35.66878872836155 139.73850753672525 46.308 35.668788955957574 139.73851039738045 46.308 35.66880701577638 139.73852859094714 46.308</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-08292c7f-fdc2-4513-968e-ed420e8818b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-08292c7f-fdc2-4513-968e-ed420e8818b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-08292c7f-fdc2-4513-968e-ed420e8818b4">
											<gml:posList>35.66879563580286 139.73854559321342 46.308 35.66879587240301 139.7385484428123 46.308 35.668809350113634 139.738528312036 46.308 35.66880701577638 139.73852859094714 46.308 35.66879563580286 139.73854559321342 46.308</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1cec4044-ab03-45e0-a266-8be00333bb2c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1cec4044-ab03-45e0-a266-8be00333bb2c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1cec4044-ab03-45e0-a266-8be00333bb2c">
											<gml:posList>35.66881637845905 139.73847952439647 42.295 35.66880220750016 139.73850067223847 42.295 35.668803919959934 139.7385004824304 42.295 35.668818099915114 139.7384793124852 42.295 35.66881637845905 139.73847952439647 42.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a70509f0-30f1-4b44-a1fd-2a777999e113">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a70509f0-30f1-4b44-a1fd-2a777999e113">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a70509f0-30f1-4b44-a1fd-2a777999e113">
											<gml:posList>35.668816577767224 139.738515136606 42.295 35.668818290227016 139.7385149467982 42.295 35.668803919959934 139.7385004824304 42.295 35.66880220750016 139.73850067223847 42.295 35.668816577767224 139.738515136606 42.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-552776c3-fa5b-4a13-8f22-5bc527466648">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-552776c3-fa5b-4a13-8f22-5bc527466648">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-552776c3-fa5b-4a13-8f22-5bc527466648">
											<gml:posList>35.668809350113634 139.738528312036 42.295 35.668818290227016 139.7385149467982 42.295 35.668816577767224 139.738515136606 42.295 35.66880841193836 139.73852736318563 42.295 35.668809350113634 139.738528312036 42.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-376eff56-47af-4048-bb36-f3b72723e6dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-376eff56-47af-4048-bb36-f3b72723e6dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-376eff56-47af-4048-bb36-f3b72723e6dd">
											<gml:posList>35.66881637845905 139.73847952439647 42.295 35.668818099915114 139.7384793124852 42.295 35.668815285422916 139.73847651011963 42.295 35.66881360907029 139.73847676616174 42.295 35.66881637845905 139.73847952439647 42.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-308bf11d-9b00-4894-9090-955294dfeaea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-308bf11d-9b00-4894-9090-955294dfeaea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-308bf11d-9b00-4894-9090-955294dfeaea">
											<gml:posList>35.668818659234674 139.73846846460822 42.295 35.66881360907029 139.73847676616174 42.295 35.668815285422916 139.73847651011963 42.295 35.66882032658226 139.73846821962258 42.295 35.668818659234674 139.73846846460822 42.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1bb532d1-dd90-480c-9725-a5ac204d7761">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1bb532d1-dd90-480c-9725-a5ac204d7761">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1bb532d1-dd90-480c-9725-a5ac204d7761">
											<gml:posList>35.66880701577638 139.73852859094714 45.827 35.66880701577638 139.73852859094714 46.308 35.668788955957574 139.73851039738045 46.308 35.668788955957574 139.73851039738045 45.827 35.66880701577638 139.73852859094714 45.827</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aad3f849-7739-4aa8-b772-3055e10b02d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aad3f849-7739-4aa8-b772-3055e10b02d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aad3f849-7739-4aa8-b772-3055e10b02d0">
											<gml:posList>35.668745866139965 139.73857379734363 42.295 35.668672435549226 139.73849910254143 42.295 35.668672435549226 139.73849910254143 16.5 35.668745866139965 139.73857379734363 16.5 35.668745866139965 139.73857379734363 42.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-372c30d6-8870-4f5f-8ff4-bcbce552293f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-372c30d6-8870-4f5f-8ff4-bcbce552293f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-372c30d6-8870-4f5f-8ff4-bcbce552293f">
											<gml:posList>35.66877755795043 139.73852738862075 45.827 35.66877755795043 139.73852738862075 46.308 35.66879563580286 139.73854559321342 46.308 35.66879563580286 139.73854559321342 45.827 35.66877755795043 139.73852738862075 45.827</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fef7401c-c5c7-4d04-bec1-2f1796e27647">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fef7401c-c5c7-4d04-bec1-2f1796e27647">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fef7401c-c5c7-4d04-bec1-2f1796e27647">
											<gml:posList>35.668744641276554 139.73839198107288 42.295 35.66882032658226 139.73846821962258 42.295 35.66882032658226 139.73846821962258 16.5 35.668744641276554 139.73839198107288 16.5 35.668744641276554 139.73839198107288 42.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c51570a4-3036-4ff7-b1a1-96ef696d50a6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c51570a4-3036-4ff7-b1a1-96ef696d50a6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c51570a4-3036-4ff7-b1a1-96ef696d50a6">
											<gml:posList>35.668818659234674 139.73846846460822 41.772 35.668818659234674 139.73846846460822 42.295 35.66874480516962 139.73839406857925 42.295 35.66874480516962 139.73839406857925 41.772 35.668818659234674 139.73846846460822 41.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-69d8c35b-18d4-493e-870d-b0b103e24f76">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69d8c35b-18d4-493e-870d-b0b103e24f76">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69d8c35b-18d4-493e-870d-b0b103e24f76">
											<gml:posList>35.668672435549226 139.73849910254143 42.295 35.668744641276554 139.73839198107288 42.295 35.668744641276554 139.73839198107288 16.5 35.668672435549226 139.73849910254143 16.5 35.668672435549226 139.73849910254143 42.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c9c2830d-2e59-4b19-8cc9-35acae07d80e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c9c2830d-2e59-4b19-8cc9-35acae07d80e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c9c2830d-2e59-4b19-8cc9-35acae07d80e">
											<gml:posList>35.66874480516962 139.73839406857925 41.772 35.66874480516962 139.73839406857925 42.295 35.66867413898662 139.7384989016983 42.295 35.66867413898662 139.7384989016983 41.772 35.66874480516962 139.73839406857925 41.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f8dc8a86-d039-4109-a56c-1a55ddaf399e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f8dc8a86-d039-4109-a56c-1a55ddaf399e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f8dc8a86-d039-4109-a56c-1a55ddaf399e">
											<gml:posList>35.66882032658226 139.73846821962258 42.295 35.668815285422916 139.73847651011963 42.295 35.668815285422916 139.73847651011963 16.5 35.66882032658226 139.73846821962258 16.5 35.66882032658226 139.73846821962258 42.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3e565b4f-c043-4099-8b78-1fdafd7b873d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e565b4f-c043-4099-8b78-1fdafd7b873d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e565b4f-c043-4099-8b78-1fdafd7b873d">
											<gml:posList>35.66881360907029 139.73847676616174 41.772 35.66881360907029 139.73847676616174 42.295 35.668818659234674 139.73846846460822 42.295 35.668818659234674 139.73846846460822 41.772 35.66881360907029 139.73847676616174 41.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3cac2fbb-9968-489b-bb50-adb94d644b9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3cac2fbb-9968-489b-bb50-adb94d644b9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3cac2fbb-9968-489b-bb50-adb94d644b9a">
											<gml:posList>35.668815285422916 139.73847651011963 42.295 35.668818099915114 139.7384793124852 42.295 35.668818099915114 139.7384793124852 16.5 35.668815285422916 139.73847651011963 16.5 35.668815285422916 139.73847651011963 42.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0facc333-59e5-40b4-8745-2ba23ee78099">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0facc333-59e5-40b4-8745-2ba23ee78099">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0facc333-59e5-40b4-8745-2ba23ee78099">
											<gml:posList>35.66881637845905 139.73847952439647 41.772 35.66881637845905 139.73847952439647 42.295 35.66881360907029 139.73847676616174 42.295 35.66881360907029 139.73847676616174 41.772 35.66881637845905 139.73847952439647 41.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0bb5ca1d-f75a-44d0-9d4c-c55c92121e9c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0bb5ca1d-f75a-44d0-9d4c-c55c92121e9c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0bb5ca1d-f75a-44d0-9d4c-c55c92121e9c">
											<gml:posList>35.668818099915114 139.7384793124852 42.295 35.668803919959934 139.7385004824304 42.295 35.668803919959934 139.7385004824304 16.5 35.668818099915114 139.7384793124852 16.5 35.668818099915114 139.7384793124852 42.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2f5f09eb-3713-4822-b3c1-31dadf54cae1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f5f09eb-3713-4822-b3c1-31dadf54cae1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f5f09eb-3713-4822-b3c1-31dadf54cae1">
											<gml:posList>35.66880220750016 139.73850067223847 41.772 35.66880220750016 139.73850067223847 42.295 35.66881637845905 139.73847952439647 42.295 35.66881637845905 139.73847952439647 41.772 35.66880220750016 139.73850067223847 41.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-86cfca5d-b8dc-4a6a-9bcb-4f30828b5ff4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-86cfca5d-b8dc-4a6a-9bcb-4f30828b5ff4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-86cfca5d-b8dc-4a6a-9bcb-4f30828b5ff4">
											<gml:posList>35.668803919959934 139.7385004824304 42.295 35.668818290227016 139.7385149467982 42.295 35.668818290227016 139.7385149467982 16.5 35.668803919959934 139.7385004824304 16.5 35.668803919959934 139.7385004824304 42.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-30827cd7-fbdf-4f2e-962f-d54500ef716f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-30827cd7-fbdf-4f2e-962f-d54500ef716f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-30827cd7-fbdf-4f2e-962f-d54500ef716f">
											<gml:posList>35.668816577767224 139.738515136606 41.772 35.668816577767224 139.738515136606 42.295 35.66880220750016 139.73850067223847 42.295 35.66880220750016 139.73850067223847 41.772 35.668816577767224 139.738515136606 41.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4140b4f3-60ad-4d76-b3e2-e653f5517dbc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4140b4f3-60ad-4d76-b3e2-e653f5517dbc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4140b4f3-60ad-4d76-b3e2-e653f5517dbc">
											<gml:posList>35.66878872836155 139.73850753672525 46.308 35.66878872836155 139.73850753672525 41.772 35.66877543969036 139.73852734694117 41.772 35.66877543969036 139.73852734694117 42.295 35.66877523261821 139.7385276564751 42.295 35.66877523261821 139.7385276564751 46.308 35.66878872836155 139.73850753672525 46.308</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4eb66371-c694-4a9d-895b-1e18f8ca601c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4eb66371-c694-4a9d-895b-1e18f8ca601c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4eb66371-c694-4a9d-895b-1e18f8ca601c">
											<gml:posList>35.668809350113634 139.738528312036 46.308 35.668809350113634 139.738528312036 42.295 35.66880841193836 139.73852736318563 42.295 35.66880841193836 139.73852736318563 41.772 35.66878872836155 139.73850753672525 41.772 35.66878872836155 139.73850753672525 46.308 35.668809350113634 139.738528312036 46.308</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-be3f35e7-835b-451e-997c-c98f99ea1ac8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-be3f35e7-835b-451e-997c-c98f99ea1ac8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-be3f35e7-835b-451e-997c-c98f99ea1ac8">
											<gml:posList>35.668788955957574 139.73851039738045 45.827 35.668788955957574 139.73851039738045 46.308 35.66877755795043 139.73852738862075 46.308 35.66877755795043 139.73852738862075 45.827 35.668788955957574 139.73851039738045 45.827</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-19aba00c-7f5d-4eb4-843f-edcbcb77a571">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-19aba00c-7f5d-4eb4-843f-edcbcb77a571">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-19aba00c-7f5d-4eb4-843f-edcbcb77a571">
											<gml:posList>35.66880841193836 139.73852736318563 41.772 35.66880841193836 139.73852736318563 42.295 35.668816577767224 139.738515136606 42.295 35.668816577767224 139.738515136606 41.772 35.66880841193836 139.73852736318563 41.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-be7f7e23-5728-40ca-a08c-a7697d8068b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-be7f7e23-5728-40ca-a08c-a7697d8068b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-be7f7e23-5728-40ca-a08c-a7697d8068b1">
											<gml:posList>35.668774510528806 139.73852639808055 41.772 35.668774510528806 139.73852639808055 42.295 35.66877543969036 139.73852734694117 42.295 35.66877543969036 139.73852734694117 41.772 35.668774510528806 139.73852639808055 41.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-29eec5c0-9cb1-47bb-a631-ed494e37c934">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-29eec5c0-9cb1-47bb-a631-ed494e37c934">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-29eec5c0-9cb1-47bb-a631-ed494e37c934">
											<gml:posList>35.66877352918079 139.73852785731788 41.772 35.66877352918079 139.73852785731788 42.295 35.668774510528806 139.73852639808055 42.295 35.668774510528806 139.73852639808055 41.772 35.66877352918079 139.73852785731788 41.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8c822e3d-5256-4aca-a345-385d2908f867">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c822e3d-5256-4aca-a345-385d2908f867">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c822e3d-5256-4aca-a345-385d2908f867">
											<gml:posList>35.6687742328079 139.73852856343234 41.772 35.6687742328079 139.73852856343234 42.295 35.66877352918079 139.73852785731788 42.295 35.66877352918079 139.73852785731788 41.772 35.6687742328079 139.73852856343234 41.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f4c39b19-6f5e-42fd-b99c-3b0b691164a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4c39b19-6f5e-42fd-b99c-3b0b691164a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4c39b19-6f5e-42fd-b99c-3b0b691164a5">
											<gml:posList>35.66879587240301 139.7385484428123 16.5 35.668818290227016 139.7385149467982 16.5 35.668818290227016 139.7385149467982 42.295 35.668809350113634 139.738528312036 42.295 35.668809350113634 139.738528312036 46.308 35.66879587240301 139.7385484428123 46.308 35.66879587240301 139.7385484428123 16.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-770a4ffa-30cd-4dfb-b64c-2c2470a19e7c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-770a4ffa-30cd-4dfb-b64c-2c2470a19e7c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-770a4ffa-30cd-4dfb-b64c-2c2470a19e7c">
											<gml:posList>35.66867413898662 139.7384989016983 41.772 35.66867413898662 139.7384989016983 42.295 35.6687456932189 139.73857168775547 42.295 35.6687456932189 139.73857168775547 41.772 35.66867413898662 139.7384989016983 41.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a9b50b71-307b-4bf4-8ca8-165206408d88">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9b50b71-307b-4bf4-8ca8-165206408d88">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9b50b71-307b-4bf4-8ca8-165206408d88">
											<gml:posList>35.66879563580286 139.73854559321342 45.827 35.66879563580286 139.73854559321342 46.308 35.66880701577638 139.73852859094714 46.308 35.66880701577638 139.73852859094714 45.827 35.66879563580286 139.73854559321342 45.827</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-15c27d9b-287e-45af-b8da-3f8400ad058b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15c27d9b-287e-45af-b8da-3f8400ad058b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15c27d9b-287e-45af-b8da-3f8400ad058b">
											<gml:posList>35.66879587240301 139.7385484428123 46.308 35.66877523261821 139.7385276564751 46.308 35.66877523261821 139.7385276564751 42.295 35.66877593624531 139.7385283625896 42.295 35.66877593624531 139.7385283625896 16.5 35.66879587240301 139.7385484428123 16.5 35.66879587240301 139.7385484428123 46.308</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d45b27c2-a2c4-4f84-af4d-096ea9f65b2c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d45b27c2-a2c4-4f84-af4d-096ea9f65b2c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d45b27c2-a2c4-4f84-af4d-096ea9f65b2c">
											<gml:posList>35.6687456932189 139.73857168775547 41.772 35.6687456932189 139.73857168775547 42.295 35.6687742328079 139.73852856343234 42.295 35.6687742328079 139.73852856343234 41.772 35.6687456932189 139.73857168775547 41.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9e75d096-55b4-4466-92fa-9c9008f728e9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e75d096-55b4-4466-92fa-9c9008f728e9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e75d096-55b4-4466-92fa-9c9008f728e9">
											<gml:posList>35.66877593624531 139.7385283625896 42.295 35.668745866139965 139.73857379734363 42.295 35.668745866139965 139.73857379734363 16.5 35.66877593624531 139.7385283625896 16.5 35.66877593624531 139.7385283625896 42.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7375</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">154.6502</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>