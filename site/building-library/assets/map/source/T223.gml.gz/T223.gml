<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_3d9dab73-c654-4862-859b-7bf515cac0cf">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>永田町二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:measuredHeight uom="m">3.6</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67356996914722 139.740447912281 0 35.67355044957006 139.74042992878216 0 35.67350008110071 139.74051204196016 0 35.67351563180314 139.7405263625606 0 35.67350390166546 139.74054549796014 0 35.67351918176515 139.7405595758537 0 35.673504831906335 139.7405829672559 0 35.67352462206805 139.74060120454277 0 35.67355184537678 139.74055680952003 0 35.673538017515526 139.74054406659045 0 35.67356486272088 139.74050031268726 0 35.673547589168784 139.74048440335426 0 35.67356996914722 139.740447912281 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67356996914722 139.740447912281 9.269 35.673547589168784 139.74048440335426 9.269 35.67356486272088 139.74050031268726 9.269 35.673538017515526 139.74054406659045 9.269 35.67355184537678 139.74055680952003 9.269 35.67352462206805 139.74060120454277 9.269 35.673504831906335 139.7405829672559 9.269 35.67351918176515 139.7405595758537 9.269 35.67350390166546 139.74054549796014 9.269 35.67351563180314 139.7405263625606 9.269 35.67350008110071 139.74051204196016 9.269 35.67355044957006 139.74042992878216 9.269 35.67356996914722 139.740447912281 9.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67356996914722 139.740447912281 9.269 35.67355044957006 139.74042992878216 9.269 35.67355044957006 139.74042992878216 12.87 35.67356996914722 139.740447912281 12.87 35.67356996914722 139.740447912281 9.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67355044957006 139.74042992878216 9.269 35.67350008110071 139.74051204196016 9.269 35.67350008110071 139.74051204196016 12.87 35.67355044957006 139.74042992878216 12.87 35.67355044957006 139.74042992878216 9.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67350008110071 139.74051204196016 9.269 35.67351563180314 139.7405263625606 9.269 35.67351563180314 139.7405263625606 12.87 35.67350008110071 139.74051204196016 12.87 35.67350008110071 139.74051204196016 9.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67351563180314 139.7405263625606 9.269 35.67350390166546 139.74054549796014 9.269 35.67350390166546 139.74054549796014 12.87 35.67351563180314 139.7405263625606 12.87 35.67351563180314 139.7405263625606 9.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67350390166546 139.74054549796014 9.269 35.67351918176515 139.7405595758537 9.269 35.67351918176515 139.7405595758537 12.87 35.67350390166546 139.74054549796014 12.87 35.67350390166546 139.74054549796014 9.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67351918176515 139.7405595758537 9.269 35.673504831906335 139.7405829672559 9.269 35.673504831906335 139.7405829672559 12.87 35.67351918176515 139.7405595758537 12.87 35.67351918176515 139.7405595758537 9.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673504831906335 139.7405829672559 9.269 35.67352462206805 139.74060120454277 9.269 35.67352462206805 139.74060120454277 12.87 35.673504831906335 139.7405829672559 12.87 35.673504831906335 139.7405829672559 9.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67352462206805 139.74060120454277 9.269 35.67355184537678 139.74055680952003 9.269 35.67355184537678 139.74055680952003 12.87 35.67352462206805 139.74060120454277 12.87 35.67352462206805 139.74060120454277 9.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67355184537678 139.74055680952003 9.269 35.673538017515526 139.74054406659045 9.269 35.673538017515526 139.74054406659045 12.87 35.67355184537678 139.74055680952003 12.87 35.67355184537678 139.74055680952003 9.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673538017515526 139.74054406659045 9.269 35.67356486272088 139.74050031268726 9.269 35.67356486272088 139.74050031268726 12.87 35.673538017515526 139.74054406659045 12.87 35.673538017515526 139.74054406659045 9.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67356486272088 139.74050031268726 9.269 35.673547589168784 139.74048440335426 9.269 35.673547589168784 139.74048440335426 12.87 35.67356486272088 139.74050031268726 12.87 35.67356486272088 139.74050031268726 9.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673547589168784 139.74048440335426 9.269 35.67356996914722 139.740447912281 9.269 35.67356996914722 139.740447912281 12.87 35.673547589168784 139.74048440335426 12.87 35.673547589168784 139.74048440335426 9.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67356996914722 139.740447912281 12.87 35.67355044957006 139.74042992878216 12.87 35.67350008110071 139.74051204196016 12.87 35.67351563180314 139.7405263625606 12.87 35.67350390166546 139.74054549796014 12.87 35.67351918176515 139.7405595758537 12.87 35.673504831906335 139.7405829672559 12.87 35.67352462206805 139.74060120454277 12.87 35.67355184537678 139.74055680952003 12.87 35.673538017515526 139.74054406659045 12.87 35.67356486272088 139.74050031268726 12.87 35.673547589168784 139.74048440335426 12.87 35.67356996914722 139.740447912281 12.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-d65648fc-85ae-466a-bca1-7a459be29771"/>
							<gml:surfaceMember xlink:href="#poly-5469c1e9-68c6-4b86-9e54-cde0550bfcf9"/>
							<gml:surfaceMember xlink:href="#poly-db00862f-57c3-40f3-ab7b-737a15065405"/>
							<gml:surfaceMember xlink:href="#poly-a4d3eabd-5449-4a92-a1fd-2bc5171fccc3"/>
							<gml:surfaceMember xlink:href="#poly-b9a3e590-973c-40d3-9f2b-17f6d3335494"/>
							<gml:surfaceMember xlink:href="#poly-e1b5d656-fd17-4d42-9700-eb61f64517ae"/>
							<gml:surfaceMember xlink:href="#poly-42ec028c-ed23-4af5-93e1-f10cb277ff31"/>
							<gml:surfaceMember xlink:href="#poly-253f0211-470a-4a5a-b669-54fa694696cc"/>
							<gml:surfaceMember xlink:href="#poly-eeb59fc7-3281-4d3c-a9e8-1a533561ef45"/>
							<gml:surfaceMember xlink:href="#poly-2311ae5f-7044-4626-bf89-62d2e60a3e29"/>
							<gml:surfaceMember xlink:href="#poly-38dbbc71-ef14-4de2-9e81-64c78a9f1a50"/>
							<gml:surfaceMember xlink:href="#poly-42af6d9b-fcb0-43a8-a291-baa100ba64a4"/>
							<gml:surfaceMember xlink:href="#poly-4a0c8c65-4a7b-4824-85e5-bc86f51bd5e6"/>
							<gml:surfaceMember xlink:href="#poly-8845599c-a49c-432a-931f-f45d282f956b"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-d65648fc-85ae-466a-bca1-7a459be29771">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d65648fc-85ae-466a-bca1-7a459be29771">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d65648fc-85ae-466a-bca1-7a459be29771">
											<gml:posList>35.673524613054326 139.7406012045532 9.269 35.673504822892625 139.7405829672663 9.269 35.67351918176511 139.7405595758537 9.269 35.67350390166546 139.74054549796014 9.269 35.67351563181165 139.74052637360728 9.269 35.67350008110072 139.74051204196016 9.269 35.67355044957006 139.74042992878216 9.269 35.67356996914721 139.740447912281 9.269 35.673547580155045 139.7404844033647 9.269 35.673564862720895 139.74050031268726 9.269 35.67353801751551 139.74054406659045 9.269 35.673551845376764 139.74055680952003 9.269 35.673524613054326 139.7406012045532 9.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5469c1e9-68c6-4b86-9e54-cde0550bfcf9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5469c1e9-68c6-4b86-9e54-cde0550bfcf9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5469c1e9-68c6-4b86-9e54-cde0550bfcf9">
											<gml:posList>35.67356996914721 139.740447912281 12.9 35.67355044957006 139.74042992878216 12.9 35.67350008110072 139.74051204196016 12.9 35.67351563181165 139.74052637360728 12.9 35.67350390166546 139.74054549796014 12.9 35.67351918176511 139.7405595758537 12.9 35.673504822892625 139.7405829672663 12.9 35.673524613054326 139.7406012045532 12.9 35.673551845376764 139.74055680952003 12.9 35.67353801751551 139.74054406659045 12.9 35.673564862720895 139.74050031268726 12.9 35.673547580155045 139.7404844033647 12.9 35.67356996914721 139.740447912281 12.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-db00862f-57c3-40f3-ab7b-737a15065405">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db00862f-57c3-40f3-ab7b-737a15065405">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db00862f-57c3-40f3-ab7b-737a15065405">
											<gml:posList>35.67350008110072 139.74051204196016 9.269 35.67351563181165 139.74052637360728 9.269 35.67351563181165 139.74052637360728 12.9 35.67350008110072 139.74051204196016 12.9 35.67350008110072 139.74051204196016 9.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a4d3eabd-5449-4a92-a1fd-2bc5171fccc3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4d3eabd-5449-4a92-a1fd-2bc5171fccc3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4d3eabd-5449-4a92-a1fd-2bc5171fccc3">
											<gml:posList>35.67351563181165 139.74052637360728 9.269 35.67350390166546 139.74054549796014 9.269 35.67350390166546 139.74054549796014 12.9 35.67351563181165 139.74052637360728 12.9 35.67351563181165 139.74052637360728 9.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b9a3e590-973c-40d3-9f2b-17f6d3335494">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b9a3e590-973c-40d3-9f2b-17f6d3335494">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b9a3e590-973c-40d3-9f2b-17f6d3335494">
											<gml:posList>35.67350390166546 139.74054549796014 9.269 35.67351918176511 139.7405595758537 9.269 35.67351918176511 139.7405595758537 12.9 35.67350390166546 139.74054549796014 12.9 35.67350390166546 139.74054549796014 9.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e1b5d656-fd17-4d42-9700-eb61f64517ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e1b5d656-fd17-4d42-9700-eb61f64517ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e1b5d656-fd17-4d42-9700-eb61f64517ae">
											<gml:posList>35.67351918176511 139.7405595758537 9.269 35.673504822892625 139.7405829672663 9.269 35.673504822892625 139.7405829672663 12.9 35.67351918176511 139.7405595758537 12.9 35.67351918176511 139.7405595758537 9.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-42ec028c-ed23-4af5-93e1-f10cb277ff31">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-42ec028c-ed23-4af5-93e1-f10cb277ff31">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-42ec028c-ed23-4af5-93e1-f10cb277ff31">
											<gml:posList>35.673504822892625 139.7405829672663 9.269 35.673524613054326 139.7406012045532 9.269 35.673524613054326 139.7406012045532 12.9 35.673504822892625 139.7405829672663 12.9 35.673504822892625 139.7405829672663 9.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-253f0211-470a-4a5a-b669-54fa694696cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-253f0211-470a-4a5a-b669-54fa694696cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-253f0211-470a-4a5a-b669-54fa694696cc">
											<gml:posList>35.67355044957006 139.74042992878216 9.269 35.67350008110072 139.74051204196016 9.269 35.67350008110072 139.74051204196016 12.9 35.67355044957006 139.74042992878216 12.9 35.67355044957006 139.74042992878216 9.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eeb59fc7-3281-4d3c-a9e8-1a533561ef45">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eeb59fc7-3281-4d3c-a9e8-1a533561ef45">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eeb59fc7-3281-4d3c-a9e8-1a533561ef45">
											<gml:posList>35.673524613054326 139.7406012045532 9.269 35.673551845376764 139.74055680952003 9.269 35.673551845376764 139.74055680952003 12.9 35.673524613054326 139.7406012045532 12.9 35.673524613054326 139.7406012045532 9.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2311ae5f-7044-4626-bf89-62d2e60a3e29">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2311ae5f-7044-4626-bf89-62d2e60a3e29">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2311ae5f-7044-4626-bf89-62d2e60a3e29">
											<gml:posList>35.673551845376764 139.74055680952003 9.269 35.67353801751551 139.74054406659045 9.269 35.67353801751551 139.74054406659045 12.9 35.673551845376764 139.74055680952003 12.9 35.673551845376764 139.74055680952003 9.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-38dbbc71-ef14-4de2-9e81-64c78a9f1a50">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38dbbc71-ef14-4de2-9e81-64c78a9f1a50">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38dbbc71-ef14-4de2-9e81-64c78a9f1a50">
											<gml:posList>35.67353801751551 139.74054406659045 9.269 35.673564862720895 139.74050031268726 9.269 35.673564862720895 139.74050031268726 12.9 35.67353801751551 139.74054406659045 12.9 35.67353801751551 139.74054406659045 9.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-42af6d9b-fcb0-43a8-a291-baa100ba64a4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-42af6d9b-fcb0-43a8-a291-baa100ba64a4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-42af6d9b-fcb0-43a8-a291-baa100ba64a4">
											<gml:posList>35.673564862720895 139.74050031268726 9.269 35.673547580155045 139.7404844033647 9.269 35.673547580155045 139.7404844033647 12.9 35.673564862720895 139.74050031268726 12.9 35.673564862720895 139.74050031268726 9.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4a0c8c65-4a7b-4824-85e5-bc86f51bd5e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a0c8c65-4a7b-4824-85e5-bc86f51bd5e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a0c8c65-4a7b-4824-85e5-bc86f51bd5e6">
											<gml:posList>35.673547580155045 139.7404844033647 9.269 35.67356996914721 139.740447912281 9.269 35.67356996914721 139.740447912281 12.9 35.673547580155045 139.7404844033647 12.9 35.673547580155045 139.7404844033647 9.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8845599c-a49c-432a-931f-f45d282f956b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8845599c-a49c-432a-931f-f45d282f956b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8845599c-a49c-432a-931f-f45d282f956b">
											<gml:posList>35.67356996914721 139.740447912281 9.269 35.67355044957006 139.74042992878216 9.269 35.67355044957006 139.74042992878216 12.9 35.67356996914721 139.740447912281 12.9 35.67356996914721 139.740447912281 9.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4551</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">2</uro:rank>
					<uro:depth uom="m">0.53</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>