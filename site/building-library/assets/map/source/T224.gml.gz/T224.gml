<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_3e2060e5-56ce-429e-a87a-af10e1debab3">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">16.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66929797821853 139.73905983646316 0 35.669335507133916 139.7390889319904 0 35.66934546122476 139.73906964481662 0 35.66940032193997 139.73910820861667 0 35.6694381238937 139.73903702711908 0 35.669417746242885 139.7389135553878 0 35.66935234704626 139.7389652177708 0 35.66929797821853 139.73905983646316 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66929797821853 139.73905983646316 14.507 35.66935234704626 139.7389652177708 14.507 35.669417746242885 139.7389135553878 14.507 35.6694381238937 139.73903702711908 14.507 35.66940032193997 139.73910820861667 14.507 35.66934546122476 139.73906964481662 14.507 35.669335507133916 139.7390889319904 14.507 35.66929797821853 139.73905983646316 14.507</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66929797821853 139.73905983646316 14.507 35.669335507133916 139.7390889319904 14.507 35.669335507133916 139.7390889319904 30.71 35.66929797821853 139.73905983646316 30.71 35.66929797821853 139.73905983646316 14.507</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669335507133916 139.7390889319904 14.507 35.66934546122476 139.73906964481662 14.507 35.66934546122476 139.73906964481662 30.71 35.669335507133916 139.7390889319904 30.71 35.669335507133916 139.7390889319904 14.507</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66934546122476 139.73906964481662 14.507 35.66940032193997 139.73910820861667 14.507 35.66940032193997 139.73910820861667 30.71 35.66934546122476 139.73906964481662 30.71 35.66934546122476 139.73906964481662 14.507</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66940032193997 139.73910820861667 14.507 35.6694381238937 139.73903702711908 14.507 35.6694381238937 139.73903702711908 30.71 35.66940032193997 139.73910820861667 30.71 35.66940032193997 139.73910820861667 14.507</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6694381238937 139.73903702711908 14.507 35.669417746242885 139.7389135553878 14.507 35.669417746242885 139.7389135553878 30.71 35.6694381238937 139.73903702711908 30.71 35.6694381238937 139.73903702711908 14.507</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669417746242885 139.7389135553878 14.507 35.66935234704626 139.7389652177708 14.507 35.66935234704626 139.7389652177708 30.71 35.669417746242885 139.7389135553878 30.71 35.669417746242885 139.7389135553878 14.507</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66935234704626 139.7389652177708 14.507 35.66929797821853 139.73905983646316 14.507 35.66929797821853 139.73905983646316 30.71 35.66935234704626 139.7389652177708 30.71 35.66935234704626 139.7389652177708 14.507</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66929797821853 139.73905983646316 30.71 35.669335507133916 139.7390889319904 30.71 35.66934546122476 139.73906964481662 30.71 35.66940032193997 139.73910820861667 30.71 35.6694381238937 139.73903702711908 30.71 35.669417746242885 139.7389135553878 30.71 35.66935234704626 139.7389652177708 30.71 35.66929797821853 139.73905983646316 30.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-67f3b6e9-2a55-4191-971d-03f192d8de26"/>
							<gml:surfaceMember xlink:href="#poly-e7e9c597-6dd6-443f-b6d0-6d1445a04c6d"/>
							<gml:surfaceMember xlink:href="#poly-38a7f641-0bf0-433c-a008-22ac6036f078"/>
							<gml:surfaceMember xlink:href="#poly-e5f72acf-295b-41d2-b52a-30e59a4fdc2c"/>
							<gml:surfaceMember xlink:href="#poly-6284e581-2854-477a-b724-51c75660d1cc"/>
							<gml:surfaceMember xlink:href="#poly-ba9d6cf6-5d1e-4c53-883d-e40ce1aea66d"/>
							<gml:surfaceMember xlink:href="#poly-f9bc4499-c787-4a97-875a-dc7c37571cb6"/>
							<gml:surfaceMember xlink:href="#poly-1927689a-f401-4a47-bb9b-fa88fc4d4667"/>
							<gml:surfaceMember xlink:href="#poly-55f7e6ba-56d1-4080-a6a8-788ce5af7c38"/>
							<gml:surfaceMember xlink:href="#poly-fe828203-f9a8-45da-a178-4aadb55ecd71"/>
							<gml:surfaceMember xlink:href="#poly-930c3cc5-afde-449a-8e51-60eb2fd24e94"/>
							<gml:surfaceMember xlink:href="#poly-9bbb43d4-9474-4d01-bcf1-3615216513a1"/>
							<gml:surfaceMember xlink:href="#poly-b4eaca27-3156-44ce-8597-e59a459ed41a"/>
							<gml:surfaceMember xlink:href="#poly-0bd25da9-8d5b-498d-9eaf-7f24bd17c69c"/>
							<gml:surfaceMember xlink:href="#poly-fa0f6188-d5aa-47b1-9408-05c5a2333e5a"/>
							<gml:surfaceMember xlink:href="#poly-5efd9da7-5674-4b80-a436-c9e473d25330"/>
							<gml:surfaceMember xlink:href="#poly-c13d3dcf-9960-4a3e-8191-ff88e83a3cd8"/>
							<gml:surfaceMember xlink:href="#poly-12ba710b-9756-4e53-9c11-a768114cf3af"/>
							<gml:surfaceMember xlink:href="#poly-55a56c14-98a5-407c-b079-feb172b70486"/>
							<gml:surfaceMember xlink:href="#poly-a5fb92f3-e1c1-4326-a458-4ea3f8ddf8cd"/>
							<gml:surfaceMember xlink:href="#poly-28506ae0-7428-4c98-8143-9796ca646d7f"/>
							<gml:surfaceMember xlink:href="#poly-7bf1dc92-33a2-4954-81b6-ba8480a76484"/>
							<gml:surfaceMember xlink:href="#poly-35caa7da-cad2-44b3-a9c8-1030650fdc4e"/>
							<gml:surfaceMember xlink:href="#poly-5b2cc69b-f4ba-4e34-b65c-62b9ba1dfc05"/>
							<gml:surfaceMember xlink:href="#poly-7e88de52-7565-4f90-bbcd-0b4f0acbc4ad"/>
							<gml:surfaceMember xlink:href="#poly-f94bcfca-0718-426e-b0ec-81f90becf889"/>
							<gml:surfaceMember xlink:href="#poly-58254abf-747a-4285-9216-b7d381cae0f7"/>
							<gml:surfaceMember xlink:href="#poly-9f1e2c64-7cee-4ca0-8fc2-9bfe68759189"/>
							<gml:surfaceMember xlink:href="#poly-c8728dc8-68ca-4455-9dff-1b2b26de3f9b"/>
							<gml:surfaceMember xlink:href="#poly-ac203fec-cf44-4de1-abae-d5e0b43119f7"/>
							<gml:surfaceMember xlink:href="#poly-d547c9e2-6fb3-451e-948f-343308bf3cd7"/>
							<gml:surfaceMember xlink:href="#poly-4bc31fdf-aa63-412d-96d8-349eba223cad"/>
							<gml:surfaceMember xlink:href="#poly-e60e2abe-15ef-4e48-90e1-481d32d26903"/>
							<gml:surfaceMember xlink:href="#poly-4812e2de-d900-4b30-ae5a-0eccfc0d0c18"/>
							<gml:surfaceMember xlink:href="#poly-d086ffad-e5a7-4fe8-942c-13f7ada15701"/>
							<gml:surfaceMember xlink:href="#poly-13eba990-e0af-4d2a-9df2-582cce33fe3f"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_3e2060e5-56ce-429e-a87a-af10e1debab3_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ddc15244-df8a-4429-a733-794396532ddb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ddc15244-df8a-4429-a733-794396532ddb_0">
											<gml:posList>35.669315707158454 139.73905846799238 31.112 35.66932257077932 139.73906379519516 31.989 35.669315707158454 139.73905846799238 31.989 35.669315707158454 139.73905846799238 31.112</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ace7c5a3-e152-45da-bd4d-0f5aafd5ad5d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ace7c5a3-e152-45da-bd4d-0f5aafd5ad5d_0">
											<gml:posList>35.669315707158454 139.73905846799238 31.112 35.66932257077932 139.73906379519516 31.112 35.66932257077932 139.73906379519516 31.989 35.669315707158454 139.73905846799238 31.112</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-108566c7-808a-4336-bcd5-1d778c434cb4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-108566c7-808a-4336-bcd5-1d778c434cb4_0">
											<gml:posList>35.6693274432543 139.73903572129015 31.112 35.669315707158454 139.73905846799238 31.989 35.6693274432543 139.73903572129015 31.989 35.6693274432543 139.73903572129015 31.112</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2e60efe8-2d0a-4094-a397-e08aed44cd2d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2e60efe8-2d0a-4094-a397-e08aed44cd2d_0">
											<gml:posList>35.6693274432543 139.73903572129015 31.112 35.669315707158454 139.73905846799238 31.112 35.669315707158454 139.73905846799238 31.989 35.6693274432543 139.73903572129015 31.112</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5dc89555-f52a-46aa-8a4a-e9d8e3851be0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5dc89555-f52a-46aa-8a4a-e9d8e3851be0_0">
											<gml:posList>35.66933430687616 139.73904104849174 31.989 35.669315707158454 139.73905846799238 31.989 35.66932257077932 139.73906379519516 31.989 35.66933430687616 139.73904104849174 31.989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-155c75de-f21e-4907-8968-77d157596418">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-155c75de-f21e-4907-8968-77d157596418_0">
											<gml:posList>35.66933430687616 139.73904104849174 31.989 35.6693274432543 139.73903572129015 31.989 35.669315707158454 139.73905846799238 31.989 35.66933430687616 139.73904104849174 31.989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6abb5499-7929-460a-a8e0-7b6078d27bfb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6abb5499-7929-460a-a8e0-7b6078d27bfb_0">
											<gml:posList>35.66932257077932 139.73906379519516 31.112 35.66933430687616 139.73904104849174 31.989 35.66932257077932 139.73906379519516 31.989 35.66932257077932 139.73906379519516 31.112</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-097d4476-777d-4efd-995b-d19a9b709619">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-097d4476-777d-4efd-995b-d19a9b709619_0">
											<gml:posList>35.66932257077932 139.73906379519516 31.112 35.66933430687616 139.73904104849174 31.112 35.66933430687616 139.73904104849174 31.989 35.66932257077932 139.73906379519516 31.112</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-898e6e9d-d946-46d5-90d0-ba9080809668">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-898e6e9d-d946-46d5-90d0-ba9080809668_0">
											<gml:posList>35.6693274432543 139.73903572129015 31.112 35.66933430687616 139.73904104849174 31.989 35.66933430687616 139.73904104849174 31.112 35.6693274432543 139.73903572129015 31.112</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-92cc166a-e0a4-4114-ab09-5f08f275062a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-92cc166a-e0a4-4114-ab09-5f08f275062a_0">
											<gml:posList>35.6693274432543 139.73903572129015 31.112 35.6693274432543 139.73903572129015 31.989 35.66933430687616 139.73904104849174 31.989 35.6693274432543 139.73903572129015 31.112</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc6d76a8-c90c-489b-95d1-51ef4da5b50c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bc6d76a8-c90c-489b-95d1-51ef4da5b50c_0">
											<gml:posList>35.66934546122476 139.73906964481662 32.138 35.669335507133916 139.7390889319904 14.51 35.669335507133916 139.7390889319904 32.138 35.66934546122476 139.73906964481662 32.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a246412-8643-42f2-864b-00cf39895c24">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0a246412-8643-42f2-864b-00cf39895c24_0">
											<gml:posList>35.66934546122476 139.73906964481662 32.138 35.66934546122476 139.73906964481662 14.51 35.669335507133916 139.7390889319904 14.51 35.66934546122476 139.73906964481662 32.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2e8dd9a9-1424-48c9-9e99-a5765b6cee75">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2e8dd9a9-1424-48c9-9e99-a5765b6cee75_0">
											<gml:posList>35.669335507133916 139.7390889319904 14.51 35.66938861931027 139.73912766354513 14.51 35.66938861931027 139.73912766354513 24.56 35.669335507133916 139.7390889319904 14.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-099378e3-8c75-471c-a66d-1d85880e61fe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-099378e3-8c75-471c-a66d-1d85880e61fe_0">
											<gml:posList>35.669335507133916 139.7390889319904 32.138 35.669335507133916 139.7390889319904 14.51 35.66938861931027 139.73912766354513 24.56 35.669335507133916 139.7390889319904 32.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b0eba8a1-3618-4b23-b181-ff623b96d569">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b0eba8a1-3618-4b23-b181-ff623b96d569_0">
											<gml:posList>35.66934546122476 139.73906964481662 32.138 35.66938861931027 139.73912766354513 24.56 35.66940032193998 139.73910820861667 24.56 35.66934546122476 139.73906964481662 32.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e3a01938-cae9-4a88-87e3-cd014a88154f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e3a01938-cae9-4a88-87e3-cd014a88154f_0">
											<gml:posList>35.66934546122476 139.73906964481662 32.138 35.669335507133916 139.7390889319904 32.138 35.66938861931027 139.73912766354513 24.56 35.66934546122476 139.73906964481662 32.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d662df03-3b63-43fa-a401-4be7eaf8c303">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d662df03-3b63-43fa-a401-4be7eaf8c303_0">
											<gml:posList>35.66934546122476 139.73906964481662 14.51 35.66940032193998 139.73910820861667 24.56 35.66940032193998 139.73910820861667 14.51 35.66934546122476 139.73906964481662 14.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf04cdee-93d6-4828-a7f3-e851e427afb5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bf04cdee-93d6-4828-a7f3-e851e427afb5_0">
											<gml:posList>35.66934546122476 139.73906964481662 14.51 35.66934546122476 139.73906964481662 32.138 35.66940032193998 139.73910820861667 24.56 35.66934546122476 139.73906964481662 14.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8c3e87c-aa5c-4105-8371-35b2349e6fcf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8c3e87c-aa5c-4105-8371-35b2349e6fcf_0">
											<gml:posList>35.66938861931027 139.73912766354513 24.56 35.66940032193998 139.73910820861667 14.51 35.66940032193998 139.73910820861667 24.56 35.66938861931027 139.73912766354513 24.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-93e23321-8e36-414e-8cc4-7454a8d9310d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-93e23321-8e36-414e-8cc4-7454a8d9310d_0">
											<gml:posList>35.66938861931027 139.73912766354513 24.56 35.66938861931027 139.73912766354513 14.51 35.66940032193998 139.73910820861667 14.51 35.66938861931027 139.73912766354513 24.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4fbb89bf-0bf8-4b74-a263-0540a8dbca2a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66933430687616 139.73904104849174 31.112 35.669315707158454 139.73905846799238 31.112 35.6693274432543 139.73903572129015 31.112 35.66933430687616 139.73904104849174 31.112</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04db6e9f-9f46-4e23-9a9f-0f413b679ec5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66933430687616 139.73904104849174 31.112 35.66932257077932 139.73906379519516 31.112 35.669315707158454 139.73905846799238 31.112 35.66933430687616 139.73904104849174 31.112</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba7c8c95-52ce-4469-9873-39a33ed6ce7a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66934546122476 139.73906964481662 14.51 35.66940032193998 139.73910820861667 14.51 35.66938861931027 139.73912766354513 14.51 35.66934546122476 139.73906964481662 14.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43360a12-546b-4f8c-bae9-00bb0531ef15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669335507133916 139.7390889319904 14.51 35.66934546122476 139.73906964481662 14.51 35.66938861931027 139.73912766354513 14.51 35.669335507133916 139.7390889319904 14.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_3e2060e5-56ce-429e-a87a-af10e1debab3_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-233b5e61-4ddd-4a23-a0f2-caf84e2a3988">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669336108411756 139.73899347075388 32.138 35.66934483083572 139.7389783052191 32.138 35.6693474827228 139.73898066596743 32.138 35.66933876931227 139.73899583149185 32.138 35.669336108411756 139.73899347075388 32.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1690576-e47d-4383-aba0-3f4a59018efb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6693474827228 139.73898066596743 31.112 35.66935394989035 139.73898618141612 31.112 35.66934523647913 139.7390013469412 31.112 35.66933876931227 139.73899583149185 31.112 35.6693474827228 139.73898066596743 31.112</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7142225b-131d-4f54-a03d-efbf87a08f31">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669331121610576 139.73900215886752 32.138 35.669333827518976 139.73900444222988 32.138 35.669328075588744 139.73901445677635 32.138 35.66932536968054 139.7390121734138 32.138 35.669331121610576 139.73900215886752 32.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7aa0172e-01bb-40fe-84f5-9fd3f97d491c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669328075588744 139.73901445677635 31.112 35.669333827518976 139.73900444222988 31.112 35.669340348906246 139.73901013435363 31.112 35.66933460598062 139.73902013784382 31.112 35.669328075588744 139.73901445677635 31.112</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc8db0a7-e1bd-49bc-b384-669263117de9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66933884940264 139.73905205612724 34.8 35.66934402671363 139.7390564353477 34.8 35.66933263119862 139.7390767073215 34.8 35.669327453897 139.73907233914645 34.8 35.66933884940264 139.73905205612724 34.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-05e22c01-6ab7-499d-b3bb-d9595ebba101">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-05e22c01-6ab7-499d-b3bb-d9595ebba101_0">
											<gml:posList>35.669331121610576 139.73900215886752 32.138 35.66932536968054 139.7390121734138 32.138 35.66932536968054 139.7390121734138 32.209 35.669331121610576 139.73900215886752 32.209 35.669331121610576 139.73900215886752 32.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-639135f2-9ecd-4168-a01e-91ad44f1b446">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-639135f2-9ecd-4168-a01e-91ad44f1b446_0">
											<gml:posList>35.669328075588744 139.73901445677635 32.138 35.669328075588744 139.73901445677635 31.112 35.66933460598062 139.73902013784382 31.112 35.66933460598062 139.73902013784382 32.209 35.66932536968054 139.7390121734138 32.209 35.66932536968054 139.7390121734138 32.138 35.669328075588744 139.73901445677635 32.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0dd2aa77-f42a-40d5-ac45-9019c9b5719c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0dd2aa77-f42a-40d5-ac45-9019c9b5719c_0">
											<gml:posList>35.669327453897 139.73907233914645 34.8 35.66933263119862 139.7390767073215 34.8 35.66933263119862 139.7390767073215 36.714 35.669327453897 139.73907233914645 36.714 35.669327453897 139.73907233914645 34.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e0a4a46-ea8a-44f6-816b-53b567a61d22">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1e0a4a46-ea8a-44f6-816b-53b567a61d22_0">
											<gml:posList>35.669328075588744 139.73901445677635 32.138 35.669333827518976 139.73900444222988 32.138 35.669333827518976 139.73900444222988 31.112 35.669328075588744 139.73901445677635 31.112 35.669328075588744 139.73901445677635 32.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14ee71cd-bac8-4e4d-bde2-3f5e58636efa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-14ee71cd-bac8-4e4d-bde2-3f5e58636efa_0">
											<gml:posList>35.669340348906246 139.73901013435363 32.209 35.669331121610576 139.73900215886752 32.209 35.66932536968054 139.7390121734138 32.209 35.66933460598062 139.73902013784382 32.209 35.669340348906246 139.73901013435363 32.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f15b4af7-8d7f-4337-87b2-764eeec1df32">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f15b4af7-8d7f-4337-87b2-764eeec1df32_0">
											<gml:posList>35.669327453897 139.73907233914645 34.8 35.669327453897 139.73907233914645 36.714 35.66933884940264 139.73905205612724 36.714 35.66933884940264 139.73905205612724 34.8 35.669327453897 139.73907233914645 34.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ef36636-9440-4bee-b18a-edc48968a212">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0ef36636-9440-4bee-b18a-edc48968a212_0">
											<gml:posList>35.66933884940264 139.73905205612724 36.714 35.669327453897 139.73907233914645 36.714 35.66933263119862 139.7390767073215 36.714 35.66934402671363 139.7390564353477 36.714 35.66933884940264 139.73905205612724 36.714</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c937b05f-cfc0-40e8-865b-81b52b9f6355">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c937b05f-cfc0-40e8-865b-81b52b9f6355_0">
											<gml:posList>35.669331121610576 139.73900215886752 32.209 35.669340348906246 139.73901013435363 32.209 35.669340348906246 139.73901013435363 31.112 35.669333827518976 139.73900444222988 31.112 35.669333827518976 139.73900444222988 32.138 35.669331121610576 139.73900215886752 32.138 35.669331121610576 139.73900215886752 32.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8eaee995-a1ba-47e1-98cd-601afa28922e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8eaee995-a1ba-47e1-98cd-601afa28922e_0">
											<gml:posList>35.669340348906246 139.73901013435363 31.112 35.669340348906246 139.73901013435363 32.209 35.66933460598062 139.73902013784382 32.209 35.66933460598062 139.73902013784382 31.112 35.669340348906246 139.73901013435363 31.112</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e77317da-5e1b-4ed8-8c98-d36c905d93ac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e77317da-5e1b-4ed8-8c98-d36c905d93ac_0">
											<gml:posList>35.66933263119862 139.7390767073215 34.8 35.66934402671363 139.7390564353477 34.8 35.66934402671363 139.7390564353477 36.714 35.66933263119862 139.7390767073215 36.714 35.66933263119862 139.7390767073215 34.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7fe65862-6d29-41b1-a275-7c5c2056c616">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7fe65862-6d29-41b1-a275-7c5c2056c616_0">
											<gml:posList>35.66934483083572 139.7389783052191 32.138 35.669336108411756 139.73899347075388 32.138 35.669336108411756 139.73899347075388 34.072 35.66934483083572 139.7389783052191 34.072 35.66934483083572 139.7389783052191 32.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b67fab9-5def-4ac5-a768-a1505ce65970">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4b67fab9-5def-4ac5-a768-a1505ce65970_0">
											<gml:posList>35.66934523647913 139.7390013469412 31.112 35.66934523647913 139.7390013469412 34.072 35.669336108411756 139.73899347075388 34.072 35.669336108411756 139.73899347075388 32.138 35.66933876931227 139.73899583149185 32.138 35.66933876931227 139.73899583149185 31.112 35.66934523647913 139.7390013469412 31.112</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb620433-c01e-4113-858e-d39d83027503">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb620433-c01e-4113-858e-d39d83027503_0">
											<gml:posList>35.66933884940264 139.73905205612724 34.8 35.66933884940264 139.73905205612724 36.714 35.66934402671363 139.7390564353477 36.714 35.66934402671363 139.7390564353477 34.8 35.66933884940264 139.73905205612724 34.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0559f623-84a5-43bd-8f31-4bbf295b0d57">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0559f623-84a5-43bd-8f31-4bbf295b0d57_0">
											<gml:posList>35.66933876931227 139.73899583149185 32.138 35.6693474827228 139.73898066596743 32.138 35.6693474827228 139.73898066596743 31.112 35.66933876931227 139.73899583149185 31.112 35.66933876931227 139.73899583149185 32.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2e74c55e-149d-405b-9c70-d9ea1bc6a2f9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2e74c55e-149d-405b-9c70-d9ea1bc6a2f9_0">
											<gml:posList>35.66935394989035 139.73898618141612 34.072 35.66934483083572 139.7389783052191 34.072 35.669336108411756 139.73899347075388 34.072 35.66934523647913 139.7390013469412 34.072 35.66935394989035 139.73898618141612 34.072</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-62f663bc-3518-4adf-ae22-a41b387ee3bf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-62f663bc-3518-4adf-ae22-a41b387ee3bf_0">
											<gml:posList>35.6693474827228 139.73898066596743 32.138 35.66934483083572 139.7389783052191 32.138 35.66934483083572 139.7389783052191 34.072 35.66935394989035 139.73898618141612 34.072 35.66935394989035 139.73898618141612 31.112 35.6693474827228 139.73898066596743 31.112 35.6693474827228 139.73898066596743 32.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-87ce0a40-8686-4003-aebf-14d245659e42">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-87ce0a40-8686-4003-aebf-14d245659e42_0">
											<gml:posList>35.66934523647913 139.7390013469412 31.112 35.66935394989035 139.73898618141612 31.112 35.66935394989035 139.73898618141612 34.072 35.66934523647913 139.7390013469412 34.072 35.66934523647913 139.7390013469412 31.112</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-67f3b6e9-2a55-4191-971d-03f192d8de26">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67f3b6e9-2a55-4191-971d-03f192d8de26">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67f3b6e9-2a55-4191-971d-03f192d8de26">
											<gml:posList>35.66929797821853 139.73905983646316 14.507 35.66935234704624 139.7389652177708 14.507 35.66941774624285 139.7389135553878 14.507 35.669438123893684 139.73903702711905 14.507 35.66940032193998 139.73910820861667 14.507 35.66934546122476 139.73906964481662 14.507 35.669335507133916 139.7390889319904 14.507 35.66929797821853 139.73905983646316 14.507</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e7e9c597-6dd6-443f-b6d0-6d1445a04c6d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e7e9c597-6dd6-443f-b6d0-6d1445a04c6d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e7e9c597-6dd6-443f-b6d0-6d1445a04c6d">
											<gml:posList>35.66935234704624 139.7389652177708 32.138 35.66935462079867 139.738968142316 32.138 35.66937716821115 139.73895033152476 32.138 35.66937939854081 139.73894385587224 32.138 35.66935234704624 139.7389652177708 32.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-38a7f641-0bf0-433c-a008-22ac6036f078">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38a7f641-0bf0-433c-a008-22ac6036f078">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38a7f641-0bf0-433c-a008-22ac6036f078">
											<gml:posList>35.66943811488862 139.73903703817578 24.56 35.66941774624285 139.7389135553878 24.56 35.66937939854081 139.73894385587224 32.138 35.66943811488862 139.73903703817578 24.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e5f72acf-295b-41d2-b52a-30e59a4fdc2c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5f72acf-295b-41d2-b52a-30e59a4fdc2c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5f72acf-295b-41d2-b52a-30e59a4fdc2c">
											<gml:posList>35.66939327227866 139.739026431404 32.138 35.66937939854081 139.73894385587224 32.138 35.66937716821115 139.73895033152476 32.138 35.66938981033392 139.73902557387828 32.138 35.66939327227866 139.739026431404 32.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6284e581-2854-477a-b724-51c75660d1cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6284e581-2854-477a-b724-51c75660d1cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6284e581-2854-477a-b724-51c75660d1cc">
											<gml:posList>35.66937939854081 139.73894385587224 32.138 35.66939327227866 139.739026431404 32.138 35.66943811488862 139.73903703817578 24.56 35.66937939854081 139.73894385587224 32.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ba9d6cf6-5d1e-4c53-883d-e40ce1aea66d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba9d6cf6-5d1e-4c53-883d-e40ce1aea66d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba9d6cf6-5d1e-4c53-883d-e40ce1aea66d">
											<gml:posList>35.66935234704624 139.7389652177708 32.138 35.66929797821853 139.73905983646316 32.138 35.669302574344286 139.73905871540202 32.138 35.66935462079867 139.738968142316 32.138 35.66935234704624 139.7389652177708 32.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f9bc4499-c787-4a97-875a-dc7c37571cb6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9bc4499-c787-4a97-875a-dc7c37571cb6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9bc4499-c787-4a97-875a-dc7c37571cb6">
											<gml:posList>35.669361014922295 139.73907604432608 31.112 35.66938981033392 139.73902557387828 31.112 35.66937716821115 139.73895033152476 31.112 35.66935462079867 139.738968142316 31.112 35.669302574344286 139.73905871540202 31.112 35.669319458438515 139.73907198402424 31.112 35.6693370265815 139.7390379302888 31.112 35.66935474030378 139.7390516618737 31.112 35.669347261236986 139.73906615212746 31.112 35.669361014922295 139.73907604432608 31.112</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1927689a-f401-4a47-bb9b-fa88fc4d4667">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1927689a-f401-4a47-bb9b-fa88fc4d4667">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1927689a-f401-4a47-bb9b-fa88fc4d4667">
											<gml:posList>35.6693370265815 139.7390379302888 36.471 35.66933773263619 139.73904174036832 36.471 35.66935164024873 139.73905251607002 36.471 35.66935474030378 139.7390516618737 36.471 35.6693370265815 139.7390379302888 36.471</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-55f7e6ba-56d1-4080-a6a8-788ce5af7c38">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-55f7e6ba-56d1-4080-a6a8-788ce5af7c38">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-55f7e6ba-56d1-4080-a6a8-788ce5af7c38">
											<gml:posList>35.66939327227866 139.739026431404 32.138 35.66938981033392 139.73902557387828 32.138 35.669361014922295 139.73907604432608 32.138 35.669361974492695 139.73908130115072 32.138 35.66939327227866 139.739026431404 32.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fe828203-f9a8-45da-a178-4aadb55ecd71">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe828203-f9a8-45da-a178-4aadb55ecd71">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe828203-f9a8-45da-a178-4aadb55ecd71">
											<gml:posList>35.66931779341582 139.73907520040052 36.471 35.669320902493425 139.73907435724092 36.471 35.66933773263619 139.73904174036832 36.471 35.6693370265815 139.7390379302888 36.471 35.66931779341582 139.73907520040052 36.471</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-930c3cc5-afde-449a-8e51-60eb2fd24e94">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-930c3cc5-afde-449a-8e51-60eb2fd24e94">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-930c3cc5-afde-449a-8e51-60eb2fd24e94">
											<gml:posList>35.66935164024873 139.73905251607002 34.8 35.66933773263619 139.73904174036832 34.8 35.669320902493425 139.73907435724092 34.8 35.66933481010309 139.73908513294603 34.8 35.66935164024873 139.73905251607002 34.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9bbb43d4-9474-4d01-bcf1-3615216513a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9bbb43d4-9474-4d01-bcf1-3615216513a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9bbb43d4-9474-4d01-bcf1-3615216513a1">
											<gml:posList>35.669302574344286 139.73905871540202 32.138 35.66929797821853 139.73905983646316 32.138 35.66931779341582 139.73907520040052 32.138 35.669319458438515 139.73907198402424 32.138 35.669302574344286 139.73905871540202 32.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b4eaca27-3156-44ce-8597-e59a459ed41a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b4eaca27-3156-44ce-8597-e59a459ed41a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b4eaca27-3156-44ce-8597-e59a459ed41a">
											<gml:posList>35.66940032193998 139.73910820861667 24.56 35.66943811488862 139.73903703817578 24.56 35.66939327227866 139.739026431404 32.138 35.66940032193998 139.73910820861667 24.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0bd25da9-8d5b-498d-9eaf-7f24bd17c69c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0bd25da9-8d5b-498d-9eaf-7f24bd17c69c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0bd25da9-8d5b-498d-9eaf-7f24bd17c69c">
											<gml:posList>35.66939327227866 139.739026431404 32.138 35.669361974492695 139.73908130115072 32.138 35.66940032193998 139.73910820861667 24.56 35.66939327227866 139.739026431404 32.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fa0f6188-d5aa-47b1-9408-05c5a2333e5a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa0f6188-d5aa-47b1-9408-05c5a2333e5a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa0f6188-d5aa-47b1-9408-05c5a2333e5a">
											<gml:posList>35.66935474030378 139.7390516618737 36.471 35.66935164024873 139.73905251607002 36.471 35.66933481010309 139.73908513294603 36.471 35.669335507133916 139.7390889319904 36.471 35.66935474030378 139.7390516618737 36.471</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5efd9da7-5674-4b80-a436-c9e473d25330">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5efd9da7-5674-4b80-a436-c9e473d25330">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5efd9da7-5674-4b80-a436-c9e473d25330">
											<gml:posList>35.669361014922295 139.73907604432608 32.138 35.669347261236986 139.73906615212746 32.138 35.66934546122476 139.73906964481662 32.138 35.669361974492695 139.73908130115072 32.138 35.669361014922295 139.73907604432608 32.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c13d3dcf-9960-4a3e-8191-ff88e83a3cd8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c13d3dcf-9960-4a3e-8191-ff88e83a3cd8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c13d3dcf-9960-4a3e-8191-ff88e83a3cd8">
											<gml:posList>35.669335507133916 139.7390889319904 36.471 35.66933481010309 139.73908513294603 36.471 35.669320902493425 139.73907435724092 36.471 35.66931779341582 139.73907520040052 36.471 35.669335507133916 139.7390889319904 36.471</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-12ba710b-9756-4e53-9c11-a768114cf3af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-12ba710b-9756-4e53-9c11-a768114cf3af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-12ba710b-9756-4e53-9c11-a768114cf3af">
											<gml:posList>35.669320902493425 139.73907435724092 36.471 35.669320902493425 139.73907435724092 34.8 35.66933773263619 139.73904174036832 34.8 35.66933773263619 139.73904174036832 36.471 35.669320902493425 139.73907435724092 36.471</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-55a56c14-98a5-407c-b079-feb172b70486">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-55a56c14-98a5-407c-b079-feb172b70486">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-55a56c14-98a5-407c-b079-feb172b70486">
											<gml:posList>35.66935164024873 139.73905251607002 36.471 35.66935164024873 139.73905251607002 34.8 35.66933481010309 139.73908513294603 34.8 35.66933481010309 139.73908513294603 36.471 35.66935164024873 139.73905251607002 36.471</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a5fb92f3-e1c1-4326-a458-4ea3f8ddf8cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5fb92f3-e1c1-4326-a458-4ea3f8ddf8cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5fb92f3-e1c1-4326-a458-4ea3f8ddf8cd">
											<gml:posList>35.66935234704624 139.7389652177708 32.138 35.66937939854081 139.73894385587224 32.138 35.66941774624285 139.7389135553878 24.56 35.66941774624285 139.7389135553878 14.507 35.66935234704624 139.7389652177708 14.507 35.66935234704624 139.7389652177708 32.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-28506ae0-7428-4c98-8143-9796ca646d7f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28506ae0-7428-4c98-8143-9796ca646d7f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28506ae0-7428-4c98-8143-9796ca646d7f">
											<gml:posList>35.66935462079867 139.738968142316 32.138 35.66935462079867 139.738968142316 31.112 35.66937716821115 139.73895033152476 31.112 35.66937716821115 139.73895033152476 32.138 35.66935462079867 139.738968142316 32.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7bf1dc92-33a2-4954-81b6-ba8480a76484">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7bf1dc92-33a2-4954-81b6-ba8480a76484">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7bf1dc92-33a2-4954-81b6-ba8480a76484">
											<gml:posList>35.669438123893684 139.73903702711905 14.507 35.66941774624285 139.7389135553878 14.507 35.66941774624285 139.7389135553878 24.56 35.66943811488862 139.73903703817578 24.56 35.669438123893684 139.73903702711905 14.507</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-35caa7da-cad2-44b3-a9c8-1030650fdc4e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-35caa7da-cad2-44b3-a9c8-1030650fdc4e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-35caa7da-cad2-44b3-a9c8-1030650fdc4e">
											<gml:posList>35.66937716821115 139.73895033152476 32.138 35.66937716821115 139.73895033152476 31.112 35.66938981033392 139.73902557387828 31.112 35.66938981033392 139.73902557387828 32.138 35.66937716821115 139.73895033152476 32.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5b2cc69b-f4ba-4e34-b65c-62b9ba1dfc05">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b2cc69b-f4ba-4e34-b65c-62b9ba1dfc05">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b2cc69b-f4ba-4e34-b65c-62b9ba1dfc05">
											<gml:posList>35.66935234704624 139.7389652177708 14.507 35.66929797821853 139.73905983646316 14.507 35.66929797821853 139.73905983646316 32.138 35.66935234704624 139.7389652177708 32.138 35.66935234704624 139.7389652177708 14.507</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7e88de52-7565-4f90-bbcd-0b4f0acbc4ad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e88de52-7565-4f90-bbcd-0b4f0acbc4ad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e88de52-7565-4f90-bbcd-0b4f0acbc4ad">
											<gml:posList>35.669302574344286 139.73905871540202 32.138 35.669302574344286 139.73905871540202 31.112 35.66935462079867 139.738968142316 31.112 35.66935462079867 139.738968142316 32.138 35.669302574344286 139.73905871540202 32.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f94bcfca-0718-426e-b0ec-81f90becf889">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f94bcfca-0718-426e-b0ec-81f90becf889">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f94bcfca-0718-426e-b0ec-81f90becf889">
											<gml:posList>35.6693370265815 139.7390379302888 36.471 35.66935474030378 139.7390516618737 36.471 35.66935474030378 139.7390516618737 31.112 35.6693370265815 139.7390379302888 31.112 35.6693370265815 139.7390379302888 36.471</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-58254abf-747a-4285-9216-b7d381cae0f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-58254abf-747a-4285-9216-b7d381cae0f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-58254abf-747a-4285-9216-b7d381cae0f7">
											<gml:posList>35.66933773263619 139.73904174036832 36.471 35.66933773263619 139.73904174036832 34.8 35.66935164024873 139.73905251607002 34.8 35.66935164024873 139.73905251607002 36.471 35.66933773263619 139.73904174036832 36.471</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9f1e2c64-7cee-4ca0-8fc2-9bfe68759189">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f1e2c64-7cee-4ca0-8fc2-9bfe68759189">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f1e2c64-7cee-4ca0-8fc2-9bfe68759189">
											<gml:posList>35.66938981033392 139.73902557387828 32.138 35.66938981033392 139.73902557387828 31.112 35.669361014922295 139.73907604432608 31.112 35.669361014922295 139.73907604432608 32.138 35.66938981033392 139.73902557387828 32.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c8728dc8-68ca-4455-9dff-1b2b26de3f9b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8728dc8-68ca-4455-9dff-1b2b26de3f9b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8728dc8-68ca-4455-9dff-1b2b26de3f9b">
											<gml:posList>35.669319458438515 139.73907198402424 32.138 35.66931779341582 139.73907520040052 32.138 35.66931779341582 139.73907520040052 36.471 35.6693370265815 139.7390379302888 36.471 35.6693370265815 139.7390379302888 31.112 35.669319458438515 139.73907198402424 31.112 35.669319458438515 139.73907198402424 32.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ac203fec-cf44-4de1-abae-d5e0b43119f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ac203fec-cf44-4de1-abae-d5e0b43119f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ac203fec-cf44-4de1-abae-d5e0b43119f7">
											<gml:posList>35.669319458438515 139.73907198402424 32.138 35.669319458438515 139.73907198402424 31.112 35.669302574344286 139.73905871540202 31.112 35.669302574344286 139.73905871540202 32.138 35.669319458438515 139.73907198402424 32.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d547c9e2-6fb3-451e-948f-343308bf3cd7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d547c9e2-6fb3-451e-948f-343308bf3cd7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d547c9e2-6fb3-451e-948f-343308bf3cd7">
											<gml:posList>35.669347261236986 139.73906615212746 32.138 35.669347261236986 139.73906615212746 31.112 35.66935474030378 139.7390516618737 31.112 35.66935474030378 139.7390516618737 36.471 35.669335507133916 139.7390889319904 36.471 35.669335507133916 139.7390889319904 14.507 35.66934546122476 139.73906964481662 14.507 35.66934546122476 139.73906964481662 32.138 35.669347261236986 139.73906615212746 32.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4bc31fdf-aa63-412d-96d8-349eba223cad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4bc31fdf-aa63-412d-96d8-349eba223cad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4bc31fdf-aa63-412d-96d8-349eba223cad">
											<gml:posList>35.669361014922295 139.73907604432608 32.138 35.669361014922295 139.73907604432608 31.112 35.669347261236986 139.73906615212746 31.112 35.669347261236986 139.73906615212746 32.138 35.669361014922295 139.73907604432608 32.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e60e2abe-15ef-4e48-90e1-481d32d26903">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e60e2abe-15ef-4e48-90e1-481d32d26903">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e60e2abe-15ef-4e48-90e1-481d32d26903">
											<gml:posList>35.66940032193998 139.73910820861667 14.507 35.669438123893684 139.73903702711905 14.507 35.66943811488862 139.73903703817578 24.56 35.66940032193998 139.73910820861667 24.56 35.66940032193998 139.73910820861667 14.507</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4812e2de-d900-4b30-ae5a-0eccfc0d0c18">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4812e2de-d900-4b30-ae5a-0eccfc0d0c18">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4812e2de-d900-4b30-ae5a-0eccfc0d0c18">
											<gml:posList>35.669335507133916 139.7390889319904 14.507 35.669335507133916 139.7390889319904 36.471 35.66931779341582 139.73907520040052 36.471 35.66931779341582 139.73907520040052 32.138 35.66929797821853 139.73905983646316 32.138 35.66929797821853 139.73905983646316 14.507 35.669335507133916 139.7390889319904 14.507</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d086ffad-e5a7-4fe8-942c-13f7ada15701">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d086ffad-e5a7-4fe8-942c-13f7ada15701">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d086ffad-e5a7-4fe8-942c-13f7ada15701">
											<gml:posList>35.66933481010309 139.73908513294603 36.471 35.66933481010309 139.73908513294603 34.8 35.669320902493425 139.73907435724092 34.8 35.669320902493425 139.73907435724092 36.471 35.66933481010309 139.73908513294603 36.471</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-13eba990-e0af-4d2a-9df2-582cce33fe3f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13eba990-e0af-4d2a-9df2-582cce33fe3f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13eba990-e0af-4d2a-9df2-582cce33fe3f">
											<gml:posList>35.66940032193998 139.73910820861667 24.56 35.669361974492695 139.73908130115072 32.138 35.66934546122476 139.73906964481662 32.138 35.66934546122476 139.73906964481662 14.507 35.66940032193998 139.73910820861667 14.507 35.66940032193998 139.73910820861667 24.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-11350</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">156.4251</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.06</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>