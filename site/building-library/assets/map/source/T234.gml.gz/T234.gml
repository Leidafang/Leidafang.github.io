<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_41b472c5-ac11-4b78-8703-9eee1921d9ba">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:measuredHeight uom="m">5.2</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66858585649096 139.7427700351214 0 35.66869421784015 139.7427916734053 0 35.66869717575641 139.7427695780096 0 35.66858881440334 139.74274793975482 0 35.66858585649096 139.7427700351214 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66858585649096 139.7427700351214 12.41 35.66858881440334 139.74274793975482 12.41 35.66869717575641 139.7427695780096 12.41 35.66869421784015 139.7427916734053 12.41 35.66858585649096 139.7427700351214 12.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66858585649096 139.7427700351214 12.41 35.66869421784015 139.7427916734053 12.41 35.66869421784015 139.7427916734053 17.59 35.66858585649096 139.7427700351214 17.59 35.66858585649096 139.7427700351214 12.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66869421784015 139.7427916734053 12.41 35.66869717575641 139.7427695780096 12.41 35.66869717575641 139.7427695780096 17.59 35.66869421784015 139.7427916734053 17.59 35.66869421784015 139.7427916734053 12.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66869717575641 139.7427695780096 12.41 35.66858881440334 139.74274793975482 12.41 35.66858881440334 139.74274793975482 17.59 35.66869717575641 139.7427695780096 17.59 35.66869717575641 139.7427695780096 12.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66858881440334 139.74274793975482 12.41 35.66858585649096 139.7427700351214 12.41 35.66858585649096 139.7427700351214 17.59 35.66858881440334 139.74274793975482 17.59 35.66858881440334 139.74274793975482 12.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66858585649096 139.7427700351214 17.59 35.66869421784015 139.7427916734053 17.59 35.66869717575641 139.7427695780096 17.59 35.66858881440334 139.74274793975482 17.59 35.66858585649096 139.7427700351214 17.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-ce70d6e8-d62a-4111-9dd1-754839536f3c"/>
							<gml:surfaceMember xlink:href="#poly-674b4492-274e-4d0a-a97f-e8509a71cf4a"/>
							<gml:surfaceMember xlink:href="#poly-e7b74a53-e4c6-4973-bdff-e1bac58520bb"/>
							<gml:surfaceMember xlink:href="#poly-d99cffe9-09d6-4be3-8afa-3e6064023834"/>
							<gml:surfaceMember xlink:href="#poly-77455672-d423-453a-b7e3-be2bdb039136"/>
							<gml:surfaceMember xlink:href="#poly-14734701-6d9e-43d9-84f3-f25b01e3b6ca"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-ce70d6e8-d62a-4111-9dd1-754839536f3c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce70d6e8-d62a-4111-9dd1-754839536f3c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce70d6e8-d62a-4111-9dd1-754839536f3c">
											<gml:posList>35.668585856490935 139.7427700351214 12.41 35.66858881440333 139.7427479397548 12.41 35.66869717575642 139.7427695780096 12.41 35.668694217840155 139.74279167340526 12.41 35.668585856490935 139.7427700351214 12.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-674b4492-274e-4d0a-a97f-e8509a71cf4a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-674b4492-274e-4d0a-a97f-e8509a71cf4a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-674b4492-274e-4d0a-a97f-e8509a71cf4a">
											<gml:posList>35.66858881440333 139.7427479397548 17.8 35.668585856490935 139.7427700351214 17.8 35.668694217840155 139.74279167340526 17.8 35.66869717575642 139.7427695780096 17.8 35.66858881440333 139.7427479397548 17.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e7b74a53-e4c6-4973-bdff-e1bac58520bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e7b74a53-e4c6-4973-bdff-e1bac58520bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e7b74a53-e4c6-4973-bdff-e1bac58520bb">
											<gml:posList>35.66869717575642 139.7427695780096 12.41 35.66858881440333 139.7427479397548 12.41 35.66858881440333 139.7427479397548 17.8 35.66869717575642 139.7427695780096 17.8 35.66869717575642 139.7427695780096 12.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d99cffe9-09d6-4be3-8afa-3e6064023834">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d99cffe9-09d6-4be3-8afa-3e6064023834">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d99cffe9-09d6-4be3-8afa-3e6064023834">
											<gml:posList>35.66858881440333 139.7427479397548 12.41 35.668585856490935 139.7427700351214 12.41 35.668585856490935 139.7427700351214 17.8 35.66858881440333 139.7427479397548 17.8 35.66858881440333 139.7427479397548 12.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-77455672-d423-453a-b7e3-be2bdb039136">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-77455672-d423-453a-b7e3-be2bdb039136">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-77455672-d423-453a-b7e3-be2bdb039136">
											<gml:posList>35.668694217840155 139.74279167340526 12.41 35.66869717575642 139.7427695780096 12.41 35.66869717575642 139.7427695780096 17.8 35.668694217840155 139.74279167340526 17.8 35.668694217840155 139.74279167340526 12.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-14734701-6d9e-43d9-84f3-f25b01e3b6ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-14734701-6d9e-43d9-84f3-f25b01e3b6ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-14734701-6d9e-43d9-84f3-f25b01e3b6ca">
											<gml:posList>35.668585856490935 139.7427700351214 12.41 35.668694217840155 139.74279167340526 12.41 35.668694217840155 139.74279167340526 17.8 35.668585856490935 139.7427700351214 17.8 35.668585856490935 139.7427700351214 12.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5845</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">6</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>