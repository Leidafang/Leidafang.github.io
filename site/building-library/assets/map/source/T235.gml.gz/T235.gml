<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_41b53426-e175-4f51-a23e-fe4f6b3a45fa">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">25.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>7</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.673114764539434 139.7377043448221 0 35.673146210482244 139.73768928388145 0 35.67309181537668 139.73752265508767 0 35.673005946369585 139.7375626360112 0 35.673089797152166 139.7378187072505 0 35.67314304692854 139.73779180047336 0 35.673114764539434 139.7377043448221 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673114764539434 139.7377043448221 8.64 35.67314304692854 139.73779180047336 8.64 35.673089797152166 139.7378187072505 8.64 35.673005946369585 139.7375626360112 8.64 35.67309181537668 139.73752265508767 8.64 35.673146210482244 139.73768928388145 8.64 35.673114764539434 139.7377043448221 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673114764539434 139.7377043448221 8.64 35.673146210482244 139.73768928388145 8.64 35.673146210482244 139.73768928388145 34.21 35.673114764539434 139.7377043448221 34.21 35.673114764539434 139.7377043448221 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673146210482244 139.73768928388145 8.64 35.67309181537668 139.73752265508767 8.64 35.67309181537668 139.73752265508767 34.21 35.673146210482244 139.73768928388145 34.21 35.673146210482244 139.73768928388145 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67309181537668 139.73752265508767 8.64 35.673005946369585 139.7375626360112 8.64 35.673005946369585 139.7375626360112 34.21 35.67309181537668 139.73752265508767 34.21 35.67309181537668 139.73752265508767 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673005946369585 139.7375626360112 8.64 35.673089797152166 139.7378187072505 8.64 35.673089797152166 139.7378187072505 34.21 35.673005946369585 139.7375626360112 34.21 35.673005946369585 139.7375626360112 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673089797152166 139.7378187072505 8.64 35.67314304692854 139.73779180047336 8.64 35.67314304692854 139.73779180047336 34.21 35.673089797152166 139.7378187072505 34.21 35.673089797152166 139.7378187072505 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67314304692854 139.73779180047336 8.64 35.673114764539434 139.7377043448221 8.64 35.673114764539434 139.7377043448221 34.21 35.67314304692854 139.73779180047336 34.21 35.67314304692854 139.73779180047336 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673114764539434 139.7377043448221 34.21 35.673146210482244 139.73768928388145 34.21 35.67309181537668 139.73752265508767 34.21 35.673005946369585 139.7375626360112 34.21 35.673089797152166 139.7378187072505 34.21 35.67314304692854 139.73779180047336 34.21 35.673114764539434 139.7377043448221 34.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-304b93e8-b7d8-4c3c-9d54-dc29c1a24a65"/>
							<gml:surfaceMember xlink:href="#poly-3e7ca9c3-f33a-4efa-abbf-35136bbfd24a"/>
							<gml:surfaceMember xlink:href="#poly-2ae0420f-7e38-461d-a5ef-1e8247fd3249"/>
							<gml:surfaceMember xlink:href="#poly-3584e08d-c8de-477b-a79e-7061f234c7ce"/>
							<gml:surfaceMember xlink:href="#poly-85263bb7-5fb6-4f2b-b273-0285950f62da"/>
							<gml:surfaceMember xlink:href="#poly-1ba3b5ed-1bd8-4ded-be96-0353911e1fd5"/>
							<gml:surfaceMember xlink:href="#poly-2e7dab9a-1f15-49c9-9c71-214b6dd84c7c"/>
							<gml:surfaceMember xlink:href="#poly-476b7c82-3507-4403-86ad-9bb8b7da5e17"/>
							<gml:surfaceMember xlink:href="#poly-7d8c9422-7145-4950-a2d3-86d9b0fa41c4"/>
							<gml:surfaceMember xlink:href="#poly-daf42ff6-b494-4fb2-a59f-cf38f0318404"/>
							<gml:surfaceMember xlink:href="#poly-31d06892-5c68-4b77-85c1-80c779e31b5f"/>
							<gml:surfaceMember xlink:href="#poly-9e55ba60-92ad-4a9d-b2c0-756a82643e87"/>
							<gml:surfaceMember xlink:href="#poly-f61551cb-f3db-4800-97ed-2e826105e954"/>
							<gml:surfaceMember xlink:href="#poly-b22f7838-ad4b-4822-8568-ea3234faf8ac"/>
							<gml:surfaceMember xlink:href="#poly-79407e22-e9be-42e9-9da0-9dcc90123f24"/>
							<gml:surfaceMember xlink:href="#poly-b54cff6f-2a88-4cab-883b-6a7b2d974551"/>
							<gml:surfaceMember xlink:href="#poly-411d38ec-2833-47aa-b8e7-9ffc6dec376d"/>
							<gml:surfaceMember xlink:href="#poly-6ca460d3-cb11-4171-9b37-ba612b62a15d"/>
							<gml:surfaceMember xlink:href="#poly-9d6f9dd9-e2b3-47ee-93bd-9903852c06cb"/>
							<gml:surfaceMember xlink:href="#poly-f5b35921-eadc-4080-921b-b26b409d56a7"/>
							<gml:surfaceMember xlink:href="#poly-7d0ca7d7-29ad-44b8-a60c-53b8f07fac39"/>
							<gml:surfaceMember xlink:href="#poly-d4105ef0-6b55-48f0-91d0-f3c6c62be4f8"/>
							<gml:surfaceMember xlink:href="#poly-d62ea4e3-a4a4-4ff1-bcaa-6fb1fc44dd69"/>
							<gml:surfaceMember xlink:href="#poly-36588622-d2ba-4362-92d5-35a904912519"/>
							<gml:surfaceMember xlink:href="#poly-9d19d26b-9290-4df4-beac-80a054daf770"/>
							<gml:surfaceMember xlink:href="#poly-ae1aa428-a003-48f5-83c4-e8668aa8331e"/>
							<gml:surfaceMember xlink:href="#poly-e3a3a9c1-524e-4c54-b958-d3a82a1a1b71"/>
							<gml:surfaceMember xlink:href="#poly-e5a06631-63c5-41a7-bf4c-8be447d8bb76"/>
							<gml:surfaceMember xlink:href="#poly-ce3a8c60-593d-49bb-891c-f4452c037780"/>
							<gml:surfaceMember xlink:href="#poly-889cb3a7-3e90-4ffb-897d-34f72c581b41"/>
							<gml:surfaceMember xlink:href="#poly-9b2ce129-434d-4c8a-ba45-3e3788bb776f"/>
							<gml:surfaceMember xlink:href="#poly-7a88b645-c1b9-4b97-9c51-9baa5b197f84"/>
							<gml:surfaceMember xlink:href="#poly-3e3a3b9f-dcfc-41fd-91c2-a1932b2c1385"/>
							<gml:surfaceMember xlink:href="#poly-e6fd1245-e801-47a4-82bf-5719875f0ce7"/>
							<gml:surfaceMember xlink:href="#poly-e8fa0ef8-8566-4e39-9818-261823c48b98"/>
							<gml:surfaceMember xlink:href="#poly-157fb64e-1d33-4e7d-b46d-774c5f607729"/>
							<gml:surfaceMember xlink:href="#poly-87132303-d782-41e8-86ca-d512b97a14a0"/>
							<gml:surfaceMember xlink:href="#poly-470b0634-4b71-4eb0-84cc-b0e26154b790"/>
							<gml:surfaceMember xlink:href="#poly-24690b7f-376c-4194-8e9d-886525448895"/>
							<gml:surfaceMember xlink:href="#poly-2f1f74e7-c158-4f7f-b6fd-80d14b55e669"/>
							<gml:surfaceMember xlink:href="#poly-bb5ce688-4b8a-40c2-ba50-de3abeeff04d"/>
							<gml:surfaceMember xlink:href="#poly-7ace81c7-b105-4bd3-b573-928a1841d6f0"/>
							<gml:surfaceMember xlink:href="#poly-0f4e7f8a-ee96-41da-99bd-5465e711f9da"/>
							<gml:surfaceMember xlink:href="#poly-87792e2a-3f6f-4d81-8cb1-86692af97b0e"/>
							<gml:surfaceMember xlink:href="#poly-0bb76adc-ce36-42c7-9091-3b9cc8905a21"/>
							<gml:surfaceMember xlink:href="#poly-b7dcd5a7-662b-44cf-848c-89b0eaaf32ce"/>
							<gml:surfaceMember xlink:href="#poly-b47154f4-1139-402d-891a-35af0245e16c"/>
							<gml:surfaceMember xlink:href="#poly-850e3f06-10fc-4250-a17d-1e424e25e847"/>
							<gml:surfaceMember xlink:href="#poly-a3acc466-fb0d-4231-9af6-72213ff08df1"/>
							<gml:surfaceMember xlink:href="#poly-7b2bab66-ade8-49f0-b127-7fc2a72cafb6"/>
							<gml:surfaceMember xlink:href="#poly-23c202fc-4ff4-46f1-8e50-0cf018e8083e"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_41b53426-e175-4f51-a23e-fe4f6b3a45fa_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e3e6e4a-8ebb-4c9e-a3d6-a0fa661f503a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67306802191966 139.73759414416938 35.009 35.6730462181813 139.7376060674243 35.009 35.67302947917518 139.73756007822195 35.009 35.673051291922754 139.73754815494627 35.009 35.67306802191966 139.73759414416938 35.009</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f51a0eb-6e20-4bee-a65a-f0806bf96ba0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f51a0eb-6e20-4bee-a65a-f0806bf96ba0_0">
											<gml:posList>35.67302947917518 139.73756007822195 37.231 35.67302947917518 139.73756007822195 35.009 35.6730462181813 139.7376060674243 35.009 35.6730462181813 139.7376060674243 37.231 35.67302947917518 139.73756007822195 37.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b7d6219e-e3fe-4b73-b7a3-3f2bca59061e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b7d6219e-e3fe-4b73-b7a3-3f2bca59061e_0">
											<gml:posList>35.673051291922754 139.73754815494627 37.231 35.673051291922754 139.73754815494627 35.009 35.67302947917518 139.73756007822195 35.009 35.67302947917518 139.73756007822195 37.231 35.673051291922754 139.73754815494627 37.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7d4c3615-6622-435a-83dd-cf141165b2f1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7d4c3615-6622-435a-83dd-cf141165b2f1_0">
											<gml:posList>35.67302947917518 139.73756007822195 37.231 35.6730462181813 139.7376060674243 37.231 35.67306802191966 139.73759414416938 37.231 35.673051291922754 139.73754815494627 37.231 35.67302947917518 139.73756007822195 37.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1219d82e-e839-41c3-9ad8-d933e149ce4d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1219d82e-e839-41c3-9ad8-d933e149ce4d_0">
											<gml:posList>35.6730462181813 139.7376060674243 37.231 35.6730462181813 139.7376060674243 35.009 35.67306802191966 139.73759414416938 35.009 35.67306802191966 139.73759414416938 37.231 35.6730462181813 139.7376060674243 37.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b32659b-bc59-4289-a5ee-528db778784c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0b32659b-bc59-4289-a5ee-528db778784c_0">
											<gml:posList>35.67306802191966 139.73759414416938 37.231 35.67306802191966 139.73759414416938 35.009 35.673051291922754 139.73754815494627 35.009 35.673051291922754 139.73754815494627 37.231 35.67306802191966 139.73759414416938 37.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_41b53426-e175-4f51-a23e-fe4f6b3a45fa_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9942bb67-0faf-448a-aad9-3cefa694d920">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673096288714575 139.73766187046206 39.332 35.67309830697988 139.73766085176325 39.332 35.673106665020555 139.7376864589351 39.332 35.67310464675502 139.7376874776334 39.332 35.673096288714575 139.73766187046206 39.332</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-20f393d3-aabf-4f7e-a1c2-957c4447d679">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673094145568555 139.73763051162828 39.109 35.67311208434724 139.73762101220044 39.109 35.67311758609898 139.7376366034825 39.109 35.67309964731908 139.73764610290752 39.109 35.673094145568555 139.73763051162828 39.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0b3fdde-d8d6-479d-9350-cd7a5f4b0ae1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67309830697988 139.73766085176325 39.109 35.673111029276136 139.73765445162547 39.109 35.673119387318145 139.7376800588007 39.109 35.673106665020555 139.7376864589351 39.109 35.67309830697988 139.73766085176325 39.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2537806b-6ffa-4776-b391-901de9ef25a0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2537806b-6ffa-4776-b391-901de9ef25a0_0">
											<gml:posList>35.673094145568555 139.73763051162828 39.109 35.67309964731908 139.73764610290752 39.109 35.67309964731908 139.73764610290752 41.76 35.673094145568555 139.73763051162828 41.76 35.673094145568555 139.73763051162828 39.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-777a758f-5395-4a7b-8915-555fd3ab7bec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-777a758f-5395-4a7b-8915-555fd3ab7bec_0">
											<gml:posList>35.67310464675502 139.7376874776334 39.332 35.67310464675502 139.7376874776334 40.246 35.673096288714575 139.73766187046206 40.246 35.673096288714575 139.73766187046206 39.332 35.67310464675502 139.7376874776334 39.332</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9478a462-7a57-4c03-9777-51ebf9c6dcd4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9478a462-7a57-4c03-9777-51ebf9c6dcd4_0">
											<gml:posList>35.67309830697988 139.73766085176325 39.109 35.673106665020555 139.7376864589351 39.109 35.673106665020555 139.7376864589351 39.332 35.67309830697988 139.73766085176325 39.332 35.67309830697988 139.73766085176325 39.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b3a5c5c-6f9b-4e39-a668-c7929d755d15">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1b3a5c5c-6f9b-4e39-a668-c7929d755d15_0">
											<gml:posList>35.673094145568555 139.73763051162828 41.76 35.67311208434724 139.73762101220044 41.76 35.67311208434724 139.73762101220044 39.109 35.673094145568555 139.73763051162828 39.109 35.673094145568555 139.73763051162828 41.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6064e65b-d087-422a-b9c5-1a8d8148b2b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6064e65b-d087-422a-b9c5-1a8d8148b2b4_0">
											<gml:posList>35.67309830697988 139.73766085176325 39.332 35.673096288714575 139.73766187046206 39.332 35.673096288714575 139.73766187046206 40.246 35.673111029276136 139.73765445162547 40.246 35.673111029276136 139.73765445162547 39.109 35.67309830697988 139.73766085176325 39.109 35.67309830697988 139.73766085176325 39.332</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0aae9917-26b7-4b1c-9a39-a501935e2321">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0aae9917-26b7-4b1c-9a39-a501935e2321_0">
											<gml:posList>35.67311758609898 139.7376366034825 41.76 35.67311208434724 139.73762101220044 41.76 35.673094145568555 139.73763051162828 41.76 35.67309964731908 139.73764610290752 41.76 35.67311758609898 139.7376366034825 41.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-029df467-becf-48cf-8014-8538b9cb2b39">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-029df467-becf-48cf-8014-8538b9cb2b39_0">
											<gml:posList>35.67310464675502 139.7376874776334 40.246 35.673119387318145 139.7376800588007 40.246 35.673111029276136 139.73765445162547 40.246 35.673096288714575 139.73766187046206 40.246 35.67310464675502 139.7376874776334 40.246</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a1f15a0-56c8-490a-9829-d34dca8cf57d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7a1f15a0-56c8-490a-9829-d34dca8cf57d_0">
											<gml:posList>35.67309964731908 139.73764610290752 41.76 35.67309964731908 139.73764610290752 39.109 35.67311758609898 139.7376366034825 39.109 35.67311758609898 139.7376366034825 41.76 35.67309964731908 139.73764610290752 41.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d50515c-a29e-4aef-b4bd-53080efd06e0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8d50515c-a29e-4aef-b4bd-53080efd06e0_0">
											<gml:posList>35.67310464675502 139.7376874776334 40.246 35.67310464675502 139.7376874776334 39.332 35.673106665020555 139.7376864589351 39.332 35.673106665020555 139.7376864589351 39.109 35.673119387318145 139.7376800588007 39.109 35.673119387318145 139.7376800588007 40.246 35.67310464675502 139.7376874776334 40.246</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9c953c0d-0965-430d-8ddf-047973185106">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9c953c0d-0965-430d-8ddf-047973185106_0">
											<gml:posList>35.67311208434724 139.73762101220044 41.76 35.67311758609898 139.7376366034825 41.76 35.67311758609898 139.7376366034825 39.109 35.67311208434724 139.73762101220044 39.109 35.67311208434724 139.73762101220044 41.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e80ae15-7739-4dec-927c-0b7d51641a87">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8e80ae15-7739-4dec-927c-0b7d51641a87_0">
											<gml:posList>35.673111029276136 139.73765445162547 40.246 35.673119387318145 139.7376800588007 40.246 35.673119387318145 139.7376800588007 39.109 35.673111029276136 139.73765445162547 39.109 35.673111029276136 139.73765445162547 40.246</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-304b93e8-b7d8-4c3c-9d54-dc29c1a24a65">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-304b93e8-b7d8-4c3c-9d54-dc29c1a24a65">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-304b93e8-b7d8-4c3c-9d54-dc29c1a24a65">
											<gml:posList>35.673114764539434 139.7377043448221 8.64 35.67314304692852 139.73779180047336 8.64 35.67308979715215 139.73781870725048 8.64 35.673005946369585 139.73756263601118 8.64 35.67309181537667 139.73752265508767 8.64 35.673146210482216 139.73768928388145 8.64 35.673114764539434 139.7377043448221 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3e7ca9c3-f33a-4efa-abbf-35136bbfd24a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e7ca9c3-f33a-4efa-abbf-35136bbfd24a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e7ca9c3-f33a-4efa-abbf-35136bbfd24a">
											<gml:posList>35.67305885151335 139.73768053975348 16.553 35.67301667774503 139.73755764116478 16.553 35.673005946369585 139.73756263601118 16.553 35.67304653456088 139.73768659695392 16.553 35.67305885151335 139.73768053975348 16.553</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2ae0420f-7e38-461d-a5ef-1e8247fd3249">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2ae0420f-7e38-461d-a5ef-1e8247fd3249">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2ae0420f-7e38-461d-a5ef-1e8247fd3249">
											<gml:posList>35.673051908974344 139.7376894074319 31.774 35.673060423550744 139.73768513327525 31.774 35.67305885151335 139.73768053975348 31.774 35.67304653456088 139.73768659695392 31.774 35.673051908974344 139.7376894074319 31.774</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3584e08d-c8de-477b-a79e-7061f234c7ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3584e08d-c8de-477b-a79e-7061f234c7ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3584e08d-c8de-477b-a79e-7061f234c7ce">
											<gml:posList>35.67301667774503 139.73755764116478 35.885 35.673022439927124 139.7375606721023 35.885 35.673089369094946 139.73752950692332 35.885 35.67309181537667 139.73752265508767 35.885 35.67301667774503 139.73755764116478 35.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-85263bb7-5fb6-4f2b-b273-0285950f62da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85263bb7-5fb6-4f2b-b273-0285950f62da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85263bb7-5fb6-4f2b-b273-0285950f62da">
											<gml:posList>35.67309551400902 139.73778733904746 35.885 35.67309787916444 139.73778046522256 35.885 35.673022439927124 139.7375606721023 35.885 35.67301667774503 139.73755764116478 35.885 35.67309551400902 139.73778733904746 35.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1ba3b5ed-1bd8-4ded-be96-0353911e1fd5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ba3b5ed-1bd8-4ded-be96-0353911e1fd5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ba3b5ed-1bd8-4ded-be96-0353911e1fd5">
											<gml:posList>35.67308979715215 139.73781870725048 31.774 35.67309207236498 139.7378120765601 31.774 35.673051908974344 139.7376894074319 31.774 35.67304653456088 139.73768659695392 31.774 35.67308979715215 139.73781870725048 31.774</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2e7dab9a-1f15-49c9-9c71-214b6dd84c7c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2e7dab9a-1f15-49c9-9c71-214b6dd84c7c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2e7dab9a-1f15-49c9-9c71-214b6dd84c7c">
											<gml:posList>35.673022439927124 139.7375606721023 35.009 35.67309787916444 139.73778046522256 35.009 35.67312971239111 139.7377650061743 35.009 35.67311076392259 139.7377062054289 35.009 35.67311015121786 139.7377064933723 35.009 35.67309629948369 139.7376640797759 35.009 35.67308926250836 139.7376675347227 35.009 35.6730748893082 139.7376268119011 35.009 35.67311428021191 139.73760529021604 35.009 35.673089369094946 139.73752950692332 35.009 35.673022439927124 139.7375606721023 35.009</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-476b7c82-3507-4403-86ad-9bb8b7da5e17">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-476b7c82-3507-4403-86ad-9bb8b7da5e17">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-476b7c82-3507-4403-86ad-9bb8b7da5e17">
											<gml:posList>35.67308926250836 139.7376675347227 39.332 35.67309078227208 139.73766305902296 39.332 35.67307862240982 139.73762859699875 39.332 35.6730748893082 139.7376268119011 39.332 35.67308926250836 139.7376675347227 39.332</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7d8c9422-7145-4950-a2d3-86d9b0fa41c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d8c9422-7145-4950-a2d3-86d9b0fa41c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d8c9422-7145-4950-a2d3-86d9b0fa41c4">
											<gml:posList>35.67309629948369 139.7376640797759 39.332 35.67309789133069 139.7376595708498 39.332 35.67309078227208 139.73766305902296 39.332 35.67308926250836 139.7376675347227 39.332 35.67309629948369 139.7376640797759 39.332</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-daf42ff6-b494-4fb2-a59f-cf38f0318404">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-daf42ff6-b494-4fb2-a59f-cf38f0318404">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-daf42ff6-b494-4fb2-a59f-cf38f0318404">
											<gml:posList>35.67309551400902 139.73778733904746 31.271 35.673060423550744 139.73768513327525 31.271 35.673051908974344 139.7376894074319 31.271 35.67309207236498 139.7378120765601 31.271 35.67313771760365 139.73778901202485 31.271 35.67313151898359 139.73776985349488 31.271 35.67309551400902 139.73778733904746 31.271</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-31d06892-5c68-4b77-85c1-80c779e31b5f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31d06892-5c68-4b77-85c1-80c779e31b5f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31d06892-5c68-4b77-85c1-80c779e31b5f">
											<gml:posList>35.6730748893082 139.7376268119011 39.332 35.67307862240982 139.73762859699875 39.332 35.67311657174249 139.737607861346 39.332 35.67311810938212 139.73760319782943 39.332 35.6730748893082 139.7376268119011 39.332</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9e55ba60-92ad-4a9d-b2c0-756a82643e87">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e55ba60-92ad-4a9d-b2c0-756a82643e87">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e55ba60-92ad-4a9d-b2c0-756a82643e87">
											<gml:posList>35.673089369094946 139.73752950692332 35.885 35.67311428021191 139.73760529021604 35.885 35.67311810938212 139.73760319782943 35.885 35.67309181537667 139.73752265508767 35.885 35.673089369094946 139.73752950692332 35.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f61551cb-f3db-4800-97ed-2e826105e954">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f61551cb-f3db-4800-97ed-2e826105e954">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f61551cb-f3db-4800-97ed-2e826105e954">
											<gml:posList>35.67309629948369 139.7376640797759 39.332 35.67311015121786 139.7377064933723 39.332 35.673111752115254 139.73770202862198 39.332 35.67309789133069 139.7376595708498 39.332 35.67309629948369 139.7376640797759 39.332</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b22f7838-ad4b-4822-8568-ea3234faf8ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b22f7838-ad4b-4822-8568-ea3234faf8ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b22f7838-ad4b-4822-8568-ea3234faf8ac">
											<gml:posList>35.67309789133069 139.7376595708498 39.109 35.673111752115254 139.73770202862198 39.109 35.673113734405 139.73770110938662 39.109 35.673142513296014 139.7376873219904 39.109 35.67311657174249 139.737607861346 39.109 35.67307862240982 139.73762859699875 39.109 35.67309078227208 139.73766305902296 39.109 35.67309789133069 139.7376595708498 39.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-79407e22-e9be-42e9-9da0-9dcc90123f24">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79407e22-e9be-42e9-9da0-9dcc90123f24">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79407e22-e9be-42e9-9da0-9dcc90123f24">
											<gml:posList>35.673114764539434 139.7377043448221 39.332 35.673113734405 139.73770110938662 39.332 35.673111752115254 139.73770202862198 39.332 35.67311015121786 139.7377064933723 39.332 35.673114764539434 139.7377043448221 39.332</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b54cff6f-2a88-4cab-883b-6a7b2d974551">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b54cff6f-2a88-4cab-883b-6a7b2d974551">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b54cff6f-2a88-4cab-883b-6a7b2d974551">
											<gml:posList>35.67313534834078 139.7377679930949 35.885 35.67312971239111 139.7377650061743 35.885 35.67309787916444 139.73778046522256 35.885 35.67309551400902 139.73778733904746 35.885 35.67313534834078 139.7377679930949 35.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-411d38ec-2833-47aa-b8e7-9ffc6dec376d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-411d38ec-2833-47aa-b8e7-9ffc6dec376d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-411d38ec-2833-47aa-b8e7-9ffc6dec376d">
											<gml:posList>35.67314304692852 139.73779180047336 31.774 35.67313771760365 139.73778901202485 31.774 35.67309207236498 139.7378120765601 31.774 35.67308979715215 139.73781870725048 31.774 35.67314304692852 139.73779180047336 31.774</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6ca460d3-cb11-4171-9b37-ba612b62a15d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ca460d3-cb11-4171-9b37-ba612b62a15d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ca460d3-cb11-4171-9b37-ba612b62a15d">
											<gml:posList>35.67312971239111 139.7377650061743 35.885 35.67313534834078 139.7377679930949 35.885 35.673114764539434 139.7377043448221 35.885 35.67311076392259 139.7377062054289 35.885 35.67312971239111 139.7377650061743 35.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9d6f9dd9-e2b3-47ee-93bd-9903852c06cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d6f9dd9-e2b3-47ee-93bd-9903852c06cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d6f9dd9-e2b3-47ee-93bd-9903852c06cb">
											<gml:posList>35.673114764539434 139.7377043448221 39.332 35.673146210482216 139.73768928388145 39.332 35.673142513296014 139.7376873219904 39.332 35.673113734405 139.73770110938662 39.332 35.673114764539434 139.7377043448221 39.332</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f5b35921-eadc-4080-921b-b26b409d56a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f5b35921-eadc-4080-921b-b26b409d56a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f5b35921-eadc-4080-921b-b26b409d56a7">
											<gml:posList>35.67311810938212 139.73760319782943 39.332 35.67311657174249 139.737607861346 39.332 35.673142513296014 139.7376873219904 39.332 35.673146210482216 139.73768928388145 39.332 35.67311810938212 139.73760319782943 39.332</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7d0ca7d7-29ad-44b8-a60c-53b8f07fac39">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d0ca7d7-29ad-44b8-a60c-53b8f07fac39">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d0ca7d7-29ad-44b8-a60c-53b8f07fac39">
											<gml:posList>35.67313771760365 139.73778901202485 31.774 35.67314304692852 139.73779180047336 31.774 35.67313534834078 139.7377679930949 31.774 35.67313151898359 139.73776985349488 31.774 35.67313771760365 139.73778901202485 31.774</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d4105ef0-6b55-48f0-91d0-f3c6c62be4f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4105ef0-6b55-48f0-91d0-f3c6c62be4f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4105ef0-6b55-48f0-91d0-f3c6c62be4f8">
											<gml:posList>35.67309078227208 139.73766305902296 39.332 35.67309078227208 139.73766305902296 39.109 35.67307862240982 139.73762859699875 39.109 35.67307862240982 139.73762859699875 39.332 35.67309078227208 139.73766305902296 39.332</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d62ea4e3-a4a4-4ff1-bcaa-6fb1fc44dd69">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d62ea4e3-a4a4-4ff1-bcaa-6fb1fc44dd69">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d62ea4e3-a4a4-4ff1-bcaa-6fb1fc44dd69">
											<gml:posList>35.673089369094946 139.73752950692332 35.885 35.673089369094946 139.73752950692332 35.009 35.67311428021191 139.73760529021604 35.009 35.67311428021191 139.73760529021604 35.885 35.673089369094946 139.73752950692332 35.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-36588622-d2ba-4362-92d5-35a904912519">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36588622-d2ba-4362-92d5-35a904912519">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36588622-d2ba-4362-92d5-35a904912519">
											<gml:posList>35.673111752115254 139.73770202862198 39.332 35.673111752115254 139.73770202862198 39.109 35.67309789133069 139.7376595708498 39.109 35.67309789133069 139.7376595708498 39.332 35.673111752115254 139.73770202862198 39.332</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9d19d26b-9290-4df4-beac-80a054daf770">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d19d26b-9290-4df4-beac-80a054daf770">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d19d26b-9290-4df4-beac-80a054daf770">
											<gml:posList>35.673005946369585 139.73756263601118 8.64 35.673005946369585 139.73756263601118 16.553 35.67301667774503 139.73755764116478 16.553 35.67301667774503 139.73755764116478 35.885 35.67309181537667 139.73752265508767 35.885 35.67309181537667 139.73752265508767 8.64 35.673005946369585 139.73756263601118 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ae1aa428-a003-48f5-83c4-e8668aa8331e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ae1aa428-a003-48f5-83c4-e8668aa8331e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ae1aa428-a003-48f5-83c4-e8668aa8331e">
											<gml:posList>35.673022439927124 139.7375606721023 35.885 35.673022439927124 139.7375606721023 35.009 35.673089369094946 139.73752950692332 35.009 35.673089369094946 139.73752950692332 35.885 35.673022439927124 139.7375606721023 35.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e3a3a9c1-524e-4c54-b958-d3a82a1a1b71">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e3a3a9c1-524e-4c54-b958-d3a82a1a1b71">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e3a3a9c1-524e-4c54-b958-d3a82a1a1b71">
											<gml:posList>35.673146210482216 139.73768928388145 39.332 35.673146210482216 139.73768928388145 8.64 35.67309181537667 139.73752265508767 8.64 35.67309181537667 139.73752265508767 35.885 35.67311810938212 139.73760319782943 35.885 35.67311810938212 139.73760319782943 39.332 35.673146210482216 139.73768928388145 39.332</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e5a06631-63c5-41a7-bf4c-8be447d8bb76">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5a06631-63c5-41a7-bf4c-8be447d8bb76">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5a06631-63c5-41a7-bf4c-8be447d8bb76">
											<gml:posList>35.67311428021191 139.73760529021604 35.885 35.67311428021191 139.73760529021604 35.009 35.6730748893082 139.7376268119011 35.009 35.6730748893082 139.7376268119011 39.332 35.67311810938212 139.73760319782943 39.332 35.67311810938212 139.73760319782943 35.885 35.67311428021191 139.73760529021604 35.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ce3a8c60-593d-49bb-891c-f4452c037780">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce3a8c60-593d-49bb-891c-f4452c037780">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce3a8c60-593d-49bb-891c-f4452c037780">
											<gml:posList>35.67307862240982 139.73762859699875 39.332 35.67307862240982 139.73762859699875 39.109 35.67311657174249 139.737607861346 39.109 35.67311657174249 139.737607861346 39.332 35.67307862240982 139.73762859699875 39.332</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-889cb3a7-3e90-4ffb-897d-34f72c581b41">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-889cb3a7-3e90-4ffb-897d-34f72c581b41">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-889cb3a7-3e90-4ffb-897d-34f72c581b41">
											<gml:posList>35.6730748893082 139.7376268119011 35.009 35.67308926250836 139.7376675347227 35.009 35.67308926250836 139.7376675347227 39.332 35.6730748893082 139.7376268119011 39.332 35.6730748893082 139.7376268119011 35.009</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9b2ce129-434d-4c8a-ba45-3e3788bb776f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b2ce129-434d-4c8a-ba45-3e3788bb776f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b2ce129-434d-4c8a-ba45-3e3788bb776f">
											<gml:posList>35.67311657174249 139.737607861346 39.332 35.67311657174249 139.737607861346 39.109 35.673142513296014 139.7376873219904 39.109 35.673142513296014 139.7376873219904 39.332 35.67311657174249 139.737607861346 39.332</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7a88b645-c1b9-4b97-9c51-9baa5b197f84">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a88b645-c1b9-4b97-9c51-9baa5b197f84">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a88b645-c1b9-4b97-9c51-9baa5b197f84">
											<gml:posList>35.67309789133069 139.7376595708498 39.332 35.67309789133069 139.7376595708498 39.109 35.67309078227208 139.73766305902296 39.109 35.67309078227208 139.73766305902296 39.332 35.67309789133069 139.7376595708498 39.332</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3e3a3b9f-dcfc-41fd-91c2-a1932b2c1385">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e3a3b9f-dcfc-41fd-91c2-a1932b2c1385">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e3a3b9f-dcfc-41fd-91c2-a1932b2c1385">
											<gml:posList>35.67308926250836 139.7376675347227 35.009 35.67309629948369 139.7376640797759 35.009 35.67309629948369 139.7376640797759 39.332 35.67308926250836 139.7376675347227 39.332 35.67308926250836 139.7376675347227 35.009</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e6fd1245-e801-47a4-82bf-5719875f0ce7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e6fd1245-e801-47a4-82bf-5719875f0ce7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e6fd1245-e801-47a4-82bf-5719875f0ce7">
											<gml:posList>35.67309787916444 139.73778046522256 35.885 35.67309787916444 139.73778046522256 35.009 35.673022439927124 139.7375606721023 35.009 35.673022439927124 139.7375606721023 35.885 35.67309787916444 139.73778046522256 35.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e8fa0ef8-8566-4e39-9818-261823c48b98">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8fa0ef8-8566-4e39-9818-261823c48b98">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8fa0ef8-8566-4e39-9818-261823c48b98">
											<gml:posList>35.673060423550744 139.73768513327525 31.774 35.673060423550744 139.73768513327525 31.271 35.67309551400902 139.73778733904746 31.271 35.67309551400902 139.73778733904746 35.885 35.67301667774503 139.73755764116478 35.885 35.67301667774503 139.73755764116478 16.553 35.67305885151335 139.73768053975348 16.553 35.67305885151335 139.73768053975348 31.774 35.673060423550744 139.73768513327525 31.774</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-157fb64e-1d33-4e7d-b46d-774c5f607729">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-157fb64e-1d33-4e7d-b46d-774c5f607729">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-157fb64e-1d33-4e7d-b46d-774c5f607729">
											<gml:posList>35.67304653456088 139.73768659695392 16.553 35.67304653456088 139.73768659695392 31.774 35.67305885151335 139.73768053975348 31.774 35.67305885151335 139.73768053975348 16.553 35.67304653456088 139.73768659695392 16.553</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-87132303-d782-41e8-86ca-d512b97a14a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-87132303-d782-41e8-86ca-d512b97a14a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-87132303-d782-41e8-86ca-d512b97a14a0">
											<gml:posList>35.67309629948369 139.7376640797759 35.009 35.67311015121786 139.7377064933723 35.009 35.67311015121786 139.7377064933723 39.332 35.67309629948369 139.7376640797759 39.332 35.67309629948369 139.7376640797759 35.009</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-470b0634-4b71-4eb0-84cc-b0e26154b790">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-470b0634-4b71-4eb0-84cc-b0e26154b790">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-470b0634-4b71-4eb0-84cc-b0e26154b790">
											<gml:posList>35.673051908974344 139.7376894074319 31.774 35.673051908974344 139.7376894074319 31.271 35.673060423550744 139.73768513327525 31.271 35.673060423550744 139.73768513327525 31.774 35.673051908974344 139.7376894074319 31.774</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-24690b7f-376c-4194-8e9d-886525448895">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-24690b7f-376c-4194-8e9d-886525448895">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-24690b7f-376c-4194-8e9d-886525448895">
											<gml:posList>35.67308979715215 139.73781870725048 8.64 35.67308979715215 139.73781870725048 31.774 35.67304653456088 139.73768659695392 31.774 35.67304653456088 139.73768659695392 16.553 35.673005946369585 139.73756263601118 16.553 35.673005946369585 139.73756263601118 8.64 35.67308979715215 139.73781870725048 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2f1f74e7-c158-4f7f-b6fd-80d14b55e669">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f1f74e7-c158-4f7f-b6fd-80d14b55e669">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f1f74e7-c158-4f7f-b6fd-80d14b55e669">
											<gml:posList>35.673142513296014 139.7376873219904 39.332 35.673142513296014 139.7376873219904 39.109 35.673113734405 139.73770110938662 39.109 35.673113734405 139.73770110938662 39.332 35.673142513296014 139.7376873219904 39.332</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bb5ce688-4b8a-40c2-ba50-de3abeeff04d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb5ce688-4b8a-40c2-ba50-de3abeeff04d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb5ce688-4b8a-40c2-ba50-de3abeeff04d">
											<gml:posList>35.673146210482216 139.73768928388145 39.332 35.673114764539434 139.7377043448221 39.332 35.673114764539434 139.7377043448221 35.885 35.673114764539434 139.7377043448221 8.64 35.673146210482216 139.73768928388145 8.64 35.673146210482216 139.73768928388145 39.332</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7ace81c7-b105-4bd3-b573-928a1841d6f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ace81c7-b105-4bd3-b573-928a1841d6f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ace81c7-b105-4bd3-b573-928a1841d6f0">
											<gml:posList>35.673113734405 139.73770110938662 39.332 35.673113734405 139.73770110938662 39.109 35.673111752115254 139.73770202862198 39.109 35.673111752115254 139.73770202862198 39.332 35.673113734405 139.73770110938662 39.332</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0f4e7f8a-ee96-41da-99bd-5465e711f9da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0f4e7f8a-ee96-41da-99bd-5465e711f9da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0f4e7f8a-ee96-41da-99bd-5465e711f9da">
											<gml:posList>35.67311015121786 139.7377064933723 39.332 35.67311015121786 139.7377064933723 35.009 35.67311076392259 139.7377062054289 35.009 35.67311076392259 139.7377062054289 35.885 35.673114764539434 139.7377043448221 35.885 35.673114764539434 139.7377043448221 39.332 35.67311015121786 139.7377064933723 39.332</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-87792e2a-3f6f-4d81-8cb1-86692af97b0e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-87792e2a-3f6f-4d81-8cb1-86692af97b0e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-87792e2a-3f6f-4d81-8cb1-86692af97b0e">
											<gml:posList>35.67311076392259 139.7377062054289 35.885 35.67311076392259 139.7377062054289 35.009 35.67312971239111 139.7377650061743 35.009 35.67312971239111 139.7377650061743 35.885 35.67311076392259 139.7377062054289 35.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0bb76adc-ce36-42c7-9091-3b9cc8905a21">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0bb76adc-ce36-42c7-9091-3b9cc8905a21">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0bb76adc-ce36-42c7-9091-3b9cc8905a21">
											<gml:posList>35.673114764539434 139.7377043448221 8.64 35.673114764539434 139.7377043448221 35.885 35.67313534834078 139.7377679930949 35.885 35.67313534834078 139.7377679930949 31.774 35.67314304692852 139.73779180047336 31.774 35.67314304692852 139.73779180047336 8.64 35.673114764539434 139.7377043448221 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b7dcd5a7-662b-44cf-848c-89b0eaaf32ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b7dcd5a7-662b-44cf-848c-89b0eaaf32ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b7dcd5a7-662b-44cf-848c-89b0eaaf32ce">
											<gml:posList>35.67309207236498 139.7378120765601 31.774 35.67309207236498 139.7378120765601 31.271 35.673051908974344 139.7376894074319 31.271 35.673051908974344 139.7376894074319 31.774 35.67309207236498 139.7378120765601 31.774</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b47154f4-1139-402d-891a-35af0245e16c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b47154f4-1139-402d-891a-35af0245e16c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b47154f4-1139-402d-891a-35af0245e16c">
											<gml:posList>35.67312971239111 139.7377650061743 35.885 35.67312971239111 139.7377650061743 35.009 35.67309787916444 139.73778046522256 35.009 35.67309787916444 139.73778046522256 35.885 35.67312971239111 139.7377650061743 35.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-850e3f06-10fc-4250-a17d-1e424e25e847">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-850e3f06-10fc-4250-a17d-1e424e25e847">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-850e3f06-10fc-4250-a17d-1e424e25e847">
											<gml:posList>35.67313151898359 139.73776985349488 31.774 35.67313534834078 139.7377679930949 31.774 35.67313534834078 139.7377679930949 35.885 35.67309551400902 139.73778733904746 35.885 35.67309551400902 139.73778733904746 31.271 35.67313151898359 139.73776985349488 31.271 35.67313151898359 139.73776985349488 31.774</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a3acc466-fb0d-4231-9af6-72213ff08df1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a3acc466-fb0d-4231-9af6-72213ff08df1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a3acc466-fb0d-4231-9af6-72213ff08df1">
											<gml:posList>35.67313151898359 139.73776985349488 31.774 35.67313151898359 139.73776985349488 31.271 35.67313771760365 139.73778901202485 31.271 35.67313771760365 139.73778901202485 31.774 35.67313151898359 139.73776985349488 31.774</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7b2bab66-ade8-49f0-b127-7fc2a72cafb6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b2bab66-ade8-49f0-b127-7fc2a72cafb6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b2bab66-ade8-49f0-b127-7fc2a72cafb6">
											<gml:posList>35.67313771760365 139.73778901202485 31.774 35.67313771760365 139.73778901202485 31.271 35.67309207236498 139.7378120765601 31.271 35.67309207236498 139.7378120765601 31.774 35.67313771760365 139.73778901202485 31.774</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-23c202fc-4ff4-46f1-8e50-0cf018e8083e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-23c202fc-4ff4-46f1-8e50-0cf018e8083e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-23c202fc-4ff4-46f1-8e50-0cf018e8083e">
											<gml:posList>35.67308979715215 139.73781870725048 8.64 35.67314304692852 139.73779180047336 8.64 35.67314304692852 139.73779180047336 31.774 35.67308979715215 139.73781870725048 31.774 35.67308979715215 139.73781870725048 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1614</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">220.8412</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1221</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.12</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>