<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_4223466c-6d75-4ae3-be31-a48b44a6bb09">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">422</bldg:usage>
			<bldg:measuredHeight uom="m">4.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>1</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66767508383003 139.74237816157904 0 35.667629203619775 139.74249717775598 0 35.66768231771709 139.7425279356145 0 35.66772819795728 139.7424089193762 0 35.66767508383003 139.74237816157904 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66767508383003 139.74237816157904 28.63 35.66772819795728 139.7424089193762 28.63 35.66768231771709 139.7425279356145 28.63 35.667629203619775 139.74249717775598 28.63 35.66767508383003 139.74237816157904 28.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66767508383003 139.74237816157904 28.63 35.667629203619775 139.74249717775598 28.63 35.667629203619775 139.74249717775598 32.87 35.66767508383003 139.74237816157904 32.87 35.66767508383003 139.74237816157904 28.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667629203619775 139.74249717775598 28.63 35.66768231771709 139.7425279356145 28.63 35.66768231771709 139.7425279356145 32.87 35.667629203619775 139.74249717775598 32.87 35.667629203619775 139.74249717775598 28.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66768231771709 139.7425279356145 28.63 35.66772819795728 139.7424089193762 28.63 35.66772819795728 139.7424089193762 32.87 35.66768231771709 139.7425279356145 32.87 35.66768231771709 139.7425279356145 28.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66772819795728 139.7424089193762 28.63 35.66767508383003 139.74237816157904 28.63 35.66767508383003 139.74237816157904 32.87 35.66772819795728 139.7424089193762 32.87 35.66772819795728 139.7424089193762 28.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66767508383003 139.74237816157904 32.87 35.667629203619775 139.74249717775598 32.87 35.66768231771709 139.7425279356145 32.87 35.66772819795728 139.7424089193762 32.87 35.66767508383003 139.74237816157904 32.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-95f8a370-a8ea-4afc-a7d2-054e46b1ba01"/>
							<gml:surfaceMember xlink:href="#poly-53498d81-cb80-4444-9b45-dbec5f10b654"/>
							<gml:surfaceMember xlink:href="#poly-5d654626-ae3e-4c64-b42e-faad5b27a6b7"/>
							<gml:surfaceMember xlink:href="#poly-42eeb175-ebec-4dd0-996b-a3256ef37f7c"/>
							<gml:surfaceMember xlink:href="#poly-aaaf3abb-60f6-48f8-a3c6-315f40700f04"/>
							<gml:surfaceMember xlink:href="#poly-859b7e72-5572-488e-8285-18751d0f4dfe"/>
							<gml:surfaceMember xlink:href="#poly-0026bc38-c2d5-471f-82a8-3a0bb83badef"/>
							<gml:surfaceMember xlink:href="#poly-f909329b-0af4-4604-bcf9-a46603b2fdcb"/>
							<gml:surfaceMember xlink:href="#poly-f403d7c2-97a2-4027-ba20-5210e7c2732e"/>
							<gml:surfaceMember xlink:href="#poly-de475d9e-28af-4f23-a693-552aee50c1db"/>
							<gml:surfaceMember xlink:href="#poly-e9a9ae9c-5dff-4ecb-84b3-43b0925238d7"/>
							<gml:surfaceMember xlink:href="#poly-782019f1-5652-4a19-93a0-9d295d3406d0"/>
							<gml:surfaceMember xlink:href="#poly-8c4a4e61-7c37-4ee2-a941-dcf687b6261a"/>
							<gml:surfaceMember xlink:href="#poly-90e4cb1b-4783-4558-8a6e-4525a1a29bc3"/>
							<gml:surfaceMember xlink:href="#poly-1f19f7c3-8a1d-424f-bdff-7d2564d645e0"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-95f8a370-a8ea-4afc-a7d2-054e46b1ba01">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-95f8a370-a8ea-4afc-a7d2-054e46b1ba01">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-95f8a370-a8ea-4afc-a7d2-054e46b1ba01">
											<gml:posList>35.66767508383003 139.74237816157904 28.63 35.66772819795725 139.7424089193762 28.63 35.667682317717095 139.7425279356145 28.63 35.66762920361977 139.74249717775598 28.63 35.66767508383003 139.74237816157904 28.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-53498d81-cb80-4444-9b45-dbec5f10b654">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-53498d81-cb80-4444-9b45-dbec5f10b654">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-53498d81-cb80-4444-9b45-dbec5f10b654">
											<gml:posList>35.66767508383003 139.74237816157904 32.2 35.66762920361977 139.74249717775598 32.2 35.667643915811915 139.74248758430937 32.845 35.66767508383003 139.74237816157904 32.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5d654626-ae3e-4c64-b42e-faad5b27a6b7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d654626-ae3e-4c64-b42e-faad5b27a6b7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d654626-ae3e-4c64-b42e-faad5b27a6b7">
											<gml:posList>35.667682317717095 139.7425279356145 32.2 35.66768123964389 139.74250877222 32.845 35.667643915811915 139.74248758430937 32.845 35.66762920361977 139.74249717775598 32.2 35.667682317717095 139.7425279356145 32.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-42eeb175-ebec-4dd0-996b-a3256ef37f7c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-42eeb175-ebec-4dd0-996b-a3256ef37f7c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-42eeb175-ebec-4dd0-996b-a3256ef37f7c">
											<gml:posList>35.667643915811915 139.74248758430937 32.845 35.66767818982912 139.74239707966098 32.845 35.66767508383003 139.74237816157904 32.2 35.667643915811915 139.74248758430937 32.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-aaaf3abb-60f6-48f8-a3c6-315f40700f04">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aaaf3abb-60f6-48f8-a3c6-315f40700f04">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aaaf3abb-60f6-48f8-a3c6-315f40700f04">
											<gml:posList>35.667694041227215 139.74241597224733 33.916 35.66767818982912 139.74239707966098 32.845 35.667643915811915 139.74248758430937 32.845 35.66766246484849 139.74249790224295 33.916 35.667694041227215 139.74241597224733 33.916</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-859b7e72-5572-488e-8285-18751d0f4dfe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-859b7e72-5572-488e-8285-18751d0f4dfe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-859b7e72-5572-488e-8285-18751d0f4dfe">
											<gml:posList>35.667694041227215 139.74241597224733 33.916 35.66766246484849 139.74249790224295 33.916 35.66768123964389 139.74250877222 32.845 35.66771546120394 139.7424203994552 32.845 35.667694041227215 139.74241597224733 33.916</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0026bc38-c2d5-471f-82a8-3a0bb83badef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0026bc38-c2d5-471f-82a8-3a0bb83badef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0026bc38-c2d5-471f-82a8-3a0bb83badef">
											<gml:posList>35.66767508383003 139.74237816157904 32.2 35.66767818982912 139.74239707966098 32.845 35.66771546120394 139.7424203994552 32.845 35.66767508383003 139.74237816157904 32.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f909329b-0af4-4604-bcf9-a46603b2fdcb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f909329b-0af4-4604-bcf9-a46603b2fdcb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f909329b-0af4-4604-bcf9-a46603b2fdcb">
											<gml:posList>35.66767818982912 139.74239707966098 32.845 35.667694041227215 139.74241597224733 33.916 35.66771546120394 139.7424203994552 32.845 35.66767818982912 139.74239707966098 32.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f403d7c2-97a2-4027-ba20-5210e7c2732e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f403d7c2-97a2-4027-ba20-5210e7c2732e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f403d7c2-97a2-4027-ba20-5210e7c2732e">
											<gml:posList>35.66771546120394 139.7424203994552 32.845 35.66772819795725 139.7424089193762 32.2 35.66767508383003 139.74237816157904 32.2 35.66771546120394 139.7424203994552 32.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-de475d9e-28af-4f23-a693-552aee50c1db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de475d9e-28af-4f23-a693-552aee50c1db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de475d9e-28af-4f23-a693-552aee50c1db">
											<gml:posList>35.66768123964389 139.74250877222 32.845 35.667682317717095 139.7425279356145 32.2 35.66772819795725 139.7424089193762 32.2 35.66771546120394 139.7424203994552 32.845 35.66768123964389 139.74250877222 32.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e9a9ae9c-5dff-4ecb-84b3-43b0925238d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e9a9ae9c-5dff-4ecb-84b3-43b0925238d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e9a9ae9c-5dff-4ecb-84b3-43b0925238d7">
											<gml:posList>35.66772819795725 139.7424089193762 28.63 35.66767508383003 139.74237816157904 28.63 35.66767508383003 139.74237816157904 32.2 35.66772819795725 139.7424089193762 32.2 35.66772819795725 139.7424089193762 28.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-782019f1-5652-4a19-93a0-9d295d3406d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-782019f1-5652-4a19-93a0-9d295d3406d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-782019f1-5652-4a19-93a0-9d295d3406d0">
											<gml:posList>35.66767508383003 139.74237816157904 28.63 35.66762920361977 139.74249717775598 28.63 35.66762920361977 139.74249717775598 32.2 35.66767508383003 139.74237816157904 32.2 35.66767508383003 139.74237816157904 28.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8c4a4e61-7c37-4ee2-a941-dcf687b6261a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c4a4e61-7c37-4ee2-a941-dcf687b6261a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c4a4e61-7c37-4ee2-a941-dcf687b6261a">
											<gml:posList>35.667682317717095 139.7425279356145 28.63 35.66772819795725 139.7424089193762 28.63 35.66772819795725 139.7424089193762 32.2 35.667682317717095 139.7425279356145 32.2 35.667682317717095 139.7425279356145 28.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-90e4cb1b-4783-4558-8a6e-4525a1a29bc3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-90e4cb1b-4783-4558-8a6e-4525a1a29bc3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-90e4cb1b-4783-4558-8a6e-4525a1a29bc3">
											<gml:posList>35.66768123964389 139.74250877222 32.845 35.66766246484849 139.74249790224295 33.916 35.667643915811915 139.74248758430937 32.845 35.66768123964389 139.74250877222 32.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1f19f7c3-8a1d-424f-bdff-7d2564d645e0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f19f7c3-8a1d-424f-bdff-7d2564d645e0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f19f7c3-8a1d-424f-bdff-7d2564d645e0">
											<gml:posList>35.66762920361977 139.74249717775598 28.63 35.667682317717095 139.7425279356145 28.63 35.667682317717095 139.7425279356145 32.2 35.66762920361977 139.74249717775598 32.2 35.66762920361977 139.74249717775598 28.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10783</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">104.17909</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1003</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">6</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1123</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.1</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">22</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>