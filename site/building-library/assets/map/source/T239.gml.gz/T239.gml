<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_426039c4-28a0-4b06-b97f-18087d3e2ffd">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">403</bldg:usage>
			<bldg:measuredHeight uom="m">22.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>7</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67179971457241 139.7385578380962 0 35.67178107196471 139.738555021196 0 35.67176643477232 139.7385678744748 0 35.67176539863026 139.7385798831908 0 35.67176051616426 139.73856075651074 0 35.67174335920536 139.73856733838144 0 35.6717353302579 139.73853588759366 0 35.671687256521714 139.73855431466475 0 35.67172916429688 139.73871852576139 0 35.67183424172927 139.73867824787592 0 35.671819187509165 139.73861928861268 0 35.67179838108537 139.73862726664004 0 35.671793986862454 139.73861003936247 0 35.67180762432723 139.73859819249574 0 35.67180968906917 139.73857604191133 0 35.67179971457241 139.7385578380962 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67179971457241 139.7385578380962 10.38 35.67180968906917 139.73857604191133 10.38 35.67180762432723 139.73859819249574 10.38 35.671793986862454 139.73861003936247 10.38 35.67179838108537 139.73862726664004 10.38 35.671819187509165 139.73861928861268 10.38 35.67183424172927 139.73867824787592 10.38 35.67172916429688 139.73871852576139 10.38 35.671687256521714 139.73855431466475 10.38 35.6717353302579 139.73853588759366 10.38 35.67174335920536 139.73856733838144 10.38 35.67176051616426 139.73856075651074 10.38 35.67176539863026 139.7385798831908 10.38 35.67176643477232 139.7385678744748 10.38 35.67178107196471 139.738555021196 10.38 35.67179971457241 139.7385578380962 10.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67179971457241 139.7385578380962 10.38 35.67178107196471 139.738555021196 10.38 35.67178107196471 139.738555021196 32.71 35.67179971457241 139.7385578380962 32.71 35.67179971457241 139.7385578380962 10.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67178107196471 139.738555021196 10.38 35.67176643477232 139.7385678744748 10.38 35.67176643477232 139.7385678744748 32.71 35.67178107196471 139.738555021196 32.71 35.67178107196471 139.738555021196 10.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67176643477232 139.7385678744748 10.38 35.67176539863026 139.7385798831908 10.38 35.67176539863026 139.7385798831908 32.71 35.67176643477232 139.7385678744748 32.71 35.67176643477232 139.7385678744748 10.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67176539863026 139.7385798831908 10.38 35.67176051616426 139.73856075651074 10.38 35.67176051616426 139.73856075651074 32.71 35.67176539863026 139.7385798831908 32.71 35.67176539863026 139.7385798831908 10.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67176051616426 139.73856075651074 10.38 35.67174335920536 139.73856733838144 10.38 35.67174335920536 139.73856733838144 32.71 35.67176051616426 139.73856075651074 32.71 35.67176051616426 139.73856075651074 10.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67174335920536 139.73856733838144 10.38 35.6717353302579 139.73853588759366 10.38 35.6717353302579 139.73853588759366 32.71 35.67174335920536 139.73856733838144 32.71 35.67174335920536 139.73856733838144 10.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6717353302579 139.73853588759366 10.38 35.671687256521714 139.73855431466475 10.38 35.671687256521714 139.73855431466475 32.71 35.6717353302579 139.73853588759366 32.71 35.6717353302579 139.73853588759366 10.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671687256521714 139.73855431466475 10.38 35.67172916429688 139.73871852576139 10.38 35.67172916429688 139.73871852576139 32.71 35.671687256521714 139.73855431466475 32.71 35.671687256521714 139.73855431466475 10.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67172916429688 139.73871852576139 10.38 35.67183424172927 139.73867824787592 10.38 35.67183424172927 139.73867824787592 32.71 35.67172916429688 139.73871852576139 32.71 35.67172916429688 139.73871852576139 10.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67183424172927 139.73867824787592 10.38 35.671819187509165 139.73861928861268 10.38 35.671819187509165 139.73861928861268 32.71 35.67183424172927 139.73867824787592 32.71 35.67183424172927 139.73867824787592 10.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671819187509165 139.73861928861268 10.38 35.67179838108537 139.73862726664004 10.38 35.67179838108537 139.73862726664004 32.71 35.671819187509165 139.73861928861268 32.71 35.671819187509165 139.73861928861268 10.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67179838108537 139.73862726664004 10.38 35.671793986862454 139.73861003936247 10.38 35.671793986862454 139.73861003936247 32.71 35.67179838108537 139.73862726664004 32.71 35.67179838108537 139.73862726664004 10.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671793986862454 139.73861003936247 10.38 35.67180762432723 139.73859819249574 10.38 35.67180762432723 139.73859819249574 32.71 35.671793986862454 139.73861003936247 32.71 35.671793986862454 139.73861003936247 10.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67180762432723 139.73859819249574 10.38 35.67180968906917 139.73857604191133 10.38 35.67180968906917 139.73857604191133 32.71 35.67180762432723 139.73859819249574 32.71 35.67180762432723 139.73859819249574 10.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67180968906917 139.73857604191133 10.38 35.67179971457241 139.7385578380962 10.38 35.67179971457241 139.7385578380962 32.71 35.67180968906917 139.73857604191133 32.71 35.67180968906917 139.73857604191133 10.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67179971457241 139.7385578380962 32.71 35.67178107196471 139.738555021196 32.71 35.67176643477232 139.7385678744748 32.71 35.67176539863026 139.7385798831908 32.71 35.67176051616426 139.73856075651074 32.71 35.67174335920536 139.73856733838144 32.71 35.6717353302579 139.73853588759366 32.71 35.671687256521714 139.73855431466475 32.71 35.67172916429688 139.73871852576139 32.71 35.67183424172927 139.73867824787592 32.71 35.671819187509165 139.73861928861268 32.71 35.67179838108537 139.73862726664004 32.71 35.671793986862454 139.73861003936247 32.71 35.67180762432723 139.73859819249574 32.71 35.67180968906917 139.73857604191133 32.71 35.67179971457241 139.7385578380962 32.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-1cabc221-c9c3-4616-8f9e-a2ceb2968343"/>
							<gml:surfaceMember xlink:href="#poly-6e374445-010a-4852-bfc5-ae31a263eddd"/>
							<gml:surfaceMember xlink:href="#poly-9f0c27c8-a12c-4b75-a292-c0a73b02b6c5"/>
							<gml:surfaceMember xlink:href="#poly-117e28a4-76b2-49d1-80a3-588453b3af17"/>
							<gml:surfaceMember xlink:href="#poly-650783dd-cc04-4529-9909-f61c5ed46c61"/>
							<gml:surfaceMember xlink:href="#poly-1836c656-f100-4b69-9498-3f0862022069"/>
							<gml:surfaceMember xlink:href="#poly-59476991-3c36-4712-9304-58eefe4aa6e7"/>
							<gml:surfaceMember xlink:href="#poly-7fa5c959-dd9f-4c09-84f7-7f2783f63152"/>
							<gml:surfaceMember xlink:href="#poly-52b47d94-d0cb-4d9f-8b13-ae70235f1b3d"/>
							<gml:surfaceMember xlink:href="#poly-3a9206fe-65b5-462f-84b0-aa635401bcaf"/>
							<gml:surfaceMember xlink:href="#poly-2c01af23-43b1-4431-b73c-fca4dfeaed66"/>
							<gml:surfaceMember xlink:href="#poly-758d627c-202f-4b7f-985e-8a371e71edbd"/>
							<gml:surfaceMember xlink:href="#poly-1fb3ad4a-05f0-4698-aecf-9e504005ab6b"/>
							<gml:surfaceMember xlink:href="#poly-c2604db5-4729-4ecc-9d5c-4af3c80c20a4"/>
							<gml:surfaceMember xlink:href="#poly-7f727c2c-805e-4e2b-930d-6a8a879c1214"/>
							<gml:surfaceMember xlink:href="#poly-87680592-33bd-47a6-bed1-f326fc741916"/>
							<gml:surfaceMember xlink:href="#poly-87f887d2-6861-4a3b-bdd7-8b73b4ad7eb3"/>
							<gml:surfaceMember xlink:href="#poly-96b81c78-1f82-4753-859b-cc2b78ee5559"/>
							<gml:surfaceMember xlink:href="#poly-c6bfeadf-152d-49c5-8a01-ebfda721e898"/>
							<gml:surfaceMember xlink:href="#poly-60ed949d-f229-460f-a18d-bfb23f066bc9"/>
							<gml:surfaceMember xlink:href="#poly-e652d9e2-8c9c-4b52-97ae-0c85c67c51f1"/>
							<gml:surfaceMember xlink:href="#poly-60a12ac9-de20-40a8-9335-b620bb90e949"/>
							<gml:surfaceMember xlink:href="#poly-bee44e9a-29e0-40c2-8e16-d205c9e69b01"/>
							<gml:surfaceMember xlink:href="#poly-a11cf555-c7ef-484d-846a-fd6650e7582d"/>
							<gml:surfaceMember xlink:href="#poly-c05729f6-334a-406d-9541-58a1bea59240"/>
							<gml:surfaceMember xlink:href="#poly-22554fdd-b65b-42f3-96cb-2beb7a95b892"/>
							<gml:surfaceMember xlink:href="#poly-3d99930b-8b15-4f6e-bb28-9bafc7cc6a6f"/>
							<gml:surfaceMember xlink:href="#poly-2826777a-44ef-4069-8298-63f88bdbcde9"/>
							<gml:surfaceMember xlink:href="#poly-a9d92500-6686-4c5b-96c6-d8e8ae8a8141"/>
							<gml:surfaceMember xlink:href="#poly-f60a08e6-0b97-4fcb-84af-7cfc840f8af6"/>
							<gml:surfaceMember xlink:href="#poly-b57cda0c-24e8-4b82-9a81-2aa475f88cd0"/>
							<gml:surfaceMember xlink:href="#poly-e69dbddb-847e-487d-ace9-90305a6c3e39"/>
							<gml:surfaceMember xlink:href="#poly-045f23d2-a2b4-4e6a-825f-a4b13872093b"/>
							<gml:surfaceMember xlink:href="#poly-b61c99c7-6797-4542-9882-f66bbe714b22"/>
							<gml:surfaceMember xlink:href="#poly-9aef46cd-fef3-45c6-bf81-c7e70238558d"/>
							<gml:surfaceMember xlink:href="#poly-39bc5a9e-ce6b-455e-8634-ee3d92535af1"/>
							<gml:surfaceMember xlink:href="#poly-04770c67-87d0-4d6e-b048-eba48eee5aff"/>
							<gml:surfaceMember xlink:href="#poly-21cd5a6e-a79e-4594-be43-92c588989d7b"/>
							<gml:surfaceMember xlink:href="#poly-36433d58-aae2-4cbe-940f-890660bb91ae"/>
							<gml:surfaceMember xlink:href="#poly-4163a9f3-3579-433a-9ae4-dca734f0abb6"/>
							<gml:surfaceMember xlink:href="#poly-71b6154c-1214-4ce1-b74e-435f5bcfcbbb"/>
							<gml:surfaceMember xlink:href="#poly-8a6c3f2b-75b2-4c72-b57b-5e708a75c9e3"/>
							<gml:surfaceMember xlink:href="#poly-6778415b-e646-4798-85a5-c2a242432816"/>
							<gml:surfaceMember xlink:href="#poly-85f39ffe-4980-4994-8f21-d45e20e78729"/>
							<gml:surfaceMember xlink:href="#poly-cb224a04-b060-4a1a-9f47-2a360ab06283"/>
							<gml:surfaceMember xlink:href="#poly-12650a02-020b-4085-8bb4-f64cf503d804"/>
							<gml:surfaceMember xlink:href="#poly-5b287239-cfd1-48db-b5c8-4547879ec589"/>
							<gml:surfaceMember xlink:href="#poly-67b66a42-d218-457d-878b-09631aca9df2"/>
							<gml:surfaceMember xlink:href="#poly-0aff4a63-6cfd-48e2-bffc-5e363c3b6d8b"/>
							<gml:surfaceMember xlink:href="#poly-31527fbc-401a-4b75-b308-2b9f33e80aa0"/>
							<gml:surfaceMember xlink:href="#poly-ef6fbe1c-9fa2-437e-9d8c-90e04a16e7b5"/>
							<gml:surfaceMember xlink:href="#poly-d9a467c6-ded7-4cf4-9674-0c3baaad04ad"/>
							<gml:surfaceMember xlink:href="#poly-077cc5cd-b9a2-4af8-9331-320e5341c395"/>
							<gml:surfaceMember xlink:href="#poly-48376a36-d291-4f60-91b4-66a85dafaa3e"/>
							<gml:surfaceMember xlink:href="#poly-f13d521f-061e-4982-9a52-5421d0474970"/>
							<gml:surfaceMember xlink:href="#poly-c47ecb1b-42f1-4435-b779-aa69afa30fa5"/>
							<gml:surfaceMember xlink:href="#poly-cb298bc9-5fec-42bc-8a0f-72b95e7f0d5a"/>
							<gml:surfaceMember xlink:href="#poly-d231e7e0-f39c-4ab4-987b-1a0189fc6804"/>
							<gml:surfaceMember xlink:href="#poly-c1958466-c824-4a80-aa0e-27fba2f1cc3f"/>
							<gml:surfaceMember xlink:href="#poly-5825351f-fe4a-49a6-92a9-06cae9f89acc"/>
							<gml:surfaceMember xlink:href="#poly-eaa0286b-5dd5-4696-85a3-2308bc6d6d95"/>
							<gml:surfaceMember xlink:href="#poly-587520e1-7e44-4102-a89c-566c4ea80b27"/>
							<gml:surfaceMember xlink:href="#poly-96428671-9146-4780-97bd-6c7519fc037f"/>
							<gml:surfaceMember xlink:href="#poly-674e4aca-2742-46b6-8e14-aba12ab89dc3"/>
							<gml:surfaceMember xlink:href="#poly-e3fc15e3-3806-4c74-9c9a-0771d73d5184"/>
							<gml:surfaceMember xlink:href="#poly-61bb9ce8-9500-4427-a943-f14c1fc2b04e"/>
							<gml:surfaceMember xlink:href="#poly-9319c962-d446-40f3-b8e8-bb77fc12961b"/>
							<gml:surfaceMember xlink:href="#poly-4905a238-0c68-46b8-a64e-34b95a3375b5"/>
							<gml:surfaceMember xlink:href="#poly-6ed6e43b-44ae-453d-8d2a-b603fc89aa0d"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_426039c4-28a0-4b06-b97f-18087d3e2ffd_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bccb1ce7-a572-4214-9f48-d6699c80e5db">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671766771067155 139.73861724066361 32.839 35.671767286587034 139.7386194493447 32.839 35.67175412114773 139.73862404917398 32.839 35.671749870031526 139.73860540779168 32.839 35.67177046919936 139.73859750733357 32.839 35.67178790219293 139.73860952736808 32.839 35.671766771067155 139.73861724066361 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8216b8b-8625-42bb-81d9-0640f72a9fb5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671766771067155 139.73861724066361 33.091 35.67178790219293 139.73860952736808 33.091 35.67178941732344 139.73861057499107 33.091 35.671789598397304 139.73861159105084 33.091 35.67176729560075 139.73861944933404 33.091 35.671766771067155 139.73861724066361 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-417a5cf6-3668-4dd4-9e24-115d53739d4d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-417a5cf6-3668-4dd4-9e24-115d53739d4d_0">
											<gml:posList>35.67178941732344 139.73861057499107 33.091 35.67178941732344 139.73861057499107 33.251 35.671789598397304 139.73861159105084 33.251 35.671789598397304 139.73861159105084 33.091 35.67178941732344 139.73861057499107 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-982bc06f-c522-452d-9818-008df5b7a99c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-982bc06f-c522-452d-9818-008df5b7a99c_0">
											<gml:posList>35.671766771067155 139.73861724066361 33.091 35.67176729560075 139.73861944933404 33.091 35.671767286587034 139.7386194493447 32.839 35.671766771067155 139.73861724066361 32.839 35.671766771067155 139.73861724066361 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7943c105-5752-4f77-9857-b211d5110710">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7943c105-5752-4f77-9857-b211d5110710_0">
											<gml:posList>35.67175412114773 139.73862404917398 32.839 35.67175412114773 139.73862404917398 33.251 35.671749870031526 139.73860540779168 33.251 35.671749870031526 139.73860540779168 32.839 35.67175412114773 139.73862404917398 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-96fc9ecd-23a1-4cb8-ac0e-9352cb91a5e3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-96fc9ecd-23a1-4cb8-ac0e-9352cb91a5e3_0">
											<gml:posList>35.671749870031526 139.73860540779168 32.839 35.671749870031526 139.73860540779168 33.251 35.67177046919936 139.73859750733357 33.251 35.67177046919936 139.73859750733357 32.839 35.671749870031526 139.73860540779168 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5adf5135-9276-41d7-9e46-0e7e06e2310e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5adf5135-9276-41d7-9e46-0e7e06e2310e_0">
											<gml:posList>35.671789598397304 139.73861159105084 33.251 35.67178941732344 139.73861057499107 33.251 35.67177046919936 139.73859750733357 33.251 35.671749870031526 139.73860540779168 33.251 35.67175412114773 139.73862404917398 33.251 35.671789598397304 139.73861159105084 33.251</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-12d28dd4-4594-4da3-adf3-444656e5fc10">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-12d28dd4-4594-4da3-adf3-444656e5fc10_0">
											<gml:posList>35.671789598397304 139.73861159105084 33.091 35.671789598397304 139.73861159105084 33.251 35.67175412114773 139.73862404917398 33.251 35.67175412114773 139.73862404917398 32.839 35.671767286587034 139.7386194493447 32.839 35.67176729560075 139.73861944933404 33.091 35.671789598397304 139.73861159105084 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0158c49a-814a-4a8f-844f-befea34e3e58">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0158c49a-814a-4a8f-844f-befea34e3e58_0">
											<gml:posList>35.67178790219293 139.73860952736808 32.839 35.67178790219293 139.73860952736808 33.091 35.671766771067155 139.73861724066361 33.091 35.671766771067155 139.73861724066361 32.839 35.67178790219293 139.73860952736808 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-21c66ea9-5f49-4743-9581-75309623bebf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-21c66ea9-5f49-4743-9581-75309623bebf_0">
											<gml:posList>35.67178790219293 139.73860952736808 33.091 35.67178790219293 139.73860952736808 32.839 35.67177046919936 139.73859750733357 32.839 35.67177046919936 139.73859750733357 33.251 35.67178941732344 139.73861057499107 33.251 35.67178941732344 139.73861057499107 33.091 35.67178790219293 139.73860952736808 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_426039c4-28a0-4b06-b97f-18087d3e2ffd_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-240f7ae0-8db1-4170-b840-43f07e7beff1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67175834842527 139.73864676672616 32.839 35.671770377954275 139.73864193626648 32.839 35.67177885779448 139.7386736848005 32.839 35.67176682825554 139.7386785042095 32.839 35.67175834842527 139.73864676672616 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b3757da-c183-4b3b-b12d-47379e78b1b0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67175043987892 139.73868816710717 32.839 35.67175077520122 139.738690475419 32.839 35.671750713954516 139.7386928283847 32.839 35.67175024702959 139.7386951045042 32.839 35.67174941042055 139.73869722640976 32.839 35.67174823107306 139.7386990725586 32.839 35.67174676302604 139.73870058765476 32.839 35.671745069314795 139.73870169429867 32.839 35.671743231028074 139.73870234820882 32.839 35.67174132024962 139.73870251616086 32.839 35.67173941809421 139.73870218701265 32.839 35.67173761471643 139.73870138275063 32.839 35.67173598225205 139.7387001364291 32.839 35.671734601876665 139.7386985142309 32.839 35.67173352770729 139.7386965602779 32.839 35.67173281391303 139.7386943849707 32.839 35.6717324785908 139.7386920766594 32.839 35.671732539837485 139.7386897236942 32.839 35.671732997739916 139.73868743653938 32.839 35.67173384337119 139.73868532566996 32.839 35.67173502270979 139.7386834684748 32.839 35.67173649076526 139.73868196442498 32.839 35.67173818447633 139.7386808577808 32.839 35.67174002276293 139.73868020387016 32.839 35.67174193354137 139.73868003591758 32.839 35.67174383569683 139.7386803650653 32.839 35.671745639066074 139.73868115828046 32.839 35.67174726251692 139.7386824046124 32.839 35.67174864290121 139.738684037857 32.839 35.671749726075824 139.73868598075313 32.839 35.67175043987892 139.73868816710717 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-abd47613-261b-47d6-9099-7e1928acce2e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-abd47613-261b-47d6-9099-7e1928acce2e_0">
											<gml:posList>35.671732539837485 139.7386897236942 32.839 35.6717324785908 139.7386920766594 32.839 35.6717324785908 139.7386920766594 35.729 35.671732539837485 139.7386897236942 35.729 35.671732539837485 139.7386897236942 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c096bcff-3406-41cf-98e7-7a4d4ae36f8f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c096bcff-3406-41cf-98e7-7a4d4ae36f8f_0">
											<gml:posList>35.6717324785908 139.7386920766594 32.839 35.67173281391303 139.7386943849707 32.839 35.67173281391303 139.7386943849707 35.729 35.6717324785908 139.7386920766594 35.729 35.6717324785908 139.7386920766594 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4b794db-9047-4f56-81c1-99fac715f873">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a4b794db-9047-4f56-81c1-99fac715f873_0">
											<gml:posList>35.671732997739916 139.73868743653938 32.839 35.671732539837485 139.7386897236942 32.839 35.671732539837485 139.7386897236942 35.729 35.671732997739916 139.73868743653938 35.729 35.671732997739916 139.73868743653938 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c4ef480c-5e13-449c-be2c-5e658eabf3aa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c4ef480c-5e13-449c-be2c-5e658eabf3aa_0">
											<gml:posList>35.67173281391303 139.7386943849707 32.839 35.67173352770729 139.7386965602779 32.839 35.67173352770729 139.7386965602779 35.729 35.67173281391303 139.7386943849707 35.729 35.67173281391303 139.7386943849707 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f944f253-f1c9-4ea3-9c18-fc6f05fb4e66">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f944f253-f1c9-4ea3-9c18-fc6f05fb4e66_0">
											<gml:posList>35.67173384337119 139.73868532566996 32.839 35.671732997739916 139.73868743653938 32.839 35.671732997739916 139.73868743653938 35.729 35.67173384337119 139.73868532566996 35.729 35.67173384337119 139.73868532566996 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e7b5781-563c-4f31-a39a-9d2d43e38181">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3e7b5781-563c-4f31-a39a-9d2d43e38181_0">
											<gml:posList>35.67173352770729 139.7386965602779 32.839 35.671734601876665 139.7386985142309 32.839 35.671734601876665 139.7386985142309 35.729 35.67173352770729 139.7386965602779 35.729 35.67173352770729 139.7386965602779 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df54bd26-70a0-4237-9fb4-92e251bc8ee5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-df54bd26-70a0-4237-9fb4-92e251bc8ee5_0">
											<gml:posList>35.67173502270979 139.7386834684748 32.839 35.67173384337119 139.73868532566996 32.839 35.67173384337119 139.73868532566996 35.729 35.67173502270979 139.7386834684748 35.729 35.67173502270979 139.7386834684748 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29d9c9fd-385c-4a22-9b68-a18299595f33">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29d9c9fd-385c-4a22-9b68-a18299595f33_0">
											<gml:posList>35.671734601876665 139.7386985142309 32.839 35.67173598225205 139.7387001364291 32.839 35.67173598225205 139.7387001364291 35.729 35.671734601876665 139.7386985142309 35.729 35.671734601876665 139.7386985142309 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4f1b37a9-b39a-42a7-96c5-b4171e1788ab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4f1b37a9-b39a-42a7-96c5-b4171e1788ab_0">
											<gml:posList>35.67173649076526 139.73868196442498 32.839 35.67173502270979 139.7386834684748 32.839 35.67173502270979 139.7386834684748 35.729 35.67173649076526 139.73868196442498 35.729 35.67173649076526 139.73868196442498 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e7faebf7-9b3a-4fc0-ad85-0fcf4f4fe48e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e7faebf7-9b3a-4fc0-ad85-0fcf4f4fe48e_0">
											<gml:posList>35.67173598225205 139.7387001364291 32.839 35.67173761471643 139.73870138275063 32.839 35.67173761471643 139.73870138275063 35.729 35.67173598225205 139.7387001364291 35.729 35.67173598225205 139.7387001364291 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b60992a1-ea26-4ec4-ac5a-33add18c2b16">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b60992a1-ea26-4ec4-ac5a-33add18c2b16_0">
											<gml:posList>35.67173818447633 139.7386808577808 32.839 35.67173649076526 139.73868196442498 32.839 35.67173649076526 139.73868196442498 35.729 35.67173818447633 139.7386808577808 35.729 35.67173818447633 139.7386808577808 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b4ffeb0-f4d7-46de-aa7c-7fce24d63f0b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7b4ffeb0-f4d7-46de-aa7c-7fce24d63f0b_0">
											<gml:posList>35.67173761471643 139.73870138275063 32.839 35.67173941809421 139.73870218701265 32.839 35.67173941809421 139.73870218701265 35.729 35.67173761471643 139.73870138275063 35.729 35.67173761471643 139.73870138275063 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d65b407c-af51-48cb-abee-4a539337c882">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d65b407c-af51-48cb-abee-4a539337c882_0">
											<gml:posList>35.67174002276293 139.73868020387016 32.839 35.67173818447633 139.7386808577808 32.839 35.67173818447633 139.7386808577808 35.729 35.67174002276293 139.73868020387016 35.729 35.67174002276293 139.73868020387016 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b73dfaac-6594-4a9b-b0b1-c6e9f829ea77">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b73dfaac-6594-4a9b-b0b1-c6e9f829ea77_0">
											<gml:posList>35.67173941809421 139.73870218701265 32.839 35.67174132024962 139.73870251616086 32.839 35.67174132024962 139.73870251616086 35.729 35.67173941809421 139.73870218701265 35.729 35.67173941809421 139.73870218701265 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-991f2b80-1155-4016-9632-60334e2e9724">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-991f2b80-1155-4016-9632-60334e2e9724_0">
											<gml:posList>35.67174193354137 139.73868003591758 32.839 35.67174002276293 139.73868020387016 32.839 35.67174002276293 139.73868020387016 35.729 35.67174193354137 139.73868003591758 35.729 35.67174193354137 139.73868003591758 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a8f12345-30f8-44c1-82eb-ec88d01dacea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a8f12345-30f8-44c1-82eb-ec88d01dacea_0">
											<gml:posList>35.67174864290121 139.738684037857 35.729 35.67174726251692 139.7386824046124 35.729 35.671745639066074 139.73868115828046 35.729 35.67174383569683 139.7386803650653 35.729 35.67174193354137 139.73868003591758 35.729 35.67174002276293 139.73868020387016 35.729 35.67173818447633 139.7386808577808 35.729 35.67173649076526 139.73868196442498 35.729 35.67173502270979 139.7386834684748 35.729 35.67173384337119 139.73868532566996 35.729 35.671732997739916 139.73868743653938 35.729 35.671732539837485 139.7386897236942 35.729 35.6717324785908 139.7386920766594 35.729 35.67173281391303 139.7386943849707 35.729 35.67173352770729 139.7386965602779 35.729 35.671734601876665 139.7386985142309 35.729 35.67173598225205 139.7387001364291 35.729 35.67173761471643 139.73870138275063 35.729 35.67173941809421 139.73870218701265 35.729 35.67174132024962 139.73870251616086 35.729 35.671743231028074 139.73870234820882 35.729 35.671745069314795 139.73870169429867 35.729 35.67174676302604 139.73870058765476 35.729 35.67174823107306 139.7386990725586 35.729 35.67174941042055 139.73869722640976 35.729 35.67175024702959 139.7386951045042 35.729 35.671750713954516 139.7386928283847 35.729 35.67175077520122 139.738690475419 35.729 35.67175043987892 139.73868816710717 35.729 35.671749726075824 139.73868598075313 35.729 35.67174864290121 139.738684037857 35.729</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db04ebbb-c5ec-4bd6-9280-e2fbefc3052f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-db04ebbb-c5ec-4bd6-9280-e2fbefc3052f_0">
											<gml:posList>35.67174132024962 139.73870251616086 32.839 35.671743231028074 139.73870234820882 32.839 35.671743231028074 139.73870234820882 35.729 35.67174132024962 139.73870251616086 35.729 35.67174132024962 139.73870251616086 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c68227aa-b835-45c9-bcc7-02d8d0e7eaa1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c68227aa-b835-45c9-bcc7-02d8d0e7eaa1_0">
											<gml:posList>35.67174383569683 139.7386803650653 32.839 35.67174193354137 139.73868003591758 32.839 35.67174193354137 139.73868003591758 35.729 35.67174383569683 139.7386803650653 35.729 35.67174383569683 139.7386803650653 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e5fae45c-6e97-4235-86e8-8fc6a0a8e2ad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e5fae45c-6e97-4235-86e8-8fc6a0a8e2ad_0">
											<gml:posList>35.671743231028074 139.73870234820882 32.839 35.671745069314795 139.73870169429867 32.839 35.671745069314795 139.73870169429867 35.729 35.671743231028074 139.73870234820882 35.729 35.671743231028074 139.73870234820882 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c777bdb6-10ec-43e9-b794-d014425759a4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c777bdb6-10ec-43e9-b794-d014425759a4_0">
											<gml:posList>35.671745639066074 139.73868115828046 32.839 35.67174383569683 139.7386803650653 32.839 35.67174383569683 139.7386803650653 35.729 35.671745639066074 139.73868115828046 35.729 35.671745639066074 139.73868115828046 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-599875cd-cbf2-415b-8391-787d23e3e810">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-599875cd-cbf2-415b-8391-787d23e3e810_0">
											<gml:posList>35.671745069314795 139.73870169429867 32.839 35.67174676302604 139.73870058765476 32.839 35.67174676302604 139.73870058765476 35.729 35.671745069314795 139.73870169429867 35.729 35.671745069314795 139.73870169429867 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-41cef3a8-6eca-4460-bebb-7dbe7a223e16">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-41cef3a8-6eca-4460-bebb-7dbe7a223e16_0">
											<gml:posList>35.67174726251692 139.7386824046124 32.839 35.671745639066074 139.73868115828046 32.839 35.671745639066074 139.73868115828046 35.729 35.67174726251692 139.7386824046124 35.729 35.67174726251692 139.7386824046124 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df1c9e17-bc49-4063-8464-33e69ea67b31">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-df1c9e17-bc49-4063-8464-33e69ea67b31_0">
											<gml:posList>35.67174676302604 139.73870058765476 32.839 35.67174823107306 139.7386990725586 32.839 35.67174823107306 139.7386990725586 35.729 35.67174676302604 139.73870058765476 35.729 35.67174676302604 139.73870058765476 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-500713e7-ca20-4e2b-adfd-ff17d833b36d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-500713e7-ca20-4e2b-adfd-ff17d833b36d_0">
											<gml:posList>35.67174864290121 139.738684037857 32.839 35.67174726251692 139.7386824046124 32.839 35.67174726251692 139.7386824046124 35.729 35.67174864290121 139.738684037857 35.729 35.67174864290121 139.738684037857 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1770469c-efcb-4927-8609-dc1164d0366e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1770469c-efcb-4927-8609-dc1164d0366e_0">
											<gml:posList>35.67174823107306 139.7386990725586 32.839 35.67174941042055 139.73869722640976 32.839 35.67174941042055 139.73869722640976 35.729 35.67174823107306 139.7386990725586 35.729 35.67174823107306 139.7386990725586 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b5660b5-fda0-456c-9ba5-3aacc402a7bf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b5660b5-fda0-456c-9ba5-3aacc402a7bf_0">
											<gml:posList>35.671749726075824 139.73868598075313 32.839 35.67174864290121 139.738684037857 32.839 35.67174864290121 139.738684037857 35.729 35.671749726075824 139.73868598075313 35.729 35.671749726075824 139.73868598075313 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8282bd88-93a0-438d-ae0e-8b34393f9136">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8282bd88-93a0-438d-ae0e-8b34393f9136_0">
											<gml:posList>35.67174941042055 139.73869722640976 32.839 35.67175024702959 139.7386951045042 32.839 35.67175024702959 139.7386951045042 35.729 35.67174941042055 139.73869722640976 35.729 35.67174941042055 139.73869722640976 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bdf65038-1b30-46fd-9b62-03dc916cf66b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bdf65038-1b30-46fd-9b62-03dc916cf66b_0">
											<gml:posList>35.67175043987892 139.73868816710717 32.839 35.671749726075824 139.73868598075313 32.839 35.671749726075824 139.73868598075313 35.729 35.67175043987892 139.73868816710717 35.729 35.67175043987892 139.73868816710717 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2650aa34-91a2-4354-867c-819a645c2887">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2650aa34-91a2-4354-867c-819a645c2887_0">
											<gml:posList>35.67175024702959 139.7386951045042 32.839 35.671750713954516 139.7386928283847 32.839 35.671750713954516 139.7386928283847 35.729 35.67175024702959 139.7386951045042 35.729 35.67175024702959 139.7386951045042 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70b98a79-3c55-486a-ac2b-9750eebd708f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-70b98a79-3c55-486a-ac2b-9750eebd708f_0">
											<gml:posList>35.67175077520122 139.738690475419 32.839 35.67175043987892 139.73868816710717 32.839 35.67175043987892 139.73868816710717 35.729 35.67175077520122 139.738690475419 35.729 35.67175077520122 139.738690475419 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b270661a-37cf-416a-a0ec-f700f88a864b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b270661a-37cf-416a-a0ec-f700f88a864b_0">
											<gml:posList>35.671750713954516 139.7386928283847 32.839 35.67175077520122 139.738690475419 32.839 35.67175077520122 139.738690475419 35.729 35.671750713954516 139.7386928283847 35.729 35.671750713954516 139.7386928283847 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8630b7b4-9cd1-47c6-a66f-0be80349767a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8630b7b4-9cd1-47c6-a66f-0be80349767a_0">
											<gml:posList>35.67175834842527 139.73864676672616 32.839 35.67176682825554 139.7386785042095 32.839 35.67176682825554 139.7386785042095 35.48 35.67175834842527 139.73864676672616 35.48 35.67175834842527 139.73864676672616 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3803471b-9e23-4590-90d8-d6ff85a0795f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3803471b-9e23-4590-90d8-d6ff85a0795f_0">
											<gml:posList>35.67175834842527 139.73864676672616 32.839 35.67175834842527 139.73864676672616 35.48 35.671770377954275 139.73864193626648 35.48 35.671770377954275 139.73864193626648 32.839 35.67175834842527 139.73864676672616 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-445ccfca-10a3-4f12-9d70-5b4b7e4ef030">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-445ccfca-10a3-4f12-9d70-5b4b7e4ef030_0">
											<gml:posList>35.67177885779448 139.7386736848005 35.48 35.671770377954275 139.73864193626648 35.48 35.67175834842527 139.73864676672616 35.48 35.67176682825554 139.7386785042095 35.48 35.67177885779448 139.7386736848005 35.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c8080ced-a21a-4763-9fb5-619f26a65e8f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c8080ced-a21a-4763-9fb5-619f26a65e8f_0">
											<gml:posList>35.67177885779448 139.7386736848005 32.839 35.67177885779448 139.7386736848005 35.48 35.67176682825554 139.7386785042095 35.48 35.67176682825554 139.7386785042095 32.839 35.67177885779448 139.7386736848005 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-261396a1-a9eb-4d5e-8078-286d61d82750">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-261396a1-a9eb-4d5e-8078-286d61d82750_0">
											<gml:posList>35.67177885779448 139.7386736848005 32.839 35.671770377954275 139.73864193626648 32.839 35.671770377954275 139.73864193626648 35.48 35.67177885779448 139.7386736848005 35.48 35.67177885779448 139.7386736848005 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_426039c4-28a0-4b06-b97f-18087d3e2ffd_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-08db8d72-189d-46b3-bccf-0b5462dbfc98">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67169876601898 139.73856445273773 32.839 35.67173321468124 139.73855070337876 32.839 35.67175288676332 139.7386246802797 32.839 35.67171844711509 139.73863844064616 32.839 35.67169876601898 139.73856445273773 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e5b4f73-d3cc-4bf1-bde9-2381ba3e6e0f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67175835115474 139.73866170152218 32.839 35.67173951835047 139.73866919115846 32.839 35.671731553585495 139.73863908795252 32.839 35.671750377374195 139.73863159832055 32.839 35.67175835115474 139.73866170152218 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb9ed63b-bed4-4521-af82-ae7017ad8407">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fb9ed63b-bed4-4521-af82-ae7017ad8407_0">
											<gml:posList>35.67173321468124 139.73855070337876 32.839 35.67169876601898 139.73856445273773 32.839 35.67169876601898 139.73856445273773 35.329 35.67173321468124 139.73855070337876 35.329 35.67173321468124 139.73855070337876 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35e99e97-ed5d-4b12-ac45-36357ec3f890">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-35e99e97-ed5d-4b12-ac45-36357ec3f890_0">
											<gml:posList>35.67173321468124 139.73855070337876 32.839 35.67173321468124 139.73855070337876 35.329 35.67175288676332 139.7386246802797 35.329 35.67175288676332 139.7386246802797 32.839 35.67173321468124 139.73855070337876 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78cef170-3e62-42f3-b1fd-c578a42d04e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78cef170-3e62-42f3-b1fd-c578a42d04e4_0">
											<gml:posList>35.67175288676332 139.7386246802797 35.329 35.67173321468124 139.73855070337876 35.329 35.67169876601898 139.73856445273773 35.329 35.67171844711509 139.73863844064616 35.329 35.67175288676332 139.7386246802797 35.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa415600-c408-46ef-a992-cc19db73561d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aa415600-c408-46ef-a992-cc19db73561d_0">
											<gml:posList>35.67169876601898 139.73856445273773 32.839 35.67171844711509 139.73863844064616 32.839 35.67171844711509 139.73863844064616 35.329 35.67169876601898 139.73856445273773 35.329 35.67169876601898 139.73856445273773 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b69e4401-53f4-4a74-a7bf-5a041791487f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b69e4401-53f4-4a74-a7bf-5a041791487f_0">
											<gml:posList>35.67175288676332 139.7386246802797 32.839 35.67175288676332 139.7386246802797 35.329 35.67171844711509 139.73863844064616 35.329 35.67171844711509 139.73863844064616 32.839 35.67175288676332 139.7386246802797 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db1aed2f-285d-4fb9-a325-863023f84d09">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-db1aed2f-285d-4fb9-a325-863023f84d09_0">
											<gml:posList>35.671750377374195 139.73863159832055 32.839 35.671731553585495 139.73863908795252 32.839 35.671731553585495 139.73863908795252 35.48 35.671750377374195 139.73863159832055 35.48 35.671750377374195 139.73863159832055 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fd5ffb0f-a92d-41fe-92fc-35f8bcea1042">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fd5ffb0f-a92d-41fe-92fc-35f8bcea1042_0">
											<gml:posList>35.671750377374195 139.73863159832055 32.839 35.671750377374195 139.73863159832055 35.48 35.67175835115474 139.73866170152218 35.48 35.67175835115474 139.73866170152218 32.839 35.671750377374195 139.73863159832055 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9cfc3874-1c66-45d4-a8fc-fd2b4f92d3dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9cfc3874-1c66-45d4-a8fc-fd2b4f92d3dd_0">
											<gml:posList>35.67175835115474 139.73866170152218 35.48 35.671750377374195 139.73863159832055 35.48 35.671731553585495 139.73863908795252 35.48 35.67173951835047 139.73866919115846 35.48 35.67175835115474 139.73866170152218 35.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fbd5326c-d05e-40b0-8764-a6920b200d46">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fbd5326c-d05e-40b0-8764-a6920b200d46_0">
											<gml:posList>35.671731553585495 139.73863908795252 32.839 35.67173951835047 139.73866919115846 32.839 35.67173951835047 139.73866919115846 35.48 35.671731553585495 139.73863908795252 35.48 35.671731553585495 139.73863908795252 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-49d0a866-f21e-4742-ab3b-8b0582b0fa40">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-49d0a866-f21e-4742-ab3b-8b0582b0fa40_0">
											<gml:posList>35.67173951835047 139.73866919115846 32.839 35.67175835115474 139.73866170152218 32.839 35.67175835115474 139.73866170152218 35.48 35.67173951835047 139.73866919115846 35.48 35.67173951835047 139.73866919115846 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-1cabc221-c9c3-4616-8f9e-a2ceb2968343">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1cabc221-c9c3-4616-8f9e-a2ceb2968343">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1cabc221-c9c3-4616-8f9e-a2ceb2968343">
											<gml:posList>35.67179838108533 139.73862726664 10.38 35.671819187509165 139.73861928861268 10.38 35.671834241729265 139.7386782478759 10.38 35.67172916429688 139.73871852576139 10.38 35.67168725652173 139.73855431466473 10.38 35.6717353302579 139.73853588759366 10.38 35.67174335920535 139.73856733838142 10.38 35.67176051616424 139.73856075651074 10.38 35.671765398630235 139.73857988319077 10.38 35.6717664347723 139.73856787447477 10.38 35.67178107196471 139.738555021196 10.38 35.67179971457241 139.7385578380962 10.38 35.671809689069164 139.73857604191133 10.38 35.67180762432722 139.73859819249574 10.38 35.67179398686242 139.73861003936247 10.38 35.67179838108533 139.73862726664 10.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6e374445-010a-4852-bfc5-ae31a263eddd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e374445-010a-4852-bfc5-ae31a263eddd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e374445-010a-4852-bfc5-ae31a263eddd">
											<gml:posList>35.67172916429688 139.73871852576139 33.091 35.67173040591611 139.73871563012747 33.091 35.671689619325015 139.7385558473266 33.091 35.67168725652173 139.73855431466473 33.091 35.67172916429688 139.73871852576139 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9f0c27c8-a12c-4b75-a292-c0a73b02b6c5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f0c27c8-a12c-4b75-a292-c0a73b02b6c5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f0c27c8-a12c-4b75-a292-c0a73b02b6c5">
											<gml:posList>35.67168725652173 139.73855431466473 33.091 35.671689619325015 139.7385558473266 33.091 35.671734097665436 139.7385387942663 33.091 35.6717353302579 139.73853588759366 33.091 35.67168725652173 139.73855431466473 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-117e28a4-76b2-49d1-80a3-588453b3af17">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-117e28a4-76b2-49d1-80a3-588453b3af17">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-117e28a4-76b2-49d1-80a3-588453b3af17">
											<gml:posList>35.67175159592945 139.73859938543822 33.091 35.6717353302579 139.73853588759366 33.091 35.671734097665436 139.7385387942663 33.091 35.671750336207374 139.73860218167803 33.091 35.67175159592945 139.73859938543822 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-650783dd-cc04-4529-9909-f61c5ed46c61">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-650783dd-cc04-4529-9909-f61c5ed46c61">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-650783dd-cc04-4529-9909-f61c5ed46c61">
											<gml:posList>35.671766771067155 139.73861724066361 32.839 35.67178790219293 139.73860952736808 32.839 35.67177046919936 139.73859750733357 32.839 35.6717840836276 139.73856784256728 32.839 35.67180304077726 139.73858092125576 32.839 35.67179023619028 139.73860881763747 32.839 35.67179349803595 139.73860738879105 32.839 35.67180567648589 139.73859707910538 32.839 35.67180772453893 139.73857662969536 32.839 35.6717986256251 139.73856001553506 32.839 35.671781560609745 139.7385574397914 32.839 35.671768220506046 139.73856916479875 32.839 35.67176727371872 139.73858017922885 32.839 35.67176532224349 139.7385973587651 32.839 35.671750336207374 139.73860218167803 32.839 35.671734097665436 139.7385387942663 32.839 35.671689619325015 139.7385558473266 32.839 35.67173040591611 139.73871563012747 32.839 35.671784967601816 139.73869471003286 32.839 35.67177137443768 139.73863679848986 32.839 35.671766771067155 139.73861724066361 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1836c656-f100-4b69-9498-3f0862022069">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1836c656-f100-4b69-9498-3f0862022069">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1836c656-f100-4b69-9498-3f0862022069">
											<gml:posList>35.67175159592945 139.73859938543822 19.166 35.67176362620399 139.73859550496562 19.166 35.671765398630235 139.73857988319077 19.166 35.67176051616424 139.73856075651074 19.166 35.67174335920535 139.73856733838142 19.166 35.67175159592945 139.73859938543822 19.166</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-59476991-3c36-4712-9304-58eefe4aa6e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-59476991-3c36-4712-9304-58eefe4aa6e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-59476991-3c36-4712-9304-58eefe4aa6e7">
											<gml:posList>35.67175159592945 139.73859938543822 33.091 35.671750336207374 139.73860218167803 33.091 35.67176532224349 139.7385973587651 33.091 35.67176362620399 139.73859550496562 33.091 35.67175159592945 139.73859938543822 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7fa5c959-dd9f-4c09-84f7-7f2783f63152">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7fa5c959-dd9f-4c09-84f7-7f2783f63152">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7fa5c959-dd9f-4c09-84f7-7f2783f63152">
											<gml:posList>35.67176362620399 139.73859550496562 33.091 35.67176532224349 139.7385973587651 33.091 35.67176727371872 139.73858017922885 33.091 35.671765398630235 139.73857988319077 33.091 35.67176362620399 139.73859550496562 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-52b47d94-d0cb-4d9f-8b13-ae70235f1b3d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-52b47d94-d0cb-4d9f-8b13-ae70235f1b3d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-52b47d94-d0cb-4d9f-8b13-ae70235f1b3d">
											<gml:posList>35.671765398630235 139.73857988319077 33.091 35.67176727371872 139.73858017922885 33.091 35.671768220506046 139.73856916479875 33.091 35.6717664347723 139.73856787447477 33.091 35.671765398630235 139.73857988319077 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3a9206fe-65b5-462f-84b0-aa635401bcaf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a9206fe-65b5-462f-84b0-aa635401bcaf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a9206fe-65b5-462f-84b0-aa635401bcaf">
											<gml:posList>35.67176910686322 139.73861881754658 33.091 35.671766771067155 139.73861724066361 33.091 35.67177137443768 139.73863679848986 33.091 35.67177317667784 139.738636155667 33.091 35.67176910686322 139.73861881754658 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2c01af23-43b1-4431-b73c-fca4dfeaed66">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c01af23-43b1-4431-b73c-fca4dfeaed66">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c01af23-43b1-4431-b73c-fca4dfeaed66">
											<gml:posList>35.6717664347723 139.73856787447477 33.091 35.671768220506046 139.73856916479875 33.091 35.671781560609745 139.7385574397914 33.091 35.67178107196471 139.738555021196 33.091 35.6717664347723 139.73856787447477 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-758d627c-202f-4b7f-985e-8a371e71edbd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-758d627c-202f-4b7f-985e-8a371e71edbd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-758d627c-202f-4b7f-985e-8a371e71edbd">
											<gml:posList>35.67177046919936 139.73859750733357 38.098 35.67177324467772 139.73859655405917 38.098 35.67178486149384 139.73857125500174 38.098 35.6717840836276 139.73856784256728 38.098 35.67177046919936 139.73859750733357 38.098</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1fb3ad4a-05f0-4698-aecf-9e504005ab6b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1fb3ad4a-05f0-4698-aecf-9e504005ab6b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1fb3ad4a-05f0-4698-aecf-9e504005ab6b">
											<gml:posList>35.67178942633717 139.7386105749804 38.098 35.67178863946702 139.73860717360245 38.098 35.67177324467772 139.73859655405917 38.098 35.67177046919936 139.73859750733357 38.098 35.67178942633717 139.7386105749804 38.098</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c2604db5-4729-4ecc-9d5c-4af3c80c20a4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c2604db5-4729-4ecc-9d5c-4af3c80c20a4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c2604db5-4729-4ecc-9d5c-4af3c80c20a4">
											<gml:posList>35.67179398686242 139.73861003936247 27.111 35.67176910686322 139.73861881754658 33.091 35.67177317667784 139.738636155667 33.091 35.67179398686242 139.73861003936247 27.111</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7f727c2c-805e-4e2b-930d-6a8a879c1214">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f727c2c-805e-4e2b-930d-6a8a879c1214">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f727c2c-805e-4e2b-930d-6a8a879c1214">
											<gml:posList>35.67177317667784 139.738636155667 33.091 35.67179838108533 139.73862726664 27.111 35.67179398686242 139.73861003936247 27.111 35.67177317667784 139.738636155667 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-87680592-33bd-47a6-bed1-f326fc741916">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-87680592-33bd-47a6-bed1-f326fc741916">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-87680592-33bd-47a6-bed1-f326fc741916">
											<gml:posList>35.671800256294006 139.73858188558813 37.843 35.67178486149384 139.73857125500174 37.843 35.67177324467772 139.73859655405917 37.843 35.67178863946702 139.73860717360245 37.843 35.671800256294006 139.73858188558813 37.843</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-87f887d2-6861-4a3b-bdd7-8b73b4ad7eb3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-87f887d2-6861-4a3b-bdd7-8b73b4ad7eb3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-87f887d2-6861-4a3b-bdd7-8b73b4ad7eb3">
											<gml:posList>35.67179398686242 139.73861003936247 33.091 35.67180762432722 139.73859819249574 33.091 35.67180567648589 139.73859707910538 33.091 35.67179349803595 139.73860738879105 33.091 35.67179023619028 139.73860881763747 33.091 35.67178942633717 139.7386105749804 33.091 35.67178790219293 139.73860952736808 33.091 35.671766771067155 139.73861724066361 33.091 35.67176910686322 139.73861881754658 33.091 35.67179398686242 139.73861003936247 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-96b81c78-1f82-4753-859b-cc2b78ee5559">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96b81c78-1f82-4753-859b-cc2b78ee5559">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96b81c78-1f82-4753-859b-cc2b78ee5559">
											<gml:posList>35.67178107196471 139.738555021196 33.091 35.671781560609745 139.7385574397914 33.091 35.6717986256251 139.73856001553506 33.091 35.67179971457241 139.7385578380962 33.091 35.67178107196471 139.738555021196 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c6bfeadf-152d-49c5-8a01-ebfda721e898">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6bfeadf-152d-49c5-8a01-ebfda721e898">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6bfeadf-152d-49c5-8a01-ebfda721e898">
											<gml:posList>35.6717840836276 139.73856784256728 38.098 35.67178486149384 139.73857125500174 38.098 35.671800256294006 139.73858188558813 38.098 35.67180304077726 139.73858092125576 38.098 35.6717840836276 139.73856784256728 38.098</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-60ed949d-f229-460f-a18d-bfb23f066bc9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-60ed949d-f229-460f-a18d-bfb23f066bc9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-60ed949d-f229-460f-a18d-bfb23f066bc9">
											<gml:posList>35.67180304077726 139.73858092125576 38.098 35.671800256294006 139.73858188558813 38.098 35.67178863946702 139.73860717360245 38.098 35.67178942633717 139.7386105749804 38.098 35.67180304077726 139.73858092125576 38.098</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e652d9e2-8c9c-4b52-97ae-0c85c67c51f1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e652d9e2-8c9c-4b52-97ae-0c85c67c51f1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e652d9e2-8c9c-4b52-97ae-0c85c67c51f1">
											<gml:posList>35.671834241729265 139.7386782478759 27.111 35.671819187509165 139.73861928861268 27.111 35.67177317667784 139.738636155667 33.091 35.671834241729265 139.7386782478759 27.111</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-60a12ac9-de20-40a8-9335-b620bb90e949">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-60a12ac9-de20-40a8-9335-b620bb90e949">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-60a12ac9-de20-40a8-9335-b620bb90e949">
											<gml:posList>35.671809689069164 139.73857604191133 33.091 35.67179971457241 139.7385578380962 33.091 35.6717986256251 139.73856001553506 33.091 35.67180772453893 139.73857662969536 33.091 35.671809689069164 139.73857604191133 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bee44e9a-29e0-40c2-8e16-d205c9e69b01">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bee44e9a-29e0-40c2-8e16-d205c9e69b01">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bee44e9a-29e0-40c2-8e16-d205c9e69b01">
											<gml:posList>35.671809689069164 139.73857604191133 33.091 35.67180772453893 139.73857662969536 33.091 35.67180567648589 139.73859707910538 33.091 35.67180762432722 139.73859819249574 33.091 35.671809689069164 139.73857604191133 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a11cf555-c7ef-484d-846a-fd6650e7582d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a11cf555-c7ef-484d-846a-fd6650e7582d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a11cf555-c7ef-484d-846a-fd6650e7582d">
											<gml:posList>35.67178729434841 139.73869624274332 33.091 35.671784967601816 139.73869471003286 33.091 35.67173040591611 139.73871563012747 33.091 35.67172916429688 139.73871852576139 33.091 35.67178729434841 139.73869624274332 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c05729f6-334a-406d-9541-58a1bea59240">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c05729f6-334a-406d-9541-58a1bea59240">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c05729f6-334a-406d-9541-58a1bea59240">
											<gml:posList>35.67177317667784 139.738636155667 33.091 35.67177137443768 139.73863679848986 33.091 35.671784967601816 139.73869471003286 33.091 35.67178729434841 139.73869624274332 33.091 35.67177317667784 139.738636155667 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-22554fdd-b65b-42f3-96cb-2beb7a95b892">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22554fdd-b65b-42f3-96cb-2beb7a95b892">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22554fdd-b65b-42f3-96cb-2beb7a95b892">
											<gml:posList>35.67177317667784 139.738636155667 33.091 35.67178729434841 139.73869624274332 33.091 35.671834241729265 139.7386782478759 27.111 35.67177317667784 139.738636155667 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3d99930b-8b15-4f6e-bb28-9bafc7cc6a6f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d99930b-8b15-4f6e-bb28-9bafc7cc6a6f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d99930b-8b15-4f6e-bb28-9bafc7cc6a6f">
											<gml:posList>35.67179349803595 139.73860738879105 33.091 35.67179349803595 139.73860738879105 32.839 35.67179023619028 139.73860881763747 32.839 35.67179023619028 139.73860881763747 33.091 35.67179349803595 139.73860738879105 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2826777a-44ef-4069-8298-63f88bdbcde9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2826777a-44ef-4069-8298-63f88bdbcde9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2826777a-44ef-4069-8298-63f88bdbcde9">
											<gml:posList>35.67168725652173 139.73855431466473 10.38 35.67172916429688 139.73871852576139 10.38 35.67172916429688 139.73871852576139 33.091 35.67168725652173 139.73855431466473 33.091 35.67168725652173 139.73855431466473 10.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a9d92500-6686-4c5b-96c6-d8e8ae8a8141">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9d92500-6686-4c5b-96c6-d8e8ae8a8141">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9d92500-6686-4c5b-96c6-d8e8ae8a8141">
											<gml:posList>35.67173040591611 139.73871563012747 33.091 35.67173040591611 139.73871563012747 32.839 35.671689619325015 139.7385558473266 32.839 35.671689619325015 139.7385558473266 33.091 35.67173040591611 139.73871563012747 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f60a08e6-0b97-4fcb-84af-7cfc840f8af6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f60a08e6-0b97-4fcb-84af-7cfc840f8af6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f60a08e6-0b97-4fcb-84af-7cfc840f8af6">
											<gml:posList>35.6717353302579 139.73853588759366 10.38 35.67168725652173 139.73855431466473 10.38 35.67168725652173 139.73855431466473 33.091 35.6717353302579 139.73853588759366 33.091 35.6717353302579 139.73853588759366 10.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b57cda0c-24e8-4b82-9a81-2aa475f88cd0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b57cda0c-24e8-4b82-9a81-2aa475f88cd0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b57cda0c-24e8-4b82-9a81-2aa475f88cd0">
											<gml:posList>35.671689619325015 139.7385558473266 33.091 35.671689619325015 139.7385558473266 32.839 35.671734097665436 139.7385387942663 32.839 35.671734097665436 139.7385387942663 33.091 35.671689619325015 139.7385558473266 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e69dbddb-847e-487d-ace9-90305a6c3e39">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e69dbddb-847e-487d-ace9-90305a6c3e39">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e69dbddb-847e-487d-ace9-90305a6c3e39">
											<gml:posList>35.671734097665436 139.7385387942663 33.091 35.671734097665436 139.7385387942663 32.839 35.671750336207374 139.73860218167803 32.839 35.671750336207374 139.73860218167803 33.091 35.671734097665436 139.7385387942663 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-045f23d2-a2b4-4e6a-825f-a4b13872093b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-045f23d2-a2b4-4e6a-825f-a4b13872093b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-045f23d2-a2b4-4e6a-825f-a4b13872093b">
											<gml:posList>35.67174335920535 139.73856733838142 19.166 35.67174335920535 139.73856733838142 10.38 35.6717353302579 139.73853588759366 10.38 35.6717353302579 139.73853588759366 33.091 35.67175159592945 139.73859938543822 33.091 35.67175159592945 139.73859938543822 19.166 35.67174335920535 139.73856733838142 19.166</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b61c99c7-6797-4542-9882-f66bbe714b22">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b61c99c7-6797-4542-9882-f66bbe714b22">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b61c99c7-6797-4542-9882-f66bbe714b22">
											<gml:posList>35.67176051616424 139.73856075651074 10.38 35.67174335920535 139.73856733838142 10.38 35.67174335920535 139.73856733838142 19.166 35.67176051616424 139.73856075651074 19.166 35.67176051616424 139.73856075651074 10.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9aef46cd-fef3-45c6-bf81-c7e70238558d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9aef46cd-fef3-45c6-bf81-c7e70238558d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9aef46cd-fef3-45c6-bf81-c7e70238558d">
											<gml:posList>35.671784967601816 139.73869471003286 33.091 35.671784967601816 139.73869471003286 32.839 35.67173040591611 139.73871563012747 32.839 35.67173040591611 139.73871563012747 33.091 35.671784967601816 139.73869471003286 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-39bc5a9e-ce6b-455e-8634-ee3d92535af1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-39bc5a9e-ce6b-455e-8634-ee3d92535af1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-39bc5a9e-ce6b-455e-8634-ee3d92535af1">
											<gml:posList>35.67175159592945 139.73859938543822 19.166 35.67175159592945 139.73859938543822 33.091 35.67176362620399 139.73859550496562 33.091 35.67176362620399 139.73859550496562 19.166 35.67175159592945 139.73859938543822 19.166</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-04770c67-87d0-4d6e-b048-eba48eee5aff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04770c67-87d0-4d6e-b048-eba48eee5aff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04770c67-87d0-4d6e-b048-eba48eee5aff">
											<gml:posList>35.671750336207374 139.73860218167803 33.091 35.671750336207374 139.73860218167803 32.839 35.67176532224349 139.7385973587651 32.839 35.67176532224349 139.7385973587651 33.091 35.671750336207374 139.73860218167803 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-21cd5a6e-a79e-4594-be43-92c588989d7b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21cd5a6e-a79e-4594-be43-92c588989d7b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21cd5a6e-a79e-4594-be43-92c588989d7b">
											<gml:posList>35.671765398630235 139.73857988319077 10.38 35.67176051616424 139.73856075651074 10.38 35.67176051616424 139.73856075651074 19.166 35.671765398630235 139.73857988319077 19.166 35.671765398630235 139.73857988319077 10.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-36433d58-aae2-4cbe-940f-890660bb91ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36433d58-aae2-4cbe-940f-890660bb91ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36433d58-aae2-4cbe-940f-890660bb91ae">
											<gml:posList>35.67176362620399 139.73859550496562 19.166 35.67176362620399 139.73859550496562 33.091 35.671765398630235 139.73857988319077 33.091 35.671765398630235 139.73857988319077 19.166 35.67176362620399 139.73859550496562 19.166</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4163a9f3-3579-433a-9ae4-dca734f0abb6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4163a9f3-3579-433a-9ae4-dca734f0abb6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4163a9f3-3579-433a-9ae4-dca734f0abb6">
											<gml:posList>35.6717664347723 139.73856787447477 10.38 35.671765398630235 139.73857988319077 10.38 35.671765398630235 139.73857988319077 19.166 35.671765398630235 139.73857988319077 33.091 35.6717664347723 139.73856787447477 33.091 35.6717664347723 139.73856787447477 10.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-71b6154c-1214-4ce1-b74e-435f5bcfcbbb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-71b6154c-1214-4ce1-b74e-435f5bcfcbbb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-71b6154c-1214-4ce1-b74e-435f5bcfcbbb">
											<gml:posList>35.67176532224349 139.7385973587651 33.091 35.67176532224349 139.7385973587651 32.839 35.67176727371872 139.73858017922885 32.839 35.67176727371872 139.73858017922885 33.091 35.67176532224349 139.7385973587651 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8a6c3f2b-75b2-4c72-b57b-5e708a75c9e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a6c3f2b-75b2-4c72-b57b-5e708a75c9e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a6c3f2b-75b2-4c72-b57b-5e708a75c9e3">
											<gml:posList>35.67176727371872 139.73858017922885 33.091 35.67176727371872 139.73858017922885 32.839 35.671768220506046 139.73856916479875 32.839 35.671768220506046 139.73856916479875 33.091 35.67176727371872 139.73858017922885 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6778415b-e646-4798-85a5-c2a242432816">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6778415b-e646-4798-85a5-c2a242432816">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6778415b-e646-4798-85a5-c2a242432816">
											<gml:posList>35.671766771067155 139.73861724066361 33.091 35.671766771067155 139.73861724066361 32.839 35.67177137443768 139.73863679848986 32.839 35.67177137443768 139.73863679848986 33.091 35.671766771067155 139.73861724066361 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-85f39ffe-4980-4994-8f21-d45e20e78729">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85f39ffe-4980-4994-8f21-d45e20e78729">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85f39ffe-4980-4994-8f21-d45e20e78729">
											<gml:posList>35.67178107196471 139.738555021196 10.38 35.6717664347723 139.73856787447477 10.38 35.6717664347723 139.73856787447477 33.091 35.67178107196471 139.738555021196 33.091 35.67178107196471 139.738555021196 10.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cb224a04-b060-4a1a-9f47-2a360ab06283">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb224a04-b060-4a1a-9f47-2a360ab06283">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb224a04-b060-4a1a-9f47-2a360ab06283">
											<gml:posList>35.671768220506046 139.73856916479875 33.091 35.671768220506046 139.73856916479875 32.839 35.671781560609745 139.7385574397914 32.839 35.671781560609745 139.7385574397914 33.091 35.671768220506046 139.73856916479875 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-12650a02-020b-4085-8bb4-f64cf503d804">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-12650a02-020b-4085-8bb4-f64cf503d804">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-12650a02-020b-4085-8bb4-f64cf503d804">
											<gml:posList>35.67177046919936 139.73859750733357 38.098 35.6717840836276 139.73856784256728 38.098 35.6717840836276 139.73856784256728 32.839 35.67177046919936 139.73859750733357 32.839 35.67177046919936 139.73859750733357 38.098</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5b287239-cfd1-48db-b5c8-4547879ec589">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b287239-cfd1-48db-b5c8-4547879ec589">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b287239-cfd1-48db-b5c8-4547879ec589">
											<gml:posList>35.67178790219293 139.73860952736808 33.091 35.67178790219293 139.73860952736808 32.839 35.671766771067155 139.73861724066361 32.839 35.671766771067155 139.73861724066361 33.091 35.67178790219293 139.73860952736808 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-67b66a42-d218-457d-878b-09631aca9df2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67b66a42-d218-457d-878b-09631aca9df2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67b66a42-d218-457d-878b-09631aca9df2">
											<gml:posList>35.67177137443768 139.73863679848986 33.091 35.67177137443768 139.73863679848986 32.839 35.671784967601816 139.73869471003286 32.839 35.671784967601816 139.73869471003286 33.091 35.67177137443768 139.73863679848986 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0aff4a63-6cfd-48e2-bffc-5e363c3b6d8b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0aff4a63-6cfd-48e2-bffc-5e363c3b6d8b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0aff4a63-6cfd-48e2-bffc-5e363c3b6d8b">
											<gml:posList>35.67177324467772 139.73859655405917 38.098 35.67177324467772 139.73859655405917 37.843 35.67178486149384 139.73857125500174 37.843 35.67178486149384 139.73857125500174 38.098 35.67177324467772 139.73859655405917 38.098</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-31527fbc-401a-4b75-b308-2b9f33e80aa0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31527fbc-401a-4b75-b308-2b9f33e80aa0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31527fbc-401a-4b75-b308-2b9f33e80aa0">
											<gml:posList>35.67178942633717 139.7386105749804 38.098 35.67177046919936 139.73859750733357 38.098 35.67177046919936 139.73859750733357 32.839 35.67178790219293 139.73860952736808 32.839 35.67178790219293 139.73860952736808 33.091 35.67178942633717 139.7386105749804 33.091 35.67178942633717 139.7386105749804 38.098</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ef6fbe1c-9fa2-437e-9d8c-90e04a16e7b5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef6fbe1c-9fa2-437e-9d8c-90e04a16e7b5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef6fbe1c-9fa2-437e-9d8c-90e04a16e7b5">
											<gml:posList>35.67178863946702 139.73860717360245 38.098 35.67178863946702 139.73860717360245 37.843 35.67177324467772 139.73859655405917 37.843 35.67177324467772 139.73859655405917 38.098 35.67178863946702 139.73860717360245 38.098</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d9a467c6-ded7-4cf4-9674-0c3baaad04ad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d9a467c6-ded7-4cf4-9674-0c3baaad04ad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d9a467c6-ded7-4cf4-9674-0c3baaad04ad">
											<gml:posList>35.67179398686242 139.73861003936247 27.111 35.67179398686242 139.73861003936247 33.091 35.67176910686322 139.73861881754658 33.091 35.67179398686242 139.73861003936247 27.111</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-077cc5cd-b9a2-4af8-9331-320e5341c395">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-077cc5cd-b9a2-4af8-9331-320e5341c395">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-077cc5cd-b9a2-4af8-9331-320e5341c395">
											<gml:posList>35.67178729434841 139.73869624274332 33.091 35.67172916429688 139.73871852576139 33.091 35.67172916429688 139.73871852576139 10.38 35.671834241729265 139.7386782478759 10.38 35.671834241729265 139.7386782478759 27.111 35.67178729434841 139.73869624274332 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-48376a36-d291-4f60-91b4-66a85dafaa3e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-48376a36-d291-4f60-91b4-66a85dafaa3e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-48376a36-d291-4f60-91b4-66a85dafaa3e">
											<gml:posList>35.671781560609745 139.7385574397914 33.091 35.671781560609745 139.7385574397914 32.839 35.6717986256251 139.73856001553506 32.839 35.6717986256251 139.73856001553506 33.091 35.671781560609745 139.7385574397914 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f13d521f-061e-4982-9a52-5421d0474970">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f13d521f-061e-4982-9a52-5421d0474970">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f13d521f-061e-4982-9a52-5421d0474970">
											<gml:posList>35.67179971457241 139.7385578380962 10.38 35.67178107196471 139.738555021196 10.38 35.67178107196471 139.738555021196 33.091 35.67179971457241 139.7385578380962 33.091 35.67179971457241 139.7385578380962 10.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c47ecb1b-42f1-4435-b779-aa69afa30fa5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c47ecb1b-42f1-4435-b779-aa69afa30fa5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c47ecb1b-42f1-4435-b779-aa69afa30fa5">
											<gml:posList>35.67178486149384 139.73857125500174 38.098 35.67178486149384 139.73857125500174 37.843 35.671800256294006 139.73858188558813 37.843 35.671800256294006 139.73858188558813 38.098 35.67178486149384 139.73857125500174 38.098</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cb298bc9-5fec-42bc-8a0f-72b95e7f0d5a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb298bc9-5fec-42bc-8a0f-72b95e7f0d5a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb298bc9-5fec-42bc-8a0f-72b95e7f0d5a">
											<gml:posList>35.6717840836276 139.73856784256728 38.098 35.67180304077726 139.73858092125576 38.098 35.67180304077726 139.73858092125576 32.839 35.6717840836276 139.73856784256728 32.839 35.6717840836276 139.73856784256728 38.098</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d231e7e0-f39c-4ab4-987b-1a0189fc6804">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d231e7e0-f39c-4ab4-987b-1a0189fc6804">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d231e7e0-f39c-4ab4-987b-1a0189fc6804">
											<gml:posList>35.671800256294006 139.73858188558813 38.098 35.671800256294006 139.73858188558813 37.843 35.67178863946702 139.73860717360245 37.843 35.67178863946702 139.73860717360245 38.098 35.671800256294006 139.73858188558813 38.098</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c1958466-c824-4a80-aa0e-27fba2f1cc3f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c1958466-c824-4a80-aa0e-27fba2f1cc3f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c1958466-c824-4a80-aa0e-27fba2f1cc3f">
											<gml:posList>35.67177317667784 139.738636155667 33.091 35.671819187509165 139.73861928861268 27.111 35.67179838108533 139.73862726664 27.111 35.67177317667784 139.738636155667 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5825351f-fe4a-49a6-92a9-06cae9f89acc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5825351f-fe4a-49a6-92a9-06cae9f89acc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5825351f-fe4a-49a6-92a9-06cae9f89acc">
											<gml:posList>35.67179838108533 139.73862726664 10.38 35.67179398686242 139.73861003936247 10.38 35.67179398686242 139.73861003936247 27.111 35.67179838108533 139.73862726664 27.111 35.67179838108533 139.73862726664 10.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eaa0286b-5dd5-4696-85a3-2308bc6d6d95">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eaa0286b-5dd5-4696-85a3-2308bc6d6d95">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eaa0286b-5dd5-4696-85a3-2308bc6d6d95">
											<gml:posList>35.67178942633717 139.7386105749804 38.098 35.67178942633717 139.7386105749804 33.091 35.67179023619028 139.73860881763747 33.091 35.67179023619028 139.73860881763747 32.839 35.67180304077726 139.73858092125576 32.839 35.67180304077726 139.73858092125576 38.098 35.67178942633717 139.7386105749804 38.098</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-587520e1-7e44-4102-a89c-566c4ea80b27">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-587520e1-7e44-4102-a89c-566c4ea80b27">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-587520e1-7e44-4102-a89c-566c4ea80b27">
											<gml:posList>35.67180567648589 139.73859707910538 33.091 35.67180567648589 139.73859707910538 32.839 35.67179349803595 139.73860738879105 32.839 35.67179349803595 139.73860738879105 33.091 35.67180567648589 139.73859707910538 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-96428671-9146-4780-97bd-6c7519fc037f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96428671-9146-4780-97bd-6c7519fc037f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96428671-9146-4780-97bd-6c7519fc037f">
											<gml:posList>35.67180762432722 139.73859819249574 33.091 35.67179398686242 139.73861003936247 33.091 35.67179398686242 139.73861003936247 27.111 35.67179398686242 139.73861003936247 10.38 35.67180762432722 139.73859819249574 10.38 35.67180762432722 139.73859819249574 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-674e4aca-2742-46b6-8e14-aba12ab89dc3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-674e4aca-2742-46b6-8e14-aba12ab89dc3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-674e4aca-2742-46b6-8e14-aba12ab89dc3">
											<gml:posList>35.6717986256251 139.73856001553506 33.091 35.6717986256251 139.73856001553506 32.839 35.67180772453893 139.73857662969536 32.839 35.67180772453893 139.73857662969536 33.091 35.6717986256251 139.73856001553506 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e3fc15e3-3806-4c74-9c9a-0771d73d5184">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e3fc15e3-3806-4c74-9c9a-0771d73d5184">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e3fc15e3-3806-4c74-9c9a-0771d73d5184">
											<gml:posList>35.671809689069164 139.73857604191133 10.38 35.67179971457241 139.7385578380962 10.38 35.67179971457241 139.7385578380962 33.091 35.671809689069164 139.73857604191133 33.091 35.671809689069164 139.73857604191133 10.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-61bb9ce8-9500-4427-a943-f14c1fc2b04e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61bb9ce8-9500-4427-a943-f14c1fc2b04e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61bb9ce8-9500-4427-a943-f14c1fc2b04e">
											<gml:posList>35.67180772453893 139.73857662969536 33.091 35.67180772453893 139.73857662969536 32.839 35.67180567648589 139.73859707910538 32.839 35.67180567648589 139.73859707910538 33.091 35.67180772453893 139.73857662969536 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9319c962-d446-40f3-b8e8-bb77fc12961b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9319c962-d446-40f3-b8e8-bb77fc12961b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9319c962-d446-40f3-b8e8-bb77fc12961b">
											<gml:posList>35.67180762432722 139.73859819249574 10.38 35.671809689069164 139.73857604191133 10.38 35.671809689069164 139.73857604191133 33.091 35.67180762432722 139.73859819249574 33.091 35.67180762432722 139.73859819249574 10.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4905a238-0c68-46b8-a64e-34b95a3375b5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4905a238-0c68-46b8-a64e-34b95a3375b5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4905a238-0c68-46b8-a64e-34b95a3375b5">
											<gml:posList>35.671819187509165 139.73861928861268 10.38 35.67179838108533 139.73862726664 10.38 35.67179838108533 139.73862726664 27.111 35.671819187509165 139.73861928861268 27.111 35.671819187509165 139.73861928861268 10.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6ed6e43b-44ae-453d-8d2a-b603fc89aa0d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ed6e43b-44ae-453d-8d2a-b603fc89aa0d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ed6e43b-44ae-453d-8d2a-b603fc89aa0d">
											<gml:posList>35.671834241729265 139.7386782478759 10.38 35.671819187509165 139.73861928861268 10.38 35.671819187509165 139.73861928861268 27.111 35.671834241729265 139.7386782478759 27.111 35.671834241729265 139.7386782478759 10.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1453</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">180.21805</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1241</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>