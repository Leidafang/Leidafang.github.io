<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_437343af-cb36-4ae5-9884-1562111ce185">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018002</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門二丁目10地区</gen:value>
			</gen:stringAttribute>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">422</bldg:usage>
			<bldg:measuredHeight uom="m">10.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.667121035561074 139.74345725880596 0 35.66712746012524 139.74344219616384 0 35.66716180985608 139.74346418301505 0 35.667191035290784 139.7433956330369 0 35.66715475568554 139.7433724112408 0 35.66718331519997 139.74330539735186 0 35.6668990570533 139.74312343902918 0 35.6668348567909 139.74327406511614 0 35.667121035561074 139.74345725880596 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667121035561074 139.74345725880596 29.07 35.6668348567909 139.74327406511614 29.07 35.6668990570533 139.74312343902918 29.07 35.66718331519997 139.74330539735186 29.07 35.66715475568554 139.7433724112408 29.07 35.667191035290784 139.7433956330369 29.07 35.66716180985608 139.74346418301505 29.07 35.66712746012524 139.74344219616384 29.07 35.667121035561074 139.74345725880596 29.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667121035561074 139.74345725880596 29.07 35.66712746012524 139.74344219616384 29.07 35.66712746012524 139.74344219616384 39.85 35.667121035561074 139.74345725880596 39.85 35.667121035561074 139.74345725880596 29.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66712746012524 139.74344219616384 29.07 35.66716180985608 139.74346418301505 29.07 35.66716180985608 139.74346418301505 39.85 35.66712746012524 139.74344219616384 39.85 35.66712746012524 139.74344219616384 29.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66716180985608 139.74346418301505 29.07 35.667191035290784 139.7433956330369 29.07 35.667191035290784 139.7433956330369 39.85 35.66716180985608 139.74346418301505 39.85 35.66716180985608 139.74346418301505 29.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667191035290784 139.7433956330369 29.07 35.66715475568554 139.7433724112408 29.07 35.66715475568554 139.7433724112408 39.85 35.667191035290784 139.7433956330369 39.85 35.667191035290784 139.7433956330369 29.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66715475568554 139.7433724112408 29.07 35.66718331519997 139.74330539735186 29.07 35.66718331519997 139.74330539735186 39.85 35.66715475568554 139.7433724112408 39.85 35.66715475568554 139.7433724112408 29.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66718331519997 139.74330539735186 29.07 35.6668990570533 139.74312343902918 29.07 35.6668990570533 139.74312343902918 39.85 35.66718331519997 139.74330539735186 39.85 35.66718331519997 139.74330539735186 29.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6668990570533 139.74312343902918 29.07 35.6668348567909 139.74327406511614 29.07 35.6668348567909 139.74327406511614 39.85 35.6668990570533 139.74312343902918 39.85 35.6668990570533 139.74312343902918 29.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6668348567909 139.74327406511614 29.07 35.667121035561074 139.74345725880596 29.07 35.667121035561074 139.74345725880596 39.85 35.6668348567909 139.74327406511614 39.85 35.6668348567909 139.74327406511614 29.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667121035561074 139.74345725880596 39.85 35.66712746012524 139.74344219616384 39.85 35.66716180985608 139.74346418301505 39.85 35.667191035290784 139.7433956330369 39.85 35.66715475568554 139.7433724112408 39.85 35.66718331519997 139.74330539735186 39.85 35.6668990570533 139.74312343902918 39.85 35.6668348567909 139.74327406511614 39.85 35.667121035561074 139.74345725880596 39.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-35d8acbf-4cc1-44f5-ba19-79642655be0b"/>
							<gml:surfaceMember xlink:href="#poly-75648efc-041c-4754-bf72-c10489817808"/>
							<gml:surfaceMember xlink:href="#poly-22e8d5e0-0d5a-4492-856c-e0b954017020"/>
							<gml:surfaceMember xlink:href="#poly-0761a179-fd44-4af0-b5e8-79598a109e23"/>
							<gml:surfaceMember xlink:href="#poly-f92a896b-6d2c-49aa-82f9-94bfb82135ae"/>
							<gml:surfaceMember xlink:href="#poly-1ba6666a-1ba0-47a7-bd9a-ac4dea01defc"/>
							<gml:surfaceMember xlink:href="#poly-e09db75c-8fd2-4f46-8e1a-f26921bddbb7"/>
							<gml:surfaceMember xlink:href="#poly-5de3c2b1-e2f2-4c8b-b719-c27af873bece"/>
							<gml:surfaceMember xlink:href="#poly-5701c8fa-0cd8-473e-92a6-81c095d0e9c8"/>
							<gml:surfaceMember xlink:href="#poly-a2bb5512-eab9-4ea9-9fbe-26d911927eba"/>
							<gml:surfaceMember xlink:href="#poly-319c09cb-7aa4-40c2-956c-353a692463ac"/>
							<gml:surfaceMember xlink:href="#poly-0d286ac6-284e-491f-89a1-e04bbe77f0a1"/>
							<gml:surfaceMember xlink:href="#poly-b10749f9-6e74-43fe-943f-ebc3dc885497"/>
							<gml:surfaceMember xlink:href="#poly-32883d71-0a52-4ef8-b03d-30c657b9980e"/>
							<gml:surfaceMember xlink:href="#poly-9ace6e93-b5cc-4a16-9da6-beedb86fbfa3"/>
							<gml:surfaceMember xlink:href="#poly-109b7025-c57d-4a87-a509-15a3dcd6ac8c"/>
							<gml:surfaceMember xlink:href="#poly-20955b61-bf34-4c44-995a-5f5e3cb83e9e"/>
							<gml:surfaceMember xlink:href="#poly-7964979a-91a6-45a0-a652-a99f843b8956"/>
							<gml:surfaceMember xlink:href="#poly-31ca07c2-0567-4305-b0d3-b4cdde792320"/>
							<gml:surfaceMember xlink:href="#poly-fe78e876-7a00-4be1-b2a1-66f4eafb4169"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-35d8acbf-4cc1-44f5-ba19-79642655be0b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-35d8acbf-4cc1-44f5-ba19-79642655be0b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-35d8acbf-4cc1-44f5-ba19-79642655be0b">
											<gml:posList>35.667154755685516 139.7433724112408 29.07 35.667191035290784 139.74339563303687 29.07 35.667161809856104 139.74346418301505 29.07 35.66712746012522 139.7434421961638 29.07 35.66712103556104 139.74345725880593 29.07 35.666834856790864 139.74327406511614 29.07 35.66689905705328 139.74312343902918 29.07 35.66718331519996 139.74330539735186 29.07 35.667154755685516 139.7433724112408 29.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-75648efc-041c-4754-bf72-c10489817808">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-75648efc-041c-4754-bf72-c10489817808">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-75648efc-041c-4754-bf72-c10489817808">
											<gml:posList>35.66689905705328 139.74312343902918 38.9 35.666834856790864 139.74327406511614 38.9 35.666926163553796 139.74323472794478 44.538 35.66689905705328 139.74312343902918 38.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-22e8d5e0-0d5a-4492-856c-e0b954017020">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22e8d5e0-0d5a-4492-856c-e0b954017020">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22e8d5e0-0d5a-4492-856c-e0b954017020">
											<gml:posList>35.66709005191057 139.7433440298336 44.538 35.666926163553796 139.74323472794478 44.538 35.666834856790864 139.74327406511614 38.9 35.66709005191057 139.7433440298336 44.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0761a179-fd44-4af0-b5e8-79598a109e23">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0761a179-fd44-4af0-b5e8-79598a109e23">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0761a179-fd44-4af0-b5e8-79598a109e23">
											<gml:posList>35.666834856790864 139.74327406511614 38.9 35.66712103556104 139.74345725880593 38.9 35.66709005191057 139.7433440298336 44.538 35.666834856790864 139.74327406511614 38.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f92a896b-6d2c-49aa-82f9-94bfb82135ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f92a896b-6d2c-49aa-82f9-94bfb82135ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f92a896b-6d2c-49aa-82f9-94bfb82135ae">
											<gml:posList>35.66689905705328 139.74312343902918 38.9 35.666926163553796 139.74323472794478 44.538 35.66709005191057 139.7433440298336 44.538 35.66689905705328 139.74312343902918 38.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1ba6666a-1ba0-47a7-bd9a-ac4dea01defc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ba6666a-1ba0-47a7-bd9a-ac4dea01defc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ba6666a-1ba0-47a7-bd9a-ac4dea01defc">
											<gml:posList>35.66709005191057 139.7433440298336 44.538 35.66718331519996 139.74330539735186 38.9 35.66689905705328 139.74312343902918 38.9 35.66709005191057 139.7433440298336 44.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e09db75c-8fd2-4f46-8e1a-f26921bddbb7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e09db75c-8fd2-4f46-8e1a-f26921bddbb7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e09db75c-8fd2-4f46-8e1a-f26921bddbb7">
											<gml:posList>35.66709005191057 139.7433440298336 44.538 35.66712103556104 139.74345725880593 38.9 35.66712746012522 139.7434421961638 38.9 35.66709005191057 139.7433440298336 44.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5de3c2b1-e2f2-4c8b-b719-c27af873bece">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5de3c2b1-e2f2-4c8b-b719-c27af873bece">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5de3c2b1-e2f2-4c8b-b719-c27af873bece">
											<gml:posList>35.667154755685516 139.7433724112408 38.9 35.66709005191057 139.7433440298336 44.538 35.66712746012522 139.7434421961638 38.9 35.667154755685516 139.7433724112408 38.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5701c8fa-0cd8-473e-92a6-81c095d0e9c8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5701c8fa-0cd8-473e-92a6-81c095d0e9c8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5701c8fa-0cd8-473e-92a6-81c095d0e9c8">
											<gml:posList>35.667154755685516 139.7433724112408 38.9 35.66718331519996 139.74330539735186 38.9 35.66709005191057 139.7433440298336 44.538 35.667154755685516 139.7433724112408 38.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a2bb5512-eab9-4ea9-9fbe-26d911927eba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2bb5512-eab9-4ea9-9fbe-26d911927eba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2bb5512-eab9-4ea9-9fbe-26d911927eba">
											<gml:posList>35.66712746012522 139.7434421961638 32.6 35.667161809856104 139.74346418301505 32.6 35.66717642257422 139.7434299025093 34.807 35.667141107906325 139.74340729818533 34.807 35.66712746012522 139.7434421961638 32.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-319c09cb-7aa4-40c2-956c-353a692463ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-319c09cb-7aa4-40c2-956c-353a692463ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-319c09cb-7aa4-40c2-956c-353a692463ac">
											<gml:posList>35.667191035290784 139.74339563303687 32.6 35.667154755685516 139.7433724112408 32.6 35.667141107906325 139.74340729818533 34.807 35.66717642257422 139.7434299025093 34.807 35.667191035290784 139.74339563303687 32.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0d286ac6-284e-491f-89a1-e04bbe77f0a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d286ac6-284e-491f-89a1-e04bbe77f0a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d286ac6-284e-491f-89a1-e04bbe77f0a1">
											<gml:posList>35.66689905705328 139.74312343902918 29.07 35.666834856790864 139.74327406511614 29.07 35.666834856790864 139.74327406511614 38.9 35.66689905705328 139.74312343902918 38.9 35.66689905705328 139.74312343902918 29.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b10749f9-6e74-43fe-943f-ebc3dc885497">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b10749f9-6e74-43fe-943f-ebc3dc885497">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b10749f9-6e74-43fe-943f-ebc3dc885497">
											<gml:posList>35.666834856790864 139.74327406511614 29.07 35.66712103556104 139.74345725880593 29.07 35.66712103556104 139.74345725880593 38.9 35.666834856790864 139.74327406511614 38.9 35.666834856790864 139.74327406511614 29.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-32883d71-0a52-4ef8-b03d-30c657b9980e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-32883d71-0a52-4ef8-b03d-30c657b9980e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-32883d71-0a52-4ef8-b03d-30c657b9980e">
											<gml:posList>35.66718331519996 139.74330539735186 29.07 35.66689905705328 139.74312343902918 29.07 35.66689905705328 139.74312343902918 38.9 35.66718331519996 139.74330539735186 38.9 35.66718331519996 139.74330539735186 29.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9ace6e93-b5cc-4a16-9da6-beedb86fbfa3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ace6e93-b5cc-4a16-9da6-beedb86fbfa3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ace6e93-b5cc-4a16-9da6-beedb86fbfa3">
											<gml:posList>35.66712103556104 139.74345725880593 29.07 35.66712746012522 139.7434421961638 29.07 35.66712746012522 139.7434421961638 32.6 35.66712746012522 139.7434421961638 38.9 35.66712103556104 139.74345725880593 38.9 35.66712103556104 139.74345725880593 29.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-109b7025-c57d-4a87-a509-15a3dcd6ac8c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-109b7025-c57d-4a87-a509-15a3dcd6ac8c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-109b7025-c57d-4a87-a509-15a3dcd6ac8c">
											<gml:posList>35.667154755685516 139.7433724112408 38.9 35.66712746012522 139.7434421961638 38.9 35.66712746012522 139.7434421961638 32.6 35.667141107906325 139.74340729818533 34.807 35.667154755685516 139.7433724112408 32.6 35.667154755685516 139.7433724112408 38.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-20955b61-bf34-4c44-995a-5f5e3cb83e9e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20955b61-bf34-4c44-995a-5f5e3cb83e9e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20955b61-bf34-4c44-995a-5f5e3cb83e9e">
											<gml:posList>35.66712746012522 139.7434421961638 29.07 35.667161809856104 139.74346418301505 29.07 35.667161809856104 139.74346418301505 32.6 35.66712746012522 139.7434421961638 32.6 35.66712746012522 139.7434421961638 29.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7964979a-91a6-45a0-a652-a99f843b8956">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7964979a-91a6-45a0-a652-a99f843b8956">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7964979a-91a6-45a0-a652-a99f843b8956">
											<gml:posList>35.66718331519996 139.74330539735186 29.07 35.66718331519996 139.74330539735186 38.9 35.667154755685516 139.7433724112408 38.9 35.667154755685516 139.7433724112408 32.6 35.667154755685516 139.7433724112408 29.07 35.66718331519996 139.74330539735186 29.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-31ca07c2-0567-4305-b0d3-b4cdde792320">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31ca07c2-0567-4305-b0d3-b4cdde792320">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31ca07c2-0567-4305-b0d3-b4cdde792320">
											<gml:posList>35.667191035290784 139.74339563303687 29.07 35.667154755685516 139.7433724112408 29.07 35.667154755685516 139.7433724112408 32.6 35.667191035290784 139.74339563303687 32.6 35.667191035290784 139.74339563303687 29.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fe78e876-7a00-4be1-b2a1-66f4eafb4169">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe78e876-7a00-4be1-b2a1-66f4eafb4169">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe78e876-7a00-4be1-b2a1-66f4eafb4169">
											<gml:posList>35.667161809856104 139.74346418301505 29.07 35.667191035290784 139.74339563303687 29.07 35.667191035290784 139.74339563303687 32.6 35.66717642257422 139.7434299025093 34.807 35.667161809856104 139.74346418301505 32.6 35.667161809856104 139.74346418301505 29.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2443</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">545.48821</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1122</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>