<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_4471c98c-2cad-40a4-99fd-18cabca699c1">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="地区計画">
				<gen:value>赤坂二・六丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:measuredHeight uom="m">4.4</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67203919201581 139.73782863041083 0 35.67199849179766 139.7378472811704 0 35.6719963861434 139.73784040172004 0 35.67197446370892 139.73785044698792 0 35.6719768495412 139.7378582761002 0 35.67195746805453 139.7378671584551 0 35.67197368984827 139.73792033898047 0 35.67205570301854 139.73788276063638 0 35.67203919201581 139.73782863041083 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67203919201581 139.73782863041083 10.015 35.67205570301854 139.73788276063638 10.015 35.67197368984827 139.73792033898047 10.015 35.67195746805453 139.7378671584551 10.015 35.6719768495412 139.7378582761002 10.015 35.67197446370892 139.73785044698792 10.015 35.6719963861434 139.73784040172004 10.015 35.67199849179766 139.7378472811704 10.015 35.67203919201581 139.73782863041083 10.015</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67203919201581 139.73782863041083 10.015 35.67199849179766 139.7378472811704 10.015 35.67199849179766 139.7378472811704 14.46 35.67203919201581 139.73782863041083 14.46 35.67203919201581 139.73782863041083 10.015</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67199849179766 139.7378472811704 10.015 35.6719963861434 139.73784040172004 10.015 35.6719963861434 139.73784040172004 14.46 35.67199849179766 139.7378472811704 14.46 35.67199849179766 139.7378472811704 10.015</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6719963861434 139.73784040172004 10.015 35.67197446370892 139.73785044698792 10.015 35.67197446370892 139.73785044698792 14.46 35.6719963861434 139.73784040172004 14.46 35.6719963861434 139.73784040172004 10.015</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67197446370892 139.73785044698792 10.015 35.6719768495412 139.7378582761002 10.015 35.6719768495412 139.7378582761002 14.46 35.67197446370892 139.73785044698792 14.46 35.67197446370892 139.73785044698792 10.015</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6719768495412 139.7378582761002 10.015 35.67195746805453 139.7378671584551 10.015 35.67195746805453 139.7378671584551 14.46 35.6719768495412 139.7378582761002 14.46 35.6719768495412 139.7378582761002 10.015</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67195746805453 139.7378671584551 10.015 35.67197368984827 139.73792033898047 10.015 35.67197368984827 139.73792033898047 14.46 35.67195746805453 139.7378671584551 14.46 35.67195746805453 139.7378671584551 10.015</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67197368984827 139.73792033898047 10.015 35.67205570301854 139.73788276063638 10.015 35.67205570301854 139.73788276063638 14.46 35.67197368984827 139.73792033898047 14.46 35.67197368984827 139.73792033898047 10.015</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67205570301854 139.73788276063638 10.015 35.67203919201581 139.73782863041083 10.015 35.67203919201581 139.73782863041083 14.46 35.67205570301854 139.73788276063638 14.46 35.67205570301854 139.73788276063638 10.015</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67203919201581 139.73782863041083 14.46 35.67199849179766 139.7378472811704 14.46 35.6719963861434 139.73784040172004 14.46 35.67197446370892 139.73785044698792 14.46 35.6719768495412 139.7378582761002 14.46 35.67195746805453 139.7378671584551 14.46 35.67197368984827 139.73792033898047 14.46 35.67205570301854 139.73788276063638 14.46 35.67203919201581 139.73782863041083 14.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-e517e026-1601-4f13-a19c-e1a5d7c22b50"/>
							<gml:surfaceMember xlink:href="#poly-c9702ee8-2f72-48b6-bd05-d3a7eec07f96"/>
							<gml:surfaceMember xlink:href="#poly-7d9f4992-dfca-4373-9045-5e6c7a7a64ee"/>
							<gml:surfaceMember xlink:href="#poly-8771b398-02ff-49d5-aa26-ecd0958e3bb1"/>
							<gml:surfaceMember xlink:href="#poly-c8f5167a-3f6e-446e-977a-df90a5de9ef0"/>
							<gml:surfaceMember xlink:href="#poly-c624925a-65f7-4549-af9a-9442d28fb5cb"/>
							<gml:surfaceMember xlink:href="#poly-a28f573b-0540-442e-824d-e734e152ca6d"/>
							<gml:surfaceMember xlink:href="#poly-fe801c90-e080-46e9-9e62-47c452b2fb14"/>
							<gml:surfaceMember xlink:href="#poly-204af4bf-d2ba-4c05-bf91-48a0bf1d7fa7"/>
							<gml:surfaceMember xlink:href="#poly-33d99e63-ab3d-4954-ba1b-0f19c7c8d6d7"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-e517e026-1601-4f13-a19c-e1a5d7c22b50">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e517e026-1601-4f13-a19c-e1a5d7c22b50">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e517e026-1601-4f13-a19c-e1a5d7c22b50">
											<gml:posList>35.67199849179764 139.73784728117036 10.015 35.672039192015816 139.73782863041083 10.015 35.67205570301853 139.7378827606364 10.015 35.67197368984827 139.73792033898047 10.015 35.67195746805452 139.7378671584551 10.015 35.67197684954119 139.73785827610018 10.015 35.67197446370893 139.73785044698792 10.015 35.671996386143384 139.73784040172004 10.015 35.67199849179764 139.73784728117036 10.015</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c9702ee8-2f72-48b6-bd05-d3a7eec07f96">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c9702ee8-2f72-48b6-bd05-d3a7eec07f96">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c9702ee8-2f72-48b6-bd05-d3a7eec07f96">
											<gml:posList>35.67197368984827 139.73792033898047 14.5 35.67205570301853 139.7378827606364 14.5 35.672039192015816 139.73782863041083 14.5 35.67199849179764 139.73784728117036 14.5 35.671996386143384 139.73784040172004 14.5 35.67197446370893 139.73785044698792 14.5 35.67197684954119 139.73785827610018 14.5 35.67195746805452 139.7378671584551 14.5 35.67197368984827 139.73792033898047 14.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7d9f4992-dfca-4373-9045-5e6c7a7a64ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d9f4992-dfca-4373-9045-5e6c7a7a64ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d9f4992-dfca-4373-9045-5e6c7a7a64ee">
											<gml:posList>35.672039192015816 139.73782863041083 14.5 35.672039192015816 139.73782863041083 10.015 35.67199849179764 139.73784728117036 10.015 35.67199849179764 139.73784728117036 14.5 35.672039192015816 139.73782863041083 14.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8771b398-02ff-49d5-aa26-ecd0958e3bb1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8771b398-02ff-49d5-aa26-ecd0958e3bb1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8771b398-02ff-49d5-aa26-ecd0958e3bb1">
											<gml:posList>35.67199849179764 139.73784728117036 14.5 35.67199849179764 139.73784728117036 10.015 35.671996386143384 139.73784040172004 10.015 35.671996386143384 139.73784040172004 14.5 35.67199849179764 139.73784728117036 14.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c8f5167a-3f6e-446e-977a-df90a5de9ef0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8f5167a-3f6e-446e-977a-df90a5de9ef0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8f5167a-3f6e-446e-977a-df90a5de9ef0">
											<gml:posList>35.671996386143384 139.73784040172004 14.5 35.671996386143384 139.73784040172004 10.015 35.67197446370893 139.73785044698792 10.015 35.67197446370893 139.73785044698792 14.5 35.671996386143384 139.73784040172004 14.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c624925a-65f7-4549-af9a-9442d28fb5cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c624925a-65f7-4549-af9a-9442d28fb5cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c624925a-65f7-4549-af9a-9442d28fb5cb">
											<gml:posList>35.67197446370893 139.73785044698792 14.5 35.67197446370893 139.73785044698792 10.015 35.67197684954119 139.73785827610018 10.015 35.67197684954119 139.73785827610018 14.5 35.67197446370893 139.73785044698792 14.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a28f573b-0540-442e-824d-e734e152ca6d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a28f573b-0540-442e-824d-e734e152ca6d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a28f573b-0540-442e-824d-e734e152ca6d">
											<gml:posList>35.67205570301853 139.7378827606364 14.5 35.67205570301853 139.7378827606364 10.015 35.672039192015816 139.73782863041083 10.015 35.672039192015816 139.73782863041083 14.5 35.67205570301853 139.7378827606364 14.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fe801c90-e080-46e9-9e62-47c452b2fb14">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe801c90-e080-46e9-9e62-47c452b2fb14">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe801c90-e080-46e9-9e62-47c452b2fb14">
											<gml:posList>35.67197684954119 139.73785827610018 14.5 35.67197684954119 139.73785827610018 10.015 35.67195746805452 139.7378671584551 10.015 35.67195746805452 139.7378671584551 14.5 35.67197684954119 139.73785827610018 14.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-204af4bf-d2ba-4c05-bf91-48a0bf1d7fa7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-204af4bf-d2ba-4c05-bf91-48a0bf1d7fa7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-204af4bf-d2ba-4c05-bf91-48a0bf1d7fa7">
											<gml:posList>35.67195746805452 139.7378671584551 14.5 35.67195746805452 139.7378671584551 10.015 35.67197368984827 139.73792033898047 10.015 35.67197368984827 139.73792033898047 14.5 35.67195746805452 139.7378671584551 14.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-33d99e63-ab3d-4954-ba1b-0f19c7c8d6d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-33d99e63-ab3d-4954-ba1b-0f19c7c8d6d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-33d99e63-ab3d-4954-ba1b-0f19c7c8d6d7">
											<gml:posList>35.67197368984827 139.73792033898047 14.5 35.67197368984827 139.73792033898047 10.015 35.67205570301853 139.7378827606364 10.015 35.67205570301853 139.7378827606364 14.5 35.67197368984827 139.73792033898047 14.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6366</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>