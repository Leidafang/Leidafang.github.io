<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_44d8a84b-313b-4e3b-aaa2-b4e67d9e2454">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">27.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.670386619021826 139.74157820842362 0 35.670371520900964 139.74163721272157 0 35.67044214359293 139.74169656087523 0 35.67047291308564 139.74162107966788 0 35.67047361533499 139.74159633521435 0 35.67044269658242 139.74159416133722 0 35.67044709218248 139.74144823509735 0 35.67038588613808 139.7414445495123 0 35.670386619021826 139.74157820842362 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670386619021826 139.74157820842362 8.617 35.67038588613808 139.7414445495123 8.617 35.67044709218248 139.74144823509735 8.617 35.67044269658242 139.74159416133722 8.617 35.67047361533499 139.74159633521435 8.617 35.67047291308564 139.74162107966788 8.617 35.67044214359293 139.74169656087523 8.617 35.670371520900964 139.74163721272157 8.617 35.670386619021826 139.74157820842362 8.617</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670386619021826 139.74157820842362 8.617 35.670371520900964 139.74163721272157 8.617 35.670371520900964 139.74163721272157 36.12 35.670386619021826 139.74157820842362 36.12 35.670386619021826 139.74157820842362 8.617</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670371520900964 139.74163721272157 8.617 35.67044214359293 139.74169656087523 8.617 35.67044214359293 139.74169656087523 36.12 35.670371520900964 139.74163721272157 36.12 35.670371520900964 139.74163721272157 8.617</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67044214359293 139.74169656087523 8.617 35.67047291308564 139.74162107966788 8.617 35.67047291308564 139.74162107966788 36.12 35.67044214359293 139.74169656087523 36.12 35.67044214359293 139.74169656087523 8.617</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67047291308564 139.74162107966788 8.617 35.67047361533499 139.74159633521435 8.617 35.67047361533499 139.74159633521435 36.12 35.67047291308564 139.74162107966788 36.12 35.67047291308564 139.74162107966788 8.617</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67047361533499 139.74159633521435 8.617 35.67044269658242 139.74159416133722 8.617 35.67044269658242 139.74159416133722 36.12 35.67047361533499 139.74159633521435 36.12 35.67047361533499 139.74159633521435 8.617</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67044269658242 139.74159416133722 8.617 35.67044709218248 139.74144823509735 8.617 35.67044709218248 139.74144823509735 36.12 35.67044269658242 139.74159416133722 36.12 35.67044269658242 139.74159416133722 8.617</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67044709218248 139.74144823509735 8.617 35.67038588613808 139.7414445495123 8.617 35.67038588613808 139.7414445495123 36.12 35.67044709218248 139.74144823509735 36.12 35.67044709218248 139.74144823509735 8.617</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67038588613808 139.7414445495123 8.617 35.670386619021826 139.74157820842362 8.617 35.670386619021826 139.74157820842362 36.12 35.67038588613808 139.7414445495123 36.12 35.67038588613808 139.7414445495123 8.617</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670386619021826 139.74157820842362 36.12 35.670371520900964 139.74163721272157 36.12 35.67044214359293 139.74169656087523 36.12 35.67047291308564 139.74162107966788 36.12 35.67047361533499 139.74159633521435 36.12 35.67044269658242 139.74159416133722 36.12 35.67044709218248 139.74144823509735 36.12 35.67038588613808 139.7414445495123 36.12 35.670386619021826 139.74157820842362 36.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-3f9f9149-9c8a-4828-86d4-e25f15fef9f4"/>
							<gml:surfaceMember xlink:href="#poly-50f2fb8c-cbfe-45c2-892a-699d94688446"/>
							<gml:surfaceMember xlink:href="#poly-f9e64344-1c39-4f14-a3e7-c9c3ef38f16f"/>
							<gml:surfaceMember xlink:href="#poly-12258179-1779-49b2-90e4-cc538976ddfc"/>
							<gml:surfaceMember xlink:href="#poly-02b7529e-71a1-4b43-9246-93ecab9d2b1f"/>
							<gml:surfaceMember xlink:href="#poly-ebe76b7e-6025-4856-8d82-c1debfb0d016"/>
							<gml:surfaceMember xlink:href="#poly-d3d4ec61-113a-4e4a-892b-fb7d30b14362"/>
							<gml:surfaceMember xlink:href="#poly-6ff49f7e-b70a-4c0c-b3fb-6384b3b0fd50"/>
							<gml:surfaceMember xlink:href="#poly-f315e740-48aa-4229-92f2-1e06703e2f1f"/>
							<gml:surfaceMember xlink:href="#poly-dc6b2bf9-8831-4413-9c64-8d958a48678f"/>
							<gml:surfaceMember xlink:href="#poly-a7499ea9-5eb2-4487-83d8-cac2e9591179"/>
							<gml:surfaceMember xlink:href="#poly-ba454ce9-bc3e-4238-8a5a-df0125278b1e"/>
							<gml:surfaceMember xlink:href="#poly-5c97a89b-9577-4be6-8c9c-45e4eef9d0fe"/>
							<gml:surfaceMember xlink:href="#poly-78258f3d-b963-4290-92f2-5735c08e3f1c"/>
							<gml:surfaceMember xlink:href="#poly-18a72e77-f6ec-4263-a3ba-81f5143f4468"/>
							<gml:surfaceMember xlink:href="#poly-1b9da464-6bd5-4dcd-91bf-bf05fdb860d8"/>
							<gml:surfaceMember xlink:href="#poly-4820e854-68c4-4fc5-93f8-0933946b05bf"/>
							<gml:surfaceMember xlink:href="#poly-efa8fc3e-949c-4deb-8315-eeb5a061c4e9"/>
							<gml:surfaceMember xlink:href="#poly-489115a9-9fe9-4893-87bd-e7f2d2dcbcc6"/>
							<gml:surfaceMember xlink:href="#poly-e430ada9-d0a5-4915-906a-e0815347feaa"/>
							<gml:surfaceMember xlink:href="#poly-b69eaa0b-64b2-4f91-a38b-a2aad7d58c42"/>
							<gml:surfaceMember xlink:href="#poly-619b9681-24d1-406e-8db4-ff861a043fa3"/>
							<gml:surfaceMember xlink:href="#poly-eb7772f5-d06d-45fa-8280-f8c61a371653"/>
							<gml:surfaceMember xlink:href="#poly-323bc57a-554a-4c95-bd5c-8d6f4362fd28"/>
							<gml:surfaceMember xlink:href="#poly-0587f568-45cf-4cf7-857d-f13137827de4"/>
							<gml:surfaceMember xlink:href="#poly-e68a767c-2b5e-4e66-8bab-0201104fe6d0"/>
							<gml:surfaceMember xlink:href="#poly-ebf1c196-090b-423a-883d-cea8a4fd134f"/>
							<gml:surfaceMember xlink:href="#poly-1d0e9da7-c1a9-444b-9180-cb4f7944db3e"/>
							<gml:surfaceMember xlink:href="#poly-c087bfaa-c118-4ec1-843e-54da4106efa3"/>
							<gml:surfaceMember xlink:href="#poly-c5b282f7-6ce8-4d9a-a104-50e7a5cfef7f"/>
							<gml:surfaceMember xlink:href="#poly-e5be4404-c664-4878-860d-712ced9e56d3"/>
							<gml:surfaceMember xlink:href="#poly-561f43d6-1be5-41e4-99a3-09e0d7588353"/>
							<gml:surfaceMember xlink:href="#poly-41409d61-8d59-4fc0-a9fa-1379ed1d0fdf"/>
							<gml:surfaceMember xlink:href="#poly-848ce16b-6b14-46f7-a8cb-ebbeba48edf4"/>
							<gml:surfaceMember xlink:href="#poly-a7583acf-0b85-44fd-ae36-d6f073c62635"/>
							<gml:surfaceMember xlink:href="#poly-df737085-bd77-4b37-920d-1cd4cd0a65a7"/>
							<gml:surfaceMember xlink:href="#poly-654103bf-6804-4833-a6f6-8a339aa7bd86"/>
							<gml:surfaceMember xlink:href="#poly-5f5b3063-4b10-40d8-a1cd-d7582f95309e"/>
							<gml:surfaceMember xlink:href="#poly-2182dfe9-eab9-4168-9edc-e97002dd0593"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_44d8a84b-313b-4e3b-aaa2-b4e67d9e2454_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-65653dcd-4077-4d3c-8fa8-5bbfd75b308d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670402106130034 139.74154472052456 36.65 35.67040942567723 139.74154524236565 36.65 35.670407713599744 139.74158142083812 36.65 35.67040039405269 139.74158089899373 36.65 35.670402106130034 139.74154472052456 36.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6f9f370-10e5-44f7-aa0b-028c59558404">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67041772225132 139.7415504135658 36.65 35.67042441981792 139.74155089193445 36.65 35.67042296502095 139.74158166849537 36.65 35.670416258449166 139.7415812011807 36.65 35.67041772225132 139.7415504135658 36.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-69984cc9-90f1-44d4-b72a-950dcc6ee25e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-69984cc9-90f1-44d4-b72a-950dcc6ee25e_0">
											<gml:posList>35.67040942567723 139.74154524236565 36.65 35.670402106130034 139.74154472052456 36.65 35.670402106130034 139.74154472052456 38.326 35.67040942567723 139.74154524236565 38.326 35.67040942567723 139.74154524236565 36.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f62e43ff-99d1-4d47-8448-7e0b0fc854ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f62e43ff-99d1-4d47-8448-7e0b0fc854ea_0">
											<gml:posList>35.67042441981792 139.74155089193445 36.65 35.67041772225132 139.7415504135658 36.65 35.67041772225132 139.7415504135658 38.326 35.67042441981792 139.74155089193445 38.326 35.67042441981792 139.74155089193445 36.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa116f1b-cf2e-4afc-b930-b1ca6fad742c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fa116f1b-cf2e-4afc-b930-b1ca6fad742c_0">
											<gml:posList>35.670402106130034 139.74154472052456 36.65 35.67040039405269 139.74158089899373 36.65 35.67040039405269 139.74158089899373 38.326 35.670402106130034 139.74154472052456 38.326 35.670402106130034 139.74154472052456 36.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58408501-ed7f-4d29-aae9-df5a7a519202">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-58408501-ed7f-4d29-aae9-df5a7a519202_0">
											<gml:posList>35.670402106130034 139.74154472052456 38.326 35.67040039405269 139.74158089899373 38.326 35.670407713599744 139.74158142083812 38.326 35.67040942567723 139.74154524236565 38.326 35.670402106130034 139.74154472052456 38.326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f7e5e11-361b-4c9c-a269-738d140aa64b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1f7e5e11-361b-4c9c-a269-738d140aa64b_0">
											<gml:posList>35.67040942567723 139.74154524236565 36.65 35.67040942567723 139.74154524236565 38.326 35.670407713599744 139.74158142083812 38.326 35.670407713599744 139.74158142083812 36.65 35.67040942567723 139.74154524236565 36.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4dfb68f0-3002-4f21-8d9a-ea52bf074c86">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4dfb68f0-3002-4f21-8d9a-ea52bf074c86_0">
											<gml:posList>35.67041772225132 139.7415504135658 36.65 35.670416258449166 139.7415812011807 36.65 35.670416258449166 139.7415812011807 38.326 35.67041772225132 139.7415504135658 38.326 35.67041772225132 139.7415504135658 36.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-21dfd281-226e-4ff5-977d-443787e5fb78">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-21dfd281-226e-4ff5-977d-443787e5fb78_0">
											<gml:posList>35.67042296502095 139.74158166849537 38.326 35.67042441981792 139.74155089193445 38.326 35.67041772225132 139.7415504135658 38.326 35.670416258449166 139.7415812011807 38.326 35.67042296502095 139.74158166849537 38.326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b35a7533-6d72-4ae7-8d27-ecfbaaa06c47">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b35a7533-6d72-4ae7-8d27-ecfbaaa06c47_0">
											<gml:posList>35.67042441981792 139.74155089193445 36.65 35.67042441981792 139.74155089193445 38.326 35.67042296502095 139.74158166849537 38.326 35.67042296502095 139.74158166849537 36.65 35.67042441981792 139.74155089193445 36.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5008b440-dc6a-4cc8-b7cd-7a3ef7b1c64b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5008b440-dc6a-4cc8-b7cd-7a3ef7b1c64b_0">
											<gml:posList>35.67040039405269 139.74158089899373 36.65 35.670407713599744 139.74158142083812 36.65 35.670407713599744 139.74158142083812 38.326 35.67040039405269 139.74158089899373 38.326 35.67040039405269 139.74158089899373 36.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29deb13f-c0fa-497c-8add-1d706d769eda">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29deb13f-c0fa-497c-8add-1d706d769eda_0">
											<gml:posList>35.670416258449166 139.7415812011807 36.65 35.67042296502095 139.74158166849537 36.65 35.67042296502095 139.74158166849537 38.326 35.670416258449166 139.7415812011807 38.326 35.670416258449166 139.7415812011807 36.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_44d8a84b-313b-4e3b-aaa2-b4e67d9e2454_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-608d7139-c487-431b-ba05-c84b36fa4a80">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670449121872004 139.74166320421327 36.65 35.67043405925985 139.74166232668736 36.65 35.670434430494275 139.74165268287177 36.65 35.67043704459167 139.74165283453038 36.65 35.670456434001125 139.74165398326375 36.65 35.670451602529496 139.74166567574136 36.65 35.670449121872004 139.74166320421327 36.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-34ccb0d1-4dba-4948-a800-acde2cffb393">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67045359607591 139.74166766179067 37.077 35.670451602529496 139.74166567574136 37.077 35.670456434001125 139.74165398326375 37.077 35.67045911120297 139.74165414589655 37.077 35.67045359607591 139.74166766179067 37.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2295b7d8-0e97-406a-8f60-6d218ba9ae3b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2295b7d8-0e97-406a-8f60-6d218ba9ae3b_0">
											<gml:posList>35.670434430494275 139.74165268287177 37.177 35.67043702656422 139.741652834551 37.177 35.67043704459167 139.74165283453038 36.65 35.670434430494275 139.74165268287177 36.65 35.670434430494275 139.74165268287177 37.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c049686-cd06-41ee-ab8d-0c0fe21d0806">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c049686-cd06-41ee-ab8d-0c0fe21d0806_0">
											<gml:posList>35.670456434001125 139.74165398326375 37.077 35.670456434001125 139.74165398326375 36.65 35.67043704459167 139.74165283453038 36.65 35.67043702656422 139.741652834551 37.177 35.67045911120297 139.74165414589655 37.177 35.67045911120297 139.74165414589655 37.077 35.670456434001125 139.74165398326375 37.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fd562d24-2962-44ef-8f2c-1ee1f8a5403c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fd562d24-2962-44ef-8f2c-1ee1f8a5403c_0">
											<gml:posList>35.67043405925985 139.74166232668736 37.177 35.670434430494275 139.74165268287177 37.177 35.670434430494275 139.74165268287177 36.65 35.67043405925985 139.74166232668736 36.65 35.67043405925985 139.74166232668736 37.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-69d2bd52-d0b1-418b-a970-e4ca31df6c66">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-69d2bd52-d0b1-418b-a970-e4ca31df6c66_0">
											<gml:posList>35.670456434001125 139.74165398326375 37.077 35.670451602529496 139.74166567574136 37.077 35.670451602529496 139.74166567574136 36.65 35.670456434001125 139.74165398326375 36.65 35.670456434001125 139.74165398326375 37.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-429335e0-ffe3-4a17-a4d4-3c6fb90dd29f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-429335e0-ffe3-4a17-a4d4-3c6fb90dd29f_0">
											<gml:posList>35.67045911120297 139.74165414589655 37.177 35.67043702656422 139.741652834551 37.177 35.670434430494275 139.74165268287177 37.177 35.67043405925985 139.74166232668736 37.177 35.670449121872004 139.74166320421327 37.177 35.67045359607591 139.74166766179067 37.177 35.67045911120297 139.74165414589655 37.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a09fcb73-85a8-4f8c-aa56-3e8976de9e13">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a09fcb73-85a8-4f8c-aa56-3e8976de9e13_0">
											<gml:posList>35.67045911120297 139.74165414589655 37.077 35.67045911120297 139.74165414589655 37.177 35.67045359607591 139.74166766179067 37.177 35.67045359607591 139.74166766179067 37.077 35.67045911120297 139.74165414589655 37.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f71f5945-422c-421c-b9af-449bf01ae53e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f71f5945-422c-421c-b9af-449bf01ae53e_0">
											<gml:posList>35.670449121872004 139.74166320421327 36.65 35.670449121872004 139.74166320421327 37.177 35.67043405925985 139.74166232668736 37.177 35.67043405925985 139.74166232668736 36.65 35.670449121872004 139.74166320421327 36.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00aec0ad-2f72-4a99-bb88-4f1179908bc4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-00aec0ad-2f72-4a99-bb88-4f1179908bc4_0">
											<gml:posList>35.67045359607591 139.74166766179067 37.177 35.670449121872004 139.74166320421327 37.177 35.670449121872004 139.74166320421327 36.65 35.670451602529496 139.74166567574136 36.65 35.670451602529496 139.74166567574136 37.077 35.67045359607591 139.74166766179067 37.077 35.67045359607591 139.74166766179067 37.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-3f9f9149-9c8a-4828-86d4-e25f15fef9f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f9f9149-9c8a-4828-86d4-e25f15fef9f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f9f9149-9c8a-4828-86d4-e25f15fef9f4">
											<gml:posList>35.67047291308563 139.74162107966785 8.617 35.670442143592915 139.74169656087523 8.617 35.67037152090096 139.74163721272154 8.617 35.67038661902181 139.74157820842362 8.617 35.67038588613805 139.7414445495123 8.617 35.67044709218248 139.74144823509732 8.617 35.670442696582434 139.74159416133722 8.617 35.670473615335005 139.74159633521435 8.617 35.67047291308563 139.74162107966785 8.617</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-50f2fb8c-cbfe-45c2-892a-699d94688446">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50f2fb8c-cbfe-45c2-892a-699d94688446">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50f2fb8c-cbfe-45c2-892a-699d94688446">
											<gml:posList>35.6703863679626 139.74153264288674 37.077 35.670444437397286 139.74153655305562 37.077 35.67044709218248 139.74144823509732 25.907 35.67038588613805 139.7414445495123 25.907 35.6703863679626 139.74153264288674 37.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f9e64344-1c39-4f14-a3e7-c9c3ef38f16f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9e64344-1c39-4f14-a3e7-c9c3ef38f16f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9e64344-1c39-4f14-a3e7-c9c3ef38f16f">
											<gml:posList>35.6703863679626 139.74153264288674 37.077 35.67038932736065 139.74153643941204 37.077 35.67044141137163 139.74153994772448 37.077 35.670444437397286 139.74153655305562 37.077 35.6703863679626 139.74153264288674 37.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-12258179-1779-49b2-90e4-cc538976ddfc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-12258179-1779-49b2-90e4-cc538976ddfc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-12258179-1779-49b2-90e4-cc538976ddfc">
											<gml:posList>35.67038661902181 139.74157820842362 37.077 35.670389557916366 139.7415787573734 37.077 35.67038932736065 139.74153643941204 37.077 35.6703863679626 139.74153264288674 37.077 35.67038661902181 139.74157820842362 37.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-02b7529e-71a1-4b43-9246-93ecab9d2b1f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-02b7529e-71a1-4b43-9246-93ecab9d2b1f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-02b7529e-71a1-4b43-9246-93ecab9d2b1f">
											<gml:posList>35.670442696582434 139.74159416133722 37.077 35.670444437397286 139.74153655305562 37.077 35.67044141137163 139.74153994772448 37.077 35.670439696796834 139.74159650657836 37.077 35.670442696582434 139.74159416133722 37.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ebe76b7e-6025-4856-8d82-c1debfb0d016">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ebe76b7e-6025-4856-8d82-c1debfb0d016">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ebe76b7e-6025-4856-8d82-c1debfb0d016">
											<gml:posList>35.67043955530387 139.741600085731 37.077 35.67047345744716 139.7416020573641 37.077 35.670473615335005 139.74159633521435 37.077 35.670442696582434 139.74159416133722 37.077 35.670439696796834 139.74159650657836 37.077 35.67043955530387 139.741600085731 37.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d3d4ec61-113a-4e4a-892b-fb7d30b14362">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3d4ec61-113a-4e4a-892b-fb7d30b14362">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3d4ec61-113a-4e4a-892b-fb7d30b14362">
											<gml:posList>35.670433669073525 139.74159973898506 41.173 35.67043520298847 139.74160181392827 41.173 35.67047180035271 139.74160393712629 41.173 35.67047345744716 139.7416020573641 41.173 35.670433669073525 139.74159973898506 41.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6ff49f7e-b70a-4c0c-b3fb-6384b3b0fd50">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ff49f7e-b70a-4c0c-b3fb-6384b3b0fd50">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ff49f7e-b70a-4c0c-b3fb-6384b3b0fd50">
											<gml:posList>35.67038661902181 139.74157820842362 37.077 35.67037152090096 139.74163721272154 37.077 35.67037497204649 139.74163575066845 37.077 35.670389557916366 139.7415787573734 37.077 35.67038661902181 139.74157820842362 37.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f315e740-48aa-4229-92f2-1e06703e2f1f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f315e740-48aa-4229-92f2-1e06703e2f1f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f315e740-48aa-4229-92f2-1e06703e2f1f">
											<gml:posList>35.67047291308563 139.74162107966785 41.173 35.67047345744716 139.7416020573641 41.173 35.67047180035271 139.74160393712629 41.173 35.67047131726967 139.74162057336474 41.173 35.67047291308563 139.74162107966785 41.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dc6b2bf9-8831-4413-9c64-8d958a48678f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc6b2bf9-8831-4413-9c64-8d958a48678f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc6b2bf9-8831-4413-9c64-8d958a48678f">
											<gml:posList>35.670433669073525 139.74159973898506 36.65 35.67043955530387 139.741600085731 36.65 35.670439696796834 139.74159650657836 36.65 35.67044141137163 139.74153994772448 36.65 35.67038932736065 139.74153643941204 36.65 35.670389557916366 139.7415787573734 36.65 35.67037497204649 139.74163575066845 36.65 35.67044103087821 139.74169127098463 36.65 35.67045644299804 139.74165396116092 36.65 35.67043162710029 139.74165252038338 36.65 35.670433669073525 139.74159973898506 36.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a7499ea9-5eb2-4487-83d8-cac2e9591179">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a7499ea9-5eb2-4487-83d8-cac2e9591179">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a7499ea9-5eb2-4487-83d8-cac2e9591179">
											<gml:posList>35.67043162710029 139.74165252038338 41.173 35.67043332025041 139.74165064058192 41.173 35.67043520298847 139.74160181392827 41.173 35.670433669073525 139.74159973898506 41.173 35.67043162710029 139.74165252038338 41.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ba454ce9-bc3e-4238-8a5a-df0125278b1e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba454ce9-bc3e-4238-8a5a-df0125278b1e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba454ce9-bc3e-4238-8a5a-df0125278b1e">
											<gml:posList>35.67047131726967 139.74162057336474 40.714 35.67047180035271 139.74160393712629 40.714 35.67043520298847 139.74160181392827 40.714 35.67043332025041 139.74165064058192 40.714 35.670458460659 139.7416521030804 40.714 35.67047131726967 139.74162057336474 40.714</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5c97a89b-9577-4be6-8c9c-45e4eef9d0fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5c97a89b-9577-4be6-8c9c-45e4eef9d0fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5c97a89b-9577-4be6-8c9c-45e4eef9d0fe">
											<gml:posList>35.67047291308563 139.74162107966785 41.173 35.67047131726967 139.74162057336474 41.173 35.670458460659 139.7416521030804 41.173 35.670459435688585 139.74165413447923 41.173 35.67047291308563 139.74162107966785 41.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-78258f3d-b963-4290-92f2-5735c08e3f1c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78258f3d-b963-4290-92f2-5735c08e3f1c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78258f3d-b963-4290-92f2-5735c08e3f1c">
											<gml:posList>35.670459435688585 139.74165413447923 41.173 35.670458460659 139.7416521030804 41.173 35.67043332025041 139.74165064058192 41.173 35.67043162710029 139.74165252038338 41.173 35.670459435688585 139.74165413447923 41.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-18a72e77-f6ec-4263-a3ba-81f5143f4468">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18a72e77-f6ec-4263-a3ba-81f5143f4468">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18a72e77-f6ec-4263-a3ba-81f5143f4468">
											<gml:posList>35.67037152090096 139.74163721272154 37.077 35.670442143592915 139.74169656087523 37.077 35.67044103087821 139.74169127098463 37.077 35.67037497204649 139.74163575066845 37.077 35.67037152090096 139.74163721272154 37.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1b9da464-6bd5-4dcd-91bf-bf05fdb860d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b9da464-6bd5-4dcd-91bf-bf05fdb860d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b9da464-6bd5-4dcd-91bf-bf05fdb860d8">
											<gml:posList>35.67044103087821 139.74169127098463 37.077 35.670442143592915 139.74169656087523 37.077 35.670459435688585 139.74165413447923 37.077 35.67045644299804 139.74165396116092 37.077 35.67044103087821 139.74169127098463 37.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4820e854-68c4-4fc5-93f8-0933946b05bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4820e854-68c4-4fc5-93f8-0933946b05bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4820e854-68c4-4fc5-93f8-0933946b05bf">
											<gml:posList>35.67037152090096 139.74163721272154 8.617 35.670442143592915 139.74169656087523 8.617 35.670442143592915 139.74169656087523 37.077 35.67037152090096 139.74163721272154 37.077 35.67037152090096 139.74163721272154 8.617</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-efa8fc3e-949c-4deb-8315-eeb5a061c4e9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-efa8fc3e-949c-4deb-8315-eeb5a061c4e9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-efa8fc3e-949c-4deb-8315-eeb5a061c4e9">
											<gml:posList>35.67038661902181 139.74157820842362 8.617 35.67037152090096 139.74163721272154 8.617 35.67037152090096 139.74163721272154 37.077 35.67038661902181 139.74157820842362 37.077 35.67038661902181 139.74157820842362 8.617</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-489115a9-9fe9-4893-87bd-e7f2d2dcbcc6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-489115a9-9fe9-4893-87bd-e7f2d2dcbcc6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-489115a9-9fe9-4893-87bd-e7f2d2dcbcc6">
											<gml:posList>35.67037497204649 139.74163575066845 37.077 35.67037497204649 139.74163575066845 36.65 35.670389557916366 139.7415787573734 36.65 35.670389557916366 139.7415787573734 37.077 35.67037497204649 139.74163575066845 37.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e430ada9-d0a5-4915-906a-e0815347feaa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e430ada9-d0a5-4915-906a-e0815347feaa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e430ada9-d0a5-4915-906a-e0815347feaa">
											<gml:posList>35.67038661902181 139.74157820842362 37.077 35.6703863679626 139.74153264288674 37.077 35.67038588613805 139.7414445495123 25.907 35.67038588613805 139.7414445495123 8.617 35.67038661902181 139.74157820842362 8.617 35.67038661902181 139.74157820842362 37.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b69eaa0b-64b2-4f91-a38b-a2aad7d58c42">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b69eaa0b-64b2-4f91-a38b-a2aad7d58c42">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b69eaa0b-64b2-4f91-a38b-a2aad7d58c42">
											<gml:posList>35.670389557916366 139.7415787573734 37.077 35.670389557916366 139.7415787573734 36.65 35.67038932736065 139.74153643941204 36.65 35.67038932736065 139.74153643941204 37.077 35.670389557916366 139.7415787573734 37.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-619b9681-24d1-406e-8db4-ff861a043fa3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-619b9681-24d1-406e-8db4-ff861a043fa3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-619b9681-24d1-406e-8db4-ff861a043fa3">
											<gml:posList>35.67044103087821 139.74169127098463 37.077 35.67044103087821 139.74169127098463 36.65 35.67037497204649 139.74163575066845 36.65 35.67037497204649 139.74163575066845 37.077 35.67044103087821 139.74169127098463 37.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eb7772f5-d06d-45fa-8280-f8c61a371653">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eb7772f5-d06d-45fa-8280-f8c61a371653">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eb7772f5-d06d-45fa-8280-f8c61a371653">
											<gml:posList>35.67038932736065 139.74153643941204 37.077 35.67038932736065 139.74153643941204 36.65 35.67044141137163 139.74153994772448 36.65 35.67044141137163 139.74153994772448 37.077 35.67038932736065 139.74153643941204 37.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-323bc57a-554a-4c95-bd5c-8d6f4362fd28">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-323bc57a-554a-4c95-bd5c-8d6f4362fd28">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-323bc57a-554a-4c95-bd5c-8d6f4362fd28">
											<gml:posList>35.67044709218248 139.74144823509732 8.617 35.67038588613805 139.7414445495123 8.617 35.67038588613805 139.7414445495123 25.907 35.67044709218248 139.74144823509732 25.907 35.67044709218248 139.74144823509732 8.617</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0587f568-45cf-4cf7-857d-f13137827de4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0587f568-45cf-4cf7-857d-f13137827de4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0587f568-45cf-4cf7-857d-f13137827de4">
											<gml:posList>35.67043162710029 139.74165252038338 41.173 35.670433669073525 139.74159973898506 41.173 35.670433669073525 139.74159973898506 36.65 35.67043162710029 139.74165252038338 36.65 35.67043162710029 139.74165252038338 41.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e68a767c-2b5e-4e66-8bab-0201104fe6d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e68a767c-2b5e-4e66-8bab-0201104fe6d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e68a767c-2b5e-4e66-8bab-0201104fe6d0">
											<gml:posList>35.67043332025041 139.74165064058192 41.173 35.67043332025041 139.74165064058192 40.714 35.67043520298847 139.74160181392827 40.714 35.67043520298847 139.74160181392827 41.173 35.67043332025041 139.74165064058192 41.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ebf1c196-090b-423a-883d-cea8a4fd134f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ebf1c196-090b-423a-883d-cea8a4fd134f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ebf1c196-090b-423a-883d-cea8a4fd134f">
											<gml:posList>35.670439696796834 139.74159650657836 37.077 35.670439696796834 139.74159650657836 36.65 35.67043955530387 139.741600085731 36.65 35.67043955530387 139.741600085731 37.077 35.670439696796834 139.74159650657836 37.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1d0e9da7-c1a9-444b-9180-cb4f7944db3e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d0e9da7-c1a9-444b-9180-cb4f7944db3e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d0e9da7-c1a9-444b-9180-cb4f7944db3e">
											<gml:posList>35.67044141137163 139.74153994772448 37.077 35.67044141137163 139.74153994772448 36.65 35.670439696796834 139.74159650657836 36.65 35.670439696796834 139.74159650657836 37.077 35.67044141137163 139.74153994772448 37.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c087bfaa-c118-4ec1-843e-54da4106efa3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c087bfaa-c118-4ec1-843e-54da4106efa3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c087bfaa-c118-4ec1-843e-54da4106efa3">
											<gml:posList>35.67044709218248 139.74144823509732 25.907 35.670444437397286 139.74153655305562 37.077 35.670442696582434 139.74159416133722 37.077 35.670442696582434 139.74159416133722 8.617 35.67044709218248 139.74144823509732 8.617 35.67044709218248 139.74144823509732 25.907</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c5b282f7-6ce8-4d9a-a104-50e7a5cfef7f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c5b282f7-6ce8-4d9a-a104-50e7a5cfef7f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c5b282f7-6ce8-4d9a-a104-50e7a5cfef7f">
											<gml:posList>35.67043162710029 139.74165252038338 36.65 35.67045644299804 139.74165396116092 36.65 35.67045644299804 139.74165396116092 37.077 35.670459435688585 139.74165413447923 37.077 35.670459435688585 139.74165413447923 41.173 35.67043162710029 139.74165252038338 41.173 35.67043162710029 139.74165252038338 36.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e5be4404-c664-4878-860d-712ced9e56d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5be4404-c664-4878-860d-712ced9e56d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5be4404-c664-4878-860d-712ced9e56d3">
											<gml:posList>35.670458460659 139.7416521030804 41.173 35.670458460659 139.7416521030804 40.714 35.67043332025041 139.74165064058192 40.714 35.67043332025041 139.74165064058192 41.173 35.670458460659 139.7416521030804 41.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-561f43d6-1be5-41e4-99a3-09e0d7588353">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-561f43d6-1be5-41e4-99a3-09e0d7588353">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-561f43d6-1be5-41e4-99a3-09e0d7588353">
											<gml:posList>35.67045644299804 139.74165396116092 37.077 35.67045644299804 139.74165396116092 36.65 35.67044103087821 139.74169127098463 36.65 35.67044103087821 139.74169127098463 37.077 35.67045644299804 139.74165396116092 37.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-41409d61-8d59-4fc0-a9fa-1379ed1d0fdf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41409d61-8d59-4fc0-a9fa-1379ed1d0fdf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41409d61-8d59-4fc0-a9fa-1379ed1d0fdf">
											<gml:posList>35.67043520298847 139.74160181392827 41.173 35.67043520298847 139.74160181392827 40.714 35.67047180035271 139.74160393712629 40.714 35.67047180035271 139.74160393712629 41.173 35.67043520298847 139.74160181392827 41.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-848ce16b-6b14-46f7-a8cb-ebbeba48edf4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-848ce16b-6b14-46f7-a8cb-ebbeba48edf4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-848ce16b-6b14-46f7-a8cb-ebbeba48edf4">
											<gml:posList>35.67047345744716 139.7416020573641 41.173 35.67047345744716 139.7416020573641 37.077 35.67043955530387 139.741600085731 37.077 35.67043955530387 139.741600085731 36.65 35.670433669073525 139.74159973898506 36.65 35.670433669073525 139.74159973898506 41.173 35.67047345744716 139.7416020573641 41.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a7583acf-0b85-44fd-ae36-d6f073c62635">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a7583acf-0b85-44fd-ae36-d6f073c62635">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a7583acf-0b85-44fd-ae36-d6f073c62635">
											<gml:posList>35.67047291308563 139.74162107966785 8.617 35.67047291308563 139.74162107966785 41.173 35.670459435688585 139.74165413447923 41.173 35.670459435688585 139.74165413447923 37.077 35.670442143592915 139.74169656087523 37.077 35.670442143592915 139.74169656087523 8.617 35.67047291308563 139.74162107966785 8.617</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-df737085-bd77-4b37-920d-1cd4cd0a65a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df737085-bd77-4b37-920d-1cd4cd0a65a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df737085-bd77-4b37-920d-1cd4cd0a65a7">
											<gml:posList>35.670473615335005 139.74159633521435 8.617 35.670442696582434 139.74159416133722 8.617 35.670442696582434 139.74159416133722 37.077 35.670473615335005 139.74159633521435 37.077 35.670473615335005 139.74159633521435 8.617</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-654103bf-6804-4833-a6f6-8a339aa7bd86">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-654103bf-6804-4833-a6f6-8a339aa7bd86">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-654103bf-6804-4833-a6f6-8a339aa7bd86">
											<gml:posList>35.67047131726967 139.74162057336474 41.173 35.67047131726967 139.74162057336474 40.714 35.670458460659 139.7416521030804 40.714 35.670458460659 139.7416521030804 41.173 35.67047131726967 139.74162057336474 41.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5f5b3063-4b10-40d8-a1cd-d7582f95309e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f5b3063-4b10-40d8-a1cd-d7582f95309e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f5b3063-4b10-40d8-a1cd-d7582f95309e">
											<gml:posList>35.67047180035271 139.74160393712629 41.173 35.67047180035271 139.74160393712629 40.714 35.67047131726967 139.74162057336474 40.714 35.67047131726967 139.74162057336474 41.173 35.67047180035271 139.74160393712629 41.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2182dfe9-eab9-4168-9edc-e97002dd0593">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2182dfe9-eab9-4168-9edc-e97002dd0593">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2182dfe9-eab9-4168-9edc-e97002dd0593">
											<gml:posList>35.67047291308563 139.74162107966785 41.173 35.67047291308563 139.74162107966785 8.617 35.670473615335005 139.74159633521435 8.617 35.670473615335005 139.74159633521435 37.077 35.67047345744716 139.7416020573641 37.077 35.67047345744716 139.7416020573641 41.173 35.67047291308563 139.74162107966785 41.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1757</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">156.2812</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.05</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>