<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_44e25b3d-b786-4659-87c3-e2887004dcd4">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">6.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.674432275273254 139.7378994065479 0 35.67443923238085 139.73792027675265 0 35.67446482117909 139.73790743198327 0 35.674476747994625 139.7379436513676 0 35.674525312754746 139.73791940102134 0 35.67450642890565 139.73786242186617 0 35.674432275273254 139.7378994065479 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674432275273254 139.7378994065479 8.59 35.67450642890565 139.73786242186617 8.59 35.674525312754746 139.73791940102134 8.59 35.674476747994625 139.7379436513676 8.59 35.67446482117909 139.73790743198327 8.59 35.67443923238085 139.73792027675265 8.59 35.674432275273254 139.7378994065479 8.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674432275273254 139.7378994065479 8.59 35.67443923238085 139.73792027675265 8.59 35.67443923238085 139.73792027675265 15.34 35.674432275273254 139.7378994065479 15.34 35.674432275273254 139.7378994065479 8.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67443923238085 139.73792027675265 8.59 35.67446482117909 139.73790743198327 8.59 35.67446482117909 139.73790743198327 15.34 35.67443923238085 139.73792027675265 15.34 35.67443923238085 139.73792027675265 8.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67446482117909 139.73790743198327 8.59 35.674476747994625 139.7379436513676 8.59 35.674476747994625 139.7379436513676 15.34 35.67446482117909 139.73790743198327 15.34 35.67446482117909 139.73790743198327 8.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674476747994625 139.7379436513676 8.59 35.674525312754746 139.73791940102134 8.59 35.674525312754746 139.73791940102134 15.34 35.674476747994625 139.7379436513676 15.34 35.674476747994625 139.7379436513676 8.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674525312754746 139.73791940102134 8.59 35.67450642890565 139.73786242186617 8.59 35.67450642890565 139.73786242186617 15.34 35.674525312754746 139.73791940102134 15.34 35.674525312754746 139.73791940102134 8.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67450642890565 139.73786242186617 8.59 35.674432275273254 139.7378994065479 8.59 35.674432275273254 139.7378994065479 15.34 35.67450642890565 139.73786242186617 15.34 35.67450642890565 139.73786242186617 8.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674432275273254 139.7378994065479 15.34 35.67443923238085 139.73792027675265 15.34 35.67446482117909 139.73790743198327 15.34 35.674476747994625 139.7379436513676 15.34 35.674525312754746 139.73791940102134 15.34 35.67450642890565 139.73786242186617 15.34 35.674432275273254 139.7378994065479 15.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-f3223e87-a8ec-4b80-bb8c-54ff7f46751c"/>
							<gml:surfaceMember xlink:href="#poly-0c858617-704a-4e56-8924-aa0fb291b407"/>
							<gml:surfaceMember xlink:href="#poly-36873be7-0f98-4ac2-890a-f04b134fa178"/>
							<gml:surfaceMember xlink:href="#poly-c955fcff-3a03-4b39-9cb4-880dec4b40b1"/>
							<gml:surfaceMember xlink:href="#poly-d5ae6e84-12c4-46dd-98a7-c3c36637af10"/>
							<gml:surfaceMember xlink:href="#poly-d51d6790-9c99-4b24-8ddb-ddb3c72fc9e7"/>
							<gml:surfaceMember xlink:href="#poly-67239bf4-2146-438a-ba85-17d5d0d0815c"/>
							<gml:surfaceMember xlink:href="#poly-865b70c9-8917-4998-bb10-c864f1b1ccc7"/>
							<gml:surfaceMember xlink:href="#poly-97f21610-7d9e-4f8b-969d-9f68e6d61358"/>
							<gml:surfaceMember xlink:href="#poly-fcf363cc-d3ab-4bc2-8326-b67c5aa7a2db"/>
							<gml:surfaceMember xlink:href="#poly-4a4bfa10-4389-47e3-80a6-eccb86640ce7"/>
							<gml:surfaceMember xlink:href="#poly-494f491d-6de3-4a35-b87f-6e43b8d47f8d"/>
							<gml:surfaceMember xlink:href="#poly-4c78380b-31c2-4abb-a5f5-282c7f191f86"/>
							<gml:surfaceMember xlink:href="#poly-a44df53a-7049-444e-a643-7f48e85b5266"/>
							<gml:surfaceMember xlink:href="#poly-15ff50b9-4fa2-4e4e-9c6b-139190082622"/>
							<gml:surfaceMember xlink:href="#poly-0ea33b45-576d-4c6f-ac60-ef06bdf4feff"/>
							<gml:surfaceMember xlink:href="#poly-c1ac3258-df77-4eae-af74-c11ce799eb7b"/>
							<gml:surfaceMember xlink:href="#poly-bb5f9398-c10a-46e8-a1cc-049b855a8bc0"/>
							<gml:surfaceMember xlink:href="#poly-00a8910d-f56c-49f6-b5d4-aa6849e46e72"/>
							<gml:surfaceMember xlink:href="#poly-92a09809-8dda-419f-b9f3-815c6ea24e00"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-f3223e87-a8ec-4b80-bb8c-54ff7f46751c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f3223e87-a8ec-4b80-bb8c-54ff7f46751c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f3223e87-a8ec-4b80-bb8c-54ff7f46751c">
											<gml:posList>35.67450642890564 139.73786242186614 8.59 35.674525312754746 139.73791940102134 8.59 35.67447674799462 139.73794365136757 8.59 35.674464821179086 139.73790743198327 8.59 35.67443923238081 139.73792027675265 8.59 35.67443227527324 139.73789940654788 8.59 35.67450642890564 139.73786242186614 8.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0c858617-704a-4e56-8924-aa0fb291b407">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c858617-704a-4e56-8924-aa0fb291b407">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c858617-704a-4e56-8924-aa0fb291b407">
											<gml:posList>35.67443227527324 139.73789940654788 15.488 35.674436233923075 139.73790145654343 15.488 35.67450475620836 139.73786728446228 15.488 35.67450642890564 139.73786242186614 15.488 35.67443227527324 139.73789940654788 15.488</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-36873be7-0f98-4ac2-890a-f04b134fa178">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36873be7-0f98-4ac2-890a-f04b134fa178">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36873be7-0f98-4ac2-890a-f04b134fa178">
											<gml:posList>35.67450642890564 139.73786242186614 15.488 35.67450475620836 139.73786728446228 15.488 35.67452135410527 139.73791735102265 15.488 35.674525312754746 139.73791940102134 15.488 35.67450642890564 139.73786242186614 15.488</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c955fcff-3a03-4b39-9cb4-880dec4b40b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c955fcff-3a03-4b39-9cb4-880dec4b40b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c955fcff-3a03-4b39-9cb4-880dec4b40b1">
											<gml:posList>35.6744664938955 139.73790259148402 15.078 35.67447841169003 139.73793879983225 15.078 35.67452135410527 139.73791735102265 15.078 35.67450475620836 139.73786728446228 15.078 35.674436233923075 139.73790145654343 15.078 35.67444089608405 139.7379154362659 15.078 35.6744664938955 139.73790259148402 15.078</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d5ae6e84-12c4-46dd-98a7-c3c36637af10">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5ae6e84-12c4-46dd-98a7-c3c36637af10">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5ae6e84-12c4-46dd-98a7-c3c36637af10">
											<gml:posList>35.67443923238081 139.73792027675265 15.488 35.67444089608405 139.7379154362659 15.488 35.674436233923075 139.73790145654343 15.488 35.67443227527324 139.73789940654788 15.488 35.67443923238081 139.73792027675265 15.488</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d51d6790-9c99-4b24-8ddb-ddb3c72fc9e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d51d6790-9c99-4b24-8ddb-ddb3c72fc9e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d51d6790-9c99-4b24-8ddb-ddb3c72fc9e7">
											<gml:posList>35.674464821179086 139.73790743198327 15.488 35.6744664938955 139.73790259148402 15.488 35.67444089608405 139.7379154362659 15.488 35.67443923238081 139.73792027675265 15.488 35.674464821179086 139.73790743198327 15.488</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-67239bf4-2146-438a-ba85-17d5d0d0815c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67239bf4-2146-438a-ba85-17d5d0d0815c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67239bf4-2146-438a-ba85-17d5d0d0815c">
											<gml:posList>35.674464821179086 139.73790743198327 15.488 35.67447674799462 139.73794365136757 15.488 35.67447841169003 139.73793879983225 15.488 35.6744664938955 139.73790259148402 15.488 35.674464821179086 139.73790743198327 15.488</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-865b70c9-8917-4998-bb10-c864f1b1ccc7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-865b70c9-8917-4998-bb10-c864f1b1ccc7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-865b70c9-8917-4998-bb10-c864f1b1ccc7">
											<gml:posList>35.674525312754746 139.73791940102134 15.488 35.67452135410527 139.73791735102265 15.488 35.67447841169003 139.73793879983225 15.488 35.67447674799462 139.73794365136757 15.488 35.674525312754746 139.73791940102134 15.488</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-97f21610-7d9e-4f8b-969d-9f68e6d61358">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-97f21610-7d9e-4f8b-969d-9f68e6d61358">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-97f21610-7d9e-4f8b-969d-9f68e6d61358">
											<gml:posList>35.6744664938955 139.73790259148402 15.488 35.6744664938955 139.73790259148402 15.078 35.67444089608405 139.7379154362659 15.078 35.67444089608405 139.7379154362659 15.488 35.6744664938955 139.73790259148402 15.488</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fcf363cc-d3ab-4bc2-8326-b67c5aa7a2db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fcf363cc-d3ab-4bc2-8326-b67c5aa7a2db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fcf363cc-d3ab-4bc2-8326-b67c5aa7a2db">
											<gml:posList>35.67450642890564 139.73786242186614 8.59 35.67443227527324 139.73789940654788 8.59 35.67443227527324 139.73789940654788 15.488 35.67450642890564 139.73786242186614 15.488 35.67450642890564 139.73786242186614 8.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4a4bfa10-4389-47e3-80a6-eccb86640ce7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a4bfa10-4389-47e3-80a6-eccb86640ce7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a4bfa10-4389-47e3-80a6-eccb86640ce7">
											<gml:posList>35.674436233923075 139.73790145654343 15.488 35.674436233923075 139.73790145654343 15.078 35.67450475620836 139.73786728446228 15.078 35.67450475620836 139.73786728446228 15.488 35.674436233923075 139.73790145654343 15.488</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-494f491d-6de3-4a35-b87f-6e43b8d47f8d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-494f491d-6de3-4a35-b87f-6e43b8d47f8d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-494f491d-6de3-4a35-b87f-6e43b8d47f8d">
											<gml:posList>35.674525312754746 139.73791940102134 8.59 35.67450642890564 139.73786242186614 8.59 35.67450642890564 139.73786242186614 15.488 35.674525312754746 139.73791940102134 15.488 35.674525312754746 139.73791940102134 8.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4c78380b-31c2-4abb-a5f5-282c7f191f86">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c78380b-31c2-4abb-a5f5-282c7f191f86">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c78380b-31c2-4abb-a5f5-282c7f191f86">
											<gml:posList>35.67450475620836 139.73786728446228 15.488 35.67450475620836 139.73786728446228 15.078 35.67452135410527 139.73791735102265 15.078 35.67452135410527 139.73791735102265 15.488 35.67450475620836 139.73786728446228 15.488</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a44df53a-7049-444e-a643-7f48e85b5266">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a44df53a-7049-444e-a643-7f48e85b5266">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a44df53a-7049-444e-a643-7f48e85b5266">
											<gml:posList>35.67444089608405 139.7379154362659 15.488 35.67444089608405 139.7379154362659 15.078 35.674436233923075 139.73790145654343 15.078 35.674436233923075 139.73790145654343 15.488 35.67444089608405 139.7379154362659 15.488</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-15ff50b9-4fa2-4e4e-9c6b-139190082622">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15ff50b9-4fa2-4e4e-9c6b-139190082622">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15ff50b9-4fa2-4e4e-9c6b-139190082622">
											<gml:posList>35.67443227527324 139.73789940654788 8.59 35.67443923238081 139.73792027675265 8.59 35.67443923238081 139.73792027675265 15.488 35.67443227527324 139.73789940654788 15.488 35.67443227527324 139.73789940654788 8.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0ea33b45-576d-4c6f-ac60-ef06bdf4feff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ea33b45-576d-4c6f-ac60-ef06bdf4feff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ea33b45-576d-4c6f-ac60-ef06bdf4feff">
											<gml:posList>35.67443923238081 139.73792027675265 8.59 35.674464821179086 139.73790743198327 8.59 35.674464821179086 139.73790743198327 15.488 35.67443923238081 139.73792027675265 15.488 35.67443923238081 139.73792027675265 8.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c1ac3258-df77-4eae-af74-c11ce799eb7b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c1ac3258-df77-4eae-af74-c11ce799eb7b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c1ac3258-df77-4eae-af74-c11ce799eb7b">
											<gml:posList>35.67447841169003 139.73793879983225 15.488 35.67447841169003 139.73793879983225 15.078 35.6744664938955 139.73790259148402 15.078 35.6744664938955 139.73790259148402 15.488 35.67447841169003 139.73793879983225 15.488</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bb5f9398-c10a-46e8-a1cc-049b855a8bc0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb5f9398-c10a-46e8-a1cc-049b855a8bc0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb5f9398-c10a-46e8-a1cc-049b855a8bc0">
											<gml:posList>35.674464821179086 139.73790743198327 8.59 35.67447674799462 139.73794365136757 8.59 35.67447674799462 139.73794365136757 15.488 35.674464821179086 139.73790743198327 15.488 35.674464821179086 139.73790743198327 8.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-00a8910d-f56c-49f6-b5d4-aa6849e46e72">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-00a8910d-f56c-49f6-b5d4-aa6849e46e72">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-00a8910d-f56c-49f6-b5d4-aa6849e46e72">
											<gml:posList>35.67452135410527 139.73791735102265 15.488 35.67452135410527 139.73791735102265 15.078 35.67447841169003 139.73793879983225 15.078 35.67447841169003 139.73793879983225 15.488 35.67452135410527 139.73791735102265 15.488</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-92a09809-8dda-419f-b9f3-815c6ea24e00">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-92a09809-8dda-419f-b9f3-815c6ea24e00">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-92a09809-8dda-419f-b9f3-815c6ea24e00">
											<gml:posList>35.67447674799462 139.73794365136757 8.59 35.674525312754746 139.73791940102134 8.59 35.674525312754746 139.73791940102134 15.488 35.67447674799462 139.73794365136757 15.488 35.67447674799462 139.73794365136757 8.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2523</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">38.6208</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1003</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.17</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">21</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>