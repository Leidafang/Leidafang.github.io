<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_450fff25-f959-4d46-8353-d7b2e56da451">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">25.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67294672298737 139.7378991865847 0 35.6729233150938 139.73782056258926 0 35.67281645234142 139.73787106237538 0 35.672842203331555 139.73794913116328 0 35.67294672298737 139.7378991865847 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67294672298737 139.7378991865847 8.54 35.672842203331555 139.73794913116328 8.54 35.67281645234142 139.73787106237538 8.54 35.6729233150938 139.73782056258926 8.54 35.67294672298737 139.7378991865847 8.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67294672298737 139.7378991865847 8.54 35.6729233150938 139.73782056258926 8.54 35.6729233150938 139.73782056258926 34.02 35.67294672298737 139.7378991865847 34.02 35.67294672298737 139.7378991865847 8.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6729233150938 139.73782056258926 8.54 35.67281645234142 139.73787106237538 8.54 35.67281645234142 139.73787106237538 34.02 35.6729233150938 139.73782056258926 34.02 35.6729233150938 139.73782056258926 8.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67281645234142 139.73787106237538 8.54 35.672842203331555 139.73794913116328 8.54 35.672842203331555 139.73794913116328 34.02 35.67281645234142 139.73787106237538 34.02 35.67281645234142 139.73787106237538 8.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672842203331555 139.73794913116328 8.54 35.67294672298737 139.7378991865847 8.54 35.67294672298737 139.7378991865847 34.02 35.672842203331555 139.73794913116328 34.02 35.672842203331555 139.73794913116328 8.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67294672298737 139.7378991865847 34.02 35.6729233150938 139.73782056258926 34.02 35.67281645234142 139.73787106237538 34.02 35.672842203331555 139.73794913116328 34.02 35.67294672298737 139.7378991865847 34.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-4040ef22-d295-44e4-8b78-6e727b7cecd3"/>
							<gml:surfaceMember xlink:href="#poly-96c44928-53af-4799-be83-930abc514d6d"/>
							<gml:surfaceMember xlink:href="#poly-b3b7cb2a-7025-488d-beb3-dc1f3b774307"/>
							<gml:surfaceMember xlink:href="#poly-ee0b6aa7-db58-495f-8407-2a31b7426a7b"/>
							<gml:surfaceMember xlink:href="#poly-fca4f6c2-f893-40f3-945b-d5b3c814262f"/>
							<gml:surfaceMember xlink:href="#poly-4f73664f-195d-4157-89fe-426fa4d4edf0"/>
							<gml:surfaceMember xlink:href="#poly-93b3b342-12af-4dec-be52-24e09d42fc86"/>
							<gml:surfaceMember xlink:href="#poly-24ef7da4-b3ec-40c3-a2ea-42cb28aa6201"/>
							<gml:surfaceMember xlink:href="#poly-294141d7-9fe3-4906-8466-a1778067ae05"/>
							<gml:surfaceMember xlink:href="#poly-87a028be-6bf9-42a6-8f19-ddc8899a724a"/>
							<gml:surfaceMember xlink:href="#poly-a91229c4-68ee-4c52-8f9e-e9c5b3de4635"/>
							<gml:surfaceMember xlink:href="#poly-d750e1c7-1068-4c1a-aac2-a2a15d828ed5"/>
							<gml:surfaceMember xlink:href="#poly-ebffee0a-0fbf-4189-92f3-9734d64bbdb6"/>
							<gml:surfaceMember xlink:href="#poly-48df61a0-befa-4cc8-a90f-c9cef6783cc1"/>
							<gml:surfaceMember xlink:href="#poly-45249701-128a-4c45-9d4b-0eb0ca461f94"/>
							<gml:surfaceMember xlink:href="#poly-9e9dc079-b6bd-48ff-8829-5ef266ae7e15"/>
							<gml:surfaceMember xlink:href="#poly-2436e133-0afc-465d-81ee-76b150a15ea6"/>
							<gml:surfaceMember xlink:href="#poly-f729ac0f-5dc9-4861-96c8-6963d2f14eb1"/>
							<gml:surfaceMember xlink:href="#poly-3d2858a0-3900-469a-a54e-98700a2317cd"/>
							<gml:surfaceMember xlink:href="#poly-e545a03a-973d-4aa0-b41f-b81b7c1dd697"/>
							<gml:surfaceMember xlink:href="#poly-20770814-28e5-4343-b8f9-d98cddfae0bd"/>
							<gml:surfaceMember xlink:href="#poly-09445b81-14e9-4cac-9bf4-8842d6002d05"/>
							<gml:surfaceMember xlink:href="#poly-44a949ec-065f-46d4-8ea5-a34973f12ec5"/>
							<gml:surfaceMember xlink:href="#poly-36ec8b49-0651-4b37-9d52-110dcdd7b30d"/>
							<gml:surfaceMember xlink:href="#poly-b7bc25dc-7718-4d94-b813-efc53af619e3"/>
							<gml:surfaceMember xlink:href="#poly-c602cc0b-6fb0-4b0c-87f0-4723313934a8"/>
							<gml:surfaceMember xlink:href="#poly-b725269b-4184-4f02-8aab-f3cdad8ff2a5"/>
							<gml:surfaceMember xlink:href="#poly-2aa7811a-c4a9-4022-8fb1-1da9332f6ae5"/>
							<gml:surfaceMember xlink:href="#poly-76de614b-e8f0-487e-9c98-3a4b9c473606"/>
							<gml:surfaceMember xlink:href="#poly-50d2dd25-1083-496e-9254-3cb46da5dff5"/>
							<gml:surfaceMember xlink:href="#poly-44bc8507-885a-4424-be1c-003030822cf4"/>
							<gml:surfaceMember xlink:href="#poly-16a255a0-679b-471d-b3b3-92f0d84861f0"/>
							<gml:surfaceMember xlink:href="#poly-cd765ce0-1769-4a52-91e8-23528365f471"/>
							<gml:surfaceMember xlink:href="#poly-27df7e59-705c-4621-b5db-a55635e2c330"/>
							<gml:surfaceMember xlink:href="#poly-6cb94c16-110e-455c-8fb2-5d7f1eaf30aa"/>
							<gml:surfaceMember xlink:href="#poly-00c52c90-cf45-4b62-82f6-8e1b4feb6c41"/>
							<gml:surfaceMember xlink:href="#poly-b56a19b0-d4ae-40fe-9e1e-74383c523ee4"/>
							<gml:surfaceMember xlink:href="#poly-7d0fbee9-3de1-4a02-8e4c-862cb3f70b40"/>
							<gml:surfaceMember xlink:href="#poly-2e43440a-612b-4455-9539-6945b194dd67"/>
							<gml:surfaceMember xlink:href="#poly-322dcbef-0f5a-49e4-aaf7-b2470b72f084"/>
							<gml:surfaceMember xlink:href="#poly-4d6ff8c9-c860-4739-b9f8-778bb5c22bdb"/>
							<gml:surfaceMember xlink:href="#poly-4a201b68-5114-4276-b37f-c45657df24bb"/>
							<gml:surfaceMember xlink:href="#poly-9d725e90-4879-420c-9ab5-dc3651effded"/>
							<gml:surfaceMember xlink:href="#poly-ee211238-2357-4e98-8d04-f55fb8cc6314"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_450fff25-f959-4d46-8353-d7b2e56da451_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5017acc9-d7a1-4513-8ec2-6cf232b413b5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67283148766153 139.737871596802 39.963 35.672832111131946 139.7378735181675 39.963 35.67282732665154 139.7378757994633 39.963 35.672826703181165 139.7378738780979 39.963 35.67283148766153 139.737871596802 39.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8df803ed-7f0d-4fd9-87db-0c80af1737d5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67287835778816 139.73787001656066 34.084 35.67289610810423 139.7378615337242 34.084 35.67290545156609 139.73789088447913 34.084 35.672887692243 139.7378993783674 34.084 35.67287835778816 139.73787001656066 34.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-351237be-8e19-4a59-aa73-56a9909bb175">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672832111131946 139.7378735181675 39.713 35.67283881576477 139.7378942667417 39.713 35.67283402227027 139.7378965480472 39.713 35.67282732665154 139.7378757994633 39.713 35.672832111131946 139.7378735181675 39.713</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-005114de-5544-4a87-9b77-acc2b39fe8d5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672858913296594 139.73790175450497 39.713 35.67285378070362 139.73788561048542 39.713 35.6728634217394 139.737881003621 39.713 35.67286855433299 139.7378971476422 39.713 35.672858913296594 139.73790175450497 39.713</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c17a965d-6db5-4cb4-8265-f6e72d52f9e7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c17a965d-6db5-4cb4-8265-f6e72d52f9e7_0">
											<gml:posList>35.67289610810423 139.7378615337242 34.084 35.67287835778816 139.73787001656066 34.084 35.67287835778816 139.73787001656066 36.621 35.67289610810423 139.7378615337242 36.621 35.67289610810423 139.7378615337242 34.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37395396-7bab-4986-9c69-5a482092214a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-37395396-7bab-4986-9c69-5a482092214a_0">
											<gml:posList>35.67283148766153 139.737871596802 39.963 35.672826703181165 139.7378738780979 39.963 35.672826703181165 139.7378738780979 40.929 35.67283148766153 139.737871596802 40.929 35.67283148766153 139.737871596802 39.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f5847e0-bcfa-49da-bd5a-3a75c10a2545">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5f5847e0-bcfa-49da-bd5a-3a75c10a2545_0">
											<gml:posList>35.67282732665154 139.7378757994633 39.963 35.672832111131946 139.7378735181675 39.963 35.672832111131946 139.7378735181675 39.713 35.67282732665154 139.7378757994633 39.713 35.67282732665154 139.7378757994633 39.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-86f90b5e-02a0-4c83-81cd-b4669fa1896b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-86f90b5e-02a0-4c83-81cd-b4669fa1896b_0">
											<gml:posList>35.67289610810423 139.7378615337242 34.084 35.67289610810423 139.7378615337242 36.621 35.67290545156609 139.73789088447913 36.621 35.67290545156609 139.73789088447913 34.084 35.67289610810423 139.7378615337242 34.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7d8bac0e-b33a-4ff9-bdb3-c1ec594f28c0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7d8bac0e-b33a-4ff9-bdb3-c1ec594f28c0_0">
											<gml:posList>35.67290545156609 139.73789088447913 36.621 35.67289610810423 139.7378615337242 36.621 35.67287835778816 139.73787001656066 36.621 35.672887692243 139.7378993783674 36.621 35.67290545156609 139.73789088447913 36.621</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f03cc44-2c1d-4569-b250-bede6c6fe155">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5f03cc44-2c1d-4569-b250-bede6c6fe155_0">
											<gml:posList>35.67283148766153 139.737871596802 40.929 35.67283881576477 139.7378942667417 40.929 35.67283881576477 139.7378942667417 39.713 35.672832111131946 139.7378735181675 39.713 35.672832111131946 139.7378735181675 39.963 35.67283148766153 139.737871596802 39.963 35.67283148766153 139.737871596802 40.929</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb4d2288-6134-4e2c-9bc5-00fb6fb1a7f2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fb4d2288-6134-4e2c-9bc5-00fb6fb1a7f2_0">
											<gml:posList>35.67285378070362 139.73788561048542 39.713 35.67285378070362 139.73788561048542 41.353 35.6728634217394 139.737881003621 41.353 35.6728634217394 139.737881003621 39.713 35.67285378070362 139.73788561048542 39.713</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a302e62-b610-4caa-aee5-603ea88b8676">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4a302e62-b610-4caa-aee5-603ea88b8676_0">
											<gml:posList>35.67283402227027 139.7378965480472 40.929 35.67283881576477 139.7378942667417 40.929 35.67283148766153 139.737871596802 40.929 35.672826703181165 139.7378738780979 40.929 35.67283402227027 139.7378965480472 40.929</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-def779d9-21dc-469b-b81f-132db476c596">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-def779d9-21dc-469b-b81f-132db476c596_0">
											<gml:posList>35.672887692243 139.7378993783674 34.084 35.672887692243 139.7378993783674 36.621 35.67287835778816 139.73787001656066 36.621 35.67287835778816 139.73787001656066 34.084 35.672887692243 139.7378993783674 34.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8fff05fc-dffa-4838-9f21-17fb7ae5e7c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8fff05fc-dffa-4838-9f21-17fb7ae5e7c3_0">
											<gml:posList>35.67282732665154 139.7378757994633 39.963 35.67282732665154 139.7378757994633 39.713 35.67283402227027 139.7378965480472 39.713 35.67283402227027 139.7378965480472 40.929 35.672826703181165 139.7378738780979 40.929 35.672826703181165 139.7378738780979 39.963 35.67282732665154 139.7378757994633 39.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94404494-5aee-49da-a7d9-1c5caa6caf2b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-94404494-5aee-49da-a7d9-1c5caa6caf2b_0">
											<gml:posList>35.67286855433299 139.7378971476422 39.713 35.6728634217394 139.737881003621 39.713 35.6728634217394 139.737881003621 41.353 35.67286855433299 139.7378971476422 41.353 35.67286855433299 139.7378971476422 39.713</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a589cc2b-8e33-470d-90b4-41798a4a6ad3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a589cc2b-8e33-470d-90b4-41798a4a6ad3_0">
											<gml:posList>35.672858913296594 139.73790175450497 41.353 35.67286855433299 139.7378971476422 41.353 35.6728634217394 139.737881003621 41.353 35.67285378070362 139.73788561048542 41.353 35.672858913296594 139.73790175450497 41.353</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e9a27d3-e39f-4073-a7ff-b2275c40df6a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8e9a27d3-e39f-4073-a7ff-b2275c40df6a_0">
											<gml:posList>35.672858913296594 139.73790175450497 39.713 35.672858913296594 139.73790175450497 41.353 35.67285378070362 139.73788561048542 41.353 35.67285378070362 139.73788561048542 39.713 35.672858913296594 139.73790175450497 39.713</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8dc7f4e-f4d4-4079-90c6-b065b6996541">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8dc7f4e-f4d4-4079-90c6-b065b6996541_0">
											<gml:posList>35.672887692243 139.7378993783674 34.084 35.67290545156609 139.73789088447913 34.084 35.67290545156609 139.73789088447913 36.621 35.672887692243 139.7378993783674 36.621 35.672887692243 139.7378993783674 34.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94330f0f-7941-455e-8704-97131cf54983">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-94330f0f-7941-455e-8704-97131cf54983_0">
											<gml:posList>35.67283402227027 139.7378965480472 39.713 35.67283881576477 139.7378942667417 39.713 35.67283881576477 139.7378942667417 40.929 35.67283402227027 139.7378965480472 40.929 35.67283402227027 139.7378965480472 39.713</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-735390a0-ad71-49e7-a217-6781e049df28">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-735390a0-ad71-49e7-a217-6781e049df28_0">
											<gml:posList>35.672858913296594 139.73790175450497 39.713 35.67286855433299 139.7378971476422 39.713 35.67286855433299 139.7378971476422 41.353 35.672858913296594 139.73790175450497 41.353 35.672858913296594 139.73790175450497 39.713</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-4040ef22-d295-44e4-8b78-6e727b7cecd3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4040ef22-d295-44e4-8b78-6e727b7cecd3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4040ef22-d295-44e4-8b78-6e727b7cecd3">
											<gml:posList>35.67294672298736 139.7378991865847 8.54 35.67284220333153 139.73794913116325 8.54 35.67281645234141 139.73787106237538 8.54 35.67292331509378 139.73782056258926 8.54 35.67294672298736 139.7378991865847 8.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-96c44928-53af-4799-be83-930abc514d6d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96c44928-53af-4799-be83-930abc514d6d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96c44928-53af-4799-be83-930abc514d6d">
											<gml:posList>35.67292331509378 139.73782056258926 34.584 35.6729209945139 139.7378268177348 34.584 35.67294170915368 139.73789640880693 34.584 35.67294672298736 139.7378991865847 34.584 35.67292331509378 139.73782056258926 34.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b3b7cb2a-7025-488d-beb3-dc1f3b774307">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b3b7cb2a-7025-488d-beb3-dc1f3b774307">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b3b7cb2a-7025-488d-beb3-dc1f3b774307">
											<gml:posList>35.67281645234141 139.73787106237538 34.584 35.67282818032542 139.7379065963578 34.584 35.67281866516879 139.737876693504 34.584 35.672841136896004 139.7378659625938 34.584 35.6729209945139 139.7378268177348 34.584 35.67292331509378 139.73782056258926 34.584 35.67281645234141 139.73787106237538 34.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ee0b6aa7-db58-495f-8407-2a31b7426a7b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee0b6aa7-db58-495f-8407-2a31b7426a7b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee0b6aa7-db58-495f-8407-2a31b7426a7b">
											<gml:posList>35.67281866516879 139.737876693504 39.963 35.67282185739123 139.737878412972 39.963 35.67283973385634 139.73786987476024 39.963 35.672841136896004 139.7378659625938 39.963 35.67281866516879 139.737876693504 39.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fca4f6c2-f893-40f3-945b-d5b3c814262f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fca4f6c2-f893-40f3-945b-d5b3c814262f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fca4f6c2-f893-40f3-945b-d5b3c814262f">
											<gml:posList>35.67287458006703 139.73790290679574 34.084 35.67288164639015 139.73792510205806 34.084 35.67294170915368 139.73789640880693 34.084 35.6729209945139 139.7378268177348 34.084 35.672841136896004 139.7378659625938 34.084 35.672847082731565 139.73788463531244 34.084 35.67286549079624 139.737875831348 34.084 35.672874165593576 139.73790310612796 34.084 35.67287458006703 139.73790290679574 34.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4f73664f-195d-4157-89fe-426fa4d4edf0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f73664f-195d-4157-89fe-426fa4d4edf0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f73664f-195d-4157-89fe-426fa4d4edf0">
											<gml:posList>35.672847082731565 139.73788463531244 39.963 35.672841136896004 139.7378659625938 39.963 35.67283973385634 139.73786987476024 39.963 35.672845670677575 139.73788854748963 39.963 35.672847082731565 139.73788463531244 39.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-93b3b342-12af-4dec-be52-24e09d42fc86">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-93b3b342-12af-4dec-be52-24e09d42fc86">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-93b3b342-12af-4dec-be52-24e09d42fc86">
											<gml:posList>35.672847082731565 139.73788463531244 39.963 35.672845670677575 139.73788854748963 39.963 35.672864078742535 139.7378797435262 39.963 35.67286549079624 139.737875831348 39.963 35.672847082731565 139.73788463531244 39.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-24ef7da4-b3ec-40c3-a2ea-42cb28aa6201">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-24ef7da4-b3ec-40c3-a2ea-42cb28aa6201">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-24ef7da4-b3ec-40c3-a2ea-42cb28aa6201">
											<gml:posList>35.67286549079624 139.737875831348 39.963 35.672864078742535 139.7378797435262 39.963 35.67287096434905 139.73790137562196 39.963 35.672874165593576 139.73790310612796 39.963 35.67286549079624 139.737875831348 39.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-294141d7-9fe3-4906-8466-a1778067ae05">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-294141d7-9fe3-4906-8466-a1778067ae05">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-294141d7-9fe3-4906-8466-a1778067ae05">
											<gml:posList>35.67282818032542 139.7379065963578 39.963 35.67283047794813 139.73790548896324 39.963 35.67282185739123 139.737878412972 39.963 35.67281866516879 139.737876693504 39.963 35.67282818032542 139.7379065963578 39.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-87a028be-6bf9-42a6-8f19-ddc8899a724a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-87a028be-6bf9-42a6-8f19-ddc8899a724a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-87a028be-6bf9-42a6-8f19-ddc8899a724a">
											<gml:posList>35.67287096434905 139.73790137562196 39.713 35.672864078742535 139.7378797435262 39.713 35.672845670677575 139.73788854748963 39.713 35.67283973385634 139.73786987476024 39.713 35.67282185739123 139.737878412972 39.713 35.67283047794813 139.73790548896324 39.713 35.672834778930465 139.737918673481 39.713 35.67287096434905 139.73790137562196 39.713</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a91229c4-68ee-4c52-8f9e-e9c5b3de4635">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a91229c4-68ee-4c52-8f9e-e9c5b3de4635">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a91229c4-68ee-4c52-8f9e-e9c5b3de4635">
											<gml:posList>35.672874165593576 139.73790310612796 39.963 35.67287096434905 139.73790137562196 39.963 35.672834778930465 139.737918673481 39.963 35.672833393916505 139.73792258562474 39.963 35.672874165593576 139.73790310612796 39.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d750e1c7-1068-4c1a-aac2-a2a15d828ed5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d750e1c7-1068-4c1a-aac2-a2a15d828ed5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d750e1c7-1068-4c1a-aac2-a2a15d828ed5">
											<gml:posList>35.672883074119994 139.73792959632678 34.584 35.67294672298736 139.7378991865847 34.584 35.67294170915368 139.73789640880693 34.584 35.67288164639015 139.73792510205806 34.584 35.672883074119994 139.73792959632678 34.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ebffee0a-0fbf-4189-92f3-9734d64bbdb6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ebffee0a-0fbf-4189-92f3-9734d64bbdb6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ebffee0a-0fbf-4189-92f3-9734d64bbdb6">
											<gml:posList>35.67282818032542 139.7379065963578 39.963 35.672833393916505 139.73792258562474 39.963 35.672834778930465 139.737918673481 39.963 35.67283047794813 139.73790548896324 39.963 35.67282818032542 139.7379065963578 39.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-48df61a0-befa-4cc8-a90f-c9cef6783cc1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-48df61a0-befa-4cc8-a90f-c9cef6783cc1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-48df61a0-befa-4cc8-a90f-c9cef6783cc1">
											<gml:posList>35.67288126158365 139.737928615336 37.3 35.672883074119994 139.73792959632678 37.3 35.67287458006703 139.73790290679574 37.3 35.672874165593576 139.73790310612796 37.3 35.672873264563194 139.73790353801797 37.3 35.67288126158365 139.737928615336 37.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-45249701-128a-4c45-9d4b-0eb0ca461f94">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45249701-128a-4c45-9d4b-0eb0ca461f94">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45249701-128a-4c45-9d4b-0eb0ca461f94">
											<gml:posList>35.672873264563194 139.73790353801797 36.961 35.67283971015219 139.73791957343315 36.961 35.67284769816436 139.7379446617996 36.961 35.67288126158365 139.737928615336 36.961 35.672873264563194 139.73790353801797 36.961</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9e9dc079-b6bd-48ff-8829-5ef266ae7e15">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e9dc079-b6bd-48ff-8829-5ef266ae7e15">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e9dc079-b6bd-48ff-8829-5ef266ae7e15">
											<gml:posList>35.67284769816436 139.7379446617996 37.3 35.67283971015219 139.73791957343315 37.3 35.67283841266693 139.7379201935868 37.3 35.67284689770238 139.73794688311838 37.3 35.67284769816436 139.7379446617996 37.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2436e133-0afc-465d-81ee-76b150a15ea6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2436e133-0afc-465d-81ee-76b150a15ea6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2436e133-0afc-465d-81ee-76b150a15ea6">
											<gml:posList>35.672833393916505 139.73792258562474 34.584 35.67284220333153 139.73794913116325 34.584 35.67284689770238 139.73794688311838 34.584 35.67283841266693 139.7379201935868 34.584 35.672833393916505 139.73792258562474 34.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f729ac0f-5dc9-4861-96c8-6963d2f14eb1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f729ac0f-5dc9-4861-96c8-6963d2f14eb1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f729ac0f-5dc9-4861-96c8-6963d2f14eb1">
											<gml:posList>35.672883074119994 139.73792959632678 37.3 35.67288126158365 139.737928615336 37.3 35.67284769816436 139.7379446617996 37.3 35.67284689770238 139.73794688311838 37.3 35.672883074119994 139.73792959632678 37.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3d2858a0-3900-469a-a54e-98700a2317cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d2858a0-3900-469a-a54e-98700a2317cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d2858a0-3900-469a-a54e-98700a2317cd">
											<gml:posList>35.67282818032542 139.7379065963578 39.963 35.67281866516879 139.737876693504 39.963 35.67281866516879 139.737876693504 34.584 35.67282818032542 139.7379065963578 34.584 35.67282818032542 139.7379065963578 39.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e545a03a-973d-4aa0-b41f-b81b7c1dd697">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e545a03a-973d-4aa0-b41f-b81b7c1dd697">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e545a03a-973d-4aa0-b41f-b81b7c1dd697">
											<gml:posList>35.67283047794813 139.73790548896324 39.963 35.67283047794813 139.73790548896324 39.713 35.67282185739123 139.737878412972 39.713 35.67282185739123 139.737878412972 39.963 35.67283047794813 139.73790548896324 39.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-20770814-28e5-4343-b8f9-d98cddfae0bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20770814-28e5-4343-b8f9-d98cddfae0bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20770814-28e5-4343-b8f9-d98cddfae0bd">
											<gml:posList>35.67281866516879 139.737876693504 39.963 35.672841136896004 139.7378659625938 39.963 35.672841136896004 139.7378659625938 34.584 35.67281866516879 139.737876693504 34.584 35.67281866516879 139.737876693504 39.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-09445b81-14e9-4cac-9bf4-8842d6002d05">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-09445b81-14e9-4cac-9bf4-8842d6002d05">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-09445b81-14e9-4cac-9bf4-8842d6002d05">
											<gml:posList>35.67282185739123 139.737878412972 39.963 35.67282185739123 139.737878412972 39.713 35.67283973385634 139.73786987476024 39.713 35.67283973385634 139.73786987476024 39.963 35.67282185739123 139.737878412972 39.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-44a949ec-065f-46d4-8ea5-a34973f12ec5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44a949ec-065f-46d4-8ea5-a34973f12ec5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44a949ec-065f-46d4-8ea5-a34973f12ec5">
											<gml:posList>35.67283973385634 139.73786987476024 39.963 35.67283973385634 139.73786987476024 39.713 35.672845670677575 139.73788854748963 39.713 35.672845670677575 139.73788854748963 39.963 35.67283973385634 139.73786987476024 39.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-36ec8b49-0651-4b37-9d52-110dcdd7b30d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36ec8b49-0651-4b37-9d52-110dcdd7b30d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36ec8b49-0651-4b37-9d52-110dcdd7b30d">
											<gml:posList>35.672841136896004 139.7378659625938 34.584 35.672841136896004 139.7378659625938 39.963 35.672847082731565 139.73788463531244 39.963 35.672847082731565 139.73788463531244 34.084 35.672841136896004 139.7378659625938 34.084 35.672841136896004 139.7378659625938 34.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b7bc25dc-7718-4d94-b813-efc53af619e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b7bc25dc-7718-4d94-b813-efc53af619e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b7bc25dc-7718-4d94-b813-efc53af619e3">
											<gml:posList>35.672845670677575 139.73788854748963 39.963 35.672845670677575 139.73788854748963 39.713 35.672864078742535 139.7378797435262 39.713 35.672864078742535 139.7378797435262 39.963 35.672845670677575 139.73788854748963 39.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c602cc0b-6fb0-4b0c-87f0-4723313934a8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c602cc0b-6fb0-4b0c-87f0-4723313934a8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c602cc0b-6fb0-4b0c-87f0-4723313934a8">
											<gml:posList>35.67286549079624 139.737875831348 39.963 35.67286549079624 139.737875831348 34.084 35.672847082731565 139.73788463531244 34.084 35.672847082731565 139.73788463531244 39.963 35.67286549079624 139.737875831348 39.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b725269b-4184-4f02-8aab-f3cdad8ff2a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b725269b-4184-4f02-8aab-f3cdad8ff2a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b725269b-4184-4f02-8aab-f3cdad8ff2a5">
											<gml:posList>35.672864078742535 139.7378797435262 39.963 35.672864078742535 139.7378797435262 39.713 35.67287096434905 139.73790137562196 39.713 35.67287096434905 139.73790137562196 39.963 35.672864078742535 139.7378797435262 39.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2aa7811a-c4a9-4022-8fb1-1da9332f6ae5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2aa7811a-c4a9-4022-8fb1-1da9332f6ae5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2aa7811a-c4a9-4022-8fb1-1da9332f6ae5">
											<gml:posList>35.67286549079624 139.737875831348 39.963 35.672874165593576 139.73790310612796 39.963 35.672874165593576 139.73790310612796 37.3 35.672874165593576 139.73790310612796 34.084 35.67286549079624 139.737875831348 34.084 35.67286549079624 139.737875831348 39.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-76de614b-e8f0-487e-9c98-3a4b9c473606">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-76de614b-e8f0-487e-9c98-3a4b9c473606">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-76de614b-e8f0-487e-9c98-3a4b9c473606">
											<gml:posList>35.67292331509378 139.73782056258926 8.54 35.67281645234141 139.73787106237538 8.54 35.67281645234141 139.73787106237538 34.584 35.67292331509378 139.73782056258926 34.584 35.67292331509378 139.73782056258926 8.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-50d2dd25-1083-496e-9254-3cb46da5dff5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50d2dd25-1083-496e-9254-3cb46da5dff5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50d2dd25-1083-496e-9254-3cb46da5dff5">
											<gml:posList>35.672841136896004 139.7378659625938 34.584 35.672841136896004 139.7378659625938 34.084 35.6729209945139 139.7378268177348 34.084 35.6729209945139 139.7378268177348 34.584 35.672841136896004 139.7378659625938 34.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-44bc8507-885a-4424-be1c-003030822cf4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44bc8507-885a-4424-be1c-003030822cf4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44bc8507-885a-4424-be1c-003030822cf4">
											<gml:posList>35.6729209945139 139.7378268177348 34.584 35.6729209945139 139.7378268177348 34.084 35.67294170915368 139.73789640880693 34.084 35.67294170915368 139.73789640880693 34.584 35.6729209945139 139.7378268177348 34.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-16a255a0-679b-471d-b3b3-92f0d84861f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16a255a0-679b-471d-b3b3-92f0d84861f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16a255a0-679b-471d-b3b3-92f0d84861f0">
											<gml:posList>35.67294672298736 139.7378991865847 8.54 35.67292331509378 139.73782056258926 8.54 35.67292331509378 139.73782056258926 34.584 35.67294672298736 139.7378991865847 34.584 35.67294672298736 139.7378991865847 8.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cd765ce0-1769-4a52-91e8-23528365f471">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd765ce0-1769-4a52-91e8-23528365f471">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd765ce0-1769-4a52-91e8-23528365f471">
											<gml:posList>35.67282818032542 139.7379065963578 34.584 35.67281645234141 139.73787106237538 34.584 35.67281645234141 139.73787106237538 8.54 35.67284220333153 139.73794913116325 8.54 35.67284220333153 139.73794913116325 34.584 35.672833393916505 139.73792258562474 34.584 35.672833393916505 139.73792258562474 39.963 35.67282818032542 139.7379065963578 39.963 35.67282818032542 139.7379065963578 34.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-27df7e59-705c-4621-b5db-a55635e2c330">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-27df7e59-705c-4621-b5db-a55635e2c330">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-27df7e59-705c-4621-b5db-a55635e2c330">
											<gml:posList>35.672834778930465 139.737918673481 39.963 35.672834778930465 139.737918673481 39.713 35.67283047794813 139.73790548896324 39.713 35.67283047794813 139.73790548896324 39.963 35.672834778930465 139.737918673481 39.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6cb94c16-110e-455c-8fb2-5d7f1eaf30aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6cb94c16-110e-455c-8fb2-5d7f1eaf30aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6cb94c16-110e-455c-8fb2-5d7f1eaf30aa">
											<gml:posList>35.67284689770238 139.73794688311838 37.3 35.67283841266693 139.7379201935868 37.3 35.67283841266693 139.7379201935868 34.584 35.67284689770238 139.73794688311838 34.584 35.67284689770238 139.73794688311838 37.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-00c52c90-cf45-4b62-82f6-8e1b4feb6c41">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-00c52c90-cf45-4b62-82f6-8e1b4feb6c41">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-00c52c90-cf45-4b62-82f6-8e1b4feb6c41">
											<gml:posList>35.67284769816436 139.7379446617996 37.3 35.67284769816436 139.7379446617996 36.961 35.67283971015219 139.73791957343315 36.961 35.67283971015219 139.73791957343315 37.3 35.67284769816436 139.7379446617996 37.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b56a19b0-d4ae-40fe-9e1e-74383c523ee4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b56a19b0-d4ae-40fe-9e1e-74383c523ee4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b56a19b0-d4ae-40fe-9e1e-74383c523ee4">
											<gml:posList>35.67287096434905 139.73790137562196 39.963 35.67287096434905 139.73790137562196 39.713 35.672834778930465 139.737918673481 39.713 35.672834778930465 139.737918673481 39.963 35.67287096434905 139.73790137562196 39.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7d0fbee9-3de1-4a02-8e4c-862cb3f70b40">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d0fbee9-3de1-4a02-8e4c-862cb3f70b40">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d0fbee9-3de1-4a02-8e4c-862cb3f70b40">
											<gml:posList>35.672873264563194 139.73790353801797 37.3 35.672874165593576 139.73790310612796 37.3 35.672874165593576 139.73790310612796 39.963 35.672833393916505 139.73792258562474 39.963 35.672833393916505 139.73792258562474 34.584 35.67283841266693 139.7379201935868 34.584 35.67283841266693 139.7379201935868 37.3 35.67283971015219 139.73791957343315 37.3 35.67283971015219 139.73791957343315 36.961 35.672873264563194 139.73790353801797 36.961 35.672873264563194 139.73790353801797 37.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2e43440a-612b-4455-9539-6945b194dd67">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2e43440a-612b-4455-9539-6945b194dd67">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2e43440a-612b-4455-9539-6945b194dd67">
											<gml:posList>35.67288126158365 139.737928615336 37.3 35.67288126158365 139.737928615336 36.961 35.67284769816436 139.7379446617996 36.961 35.67284769816436 139.7379446617996 37.3 35.67288126158365 139.737928615336 37.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-322dcbef-0f5a-49e4-aaf7-b2470b72f084">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-322dcbef-0f5a-49e4-aaf7-b2470b72f084">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-322dcbef-0f5a-49e4-aaf7-b2470b72f084">
											<gml:posList>35.67287458006703 139.73790290679574 37.3 35.67287458006703 139.73790290679574 34.084 35.672874165593576 139.73790310612796 34.084 35.672874165593576 139.73790310612796 37.3 35.67287458006703 139.73790290679574 37.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4d6ff8c9-c860-4739-b9f8-778bb5c22bdb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d6ff8c9-c860-4739-b9f8-778bb5c22bdb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d6ff8c9-c860-4739-b9f8-778bb5c22bdb">
											<gml:posList>35.672873264563194 139.73790353801797 37.3 35.672873264563194 139.73790353801797 36.961 35.67288126158365 139.737928615336 36.961 35.67288126158365 139.737928615336 37.3 35.672873264563194 139.73790353801797 37.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4a201b68-5114-4276-b37f-c45657df24bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a201b68-5114-4276-b37f-c45657df24bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a201b68-5114-4276-b37f-c45657df24bb">
											<gml:posList>35.67287458006703 139.73790290679574 37.3 35.672883074119994 139.73792959632678 37.3 35.672883074119994 139.73792959632678 34.584 35.67288164639015 139.73792510205806 34.584 35.67288164639015 139.73792510205806 34.084 35.67287458006703 139.73790290679574 34.084 35.67287458006703 139.73790290679574 37.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9d725e90-4879-420c-9ab5-dc3651effded">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d725e90-4879-420c-9ab5-dc3651effded">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d725e90-4879-420c-9ab5-dc3651effded">
											<gml:posList>35.672883074119994 139.73792959632678 34.584 35.672883074119994 139.73792959632678 37.3 35.67284689770238 139.73794688311838 37.3 35.67284689770238 139.73794688311838 34.584 35.67284220333153 139.73794913116325 34.584 35.67284220333153 139.73794913116325 8.54 35.67294672298736 139.7378991865847 8.54 35.67294672298736 139.7378991865847 34.584 35.672883074119994 139.73792959632678 34.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ee211238-2357-4e98-8d04-f55fb8cc6314">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee211238-2357-4e98-8d04-f55fb8cc6314">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee211238-2357-4e98-8d04-f55fb8cc6314">
											<gml:posList>35.67294170915368 139.73789640880693 34.584 35.67294170915368 139.73789640880693 34.084 35.67288164639015 139.73792510205806 34.084 35.67288164639015 139.73792510205806 34.584 35.67294170915368 139.73789640880693 34.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6489</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">95.55955</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.17</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>