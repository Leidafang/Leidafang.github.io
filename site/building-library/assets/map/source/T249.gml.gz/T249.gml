<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_453a3b19-5ac4-499c-a065-23a8f4008473">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>0.85</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018003</gen:value>
			</gen:stringAttribute>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">431</bldg:usage>
			<bldg:measuredHeight uom="m">15.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66667494085066 139.74689806792634 0 35.66659259838947 139.7471846168604 0 35.666684756236116 139.74722438196824 0 35.66672922740871 139.7470696162934 0 35.66683060017804 139.74711335895122 0 35.666800362266855 139.74721856925646 0 35.66688114125891 139.7472534313488 0 35.66692871447484 139.74708787024326 0 35.666827972848964 139.74704439198374 0 35.66684988466146 139.74696814152023 0 35.6668388303986 139.74696337060666 0 35.666802881502534 139.7469478568866 0 35.66680149684296 139.74695267433276 0 35.66667494085066 139.74689806792634 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66667494085066 139.74689806792634 6.237 35.66680149684296 139.74695267433276 6.237 35.666802881502534 139.7469478568866 6.237 35.6668388303986 139.74696337060666 6.237 35.66684988466146 139.74696814152023 6.237 35.666827972848964 139.74704439198374 6.237 35.66692871447484 139.74708787024326 6.237 35.66688114125891 139.7472534313488 6.237 35.666800362266855 139.74721856925646 6.237 35.66683060017804 139.74711335895122 6.237 35.66672922740871 139.7470696162934 6.237 35.666684756236116 139.74722438196824 6.237 35.66659259838947 139.7471846168604 6.237 35.66667494085066 139.74689806792634 6.237</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66667494085066 139.74689806792634 6.237 35.66659259838947 139.7471846168604 6.237 35.66659259838947 139.7471846168604 21.49 35.66667494085066 139.74689806792634 21.49 35.66667494085066 139.74689806792634 6.237</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66659259838947 139.7471846168604 6.237 35.666684756236116 139.74722438196824 6.237 35.666684756236116 139.74722438196824 21.49 35.66659259838947 139.7471846168604 21.49 35.66659259838947 139.7471846168604 6.237</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666684756236116 139.74722438196824 6.237 35.66672922740871 139.7470696162934 6.237 35.66672922740871 139.7470696162934 21.49 35.666684756236116 139.74722438196824 21.49 35.666684756236116 139.74722438196824 6.237</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66672922740871 139.7470696162934 6.237 35.66683060017804 139.74711335895122 6.237 35.66683060017804 139.74711335895122 21.49 35.66672922740871 139.7470696162934 21.49 35.66672922740871 139.7470696162934 6.237</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66683060017804 139.74711335895122 6.237 35.666800362266855 139.74721856925646 6.237 35.666800362266855 139.74721856925646 21.49 35.66683060017804 139.74711335895122 21.49 35.66683060017804 139.74711335895122 6.237</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666800362266855 139.74721856925646 6.237 35.66688114125891 139.7472534313488 6.237 35.66688114125891 139.7472534313488 21.49 35.666800362266855 139.74721856925646 21.49 35.666800362266855 139.74721856925646 6.237</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66688114125891 139.7472534313488 6.237 35.66692871447484 139.74708787024326 6.237 35.66692871447484 139.74708787024326 21.49 35.66688114125891 139.7472534313488 21.49 35.66688114125891 139.7472534313488 6.237</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66692871447484 139.74708787024326 6.237 35.666827972848964 139.74704439198374 6.237 35.666827972848964 139.74704439198374 21.49 35.66692871447484 139.74708787024326 21.49 35.66692871447484 139.74708787024326 6.237</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666827972848964 139.74704439198374 6.237 35.66684988466146 139.74696814152023 6.237 35.66684988466146 139.74696814152023 21.49 35.666827972848964 139.74704439198374 21.49 35.666827972848964 139.74704439198374 6.237</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66684988466146 139.74696814152023 6.237 35.6668388303986 139.74696337060666 6.237 35.6668388303986 139.74696337060666 21.49 35.66684988466146 139.74696814152023 21.49 35.66684988466146 139.74696814152023 6.237</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6668388303986 139.74696337060666 6.237 35.666802881502534 139.7469478568866 6.237 35.666802881502534 139.7469478568866 21.49 35.6668388303986 139.74696337060666 21.49 35.6668388303986 139.74696337060666 6.237</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666802881502534 139.7469478568866 6.237 35.66680149684296 139.74695267433276 6.237 35.66680149684296 139.74695267433276 21.49 35.666802881502534 139.7469478568866 21.49 35.666802881502534 139.7469478568866 6.237</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66680149684296 139.74695267433276 6.237 35.66667494085066 139.74689806792634 6.237 35.66667494085066 139.74689806792634 21.49 35.66680149684296 139.74695267433276 21.49 35.66680149684296 139.74695267433276 6.237</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66667494085066 139.74689806792634 21.49 35.66659259838947 139.7471846168604 21.49 35.666684756236116 139.74722438196824 21.49 35.66672922740871 139.7470696162934 21.49 35.66683060017804 139.74711335895122 21.49 35.666800362266855 139.74721856925646 21.49 35.66688114125891 139.7472534313488 21.49 35.66692871447484 139.74708787024326 21.49 35.666827972848964 139.74704439198374 21.49 35.66684988466146 139.74696814152023 21.49 35.6668388303986 139.74696337060666 21.49 35.666802881502534 139.7469478568866 21.49 35.66680149684296 139.74695267433276 21.49 35.66667494085066 139.74689806792634 21.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-a1722609-3269-4d3b-b155-a3ead8cf66bb"/>
							<gml:surfaceMember xlink:href="#poly-6255ad61-21d6-420e-8451-fd29ada8bcc2"/>
							<gml:surfaceMember xlink:href="#poly-3ea59a49-c643-4cee-b447-795894c25baf"/>
							<gml:surfaceMember xlink:href="#poly-30536dfa-e0d8-490a-8011-032790e36667"/>
							<gml:surfaceMember xlink:href="#poly-42bbc397-bccc-40c2-b99d-5296803e9bf4"/>
							<gml:surfaceMember xlink:href="#poly-841798e8-0de4-4c05-87d0-69820cf68ce6"/>
							<gml:surfaceMember xlink:href="#poly-41c65e74-f11b-4c67-b966-cc1c49f93a21"/>
							<gml:surfaceMember xlink:href="#poly-1e968506-3a38-4a35-b6ca-40e59ac02e90"/>
							<gml:surfaceMember xlink:href="#poly-725db44e-0949-45b0-ad9c-4e04c2d5e175"/>
							<gml:surfaceMember xlink:href="#poly-01b7a6cd-0063-44b6-8825-1ae1e4d3941d"/>
							<gml:surfaceMember xlink:href="#poly-905bfa99-fff8-4eb2-b8c2-841188c7d604"/>
							<gml:surfaceMember xlink:href="#poly-c8fc12c5-5836-4d3b-b99c-0947b4e312fb"/>
							<gml:surfaceMember xlink:href="#poly-89710eaa-2573-4c1d-8f40-d890b8fc92da"/>
							<gml:surfaceMember xlink:href="#poly-f4840401-640e-48d9-ba6e-d90cb2137b71"/>
							<gml:surfaceMember xlink:href="#poly-d3571e12-fa82-4449-8f16-2454a22e2b7a"/>
							<gml:surfaceMember xlink:href="#poly-9491a3cb-1800-44c1-8769-ab21ec5f795a"/>
							<gml:surfaceMember xlink:href="#poly-6265d6c8-5ace-40b4-a540-ca7965b18751"/>
							<gml:surfaceMember xlink:href="#poly-b496ef56-fb7d-489c-a834-1c7268bc984c"/>
							<gml:surfaceMember xlink:href="#poly-b4bc32c2-c33c-4b24-9a8e-95f1c1333d24"/>
							<gml:surfaceMember xlink:href="#poly-6dd73dd1-953f-4be1-994e-baf058cbbaa8"/>
							<gml:surfaceMember xlink:href="#poly-b60149f7-a5e8-450f-a2f6-f69ec6954c53"/>
							<gml:surfaceMember xlink:href="#poly-25bfdd55-b96f-45f5-a7c8-38348df1b84f"/>
							<gml:surfaceMember xlink:href="#poly-76331f3a-7c68-4543-97dd-b5eb83847a61"/>
							<gml:surfaceMember xlink:href="#poly-cfc82692-13f5-41d9-b039-815754162ca2"/>
							<gml:surfaceMember xlink:href="#poly-aed468fe-f230-4929-bc8a-6b7aa555d065"/>
							<gml:surfaceMember xlink:href="#poly-54cfd540-1368-4eb6-9404-bd629f936ea3"/>
							<gml:surfaceMember xlink:href="#poly-0a86bff6-100d-47a4-b1bc-a9ab232cb5ff"/>
							<gml:surfaceMember xlink:href="#poly-daede928-2fdd-46c6-b49b-c5af30e8b7b9"/>
							<gml:surfaceMember xlink:href="#poly-6b59667f-ffc2-43f3-9e12-eb940c389537"/>
							<gml:surfaceMember xlink:href="#poly-e4d98e9e-f4a8-42b2-9967-b4d672fe9fa3"/>
							<gml:surfaceMember xlink:href="#poly-99945a74-8a46-4dd6-b179-c05708a7213e"/>
							<gml:surfaceMember xlink:href="#poly-6ef14242-3064-4a69-a450-6d923d5553ba"/>
							<gml:surfaceMember xlink:href="#poly-ebf0179b-4370-4944-8f8f-1fc9bac46c61"/>
							<gml:surfaceMember xlink:href="#poly-21d73d7c-e608-4a26-958d-a06683148bee"/>
							<gml:surfaceMember xlink:href="#poly-d9d22846-1dda-432c-8b7d-e151e89f330a"/>
							<gml:surfaceMember xlink:href="#poly-164c9f28-af5e-4d7c-9e76-43cc5b6d5f2b"/>
							<gml:surfaceMember xlink:href="#poly-487ee97b-f968-4194-b450-d67a9ef093ee"/>
							<gml:surfaceMember xlink:href="#poly-d33b15ab-6267-472d-99e9-09d45029a9bf"/>
							<gml:surfaceMember xlink:href="#poly-0a49f6f3-2004-427d-9a2a-07d2f6331320"/>
							<gml:surfaceMember xlink:href="#poly-c6dd6e84-aee9-4721-b407-f1535de4f7ed"/>
							<gml:surfaceMember xlink:href="#poly-3fd4495d-fc96-494a-8b08-2a8fa635c372"/>
							<gml:surfaceMember xlink:href="#poly-ccf0355e-b1f8-4aa9-b57f-19dbb08b94f7"/>
							<gml:surfaceMember xlink:href="#poly-f6c8fe17-4430-4b68-9f58-abe2c46e8e80"/>
							<gml:surfaceMember xlink:href="#poly-4bff34d9-af3c-4cc4-ad8a-053e802bba00"/>
							<gml:surfaceMember xlink:href="#poly-e9b0c5c2-1a1b-4bf5-ba95-49870ddcb143"/>
							<gml:surfaceMember xlink:href="#poly-e3a63f0f-69e4-437f-a448-f93fe3013f7b"/>
							<gml:surfaceMember xlink:href="#poly-6ff50da0-05e8-460b-beb3-89855e832c73"/>
							<gml:surfaceMember xlink:href="#poly-62c4c686-f751-49aa-bfdc-6a829309fbd9"/>
							<gml:surfaceMember xlink:href="#poly-c8f3f12a-b8ff-4d43-9197-ab70fe5859e6"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_453a3b19-5ac4-499c-a065-23a8f4008473_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-15008785-db95-4ab2-8565-9475200061e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-15008785-db95-4ab2-8565-9475200061e2_0">
											<gml:posList>35.66668284904567 139.74692757364804 22.678 35.66667258188825 139.74696455483422 24.337 35.66668284904567 139.74692757364804 24.337 35.66668284904567 139.74692757364804 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24083f04-67a0-44af-ac26-1ae8519e4856">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-24083f04-67a0-44af-ac26-1ae8519e4856_0">
											<gml:posList>35.66668284904567 139.74692757364804 22.678 35.66667258188825 139.74696455483422 22.678 35.66667258188825 139.74696455483422 24.337 35.66668284904567 139.74692757364804 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3839f6b9-f66d-4af5-b61d-5bfc10ac679e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3839f6b9-f66d-4af5-b61d-5bfc10ac679e_0">
											<gml:posList>35.66667258188825 139.74696455483422 22.678 35.66673074689418 139.74698880389812 24.337 35.66667258188825 139.74696455483422 24.337 35.66667258188825 139.74696455483422 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-843a622a-0ab1-439a-bc67-2056445dcf9c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-843a622a-0ab1-439a-bc67-2056445dcf9c_0">
											<gml:posList>35.66667258188825 139.74696455483422 22.678 35.66673074689418 139.74698880389812 22.678 35.66673074689418 139.74698880389812 24.337 35.66667258188825 139.74696455483422 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3469abd2-9a1a-4fc2-9514-c982a2566421">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3469abd2-9a1a-4fc2-9514-c982a2566421_0">
											<gml:posList>35.666741014050984 139.74695181164248 22.678 35.66668284904567 139.74692757364804 24.337 35.666741014050984 139.74695181164248 24.337 35.666741014050984 139.74695181164248 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f6a2f04-9267-4b49-ab9d-931e571a8d68">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2f6a2f04-9267-4b49-ab9d-931e571a8d68_0">
											<gml:posList>35.666741014050984 139.74695181164248 22.678 35.66668284904567 139.74692757364804 22.678 35.66668284904567 139.74692757364804 24.337 35.666741014050984 139.74695181164248 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bcd6ab67-770f-4cdb-a5fa-55a132a0efc4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bcd6ab67-770f-4cdb-a5fa-55a132a0efc4_0">
											<gml:posList>35.66673827742149 139.7469944622635 22.678 35.66674562575746 139.74699744775234 23.458 35.66673827742149 139.7469944622635 23.458 35.66673827742149 139.7469944622635 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a332438c-a7da-4905-b85e-6bab5817a789">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a332438c-a7da-4905-b85e-6bab5817a789_0">
											<gml:posList>35.66673827742149 139.7469944622635 22.678 35.66674562575746 139.74699744775234 22.678 35.66674562575746 139.74699744775234 23.458 35.66673827742149 139.7469944622635 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13aa5d70-4d6a-4ed1-b94a-4824fbcecb75">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-13aa5d70-4d6a-4ed1-b94a-4824fbcecb75_0">
											<gml:posList>35.66674930089449 139.7470065786389 22.678 35.666760038923044 139.74701030054618 23.233 35.66674930089449 139.7470065786389 23.233 35.66674930089449 139.7470065786389 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b4076fd-858b-4baa-a094-fd1539c14e7c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5b4076fd-858b-4baa-a094-fd1539c14e7c_0">
											<gml:posList>35.66674930089449 139.7470065786389 22.678 35.666760038923044 139.74701030054618 22.678 35.666760038923044 139.74701030054618 23.233 35.66674930089449 139.7470065786389 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5dc5227c-d68d-48bc-aaa5-5e9d1f759113">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5dc5227c-d68d-48bc-aaa5-5e9d1f759113_0">
											<gml:posList>35.66676302222418 139.74699738483912 23.233 35.666760038923044 139.74701030054618 22.678 35.66676302222418 139.74699738483912 22.678 35.66676302222418 139.74699738483912 23.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-49d5e776-4ac9-4f55-a67f-f92f3037a219">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-49d5e776-4ac9-4f55-a67f-f92f3037a219_0">
											<gml:posList>35.66676302222418 139.74699738483912 23.233 35.666760038923044 139.74701030054618 23.233 35.666760038923044 139.74701030054618 22.678 35.66676302222418 139.74699738483912 23.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b9e0c62-051e-41b2-8e1e-8aa51353a845">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b9e0c62-051e-41b2-8e1e-8aa51353a845_0">
											<gml:posList>35.66675219865199 139.74697492941607 22.678 35.66677392833098 139.74698409608942 25.861 35.66675219865199 139.74697492941607 25.861 35.66675219865199 139.74697492941607 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b6beef50-c9d7-4bbd-9eb1-d553c229bdf4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b6beef50-c9d7-4bbd-9eb1-d553c229bdf4_0">
											<gml:posList>35.66675219865199 139.74697492941607 22.678 35.66677392833098 139.74698409608942 22.678 35.66677392833098 139.74698409608942 25.861 35.66675219865199 139.74697492941607 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d547600c-e0b2-4920-ab1a-a5d69c98e495">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d547600c-e0b2-4920-ab1a-a5d69c98e495_0">
											<gml:posList>35.66667894910684 139.74690664615375 22.678 35.66666010452686 139.7469738467012 25.861 35.66667894910684 139.74690664615375 25.861 35.66667894910684 139.74690664615375 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3041f413-7ce3-4270-a8e5-2d72d4a9e44c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3041f413-7ce3-4270-a8e5-2d72d4a9e44c_0">
											<gml:posList>35.66667894910684 139.74690664615375 22.678 35.66666010452686 139.7469738467012 22.678 35.66666010452686 139.7469738467012 25.861 35.66667894910684 139.74690664615375 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aecd9848-8abe-4c28-9572-7d5b706791e0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aecd9848-8abe-4c28-9572-7d5b706791e0_0">
											<gml:posList>35.66668027652718 139.74690999158543 22.678 35.666662825500886 139.74697220900012 25.861 35.666662825500886 139.74697220900012 22.678 35.66668027652718 139.74690999158543 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe9d5495-3b49-4799-9bc2-fce2c4464d62">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe9d5495-3b49-4799-9bc2-fce2c4464d62_0">
											<gml:posList>35.66668027652718 139.74690999158543 22.678 35.66668027652718 139.74690999158543 25.861 35.666662825500886 139.74697220900012 25.861 35.66668027652718 139.74690999158543 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b971ce97-fe00-4a1a-ada9-1f3a32e8f8e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b971ce97-fe00-4a1a-ada9-1f3a32e8f8e2_0">
											<gml:posList>35.66668284904567 139.74692757364804 24.337 35.66667258188825 139.74696455483422 24.337 35.66673074689418 139.74698880389812 24.337 35.66668284904567 139.74692757364804 24.337</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc6fa94e-d34a-4d60-9a47-5eec274470f6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dc6fa94e-d34a-4d60-9a47-5eec274470f6_0">
											<gml:posList>35.666741014050984 139.74695181164248 24.337 35.66668284904567 139.74692757364804 24.337 35.66673074689418 139.74698880389812 24.337 35.666741014050984 139.74695181164248 24.337</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-704c410d-c61e-4211-b1e1-cff6b190eec4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-704c410d-c61e-4211-b1e1-cff6b190eec4_0">
											<gml:posList>35.66676649875529 139.74701866627996 22.678 35.66666010452686 139.7469738467012 25.861 35.66666010452686 139.7469738467012 22.678 35.66676649875529 139.74701866627996 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5ee91647-bb48-4f80-9daf-732bc45e4ad7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5ee91647-bb48-4f80-9daf-732bc45e4ad7_0">
											<gml:posList>35.66676649875529 139.74701866627996 22.678 35.66676649875529 139.74701866627996 25.861 35.66666010452686 139.7469738467012 25.861 35.66676649875529 139.74701866627996 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80c7375b-f41a-43b2-806e-42ea572d0d79">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-80c7375b-f41a-43b2-806e-42ea572d0d79_0">
											<gml:posList>35.666662825500886 139.74697220900012 22.678 35.66676517133797 139.74701532084288 25.861 35.66676517133797 139.74701532084288 22.678 35.666662825500886 139.74697220900012 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7de41be7-9f7e-4114-a1e6-6b9e167b7fa3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7de41be7-9f7e-4114-a1e6-6b9e167b7fa3_0">
											<gml:posList>35.666662825500886 139.74697220900012 22.678 35.666662825500886 139.74697220900012 25.861 35.66676517133797 139.74701532084288 25.861 35.666662825500886 139.74697220900012 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9b93c716-66a3-438d-9524-a4b76b5e7e07">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9b93c716-66a3-438d-9524-a4b76b5e7e07_0">
											<gml:posList>35.66676649875529 139.74701866627996 25.861 35.66677665831881 139.74698245837666 25.861 35.66676517133797 139.74701532084288 25.861 35.66676649875529 139.74701866627996 25.861</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-abf30b1d-c3ee-4340-8deb-3803540e94d3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-abf30b1d-c3ee-4340-8deb-3803540e94d3_0">
											<gml:posList>35.66676649875529 139.74701866627996 25.861 35.66676517133797 139.74701532084288 25.861 35.66666010452686 139.7469738467012 25.861 35.66676649875529 139.74701866627996 25.861</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-705b7018-7bba-4ac6-86b5-d95f4776adb3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-705b7018-7bba-4ac6-86b5-d95f4776adb3_0">
											<gml:posList>35.66666010452686 139.7469738467012 25.861 35.666662825500886 139.74697220900012 25.861 35.66667894910684 139.74690664615375 25.861 35.66666010452686 139.7469738467012 25.861</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c0b3636-918d-4b3c-bbfa-5580c1e798a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c0b3636-918d-4b3c-bbfa-5580c1e798a6_0">
											<gml:posList>35.66676089271277 139.74694394773786 25.861 35.66675491963389 139.7469733027589 25.861 35.66676361368632 139.74694231003372 25.861 35.66676089271277 139.74694394773786 25.861</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-904b79b9-5f25-4016-a2e2-6e70a6f97183">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-904b79b9-5f25-4016-a2e2-6e70a6f97183_0">
											<gml:posList>35.66677665831881 139.74698245837666 25.861 35.66675491963389 139.7469733027589 25.861 35.66677392833098 139.74698409608942 25.861 35.66677665831881 139.74698245837666 25.861</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d50d8a06-51a7-476c-9074-d1f583bdcaa1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d50d8a06-51a7-476c-9074-d1f583bdcaa1_0">
											<gml:posList>35.66668027652718 139.74690999158543 25.861 35.66676361368632 139.74694231003372 25.861 35.66667894910684 139.74690664615375 25.861 35.66668027652718 139.74690999158543 25.861</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e95c18e-f3f0-4999-81db-99e7fa167c0e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4e95c18e-f3f0-4999-81db-99e7fa167c0e_0">
											<gml:posList>35.66677665831881 139.74698245837666 25.861 35.66677392833098 139.74698409608942 25.861 35.66676517133797 139.74701532084288 25.861 35.66677665831881 139.74698245837666 25.861</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11981ba0-ec0a-4f4e-a667-d550e0c9b5cb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-11981ba0-ec0a-4f4e-a667-d550e0c9b5cb_0">
											<gml:posList>35.66666010452686 139.7469738467012 25.861 35.66676517133797 139.74701532084288 25.861 35.666662825500886 139.74697220900012 25.861 35.66666010452686 139.7469738467012 25.861</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ee018a03-43f0-4681-8f14-7f9c3d07dfe4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ee018a03-43f0-4681-8f14-7f9c3d07dfe4_0">
											<gml:posList>35.666662825500886 139.74697220900012 25.861 35.66668027652718 139.74690999158543 25.861 35.66667894910684 139.74690664615375 25.861 35.666662825500886 139.74697220900012 25.861</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e3b4963-d7fb-467e-980c-cad500ba3cc3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e3b4963-d7fb-467e-980c-cad500ba3cc3_0">
											<gml:posList>35.66668027652718 139.74690999158543 25.861 35.66676089271277 139.74694394773786 25.861 35.66676361368632 139.74694231003372 25.861 35.66668027652718 139.74690999158543 25.861</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-17333990-4aa2-408f-ac85-339c292e39d5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-17333990-4aa2-408f-ac85-339c292e39d5_0">
											<gml:posList>35.66675219865199 139.74697492941607 25.861 35.66675491963389 139.7469733027589 25.861 35.66676089271277 139.74694394773786 25.861 35.66675219865199 139.74697492941607 25.861</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1adbf5a-1d34-446a-b5be-52db8d27dd2e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d1adbf5a-1d34-446a-b5be-52db8d27dd2e_0">
											<gml:posList>35.66677392833098 139.74698409608942 25.861 35.66675491963389 139.7469733027589 25.861 35.66675219865199 139.74697492941607 25.861 35.66677392833098 139.74698409608942 25.861</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df9ddf7e-aabb-4b10-af0d-48df2dce1867">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-df9ddf7e-aabb-4b10-af0d-48df2dce1867_0">
											<gml:posList>35.66676089271277 139.74694394773786 22.678 35.66668027652718 139.74690999158543 25.861 35.66668027652718 139.74690999158543 22.678 35.66676089271277 139.74694394773786 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f4be9b2e-13c2-43cb-8094-d6e798391900">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f4be9b2e-13c2-43cb-8094-d6e798391900_0">
											<gml:posList>35.66676089271277 139.74694394773786 22.678 35.66676089271277 139.74694394773786 25.861 35.66668027652718 139.74690999158543 25.861 35.66676089271277 139.74694394773786 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3bd73c0-a554-48a2-a5c9-ede54f46a49c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b3bd73c0-a554-48a2-a5c9-ede54f46a49c_0">
											<gml:posList>35.66676361368632 139.74694231003372 22.678 35.66667894910684 139.74690664615375 25.861 35.66676361368632 139.74694231003372 25.861 35.66676361368632 139.74694231003372 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48c29eb6-0f36-4796-ae86-25b21dbe4746">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-48c29eb6-0f36-4796-ae86-25b21dbe4746_0">
											<gml:posList>35.66676361368632 139.74694231003372 22.678 35.66667894910684 139.74690664615375 22.678 35.66667894910684 139.74690664615375 25.861 35.66676361368632 139.74694231003372 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f40b8642-1a1d-4b31-8ce7-e2e6ac28b64c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f40b8642-1a1d-4b31-8ce7-e2e6ac28b64c_0">
											<gml:posList>35.666741014050984 139.74695181164248 22.678 35.66673074689418 139.74698880389812 24.337 35.66673074689418 139.74698880389812 22.678 35.666741014050984 139.74695181164248 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-51b3b931-51b0-44c3-b6c2-e4917b9f37e9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-51b3b931-51b0-44c3-b6c2-e4917b9f37e9_0">
											<gml:posList>35.666741014050984 139.74695181164248 22.678 35.666741014050984 139.74695181164248 24.337 35.66673074689418 139.74698880389812 24.337 35.666741014050984 139.74695181164248 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ddf1f57-124d-49f2-bed1-c9ca1e23e228">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0ddf1f57-124d-49f2-bed1-c9ca1e23e228_0">
											<gml:posList>35.66674942494637 139.74695331585107 22.678 35.66673827742149 139.7469944622635 23.458 35.66674942494637 139.74695331585107 23.458 35.66674942494637 139.74695331585107 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c91bbcd-79d3-480a-80ec-0323c3efd568">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c91bbcd-79d3-480a-80ec-0323c3efd568_0">
											<gml:posList>35.66674942494637 139.74695331585107 22.678 35.66673827742149 139.7469944622635 22.678 35.66673827742149 139.7469944622635 23.458 35.66674942494637 139.74695331585107 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d24908b5-94ea-4f25-a26d-da99e34c09f7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d24908b5-94ea-4f25-a26d-da99e34c09f7_0">
											<gml:posList>35.66674562575746 139.74699744775234 23.458 35.666756782297064 139.74695630132683 23.458 35.66674942494637 139.74695331585107 23.458 35.66674562575746 139.74699744775234 23.458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-395ccd1d-7144-474b-8aea-3ff8dd77abcd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-395ccd1d-7144-474b-8aea-3ff8dd77abcd_0">
											<gml:posList>35.66673827742149 139.7469944622635 23.458 35.66674562575746 139.74699744775234 23.458 35.66674942494637 139.74695331585107 23.458 35.66673827742149 139.7469944622635 23.458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8de2ef39-376c-4c4f-9d07-e50acac003b6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8de2ef39-376c-4c4f-9d07-e50acac003b6_0">
											<gml:posList>35.6667522751815 139.7469936629431 22.678 35.66674930089449 139.7470065786389 23.233 35.6667522751815 139.7469936629431 23.233 35.6667522751815 139.7469936629431 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b17f26bd-dc2b-4c59-84b9-30eb2fb13871">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b17f26bd-dc2b-4c59-84b9-30eb2fb13871_0">
											<gml:posList>35.6667522751815 139.7469936629431 22.678 35.66674930089449 139.7470065786389 22.678 35.66674930089449 139.7470065786389 23.233 35.6667522751815 139.7469936629431 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4bfe03a8-6b92-4a26-b16f-17843b2570f3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4bfe03a8-6b92-4a26-b16f-17843b2570f3_0">
											<gml:posList>35.666756782297064 139.74695630132683 22.678 35.66674562575746 139.74699744775234 23.458 35.66674562575746 139.74699744775234 22.678 35.666756782297064 139.74695630132683 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-409a3279-90a9-4c97-a4b6-28d3f42fee5d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-409a3279-90a9-4c97-a4b6-28d3f42fee5d_0">
											<gml:posList>35.666756782297064 139.74695630132683 22.678 35.666756782297064 139.74695630132683 23.458 35.66674562575746 139.74699744775234 23.458 35.666756782297064 139.74695630132683 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-147bb841-fd44-411c-a297-c1af16b4f895">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-147bb841-fd44-411c-a297-c1af16b4f895_0">
											<gml:posList>35.666756782297064 139.74695630132683 22.678 35.66674942494637 139.74695331585107 23.458 35.666756782297064 139.74695630132683 23.458 35.666756782297064 139.74695630132683 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7fdc5a2d-8b64-4ca9-a030-2dd968b39f46">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7fdc5a2d-8b64-4ca9-a030-2dd968b39f46_0">
											<gml:posList>35.666756782297064 139.74695630132683 22.678 35.66674942494637 139.74695331585107 22.678 35.66674942494637 139.74695331585107 23.458 35.666756782297064 139.74695630132683 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1dcec65c-4c35-417d-ba58-292018d02c35">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1dcec65c-4c35-417d-ba58-292018d02c35_0">
											<gml:posList>35.66674930089449 139.7470065786389 23.233 35.666760038923044 139.74701030054618 23.233 35.66676302222418 139.74699738483912 23.233 35.66674930089449 139.7470065786389 23.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-880bd963-4419-4c34-867c-d4d45562d9f7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-880bd963-4419-4c34-867c-d4d45562d9f7_0">
											<gml:posList>35.6667522751815 139.7469936629431 23.233 35.66674930089449 139.7470065786389 23.233 35.66676302222418 139.74699738483912 23.233 35.6667522751815 139.7469936629431 23.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1927ad5-c3db-4f4c-8268-02c34bad6064">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a1927ad5-c3db-4f4c-8268-02c34bad6064_0">
											<gml:posList>35.66676089271277 139.74694394773786 22.678 35.66675219865199 139.74697492941607 25.861 35.66676089271277 139.74694394773786 25.861 35.66676089271277 139.74694394773786 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d121b500-ac47-413c-ad60-e452354a95d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d121b500-ac47-413c-ad60-e452354a95d7_0">
											<gml:posList>35.66676089271277 139.74694394773786 22.678 35.66675219865199 139.74697492941607 22.678 35.66675219865199 139.74697492941607 25.861 35.66676089271277 139.74694394773786 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40aa2620-b5e3-49d7-9a51-475c07d31fb4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40aa2620-b5e3-49d7-9a51-475c07d31fb4_0">
											<gml:posList>35.6667522751815 139.7469936629431 22.678 35.66676302222418 139.74699738483912 23.233 35.66676302222418 139.74699738483912 22.678 35.6667522751815 139.7469936629431 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cdd40b46-bcd9-4f78-b77d-c2388404ddea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cdd40b46-bcd9-4f78-b77d-c2388404ddea_0">
											<gml:posList>35.6667522751815 139.7469936629431 22.678 35.6667522751815 139.7469936629431 23.233 35.66676302222418 139.74699738483912 23.233 35.6667522751815 139.7469936629431 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ea06691-8337-465f-a4cb-5829ad2cdaa4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2ea06691-8337-465f-a4cb-5829ad2cdaa4_0">
											<gml:posList>35.66675491963389 139.7469733027589 22.678 35.66676361368632 139.74694231003372 25.861 35.66675491963389 139.7469733027589 25.861 35.66675491963389 139.7469733027589 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a47117e-19d9-49cf-9994-449ce05540c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7a47117e-19d9-49cf-9994-449ce05540c6_0">
											<gml:posList>35.66675491963389 139.7469733027589 22.678 35.66676361368632 139.74694231003372 22.678 35.66676361368632 139.74694231003372 25.861 35.66675491963389 139.7469733027589 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2371029e-99a3-4211-ba3c-50d5904be389">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2371029e-99a3-4211-ba3c-50d5904be389_0">
											<gml:posList>35.66677665831881 139.74698245837666 22.678 35.66675491963389 139.7469733027589 25.861 35.66677665831881 139.74698245837666 25.861 35.66677665831881 139.74698245837666 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fbe85e5a-d1dd-49d0-8439-8bcfaba7e945">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fbe85e5a-d1dd-49d0-8439-8bcfaba7e945_0">
											<gml:posList>35.66677665831881 139.74698245837666 22.678 35.66675491963389 139.7469733027589 22.678 35.66675491963389 139.7469733027589 25.861 35.66677665831881 139.74698245837666 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f5807fb-e07f-4242-8858-3a4fea899351">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f5807fb-e07f-4242-8858-3a4fea899351_0">
											<gml:posList>35.66677392833098 139.74698409608942 22.678 35.66676517133797 139.74701532084288 25.861 35.66677392833098 139.74698409608942 25.861 35.66677392833098 139.74698409608942 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6cc0c1b6-5697-450a-a418-7bcd16b0c691">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6cc0c1b6-5697-450a-a418-7bcd16b0c691_0">
											<gml:posList>35.66677392833098 139.74698409608942 22.678 35.66676517133797 139.74701532084288 22.678 35.66676517133797 139.74701532084288 25.861 35.66677392833098 139.74698409608942 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b6e3d7aa-b754-44a7-9f20-9558130ae2c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b6e3d7aa-b754-44a7-9f20-9558130ae2c9_0">
											<gml:posList>35.66677665831881 139.74698245837666 22.678 35.66676649875529 139.74701866627996 25.861 35.66676649875529 139.74701866627996 22.678 35.66677665831881 139.74698245837666 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57844364-7b5f-4c5e-a9c8-09c537e1d0d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-57844364-7b5f-4c5e-a9c8-09c537e1d0d6_0">
											<gml:posList>35.66677665831881 139.74698245837666 22.678 35.66677665831881 139.74698245837666 25.861 35.66676649875529 139.74701866627996 25.861 35.66677665831881 139.74698245837666 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d867492b-caa3-40b6-8ffb-dea221d00d65">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d867492b-caa3-40b6-8ffb-dea221d00d65_0">
											<gml:posList>35.666786561199665 139.74702826554605 22.678 35.66678621053503 139.7470294809576 22.678 35.666786561199665 139.74702826554605 24.096 35.666786561199665 139.74702826554605 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-112ac687-c4e9-436f-a802-2b146d934338">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-112ac687-c4e9-436f-a802-2b146d934338_0">
											<gml:posList>35.666786561199665 139.74702826554605 24.096 35.66678621053503 139.7470294809576 22.678 35.66678329734562 139.74703961305906 24.096 35.666786561199665 139.74702826554605 24.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38f1ebb5-ddc8-48bc-bb18-dbf3cae681e1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-38f1ebb5-ddc8-48bc-bb18-dbf3cae681e1_0">
											<gml:posList>35.66678329734562 139.74703961305906 24.096 35.66678621053503 139.7470294809576 22.678 35.66678329734562 139.74703961305906 21.568 35.66678329734562 139.74703961305906 24.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-85e8c5a2-f560-4faf-a331-fa18fc347225">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-85e8c5a2-f560-4faf-a331-fa18fc347225_0">
											<gml:posList>35.66678621053503 139.7470294809576 22.678 35.66678621053503 139.7470294809576 21.568 35.66678329734562 139.74703961305906 21.568 35.66678621053503 139.7470294809576 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4d48ffd-b3a9-47ed-9a7d-ff6b68ed9b7e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4d48ffd-b3a9-47ed-9a7d-ff6b68ed9b7e_0">
											<gml:posList>35.66678329734562 139.74703961305906 21.568 35.66679521719275 139.7470447586045 24.096 35.66678329734562 139.74703961305906 24.096 35.66678329734562 139.74703961305906 21.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fad4c591-b351-4d65-a7a3-06b9df874f45">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fad4c591-b351-4d65-a7a3-06b9df874f45_0">
											<gml:posList>35.66678329734562 139.74703961305906 21.568 35.66679521719275 139.7470447586045 21.568 35.66679521719275 139.7470447586045 24.096 35.66678329734562 139.74703961305906 21.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eea8930b-2f5e-4f8c-96bc-6beef4125246">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eea8930b-2f5e-4f8c-96bc-6beef4125246_0">
											<gml:posList>35.66679521719275 139.7470447586045 24.096 35.666786561199665 139.74702826554605 24.096 35.66678329734562 139.74703961305906 24.096 35.66679521719275 139.7470447586045 24.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-861bb07f-6e3a-4204-b7b1-87a023a013c0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-861bb07f-6e3a-4204-b7b1-87a023a013c0_0">
											<gml:posList>35.66679521719275 139.7470447586045 24.096 35.66679848104728 139.74703341108994 24.096 35.666786561199665 139.74702826554605 24.096 35.66679521719275 139.7470447586045 24.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d3f8e76-c605-491c-9bbe-663b3d1ec9ac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d3f8e76-c605-491c-9bbe-663b3d1ec9ac_0">
											<gml:posList>35.66678621053503 139.7470294809576 22.678 35.66679813037467 139.74703461545593 21.568 35.66678621053503 139.7470294809576 21.568 35.66678621053503 139.7470294809576 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-20a85a19-e5fa-4545-afca-c311063f5109">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-20a85a19-e5fa-4545-afca-c311063f5109_0">
											<gml:posList>35.66678621053503 139.7470294809576 22.678 35.66679813037467 139.74703461545593 22.678 35.66679813037467 139.74703461545593 21.568 35.66678621053503 139.7470294809576 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d484beb-52f8-454a-a4c3-0cc790fffadc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5d484beb-52f8-454a-a4c3-0cc790fffadc_0">
											<gml:posList>35.66679848104728 139.74703341108994 22.678 35.666786561199665 139.74702826554605 24.096 35.66679848104728 139.74703341108994 24.096 35.66679848104728 139.74703341108994 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-912e05a5-ba28-467b-950e-04bbf37992c4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-912e05a5-ba28-467b-950e-04bbf37992c4_0">
											<gml:posList>35.66679848104728 139.74703341108994 22.678 35.666786561199665 139.74702826554605 22.678 35.666786561199665 139.74702826554605 24.096 35.66679848104728 139.74703341108994 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2910be3-ad79-41e6-ba98-a95158cff59b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a2910be3-ad79-41e6-ba98-a95158cff59b_0">
											<gml:posList>35.66679848104728 139.74703341108994 22.678 35.66679848104728 139.74703341108994 24.096 35.66679813037467 139.74703461545593 22.678 35.66679848104728 139.74703341108994 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81be6a28-67f1-42c5-920c-014727f3b582">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81be6a28-67f1-42c5-920c-014727f3b582_0">
											<gml:posList>35.66679813037467 139.74703461545593 21.568 35.66679813037467 139.74703461545593 22.678 35.66679521719275 139.7470447586045 21.568 35.66679813037467 139.74703461545593 21.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-001989fd-e464-4e79-9064-ce712ddaf1a7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-001989fd-e464-4e79-9064-ce712ddaf1a7_0">
											<gml:posList>35.66679521719275 139.7470447586045 21.568 35.66679813037467 139.74703461545593 22.678 35.66679521719275 139.7470447586045 24.096 35.66679521719275 139.7470447586045 21.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f7faf41-304f-44fe-a368-56de6b8cc52f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f7faf41-304f-44fe-a368-56de6b8cc52f_0">
											<gml:posList>35.66679813037467 139.74703461545593 22.678 35.66679848104728 139.74703341108994 24.096 35.66679521719275 139.7470447586045 24.096 35.66679813037467 139.74703461545593 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-92ab7cb3-dbf4-4a9f-964f-1ea28853b19f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66673074689418 139.74698880389812 22.678 35.66667258188825 139.74696455483422 22.678 35.66668284904567 139.74692757364804 22.678 35.66673074689418 139.74698880389812 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1176ce63-4b7e-41fa-9d0a-dae0e156392f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666741014050984 139.74695181164248 22.678 35.66673074689418 139.74698880389812 22.678 35.66668284904567 139.74692757364804 22.678 35.666741014050984 139.74695181164248 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5ec13c89-4060-4268-a592-5946ce1fc1c2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66676517133797 139.74701532084288 22.678 35.66677665831881 139.74698245837666 22.678 35.66676649875529 139.74701866627996 22.678 35.66676517133797 139.74701532084288 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-30aca536-ea00-46fa-9ba0-d1b9173c3e3f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66666010452686 139.7469738467012 22.678 35.66676517133797 139.74701532084288 22.678 35.66676649875529 139.74701866627996 22.678 35.66666010452686 139.7469738467012 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7954d41e-c251-4fca-b621-fbbc742dd607">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66676361368632 139.74694231003372 22.678 35.66668027652718 139.74690999158543 22.678 35.66667894910684 139.74690664615375 22.678 35.66676361368632 139.74694231003372 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db83c3b5-797e-4490-8bd2-389f1ab8bd63">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66677392833098 139.74698409608942 22.678 35.66675491963389 139.7469733027589 22.678 35.66677665831881 139.74698245837666 22.678 35.66677392833098 139.74698409608942 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6032f516-2bf4-4d73-a3ae-5f17789724bb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66676089271277 139.74694394773786 22.678 35.66676361368632 139.74694231003372 22.678 35.66675491963389 139.7469733027589 22.678 35.66676089271277 139.74694394773786 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-96bc0d36-29fd-458d-a1fb-981dbefdc4de">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66667894910684 139.74690664615375 22.678 35.66668027652718 139.74690999158543 22.678 35.66666010452686 139.7469738467012 22.678 35.66667894910684 139.74690664615375 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ded33f80-c609-42fc-b51d-d12c54a8f9af">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66676517133797 139.74701532084288 22.678 35.66677392833098 139.74698409608942 22.678 35.66677665831881 139.74698245837666 22.678 35.66676517133797 139.74701532084288 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b667e20-79ea-4336-9e74-9b42a07c8490">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66666010452686 139.7469738467012 22.678 35.666662825500886 139.74697220900012 22.678 35.66676517133797 139.74701532084288 22.678 35.66666010452686 139.7469738467012 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b7efb46-b222-4dad-8be5-ad9c973fc6d9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66676089271277 139.74694394773786 22.678 35.66668027652718 139.74690999158543 22.678 35.66676361368632 139.74694231003372 22.678 35.66676089271277 139.74694394773786 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c48f31a1-b740-4f81-85ec-7c7cfba9ec9a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66675219865199 139.74697492941607 22.678 35.66675491963389 139.7469733027589 22.678 35.66677392833098 139.74698409608942 22.678 35.66675219865199 139.74697492941607 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f3b06340-e858-4543-9dbb-4ba95389462b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66675219865199 139.74697492941607 22.678 35.66676089271277 139.74694394773786 22.678 35.66675491963389 139.7469733027589 22.678 35.66675219865199 139.74697492941607 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fd322177-8c83-46db-b71e-ebde26d6f3f9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66668027652718 139.74690999158543 22.678 35.666662825500886 139.74697220900012 22.678 35.66666010452686 139.7469738467012 22.678 35.66668027652718 139.74690999158543 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f728ad5-63f1-47c0-a69e-c785cb847bcc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66674942494637 139.74695331585107 22.678 35.666756782297064 139.74695630132683 22.678 35.66674562575746 139.74699744775234 22.678 35.66674942494637 139.74695331585107 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf974579-fdc8-4095-9785-27cfeb058418">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66673827742149 139.7469944622635 22.678 35.66674942494637 139.74695331585107 22.678 35.66674562575746 139.74699744775234 22.678 35.66673827742149 139.7469944622635 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-093895d1-b282-42e4-b0ea-26de8181c376">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66674930089449 139.7470065786389 22.678 35.6667522751815 139.7469936629431 22.678 35.66676302222418 139.74699738483912 22.678 35.66674930089449 139.7470065786389 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a19cb9c-3f76-4e2c-8600-4c86473e46d0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666760038923044 139.74701030054618 22.678 35.66674930089449 139.7470065786389 22.678 35.66676302222418 139.74699738483912 22.678 35.666760038923044 139.74701030054618 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-69b5259b-508f-4074-bf56-76c1c0cf0411">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66678621053503 139.7470294809576 21.568 35.66679521719275 139.7470447586045 21.568 35.66678329734562 139.74703961305906 21.568 35.66678621053503 139.7470294809576 21.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0732f7a7-9085-45f3-9bba-8090e04aee54">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66678621053503 139.7470294809576 21.568 35.66679813037467 139.74703461545593 21.568 35.66679521719275 139.7470447586045 21.568 35.66678621053503 139.7470294809576 21.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec71a8c8-2ccc-4409-a16a-b88e8789d444">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666786561199665 139.74702826554605 22.678 35.66679813037467 139.74703461545593 22.678 35.66678621053503 139.7470294809576 22.678 35.666786561199665 139.74702826554605 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d0fbe54-1f93-4681-96cc-9491bcd1cc91">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666786561199665 139.74702826554605 22.678 35.66679848104728 139.74703341108994 22.678 35.66679813037467 139.74703461545593 22.678 35.666786561199665 139.74702826554605 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_453a3b19-5ac4-499c-a065-23a8f4008473_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e9f5f74-850a-4247-89e3-2154e4217830">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66676754059771 139.74693802004722 22.678 35.66680149684293 139.74695267433273 22.678 35.666793062974186 139.7469819767891 22.678 35.66675911573035 139.7469673003915 22.678 35.66676754059771 139.74693802004722 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc1fa4e9-33a3-40f0-8872-dab1e53167e0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dc1fa4e9-33a3-40f0-8872-dab1e53167e0_0">
											<gml:posList>35.66676754059771 139.74693802004722 22.678 35.66675911573035 139.7469673003915 22.678 35.66675911573035 139.7469673003915 23.091 35.66676754059771 139.74693802004722 23.091 35.66676754059771 139.74693802004722 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1764bd83-6491-4c30-bee4-86e4258946a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1764bd83-6491-4c30-bee4-86e4258946a8_0">
											<gml:posList>35.66675911573035 139.7469673003915 22.678 35.666793062974186 139.7469819767891 22.678 35.666793062974186 139.7469819767891 23.091 35.66675911573035 139.7469673003915 23.091 35.66675911573035 139.7469673003915 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4017b8e1-6086-4c55-87fb-ffa8369f6e63">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4017b8e1-6086-4c55-87fb-ffa8369f6e63_0">
											<gml:posList>35.66676754059771 139.74693802004722 23.091 35.66675911573035 139.7469673003915 23.091 35.666793062974186 139.7469819767891 23.091 35.66680149684293 139.74695267433273 23.091 35.66676754059771 139.74693802004722 23.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81b093b6-a06a-4fc4-b26c-aa44b07debc4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81b093b6-a06a-4fc4-b26c-aa44b07debc4_0">
											<gml:posList>35.66680149684293 139.74695267433273 22.678 35.66676754059771 139.74693802004722 22.678 35.66676754059771 139.74693802004722 23.091 35.66680149684293 139.74695267433273 23.091 35.66680149684293 139.74695267433273 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2e7d6b28-4955-46d5-9c4c-3b4ab9742952">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2e7d6b28-4955-46d5-9c4c-3b4ab9742952_0">
											<gml:posList>35.666793062974186 139.7469819767891 23.091 35.666793062974186 139.7469819767891 22.678 35.66680149684293 139.74695267433273 22.678 35.66680149684293 139.74695267433273 23.091 35.666793062974186 139.7469819767891 23.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-a1722609-3269-4d3b-b155-a3ead8cf66bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a1722609-3269-4d3b-b155-a3ead8cf66bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a1722609-3269-4d3b-b155-a3ead8cf66bb">
											<gml:posList>35.66659259838945 139.7471846168604 6.237 35.666674940850626 139.74689806792634 6.237 35.66680149684293 139.74695267433273 6.237 35.666802881502534 139.7469478568866 6.237 35.66683883039859 139.74696337060666 6.237 35.66684988466147 139.7469681415202 6.237 35.66682797284893 139.74704439198374 6.237 35.666928714474835 139.7470878702433 6.237 35.6668811412589 139.7472534313488 6.237 35.666800362266834 139.74721856925643 6.237 35.66683060017802 139.74711335895122 6.237 35.66672922740871 139.74706961629337 6.237 35.666684756236094 139.7472243819682 6.237 35.66659259838945 139.7471846168604 6.237</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6255ad61-21d6-420e-8451-fd29ada8bcc2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6255ad61-21d6-420e-8451-fd29ada8bcc2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6255ad61-21d6-420e-8451-fd29ada8bcc2">
											<gml:posList>35.66659259838945 139.7471846168604 22.678 35.666598617032335 139.7471810757579 22.678 35.66665806766155 139.74697418026722 22.678 35.66665518698197 139.7469667937649 22.678 35.66659259838945 139.7471846168604 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3ea59a49-c643-4cee-b447-795894c25baf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ea59a49-c643-4cee-b447-795894c25baf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ea59a49-c643-4cee-b447-795894c25baf">
											<gml:posList>35.666684756236094 139.7472243819682 22.678 35.66668187557187 139.7472169954544 22.678 35.666598617032335 139.7471810757579 22.678 35.66659259838945 139.7471846168604 22.678 35.666684756236094 139.7472243819682 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-30536dfa-e0d8-490a-8011-032790e36667">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-30536dfa-e0d8-490a-8011-032790e36667">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-30536dfa-e0d8-490a-8011-032790e36667">
											<gml:posList>35.66665806766155 139.74697418026722 21.568 35.666598617032335 139.7471810757579 21.568 35.66668187557187 139.7472169954544 21.568 35.66672634674291 139.7470622408268 21.568 35.66679668464658 139.74709259623975 21.568 35.66680474085982 139.7470645423717 21.568 35.66681166417829 139.7470404551481 21.568 35.66665806766155 139.74697418026722 21.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-42bbc397-bccc-40c2-b99d-5296803e9bf4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-42bbc397-bccc-40c2-b99d-5296803e9bf4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-42bbc397-bccc-40c2-b99d-5296803e9bf4">
											<gml:posList>35.66672922740871 139.74706961629337 22.678 35.66672634674291 139.7470622408268 22.678 35.66668187557187 139.7472169954544 22.678 35.666684756236094 139.7472243819682 22.678 35.66672922740871 139.74706961629337 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-841798e8-0de4-4c05-87d0-69820cf68ce6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-841798e8-0de4-4c05-87d0-69820cf68ce6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-841798e8-0de4-4c05-87d0-69820cf68ce6">
											<gml:posList>35.666674940850626 139.74689806792634 22.678 35.66665518698197 139.7469667937649 22.678 35.66678174295159 139.74702141131218 22.678 35.66680149684293 139.74695267433273 22.678 35.666674940850626 139.74689806792634 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-41c65e74-f11b-4c67-b966-cc1c49f93a21">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41c65e74-f11b-4c67-b966-cc1c49f93a21">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41c65e74-f11b-4c67-b966-cc1c49f93a21">
											<gml:posList>35.66665806766155 139.74697418026722 22.678 35.66681166417829 139.7470404551481 22.678 35.66681769183834 139.7470369250611 22.678 35.66678174295159 139.74702141131218 22.678 35.66665518698197 139.7469667937649 22.678 35.66665806766155 139.74697418026722 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1e968506-3a38-4a35-b6ca-40e59ac02e90">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e968506-3a38-4a35-b6ca-40e59ac02e90">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e968506-3a38-4a35-b6ca-40e59ac02e90">
											<gml:posList>35.66672922740871 139.74706961629337 22.678 35.66683060017802 139.74711335895122 22.678 35.666836609812734 139.7471098288883 22.678 35.66680596265388 139.74709660692088 22.678 35.66679668464658 139.74709259623975 22.678 35.66672634674291 139.7470622408268 22.678 35.66672922740871 139.74706961629337 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-725db44e-0949-45b0-ad9c-4e04c2d5e175">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-725db44e-0949-45b0-ad9c-4e04c2d5e175">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-725db44e-0949-45b0-ad9c-4e04c2d5e175">
											<gml:posList>35.66680149684293 139.74695267433273 23.215 35.66678174295159 139.74702141131218 24.177 35.66681769183834 139.7470369250611 24.177 35.66680149684293 139.74695267433273 23.215</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-01b7a6cd-0063-44b6-8825-1ae1e4d3941d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-01b7a6cd-0063-44b6-8825-1ae1e4d3941d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-01b7a6cd-0063-44b6-8825-1ae1e4d3941d">
											<gml:posList>35.66680474085982 139.7470645423717 22.678 35.66679668464658 139.74709259623975 22.678 35.66680596265388 139.74709660692088 22.678 35.666814027881756 139.7470685530403 22.678 35.66680474085982 139.7470645423717 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-905bfa99-fff8-4eb2-b8c2-841188c7d604">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-905bfa99-fff8-4eb2-b8c2-841188c7d604">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-905bfa99-fff8-4eb2-b8c2-841188c7d604">
											<gml:posList>35.666810768520584 139.74706101228685 22.678 35.66681769183834 139.7470369250611 22.678 35.66681166417829 139.7470404551481 22.678 35.66680474085982 139.7470645423717 22.678 35.666810768520584 139.74706101228685 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c8fc12c5-5836-4d3b-b99c-0947b4e312fb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8fc12c5-5836-4d3b-b99c-0947b4e312fb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8fc12c5-5836-4d3b-b99c-0947b4e312fb">
											<gml:posList>35.66683060017802 139.74711335895122 22.678 35.666800362266834 139.74721856925643 22.678 35.666806371896776 139.74721502815694 22.678 35.666836609812734 139.7471098288883 22.678 35.66683060017802 139.74711335895122 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-89710eaa-2573-4c1d-8f40-d890b8fc92da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-89710eaa-2573-4c1d-8f40-d890b8fc92da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-89710eaa-2573-4c1d-8f40-d890b8fc92da">
											<gml:posList>35.66683883039859 139.74696337060666 23.215 35.66680149684293 139.74695267433273 23.215 35.66681769183834 139.7470369250611 24.177 35.66683883039859 139.74696337060666 23.215</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f4840401-640e-48d9-ba6e-d90cb2137b71">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4840401-640e-48d9-ba6e-d90cb2137b71">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4840401-640e-48d9-ba6e-d90cb2137b71">
											<gml:posList>35.66683883039859 139.74696337060666 23.215 35.666802881502534 139.7469478568866 23.215 35.66680149684293 139.74695267433273 23.215 35.66683883039859 139.74696337060666 23.215</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d3571e12-fa82-4449-8f16-2454a22e2b7a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3571e12-fa82-4449-8f16-2454a22e2b7a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3571e12-fa82-4449-8f16-2454a22e2b7a">
											<gml:posList>35.6668811412589 139.7472534313488 22.678 35.66687825158278 139.74724604482554 22.678 35.666806371896776 139.74721502815694 22.678 35.666800362266834 139.74721856925643 22.678 35.6668811412589 139.7472534313488 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9491a3cb-1800-44c1-8769-ab21ec5f795a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9491a3cb-1800-44c1-8769-ab21ec5f795a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9491a3cb-1800-44c1-8769-ab21ec5f795a">
											<gml:posList>35.666836609812734 139.7471098288883 21.568 35.666806371896776 139.74721502815694 21.568 35.66687825158278 139.74724604482554 21.568 35.666916545749636 139.7471127915718 21.568 35.666814027881756 139.7470685530403 21.568 35.66680596265388 139.74709660692088 21.568 35.666836609812734 139.7471098288883 21.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6265d6c8-5ace-40b4-a540-ca7965b18751">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6265d6c8-5ace-40b4-a540-ca7965b18751">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6265d6c8-5ace-40b4-a540-ca7965b18751">
											<gml:posList>35.666810768520584 139.74706101228685 22.678 35.66680474085982 139.7470645423717 22.678 35.666814027881756 139.7470685530403 22.678 35.666916545749636 139.7471127915718 22.678 35.66692257341171 139.7471092614856 22.678 35.666810768520584 139.74706101228685 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b496ef56-fb7d-489c-a834-1c7268bc984c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b496ef56-fb7d-489c-a834-1c7268bc984c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b496ef56-fb7d-489c-a834-1c7268bc984c">
											<gml:posList>35.666810768520584 139.74706101228685 16.178 35.66692257341171 139.7471092614856 16.178 35.666928714474835 139.7470878702433 16.178 35.66682797284893 139.74704439198374 16.178 35.66684988466147 139.7469681415202 16.178 35.66683883039859 139.74696337060666 16.178 35.666810768520584 139.74706101228685 16.178</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b4bc32c2-c33c-4b24-9a8e-95f1c1333d24">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b4bc32c2-c33c-4b24-9a8e-95f1c1333d24">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b4bc32c2-c33c-4b24-9a8e-95f1c1333d24">
											<gml:posList>35.66692257341171 139.7471092614856 22.678 35.666916545749636 139.7471127915718 22.678 35.66687825158278 139.74724604482554 22.678 35.6668811412589 139.7472534313488 22.678 35.66692257341171 139.7471092614856 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6dd73dd1-953f-4be1-994e-baf058cbbaa8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6dd73dd1-953f-4be1-994e-baf058cbbaa8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6dd73dd1-953f-4be1-994e-baf058cbbaa8">
											<gml:posList>35.666836609812734 139.7471098288883 22.678 35.666836609812734 139.7471098288883 21.568 35.66680596265388 139.74709660692088 21.568 35.66680596265388 139.74709660692088 22.678 35.666836609812734 139.7471098288883 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b60149f7-a5e8-450f-a2f6-f69ec6954c53">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b60149f7-a5e8-450f-a2f6-f69ec6954c53">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b60149f7-a5e8-450f-a2f6-f69ec6954c53">
											<gml:posList>35.666598617032335 139.7471810757579 22.678 35.666598617032335 139.7471810757579 21.568 35.66665806766155 139.74697418026722 21.568 35.66665806766155 139.74697418026722 22.678 35.666598617032335 139.7471810757579 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-25bfdd55-b96f-45f5-a7c8-38348df1b84f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25bfdd55-b96f-45f5-a7c8-38348df1b84f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25bfdd55-b96f-45f5-a7c8-38348df1b84f">
											<gml:posList>35.666674940850626 139.74689806792634 6.237 35.66659259838945 139.7471846168604 6.237 35.66659259838945 139.7471846168604 22.678 35.66665518698197 139.7469667937649 22.678 35.666674940850626 139.74689806792634 22.678 35.666674940850626 139.74689806792634 6.237</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-76331f3a-7c68-4543-97dd-b5eb83847a61">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-76331f3a-7c68-4543-97dd-b5eb83847a61">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-76331f3a-7c68-4543-97dd-b5eb83847a61">
											<gml:posList>35.66659259838945 139.7471846168604 6.237 35.666684756236094 139.7472243819682 6.237 35.666684756236094 139.7472243819682 22.678 35.66659259838945 139.7471846168604 22.678 35.66659259838945 139.7471846168604 6.237</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cfc82692-13f5-41d9-b039-815754162ca2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cfc82692-13f5-41d9-b039-815754162ca2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cfc82692-13f5-41d9-b039-815754162ca2">
											<gml:posList>35.66668187557187 139.7472169954544 22.678 35.66668187557187 139.7472169954544 21.568 35.666598617032335 139.7471810757579 21.568 35.666598617032335 139.7471810757579 22.678 35.66668187557187 139.7472169954544 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aed468fe-f230-4929-bc8a-6b7aa555d065">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aed468fe-f230-4929-bc8a-6b7aa555d065">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aed468fe-f230-4929-bc8a-6b7aa555d065">
											<gml:posList>35.66672634674291 139.7470622408268 22.678 35.66672634674291 139.7470622408268 21.568 35.66668187557187 139.7472169954544 21.568 35.66668187557187 139.7472169954544 22.678 35.66672634674291 139.7470622408268 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-54cfd540-1368-4eb6-9404-bd629f936ea3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-54cfd540-1368-4eb6-9404-bd629f936ea3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-54cfd540-1368-4eb6-9404-bd629f936ea3">
											<gml:posList>35.666684756236094 139.7472243819682 6.237 35.66672922740871 139.74706961629337 6.237 35.66672922740871 139.74706961629337 22.678 35.666684756236094 139.7472243819682 22.678 35.666684756236094 139.7472243819682 6.237</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0a86bff6-100d-47a4-b1bc-a9ab232cb5ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a86bff6-100d-47a4-b1bc-a9ab232cb5ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a86bff6-100d-47a4-b1bc-a9ab232cb5ff">
											<gml:posList>35.66665806766155 139.74697418026722 22.678 35.66665806766155 139.74697418026722 21.568 35.66681166417829 139.7470404551481 21.568 35.66681166417829 139.7470404551481 22.678 35.66665806766155 139.74697418026722 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-daede928-2fdd-46c6-b49b-c5af30e8b7b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-daede928-2fdd-46c6-b49b-c5af30e8b7b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-daede928-2fdd-46c6-b49b-c5af30e8b7b9">
											<gml:posList>35.666674940850626 139.74689806792634 22.678 35.66680149684293 139.74695267433273 22.678 35.66680149684293 139.74695267433273 6.237 35.666674940850626 139.74689806792634 6.237 35.666674940850626 139.74689806792634 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6b59667f-ffc2-43f3-9e12-eb940c389537">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b59667f-ffc2-43f3-9e12-eb940c389537">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b59667f-ffc2-43f3-9e12-eb940c389537">
											<gml:posList>35.66679668464658 139.74709259623975 22.678 35.66679668464658 139.74709259623975 21.568 35.66672634674291 139.7470622408268 21.568 35.66672634674291 139.7470622408268 22.678 35.66679668464658 139.74709259623975 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e4d98e9e-f4a8-42b2-9967-b4d672fe9fa3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e4d98e9e-f4a8-42b2-9967-b4d672fe9fa3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e4d98e9e-f4a8-42b2-9967-b4d672fe9fa3">
											<gml:posList>35.66672922740871 139.74706961629337 6.237 35.66683060017802 139.74711335895122 6.237 35.66683060017802 139.74711335895122 22.678 35.66672922740871 139.74706961629337 22.678 35.66672922740871 139.74706961629337 6.237</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-99945a74-8a46-4dd6-b179-c05708a7213e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-99945a74-8a46-4dd6-b179-c05708a7213e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-99945a74-8a46-4dd6-b179-c05708a7213e">
											<gml:posList>35.66678174295159 139.74702141131218 22.678 35.66678174295159 139.74702141131218 24.177 35.66680149684293 139.74695267433273 23.215 35.66680149684293 139.74695267433273 22.678 35.66678174295159 139.74702141131218 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6ef14242-3064-4a69-a450-6d923d5553ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ef14242-3064-4a69-a450-6d923d5553ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ef14242-3064-4a69-a450-6d923d5553ba">
											<gml:posList>35.66681769183834 139.7470369250611 22.678 35.66681769183834 139.7470369250611 24.177 35.66678174295159 139.74702141131218 24.177 35.66678174295159 139.74702141131218 22.678 35.66681769183834 139.7470369250611 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ebf0179b-4370-4944-8f8f-1fc9bac46c61">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ebf0179b-4370-4944-8f8f-1fc9bac46c61">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ebf0179b-4370-4944-8f8f-1fc9bac46c61">
											<gml:posList>35.66680474085982 139.7470645423717 22.678 35.66680474085982 139.7470645423717 21.568 35.66679668464658 139.74709259623975 21.568 35.66679668464658 139.74709259623975 22.678 35.66680474085982 139.7470645423717 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-21d73d7c-e608-4a26-958d-a06683148bee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21d73d7c-e608-4a26-958d-a06683148bee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21d73d7c-e608-4a26-958d-a06683148bee">
											<gml:posList>35.666802881502534 139.7469478568866 23.215 35.666802881502534 139.7469478568866 6.237 35.66680149684293 139.74695267433273 6.237 35.66680149684293 139.74695267433273 22.678 35.66680149684293 139.74695267433273 23.215 35.666802881502534 139.7469478568866 23.215</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d9d22846-1dda-432c-8b7d-e151e89f330a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d9d22846-1dda-432c-8b7d-e151e89f330a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d9d22846-1dda-432c-8b7d-e151e89f330a">
											<gml:posList>35.66681166417829 139.7470404551481 22.678 35.66681166417829 139.7470404551481 21.568 35.66680474085982 139.7470645423717 21.568 35.66680474085982 139.7470645423717 22.678 35.66681166417829 139.7470404551481 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-164c9f28-af5e-4d7c-9e76-43cc5b6d5f2b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-164c9f28-af5e-4d7c-9e76-43cc5b6d5f2b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-164c9f28-af5e-4d7c-9e76-43cc5b6d5f2b">
											<gml:posList>35.66680596265388 139.74709660692088 22.678 35.66680596265388 139.74709660692088 21.568 35.666814027881756 139.7470685530403 21.568 35.666814027881756 139.7470685530403 22.678 35.66680596265388 139.74709660692088 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-487ee97b-f968-4194-b450-d67a9ef093ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-487ee97b-f968-4194-b450-d67a9ef093ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-487ee97b-f968-4194-b450-d67a9ef093ee">
											<gml:posList>35.66683060017802 139.74711335895122 6.237 35.666800362266834 139.74721856925643 6.237 35.666800362266834 139.74721856925643 22.678 35.66683060017802 139.74711335895122 22.678 35.66683060017802 139.74711335895122 6.237</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d33b15ab-6267-472d-99e9-09d45029a9bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d33b15ab-6267-472d-99e9-09d45029a9bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d33b15ab-6267-472d-99e9-09d45029a9bf">
											<gml:posList>35.666802881502534 139.7469478568866 6.237 35.666802881502534 139.7469478568866 23.215 35.66683883039859 139.74696337060666 23.215 35.66683883039859 139.74696337060666 16.178 35.66683883039859 139.74696337060666 6.237 35.666802881502534 139.7469478568866 6.237</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0a49f6f3-2004-427d-9a2a-07d2f6331320">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a49f6f3-2004-427d-9a2a-07d2f6331320">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a49f6f3-2004-427d-9a2a-07d2f6331320">
											<gml:posList>35.666806371896776 139.74721502815694 22.678 35.666806371896776 139.74721502815694 21.568 35.666836609812734 139.7471098288883 21.568 35.666836609812734 139.7471098288883 22.678 35.666806371896776 139.74721502815694 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c6dd6e84-aee9-4721-b407-f1535de4f7ed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6dd6e84-aee9-4721-b407-f1535de4f7ed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6dd6e84-aee9-4721-b407-f1535de4f7ed">
											<gml:posList>35.66681769183834 139.7470369250611 22.678 35.666810768520584 139.74706101228685 22.678 35.666810768520584 139.74706101228685 16.178 35.66683883039859 139.74696337060666 16.178 35.66683883039859 139.74696337060666 23.215 35.66681769183834 139.7470369250611 24.177 35.66681769183834 139.7470369250611 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3fd4495d-fc96-494a-8b08-2a8fa635c372">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3fd4495d-fc96-494a-8b08-2a8fa635c372">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3fd4495d-fc96-494a-8b08-2a8fa635c372">
											<gml:posList>35.66682797284893 139.74704439198374 6.237 35.66684988466147 139.7469681415202 6.237 35.66684988466147 139.7469681415202 16.178 35.66682797284893 139.74704439198374 16.178 35.66682797284893 139.74704439198374 6.237</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ccf0355e-b1f8-4aa9-b57f-19dbb08b94f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ccf0355e-b1f8-4aa9-b57f-19dbb08b94f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ccf0355e-b1f8-4aa9-b57f-19dbb08b94f7">
											<gml:posList>35.666800362266834 139.74721856925643 6.237 35.6668811412589 139.7472534313488 6.237 35.6668811412589 139.7472534313488 22.678 35.666800362266834 139.74721856925643 22.678 35.666800362266834 139.74721856925643 6.237</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f6c8fe17-4430-4b68-9f58-abe2c46e8e80">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f6c8fe17-4430-4b68-9f58-abe2c46e8e80">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f6c8fe17-4430-4b68-9f58-abe2c46e8e80">
											<gml:posList>35.66687825158278 139.74724604482554 22.678 35.66687825158278 139.74724604482554 21.568 35.666806371896776 139.74721502815694 21.568 35.666806371896776 139.74721502815694 22.678 35.66687825158278 139.74724604482554 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4bff34d9-af3c-4cc4-ad8a-053e802bba00">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4bff34d9-af3c-4cc4-ad8a-053e802bba00">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4bff34d9-af3c-4cc4-ad8a-053e802bba00">
											<gml:posList>35.66683883039859 139.74696337060666 6.237 35.66683883039859 139.74696337060666 16.178 35.66684988466147 139.7469681415202 16.178 35.66684988466147 139.7469681415202 6.237 35.66683883039859 139.74696337060666 6.237</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e9b0c5c2-1a1b-4bf5-ba95-49870ddcb143">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e9b0c5c2-1a1b-4bf5-ba95-49870ddcb143">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e9b0c5c2-1a1b-4bf5-ba95-49870ddcb143">
											<gml:posList>35.666814027881756 139.7470685530403 22.678 35.666814027881756 139.7470685530403 21.568 35.666916545749636 139.7471127915718 21.568 35.666916545749636 139.7471127915718 22.678 35.666814027881756 139.7470685530403 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e3a63f0f-69e4-437f-a448-f93fe3013f7b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e3a63f0f-69e4-437f-a448-f93fe3013f7b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e3a63f0f-69e4-437f-a448-f93fe3013f7b">
											<gml:posList>35.666810768520584 139.74706101228685 22.678 35.66692257341171 139.7471092614856 22.678 35.66692257341171 139.7471092614856 16.178 35.666810768520584 139.74706101228685 16.178 35.666810768520584 139.74706101228685 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6ff50da0-05e8-460b-beb3-89855e832c73">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ff50da0-05e8-460b-beb3-89855e832c73">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ff50da0-05e8-460b-beb3-89855e832c73">
											<gml:posList>35.666928714474835 139.7470878702433 16.178 35.666928714474835 139.7470878702433 6.237 35.66682797284893 139.74704439198374 6.237 35.66682797284893 139.74704439198374 16.178 35.666928714474835 139.7470878702433 16.178</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-62c4c686-f751-49aa-bfdc-6a829309fbd9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-62c4c686-f751-49aa-bfdc-6a829309fbd9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-62c4c686-f751-49aa-bfdc-6a829309fbd9">
											<gml:posList>35.666916545749636 139.7471127915718 22.678 35.666916545749636 139.7471127915718 21.568 35.66687825158278 139.74724604482554 21.568 35.66687825158278 139.74724604482554 22.678 35.666916545749636 139.7471127915718 22.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c8f3f12a-b8ff-4d43-9197-ab70fe5859e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8f3f12a-b8ff-4d43-9197-ab70fe5859e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8f3f12a-b8ff-4d43-9197-ab70fe5859e6">
											<gml:posList>35.66692257341171 139.7471092614856 16.178 35.66692257341171 139.7471092614856 22.678 35.6668811412589 139.7472534313488 22.678 35.6668811412589 139.7472534313488 6.237 35.666928714474835 139.7470878702433 6.237 35.666928714474835 139.7470878702433 16.178 35.66692257341171 139.7471092614856 16.178</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-3561</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">572.88675</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">216</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1431</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>