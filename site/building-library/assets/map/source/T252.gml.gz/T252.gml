<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_45af2a18-ae49-47c5-a215-51d8f93661b8">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">403</bldg:usage>
			<bldg:measuredHeight uom="m">36</bldg:measuredHeight>
			<bldg:storeysAboveGround>11</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67216192283752 139.73907535842946 0 35.6720750982559 139.73916195454717 0 35.67220956112689 139.73936461055408 0 35.672296385938644 139.7392781249751 0 35.67216192283752 139.73907535842946 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67216192283752 139.73907535842946 9.43 35.672296385938644 139.7392781249751 9.43 35.67220956112689 139.73936461055408 9.43 35.6720750982559 139.73916195454717 9.43 35.67216192283752 139.73907535842946 9.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67216192283752 139.73907535842946 9.43 35.6720750982559 139.73916195454717 9.43 35.6720750982559 139.73916195454717 45.39 35.67216192283752 139.73907535842946 45.39 35.67216192283752 139.73907535842946 9.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6720750982559 139.73916195454717 9.43 35.67220956112689 139.73936461055408 9.43 35.67220956112689 139.73936461055408 45.39 35.6720750982559 139.73916195454717 45.39 35.6720750982559 139.73916195454717 9.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67220956112689 139.73936461055408 9.43 35.672296385938644 139.7392781249751 9.43 35.672296385938644 139.7392781249751 45.39 35.67220956112689 139.73936461055408 45.39 35.67220956112689 139.73936461055408 9.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672296385938644 139.7392781249751 9.43 35.67216192283752 139.73907535842946 9.43 35.67216192283752 139.73907535842946 45.39 35.672296385938644 139.7392781249751 45.39 35.672296385938644 139.7392781249751 9.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67216192283752 139.73907535842946 45.39 35.6720750982559 139.73916195454717 45.39 35.67220956112689 139.73936461055408 45.39 35.672296385938644 139.7392781249751 45.39 35.67216192283752 139.73907535842946 45.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-ae1849c3-d81c-42e2-a766-47a1da1aa558"/>
							<gml:surfaceMember xlink:href="#poly-9502c165-cafc-4259-9d13-df4981bbfd1d"/>
							<gml:surfaceMember xlink:href="#poly-88c7d700-3ecb-499d-a2b1-1ca0b3c17aee"/>
							<gml:surfaceMember xlink:href="#poly-477a4d77-81e4-4e3e-8cfc-fc33fc114dc4"/>
							<gml:surfaceMember xlink:href="#poly-36fafe0d-6cae-45ef-8e74-69d5dd12309d"/>
							<gml:surfaceMember xlink:href="#poly-822b78bf-2e66-4558-9052-54689a224d4d"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_45af2a18-ae49-47c5-a215-51d8f93661b8_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9436a45f-30fc-4e6e-990e-2313c1f51e40">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67219980942028 139.73921604642402 45.498 35.672216120141144 139.73919923657755 45.498 35.672250203811345 139.7392489058845 45.498 35.6722338840699 139.7392657157386 45.498 35.67219980942028 139.73921604642402 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04dc89d4-66d3-4260-b6e4-757c6983e876">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-04dc89d4-66d3-4260-b6e4-757c6983e876_0">
											<gml:posList>35.67219980942028 139.73921604642402 45.498 35.67219980942028 139.73921604642402 48.05 35.672216120141144 139.73919923657755 48.05 35.672216120141144 139.73919923657755 45.498 35.67219980942028 139.73921604642402 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b36088c-9218-44c2-a948-6887a0a9c61a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5b36088c-9218-44c2-a948-6887a0a9c61a_0">
											<gml:posList>35.672216120141144 139.73919923657755 45.498 35.672216120141144 139.73919923657755 48.05 35.672250203811345 139.7392489058845 48.05 35.672250203811345 139.7392489058845 45.498 35.672216120141144 139.73919923657755 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e0255565-6aa1-43a9-adfd-dc0a2e5c9d81">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e0255565-6aa1-43a9-adfd-dc0a2e5c9d81_0">
											<gml:posList>35.67219980942028 139.73921604642402 48.05 35.6722338840699 139.7392657157386 48.05 35.672250203811345 139.7392489058845 48.05 35.672216120141144 139.73919923657755 48.05 35.67219980942028 139.73921604642402 48.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eaf016cb-7ae0-4f33-bdc1-e775b51da8a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eaf016cb-7ae0-4f33-bdc1-e775b51da8a8_0">
											<gml:posList>35.6722338840699 139.7392657157386 45.498 35.6722338840699 139.7392657157386 48.05 35.67219980942028 139.73921604642402 48.05 35.67219980942028 139.73921604642402 45.498 35.6722338840699 139.7392657157386 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de507c33-1630-4834-b2e8-f45178073126">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de507c33-1630-4834-b2e8-f45178073126_0">
											<gml:posList>35.672250203811345 139.7392489058845 45.498 35.672250203811345 139.7392489058845 48.05 35.6722338840699 139.7392657157386 48.05 35.6722338840699 139.7392657157386 45.498 35.672250203811345 139.7392489058845 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_45af2a18-ae49-47c5-a215-51d8f93661b8_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a73757d2-f1ea-4f32-9fa2-6dec7d48c960">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a73757d2-f1ea-4f32-9fa2-6dec7d48c960_0">
											<gml:posList>35.67216608468206 139.73911823607023 45.498 35.67215175568579 139.7391333755722 47.889 35.67216608468206 139.73911823607023 47.889 35.67216608468206 139.73911823607023 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61a049d6-9a50-4cad-8bc9-f371e3665594">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-61a049d6-9a50-4cad-8bc9-f371e3665594_0">
											<gml:posList>35.67216608468206 139.73911823607023 45.498 35.67215175568579 139.7391333755722 45.498 35.67215175568579 139.7391333755722 47.889 35.67216608468206 139.73911823607023 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7ba7b5b-872e-46df-a8db-ce80ec44ee75">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c7ba7b5b-872e-46df-a8db-ce80ec44ee75_0">
											<gml:posList>35.67218395172392 139.7391436220416 45.498 35.67216608468206 139.73911823607023 47.889 35.67218395172392 139.7391436220416 47.889 35.67218395172392 139.7391436220416 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba976631-f861-4839-ad35-998a01e076ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba976631-f861-4839-ad35-998a01e076ce_0">
											<gml:posList>35.67218395172392 139.7391436220416 45.498 35.67216608468206 139.73911823607023 45.498 35.67216608468206 139.73911823607023 47.889 35.67218395172392 139.7391436220416 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d361c1d-cc53-4366-9349-8cc25ed9ae6e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4d361c1d-cc53-4366-9349-8cc25ed9ae6e_0">
											<gml:posList>35.67213017988268 139.73913728929125 45.498 35.67212459636246 139.7391436696817 47.172 35.67213017988268 139.73913728929125 47.172 35.67213017988268 139.73913728929125 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c54b9cea-a5d1-4f02-8604-0654155a324e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c54b9cea-a5d1-4f02-8604-0654155a324e_0">
											<gml:posList>35.67213017988268 139.73913728929125 45.498 35.67212459636246 139.7391436696817 45.498 35.67212459636246 139.7391436696817 47.172 35.67213017988268 139.73913728929125 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d9ce9f4b-de36-48d0-a465-fdba03231c9f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d9ce9f4b-de36-48d0-a465-fdba03231c9f_0">
											<gml:posList>35.672141323293 139.73915193490674 45.498 35.672135757790805 139.73915830422942 47.066 35.672141323293 139.73915193490674 47.066 35.672141323293 139.73915193490674 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-45c0feae-4be0-43cd-9d01-56c71a592d9c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-45c0feae-4be0-43cd-9d01-56c71a592d9c_0">
											<gml:posList>35.672141323293 139.73915193490674 45.498 35.672135757790805 139.73915830422942 45.498 35.672135757790805 139.73915830422942 47.066 35.672141323293 139.73915193490674 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94858f7f-18a1-4780-8679-747bda55eb5a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-94858f7f-18a1-4780-8679-747bda55eb5a_0">
											<gml:posList>35.672135757790805 139.73915830422942 45.498 35.672145755272695 139.73917143782384 47.066 35.672135757790805 139.73915830422942 47.066 35.672135757790805 139.73915830422942 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fced928b-cc54-4811-923c-7a8dfdce89e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fced928b-cc54-4811-923c-7a8dfdce89e4_0">
											<gml:posList>35.672135757790805 139.73915830422942 45.498 35.672145755272695 139.73917143782384 45.498 35.672145755272695 139.73917143782384 47.066 35.672135757790805 139.73915830422942 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f7193c2-b048-47b9-9bf5-89db32ff4751">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f7193c2-b048-47b9-9bf5-89db32ff4751_0">
											<gml:posList>35.67209739848027 139.7391738143827 45.498 35.67210317162716 139.73916786458713 47.095 35.67210317162716 139.73916786458713 45.498 35.67209739848027 139.7391738143827 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38db5611-ef49-4e70-8e2c-570f713494d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-38db5611-ef49-4e70-8e2c-570f713494d6_0">
											<gml:posList>35.67209739848027 139.7391738143827 45.498 35.67209739848027 139.7391738143827 47.095 35.67210317162716 139.73916786458713 47.095 35.67209739848027 139.7391738143827 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c09fee9-96ef-4954-9f28-b8b038b5a878">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3c09fee9-96ef-4954-9f28-b8b038b5a878_0">
											<gml:posList>35.672272870214556 139.73925644615102 45.498 35.67216211596057 139.73909177330856 48.302 35.67216211596057 139.73909177330856 45.498 35.672272870214556 139.73925644615102 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4805e82-366e-40dd-af88-14acd853f854">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4805e82-366e-40dd-af88-14acd853f854_0">
											<gml:posList>35.672272870214556 139.73925644615102 45.498 35.672272870214556 139.73925644615102 48.302 35.67216211596057 139.73909177330856 48.302 35.672272870214556 139.73925644615102 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd03444f-91bc-4726-a710-f13efa0e44d5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dd03444f-91bc-4726-a710-f13efa0e44d5_0">
											<gml:posList>35.67216170794561 139.73918088594212 45.498 35.67215547301275 139.73917264152587 47.199 35.67216170794561 139.73918088594212 47.199 35.67216170794561 139.73918088594212 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d28be8c-73a4-46f0-8f8d-b77f27c57271">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4d28be8c-73a4-46f0-8f8d-b77f27c57271_0">
											<gml:posList>35.67216170794561 139.73918088594212 45.498 35.67215547301275 139.73917264152587 45.498 35.67215547301275 139.73917264152587 47.199 35.67216170794561 139.73918088594212 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-20764dfc-4271-4a04-aa11-e502c327ba8f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-20764dfc-4271-4a04-aa11-e502c327ba8f_0">
											<gml:posList>35.67214995250035 139.73917891137685 45.498 35.672156196446494 139.73918715578247 47.199 35.67214995250035 139.73917891137685 47.199 35.67214995250035 139.73917891137685 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c8f55ec4-782c-41eb-890d-74fbbd86c1f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c8f55ec4-782c-41eb-890d-74fbbd86c1f8_0">
											<gml:posList>35.67214995250035 139.73917891137685 45.498 35.672156196446494 139.73918715578247 45.498 35.672156196446494 139.73918715578247 47.199 35.67214995250035 139.73917891137685 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-736dc39b-83d5-47cd-8468-2a7cf41948c8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-736dc39b-83d5-47cd-8468-2a7cf41948c8_0">
											<gml:posList>35.67211198129535 139.73919508385723 45.498 35.6721177454382 139.73918914511916 47.095 35.67211198129535 139.73919508385723 47.095 35.67211198129535 139.73919508385723 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-955f2878-7d25-4049-a76d-f630f37a816e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-955f2878-7d25-4049-a76d-f630f37a816e_0">
											<gml:posList>35.67211198129535 139.73919508385723 45.498 35.6721177454382 139.73918914511916 45.498 35.6721177454382 139.73918914511916 47.095 35.67211198129535 139.73919508385723 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e3ebc38-2cc9-4f7c-87e5-84a54b1c12d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4e3ebc38-2cc9-4f7c-87e5-84a54b1c12d7_0">
											<gml:posList>35.67216208505074 139.739202061649 45.498 35.67215537118309 139.7391922712829 46.606 35.67216208505074 139.739202061649 46.606 35.67216208505074 139.739202061649 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a7f3fbc-c2a9-4ba8-8893-27950cf37395">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2a7f3fbc-c2a9-4ba8-8893-27950cf37395_0">
											<gml:posList>35.67216208505074 139.739202061649 45.498 35.67215537118309 139.7391922712829 45.498 35.67215537118309 139.7391922712829 46.606 35.67216208505074 139.739202061649 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1045b0f8-5c16-4fc0-881d-e87a79d6e539">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1045b0f8-5c16-4fc0-881d-e87a79d6e539_0">
											<gml:posList>35.67214482460651 139.73920314237895 45.498 35.67215153847329 139.7392129327447 46.606 35.67214482460651 139.73920314237895 46.606 35.67214482460651 139.73920314237895 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-50cda5a4-f944-44b5-bbc7-ac32e414e9cf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-50cda5a4-f944-44b5-bbc7-ac32e414e9cf_0">
											<gml:posList>35.67214482460651 139.73920314237895 45.498 35.67215153847329 139.7392129327447 45.498 35.67215153847329 139.7392129327447 46.606 35.67214482460651 139.73920314237895 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f10c8e5-4541-42b1-9509-96d046a607af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f10c8e5-4541-42b1-9509-96d046a607af_0">
											<gml:posList>35.672132941874274 139.7392112976015 45.498 35.67216728728297 139.73926140841527 47.095 35.67216728728297 139.73926140841527 45.498 35.672132941874274 139.7392112976015 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f9f63fb5-3bd8-490c-a36b-632712a7192a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f9f63fb5-3bd8-490c-a36b-632712a7192a_0">
											<gml:posList>35.672132941874274 139.7392112976015 45.498 35.672132941874274 139.7392112976015 47.095 35.67216728728297 139.73926140841527 47.095 35.672132941874274 139.7392112976015 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7900a912-fb8c-42dd-995b-7ecd393c0517">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7900a912-fb8c-42dd-995b-7ecd393c0517_0">
											<gml:posList>35.67216151412289 139.73926734716238 45.498 35.67212716872527 139.73921724739617 47.095 35.67212716872527 139.73921724739617 45.498 35.67216151412289 139.73926734716238 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-026c416c-9411-4873-a85d-9a8a862d442c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-026c416c-9411-4873-a85d-9a8a862d442c_0">
											<gml:posList>35.67216151412289 139.73926734716238 45.498 35.67216151412289 139.73926734716238 47.095 35.67212716872527 139.73921724739617 47.095 35.67216151412289 139.73926734716238 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-878df2e1-764e-47a6-a400-291d2619add0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-878df2e1-764e-47a6-a400-291d2619add0_0">
											<gml:posList>35.672198134732994 139.73933382627746 45.498 35.672089190872626 139.73916727345085 48.302 35.672198134732994 139.73933382627746 48.302 35.672198134732994 139.73933382627746 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4bb99678-c488-408c-9cdd-e3199df547f4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4bb99678-c488-408c-9cdd-e3199df547f4_0">
											<gml:posList>35.672198134732994 139.73933382627746 45.498 35.672089190872626 139.73916727345085 45.498 35.672089190872626 139.73916727345085 48.302 35.672198134732994 139.73933382627746 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11c2fd06-fee4-454b-8e70-b1726e008b97">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-11c2fd06-fee4-454b-8e70-b1726e008b97_0">
											<gml:posList>35.6722025122716 139.73930672405493 45.498 35.67222959544152 139.73927969461093 47.907 35.6722025122716 139.73930672405493 47.907 35.6722025122716 139.73930672405493 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-611c2398-9e04-4e77-8742-24d913b3b30b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-611c2398-9e04-4e77-8742-24d913b3b30b_0">
											<gml:posList>35.6722025122716 139.73930672405493 45.498 35.67222959544152 139.73927969461093 45.498 35.67222959544152 139.73927969461093 47.907 35.6722025122716 139.73930672405493 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8d038db-fe88-4b55-a59b-b1e3e5299429">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d8d038db-fe88-4b55-a59b-b1e3e5299429_0">
											<gml:posList>35.672196177187125 139.7392971873005 45.498 35.6722025122716 139.73930672405493 47.907 35.672196177187125 139.7392971873005 47.907 35.672196177187125 139.7392971873005 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b7849dba-04dd-43d6-b891-4eef6e4e47be">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b7849dba-04dd-43d6-b891-4eef6e4e47be_0">
											<gml:posList>35.672196177187125 139.7392971873005 45.498 35.6722025122716 139.73930672405493 45.498 35.6722025122716 139.73930672405493 47.907 35.672196177187125 139.7392971873005 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f5c8c0d-5015-4c19-a25f-93ced0471a23">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f5c8c0d-5015-4c19-a25f-93ced0471a23_0">
											<gml:posList>35.67209739848027 139.7391738143827 47.095 35.67211198129535 139.73919508385723 47.095 35.6721177454382 139.73918914511916 47.095 35.67209739848027 139.7391738143827 47.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f707993-fb84-4deb-b656-e62f92c4c6b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2f707993-fb84-4deb-b656-e62f92c4c6b4_0">
											<gml:posList>35.67210317162716 139.73916786458713 47.095 35.67209739848027 139.7391738143827 47.095 35.6721177454382 139.73918914511916 47.095 35.67210317162716 139.73916786458713 47.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-133fe93d-5083-4152-9f8a-b6605d7df53a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-133fe93d-5083-4152-9f8a-b6605d7df53a_0">
											<gml:posList>35.67210317162716 139.73916786458713 45.498 35.6721177454382 139.73918914511916 47.095 35.6721177454382 139.73918914511916 45.498 35.67210317162716 139.73916786458713 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76c2e016-5e5f-4180-b2ef-40880228a35a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-76c2e016-5e5f-4180-b2ef-40880228a35a_0">
											<gml:posList>35.67210317162716 139.73916786458713 45.498 35.67210317162716 139.73916786458713 47.095 35.6721177454382 139.73918914511916 47.095 35.67210317162716 139.73916786458713 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9eb706d0-c86e-4245-8952-0988e7bb8242">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9eb706d0-c86e-4245-8952-0988e7bb8242_0">
											<gml:posList>35.67211902684601 139.73919101047275 45.498 35.67211325368936 139.73919694922134 47.095 35.67211902684601 139.73919101047275 47.095 35.67211902684601 139.73919101047275 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-03b9b4b3-a623-46ee-a2c5-a7b838d4c3c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-03b9b4b3-a623-46ee-a2c5-a7b838d4c3c3_0">
											<gml:posList>35.67211902684601 139.73919101047275 45.498 35.67211325368936 139.73919694922134 45.498 35.67211325368936 139.73919694922134 47.095 35.67211902684601 139.73919101047275 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9b4d1603-0075-48fc-b956-0adbbaa31f15">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9b4d1603-0075-48fc-b956-0adbbaa31f15_0">
											<gml:posList>35.6720806270354 139.7391662561855 45.498 35.672162909803426 139.73908106831215 48.302 35.672162909803426 139.73908106831215 45.498 35.6720806270354 139.7391662561855 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-45c3306f-04f6-42d2-a137-ebe7084a3399">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-45c3306f-04f6-42d2-a137-ebe7084a3399_0">
											<gml:posList>35.6720806270354 139.7391662561855 45.498 35.6720806270354 139.7391662561855 48.302 35.672162909803426 139.73908106831215 48.302 35.6720806270354 139.7391662561855 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-605f58dd-bbf8-4a03-8f48-9aa2a9370548">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-605f58dd-bbf8-4a03-8f48-9aa2a9370548_0">
											<gml:posList>35.67211902684601 139.73919101047275 47.095 35.67212604974615 139.7392156138278 47.095 35.67213182289507 139.73920966403313 47.095 35.67211902684601 139.73919101047275 47.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a76d71f0-0c6c-4ed2-baf2-be808b63abd5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a76d71f0-0c6c-4ed2-baf2-be808b63abd5_0">
											<gml:posList>35.67211902684601 139.73919101047275 47.095 35.67211325368936 139.73919694922134 47.095 35.67212604974615 139.7392156138278 47.095 35.67211902684601 139.73919101047275 47.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ad0bcfd-7a94-4b56-963c-d1c4ec4e754e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3ad0bcfd-7a94-4b56-963c-d1c4ec4e754e_0">
											<gml:posList>35.67213182289507 139.73920966403313 45.498 35.67211902684601 139.73919101047275 47.095 35.67213182289507 139.73920966403313 47.095 35.67213182289507 139.73920966403313 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bdae8e93-32e1-42be-9c7b-e1a03aa1e11b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bdae8e93-32e1-42be-9c7b-e1a03aa1e11b_0">
											<gml:posList>35.67213182289507 139.73920966403313 45.498 35.67211902684601 139.73919101047275 45.498 35.67211902684601 139.73919101047275 47.095 35.67213182289507 139.73920966403313 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a60dc6f-03b4-4b55-a5ea-bb88dbaefe64">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1a60dc6f-03b4-4b55-a5ea-bb88dbaefe64_0">
											<gml:posList>35.672089190872626 139.73916727345085 45.498 35.67216211596057 139.73909177330856 48.302 35.672089190872626 139.73916727345085 48.302 35.672089190872626 139.73916727345085 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-28174667-cebc-43a3-ac68-5bd2b97cba7f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-28174667-cebc-43a3-ac68-5bd2b97cba7f_0">
											<gml:posList>35.672089190872626 139.73916727345085 45.498 35.67216211596057 139.73909177330856 45.498 35.67216211596057 139.73909177330856 48.302 35.672089190872626 139.73916727345085 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a93d19af-0e7b-4a82-a8e4-0efb064b698f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a93d19af-0e7b-4a82-a8e4-0efb064b698f_0">
											<gml:posList>35.67212459636246 139.7391436696817 45.498 35.672130876374545 139.73915192508613 47.172 35.67212459636246 139.7391436696817 47.172 35.67212459636246 139.7391436696817 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac20fde1-869a-48c9-a8bd-5d772ae9e54d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ac20fde1-869a-48c9-a8bd-5d772ae9e54d_0">
											<gml:posList>35.67212459636246 139.7391436696817 45.498 35.672130876374545 139.73915192508613 45.498 35.672130876374545 139.73915192508613 47.172 35.67212459636246 139.7391436696817 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e492af69-8003-4b0b-9865-4a67624fd631">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e492af69-8003-4b0b-9865-4a67624fd631_0">
											<gml:posList>35.67212459636246 139.7391436696817 47.172 35.672130876374545 139.73915192508613 47.172 35.67213645989521 139.7391455446957 47.172 35.67212459636246 139.7391436696817 47.172</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9b1b565b-4550-4040-871b-25bca91aab6d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9b1b565b-4550-4040-871b-25bca91aab6d_0">
											<gml:posList>35.67213017988268 139.73913728929125 47.172 35.67212459636246 139.7391436696817 47.172 35.67213645989521 139.7391455446957 47.172 35.67213017988268 139.73913728929125 47.172</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a83a3d61-7619-47c9-af18-44a702c125b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a83a3d61-7619-47c9-af18-44a702c125b2_0">
											<gml:posList>35.67213645989521 139.7391455446957 45.498 35.67213017988268 139.73913728929125 47.172 35.67213645989521 139.7391455446957 47.172 35.67213645989521 139.7391455446957 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26cfc187-fa6c-4ef3-8b8b-4fdba22e3f8c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-26cfc187-fa6c-4ef3-8b8b-4fdba22e3f8c_0">
											<gml:posList>35.67213645989521 139.7391455446957 45.498 35.67213017988268 139.73913728929125 45.498 35.67213017988268 139.73913728929125 47.172 35.67213645989521 139.7391455446957 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bbf56562-ba41-47a9-a614-c61cc4d72e58">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bbf56562-ba41-47a9-a614-c61cc4d72e58_0">
											<gml:posList>35.672130876374545 139.73915192508613 45.498 35.67213645989521 139.7391455446957 47.172 35.672130876374545 139.73915192508613 47.172 35.672130876374545 139.73915192508613 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7950c852-e509-4599-b898-6a5d96117154">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7950c852-e509-4599-b898-6a5d96117154_0">
											<gml:posList>35.672130876374545 139.73915192508613 45.498 35.67213645989521 139.7391455446957 45.498 35.67213645989521 139.7391455446957 47.172 35.672130876374545 139.73915192508613 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-946dacf7-d7bf-4c7f-bd97-78b8ee292bb8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-946dacf7-d7bf-4c7f-bd97-78b8ee292bb8_0">
											<gml:posList>35.6720806270354 139.7391662561855 45.498 35.672197277832 139.73934460867562 48.302 35.6720806270354 139.7391662561855 48.302 35.6720806270354 139.7391662561855 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-226dd713-18dc-4876-9808-090851adf2c4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-226dd713-18dc-4876-9808-090851adf2c4_0">
											<gml:posList>35.6720806270354 139.7391662561855 45.498 35.672197277832 139.73934460867562 45.498 35.672197277832 139.73934460867562 48.302 35.6720806270354 139.7391662561855 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5872b4dc-fd72-45b9-826e-eb8a45ef30f5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5872b4dc-fd72-45b9-826e-eb8a45ef30f5_0">
											<gml:posList>35.672135757790805 139.73915830422942 47.066 35.67215132077557 139.73916506850128 47.066 35.672141323293 139.73915193490674 47.066 35.672135757790805 139.73915830422942 47.066</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c8531e8-bc5d-4c5a-be0a-4bfa95baf428">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c8531e8-bc5d-4c5a-be0a-4bfa95baf428_0">
											<gml:posList>35.672135757790805 139.73915830422942 47.066 35.672145755272695 139.73917143782384 47.066 35.67215132077557 139.73916506850128 47.066 35.672135757790805 139.73915830422942 47.066</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc82a8fe-2601-4c67-81e8-ea0f6f07b682">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cc82a8fe-2601-4c67-81e8-ea0f6f07b682_0">
											<gml:posList>35.67215132077557 139.73916506850128 45.498 35.672141323293 139.73915193490674 47.066 35.67215132077557 139.73916506850128 47.066 35.67215132077557 139.73916506850128 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b5091466-522c-4fd0-8a64-d56cc643c858">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b5091466-522c-4fd0-8a64-d56cc643c858_0">
											<gml:posList>35.67215132077557 139.73916506850128 45.498 35.672141323293 139.73915193490674 45.498 35.672141323293 139.73915193490674 47.066 35.67215132077557 139.73916506850128 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2dcb64f3-48f1-4c9d-b19a-8f927de30cf5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2dcb64f3-48f1-4c9d-b19a-8f927de30cf5_0">
											<gml:posList>35.67216728728297 139.73926140841527 47.095 35.672132941874274 139.7392112976015 47.095 35.67212716872527 139.73921724739617 47.095 35.67216728728297 139.73926140841527 47.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7cb15471-e373-4ac2-9b31-22f36e3ecf43">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7cb15471-e373-4ac2-9b31-22f36e3ecf43_0">
											<gml:posList>35.67216151412289 139.73926734716238 47.095 35.67216728728297 139.73926140841527 47.095 35.67212716872527 139.73921724739617 47.095 35.67216151412289 139.73926734716238 47.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e2f9626c-489d-450d-a189-ff37e20f1277">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e2f9626c-489d-450d-a189-ff37e20f1277_0">
											<gml:posList>35.672145755272695 139.73917143782384 45.498 35.67215132077557 139.73916506850128 47.066 35.672145755272695 139.73917143782384 47.066 35.672145755272695 139.73917143782384 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc409c2b-b6a1-4856-ba12-2396891ffd03">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cc409c2b-b6a1-4856-ba12-2396891ffd03_0">
											<gml:posList>35.672145755272695 139.73917143782384 45.498 35.67215132077557 139.73916506850128 45.498 35.67215132077557 139.73916506850128 47.066 35.672145755272695 139.73917143782384 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e4c789f9-510a-4c4b-b029-bcf044014802">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e4c789f9-510a-4c4b-b029-bcf044014802_0">
											<gml:posList>35.67214482460651 139.73920314237895 45.498 35.67215537118309 139.7391922712829 46.606 35.67215537118309 139.7391922712829 45.498 35.67214482460651 139.73920314237895 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-05975f1a-ddce-475f-8d76-bcd97b6aca5b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-05975f1a-ddce-475f-8d76-bcd97b6aca5b_0">
											<gml:posList>35.67214482460651 139.73920314237895 45.498 35.67214482460651 139.73920314237895 46.606 35.67215537118309 139.7391922712829 46.606 35.67214482460651 139.73920314237895 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78f1021b-41a1-4d73-9e52-e118efb6e991">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78f1021b-41a1-4d73-9e52-e118efb6e991_0">
											<gml:posList>35.67215547301275 139.73917264152587 45.498 35.67214995250035 139.73917891137685 47.199 35.67215547301275 139.73917264152587 47.199 35.67215547301275 139.73917264152587 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-10f5b24e-8b48-4c93-9ee4-0a683d466133">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-10f5b24e-8b48-4c93-9ee4-0a683d466133_0">
											<gml:posList>35.67215547301275 139.73917264152587 45.498 35.67214995250035 139.73917891137685 45.498 35.67214995250035 139.73917891137685 47.199 35.67215547301275 139.73917264152587 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a591f8a-ba39-4e40-9385-402c04fd5245">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1a591f8a-ba39-4e40-9385-402c04fd5245_0">
											<gml:posList>35.67214482460651 139.73920314237895 46.606 35.67216208505074 139.739202061649 46.606 35.67215537118309 139.7391922712829 46.606 35.67214482460651 139.73920314237895 46.606</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33a9fa3d-23a6-4964-a23f-3a69b9c8026c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-33a9fa3d-23a6-4964-a23f-3a69b9c8026c_0">
											<gml:posList>35.67214482460651 139.73920314237895 46.606 35.67215153847329 139.7392129327447 46.606 35.67216208505074 139.739202061649 46.606 35.67214482460651 139.73920314237895 46.606</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c1d14d5-4938-4844-9aa5-d100bb4e5703">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c1d14d5-4938-4844-9aa5-d100bb4e5703_0">
											<gml:posList>35.67216170794561 139.73918088594212 47.199 35.67215547301275 139.73917264152587 47.199 35.67214995250035 139.73917891137685 47.199 35.67216170794561 139.73918088594212 47.199</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f19ccf3-ea4d-4f53-b653-8852047bff97">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9f19ccf3-ea4d-4f53-b653-8852047bff97_0">
											<gml:posList>35.672156196446494 139.73918715578247 47.199 35.67216170794561 139.73918088594212 47.199 35.67214995250035 139.73917891137685 47.199 35.672156196446494 139.73918715578247 47.199</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c8abd8e4-7508-407b-9b8d-f6120ae2e1a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c8abd8e4-7508-407b-9b8d-f6120ae2e1a8_0">
											<gml:posList>35.67215153847329 139.7392129327447 45.498 35.67216208505074 139.739202061649 46.606 35.67215153847329 139.7392129327447 46.606 35.67215153847329 139.7392129327447 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ccc631c0-e9e1-4bf8-a246-2193410a4482">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ccc631c0-e9e1-4bf8-a246-2193410a4482_0">
											<gml:posList>35.67215153847329 139.7392129327447 45.498 35.67216208505074 139.739202061649 45.498 35.67216208505074 139.739202061649 46.606 35.67215153847329 139.7392129327447 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cadbeb66-382d-4c71-bea6-c43921ec73cd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cadbeb66-382d-4c71-bea6-c43921ec73cd_0">
											<gml:posList>35.672156196446494 139.73918715578247 45.498 35.67216170794561 139.73918088594212 47.199 35.672156196446494 139.73918715578247 47.199 35.672156196446494 139.73918715578247 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44483855-1c85-4bb9-9e5f-9ea775935824">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-44483855-1c85-4bb9-9e5f-9ea775935824_0">
											<gml:posList>35.672156196446494 139.73918715578247 45.498 35.67216170794561 139.73918088594212 45.498 35.67216170794561 139.73918088594212 47.199 35.672156196446494 139.73918715578247 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9b43ead-89e0-43c9-8764-b529a69d590f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b9b43ead-89e0-43c9-8764-b529a69d590f_0">
											<gml:posList>35.67215175568579 139.7391333755722 45.498 35.67216961371078 139.73915876155306 47.889 35.67215175568579 139.7391333755722 47.889 35.67215175568579 139.7391333755722 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b60c900f-f3f5-48e9-b78a-d2c2103b9fa6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b60c900f-f3f5-48e9-b78a-d2c2103b9fa6_0">
											<gml:posList>35.67215175568579 139.7391333755722 45.498 35.67216961371078 139.73915876155306 45.498 35.67216961371078 139.73915876155306 47.889 35.67215175568579 139.7391333755722 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-940d5a9f-3e16-42cc-b54e-d2aa05151a9d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-940d5a9f-3e16-42cc-b54e-d2aa05151a9d_0">
											<gml:posList>35.67216151412289 139.73926734716238 45.498 35.67216728728297 139.73926140841527 47.095 35.67216151412289 139.73926734716238 47.095 35.67216151412289 139.73926734716238 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9ff04bc-7cdd-4fdd-94a5-5df02626449c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b9ff04bc-7cdd-4fdd-94a5-5df02626449c_0">
											<gml:posList>35.67216151412289 139.73926734716238 45.498 35.67216728728297 139.73926140841527 45.498 35.67216728728297 139.73926140841527 47.095 35.67216151412289 139.73926734716238 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0454b91f-47e8-4e5b-9cfa-5a8c36b969af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0454b91f-47e8-4e5b-9cfa-5a8c36b969af_0">
											<gml:posList>35.67216961371078 139.73915876155306 47.889 35.67218395172392 139.7391436220416 47.889 35.67216608468206 139.73911823607023 47.889 35.67216961371078 139.73915876155306 47.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01c92941-5814-443c-b0fe-a2adb3595f68">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01c92941-5814-443c-b0fe-a2adb3595f68_0">
											<gml:posList>35.67215175568579 139.7391333755722 47.889 35.67216961371078 139.73915876155306 47.889 35.67216608468206 139.73911823607023 47.889 35.67215175568579 139.7391333755722 47.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43d26f2a-deff-4507-8cf8-28b392c7c5d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-43d26f2a-deff-4507-8cf8-28b392c7c5d4_0">
											<gml:posList>35.67216961371078 139.73915876155306 45.498 35.67218395172392 139.7391436220416 47.889 35.67216961371078 139.73915876155306 47.889 35.67216961371078 139.73915876155306 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13cdd09c-78f4-43d8-8812-c3178cd64153">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-13cdd09c-78f4-43d8-8812-c3178cd64153_0">
											<gml:posList>35.67216961371078 139.73915876155306 45.498 35.67218395172392 139.7391436220416 45.498 35.67218395172392 139.7391436220416 47.889 35.67216961371078 139.73915876155306 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b3e9205-fe07-43d8-a5fd-020125b822c8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b3e9205-fe07-43d8-a5fd-020125b822c8_0">
											<gml:posList>35.672183142794346 139.73928495201181 45.498 35.67217481147945 139.7392931251535 47.429 35.672183142794346 139.73928495201181 47.429 35.672183142794346 139.73928495201181 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f543ee84-a26e-4bdf-ba70-835549bc6b76">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f543ee84-a26e-4bdf-ba70-835549bc6b76_0">
											<gml:posList>35.672183142794346 139.73928495201181 45.498 35.67217481147945 139.7392931251535 45.498 35.67217481147945 139.7392931251535 47.429 35.672183142794346 139.73928495201181 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8781e3c4-b671-443e-bc27-bf5549a5ed22">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8781e3c4-b671-443e-bc27-bf5549a5ed22_0">
											<gml:posList>35.672198134732994 139.73933382627746 48.302 35.6720806270354 139.7391662561855 48.302 35.672197277832 139.73934460867562 48.302 35.672198134732994 139.73933382627746 48.302</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca864b75-56cf-4d5d-81dd-7fd071d6edc1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ca864b75-56cf-4d5d-81dd-7fd071d6edc1_0">
											<gml:posList>35.672197277832 139.73934460867562 48.302 35.67228149710365 139.73925740812174 48.302 35.672272870214556 139.73925644615102 48.302 35.672197277832 139.73934460867562 48.302</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63146c34-5483-4584-bff6-1b15b0aa05e5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-63146c34-5483-4584-bff6-1b15b0aa05e5_0">
											<gml:posList>35.6720806270354 139.7391662561855 48.302 35.67216211596057 139.73909177330856 48.302 35.672162909803426 139.73908106831215 48.302 35.6720806270354 139.7391662561855 48.302</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16d67792-da3d-40d2-94d5-5a6115127ef9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16d67792-da3d-40d2-94d5-5a6115127ef9_0">
											<gml:posList>35.67228149710365 139.73925740812174 48.302 35.672162909803426 139.73908106831215 48.302 35.67216211596057 139.73909177330856 48.302 35.67228149710365 139.73925740812174 48.302</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1148c1e4-f4c7-42ed-9fb9-83a31fdcdb00">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1148c1e4-f4c7-42ed-9fb9-83a31fdcdb00_0">
											<gml:posList>35.672198134732994 139.73933382627746 48.302 35.672197277832 139.73934460867562 48.302 35.672272870214556 139.73925644615102 48.302 35.672198134732994 139.73933382627746 48.302</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46203c8a-88db-4df5-9074-5335cd2ef7f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46203c8a-88db-4df5-9074-5335cd2ef7f8_0">
											<gml:posList>35.672089190872626 139.73916727345085 48.302 35.6720806270354 139.7391662561855 48.302 35.672198134732994 139.73933382627746 48.302 35.672089190872626 139.73916727345085 48.302</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-654f32c0-266d-4a55-a40b-4a2d89f40244">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-654f32c0-266d-4a55-a40b-4a2d89f40244_0">
											<gml:posList>35.67228149710365 139.73925740812174 48.302 35.67216211596057 139.73909177330856 48.302 35.672272870214556 139.73925644615102 48.302 35.67228149710365 139.73925740812174 48.302</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-edb86df5-7f8e-49e9-a10c-dd19b5ced897">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-edb86df5-7f8e-49e9-a10c-dd19b5ced897_0">
											<gml:posList>35.67216211596057 139.73909177330856 48.302 35.6720806270354 139.7391662561855 48.302 35.672089190872626 139.73916727345085 48.302 35.67216211596057 139.73909177330856 48.302</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-524e5620-6657-4919-a119-23669dbe7158">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-524e5620-6657-4919-a119-23669dbe7158_0">
											<gml:posList>35.672183142794346 139.73928495201181 47.429 35.67217481147945 139.7392931251535 47.429 35.672180442778135 139.73930174587036 47.429 35.672183142794346 139.73928495201181 47.429</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-573117f3-a9a5-4fbf-8aed-a99caea3a55f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-573117f3-a9a5-4fbf-8aed-a99caea3a55f_0">
											<gml:posList>35.67218877408497 139.7392935616825 47.429 35.672183142794346 139.73928495201181 47.429 35.672180442778135 139.73930174587036 47.429 35.67218877408497 139.7392935616825 47.429</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-52ea88d7-6f95-400f-a06b-75b2b7b7dc86">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-52ea88d7-6f95-400f-a06b-75b2b7b7dc86_0">
											<gml:posList>35.672180442778135 139.73930174587036 45.498 35.67218877408497 139.7392935616825 47.429 35.672180442778135 139.73930174587036 47.429 35.672180442778135 139.73930174587036 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7fcf435f-3727-4ff8-a3e7-78cf769c4406">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7fcf435f-3727-4ff8-a3e7-78cf769c4406_0">
											<gml:posList>35.672180442778135 139.73930174587036 45.498 35.67218877408497 139.7392935616825 45.498 35.67218877408497 139.7392935616825 47.429 35.672180442778135 139.73930174587036 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c2fbc5fc-73e5-46c4-a41c-78c09a8ed26d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c2fbc5fc-73e5-46c4-a41c-78c09a8ed26d_0">
											<gml:posList>35.672183142794346 139.73928495201181 45.498 35.67218877408497 139.7392935616825 47.429 35.67218877408497 139.7392935616825 45.498 35.672183142794346 139.73928495201181 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-85554934-8dea-4556-84f6-bc5e79d3dd1b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-85554934-8dea-4556-84f6-bc5e79d3dd1b_0">
											<gml:posList>35.672183142794346 139.73928495201181 45.498 35.672183142794346 139.73928495201181 47.429 35.67218877408497 139.7392935616825 47.429 35.672183142794346 139.73928495201181 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e26b6b1-6c7d-4c1c-89b3-7190defd11e0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1e26b6b1-6c7d-4c1c-89b3-7190defd11e0_0">
											<gml:posList>35.67222326936865 139.73927015784489 45.498 35.672196177187125 139.7392971873005 47.907 35.67222326936865 139.73927015784489 47.907 35.67222326936865 139.73927015784489 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a770b51-c0b4-444b-8c2a-e0da71eed17d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4a770b51-c0b4-444b-8c2a-e0da71eed17d_0">
											<gml:posList>35.67222326936865 139.73927015784489 45.498 35.672196177187125 139.7392971873005 45.498 35.672196177187125 139.7392971873005 47.907 35.67222326936865 139.73927015784489 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b527451-ffd1-462d-b62f-9ad84f1b5884">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b527451-ffd1-462d-b62f-9ad84f1b5884_0">
											<gml:posList>35.672196177187125 139.7392971873005 47.907 35.67222959544152 139.73927969461093 47.907 35.67222326936865 139.73927015784489 47.907 35.672196177187125 139.7392971873005 47.907</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-082d2ba7-7a0a-49ef-82d8-b0ec413c1250">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-082d2ba7-7a0a-49ef-82d8-b0ec413c1250_0">
											<gml:posList>35.672196177187125 139.7392971873005 47.907 35.6722025122716 139.73930672405493 47.907 35.67222959544152 139.73927969461093 47.907 35.672196177187125 139.7392971873005 47.907</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eb1c8f2e-832c-474c-a6b6-c48fa11ed263">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eb1c8f2e-832c-474c-a6b6-c48fa11ed263_0">
											<gml:posList>35.67228149710365 139.73925740812174 45.498 35.672162909803426 139.73908106831215 48.302 35.67228149710365 139.73925740812174 48.302 35.67228149710365 139.73925740812174 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-30ddeca5-0a21-40c6-aca0-cd4326e9425d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-30ddeca5-0a21-40c6-aca0-cd4326e9425d_0">
											<gml:posList>35.67228149710365 139.73925740812174 45.498 35.672162909803426 139.73908106831215 45.498 35.672162909803426 139.73908106831215 48.302 35.67228149710365 139.73925740812174 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82ed3231-661c-40b5-ac10-8c5fef9f6e01">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-82ed3231-661c-40b5-ac10-8c5fef9f6e01_0">
											<gml:posList>35.67222959544152 139.73927969461093 45.498 35.67222326936865 139.73927015784489 47.907 35.67222959544152 139.73927969461093 47.907 35.67222959544152 139.73927969461093 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8033b6f1-a86b-49c1-8c64-2115841bedaa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8033b6f1-a86b-49c1-8c64-2115841bedaa_0">
											<gml:posList>35.67222959544152 139.73927969461093 45.498 35.67222326936865 139.73927015784489 45.498 35.67222326936865 139.73927015784489 47.907 35.67222959544152 139.73927969461093 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5be54273-6900-491c-8610-ba920b507b19">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5be54273-6900-491c-8610-ba920b507b19_0">
											<gml:posList>35.672198134732994 139.73933382627746 45.498 35.672272870214556 139.73925644615102 48.302 35.672272870214556 139.73925644615102 45.498 35.672198134732994 139.73933382627746 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eacd9ac7-91e1-4596-bdd6-5876357071b5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eacd9ac7-91e1-4596-bdd6-5876357071b5_0">
											<gml:posList>35.672198134732994 139.73933382627746 45.498 35.672198134732994 139.73933382627746 48.302 35.672272870214556 139.73925644615102 48.302 35.672198134732994 139.73933382627746 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7b56996-2fbb-4b84-b286-1a908ffac342">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c7b56996-2fbb-4b84-b286-1a908ffac342_0">
											<gml:posList>35.672197277832 139.73934460867562 45.498 35.67228149710365 139.73925740812174 48.302 35.672197277832 139.73934460867562 48.302 35.672197277832 139.73934460867562 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d593de2-926a-43de-b116-c73838bfc838">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d593de2-926a-43de-b116-c73838bfc838_0">
											<gml:posList>35.672197277832 139.73934460867562 45.498 35.67228149710365 139.73925740812174 45.498 35.67228149710365 139.73925740812174 48.302 35.672197277832 139.73934460867562 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d747bc4f-7e58-4cd6-aecb-75dfdd6edbce">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67216961371078 139.73915876155306 45.498 35.67215175568579 139.7391333755722 45.498 35.67216608468206 139.73911823607023 45.498 35.67216961371078 139.73915876155306 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60f11973-df75-4325-934c-972938056754">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67218395172392 139.7391436220416 45.498 35.67216961371078 139.73915876155306 45.498 35.67216608468206 139.73911823607023 45.498 35.67218395172392 139.7391436220416 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-85892c6b-e18e-415b-9236-31c4729013e6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67212459636246 139.7391436696817 45.498 35.67213017988268 139.73913728929125 45.498 35.67213645989521 139.7391455446957 45.498 35.67212459636246 139.7391436696817 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-142ed144-c6b7-432b-a6dc-41be6610986c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672130876374545 139.73915192508613 45.498 35.67212459636246 139.7391436696817 45.498 35.67213645989521 139.7391455446957 45.498 35.672130876374545 139.73915192508613 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-65ac4b8a-392b-4faf-8d4d-505b31a63d43">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67215132077557 139.73916506850128 45.498 35.672135757790805 139.73915830422942 45.498 35.672141323293 139.73915193490674 45.498 35.67215132077557 139.73916506850128 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af393e2f-146b-4e93-a632-22cc23f46192">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67215132077557 139.73916506850128 45.498 35.672145755272695 139.73917143782384 45.498 35.672135757790805 139.73915830422942 45.498 35.67215132077557 139.73916506850128 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3cdfccb7-f340-4757-9cbd-1e9d180d78a3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67216170794561 139.73918088594212 45.498 35.672156196446494 139.73918715578247 45.498 35.67214995250035 139.73917891137685 45.498 35.67216170794561 139.73918088594212 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-87837e17-d990-446e-9746-8a7dfa4f61e4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67215547301275 139.73917264152587 45.498 35.67216170794561 139.73918088594212 45.498 35.67214995250035 139.73917891137685 45.498 35.67215547301275 139.73917264152587 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00fce1d9-dbea-4964-a2d7-ffec3b65a42e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6721177454382 139.73918914511916 45.498 35.67211198129535 139.73919508385723 45.498 35.67209739848027 139.7391738143827 45.498 35.6721177454382 139.73918914511916 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4f58e161-5356-489a-85b6-c2d7da909f0d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67210317162716 139.73916786458713 45.498 35.6721177454382 139.73918914511916 45.498 35.67209739848027 139.7391738143827 45.498 35.67210317162716 139.73916786458713 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4eca1632-040b-44ff-a085-a81db4a89d02">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67209739848027 139.7391738143827 45.498 35.67211198129535 139.73919508385723 47.095 35.67209739848027 139.7391738143827 47.095 35.67209739848027 139.7391738143827 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a06edbcd-3a2e-40f4-b45b-46d70caded18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67209739848027 139.7391738143827 45.498 35.67211198129535 139.73919508385723 45.498 35.67211198129535 139.73919508385723 47.095 35.67209739848027 139.7391738143827 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-435ba15e-3cd9-4b99-b509-ea5ffc63ef5e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67214482460651 139.73920314237895 45.498 35.67216208505074 139.739202061649 45.498 35.67215153847329 139.7392129327447 45.498 35.67214482460651 139.73920314237895 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18157a37-411d-4239-8f19-29c62a18bfbe">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67214482460651 139.73920314237895 45.498 35.67215537118309 139.7391922712829 45.498 35.67216208505074 139.739202061649 45.498 35.67214482460651 139.73920314237895 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7c487ef-b11b-4c76-b5db-af443df23d7d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67212604974615 139.7392156138278 45.498 35.67211902684601 139.73919101047275 45.498 35.67213182289507 139.73920966403313 45.498 35.67212604974615 139.7392156138278 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9bb89c27-2c24-4601-8e93-6f6986915f2f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67212604974615 139.7392156138278 45.498 35.67211325368936 139.73919694922134 45.498 35.67211902684601 139.73919101047275 45.498 35.67212604974615 139.7392156138278 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-15f29416-753d-463b-ab74-f84cdf691e71">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67211325368936 139.73919694922134 45.498 35.67212604974615 139.7392156138278 47.095 35.67211325368936 139.73919694922134 47.095 35.67211325368936 139.73919694922134 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b8bb50f-01c9-4d9c-a8b5-bc5936d8e119">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67211325368936 139.73919694922134 45.498 35.67212604974615 139.7392156138278 45.498 35.67212604974615 139.7392156138278 47.095 35.67211325368936 139.73919694922134 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0777df4d-af28-44f4-92cc-c0d085552b57">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67212604974615 139.7392156138278 45.498 35.67213182289507 139.73920966403313 47.095 35.67212604974615 139.7392156138278 47.095 35.67212604974615 139.7392156138278 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0171a412-fd50-47ce-b1ad-90cb257db870">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67212604974615 139.7392156138278 45.498 35.67213182289507 139.73920966403313 45.498 35.67213182289507 139.73920966403313 47.095 35.67212604974615 139.7392156138278 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33fe0f3c-2bf2-4a61-8de3-0c492abc9188">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672162909803426 139.73908106831215 45.498 35.67228149710365 139.73925740812174 45.498 35.67216211596057 139.73909177330856 45.498 35.672162909803426 139.73908106831215 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a48f33c-a39a-43cf-873d-429876e05407">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672162909803426 139.73908106831215 45.498 35.67216211596057 139.73909177330856 45.498 35.6720806270354 139.7391662561855 45.498 35.672162909803426 139.73908106831215 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01456262-79d5-4fc1-88bd-297367865595">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672197277832 139.73934460867562 45.498 35.672198134732994 139.73933382627746 45.498 35.67228149710365 139.73925740812174 45.498 35.672197277832 139.73934460867562 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f5590c4c-c114-4ed7-bba7-fa6b7a75b715">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672198134732994 139.73933382627746 45.498 35.672197277832 139.73934460867562 45.498 35.6720806270354 139.7391662561855 45.498 35.672198134732994 139.73933382627746 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e446988-2951-4c9e-912e-bb72a4eb9909">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67228149710365 139.73925740812174 45.498 35.672272870214556 139.73925644615102 45.498 35.67216211596057 139.73909177330856 45.498 35.67228149710365 139.73925740812174 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16a16a86-baf6-4cac-bd3d-4a36e0bb1c88">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67216211596057 139.73909177330856 45.498 35.672089190872626 139.73916727345085 45.498 35.6720806270354 139.7391662561855 45.498 35.67216211596057 139.73909177330856 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-83944407-a14a-4a22-b857-bd6fa3642953">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67228149710365 139.73925740812174 45.498 35.672198134732994 139.73933382627746 45.498 35.672272870214556 139.73925644615102 45.498 35.67228149710365 139.73925740812174 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8fe4db75-7561-4761-98db-9c444bfd3fda">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672089190872626 139.73916727345085 45.498 35.672198134732994 139.73933382627746 45.498 35.6720806270354 139.7391662561855 45.498 35.672089190872626 139.73916727345085 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e72ad00f-3dfc-4ad9-b510-1ec95cfa7d71">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672132941874274 139.7392112976015 45.498 35.67212716872527 139.73921724739617 47.095 35.672132941874274 139.7392112976015 47.095 35.672132941874274 139.7392112976015 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-21f3bc99-1db9-43c6-b7de-8e7c7d622b00">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672132941874274 139.7392112976015 45.498 35.67212716872527 139.73921724739617 45.498 35.67212716872527 139.73921724739617 47.095 35.672132941874274 139.7392112976015 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82ce9873-ac5d-4c41-bb66-cc0264b5db96">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67216728728297 139.73926140841527 45.498 35.67216151412289 139.73926734716238 45.498 35.67212716872527 139.73921724739617 45.498 35.67216728728297 139.73926140841527 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a97ceea-fa12-4218-a63c-470412828d5b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672132941874274 139.7392112976015 45.498 35.67216728728297 139.73926140841527 45.498 35.67212716872527 139.73921724739617 45.498 35.672132941874274 139.7392112976015 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b536ce51-81b6-4d8a-98f1-17404c31f896">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67222959544152 139.73927969461093 45.498 35.672196177187125 139.7392971873005 45.498 35.67222326936865 139.73927015784489 45.498 35.67222959544152 139.73927969461093 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a9b92ed-cc31-4f09-8a5c-d60704dd0289">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67222959544152 139.73927969461093 45.498 35.6722025122716 139.73930672405493 45.498 35.672196177187125 139.7392971873005 45.498 35.67222959544152 139.73927969461093 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-014bd7f3-17ec-46d8-8960-c836e935ccca">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672183142794346 139.73928495201181 45.498 35.67218877408497 139.7392935616825 45.498 35.672180442778135 139.73930174587036 45.498 35.672183142794346 139.73928495201181 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ee213d4-32b7-493a-8191-eb7e729d6d5e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67217481147945 139.7392931251535 45.498 35.672183142794346 139.73928495201181 45.498 35.672180442778135 139.73930174587036 45.498 35.67217481147945 139.7392931251535 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-529ffb48-de61-49a5-9505-3ea696541eaa">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67217481147945 139.7392931251535 45.498 35.672180442778135 139.73930174587036 47.429 35.67217481147945 139.7392931251535 47.429 35.67217481147945 139.7392931251535 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1a3aa9f-db18-4dcd-b67f-bb4ed63bf60c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67217481147945 139.7392931251535 45.498 35.672180442778135 139.73930174587036 45.498 35.672180442778135 139.73930174587036 47.429 35.67217481147945 139.7392931251535 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-ae1849c3-d81c-42e2-a766-47a1da1aa558">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ae1849c3-d81c-42e2-a766-47a1da1aa558">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ae1849c3-d81c-42e2-a766-47a1da1aa558">
											<gml:posList>35.67216192283749 139.73907535842943 9.43 35.67229638593865 139.73927812497507 9.43 35.67220956112688 139.73936461055408 9.43 35.6720750982559 139.73916195454717 9.43 35.67216192283749 139.73907535842943 9.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9502c165-cafc-4259-9d13-df4981bbfd1d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9502c165-cafc-4259-9d13-df4981bbfd1d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9502c165-cafc-4259-9d13-df4981bbfd1d">
											<gml:posList>35.67229638593865 139.73927812497507 45.498 35.67216192283749 139.73907535842943 45.498 35.6720750982559 139.73916195454717 45.498 35.67220956112688 139.73936461055408 45.498 35.67229638593865 139.73927812497507 45.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-88c7d700-3ecb-499d-a2b1-1ca0b3c17aee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-88c7d700-3ecb-499d-a2b1-1ca0b3c17aee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-88c7d700-3ecb-499d-a2b1-1ca0b3c17aee">
											<gml:posList>35.67216192283749 139.73907535842943 9.43 35.6720750982559 139.73916195454717 9.43 35.6720750982559 139.73916195454717 45.498 35.67216192283749 139.73907535842943 45.498 35.67216192283749 139.73907535842943 9.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-477a4d77-81e4-4e3e-8cfc-fc33fc114dc4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-477a4d77-81e4-4e3e-8cfc-fc33fc114dc4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-477a4d77-81e4-4e3e-8cfc-fc33fc114dc4">
											<gml:posList>35.67229638593865 139.73927812497507 9.43 35.67216192283749 139.73907535842943 9.43 35.67216192283749 139.73907535842943 45.498 35.67229638593865 139.73927812497507 45.498 35.67229638593865 139.73927812497507 9.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-36fafe0d-6cae-45ef-8e74-69d5dd12309d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36fafe0d-6cae-45ef-8e74-69d5dd12309d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36fafe0d-6cae-45ef-8e74-69d5dd12309d">
											<gml:posList>35.6720750982559 139.73916195454717 9.43 35.67220956112688 139.73936461055408 9.43 35.67220956112688 139.73936461055408 45.498 35.6720750982559 139.73916195454717 45.498 35.6720750982559 139.73916195454717 9.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-822b78bf-2e66-4558-9052-54689a224d4d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-822b78bf-2e66-4558-9052-54689a224d4d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-822b78bf-2e66-4558-9052-54689a224d4d">
											<gml:posList>35.67220956112688 139.73936461055408 9.43 35.67229638593865 139.73927812497507 9.43 35.67229638593865 139.73927812497507 45.498 35.67220956112688 139.73936461055408 45.498 35.67220956112688 139.73936461055408 9.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-11391</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">293.6311</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1241</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.06</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>