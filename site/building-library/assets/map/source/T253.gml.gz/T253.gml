<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_46830f78-f07d-43c4-a7f0-da1738cfa0af">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">20</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.670639626178286 139.73854206558534 0 35.67080435786894 139.73849216239623 0 35.670782549661055 139.73838415523582 0 35.67062367562822 139.73843239475596 0 35.67063923979829 139.7385092585462 0 35.670633382270914 139.7385110328809 0 35.670639626178286 139.73854206558534 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670639626178286 139.73854206558534 17.78 35.670633382270914 139.7385110328809 17.78 35.67063923979829 139.7385092585462 17.78 35.67062367562822 139.73843239475596 17.78 35.670782549661055 139.73838415523582 17.78 35.67080435786894 139.73849216239623 17.78 35.670639626178286 139.73854206558534 17.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670639626178286 139.73854206558534 17.78 35.67080435786894 139.73849216239623 17.78 35.67080435786894 139.73849216239623 37.73 35.670639626178286 139.73854206558534 37.73 35.670639626178286 139.73854206558534 17.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67080435786894 139.73849216239623 17.78 35.670782549661055 139.73838415523582 17.78 35.670782549661055 139.73838415523582 37.73 35.67080435786894 139.73849216239623 37.73 35.67080435786894 139.73849216239623 17.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670782549661055 139.73838415523582 17.78 35.67062367562822 139.73843239475596 17.78 35.67062367562822 139.73843239475596 37.73 35.670782549661055 139.73838415523582 37.73 35.670782549661055 139.73838415523582 17.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67062367562822 139.73843239475596 17.78 35.67063923979829 139.7385092585462 17.78 35.67063923979829 139.7385092585462 37.73 35.67062367562822 139.73843239475596 37.73 35.67062367562822 139.73843239475596 17.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67063923979829 139.7385092585462 17.78 35.670633382270914 139.7385110328809 17.78 35.670633382270914 139.7385110328809 37.73 35.67063923979829 139.7385092585462 37.73 35.67063923979829 139.7385092585462 17.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670633382270914 139.7385110328809 17.78 35.670639626178286 139.73854206558534 17.78 35.670639626178286 139.73854206558534 37.73 35.670633382270914 139.7385110328809 37.73 35.670633382270914 139.7385110328809 17.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670639626178286 139.73854206558534 37.73 35.67080435786894 139.73849216239623 37.73 35.670782549661055 139.73838415523582 37.73 35.67062367562822 139.73843239475596 37.73 35.67063923979829 139.7385092585462 37.73 35.670633382270914 139.7385110328809 37.73 35.670639626178286 139.73854206558534 37.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-d5763ec6-15a3-4334-8881-61d13e0f16d7"/>
							<gml:surfaceMember xlink:href="#poly-8d455a9d-1ac8-4314-a8bd-f169e71b35a7"/>
							<gml:surfaceMember xlink:href="#poly-4d7905f4-a764-4b21-997d-65b792984ca3"/>
							<gml:surfaceMember xlink:href="#poly-a248f101-eb43-4c19-b37b-ebe8a0fc68ea"/>
							<gml:surfaceMember xlink:href="#poly-795e5f64-9417-487d-9cfc-c2e1227dd236"/>
							<gml:surfaceMember xlink:href="#poly-da2023cb-ff1c-4e44-8f32-f6e6fff58d5b"/>
							<gml:surfaceMember xlink:href="#poly-e2f10590-915b-494c-b719-14558c262f45"/>
							<gml:surfaceMember xlink:href="#poly-049ef82c-f2a2-411c-9ce3-2aa73fc4fecc"/>
							<gml:surfaceMember xlink:href="#poly-8a0dc17d-3705-4f54-aaa9-f21b864dc9a1"/>
							<gml:surfaceMember xlink:href="#poly-37b65519-5d94-475c-993d-71e6b158d6f1"/>
							<gml:surfaceMember xlink:href="#poly-7313fe60-7863-4194-a8da-30a0e368342c"/>
							<gml:surfaceMember xlink:href="#poly-9a663f19-614c-44e0-8190-00ab97319887"/>
							<gml:surfaceMember xlink:href="#poly-bd33a019-a22e-4ebd-905b-b70cc2396020"/>
							<gml:surfaceMember xlink:href="#poly-f1c2257a-a8b0-4394-96b8-94b0c7f6ea3f"/>
							<gml:surfaceMember xlink:href="#poly-142509b7-c216-4f87-93b9-c7238b3e7fc7"/>
							<gml:surfaceMember xlink:href="#poly-2b5b88e9-b927-47a1-97b5-636a312772fc"/>
							<gml:surfaceMember xlink:href="#poly-65e6c564-9dc6-414e-b423-84ce0c5f8bd8"/>
							<gml:surfaceMember xlink:href="#poly-ec0755e5-7bab-4f77-a2ad-b78d16f39264"/>
							<gml:surfaceMember xlink:href="#poly-7783c882-ce81-40ec-9b24-20766bb92a9f"/>
							<gml:surfaceMember xlink:href="#poly-954b44fb-77c3-4721-8a8b-9e4fac5e9231"/>
							<gml:surfaceMember xlink:href="#poly-0020a2ff-c540-4cd9-8880-f4eaf34e4775"/>
							<gml:surfaceMember xlink:href="#poly-449fdb60-37b7-467e-9391-36e48bde14e1"/>
							<gml:surfaceMember xlink:href="#poly-2a4f3685-de54-428a-9bba-db52513601da"/>
							<gml:surfaceMember xlink:href="#poly-e931ad9d-286e-42c9-8e19-7d6d523d58e6"/>
							<gml:surfaceMember xlink:href="#poly-31b6761a-46f6-4920-94f8-25ae28919e07"/>
							<gml:surfaceMember xlink:href="#poly-572b9bcd-b5e0-4be4-91ca-c787c0cec0e0"/>
							<gml:surfaceMember xlink:href="#poly-6b901201-ac3a-4756-862d-48a33fcde97a"/>
							<gml:surfaceMember xlink:href="#poly-e7ea8354-a705-49b1-a8df-deb32460adc4"/>
							<gml:surfaceMember xlink:href="#poly-78b79e36-3a4a-4089-a731-f9f5fada138c"/>
							<gml:surfaceMember xlink:href="#poly-9bc7f591-bd90-4342-bdcb-3d6585a310d7"/>
							<gml:surfaceMember xlink:href="#poly-2526a638-73ca-4e07-9d13-83b7f510475b"/>
							<gml:surfaceMember xlink:href="#poly-2f956c5a-879e-4393-922c-5f6d195df196"/>
							<gml:surfaceMember xlink:href="#poly-82a274ce-fc79-432e-be08-49658d715db6"/>
							<gml:surfaceMember xlink:href="#poly-865d1236-ebf2-4acf-a2a5-a46879420e3e"/>
							<gml:surfaceMember xlink:href="#poly-23253a7c-f117-4870-92d1-16ae2ea21992"/>
							<gml:surfaceMember xlink:href="#poly-b0711f2d-4939-4bfa-84a5-2d4d4ed0cee5"/>
							<gml:surfaceMember xlink:href="#poly-9ae4f3ee-fff3-4a1c-8004-073c6b9fdee3"/>
							<gml:surfaceMember xlink:href="#poly-76d1e39f-6915-406b-979b-391aa497d3d3"/>
							<gml:surfaceMember xlink:href="#poly-cd42919f-3682-46ca-b507-bb52b8cc7b01"/>
							<gml:surfaceMember xlink:href="#poly-85590470-9d99-46a9-a77e-7612ed6e13d6"/>
							<gml:surfaceMember xlink:href="#poly-75ac99ae-d76c-495a-a3d6-f7ff084b2aaa"/>
							<gml:surfaceMember xlink:href="#poly-f7efc062-388c-487d-80ea-962cbcba9ce6"/>
							<gml:surfaceMember xlink:href="#poly-9d7088de-f1cb-450c-8b4d-684d7c8f7eb1"/>
							<gml:surfaceMember xlink:href="#poly-b4eb3405-6995-4b2a-8f1d-6acdf059a7a3"/>
							<gml:surfaceMember xlink:href="#poly-485467ed-3d90-4e37-bb7f-e54e39d55b3c"/>
							<gml:surfaceMember xlink:href="#poly-8f892316-fc86-431a-b6f4-d8468c95c1ee"/>
							<gml:surfaceMember xlink:href="#poly-d14b528d-1302-4ded-812f-d1459731a88f"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_46830f78-f07d-43c4-a7f0-da1738cfa0af_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f322494-86cb-43ae-a0d4-a4f3bbc21fd0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670722138214224 139.73850816633546 38.205 35.67072018364705 139.73849851417563 38.205 35.67075622101098 139.73848766825748 36.155 35.670758103286545 139.7384970885344 36.156 35.670722138214224 139.73850816633546 38.205</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3719a9fc-2a14-42b9-923f-526c4a9f8135">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3719a9fc-2a14-42b9-923f-526c4a9f8135_0">
											<gml:posList>35.67072018364705 139.73849851417563 38.205 35.670722138214224 139.73850816633546 38.205 35.670722138214224 139.73850816633546 38.283 35.67072018364705 139.73849851417563 38.283 35.67072018364705 139.73849851417563 38.205</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6434a221-644d-4edd-a533-448c637b81d3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6434a221-644d-4edd-a533-448c637b81d3_0">
											<gml:posList>35.67072018364705 139.73849851417563 38.205 35.67072018364705 139.73849851417563 38.283 35.67075622101098 139.73848766825748 38.283 35.67075622101098 139.73848766825748 36.155 35.67072018364705 139.73849851417563 38.205</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e657ee54-fad1-4f3a-9855-e2e81e80d4ab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e657ee54-fad1-4f3a-9855-e2e81e80d4ab_0">
											<gml:posList>35.670758103286545 139.7384970885344 38.283 35.67075622101098 139.73848766825748 38.283 35.67072018364705 139.73849851417563 38.283 35.670722138214224 139.73850816633546 38.283 35.670758103286545 139.7384970885344 38.283</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ef89df0-edfb-4368-bcac-05bd577eea5f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6ef89df0-edfb-4368-bcac-05bd577eea5f_0">
											<gml:posList>35.670758103286545 139.7384970885344 38.283 35.670722138214224 139.73850816633546 38.283 35.670722138214224 139.73850816633546 38.205 35.670758103286545 139.7384970885344 36.156 35.670758103286545 139.7384970885344 38.283</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-245de11b-950b-4c06-83e4-0aec6e8a92a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-245de11b-950b-4c06-83e4-0aec6e8a92a6_0">
											<gml:posList>35.670758103286545 139.7384970885344 36.156 35.67075622101098 139.73848766825748 36.155 35.67075622101098 139.73848766825748 38.283 35.670758103286545 139.7384970885344 38.283 35.670758103286545 139.7384970885344 36.156</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_46830f78-f07d-43c4-a7f0-da1738cfa0af_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d318b189-a0ad-4bcd-b94f-6a76c35bd5e4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670679040985114 139.73844767253416 37.793 35.670700677786385 139.7384411185626 37.793 35.67070530186782 139.73846404521697 37.793 35.670683665065305 139.73847059918273 37.793 35.670679040985114 139.73844767253416 37.793</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b0d56f5-d932-41ef-8d55-21933ada71f1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670702595698046 139.73851866134436 37.793 35.67067717402521 139.73852635753968 37.793 35.67067386205165 139.7385099135157 37.793 35.67069927470972 139.73850221732621 37.793 35.670702595698046 139.73851866134436 37.793</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f16ed128-8777-4254-b74e-5743075b3e20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67066963462255 139.73852137352762 37.793 35.67065470243416 139.7385258980747 37.793 35.67065168004787 139.73851091182405 37.793 35.67066661223569 139.73850638727436 37.793 35.67066963462255 139.73852137352762 37.793</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-628ef680-6f6b-4aa2-9e03-70c1b13cbaab">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67067717402521 139.73852635753968 38.701 35.670702595698046 139.73851866134436 38.701 35.67070341915621 139.73852273645667 38.701 35.67067799749182 139.73853044369702 38.701 35.67067717402521 139.73852635753968 38.701</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-32c03eea-1652-4550-9681-aa02a2b07b07">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-32c03eea-1652-4550-9681-aa02a2b07b07_0">
											<gml:posList>35.670679040985114 139.73844767253416 37.793 35.670679040985114 139.73844767253416 40.926 35.670700677786385 139.7384411185626 40.926 35.670700677786385 139.7384411185626 37.793 35.670679040985114 139.73844767253416 37.793</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d207d93e-b814-4d9c-a34a-95475f026718">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d207d93e-b814-4d9c-a34a-95475f026718_0">
											<gml:posList>35.67070530186782 139.73846404521697 37.793 35.670700677786385 139.7384411185626 37.793 35.670700677786385 139.7384411185626 40.926 35.67070530186782 139.73846404521697 40.926 35.67070530186782 139.73846404521697 37.793</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-42048a3d-87e8-439a-a62a-177322aa7a3d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-42048a3d-87e8-439a-a62a-177322aa7a3d_0">
											<gml:posList>35.67070530186782 139.73846404521697 40.926 35.670700677786385 139.7384411185626 40.926 35.670679040985114 139.73844767253416 40.926 35.670683665065305 139.73847059918273 40.926 35.67070530186782 139.73846404521697 40.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd41616f-2f05-46d6-9c2b-5dc182dd01b6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cd41616f-2f05-46d6-9c2b-5dc182dd01b6_0">
											<gml:posList>35.670679040985114 139.73844767253416 37.793 35.670683665065305 139.73847059918273 37.793 35.670683665065305 139.73847059918273 40.926 35.670679040985114 139.73844767253416 40.926 35.670679040985114 139.73844767253416 37.793</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8c159c8-c067-4732-9e56-93de7245009f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b8c159c8-c067-4732-9e56-93de7245009f_0">
											<gml:posList>35.670683665065305 139.73847059918273 37.793 35.67070530186782 139.73846404521697 37.793 35.67070530186782 139.73846404521697 40.926 35.670683665065305 139.73847059918273 40.926 35.670683665065305 139.73847059918273 37.793</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-594c86c6-5414-4dba-a49c-5b696332a350">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-594c86c6-5414-4dba-a49c-5b696332a350_0">
											<gml:posList>35.67069927470972 139.73850221732621 37.793 35.67067386205165 139.7385099135157 37.793 35.67067386205165 139.7385099135157 40.321 35.67069927470972 139.73850221732621 40.321 35.67069927470972 139.73850221732621 37.793</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53b1dee0-142c-430b-822d-7d55b8a8f661">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-53b1dee0-142c-430b-822d-7d55b8a8f661_0">
											<gml:posList>35.67066661223569 139.73850638727436 37.793 35.67065168004787 139.73851091182405 37.793 35.67065168004787 139.73851091182405 39.744 35.67066661223569 139.73850638727436 39.744 35.67066661223569 139.73850638727436 37.793</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a305b0e-74c4-404c-ad18-f979addb3d0a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2a305b0e-74c4-404c-ad18-f979addb3d0a_0">
											<gml:posList>35.67069927470972 139.73850221732621 37.793 35.67069927470972 139.73850221732621 40.321 35.67070341915621 139.73852273645667 40.321 35.67070341915621 139.73852273645667 38.701 35.670702595698046 139.73851866134436 38.701 35.670702595698046 139.73851866134436 37.793 35.67069927470972 139.73850221732621 37.793</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46765e00-865a-48da-988c-940f4f7c384d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46765e00-865a-48da-988c-940f4f7c384d_0">
											<gml:posList>35.67066661223569 139.73850638727436 37.793 35.67066661223569 139.73850638727436 39.744 35.67066963462255 139.73852137352762 39.744 35.67066963462255 139.73852137352762 37.793 35.67066661223569 139.73850638727436 37.793</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b5ada05-7c87-4b63-96e4-338c9bbde1a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b5ada05-7c87-4b63-96e4-338c9bbde1a5_0">
											<gml:posList>35.67065168004787 139.73851091182405 39.744 35.67065470243416 139.7385258980747 39.744 35.67066963462255 139.73852137352762 39.744 35.67066661223569 139.73850638727436 39.744 35.67065168004787 139.73851091182405 39.744</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d082c9e6-f971-4996-b254-1c73c5a08630">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d082c9e6-f971-4996-b254-1c73c5a08630_0">
											<gml:posList>35.67069927470972 139.73850221732621 40.321 35.67067386205165 139.7385099135157 40.321 35.67067799749182 139.73853044369702 40.321 35.67070341915621 139.73852273645667 40.321 35.67069927470972 139.73850221732621 40.321</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-32b457c9-d79a-4e3f-a9ce-3f154771123c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-32b457c9-d79a-4e3f-a9ce-3f154771123c_0">
											<gml:posList>35.67065168004787 139.73851091182405 37.793 35.67065470243416 139.7385258980747 37.793 35.67065470243416 139.7385258980747 39.744 35.67065168004787 139.73851091182405 39.744 35.67065168004787 139.73851091182405 37.793</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58fcf93c-c64b-4a5d-848b-f9e3fb7b2166">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-58fcf93c-c64b-4a5d-848b-f9e3fb7b2166_0">
											<gml:posList>35.67067799749182 139.73853044369702 40.321 35.67067386205165 139.7385099135157 40.321 35.67067386205165 139.7385099135157 37.793 35.67067717402521 139.73852635753968 37.793 35.67067717402521 139.73852635753968 38.701 35.67067799749182 139.73853044369702 38.701 35.67067799749182 139.73853044369702 40.321</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4ff01df7-128c-4663-bc83-a58f039d4936">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4ff01df7-128c-4663-bc83-a58f039d4936_0">
											<gml:posList>35.670702595698046 139.73851866134436 38.701 35.67067717402521 139.73852635753968 38.701 35.67067717402521 139.73852635753968 37.793 35.670702595698046 139.73851866134436 37.793 35.670702595698046 139.73851866134436 38.701</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-116ad25a-2848-492c-8978-060c913144be">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-116ad25a-2848-492c-8978-060c913144be_0">
											<gml:posList>35.67065470243416 139.7385258980747 37.793 35.67066963462255 139.73852137352762 37.793 35.67066963462255 139.73852137352762 39.744 35.67065470243416 139.7385258980747 39.744 35.67065470243416 139.7385258980747 37.793</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-abb9e557-9821-4e53-bbc4-8e7729ea4d58">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-abb9e557-9821-4e53-bbc4-8e7729ea4d58_0">
											<gml:posList>35.67067799749182 139.73853044369702 38.701 35.67070341915621 139.73852273645667 38.701 35.67070341915621 139.73852273645667 40.321 35.67067799749182 139.73853044369702 40.321 35.67067799749182 139.73853044369702 38.701</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-d5763ec6-15a3-4334-8881-61d13e0f16d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5763ec6-15a3-4334-8881-61d13e0f16d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5763ec6-15a3-4334-8881-61d13e0f16d7">
											<gml:posList>35.67080435786892 139.73849216239623 17.78 35.670639626178286 139.73854206558534 17.78 35.67063338227091 139.7385110328809 17.78 35.67063923979828 139.7385092585462 17.78 35.670623675628214 139.73843239475593 17.78 35.670782549661055 139.73838415523582 17.78 35.67080435786892 139.73849216239623 17.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8d455a9d-1ac8-4314-a8bd-f169e71b35a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d455a9d-1ac8-4314-a8bd-f169e71b35a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d455a9d-1ac8-4314-a8bd-f169e71b35a7">
											<gml:posList>35.67062783338286 139.73843547175048 38.701 35.670623675628214 139.73843239475593 38.701 35.67063923979828 139.7385092585462 38.701 35.67064339754227 139.73851232449903 38.701 35.67062783338286 139.73843547175048 38.701</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4d7905f4-a764-4b21-997d-65b792984ca3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d7905f4-a764-4b21-997d-65b792984ca3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d7905f4-a764-4b21-997d-65b792984ca3">
											<gml:posList>35.67063754001485 139.73851409883358 38.701 35.67063338227091 139.7385110328809 38.701 35.670639626178286 139.73854206558534 38.701 35.67064213700648 139.73853698132098 38.701 35.67063754001485 139.73851409883358 38.701</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a248f101-eb43-4c19-b37b-ebe8a0fc68ea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a248f101-eb43-4c19-b37b-ebe8a0fc68ea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a248f101-eb43-4c19-b37b-ebe8a0fc68ea">
											<gml:posList>35.67063754001485 139.73851409883358 38.701 35.67064339754227 139.73851232449903 38.701 35.67063923979828 139.7385092585462 38.701 35.67063338227091 139.7385110328809 38.701 35.67063754001485 139.73851409883358 38.701</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-795e5f64-9417-487d-9cfc-c2e1227dd236">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-795e5f64-9417-487d-9cfc-c2e1227dd236">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-795e5f64-9417-487d-9cfc-c2e1227dd236">
											<gml:posList>35.67070226897156 139.73841286023475 38.701 35.67070144550967 139.73840878512362 38.701 35.670623675628214 139.73843239475593 38.701 35.67062783338286 139.73843547175048 38.701 35.670699178005165 139.73841380282988 38.701 35.67070226897156 139.73841286023475 38.701</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-da2023cb-ff1c-4e44-8f32-f6e6fff58d5b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da2023cb-ff1c-4e44-8f32-f6e6fff58d5b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da2023cb-ff1c-4e44-8f32-f6e6fff58d5b">
											<gml:posList>35.67064213700648 139.73853698132098 38.701 35.670639626178286 139.73854206558534 38.701 35.67072383939613 139.7385165484702 38.701 35.670719681652294 139.73851348251407 38.701 35.67064213700648 139.73853698132098 38.701</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e2f10590-915b-494c-b719-14558c262f45">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e2f10590-915b-494c-b719-14558c262f45">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e2f10590-915b-494c-b719-14558c262f45">
											<gml:posList>35.670716016880334 139.73849543718495 37.793 35.67076755419062 139.73847993347823 37.793 35.670753356307635 139.73840970678575 37.793 35.670701349761714 139.73842453726576 37.793 35.670699178005165 139.73841380282988 37.793 35.67062783338286 139.73843547175048 37.793 35.67064339754227 139.73851232449903 37.793 35.67063754001485 139.73851409883358 37.793 35.67064213700648 139.73853698132098 37.793 35.670719681652294 139.73851348251407 37.793 35.670716016880334 139.73849543718495 37.793</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-049ef82c-f2a2-411c-9ce3-2aa73fc4fecc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-049ef82c-f2a2-411c-9ce3-2aa73fc4fecc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-049ef82c-f2a2-411c-9ce3-2aa73fc4fecc">
											<gml:posList>35.670719681652294 139.73851348251407 38.701 35.67072383939613 139.7385165484702 38.701 35.67072017463333 139.73849851418632 38.701 35.670716016880334 139.73849543718495 38.701 35.670719681652294 139.73851348251407 38.701</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8a0dc17d-3705-4f54-aaa9-f21b864dc9a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a0dc17d-3705-4f54-aaa9-f21b864dc9a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a0dc17d-3705-4f54-aaa9-f21b864dc9a1">
											<gml:posList>35.670701349761714 139.73842453726576 38.701 35.670753356307635 139.73840970678575 38.701 35.67075271385158 139.73840655934785 38.701 35.67070398827461 139.7384213528069 38.701 35.67070226897156 139.73841286023475 38.701 35.670699178005165 139.73841380282988 38.701 35.670701349761714 139.73842453726576 38.701</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-37b65519-5d94-475c-993d-71e6b158d6f1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37b65519-5d94-475c-993d-71e6b158d6f1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37b65519-5d94-475c-993d-71e6b158d6f1">
											<gml:posList>35.67070144550967 139.73840878512362 37.396 35.67070398827461 139.7384213528069 37.396 35.67075271385158 139.73840655934785 37.396 35.6707501710764 139.7383939806111 37.396 35.67070144550967 139.73840878512362 37.396</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7313fe60-7863-4194-a8da-30a0e368342c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7313fe60-7863-4194-a8da-30a0e368342c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7313fe60-7863-4194-a8da-30a0e368342c">
											<gml:posList>35.6707598406633 139.73850564737077 36.155 35.670756230050806 139.7384877013857 36.155 35.67072018364705 139.73849851417563 38.205 35.67072383939613 139.7385165484702 38.205 35.6707598406633 139.73850564737077 36.155</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9a663f19-614c-44e0-8190-00ab97319887">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a663f19-614c-44e0-8190-00ab97319887">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a663f19-614c-44e0-8190-00ab97319887">
											<gml:posList>35.67076755419062 139.73847993347823 38.701 35.670716016880334 139.73849543718495 38.701 35.67072017463333 139.73849851418632 38.701 35.670771702921556 139.7384829994451 38.701 35.67076755419062 139.73847993347823 38.701</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bd33a019-a22e-4ebd-905b-b70cc2396020">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd33a019-a22e-4ebd-905b-b70cc2396020">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd33a019-a22e-4ebd-905b-b70cc2396020">
											<gml:posList>35.6707501710764 139.7383939806111 38.701 35.67075271385158 139.73840655934785 38.701 35.670753356307635 139.73840970678575 38.701 35.67076755419062 139.73847993347823 38.701 35.670771702921556 139.7384829994451 38.701 35.67075350536083 139.7383929714486 38.701 35.6707501710764 139.7383939806111 38.701</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f1c2257a-a8b0-4394-96b8-94b0c7f6ea3f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f1c2257a-a8b0-4394-96b8-94b0c7f6ea3f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f1c2257a-a8b0-4394-96b8-94b0c7f6ea3f">
											<gml:posList>35.67078048881998 139.73838834422952 33.345 35.670782549661055 139.73838415523582 33.345 35.67075350536083 139.7383929714486 33.345 35.6707541840376 139.73839632872344 33.345 35.67078048881998 139.73838834422952 33.345</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-142509b7-c216-4f87-93b9-c7238b3e7fc7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-142509b7-c216-4f87-93b9-c7238b3e7fc7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-142509b7-c216-4f87-93b9-c7238b3e7fc7">
											<gml:posList>35.670771702921556 139.7384829994451 36.155 35.670756230050806 139.7384877013857 36.155 35.6707598406633 139.73850564737077 36.155 35.67078763237771 139.73849723034706 36.155 35.670776574419406 139.73844242057123 36.155 35.67076425559553 139.73844615775812 36.155 35.670771702921556 139.7384829994451 36.155</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2b5b88e9-b927-47a1-97b5-636a312772fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b5b88e9-b927-47a1-97b5-636a312772fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b5b88e9-b927-47a1-97b5-636a312772fc">
											<gml:posList>35.67078048881998 139.73838834422952 32.871 35.6707541840376 139.73839632872344 32.871 35.67076425559553 139.73844615775812 32.871 35.670776574419406 139.73844242057123 32.871 35.6707788638479 139.73845378451892 32.871 35.67079284081375 139.73844955933234 32.871 35.67078048881998 139.73838834422952 32.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-65e6c564-9dc6-414e-b423-84ce0c5f8bd8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65e6c564-9dc6-414e-b423-84ce0c5f8bd8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65e6c564-9dc6-414e-b423-84ce0c5f8bd8">
											<gml:posList>35.67079284081375 139.73844955933234 33.345 35.6707788638479 139.73845378451892 33.345 35.67077954252297 139.73845714179532 33.345 35.67079625899879 139.7384520738473 33.345 35.67079284081375 139.73844955933234 33.345</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ec0755e5-7bab-4f77-a2ad-b78d16f39264">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec0755e5-7bab-4f77-a2ad-b78d16f39264">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec0755e5-7bab-4f77-a2ad-b78d16f39264">
											<gml:posList>35.67079284081375 139.73844955933234 33.345 35.67079625899879 139.7384520738473 33.345 35.670782549661055 139.73838415523582 33.345 35.67078048881998 139.73838834422952 33.345 35.67079284081375 139.73844955933234 33.345</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7783c882-ce81-40ec-9b24-20766bb92a9f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7783c882-ce81-40ec-9b24-20766bb92a9f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7783c882-ce81-40ec-9b24-20766bb92a9f">
											<gml:posList>35.67077954252297 139.73845714179532 27.191 35.67078763237771 139.73849723034706 27.191 35.67080435786892 139.73849216239623 27.191 35.67079625899879 139.7384520738473 27.191 35.67077954252297 139.73845714179532 27.191</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-954b44fb-77c3-4721-8a8b-9e4fac5e9231">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-954b44fb-77c3-4721-8a8b-9e4fac5e9231">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-954b44fb-77c3-4721-8a8b-9e4fac5e9231">
											<gml:posList>35.67064339754227 139.73851232449903 37.793 35.67064339754227 139.73851232449903 38.701 35.67063754001485 139.73851409883358 38.701 35.67063754001485 139.73851409883358 37.793 35.67064339754227 139.73851232449903 37.793</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0020a2ff-c540-4cd9-8880-f4eaf34e4775">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0020a2ff-c540-4cd9-8880-f4eaf34e4775">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0020a2ff-c540-4cd9-8880-f4eaf34e4775">
											<gml:posList>35.67063923979828 139.7385092585462 17.78 35.67063923979828 139.7385092585462 38.701 35.670623675628214 139.73843239475593 38.701 35.670623675628214 139.73843239475593 17.78 35.67063923979828 139.7385092585462 17.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-449fdb60-37b7-467e-9391-36e48bde14e1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-449fdb60-37b7-467e-9391-36e48bde14e1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-449fdb60-37b7-467e-9391-36e48bde14e1">
											<gml:posList>35.67062783338286 139.73843547175048 37.793 35.67062783338286 139.73843547175048 38.701 35.67064339754227 139.73851232449903 38.701 35.67064339754227 139.73851232449903 37.793 35.67062783338286 139.73843547175048 37.793</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2a4f3685-de54-428a-9bba-db52513601da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a4f3685-de54-428a-9bba-db52513601da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a4f3685-de54-428a-9bba-db52513601da">
											<gml:posList>35.67063338227091 139.7385110328809 17.78 35.67063338227091 139.7385110328809 38.701 35.67063923979828 139.7385092585462 38.701 35.67063923979828 139.7385092585462 17.78 35.67063338227091 139.7385110328809 17.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e931ad9d-286e-42c9-8e19-7d6d523d58e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e931ad9d-286e-42c9-8e19-7d6d523d58e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e931ad9d-286e-42c9-8e19-7d6d523d58e6">
											<gml:posList>35.670639626178286 139.73854206558534 17.78 35.670639626178286 139.73854206558534 38.701 35.67063338227091 139.7385110328809 38.701 35.67063338227091 139.7385110328809 17.78 35.670639626178286 139.73854206558534 17.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-31b6761a-46f6-4920-94f8-25ae28919e07">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31b6761a-46f6-4920-94f8-25ae28919e07">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31b6761a-46f6-4920-94f8-25ae28919e07">
											<gml:posList>35.67063754001485 139.73851409883358 37.793 35.67063754001485 139.73851409883358 38.701 35.67064213700648 139.73853698132098 38.701 35.67064213700648 139.73853698132098 37.793 35.67063754001485 139.73851409883358 37.793</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-572b9bcd-b5e0-4be4-91ca-c787c0cec0e0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-572b9bcd-b5e0-4be4-91ca-c787c0cec0e0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-572b9bcd-b5e0-4be4-91ca-c787c0cec0e0">
											<gml:posList>35.670699178005165 139.73841380282988 37.793 35.670699178005165 139.73841380282988 38.701 35.67062783338286 139.73843547175048 38.701 35.67062783338286 139.73843547175048 37.793 35.670699178005165 139.73841380282988 37.793</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6b901201-ac3a-4756-862d-48a33fcde97a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b901201-ac3a-4756-862d-48a33fcde97a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b901201-ac3a-4756-862d-48a33fcde97a">
											<gml:posList>35.67064213700648 139.73853698132098 37.793 35.67064213700648 139.73853698132098 38.701 35.670719681652294 139.73851348251407 38.701 35.670719681652294 139.73851348251407 37.793 35.67064213700648 139.73853698132098 37.793</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e7ea8354-a705-49b1-a8df-deb32460adc4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e7ea8354-a705-49b1-a8df-deb32460adc4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e7ea8354-a705-49b1-a8df-deb32460adc4">
											<gml:posList>35.670701349761714 139.73842453726576 37.793 35.670701349761714 139.73842453726576 38.701 35.670699178005165 139.73841380282988 38.701 35.670699178005165 139.73841380282988 37.793 35.670701349761714 139.73842453726576 37.793</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-78b79e36-3a4a-4089-a731-f9f5fada138c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78b79e36-3a4a-4089-a731-f9f5fada138c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78b79e36-3a4a-4089-a731-f9f5fada138c">
											<gml:posList>35.67070226897156 139.73841286023475 38.701 35.67070398827461 139.7384213528069 38.701 35.67070398827461 139.7384213528069 37.396 35.67070144550967 139.73840878512362 37.396 35.67070144550967 139.73840878512362 38.701 35.67070226897156 139.73841286023475 38.701</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9bc7f591-bd90-4342-bdcb-3d6585a310d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9bc7f591-bd90-4342-bdcb-3d6585a310d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9bc7f591-bd90-4342-bdcb-3d6585a310d7">
											<gml:posList>35.67075350536083 139.7383929714486 33.345 35.670782549661055 139.73838415523582 33.345 35.670782549661055 139.73838415523582 17.78 35.670623675628214 139.73843239475593 17.78 35.670623675628214 139.73843239475593 38.701 35.67070144550967 139.73840878512362 38.701 35.67070144550967 139.73840878512362 37.396 35.6707501710764 139.7383939806111 37.396 35.6707501710764 139.7383939806111 38.701 35.67075350536083 139.7383929714486 38.701 35.67075350536083 139.7383929714486 33.345</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2526a638-73ca-4e07-9d13-83b7f510475b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2526a638-73ca-4e07-9d13-83b7f510475b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2526a638-73ca-4e07-9d13-83b7f510475b">
											<gml:posList>35.670719681652294 139.73851348251407 37.793 35.670719681652294 139.73851348251407 38.701 35.670716016880334 139.73849543718495 38.701 35.670716016880334 139.73849543718495 37.793 35.670719681652294 139.73851348251407 37.793</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2f956c5a-879e-4393-922c-5f6d195df196">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f956c5a-879e-4393-922c-5f6d195df196">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f956c5a-879e-4393-922c-5f6d195df196">
											<gml:posList>35.670639626178286 139.73854206558534 38.701 35.670639626178286 139.73854206558534 17.78 35.67080435786892 139.73849216239623 17.78 35.67080435786892 139.73849216239623 27.191 35.67078763237771 139.73849723034706 27.191 35.67078763237771 139.73849723034706 36.155 35.6707598406633 139.73850564737077 36.155 35.67072383939613 139.7385165484702 38.205 35.67072383939613 139.7385165484702 38.701 35.670639626178286 139.73854206558534 38.701</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-82a274ce-fc79-432e-be08-49658d715db6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-82a274ce-fc79-432e-be08-49658d715db6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-82a274ce-fc79-432e-be08-49658d715db6">
											<gml:posList>35.67072383939613 139.7385165484702 38.205 35.67072018364705 139.73849851417563 38.205 35.67072017463333 139.73849851418632 38.701 35.67072383939613 139.7385165484702 38.701 35.67072383939613 139.7385165484702 38.205</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-865d1236-ebf2-4acf-a2a5-a46879420e3e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-865d1236-ebf2-4acf-a2a5-a46879420e3e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-865d1236-ebf2-4acf-a2a5-a46879420e3e">
											<gml:posList>35.670753356307635 139.73840970678575 37.793 35.670753356307635 139.73840970678575 38.701 35.670701349761714 139.73842453726576 38.701 35.670701349761714 139.73842453726576 37.793 35.670753356307635 139.73840970678575 37.793</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-23253a7c-f117-4870-92d1-16ae2ea21992">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-23253a7c-f117-4870-92d1-16ae2ea21992">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-23253a7c-f117-4870-92d1-16ae2ea21992">
											<gml:posList>35.67070398827461 139.7384213528069 37.396 35.67070398827461 139.7384213528069 38.701 35.67075271385158 139.73840655934785 38.701 35.67075271385158 139.73840655934785 37.396 35.67070398827461 139.7384213528069 37.396</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b0711f2d-4939-4bfa-84a5-2d4d4ed0cee5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b0711f2d-4939-4bfa-84a5-2d4d4ed0cee5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b0711f2d-4939-4bfa-84a5-2d4d4ed0cee5">
											<gml:posList>35.670716016880334 139.73849543718495 37.793 35.670716016880334 139.73849543718495 38.701 35.67076755419062 139.73847993347823 38.701 35.67076755419062 139.73847993347823 37.793 35.670716016880334 139.73849543718495 37.793</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9ae4f3ee-fff3-4a1c-8004-073c6b9fdee3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ae4f3ee-fff3-4a1c-8004-073c6b9fdee3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ae4f3ee-fff3-4a1c-8004-073c6b9fdee3">
											<gml:posList>35.670771702921556 139.7384829994451 36.155 35.670771702921556 139.7384829994451 38.701 35.67072017463333 139.73849851418632 38.701 35.67072018364705 139.73849851417563 38.205 35.670756230050806 139.7384877013857 36.155 35.670771702921556 139.7384829994451 36.155</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-76d1e39f-6915-406b-979b-391aa497d3d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-76d1e39f-6915-406b-979b-391aa497d3d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-76d1e39f-6915-406b-979b-391aa497d3d3">
											<gml:posList>35.67075271385158 139.73840655934785 37.396 35.67075271385158 139.73840655934785 38.701 35.6707501710764 139.7383939806111 38.701 35.6707501710764 139.7383939806111 37.396 35.67075271385158 139.73840655934785 37.396</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cd42919f-3682-46ca-b507-bb52b8cc7b01">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd42919f-3682-46ca-b507-bb52b8cc7b01">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd42919f-3682-46ca-b507-bb52b8cc7b01">
											<gml:posList>35.67076755419062 139.73847993347823 37.793 35.67076755419062 139.73847993347823 38.701 35.670753356307635 139.73840970678575 38.701 35.670753356307635 139.73840970678575 37.793 35.67076755419062 139.73847993347823 37.793</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-85590470-9d99-46a9-a77e-7612ed6e13d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85590470-9d99-46a9-a77e-7612ed6e13d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85590470-9d99-46a9-a77e-7612ed6e13d6">
											<gml:posList>35.67076425559553 139.73844615775812 36.155 35.67076425559553 139.73844615775812 32.871 35.6707541840376 139.73839632872344 32.871 35.6707541840376 139.73839632872344 33.345 35.67075350536083 139.7383929714486 33.345 35.67075350536083 139.7383929714486 38.701 35.670771702921556 139.7384829994451 38.701 35.670771702921556 139.7384829994451 36.155 35.67076425559553 139.73844615775812 36.155</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-75ac99ae-d76c-495a-a3d6-f7ff084b2aaa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-75ac99ae-d76c-495a-a3d6-f7ff084b2aaa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-75ac99ae-d76c-495a-a3d6-f7ff084b2aaa">
											<gml:posList>35.67078048881998 139.73838834422952 32.871 35.67078048881998 139.73838834422952 33.345 35.6707541840376 139.73839632872344 33.345 35.6707541840376 139.73839632872344 32.871 35.67078048881998 139.73838834422952 32.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f7efc062-388c-487d-80ea-962cbcba9ce6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f7efc062-388c-487d-80ea-962cbcba9ce6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f7efc062-388c-487d-80ea-962cbcba9ce6">
											<gml:posList>35.670776574419406 139.73844242057123 32.871 35.67076425559553 139.73844615775812 32.871 35.67076425559553 139.73844615775812 36.155 35.670776574419406 139.73844242057123 36.155 35.670776574419406 139.73844242057123 32.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9d7088de-f1cb-450c-8b4d-684d7c8f7eb1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d7088de-f1cb-450c-8b4d-684d7c8f7eb1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d7088de-f1cb-450c-8b4d-684d7c8f7eb1">
											<gml:posList>35.6707788638479 139.73845378451892 33.345 35.6707788638479 139.73845378451892 32.871 35.670776574419406 139.73844242057123 32.871 35.670776574419406 139.73844242057123 36.155 35.67078763237771 139.73849723034706 36.155 35.67078763237771 139.73849723034706 27.191 35.67077954252297 139.73845714179532 27.191 35.67077954252297 139.73845714179532 33.345 35.6707788638479 139.73845378451892 33.345</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b4eb3405-6995-4b2a-8f1d-6acdf059a7a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b4eb3405-6995-4b2a-8f1d-6acdf059a7a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b4eb3405-6995-4b2a-8f1d-6acdf059a7a3">
											<gml:posList>35.6707788638479 139.73845378451892 32.871 35.6707788638479 139.73845378451892 33.345 35.67079284081375 139.73844955933234 33.345 35.67079284081375 139.73844955933234 32.871 35.6707788638479 139.73845378451892 32.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-485467ed-3d90-4e37-bb7f-e54e39d55b3c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-485467ed-3d90-4e37-bb7f-e54e39d55b3c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-485467ed-3d90-4e37-bb7f-e54e39d55b3c">
											<gml:posList>35.67079284081375 139.73844955933234 32.871 35.67079284081375 139.73844955933234 33.345 35.67078048881998 139.73838834422952 33.345 35.67078048881998 139.73838834422952 32.871 35.67079284081375 139.73844955933234 32.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8f892316-fc86-431a-b6f4-d8468c95c1ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f892316-fc86-431a-b6f4-d8468c95c1ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f892316-fc86-431a-b6f4-d8468c95c1ee">
											<gml:posList>35.67077954252297 139.73845714179532 33.345 35.67077954252297 139.73845714179532 27.191 35.67079625899879 139.7384520738473 27.191 35.67079625899879 139.7384520738473 33.345 35.67077954252297 139.73845714179532 33.345</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d14b528d-1302-4ded-812f-d1459731a88f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d14b528d-1302-4ded-812f-d1459731a88f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d14b528d-1302-4ded-812f-d1459731a88f">
											<gml:posList>35.670782549661055 139.73838415523582 33.345 35.67079625899879 139.7384520738473 33.345 35.67079625899879 139.7384520738473 27.191 35.67080435786892 139.73849216239623 27.191 35.67080435786892 139.73849216239623 17.78 35.670782549661055 139.73838415523582 17.78 35.670782549661055 139.73838415523582 33.345</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2141</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">184.7261</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>