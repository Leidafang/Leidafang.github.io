<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_46b70c85-2ec0-4957-b630-53fa688e7faf">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">411</bldg:usage>
			<bldg:measuredHeight uom="m">9.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66892533654736 139.739619315638 0 35.66885642052258 139.73955367219068 0 35.66883724477034 139.73958385032606 0 35.66883219338639 139.73957910643236 0 35.66879609254219 139.73963592529515 0 35.66887005998784 139.73970642312787 0 35.66892533654736 139.739619315638 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66892533654736 139.739619315638 11.62 35.66887005998784 139.73970642312787 11.62 35.66879609254219 139.73963592529515 11.62 35.66883219338639 139.73957910643236 11.62 35.66883724477034 139.73958385032606 11.62 35.66885642052258 139.73955367219068 11.62 35.66892533654736 139.739619315638 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66892533654736 139.739619315638 11.62 35.66885642052258 139.73955367219068 11.62 35.66885642052258 139.73955367219068 21.3 35.66892533654736 139.739619315638 21.3 35.66892533654736 139.739619315638 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66885642052258 139.73955367219068 11.62 35.66883724477034 139.73958385032606 11.62 35.66883724477034 139.73958385032606 21.3 35.66885642052258 139.73955367219068 21.3 35.66885642052258 139.73955367219068 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66883724477034 139.73958385032606 11.62 35.66883219338639 139.73957910643236 11.62 35.66883219338639 139.73957910643236 21.3 35.66883724477034 139.73958385032606 21.3 35.66883724477034 139.73958385032606 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66883219338639 139.73957910643236 11.62 35.66879609254219 139.73963592529515 11.62 35.66879609254219 139.73963592529515 21.3 35.66883219338639 139.73957910643236 21.3 35.66883219338639 139.73957910643236 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66879609254219 139.73963592529515 11.62 35.66887005998784 139.73970642312787 11.62 35.66887005998784 139.73970642312787 21.3 35.66879609254219 139.73963592529515 21.3 35.66879609254219 139.73963592529515 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66887005998784 139.73970642312787 11.62 35.66892533654736 139.739619315638 11.62 35.66892533654736 139.739619315638 21.3 35.66887005998784 139.73970642312787 21.3 35.66887005998784 139.73970642312787 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66892533654736 139.739619315638 21.3 35.66885642052258 139.73955367219068 21.3 35.66883724477034 139.73958385032606 21.3 35.66883219338639 139.73957910643236 21.3 35.66879609254219 139.73963592529515 21.3 35.66887005998784 139.73970642312787 21.3 35.66892533654736 139.739619315638 21.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-dce8e46e-3817-47fe-9810-8295b0fffdae"/>
							<gml:surfaceMember xlink:href="#poly-4adb65e8-4fc5-410f-9c3b-5bd342596c42"/>
							<gml:surfaceMember xlink:href="#poly-fcbef0ec-3f4f-4c59-a832-8755de7b4b65"/>
							<gml:surfaceMember xlink:href="#poly-6844cddf-8bb8-446c-b4fc-fa5dfb96370b"/>
							<gml:surfaceMember xlink:href="#poly-d5762018-8186-47c0-87bf-2bddf6b2cb36"/>
							<gml:surfaceMember xlink:href="#poly-e37b63ed-69d9-41b3-bef2-28f9da4a4dbc"/>
							<gml:surfaceMember xlink:href="#poly-d1dace2f-88e8-4fbf-b67f-0de9eb5ff1bc"/>
							<gml:surfaceMember xlink:href="#poly-8fc0aaf9-ea4f-49f3-97a5-5e890f8c3625"/>
							<gml:surfaceMember xlink:href="#poly-831897fb-18b8-44af-ac08-8fb453a8f4bd"/>
							<gml:surfaceMember xlink:href="#poly-bf8e24e6-1b33-439a-acc8-278fce172d94"/>
							<gml:surfaceMember xlink:href="#poly-fa0d517e-1d6e-4dbc-9a5c-763d27ea6a0e"/>
							<gml:surfaceMember xlink:href="#poly-31e76522-4590-4ab3-87c9-44574dbbcbc7"/>
							<gml:surfaceMember xlink:href="#poly-4a5d3ff2-4c71-4dbb-aed1-e4df2e092b04"/>
							<gml:surfaceMember xlink:href="#poly-6391fc5e-3ec5-483c-951b-c76208a7c484"/>
							<gml:surfaceMember xlink:href="#poly-4d1038cb-cabf-4ecf-8a13-9dd627edce5b"/>
							<gml:surfaceMember xlink:href="#poly-7b39d001-c9fb-47b8-88b7-e5df6337265e"/>
							<gml:surfaceMember xlink:href="#poly-97ff2b07-0c0f-4a26-9cc1-d78466adce2c"/>
							<gml:surfaceMember xlink:href="#poly-03e20536-12e8-4c2b-93cf-1ed6e2e8b6ff"/>
							<gml:surfaceMember xlink:href="#poly-bf01f765-3dbd-4851-a8eb-4a67f1355b3b"/>
							<gml:surfaceMember xlink:href="#poly-8474d6a0-6786-4a0d-9d2e-1cfa5ce37e28"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-dce8e46e-3817-47fe-9810-8295b0fffdae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dce8e46e-3817-47fe-9810-8295b0fffdae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dce8e46e-3817-47fe-9810-8295b0fffdae">
											<gml:posList>35.66887005998783 139.73970642312784 11.62 35.668796092542166 139.73963592529518 11.62 35.6688321933864 139.73957910643236 11.62 35.66883724477034 139.73958385032606 11.62 35.66885642052257 139.73955367219068 11.62 35.66892533654736 139.73961931563804 11.62 35.66887005998783 139.73970642312784 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4adb65e8-4fc5-410f-9c3b-5bd342596c42">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4adb65e8-4fc5-410f-9c3b-5bd342596c42">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4adb65e8-4fc5-410f-9c3b-5bd342596c42">
											<gml:posList>35.668796092542166 139.73963592529518 21.781 35.66879839077556 139.73963558018227 21.781 35.668832493015174 139.73958190073168 21.781 35.6688321933864 139.73957910643236 21.781 35.668796092542166 139.73963592529518 21.781</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fcbef0ec-3f4f-4c59-a832-8755de7b4b65">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fcbef0ec-3f4f-4c59-a832-8755de7b4b65">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fcbef0ec-3f4f-4c59-a832-8755de7b4b65">
											<gml:posList>35.66887005998783 139.73970642312784 21.781 35.66886976035337 139.7397036177807 21.781 35.66879839077556 139.73963558018227 21.781 35.668796092542166 139.73963592529518 21.781 35.66887005998783 139.73970642312784 21.781</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6844cddf-8bb8-446c-b4fc-fa5dfb96370b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6844cddf-8bb8-446c-b4fc-fa5dfb96370b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6844cddf-8bb8-446c-b4fc-fa5dfb96370b">
											<gml:posList>35.66883724477034 139.73958385032606 21.781 35.6688321933864 139.73957910643236 21.781 35.668832493015174 139.73958190073168 21.781 35.66883753538527 139.73958664463612 21.781 35.66883724477034 139.73958385032606 21.781</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d5762018-8186-47c0-87bf-2bddf6b2cb36">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5762018-8186-47c0-87bf-2bddf6b2cb36">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5762018-8186-47c0-87bf-2bddf6b2cb36">
											<gml:posList>35.66883724477034 139.73958385032606 21.781 35.66883753538527 139.73958664463612 21.781 35.66885670213309 139.73955647755787 21.781 35.66885642052257 139.73955367219068 21.781 35.66883724477034 139.73958385032606 21.781</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e37b63ed-69d9-41b3-bef2-28f9da4a4dbc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e37b63ed-69d9-41b3-bef2-28f9da4a4dbc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e37b63ed-69d9-41b3-bef2-28f9da4a4dbc">
											<gml:posList>35.66886976035337 139.7397036177807 21.262 35.668923038322674 139.739619671798 21.262 35.66885670213309 139.73955647755787 21.262 35.66883753538527 139.73958664463612 21.262 35.668832493015174 139.73958190073168 21.262 35.66879839077556 139.73963558018227 21.262 35.66886976035337 139.7397036177807 21.262</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d1dace2f-88e8-4fbf-b67f-0de9eb5ff1bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1dace2f-88e8-4fbf-b67f-0de9eb5ff1bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1dace2f-88e8-4fbf-b67f-0de9eb5ff1bc">
											<gml:posList>35.66885642052257 139.73955367219068 21.781 35.66885670213309 139.73955647755787 21.781 35.668923038322674 139.739619671798 21.781 35.66892533654736 139.73961931563804 21.781 35.66885642052257 139.73955367219068 21.781</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8fc0aaf9-ea4f-49f3-97a5-5e890f8c3625">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8fc0aaf9-ea4f-49f3-97a5-5e890f8c3625">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8fc0aaf9-ea4f-49f3-97a5-5e890f8c3625">
											<gml:posList>35.66892533654736 139.73961931563804 21.781 35.668923038322674 139.739619671798 21.781 35.66886976035337 139.7397036177807 21.781 35.66887005998783 139.73970642312784 21.781 35.66892533654736 139.73961931563804 21.781</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-831897fb-18b8-44af-ac08-8fb453a8f4bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-831897fb-18b8-44af-ac08-8fb453a8f4bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-831897fb-18b8-44af-ac08-8fb453a8f4bd">
											<gml:posList>35.66885642052257 139.73955367219068 11.62 35.66883724477034 139.73958385032606 11.62 35.66883724477034 139.73958385032606 21.781 35.66885642052257 139.73955367219068 21.781 35.66885642052257 139.73955367219068 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bf8e24e6-1b33-439a-acc8-278fce172d94">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf8e24e6-1b33-439a-acc8-278fce172d94">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf8e24e6-1b33-439a-acc8-278fce172d94">
											<gml:posList>35.66883753538527 139.73958664463612 21.781 35.66883753538527 139.73958664463612 21.262 35.66885670213309 139.73955647755787 21.262 35.66885670213309 139.73955647755787 21.781 35.66883753538527 139.73958664463612 21.781</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fa0d517e-1d6e-4dbc-9a5c-763d27ea6a0e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa0d517e-1d6e-4dbc-9a5c-763d27ea6a0e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa0d517e-1d6e-4dbc-9a5c-763d27ea6a0e">
											<gml:posList>35.66883724477034 139.73958385032606 11.62 35.6688321933864 139.73957910643236 11.62 35.6688321933864 139.73957910643236 21.781 35.66883724477034 139.73958385032606 21.781 35.66883724477034 139.73958385032606 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-31e76522-4590-4ab3-87c9-44574dbbcbc7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31e76522-4590-4ab3-87c9-44574dbbcbc7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31e76522-4590-4ab3-87c9-44574dbbcbc7">
											<gml:posList>35.668832493015174 139.73958190073168 21.781 35.668832493015174 139.73958190073168 21.262 35.66883753538527 139.73958664463612 21.262 35.66883753538527 139.73958664463612 21.781 35.668832493015174 139.73958190073168 21.781</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4a5d3ff2-4c71-4dbb-aed1-e4df2e092b04">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a5d3ff2-4c71-4dbb-aed1-e4df2e092b04">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a5d3ff2-4c71-4dbb-aed1-e4df2e092b04">
											<gml:posList>35.66892533654736 139.73961931563804 11.62 35.66885642052257 139.73955367219068 11.62 35.66885642052257 139.73955367219068 21.781 35.66892533654736 139.73961931563804 21.781 35.66892533654736 139.73961931563804 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6391fc5e-3ec5-483c-951b-c76208a7c484">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6391fc5e-3ec5-483c-951b-c76208a7c484">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6391fc5e-3ec5-483c-951b-c76208a7c484">
											<gml:posList>35.66885670213309 139.73955647755787 21.781 35.66885670213309 139.73955647755787 21.262 35.668923038322674 139.739619671798 21.262 35.668923038322674 139.739619671798 21.781 35.66885670213309 139.73955647755787 21.781</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4d1038cb-cabf-4ecf-8a13-9dd627edce5b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d1038cb-cabf-4ecf-8a13-9dd627edce5b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d1038cb-cabf-4ecf-8a13-9dd627edce5b">
											<gml:posList>35.6688321933864 139.73957910643236 11.62 35.668796092542166 139.73963592529518 11.62 35.668796092542166 139.73963592529518 21.781 35.6688321933864 139.73957910643236 21.781 35.6688321933864 139.73957910643236 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7b39d001-c9fb-47b8-88b7-e5df6337265e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b39d001-c9fb-47b8-88b7-e5df6337265e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b39d001-c9fb-47b8-88b7-e5df6337265e">
											<gml:posList>35.66879839077556 139.73963558018227 21.781 35.66879839077556 139.73963558018227 21.262 35.668832493015174 139.73958190073168 21.262 35.668832493015174 139.73958190073168 21.781 35.66879839077556 139.73963558018227 21.781</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-97ff2b07-0c0f-4a26-9cc1-d78466adce2c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-97ff2b07-0c0f-4a26-9cc1-d78466adce2c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-97ff2b07-0c0f-4a26-9cc1-d78466adce2c">
											<gml:posList>35.668923038322674 139.739619671798 21.781 35.668923038322674 139.739619671798 21.262 35.66886976035337 139.7397036177807 21.262 35.66886976035337 139.7397036177807 21.781 35.668923038322674 139.739619671798 21.781</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-03e20536-12e8-4c2b-93cf-1ed6e2e8b6ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03e20536-12e8-4c2b-93cf-1ed6e2e8b6ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03e20536-12e8-4c2b-93cf-1ed6e2e8b6ff">
											<gml:posList>35.66887005998783 139.73970642312784 11.62 35.66892533654736 139.73961931563804 11.62 35.66892533654736 139.73961931563804 21.781 35.66887005998783 139.73970642312784 21.781 35.66887005998783 139.73970642312784 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bf01f765-3dbd-4851-a8eb-4a67f1355b3b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf01f765-3dbd-4851-a8eb-4a67f1355b3b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf01f765-3dbd-4851-a8eb-4a67f1355b3b">
											<gml:posList>35.66886976035337 139.7397036177807 21.781 35.66886976035337 139.7397036177807 21.262 35.66879839077556 139.73963558018227 21.262 35.66879839077556 139.73963558018227 21.781 35.66886976035337 139.7397036177807 21.781</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8474d6a0-6786-4a0d-9d2e-1cfa5ce37e28">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8474d6a0-6786-4a0d-9d2e-1cfa5ce37e28">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8474d6a0-6786-4a0d-9d2e-1cfa5ce37e28">
											<gml:posList>35.668796092542166 139.73963592529518 11.62 35.66887005998783 139.73970642312784 11.62 35.66887005998783 139.73970642312784 21.781 35.668796092542166 139.73963592529518 21.781 35.668796092542166 139.73963592529518 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7592</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">101.35805</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1310</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>