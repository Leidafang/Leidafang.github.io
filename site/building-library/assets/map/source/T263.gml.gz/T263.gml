<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_490611ae-9d1c-4c45-894e-e730435000fa">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">60.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>13</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.670142832723045 139.74851043682278 0 35.66999866439911 139.7483276641434 0 35.66995129149348 139.7483833872219 0 35.66993613534149 139.74836484566558 0 35.66974592472461 139.74859105193403 0 35.66976126134993 139.7486099246838 0 35.66971370842524 139.74866619992886 0 35.66985805581911 139.7488479782233 0 35.66990551946591 139.74879280769807 0 35.66992040506291 139.74881123915156 0 35.67011088688843 139.74858558493642 0 35.670096091083565 139.7485667115374 0 35.670142832723045 139.74851043682278 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670142832723045 139.74851043682278 6.39 35.670096091083565 139.7485667115374 6.39 35.67011088688843 139.74858558493642 6.39 35.66992040506291 139.74881123915156 6.39 35.66990551946591 139.74879280769807 6.39 35.66985805581911 139.7488479782233 6.39 35.66971370842524 139.74866619992886 6.39 35.66976126134993 139.7486099246838 6.39 35.66974592472461 139.74859105193403 6.39 35.66993613534149 139.74836484566558 6.39 35.66995129149348 139.7483833872219 6.39 35.66999866439911 139.7483276641434 6.39 35.670142832723045 139.74851043682278 6.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670142832723045 139.74851043682278 6.39 35.66999866439911 139.7483276641434 6.39 35.66999866439911 139.7483276641434 66.46 35.670142832723045 139.74851043682278 66.46 35.670142832723045 139.74851043682278 6.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66999866439911 139.7483276641434 6.39 35.66995129149348 139.7483833872219 6.39 35.66995129149348 139.7483833872219 66.46 35.66999866439911 139.7483276641434 66.46 35.66999866439911 139.7483276641434 6.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66995129149348 139.7483833872219 6.39 35.66993613534149 139.74836484566558 6.39 35.66993613534149 139.74836484566558 66.46 35.66995129149348 139.7483833872219 66.46 35.66995129149348 139.7483833872219 6.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66993613534149 139.74836484566558 6.39 35.66974592472461 139.74859105193403 6.39 35.66974592472461 139.74859105193403 66.46 35.66993613534149 139.74836484566558 66.46 35.66993613534149 139.74836484566558 6.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66974592472461 139.74859105193403 6.39 35.66976126134993 139.7486099246838 6.39 35.66976126134993 139.7486099246838 66.46 35.66974592472461 139.74859105193403 66.46 35.66974592472461 139.74859105193403 6.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66976126134993 139.7486099246838 6.39 35.66971370842524 139.74866619992886 6.39 35.66971370842524 139.74866619992886 66.46 35.66976126134993 139.7486099246838 66.46 35.66976126134993 139.7486099246838 6.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66971370842524 139.74866619992886 6.39 35.66985805581911 139.7488479782233 6.39 35.66985805581911 139.7488479782233 66.46 35.66971370842524 139.74866619992886 66.46 35.66971370842524 139.74866619992886 6.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66985805581911 139.7488479782233 6.39 35.66990551946591 139.74879280769807 6.39 35.66990551946591 139.74879280769807 66.46 35.66985805581911 139.7488479782233 66.46 35.66985805581911 139.7488479782233 6.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66990551946591 139.74879280769807 6.39 35.66992040506291 139.74881123915156 6.39 35.66992040506291 139.74881123915156 66.46 35.66990551946591 139.74879280769807 66.46 35.66990551946591 139.74879280769807 6.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66992040506291 139.74881123915156 6.39 35.67011088688843 139.74858558493642 6.39 35.67011088688843 139.74858558493642 66.46 35.66992040506291 139.74881123915156 66.46 35.66992040506291 139.74881123915156 6.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67011088688843 139.74858558493642 6.39 35.670096091083565 139.7485667115374 6.39 35.670096091083565 139.7485667115374 66.46 35.67011088688843 139.74858558493642 66.46 35.67011088688843 139.74858558493642 6.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670096091083565 139.7485667115374 6.39 35.670142832723045 139.74851043682278 6.39 35.670142832723045 139.74851043682278 66.46 35.670096091083565 139.7485667115374 66.46 35.670096091083565 139.7485667115374 6.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670142832723045 139.74851043682278 66.46 35.66999866439911 139.7483276641434 66.46 35.66995129149348 139.7483833872219 66.46 35.66993613534149 139.74836484566558 66.46 35.66974592472461 139.74859105193403 66.46 35.66976126134993 139.7486099246838 66.46 35.66971370842524 139.74866619992886 66.46 35.66985805581911 139.7488479782233 66.46 35.66990551946591 139.74879280769807 66.46 35.66992040506291 139.74881123915156 66.46 35.67011088688843 139.74858558493642 66.46 35.670096091083565 139.7485667115374 66.46 35.670142832723045 139.74851043682278 66.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-1ad8a352-2fa2-4f16-a6c0-41d53fb3e3e3"/>
							<gml:surfaceMember xlink:href="#poly-bbb39c59-cc67-4964-b705-c8274b441b04"/>
							<gml:surfaceMember xlink:href="#poly-0a1d395a-42af-4b5f-8d24-b41369fa5c0d"/>
							<gml:surfaceMember xlink:href="#poly-bb6795da-0cc5-4305-b10a-ba6e46527caa"/>
							<gml:surfaceMember xlink:href="#poly-bfcccd65-a8d3-4566-a5dd-ea7a8ec592ef"/>
							<gml:surfaceMember xlink:href="#poly-b8ed22e0-2b89-49d6-a459-2ffedb429a40"/>
							<gml:surfaceMember xlink:href="#poly-5c10d49e-c801-4d8d-bab2-6312d5e1b0f0"/>
							<gml:surfaceMember xlink:href="#poly-3b56cd90-147e-4f9f-9276-9d05d2ab354d"/>
							<gml:surfaceMember xlink:href="#poly-e2691ef7-c407-40b1-af88-698ac961b492"/>
							<gml:surfaceMember xlink:href="#poly-16c3827b-9466-4404-9699-1b7028477972"/>
							<gml:surfaceMember xlink:href="#poly-b53d6eb6-7139-4efa-922f-ca08fee0ec89"/>
							<gml:surfaceMember xlink:href="#poly-099f0685-b5c1-4d6a-8ffc-d8e27677a2a9"/>
							<gml:surfaceMember xlink:href="#poly-37792ce5-1d71-40b2-9690-d4dcea390066"/>
							<gml:surfaceMember xlink:href="#poly-efdcee24-9205-4a28-9a81-1be4a63da57b"/>
							<gml:surfaceMember xlink:href="#poly-f8ad1cbf-4a59-47f7-ac21-5daa7ad22a35"/>
							<gml:surfaceMember xlink:href="#poly-e9123774-5a6d-40bf-bde9-6abeed303568"/>
							<gml:surfaceMember xlink:href="#poly-612dec5e-07c3-42a8-8afe-b8d2cffaccc7"/>
							<gml:surfaceMember xlink:href="#poly-a15955e5-0222-4803-b6be-da143ecf0d02"/>
							<gml:surfaceMember xlink:href="#poly-4c58fd52-ca43-4457-8598-c4cf66168b9d"/>
							<gml:surfaceMember xlink:href="#poly-13a9af96-5953-412a-b8bc-4d8484d61510"/>
							<gml:surfaceMember xlink:href="#poly-b7856c97-542d-43d1-b14f-b3ef9fbd3198"/>
							<gml:surfaceMember xlink:href="#poly-e8d77030-b255-459c-9228-76653ec2f7b9"/>
							<gml:surfaceMember xlink:href="#poly-df0d64f6-0fe0-41b8-9d13-69e48a354413"/>
							<gml:surfaceMember xlink:href="#poly-b5b6f4d3-c41e-468c-9aab-7ca6d9e1d8b8"/>
							<gml:surfaceMember xlink:href="#poly-0795255a-f078-4516-b4ec-0485572d3ad8"/>
							<gml:surfaceMember xlink:href="#poly-5055fca0-27dc-4144-81e5-4fe1a76781ce"/>
							<gml:surfaceMember xlink:href="#poly-398a7d08-b0af-4eb7-9590-6a61b6d25901"/>
							<gml:surfaceMember xlink:href="#poly-6da32acc-624d-43c7-8cea-ecf3c83a23ee"/>
							<gml:surfaceMember xlink:href="#poly-a5a924b1-141c-4975-ba84-579a065e3046"/>
							<gml:surfaceMember xlink:href="#poly-9db25a79-03bb-4f87-bd02-eac7ed6981a0"/>
							<gml:surfaceMember xlink:href="#poly-6a9e7886-2039-4cc8-8823-ece566b59935"/>
							<gml:surfaceMember xlink:href="#poly-5f57ff26-ff18-4a36-aa9a-5417613849b3"/>
							<gml:surfaceMember xlink:href="#poly-e72e2e81-fe41-4c17-a19a-de9887596fc7"/>
							<gml:surfaceMember xlink:href="#poly-a4f38832-7d03-4eec-af03-d86f09d9ff39"/>
							<gml:surfaceMember xlink:href="#poly-0cdf027a-28d8-463a-9825-53bbb08a6dc2"/>
							<gml:surfaceMember xlink:href="#poly-97db5fe6-7346-4832-992b-53bd61ffa3c8"/>
							<gml:surfaceMember xlink:href="#poly-3a1224b8-0450-465e-b7cd-b94500f56fbe"/>
							<gml:surfaceMember xlink:href="#poly-10261de1-d610-4505-b91b-80a68e73d071"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_490611ae-9d1c-4c45-894e-e730435000fa_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-22902664-52e7-485b-bfc4-58d74e622fd8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67002066411458 139.74861785791256 65.62 35.66999674349741 139.74864608415422 65.62 35.66997117569308 139.7486135469507 65.62 35.66999509630271 139.74858532070837 65.62 35.67002066411458 139.74861785791256 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a31c9342-9e06-4b36-8763-6e2d8eb55910">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a31c9342-9e06-4b36-8763-6e2d8eb55910_0">
											<gml:posList>35.66997117569308 139.7486135469507 65.62 35.66997117569308 139.7486135469507 71.6 35.66999509630271 139.74858532070837 71.6 35.66999509630271 139.74858532070837 65.62 35.66997117569308 139.7486135469507 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c81e475-0a91-430a-b35f-9fdb9d354c06">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c81e475-0a91-430a-b35f-9fdb9d354c06_0">
											<gml:posList>35.66999674349741 139.74864608415422 65.62 35.66999674349741 139.74864608415422 71.6 35.66997117569308 139.7486135469507 71.6 35.66997117569308 139.7486135469507 65.62 35.66999674349741 139.74864608415422 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d1a736b-bf1b-4d21-9025-9bf378597256">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3d1a736b-bf1b-4d21-9025-9bf378597256_0">
											<gml:posList>35.67002066411458 139.74861785791256 71.6 35.66999509630271 139.74858532070837 71.6 35.66997117569308 139.7486135469507 71.6 35.66999674349741 139.74864608415422 71.6 35.67002066411458 139.74861785791256 71.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c209671-560a-4444-a7d9-6285800d5bde">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3c209671-560a-4444-a7d9-6285800d5bde_0">
											<gml:posList>35.66999509630271 139.74858532070837 65.62 35.66999509630271 139.74858532070837 71.6 35.67002066411458 139.74861785791256 71.6 35.67002066411458 139.74861785791256 65.62 35.66999509630271 139.74858532070837 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48c578a7-090b-45bd-9483-cedfec9c5ff9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-48c578a7-090b-45bd-9483-cedfec9c5ff9_0">
											<gml:posList>35.67002066411458 139.74861785791256 65.62 35.67002066411458 139.74861785791256 71.6 35.66999674349741 139.74864608415422 71.6 35.66999674349741 139.74864608415422 65.62 35.67002066411458 139.74861785791256 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_490611ae-9d1c-4c45-894e-e730435000fa_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa6880aa-8491-4597-b6e2-194576ebca1e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670002404592246 139.7484163722758 65.62 35.66998797596102 139.74843249292573 65.62 35.66997290874643 139.74841223909579 65.62 35.66998699452617 139.7483956548678 65.62 35.670002404592246 139.7484163722758 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-32dfbb2e-f537-4f81-a449-7dce3b297604">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66996037065773 139.74846339629246 65.62 35.66993663466195 139.7484337955112 65.62 35.66994198427403 139.7484273499121 65.62 35.66995084340825 139.7484381989463 65.62 35.6699593002868 139.74842824840997 65.62 35.66997415897605 139.74844679029857 65.62 35.66996037065773 139.74846339629246 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9cc9155e-f7d9-431b-94e3-0237aab5ebfd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670021495972904 139.7484551463485 65.62 35.66998481384152 139.748498850832 65.62 35.669980591659126 139.74849351998225 65.62 35.670017273788595 139.74844981549862 65.62 35.670021495972904 139.7484551463485 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a6acf47f-dd34-4945-b870-3a578799b5f2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67003347228856 139.74846377180833 65.62 35.6700417273908 139.7484744668512 65.62 35.67003223466961 139.74848546787925 65.62 35.67002397956833 139.74847477283652 65.62 35.67003347228856 139.74846377180833 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1583e508-7b2d-4e8e-8174-952ebb53a8b1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66988452828659 139.74848780028674 65.62 35.66990735966226 139.748461640829 65.62 35.669952460976596 139.74852077863443 65.62 35.669929629580466 139.74854692704392 65.62 35.66988452828659 139.74848780028674 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a0f075c-d6e5-4010-84e4-2eec4013a5ef">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67002532951692 139.74849736090997 65.62 35.67000007462444 139.7485252019832 65.62 35.66998982519795 139.74851125041948 65.62 35.670015080087246 139.7484834093454 65.62 35.67002532951692 139.74849736090997 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9c48bcf0-f114-4177-b1c0-d972bfe4442b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66986150188661 139.74851862142756 65.62 35.669874380643655 139.74850317627602 65.62 35.6698909444717 139.74852392559382 65.62 35.669878065712034 139.74853937074522 65.62 35.66986150188661 139.74851862142756 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-15ce2a0a-dfe7-4b82-b14d-a4cfbe09930f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66998982648962 139.7485130840884 65.62 35.66999962480174 139.74852642858804 65.62 35.66998840240503 139.74853880116302 65.62 35.66997860409426 139.74852545666369 65.62 35.66998982648962 139.7485130840884 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb7c3247-c230-4dca-a7eb-842a88021715">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66995966155271 139.74858280648976 65.62 35.670052506965355 139.74847326245114 65.62 35.67005681942598 139.74847879204097 65.62 35.669963676291104 139.74858796082285 65.62 35.66995966155271 139.74858280648976 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9584adaf-d9a7-483f-954b-f13946bd0d96">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66988492131589 139.74854670921272 65.62 35.66989575533774 139.74853322140004 65.62 35.66990666221155 139.74854638797515 65.62 35.66989581916674 139.74855986475126 65.62 35.66988492131589 139.74854670921272 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-334d10b5-4ce7-4b94-bb38-60866ff053b0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66998500271504 139.74854945330083 65.62 35.66996388223336 139.74857320287813 65.62 35.66995089926607 139.748555863021 65.62 35.669972019736605 139.74853210239678 65.62 35.66998500271504 139.74854945330083 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a669f0a-2fde-4c2a-bff5-6d551a262a1b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669963615387296 139.7485910759164 65.62 35.67005936135095 139.74847886667428 65.62 35.67005380386748 139.74847173670082 65.62 35.67006108090828 139.7484631460887 65.62 35.67007320619144 139.74847850958926 65.62 35.6698615141718 139.7487282780775 65.62 35.669849415937975 139.74871288141253 65.62 35.66995836465692 139.7485843432827 65.62 35.669963615387296 139.7485910759164 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1dd5e5d6-23b0-45f1-a41b-f055a064687a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66985565021588 139.74875961125423 65.62 35.66986765846162 139.74877522894616 65.62 35.66985889520388 139.74878534545041 65.62 35.66984688695945 139.74876972775868 65.62 35.66985565021588 139.74875961125423 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aad93d34-f584-4648-aced-b87aec588c5a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66987782573396 139.74876208430243 65.62 35.66986892738007 139.74877235559856 65.62 35.669852570537955 139.74875107579973 65.62 35.66986146889007 139.74874080450334 65.62 35.66987782573396 139.74876208430243 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-579e5758-570e-4e06-8e0f-d2843842dd43">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-579e5758-570e-4e06-8e0f-d2843842dd43_0">
											<gml:posList>35.670052506965355 139.74847326245114 65.62 35.670052506965355 139.74847326245114 66.64 35.67005681942598 139.74847879204097 66.64 35.67005681942598 139.74847879204097 65.62 35.670052506965355 139.74847326245114 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-50b14dcb-f639-43ef-9039-206e10ed4521">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-50b14dcb-f639-43ef-9039-206e10ed4521_0">
											<gml:posList>35.669963676291104 139.74858796082285 66.64 35.669963676291104 139.74858796082285 65.62 35.67005681942598 139.74847879204097 65.62 35.67005681942598 139.74847879204097 66.64 35.669963676291104 139.74858796082285 66.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b9225db-efa2-4a80-abed-02f74ef595e9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1b9225db-efa2-4a80-abed-02f74ef595e9_0">
											<gml:posList>35.66986892738007 139.74877235559856 65.62 35.66987782573396 139.74876208430243 65.62 35.66987782573396 139.74876208430243 67.216 35.66986892738007 139.74877235559856 67.216 35.66986892738007 139.74877235559856 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-350f71cb-1455-45b8-8fa3-183707687dd1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-350f71cb-1455-45b8-8fa3-183707687dd1_0">
											<gml:posList>35.669849415937975 139.74871288141253 65.62 35.669849415937975 139.74871288141253 66.64 35.66995836465692 139.7485843432827 66.64 35.66995836465692 139.7485843432827 65.62 35.669849415937975 139.74871288141253 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-47c06f52-9e02-43ab-8ca4-085ebcec63a1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-47c06f52-9e02-43ab-8ca4-085ebcec63a1_0">
											<gml:posList>35.669963615387296 139.7485910759164 65.62 35.66995836465692 139.7485843432827 65.62 35.66995836465692 139.7485843432827 66.64 35.669963615387296 139.7485910759164 66.64 35.669963615387296 139.7485910759164 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26a3749e-3bf0-49e5-a47f-6a7ffa4f4e78">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-26a3749e-3bf0-49e5-a47f-6a7ffa4f4e78_0">
											<gml:posList>35.669849415937975 139.74871288141253 66.64 35.6698615141718 139.7487282780775 66.64 35.67007320619144 139.74847850958926 66.64 35.67006108090828 139.7484631460887 66.64 35.67005380386748 139.74847173670082 66.64 35.67005936135095 139.74847886667428 66.64 35.669963615387296 139.7485910759164 66.64 35.66995836465692 139.7485843432827 66.64 35.669849415937975 139.74871288141253 66.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc1c7c4b-f7a8-4c10-8050-864434331325">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bc1c7c4b-f7a8-4c10-8050-864434331325_0">
											<gml:posList>35.66995966155271 139.74858280648976 66.64 35.66995966155271 139.74858280648976 65.62 35.669963676291104 139.74858796082285 65.62 35.669963676291104 139.74858796082285 66.64 35.66995966155271 139.74858280648976 66.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8dc5d832-9d39-4a1d-885e-6b9f489b41b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8dc5d832-9d39-4a1d-885e-6b9f489b41b0_0">
											<gml:posList>35.6698615141718 139.7487282780775 66.64 35.6698615141718 139.7487282780775 65.62 35.67007320619144 139.74847850958926 65.62 35.67007320619144 139.74847850958926 66.64 35.6698615141718 139.7487282780775 66.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-239c87de-1f38-4dd4-b4c7-a00f16bb8c01">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-239c87de-1f38-4dd4-b4c7-a00f16bb8c01_0">
											<gml:posList>35.66984688695945 139.74876972775868 65.62 35.66984688695945 139.74876972775868 67.216 35.66985565021588 139.74875961125423 67.216 35.66985565021588 139.74875961125423 65.62 35.66984688695945 139.74876972775868 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e33dafb-6825-48c5-a008-25787601de7f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6e33dafb-6825-48c5-a008-25787601de7f_0">
											<gml:posList>35.66984688695945 139.74876972775868 65.62 35.66985889520388 139.74878534545041 65.62 35.66985889520388 139.74878534545041 67.216 35.66984688695945 139.74876972775868 67.216 35.66984688695945 139.74876972775868 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9eaf9de4-6555-496d-9d69-47b8800f5990">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9eaf9de4-6555-496d-9d69-47b8800f5990_0">
											<gml:posList>35.6698615141718 139.7487282780775 65.62 35.6698615141718 139.7487282780775 66.64 35.669849415937975 139.74871288141253 66.64 35.669849415937975 139.74871288141253 65.62 35.6698615141718 139.7487282780775 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7a03a6f-d464-458f-a49c-2994ec5319c2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d7a03a6f-d464-458f-a49c-2994ec5319c2_0">
											<gml:posList>35.669852570537955 139.74875107579973 65.62 35.669852570537955 139.74875107579973 67.216 35.66986146889007 139.74874080450334 67.216 35.66986146889007 139.74874080450334 65.62 35.669852570537955 139.74875107579973 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f55cdede-64f8-434a-8398-e3820da7c02e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f55cdede-64f8-434a-8398-e3820da7c02e_0">
											<gml:posList>35.66985889520388 139.74878534545041 67.216 35.66986765846162 139.74877522894616 67.216 35.66985565021588 139.74875961125423 67.216 35.66984688695945 139.74876972775868 67.216 35.66985889520388 139.74878534545041 67.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a43a235-20ba-4af2-b28b-4fc0f65b2583">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0a43a235-20ba-4af2-b28b-4fc0f65b2583_0">
											<gml:posList>35.669852570537955 139.74875107579973 65.62 35.66986892738007 139.74877235559856 65.62 35.66986892738007 139.74877235559856 67.216 35.669852570537955 139.74875107579973 67.216 35.669852570537955 139.74875107579973 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f9b0eeb-6ce9-4567-b5dd-bde4946bfa06">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1f9b0eeb-6ce9-4567-b5dd-bde4946bfa06_0">
											<gml:posList>35.66986765846162 139.74877522894616 65.62 35.66985565021588 139.74875961125423 65.62 35.66985565021588 139.74875961125423 67.216 35.66986765846162 139.74877522894616 67.216 35.66986765846162 139.74877522894616 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ca33af2-1ce7-4d83-8c54-cb3239c0c004">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6ca33af2-1ce7-4d83-8c54-cb3239c0c004_0">
											<gml:posList>35.66985889520388 139.74878534545041 65.62 35.66986765846162 139.74877522894616 65.62 35.66986765846162 139.74877522894616 67.216 35.66985889520388 139.74878534545041 67.216 35.66985889520388 139.74878534545041 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8b5c7d0-5fa1-4825-92a6-819e211e7bcd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b8b5c7d0-5fa1-4825-92a6-819e211e7bcd_0">
											<gml:posList>35.669852570537955 139.74875107579973 67.216 35.66986892738007 139.74877235559856 67.216 35.66987782573396 139.74876208430243 67.216 35.66986146889007 139.74874080450334 67.216 35.669852570537955 139.74875107579973 67.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75e30f4b-c3b5-401a-aafc-99c7a8c17428">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-75e30f4b-c3b5-401a-aafc-99c7a8c17428_0">
											<gml:posList>35.66987782573396 139.74876208430243 65.62 35.66986146889007 139.74874080450334 65.62 35.66986146889007 139.74874080450334 67.216 35.66987782573396 139.74876208430243 67.216 35.66987782573396 139.74876208430243 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-55269745-4e07-4662-bda3-e4dda0416c79">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-55269745-4e07-4662-bda3-e4dda0416c79_0">
											<gml:posList>35.669874380643655 139.74850317627602 65.62 35.66986150188661 139.74851862142756 65.62 35.66986150188661 139.74851862142756 68.774 35.669874380643655 139.74850317627602 68.774 35.669874380643655 139.74850317627602 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5bcac91a-f713-4668-9c47-d901501ce7d5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5bcac91a-f713-4668-9c47-d901501ce7d5_0">
											<gml:posList>35.669878065712034 139.74853937074522 65.62 35.669878065712034 139.74853937074522 68.774 35.66986150188661 139.74851862142756 68.774 35.66986150188661 139.74851862142756 65.62 35.669878065712034 139.74853937074522 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e6342ef1-d517-4f3f-a6fc-2a6b698cb149">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e6342ef1-d517-4f3f-a6fc-2a6b698cb149_0">
											<gml:posList>35.66986150188661 139.74851862142756 68.774 35.669878065712034 139.74853937074522 68.774 35.6698909444717 139.74852392559382 68.774 35.669874380643655 139.74850317627602 68.774 35.66986150188661 139.74851862142756 68.774</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b32b573e-721e-4488-8af2-941b5cf6e5e6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b32b573e-721e-4488-8af2-941b5cf6e5e6_0">
											<gml:posList>35.6698909444717 139.74852392559382 65.62 35.669874380643655 139.74850317627602 65.62 35.669874380643655 139.74850317627602 68.774 35.6698909444717 139.74852392559382 68.774 35.6698909444717 139.74852392559382 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7dce9cbb-2867-4403-ad5d-ce256e79ee4c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7dce9cbb-2867-4403-ad5d-ce256e79ee4c_0">
											<gml:posList>35.669878065712034 139.74853937074522 65.62 35.6698909444717 139.74852392559382 65.62 35.6698909444717 139.74852392559382 68.774 35.669878065712034 139.74853937074522 68.774 35.669878065712034 139.74853937074522 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c42f8b2c-dc26-413c-934a-d00b5f2eb8f4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c42f8b2c-dc26-413c-934a-d00b5f2eb8f4_0">
											<gml:posList>35.66989575533774 139.74853322140004 65.62 35.66988492131589 139.74854670921272 65.62 35.66988492131589 139.74854670921272 68.774 35.66989575533774 139.74853322140004 68.774 35.66989575533774 139.74853322140004 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0021469-5a5c-4e01-88f6-5a10af51675d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0021469-5a5c-4e01-88f6-5a10af51675d_0">
											<gml:posList>35.66988492131589 139.74854670921272 65.62 35.66989581916674 139.74855986475126 65.62 35.66989581916674 139.74855986475126 68.774 35.66988492131589 139.74854670921272 68.774 35.66988492131589 139.74854670921272 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5800a4aa-d652-4567-a8b6-3c401307129a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5800a4aa-d652-4567-a8b6-3c401307129a_0">
											<gml:posList>35.66988492131589 139.74854670921272 68.774 35.66989581916674 139.74855986475126 68.774 35.66990666221155 139.74854638797515 68.774 35.66989575533774 139.74853322140004 68.774 35.66988492131589 139.74854670921272 68.774</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1ad12f1e-1ae1-4591-a0b9-79cecc84a06b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1ad12f1e-1ae1-4591-a0b9-79cecc84a06b_0">
											<gml:posList>35.66990735966226 139.748461640829 65.62 35.66988452828659 139.74848780028674 65.62 35.66988452828659 139.74848780028674 70.173 35.66990735966226 139.748461640829 70.173 35.66990735966226 139.748461640829 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40f832cc-22d7-4aec-85ed-373268964064">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40f832cc-22d7-4aec-85ed-373268964064_0">
											<gml:posList>35.66990666221155 139.74854638797515 65.62 35.66989575533774 139.74853322140004 65.62 35.66989575533774 139.74853322140004 68.774 35.66990666221155 139.74854638797515 68.774 35.66990666221155 139.74854638797515 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b80c75a-fdba-4c63-a8e8-ee465a13c037">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5b80c75a-fdba-4c63-a8e8-ee465a13c037_0">
											<gml:posList>35.66989581916674 139.74855986475126 65.62 35.66990666221155 139.74854638797515 65.62 35.66990666221155 139.74854638797515 68.774 35.66989581916674 139.74855986475126 68.774 35.66989581916674 139.74855986475126 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb258983-0fc5-468a-8126-329356ce1250">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fb258983-0fc5-468a-8126-329356ce1250_0">
											<gml:posList>35.669929629580466 139.74854692704392 65.62 35.669929629580466 139.74854692704392 70.173 35.66988452828659 139.74848780028674 70.173 35.66988452828659 139.74848780028674 65.62 35.669929629580466 139.74854692704392 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e6b881fb-4f15-4dd4-b68d-de19ff94880f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e6b881fb-4f15-4dd4-b68d-de19ff94880f_0">
											<gml:posList>35.66988452828659 139.74848780028674 70.173 35.669929629580466 139.74854692704392 70.173 35.669952460976596 139.74852077863443 70.173 35.66990735966226 139.748461640829 70.173 35.66988452828659 139.74848780028674 70.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97aeca1a-0eb6-4416-9ca4-70c3bbcdafd1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-97aeca1a-0eb6-4416-9ca4-70c3bbcdafd1_0">
											<gml:posList>35.669952460976596 139.74852077863443 65.62 35.66990735966226 139.748461640829 65.62 35.66990735966226 139.748461640829 70.173 35.669952460976596 139.74852077863443 70.173 35.669952460976596 139.74852077863443 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5273d29e-43ce-4139-a6fe-989f05d53507">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5273d29e-43ce-4139-a6fe-989f05d53507_0">
											<gml:posList>35.66994198427403 139.7484273499121 69.035 35.66994198427403 139.7484273499121 65.62 35.66993663466195 139.7484337955112 65.62 35.66993663466195 139.7484337955112 69.035 35.66994198427403 139.7484273499121 69.035</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-039f58f5-02cc-4d25-8003-0552f88b35af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-039f58f5-02cc-4d25-8003-0552f88b35af_0">
											<gml:posList>35.669929629580466 139.74854692704392 65.62 35.669952460976596 139.74852077863443 65.62 35.669952460976596 139.74852077863443 70.173 35.669929629580466 139.74854692704392 70.173 35.669929629580466 139.74854692704392 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ffdd297d-3520-4828-94ff-fed0af50f79f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ffdd297d-3520-4828-94ff-fed0af50f79f_0">
											<gml:posList>35.66995084340825 139.7484381989463 65.62 35.66994198427403 139.7484273499121 65.62 35.66994198427403 139.7484273499121 69.035 35.66995084340825 139.7484381989463 69.035 35.66995084340825 139.7484381989463 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa5dc79b-b2fa-45d1-93c6-2c9866593e3a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aa5dc79b-b2fa-45d1-93c6-2c9866593e3a_0">
											<gml:posList>35.66996037065773 139.74846339629246 65.62 35.66996037065773 139.74846339629246 69.035 35.66993663466195 139.7484337955112 69.035 35.66993663466195 139.7484337955112 65.62 35.66996037065773 139.74846339629246 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ac61d54-a1d9-43bc-9699-39b82528a6d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3ac61d54-a1d9-43bc-9699-39b82528a6d8_0">
											<gml:posList>35.6699593002868 139.74842824840997 69.035 35.6699593002868 139.74842824840997 65.62 35.66995084340825 139.7484381989463 65.62 35.66995084340825 139.7484381989463 69.035 35.6699593002868 139.74842824840997 69.035</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-244cca23-1998-46e6-9dc7-524c3d324dc7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-244cca23-1998-46e6-9dc7-524c3d324dc7_0">
											<gml:posList>35.6699593002868 139.74842824840997 69.035 35.66995084340825 139.7484381989463 69.035 35.66994198427403 139.7484273499121 69.035 35.66993663466195 139.7484337955112 69.035 35.66996037065773 139.74846339629246 69.035 35.66997415897605 139.74844679029857 69.035 35.6699593002868 139.74842824840997 69.035</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a9e5df2-be6f-41a0-ba61-ace923530595">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5a9e5df2-be6f-41a0-ba61-ace923530595_0">
											<gml:posList>35.66996388223336 139.74857320287813 65.62 35.66996388223336 139.74857320287813 69.175 35.66995089926607 139.748555863021 69.175 35.66995089926607 139.748555863021 65.62 35.66996388223336 139.74857320287813 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b203dd6a-5d25-40f8-90cf-1f58d1d12458">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b203dd6a-5d25-40f8-90cf-1f58d1d12458_0">
											<gml:posList>35.669972019736605 139.74853210239678 65.62 35.66995089926607 139.748555863021 65.62 35.66995089926607 139.748555863021 69.175 35.669972019736605 139.74853210239678 69.175 35.669972019736605 139.74853210239678 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f2b1bbc0-b91d-4970-9b24-1ca231a52bb0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f2b1bbc0-b91d-4970-9b24-1ca231a52bb0_0">
											<gml:posList>35.6699593002868 139.74842824840997 69.035 35.66997415897605 139.74844679029857 69.035 35.66997415897605 139.74844679029857 65.62 35.6699593002868 139.74842824840997 65.62 35.6699593002868 139.74842824840997 69.035</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c297e1ae-7031-4ec9-9951-585f28f00c90">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c297e1ae-7031-4ec9-9951-585f28f00c90_0">
											<gml:posList>35.66996037065773 139.74846339629246 65.62 35.66997415897605 139.74844679029857 65.62 35.66997415897605 139.74844679029857 69.035 35.66996037065773 139.74846339629246 69.035 35.66996037065773 139.74846339629246 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c336eed-3cc8-40b0-9a05-0492088db99a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c336eed-3cc8-40b0-9a05-0492088db99a_0">
											<gml:posList>35.66995089926607 139.748555863021 69.175 35.66996388223336 139.74857320287813 69.175 35.66998500271504 139.74854945330083 69.175 35.669972019736605 139.74853210239678 69.175 35.66995089926607 139.748555863021 69.175</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b841133-a91b-4039-a6b4-11a9a7d6ffdf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7b841133-a91b-4039-a6b4-11a9a7d6ffdf_0">
											<gml:posList>35.66996388223336 139.74857320287813 65.62 35.66998500271504 139.74854945330083 65.62 35.66998500271504 139.74854945330083 69.175 35.66996388223336 139.74857320287813 69.175 35.66996388223336 139.74857320287813 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-50544d6d-0074-402c-ae23-154c8e9715c4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-50544d6d-0074-402c-ae23-154c8e9715c4_0">
											<gml:posList>35.66998500271504 139.74854945330083 65.62 35.669972019736605 139.74853210239678 65.62 35.669972019736605 139.74853210239678 69.175 35.66998500271504 139.74854945330083 69.175 35.66998500271504 139.74854945330083 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-731ebd9a-0fc4-41d5-8787-88e5f0d6322a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-731ebd9a-0fc4-41d5-8787-88e5f0d6322a_0">
											<gml:posList>35.66997290874643 139.74841223909579 69.035 35.66998699452617 139.7483956548678 69.035 35.66998699452617 139.7483956548678 65.62 35.66997290874643 139.74841223909579 65.62 35.66997290874643 139.74841223909579 69.035</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8a41632-6352-4c7f-9ad7-635a1b5fad8c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b8a41632-6352-4c7f-9ad7-635a1b5fad8c_0">
											<gml:posList>35.66997290874643 139.74841223909579 69.035 35.66997290874643 139.74841223909579 65.62 35.66998797596102 139.74843249292573 65.62 35.66998797596102 139.74843249292573 69.035 35.66997290874643 139.74841223909579 69.035</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8204f8d8-0056-45d5-b638-f30970d33ed4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8204f8d8-0056-45d5-b638-f30970d33ed4_0">
											<gml:posList>35.669980591659126 139.74849351998225 65.62 35.66998481384152 139.748498850832 65.62 35.66998481384152 139.748498850832 68.616 35.669980591659126 139.74849351998225 68.616 35.669980591659126 139.74849351998225 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-91ced20b-db24-4b30-b581-32dd7a1295c8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-91ced20b-db24-4b30-b581-32dd7a1295c8_0">
											<gml:posList>35.66997860409426 139.74852545666369 65.62 35.66998840240503 139.74853880116302 65.62 35.66998840240503 139.74853880116302 71.303 35.66997860409426 139.74852545666369 71.303 35.66997860409426 139.74852545666369 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e1a9ec87-6784-4de8-8937-f71f4e608a58">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e1a9ec87-6784-4de8-8937-f71f4e608a58_0">
											<gml:posList>35.66998982648962 139.7485130840884 65.62 35.66997860409426 139.74852545666369 65.62 35.66997860409426 139.74852545666369 71.303 35.66998982648962 139.7485130840884 71.303 35.66998982648962 139.7485130840884 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7aa0daad-4d67-4fe0-b7e2-45e43d2e133d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7aa0daad-4d67-4fe0-b7e2-45e43d2e133d_0">
											<gml:posList>35.66997290874643 139.74841223909579 69.035 35.66998797596102 139.74843249292573 69.035 35.670002404592246 139.7484163722758 69.035 35.66998699452617 139.7483956548678 69.035 35.66997290874643 139.74841223909579 69.035</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a80bf01-e26e-4a42-b2ad-b1f83b1e2745">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a80bf01-e26e-4a42-b2ad-b1f83b1e2745_0">
											<gml:posList>35.66998840240503 139.74853880116302 71.303 35.66999962480174 139.74852642858804 71.303 35.66998982648962 139.7485130840884 71.303 35.66997860409426 139.74852545666369 71.303 35.66998840240503 139.74853880116302 71.303</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a336f557-f0f5-42f8-9dba-017a61677abf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a336f557-f0f5-42f8-9dba-017a61677abf_0">
											<gml:posList>35.66998840240503 139.74853880116302 65.62 35.66999962480174 139.74852642858804 65.62 35.66999962480174 139.74852642858804 71.303 35.66998840240503 139.74853880116302 71.303 35.66998840240503 139.74853880116302 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-72fe4290-d24e-473e-bb95-55cb22897613">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-72fe4290-d24e-473e-bb95-55cb22897613_0">
											<gml:posList>35.66999962480174 139.74852642858804 65.62 35.66998982648962 139.7485130840884 65.62 35.66998982648962 139.7485130840884 71.303 35.66999962480174 139.74852642858804 71.303 35.66999962480174 139.74852642858804 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f13832cc-31a7-4329-ac6b-8f8951c9359a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f13832cc-31a7-4329-ac6b-8f8951c9359a_0">
											<gml:posList>35.66998699452617 139.7483956548678 69.035 35.670002404592246 139.7484163722758 69.035 35.670002404592246 139.7484163722758 65.62 35.66998699452617 139.7483956548678 65.62 35.66998699452617 139.7483956548678 69.035</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0662336e-f8e8-4e78-afe2-536993222b3b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0662336e-f8e8-4e78-afe2-536993222b3b_0">
											<gml:posList>35.66998982519795 139.74851125041948 65.62 35.67000007462444 139.7485252019832 65.62 35.67000007462444 139.7485252019832 69.175 35.66998982519795 139.74851125041948 69.175 35.66998982519795 139.74851125041948 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18dab538-c22d-4648-aaf9-56e28d8413b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-18dab538-c22d-4648-aaf9-56e28d8413b0_0">
											<gml:posList>35.66998797596102 139.74843249292573 65.62 35.670002404592246 139.7484163722758 65.62 35.670002404592246 139.7484163722758 69.035 35.66998797596102 139.74843249292573 69.035 35.66998797596102 139.74843249292573 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7d62b9cd-8f8b-41ab-8699-48e80b08af50">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7d62b9cd-8f8b-41ab-8699-48e80b08af50_0">
											<gml:posList>35.669980591659126 139.74849351998225 65.62 35.669980591659126 139.74849351998225 68.616 35.670017273788595 139.74844981549862 68.616 35.670017273788595 139.74844981549862 65.62 35.669980591659126 139.74849351998225 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26183c9a-ef2c-42bf-8663-eb8baebe0343">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-26183c9a-ef2c-42bf-8663-eb8baebe0343_0">
											<gml:posList>35.670021495972904 139.7484551463485 68.616 35.670017273788595 139.74844981549862 68.616 35.669980591659126 139.74849351998225 68.616 35.66998481384152 139.748498850832 68.616 35.670021495972904 139.7484551463485 68.616</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8bc7298-cf2b-4797-8a49-ea6341692fd0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8bc7298-cf2b-4797-8a49-ea6341692fd0_0">
											<gml:posList>35.66998982519795 139.74851125041948 65.62 35.66998982519795 139.74851125041948 69.175 35.670015080087246 139.7484834093454 69.175 35.670015080087246 139.7484834093454 65.62 35.66998982519795 139.74851125041948 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4eeb7aa2-81f6-4657-9087-0e8c688aada0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4eeb7aa2-81f6-4657-9087-0e8c688aada0_0">
											<gml:posList>35.66998481384152 139.748498850832 65.62 35.670021495972904 139.7484551463485 65.62 35.670021495972904 139.7484551463485 68.616 35.66998481384152 139.748498850832 68.616 35.66998481384152 139.748498850832 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec7fd6bb-a63f-47b2-8316-49e0cc15f9a0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ec7fd6bb-a63f-47b2-8316-49e0cc15f9a0_0">
											<gml:posList>35.66995966155271 139.74858280648976 66.64 35.670052506965355 139.74847326245114 66.64 35.670052506965355 139.74847326245114 65.62 35.66995966155271 139.74858280648976 65.62 35.66995966155271 139.74858280648976 66.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf77a652-96c4-4d94-8c46-eef1bd91b2db">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cf77a652-96c4-4d94-8c46-eef1bd91b2db_0">
											<gml:posList>35.66998982519795 139.74851125041948 69.175 35.67000007462444 139.7485252019832 69.175 35.67002532951692 139.74849736090997 69.175 35.670015080087246 139.7484834093454 69.175 35.66998982519795 139.74851125041948 69.175</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a61055d5-c2f9-427a-85ab-799d1c220bb4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a61055d5-c2f9-427a-85ab-799d1c220bb4_0">
											<gml:posList>35.66995966155271 139.74858280648976 66.64 35.669963676291104 139.74858796082285 66.64 35.67005681942598 139.74847879204097 66.64 35.670052506965355 139.74847326245114 66.64 35.66995966155271 139.74858280648976 66.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7d608620-361e-40df-b699-401e74798f84">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7d608620-361e-40df-b699-401e74798f84_0">
											<gml:posList>35.669963615387296 139.7485910759164 65.62 35.669963615387296 139.7485910759164 66.64 35.67005936135095 139.74847886667428 66.64 35.67005936135095 139.74847886667428 65.62 35.669963615387296 139.7485910759164 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d5dd21f-e85e-4ae4-9728-c6d6d167725d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d5dd21f-e85e-4ae4-9728-c6d6d167725d_0">
											<gml:posList>35.67000007462444 139.7485252019832 65.62 35.67002532951692 139.74849736090997 65.62 35.67002532951692 139.74849736090997 69.175 35.67000007462444 139.7485252019832 69.175 35.67000007462444 139.7485252019832 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc4ada0d-543e-439f-a7ea-c5374fc5d6e9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bc4ada0d-543e-439f-a7ea-c5374fc5d6e9_0">
											<gml:posList>35.670017273788595 139.74844981549862 65.62 35.670017273788595 139.74844981549862 68.616 35.670021495972904 139.7484551463485 68.616 35.670021495972904 139.7484551463485 65.62 35.670017273788595 139.74844981549862 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-34f1dc1c-08c6-4c67-9f5f-a2f320df7460">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-34f1dc1c-08c6-4c67-9f5f-a2f320df7460_0">
											<gml:posList>35.67002532951692 139.74849736090997 65.62 35.670015080087246 139.7484834093454 65.62 35.670015080087246 139.7484834093454 69.175 35.67002532951692 139.74849736090997 69.175 35.67002532951692 139.74849736090997 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6874e0fb-f0a6-4d6d-ad24-c8e8bf68af9b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6874e0fb-f0a6-4d6d-ad24-c8e8bf68af9b_0">
											<gml:posList>35.67002397956833 139.74847477283652 65.62 35.67003223466961 139.74848546787925 65.62 35.67003223466961 139.74848546787925 69.645 35.67002397956833 139.74847477283652 69.645 35.67002397956833 139.74847477283652 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5535bf3b-7def-4c05-94e7-23b60b7c97a3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5535bf3b-7def-4c05-94e7-23b60b7c97a3_0">
											<gml:posList>35.67002397956833 139.74847477283652 65.62 35.67002397956833 139.74847477283652 69.645 35.67003347228856 139.74846377180833 69.645 35.67003347228856 139.74846377180833 65.62 35.67002397956833 139.74847477283652 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7b544de-0c39-420c-863d-f27d23e292a3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c7b544de-0c39-420c-863d-f27d23e292a3_0">
											<gml:posList>35.67003223466961 139.74848546787925 69.645 35.6700417273908 139.7484744668512 69.645 35.67003347228856 139.74846377180833 69.645 35.67002397956833 139.74847477283652 69.645 35.67003223466961 139.74848546787925 69.645</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a62f80da-78f5-430c-aae4-6f49db279aba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a62f80da-78f5-430c-aae4-6f49db279aba_0">
											<gml:posList>35.67003223466961 139.74848546787925 65.62 35.6700417273908 139.7484744668512 65.62 35.6700417273908 139.7484744668512 69.645 35.67003223466961 139.74848546787925 69.645 35.67003223466961 139.74848546787925 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f52c5104-e43a-4828-ac31-1d698d6e2a6a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f52c5104-e43a-4828-ac31-1d698d6e2a6a_0">
											<gml:posList>35.67003347228856 139.74846377180833 65.62 35.67003347228856 139.74846377180833 69.645 35.6700417273908 139.7484744668512 69.645 35.6700417273908 139.7484744668512 65.62 35.67003347228856 139.74846377180833 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d3819f94-f6d6-4309-8642-d77145802dda">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d3819f94-f6d6-4309-8642-d77145802dda_0">
											<gml:posList>35.67005380386748 139.74847173670082 65.62 35.67005936135095 139.74847886667428 65.62 35.67005936135095 139.74847886667428 66.64 35.67005380386748 139.74847173670082 66.64 35.67005380386748 139.74847173670082 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-03e65cd4-68b0-426f-ba6d-6966970b6f41">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-03e65cd4-68b0-426f-ba6d-6966970b6f41_0">
											<gml:posList>35.67005380386748 139.74847173670082 66.64 35.67006108090828 139.7484631460887 66.64 35.67006108090828 139.7484631460887 65.62 35.67005380386748 139.74847173670082 65.62 35.67005380386748 139.74847173670082 66.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58c1fc57-fc9c-496b-b2ab-719b853a763e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-58c1fc57-fc9c-496b-b2ab-719b853a763e_0">
											<gml:posList>35.67007320619144 139.74847850958926 66.64 35.67007320619144 139.74847850958926 65.62 35.67006108090828 139.7484631460887 65.62 35.67006108090828 139.7484631460887 66.64 35.67007320619144 139.74847850958926 66.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_490611ae-9d1c-4c45-894e-e730435000fa_BuildingInstallation_1031">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8741edd8-c711-42da-8fe4-63c4d7663b14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67005114807459 139.7485659416323 65.62 35.670065754420385 139.74858457220412 65.62 35.67003144971325 139.74862521434022 65.62 35.67000884329476 139.7485996220649 65.62 35.67001577811862 139.7485914515869 65.62 35.66999735557776 139.7485680089132 65.62 35.670044305149105 139.7485126066997 65.62 35.67007033106252 139.748542845803 65.62 35.67005114807459 139.7485659416323 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e58925a4-c1a1-47de-ba62-d92f1a8d906e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66985958536408 139.74866434477366 65.62 35.6698613923071 139.74865749422847 65.62 35.669870719526536 139.74864184297306 65.62 35.66990841138008 139.74859832533545 65.62 35.66991596279372 139.7486081595158 65.62 35.66988410709193 139.74864493281194 65.62 35.66988681368002 139.7486484426423 65.62 35.66984190766826 139.74870029668458 65.62 35.66983557424085 139.74869206291564 65.62 35.66985958536408 139.74866434477366 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-703f6313-d59d-4ce4-a3f0-555b292e4cd6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66992444666757 139.74875197204167 65.62 35.669909975762764 139.74873363957644 65.62 35.66988665825395 139.748760749443 65.62 35.6698615141718 139.7487282780775 65.62 35.66994627209964 139.7486282757575 65.62 35.66998776950169 139.74867695673288 65.62 35.66992444666757 139.74875197204167 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f322bbf-d378-46e8-b635-311c3575a631">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66984190766826 139.74870029668458 65.62 35.66983475656171 139.74870854468696 65.62 35.669860460167605 139.7487419654174 65.62 35.6698560109955 139.74874710658884 65.62 35.66982730305686 139.74870975658783 65.62 35.66982648951593 139.7487064767298 65.62 35.66982648814958 139.7487045326029 65.62 35.669826937461714 139.74870257695406 65.62 35.66983557424085 139.74869206291564 65.62 35.66984190766826 139.74870029668458 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ed74be80-ba63-427a-bbe3-1cb4f0d23873">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ed74be80-ba63-427a-bbe3-1cb4f0d23873_0">
											<gml:posList>35.66984190766826 139.74870029668458 65.62 35.66984190766826 139.74870029668458 66.64 35.66983557424085 139.74869206291564 66.64 35.66983557424085 139.74869206291564 65.62 35.66984190766826 139.74870029668458 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-548a459c-1699-4f86-b32d-cfc82febf231">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-548a459c-1699-4f86-b32d-cfc82febf231_0">
											<gml:posList>35.66983557424085 139.74869206291564 65.62 35.66983557424085 139.74869206291564 66.64 35.66984190766826 139.74870029668458 66.64 35.66984190766826 139.74870029668458 65.62 35.66983557424085 139.74869206291564 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8345bbd-398f-4310-858a-ff5813eecf50">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d8345bbd-398f-4310-858a-ff5813eecf50_0">
											<gml:posList>35.66982648951593 139.7487064767298 65.62 35.66982648951593 139.7487064767298 66.64 35.66982648814958 139.7487045326029 66.64 35.66982648814958 139.7487045326029 65.62 35.66982648951593 139.7487064767298 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11075dee-a0a9-4148-85d0-39b13e53b884">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-11075dee-a0a9-4148-85d0-39b13e53b884_0">
											<gml:posList>35.66982648814958 139.7487045326029 65.62 35.66982648814958 139.7487045326029 66.64 35.669826937461714 139.74870257695406 66.64 35.669826937461714 139.74870257695406 65.62 35.66982648814958 139.7487045326029 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57914d2d-e8bd-41e8-9a51-10f08bf173cc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-57914d2d-e8bd-41e8-9a51-10f08bf173cc_0">
											<gml:posList>35.66982730305686 139.74870975658783 66.64 35.66982648951593 139.7487064767298 66.64 35.66982648951593 139.7487064767298 65.62 35.66982730305686 139.74870975658783 65.62 35.66982730305686 139.74870975658783 66.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8696af9a-09c2-45e8-94b3-79e8d62c4667">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8696af9a-09c2-45e8-94b3-79e8d62c4667_0">
											<gml:posList>35.669826937461714 139.74870257695406 65.62 35.669826937461714 139.74870257695406 66.64 35.66983557424085 139.74869206291564 66.64 35.66983557424085 139.74869206291564 65.62 35.669826937461714 139.74870257695406 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-85dcc225-faf1-4404-bdf0-55cc0e813491">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-85dcc225-faf1-4404-bdf0-55cc0e813491_0">
											<gml:posList>35.66984190766826 139.74870029668458 65.62 35.66984190766826 139.74870029668458 66.64 35.66983475656171 139.74870854468696 66.64 35.66983475656171 139.74870854468696 65.62 35.66984190766826 139.74870029668458 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fbbfcfa5-9d2f-416c-8ac6-f5e2dbcd7d80">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fbbfcfa5-9d2f-416c-8ac6-f5e2dbcd7d80_0">
											<gml:posList>35.6698560109955 139.74874710658884 65.62 35.6698560109955 139.74874710658884 66.64 35.66982730305686 139.74870975658783 66.64 35.66982730305686 139.74870975658783 65.62 35.6698560109955 139.74874710658884 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-93ab8a32-9e9e-40e8-885c-8c302f544ba1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-93ab8a32-9e9e-40e8-885c-8c302f544ba1_0">
											<gml:posList>35.669826937461714 139.74870257695406 66.64 35.66982648814958 139.7487045326029 66.64 35.66982648951593 139.7487064767298 66.64 35.66982730305686 139.74870975658783 66.64 35.6698560109955 139.74874710658884 66.64 35.669860460167605 139.7487419654174 66.64 35.66983475656171 139.74870854468696 66.64 35.66984190766826 139.74870029668458 66.64 35.66983557424085 139.74869206291564 66.64 35.669826937461714 139.74870257695406 66.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea3ec449-0a61-444d-bd9e-1ca64f1081ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea3ec449-0a61-444d-bd9e-1ca64f1081ca_0">
											<gml:posList>35.66983475656171 139.74870854468696 66.64 35.669860460167605 139.7487419654174 66.64 35.669860460167605 139.7487419654174 65.62 35.66983475656171 139.74870854468696 65.62 35.66983475656171 139.74870854468696 66.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-54d03227-984c-4152-8383-f57da2b690f9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-54d03227-984c-4152-8383-f57da2b690f9_0">
											<gml:posList>35.66983557424085 139.74869206291564 66.64 35.66985958536408 139.74866434477366 66.64 35.66985958536408 139.74866434477366 65.62 35.66983557424085 139.74869206291564 65.62 35.66983557424085 139.74869206291564 66.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b1c1dd3-0681-40a0-a486-724fdc9c1a1f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1b1c1dd3-0681-40a0-a486-724fdc9c1a1f_0">
											<gml:posList>35.669860460167605 139.7487419654174 65.62 35.669860460167605 139.7487419654174 66.64 35.6698560109955 139.74874710658884 66.64 35.6698560109955 139.74874710658884 65.62 35.669860460167605 139.7487419654174 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0620fc5-1985-414c-9695-044b37d1fa42">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0620fc5-1985-414c-9695-044b37d1fa42_0">
											<gml:posList>35.66985958536408 139.74866434477366 65.62 35.66985958536408 139.74866434477366 66.64 35.6698613923071 139.74865749422847 66.64 35.6698613923071 139.74865749422847 65.62 35.66985958536408 139.74866434477366 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76fcc777-35a8-4d8c-92b2-4a6e92b61cb1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-76fcc777-35a8-4d8c-92b2-4a6e92b61cb1_0">
											<gml:posList>35.66988681368002 139.7486484426423 65.62 35.66988681368002 139.7486484426423 66.64 35.66984190766826 139.74870029668458 66.64 35.66984190766826 139.74870029668458 65.62 35.66988681368002 139.7486484426423 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-49daa2f9-f768-4513-ad82-0d7edf562225">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-49daa2f9-f768-4513-ad82-0d7edf562225_0">
											<gml:posList>35.6698613923071 139.74865749422847 65.62 35.6698613923071 139.74865749422847 66.64 35.669870719526536 139.74864184297306 66.64 35.669870719526536 139.74864184297306 65.62 35.6698613923071 139.74865749422847 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2299d765-2d7b-4932-9ff1-d6eac88be3eb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2299d765-2d7b-4932-9ff1-d6eac88be3eb_0">
											<gml:posList>35.6698615141718 139.7487282780775 65.62 35.66988665825395 139.748760749443 65.62 35.66988665825395 139.748760749443 69.626 35.6698615141718 139.7487282780775 69.626 35.6698615141718 139.7487282780775 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b42a95f-1ae8-462d-a840-e1d3d364fa0c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b42a95f-1ae8-462d-a840-e1d3d364fa0c_0">
											<gml:posList>35.66984190766826 139.74870029668458 66.64 35.66988681368002 139.7486484426423 66.64 35.66988410709193 139.74864493281194 66.64 35.66991596279372 139.7486081595158 66.64 35.66990841138008 139.74859832533545 66.64 35.669870719526536 139.74864184297306 66.64 35.6698613923071 139.74865749422847 66.64 35.66985958536408 139.74866434477366 66.64 35.66983557424085 139.74869206291564 66.64 35.66984190766826 139.74870029668458 66.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f9fe4a1-7529-4dbc-9e64-38480c77449d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0f9fe4a1-7529-4dbc-9e64-38480c77449d_0">
											<gml:posList>35.66988410709193 139.74864493281194 65.62 35.66988410709193 139.74864493281194 66.64 35.66988681368002 139.7486484426423 66.64 35.66988681368002 139.7486484426423 65.62 35.66988410709193 139.74864493281194 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d07ceeb6-8c9a-464a-8f15-f8a9a050ef52">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d07ceeb6-8c9a-464a-8f15-f8a9a050ef52_0">
											<gml:posList>35.669870719526536 139.74864184297306 65.62 35.669870719526536 139.74864184297306 66.64 35.66990841138008 139.74859832533545 66.64 35.66990841138008 139.74859832533545 65.62 35.669870719526536 139.74864184297306 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc8dd0ae-d1f4-445e-8e0f-472a942a6a2f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dc8dd0ae-d1f4-445e-8e0f-472a942a6a2f_0">
											<gml:posList>35.66988665825395 139.748760749443 65.62 35.669909975762764 139.74873363957644 65.62 35.669909975762764 139.74873363957644 69.626 35.66988665825395 139.748760749443 69.626 35.66988665825395 139.748760749443 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e29d5b8-436a-4513-bc3a-e7fbed956ea2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7e29d5b8-436a-4513-bc3a-e7fbed956ea2_0">
											<gml:posList>35.66991596279372 139.7486081595158 65.62 35.66991596279372 139.7486081595158 66.64 35.66988410709193 139.74864493281194 66.64 35.66988410709193 139.74864493281194 65.62 35.66991596279372 139.7486081595158 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8fc755d2-9e19-451e-a1a4-96cc3985239b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8fc755d2-9e19-451e-a1a4-96cc3985239b_0">
											<gml:posList>35.66994627209964 139.7486282757575 65.62 35.6698615141718 139.7487282780775 65.62 35.6698615141718 139.7487282780775 69.626 35.66994627209964 139.7486282757575 69.626 35.66994627209964 139.7486282757575 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-742171bd-afe8-42c0-9d49-a47483c4ec4b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-742171bd-afe8-42c0-9d49-a47483c4ec4b_0">
											<gml:posList>35.66990841138008 139.74859832533545 65.62 35.66990841138008 139.74859832533545 66.64 35.66991596279372 139.7486081595158 66.64 35.66991596279372 139.7486081595158 65.62 35.66990841138008 139.74859832533545 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2070384d-dc45-45e9-9472-52d7b72e04b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2070384d-dc45-45e9-9472-52d7b72e04b4_0">
											<gml:posList>35.669909975762764 139.74873363957644 65.62 35.66992444666757 139.74875197204167 65.62 35.66992444666757 139.74875197204167 69.626 35.669909975762764 139.74873363957644 69.626 35.669909975762764 139.74873363957644 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16a8cc76-35dc-4fac-abcf-59d8874b323a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16a8cc76-35dc-4fac-abcf-59d8874b323a_0">
											<gml:posList>35.66998776950169 139.74867695673288 69.626 35.66994627209964 139.7486282757575 69.626 35.6698615141718 139.7487282780775 69.626 35.66988665825395 139.748760749443 69.626 35.669909975762764 139.74873363957644 69.626 35.66992444666757 139.74875197204167 69.626 35.66998776950169 139.74867695673288 69.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ae41e1cb-9aa5-4ed2-a499-749849c7b4f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ae41e1cb-9aa5-4ed2-a499-749849c7b4f0_0">
											<gml:posList>35.66992444666757 139.74875197204167 65.62 35.66998776950169 139.74867695673288 65.62 35.66998776950169 139.74867695673288 69.626 35.66992444666757 139.74875197204167 69.626 35.66992444666757 139.74875197204167 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38e15755-7f81-45f7-89f7-a36127ae9d32">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-38e15755-7f81-45f7-89f7-a36127ae9d32_0">
											<gml:posList>35.66998776950169 139.74867695673288 65.62 35.66994627209964 139.7486282757575 65.62 35.66994627209964 139.7486282757575 69.626 35.66998776950169 139.74867695673288 69.626 35.66998776950169 139.74867695673288 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b95d9e56-fc17-4886-a706-1015485504d9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b95d9e56-fc17-4886-a706-1015485504d9_0">
											<gml:posList>35.66999735557776 139.7485680089132 65.62 35.67001577811862 139.7485914515869 65.62 35.67001577811862 139.7485914515869 69.981 35.66999735557776 139.7485680089132 69.981 35.66999735557776 139.7485680089132 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b144a2b1-5b84-4820-8f2b-4dbb8785c77a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b144a2b1-5b84-4820-8f2b-4dbb8785c77a_0">
											<gml:posList>35.67001577811862 139.7485914515869 65.62 35.67000884329476 139.7485996220649 65.62 35.67000884329476 139.7485996220649 69.981 35.67001577811862 139.7485914515869 69.981 35.67001577811862 139.7485914515869 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca477892-69ac-4d4b-866e-096abb4da1bd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ca477892-69ac-4d4b-866e-096abb4da1bd_0">
											<gml:posList>35.67000884329476 139.7485996220649 65.62 35.67003144971325 139.74862521434022 65.62 35.67003144971325 139.74862521434022 69.981 35.67000884329476 139.7485996220649 69.981 35.67000884329476 139.7485996220649 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d9461e7e-0df4-4313-962d-de8abf878eb6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d9461e7e-0df4-4313-962d-de8abf878eb6_0">
											<gml:posList>35.670044305149105 139.7485126066997 65.62 35.66999735557776 139.7485680089132 65.62 35.66999735557776 139.7485680089132 69.981 35.670044305149105 139.7485126066997 69.981 35.670044305149105 139.7485126066997 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9fb392c-7025-4c9c-b1d8-bf1d81cba209">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b9fb392c-7025-4c9c-b1d8-bf1d81cba209_0">
											<gml:posList>35.67007033106252 139.748542845803 69.981 35.670044305149105 139.7485126066997 69.981 35.66999735557776 139.7485680089132 69.981 35.67001577811862 139.7485914515869 69.981 35.67000884329476 139.7485996220649 69.981 35.67003144971325 139.74862521434022 69.981 35.670065754420385 139.74858457220412 69.981 35.67005114807459 139.7485659416323 69.981 35.67007033106252 139.748542845803 69.981</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c9e167f0-25c6-4828-814e-0ea2a5daaeb3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c9e167f0-25c6-4828-814e-0ea2a5daaeb3_0">
											<gml:posList>35.67003144971325 139.74862521434022 65.62 35.670065754420385 139.74858457220412 65.62 35.670065754420385 139.74858457220412 69.981 35.67003144971325 139.74862521434022 69.981 35.67003144971325 139.74862521434022 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8913b09b-ac40-4f98-a097-f80b6ba65f56">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8913b09b-ac40-4f98-a097-f80b6ba65f56_0">
											<gml:posList>35.67007033106252 139.748542845803 65.62 35.670044305149105 139.7485126066997 65.62 35.670044305149105 139.7485126066997 69.981 35.67007033106252 139.748542845803 69.981 35.67007033106252 139.748542845803 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce32aa4c-7775-463c-ae32-bf81a7623351">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce32aa4c-7775-463c-ae32-bf81a7623351_0">
											<gml:posList>35.670065754420385 139.74858457220412 65.62 35.67005114807459 139.7485659416323 65.62 35.67005114807459 139.7485659416323 69.981 35.670065754420385 139.74858457220412 69.981 35.670065754420385 139.74858457220412 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c8dd8d98-8792-4d21-b612-42ae4af2f81b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c8dd8d98-8792-4d21-b612-42ae4af2f81b_0">
											<gml:posList>35.67005114807459 139.7485659416323 65.62 35.67007033106252 139.748542845803 65.62 35.67007033106252 139.748542845803 69.981 35.67005114807459 139.7485659416323 69.981 35.67005114807459 139.7485659416323 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_490611ae-9d1c-4c45-894e-e730435000fa_BuildingInstallation_1061">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-50f8b280-2291-4dfa-bbe2-df3feb7b2fc9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-50f8b280-2291-4dfa-bbe2-df3feb7b2fc9_0">
											<gml:posList>35.67003222578325 139.74844728113285 65.62 35.669939082668805 139.74855643887153 68.688 35.669939082668805 139.74855643887153 65.62 35.67003222578325 139.74844728113285 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0294e885-6a14-45e2-a0ec-bedc1f741a56">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0294e885-6a14-45e2-a0ec-bedc1f741a56_0">
											<gml:posList>35.67003222578325 139.74844728113285 65.62 35.67003222578325 139.74844728113285 68.688 35.669939082668805 139.74855643887153 68.688 35.67003222578325 139.74844728113285 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1bf4f185-1b66-4206-acec-8f89b882e563">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1bf4f185-1b66-4206-acec-8f89b882e563_0">
											<gml:posList>35.669963676291104 139.74858796082285 65.62 35.67005681942598 139.74847879204097 68.688 35.67005681942598 139.74847879204097 65.62 35.669963676291104 139.74858796082285 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f079074-6b2e-4b36-8b59-43e796fe24c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f079074-6b2e-4b36-8b59-43e796fe24c3_0">
											<gml:posList>35.669963676291104 139.74858796082285 65.62 35.669963676291104 139.74858796082285 68.688 35.67005681942598 139.74847879204097 68.688 35.669963676291104 139.74858796082285 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b886a7e7-7f60-41bb-acf1-ed604d6d2987">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b886a7e7-7f60-41bb-acf1-ed604d6d2987_0">
											<gml:posList>35.670032277661825 139.74844415499985 65.62 35.67005936135095 139.74847886667428 68.688 35.67005936135095 139.74847886667428 65.62 35.670032277661825 139.74844415499985 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-15ad80fa-176d-4da5-a6bb-aeed7ec39fda">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-15ad80fa-176d-4da5-a6bb-aeed7ec39fda_0">
											<gml:posList>35.670032277661825 139.74844415499985 65.62 35.670032277661825 139.74844415499985 68.688 35.67005936135095 139.74847886667428 68.688 35.670032277661825 139.74844415499985 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74c2381e-4eb3-4acb-bf94-6e8ec6cbf57a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-74c2381e-4eb3-4acb-bf94-6e8ec6cbf57a_0">
											<gml:posList>35.67005681942598 139.74847879204097 65.62 35.67003222578325 139.74844728113285 68.688 35.67003222578325 139.74844728113285 65.62 35.67005681942598 139.74847879204097 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-afad5158-689a-4e4b-bfb3-a5e60c8a66a9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-afad5158-689a-4e4b-bfb3-a5e60c8a66a9_0">
											<gml:posList>35.67005681942598 139.74847879204097 65.62 35.67005681942598 139.74847879204097 68.688 35.67003222578325 139.74844728113285 68.688 35.67005681942598 139.74847879204097 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-548ff1cd-e331-428f-ab61-fdc9ab133553">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-548ff1cd-e331-428f-ab61-fdc9ab133553_0">
											<gml:posList>35.66993653173786 139.74855637529157 65.62 35.670032277661825 139.74844415499985 68.688 35.670032277661825 139.74844415499985 65.62 35.66993653173786 139.74855637529157 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-09730299-4b23-464a-8198-26c93b6f7a9f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-09730299-4b23-464a-8198-26c93b6f7a9f_0">
											<gml:posList>35.66993653173786 139.74855637529157 65.62 35.66993653173786 139.74855637529157 68.688 35.670032277661825 139.74844415499985 68.688 35.66993653173786 139.74855637529157 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba064588-233c-4385-b6a1-c1ecd14ef00e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba064588-233c-4385-b6a1-c1ecd14ef00e_0">
											<gml:posList>35.669963676291104 139.74858796082285 68.688 35.669963615387296 139.7485910759164 68.688 35.67005936135095 139.74847886667428 68.688 35.669963676291104 139.74858796082285 68.688</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6828fdd6-41a7-4f13-a3c7-2287516389eb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6828fdd6-41a7-4f13-a3c7-2287516389eb_0">
											<gml:posList>35.67005936135095 139.74847886667428 68.688 35.670032277661825 139.74844415499985 68.688 35.67003222578325 139.74844728113285 68.688 35.67005936135095 139.74847886667428 68.688</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ad2518c-dbd4-40d7-af2b-c8799943209d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9ad2518c-dbd4-40d7-af2b-c8799943209d_0">
											<gml:posList>35.66993653173786 139.74855637529157 68.688 35.669963615387296 139.7485910759164 68.688 35.669963676291104 139.74858796082285 68.688 35.66993653173786 139.74855637529157 68.688</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-500e2e0e-173c-405c-8503-6ae2efdea62a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-500e2e0e-173c-405c-8503-6ae2efdea62a_0">
											<gml:posList>35.670032277661825 139.74844415499985 68.688 35.66993653173786 139.74855637529157 68.688 35.669939082668805 139.74855643887153 68.688 35.670032277661825 139.74844415499985 68.688</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7163771a-092e-4e89-aa7d-0fa95a7f6106">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7163771a-092e-4e89-aa7d-0fa95a7f6106_0">
											<gml:posList>35.669963676291104 139.74858796082285 68.688 35.67005936135095 139.74847886667428 68.688 35.67005681942598 139.74847879204097 68.688 35.669963676291104 139.74858796082285 68.688</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-47c6cca8-54d0-48fe-b85e-b58c4e970bec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-47c6cca8-54d0-48fe-b85e-b58c4e970bec_0">
											<gml:posList>35.670032277661825 139.74844415499985 68.688 35.669939082668805 139.74855643887153 68.688 35.67003222578325 139.74844728113285 68.688 35.670032277661825 139.74844415499985 68.688</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f386935a-7195-4d6c-814b-bbd38f832104">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f386935a-7195-4d6c-814b-bbd38f832104_0">
											<gml:posList>35.669963676291104 139.74858796082285 68.688 35.669939082668805 139.74855643887153 68.688 35.66993653173786 139.74855637529157 68.688 35.669963676291104 139.74858796082285 68.688</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1d7f9ed-9435-431d-b6b4-5adc58cbb197">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a1d7f9ed-9435-431d-b6b4-5adc58cbb197_0">
											<gml:posList>35.67005681942598 139.74847879204097 68.688 35.67005936135095 139.74847886667428 68.688 35.67003222578325 139.74844728113285 68.688 35.67005681942598 139.74847879204097 68.688</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e298235-851b-41a7-b5fa-bb447d456518">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8e298235-851b-41a7-b5fa-bb447d456518_0">
											<gml:posList>35.67005936135095 139.74847886667428 68.688 35.669963615387296 139.7485910759164 65.62 35.67005936135095 139.74847886667428 65.62 35.67005936135095 139.74847886667428 68.688</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e84abb82-471e-4ef1-a798-08dd283d2db3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e84abb82-471e-4ef1-a798-08dd283d2db3_0">
											<gml:posList>35.67005936135095 139.74847886667428 68.688 35.669963615387296 139.7485910759164 68.688 35.669963615387296 139.7485910759164 65.62 35.67005936135095 139.74847886667428 68.688</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-23a4e2a1-c540-45b4-a3fd-0b1d569152e5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-23a4e2a1-c540-45b4-a3fd-0b1d569152e5_0">
											<gml:posList>35.669939082668805 139.74855643887153 65.62 35.669963676291104 139.74858796082285 68.688 35.669963676291104 139.74858796082285 65.62 35.669939082668805 139.74855643887153 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9248d43c-6c10-46db-b1f5-4415f1ca380c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9248d43c-6c10-46db-b1f5-4415f1ca380c_0">
											<gml:posList>35.669939082668805 139.74855643887153 65.62 35.669939082668805 139.74855643887153 68.688 35.669963676291104 139.74858796082285 68.688 35.669939082668805 139.74855643887153 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a4d13ab-6226-4998-a083-7335839941f5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5a4d13ab-6226-4998-a083-7335839941f5_0">
											<gml:posList>35.669963615387296 139.7485910759164 65.62 35.66993653173786 139.74855637529157 68.688 35.66993653173786 139.74855637529157 65.62 35.669963615387296 139.7485910759164 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa81aa66-4e48-4764-9810-2bd12f2c8301">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fa81aa66-4e48-4764-9810-2bd12f2c8301_0">
											<gml:posList>35.669963615387296 139.7485910759164 65.62 35.669963615387296 139.7485910759164 68.688 35.66993653173786 139.74855637529157 68.688 35.669963615387296 139.7485910759164 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99ca0e31-51ae-49a4-a8be-1b7a5d0ae8f1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67005936135095 139.74847886667428 65.62 35.67003222578325 139.74844728113285 65.62 35.670032277661825 139.74844415499985 65.62 35.67005936135095 139.74847886667428 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2705a3f9-e3b3-439b-8fc3-abc8c37a8d33">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67005936135095 139.74847886667428 65.62 35.669963615387296 139.7485910759164 65.62 35.669963676291104 139.74858796082285 65.62 35.67005936135095 139.74847886667428 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-434e8469-97d8-42e4-8aaa-b9c8981aa5e1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66993653173786 139.74855637529157 65.62 35.670032277661825 139.74844415499985 65.62 35.669939082668805 139.74855643887153 65.62 35.66993653173786 139.74855637529157 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4f2875aa-6af8-479c-83a4-f4dde7542f7a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669963676291104 139.74858796082285 65.62 35.669963615387296 139.7485910759164 65.62 35.66993653173786 139.74855637529157 65.62 35.669963676291104 139.74858796082285 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8ffef7e-0b90-4e2a-9a95-0ca7cce2955d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669939082668805 139.74855643887153 65.62 35.670032277661825 139.74844415499985 65.62 35.67003222578325 139.74844728113285 65.62 35.669939082668805 139.74855643887153 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-721f8f5c-38d3-4245-965b-30b949838aba">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67005681942598 139.74847879204097 65.62 35.67003222578325 139.74844728113285 65.62 35.67005936135095 139.74847886667428 65.62 35.67005681942598 139.74847879204097 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c92a097b-aaf6-46c6-b8da-fa2b7065c081">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67005681942598 139.74847879204097 65.62 35.67005936135095 139.74847886667428 65.62 35.669963676291104 139.74858796082285 65.62 35.67005681942598 139.74847879204097 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe701856-b290-4ed9-b620-3abf14dd9058">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669963676291104 139.74858796082285 65.62 35.66993653173786 139.74855637529157 65.62 35.669939082668805 139.74855643887153 65.62 35.669963676291104 139.74858796082285 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-1ad8a352-2fa2-4f16-a6c0-41d53fb3e3e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ad8a352-2fa2-4f16-a6c0-41d53fb3e3e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ad8a352-2fa2-4f16-a6c0-41d53fb3e3e3">
											<gml:posList>35.670096091083565 139.74856671153736 6.39 35.67011088688841 139.74858558493642 6.39 35.66992040506289 139.74881123915154 6.39 35.669905519465914 139.74879280769807 6.39 35.66985805581911 139.7488479782233 6.39 35.66971370842521 139.74866619992883 6.39 35.669761261349926 139.7486099246838 6.39 35.66974592472461 139.74859105193403 6.39 35.669936135341494 139.74836484566555 6.39 35.66995129149349 139.7483833872219 6.39 35.66999866439908 139.74832766414343 6.39 35.67014283272305 139.74851043682278 6.39 35.670096091083565 139.74856671153736 6.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bbb39c59-cc67-4964-b705-c8274b441b04">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bbb39c59-cc67-4964-b705-c8274b441b04">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bbb39c59-cc67-4964-b705-c8274b441b04">
											<gml:posList>35.669761261349926 139.7486099246838 70.6 35.66971370842521 139.74866619992883 70.6 35.669758975992416 139.74866705791393 70.6 35.66980679009753 139.74861047306848 70.6 35.669761261349926 139.7486099246838 70.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0a1d395a-42af-4b5f-8d24-b41369fa5c0d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a1d395a-42af-4b5f-8d24-b41369fa5c0d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a1d395a-42af-4b5f-8d24-b41369fa5c0d">
											<gml:posList>35.669761261349926 139.7486099246838 70.6 35.66980679009753 139.74861047306848 70.6 35.66979139933563 139.7485915230419 70.6 35.66974592472461 139.74859105193403 70.6 35.669761261349926 139.7486099246838 70.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bb6795da-0cc5-4305-b10a-ba6e46527caa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb6795da-0cc5-4305-b10a-ba6e46527caa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb6795da-0cc5-4305-b10a-ba6e46527caa">
											<gml:posList>35.66985805581911 139.7488479782233 70.6 35.669858954629895 139.7487929562116 70.6 35.669758975992416 139.74866705791393 70.6 35.66971370842521 139.74866619992883 70.6 35.66985805581911 139.7488479782233 70.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bfcccd65-a8d3-4566-a5dd-ea7a8ec592ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bfcccd65-a8d3-4566-a5dd-ea7a8ec592ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bfcccd65-a8d3-4566-a5dd-ea7a8ec592ef">
											<gml:posList>35.66974592472461 139.74859105193403 70.6 35.66979139933563 139.7485915230419 70.6 35.669935804536586 139.74841978980987 70.6 35.669936135341494 139.74836484566555 70.6 35.66974592472461 139.74859105193403 70.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b8ed22e0-2b89-49d6-a459-2ffedb429a40">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8ed22e0-2b89-49d6-a459-2ffedb429a40">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8ed22e0-2b89-49d6-a459-2ffedb429a40">
											<gml:posList>35.669905519465914 139.74879280769807 70.6 35.669906220104686 139.7487380067862 70.6 35.669858954629895 139.7487929562116 70.6 35.66985805581911 139.7488479782233 70.6 35.669905519465914 139.74879280769807 70.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5c10d49e-c801-4d8d-bab2-6312d5e1b0f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5c10d49e-c801-4d8d-bab2-6312d5e1b0f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5c10d49e-c801-4d8d-bab2-6312d5e1b0f0">
											<gml:posList>35.669905519465914 139.74879280769807 70.6 35.66992040506289 139.74881123915154 70.6 35.66992089820814 139.74875617333979 70.6 35.669906220104686 139.7487380067862 70.6 35.669905519465914 139.74879280769807 70.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3b56cd90-147e-4f9f-9276-9d05d2ab354d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3b56cd90-147e-4f9f-9276-9d05d2ab354d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3b56cd90-147e-4f9f-9276-9d05d2ab354d">
											<gml:posList>35.669906220104686 139.7487380067862 65.62 35.66992089820814 139.74875617333979 65.62 35.670065754420385 139.74858457220412 65.62 35.67005114807459 139.7485659416323 65.62 35.67009782665694 139.7485097222467 65.62 35.669997811041135 139.74838292922442 65.62 35.66995084340825 139.7484381989463 65.62 35.669935804536586 139.74841978980987 65.62 35.66979139933563 139.7485915230419 65.62 35.66980679009753 139.74861047306848 65.62 35.669758975992416 139.74866705791393 65.62 35.669858954629895 139.7487929562116 65.62 35.669906220104686 139.7487380067862 65.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e2691ef7-c407-40b1-af88-698ac961b492">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e2691ef7-c407-40b1-af88-698ac961b492">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e2691ef7-c407-40b1-af88-698ac961b492">
											<gml:posList>35.66995129149349 139.7483833872219 70.6 35.669936135341494 139.74836484566555 70.6 35.669935804536586 139.74841978980987 70.6 35.66995084340825 139.7484381989463 70.6 35.66995129149349 139.7483833872219 70.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-16c3827b-9466-4404-9699-1b7028477972">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16c3827b-9466-4404-9699-1b7028477972">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16c3827b-9466-4404-9699-1b7028477972">
											<gml:posList>35.66995129149349 139.7483833872219 70.6 35.66995084340825 139.7484381989463 70.6 35.669997811041135 139.74838292922442 70.6 35.66999866439908 139.74832766414343 70.6 35.66995129149349 139.7483833872219 70.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b53d6eb6-7139-4efa-922f-ca08fee0ec89">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b53d6eb6-7139-4efa-922f-ca08fee0ec89">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b53d6eb6-7139-4efa-922f-ca08fee0ec89">
											<gml:posList>35.67011088688841 139.74858558493642 70.6 35.670065754420385 139.74858457220412 70.6 35.66992089820814 139.74875617333979 70.6 35.66992040506289 139.74881123915154 70.6 35.67011088688841 139.74858558493642 70.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-099f0685-b5c1-4d6a-8ffc-d8e27677a2a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-099f0685-b5c1-4d6a-8ffc-d8e27677a2a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-099f0685-b5c1-4d6a-8ffc-d8e27677a2a9">
											<gml:posList>35.66999866439908 139.74832766414343 70.6 35.669997811041135 139.74838292922442 70.6 35.67009782665694 139.7485097222467 70.6 35.67014283272305 139.74851043682278 70.6 35.66999866439908 139.74832766414343 70.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-37792ce5-1d71-40b2-9690-d4dcea390066">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37792ce5-1d71-40b2-9690-d4dcea390066">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37792ce5-1d71-40b2-9690-d4dcea390066">
											<gml:posList>35.670096091083565 139.74856671153736 70.6 35.67005114807459 139.7485659416323 70.6 35.670065754420385 139.74858457220412 70.6 35.67011088688841 139.74858558493642 70.6 35.670096091083565 139.74856671153736 70.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-efdcee24-9205-4a28-9a81-1be4a63da57b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-efdcee24-9205-4a28-9a81-1be4a63da57b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-efdcee24-9205-4a28-9a81-1be4a63da57b">
											<gml:posList>35.670096091083565 139.74856671153736 70.6 35.67014283272305 139.74851043682278 70.6 35.67009782665694 139.7485097222467 70.6 35.67005114807459 139.7485659416323 70.6 35.670096091083565 139.74856671153736 70.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f8ad1cbf-4a59-47f7-ac21-5daa7ad22a35">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f8ad1cbf-4a59-47f7-ac21-5daa7ad22a35">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f8ad1cbf-4a59-47f7-ac21-5daa7ad22a35">
											<gml:posList>35.66979139933563 139.7485915230419 70.6 35.66979139933563 139.7485915230419 65.62 35.669935804536586 139.74841978980987 65.62 35.669935804536586 139.74841978980987 70.6 35.66979139933563 139.7485915230419 70.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e9123774-5a6d-40bf-bde9-6abeed303568">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e9123774-5a6d-40bf-bde9-6abeed303568">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e9123774-5a6d-40bf-bde9-6abeed303568">
											<gml:posList>35.670065754420385 139.74858457220412 70.6 35.670065754420385 139.74858457220412 65.62 35.66992089820814 139.74875617333979 65.62 35.66992089820814 139.74875617333979 70.6 35.670065754420385 139.74858457220412 70.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-612dec5e-07c3-42a8-8afe-b8d2cffaccc7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-612dec5e-07c3-42a8-8afe-b8d2cffaccc7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-612dec5e-07c3-42a8-8afe-b8d2cffaccc7">
											<gml:posList>35.66999866439908 139.74832766414343 6.39 35.66995129149349 139.7483833872219 6.39 35.66995129149349 139.7483833872219 70.6 35.66999866439908 139.74832766414343 70.6 35.66999866439908 139.74832766414343 6.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a15955e5-0222-4803-b6be-da143ecf0d02">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a15955e5-0222-4803-b6be-da143ecf0d02">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a15955e5-0222-4803-b6be-da143ecf0d02">
											<gml:posList>35.66995129149349 139.7483833872219 6.39 35.669936135341494 139.74836484566555 6.39 35.669936135341494 139.74836484566555 70.6 35.66995129149349 139.7483833872219 70.6 35.66995129149349 139.7483833872219 6.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4c58fd52-ca43-4457-8598-c4cf66168b9d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c58fd52-ca43-4457-8598-c4cf66168b9d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c58fd52-ca43-4457-8598-c4cf66168b9d">
											<gml:posList>35.66995084340825 139.7484381989463 70.6 35.66995084340825 139.7484381989463 65.62 35.669997811041135 139.74838292922442 65.62 35.669997811041135 139.74838292922442 70.6 35.66995084340825 139.7484381989463 70.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-13a9af96-5953-412a-b8bc-4d8484d61510">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13a9af96-5953-412a-b8bc-4d8484d61510">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13a9af96-5953-412a-b8bc-4d8484d61510">
											<gml:posList>35.67014283272305 139.74851043682278 6.39 35.66999866439908 139.74832766414343 6.39 35.66999866439908 139.74832766414343 70.6 35.67014283272305 139.74851043682278 70.6 35.67014283272305 139.74851043682278 6.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b7856c97-542d-43d1-b14f-b3ef9fbd3198">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b7856c97-542d-43d1-b14f-b3ef9fbd3198">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b7856c97-542d-43d1-b14f-b3ef9fbd3198">
											<gml:posList>35.669935804536586 139.74841978980987 70.6 35.669935804536586 139.74841978980987 65.62 35.66995084340825 139.7484381989463 65.62 35.66995084340825 139.7484381989463 70.6 35.669935804536586 139.74841978980987 70.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e8d77030-b255-459c-9228-76653ec2f7b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8d77030-b255-459c-9228-76653ec2f7b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8d77030-b255-459c-9228-76653ec2f7b9">
											<gml:posList>35.669997811041135 139.74838292922442 70.6 35.669997811041135 139.74838292922442 65.62 35.67009782665694 139.7485097222467 65.62 35.67009782665694 139.7485097222467 70.6 35.669997811041135 139.74838292922442 70.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-df0d64f6-0fe0-41b8-9d13-69e48a354413">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df0d64f6-0fe0-41b8-9d13-69e48a354413">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df0d64f6-0fe0-41b8-9d13-69e48a354413">
											<gml:posList>35.669936135341494 139.74836484566555 6.39 35.66974592472461 139.74859105193403 6.39 35.66974592472461 139.74859105193403 70.6 35.669936135341494 139.74836484566555 70.6 35.669936135341494 139.74836484566555 6.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b5b6f4d3-c41e-468c-9aab-7ca6d9e1d8b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b5b6f4d3-c41e-468c-9aab-7ca6d9e1d8b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b5b6f4d3-c41e-468c-9aab-7ca6d9e1d8b8">
											<gml:posList>35.67009782665694 139.7485097222467 70.6 35.67009782665694 139.7485097222467 65.62 35.67005114807459 139.7485659416323 65.62 35.67005114807459 139.7485659416323 70.6 35.67009782665694 139.7485097222467 70.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0795255a-f078-4516-b4ec-0485572d3ad8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0795255a-f078-4516-b4ec-0485572d3ad8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0795255a-f078-4516-b4ec-0485572d3ad8">
											<gml:posList>35.670096091083565 139.74856671153736 6.39 35.67014283272305 139.74851043682278 6.39 35.67014283272305 139.74851043682278 70.6 35.670096091083565 139.74856671153736 70.6 35.670096091083565 139.74856671153736 6.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5055fca0-27dc-4144-81e5-4fe1a76781ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5055fca0-27dc-4144-81e5-4fe1a76781ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5055fca0-27dc-4144-81e5-4fe1a76781ce">
											<gml:posList>35.67005114807459 139.7485659416323 70.6 35.67005114807459 139.7485659416323 65.62 35.670065754420385 139.74858457220412 65.62 35.670065754420385 139.74858457220412 70.6 35.67005114807459 139.7485659416323 70.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-398a7d08-b0af-4eb7-9590-6a61b6d25901">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-398a7d08-b0af-4eb7-9590-6a61b6d25901">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-398a7d08-b0af-4eb7-9590-6a61b6d25901">
											<gml:posList>35.67011088688841 139.74858558493642 6.39 35.670096091083565 139.74856671153736 6.39 35.670096091083565 139.74856671153736 70.6 35.67011088688841 139.74858558493642 70.6 35.67011088688841 139.74858558493642 6.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6da32acc-624d-43c7-8cea-ecf3c83a23ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6da32acc-624d-43c7-8cea-ecf3c83a23ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6da32acc-624d-43c7-8cea-ecf3c83a23ee">
											<gml:posList>35.66974592472461 139.74859105193403 6.39 35.669761261349926 139.7486099246838 6.39 35.669761261349926 139.7486099246838 70.6 35.66974592472461 139.74859105193403 70.6 35.66974592472461 139.74859105193403 6.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a5a924b1-141c-4975-ba84-579a065e3046">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5a924b1-141c-4975-ba84-579a065e3046">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5a924b1-141c-4975-ba84-579a065e3046">
											<gml:posList>35.66980679009753 139.74861047306848 70.6 35.66980679009753 139.74861047306848 65.62 35.66979139933563 139.7485915230419 65.62 35.66979139933563 139.7485915230419 70.6 35.66980679009753 139.74861047306848 70.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9db25a79-03bb-4f87-bd02-eac7ed6981a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9db25a79-03bb-4f87-bd02-eac7ed6981a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9db25a79-03bb-4f87-bd02-eac7ed6981a0">
											<gml:posList>35.669761261349926 139.7486099246838 6.39 35.66971370842521 139.74866619992883 6.39 35.66971370842521 139.74866619992883 70.6 35.669761261349926 139.7486099246838 70.6 35.669761261349926 139.7486099246838 6.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6a9e7886-2039-4cc8-8823-ece566b59935">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a9e7886-2039-4cc8-8823-ece566b59935">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a9e7886-2039-4cc8-8823-ece566b59935">
											<gml:posList>35.669758975992416 139.74866705791393 70.6 35.669758975992416 139.74866705791393 65.62 35.66980679009753 139.74861047306848 65.62 35.66980679009753 139.74861047306848 70.6 35.669758975992416 139.74866705791393 70.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5f57ff26-ff18-4a36-aa9a-5417613849b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f57ff26-ff18-4a36-aa9a-5417613849b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f57ff26-ff18-4a36-aa9a-5417613849b3">
											<gml:posList>35.66992040506289 139.74881123915154 6.39 35.67011088688841 139.74858558493642 6.39 35.67011088688841 139.74858558493642 70.6 35.66992040506289 139.74881123915154 70.6 35.66992040506289 139.74881123915154 6.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e72e2e81-fe41-4c17-a19a-de9887596fc7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e72e2e81-fe41-4c17-a19a-de9887596fc7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e72e2e81-fe41-4c17-a19a-de9887596fc7">
											<gml:posList>35.669858954629895 139.7487929562116 70.6 35.669858954629895 139.7487929562116 65.62 35.669758975992416 139.74866705791393 65.62 35.669758975992416 139.74866705791393 70.6 35.669858954629895 139.7487929562116 70.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a4f38832-7d03-4eec-af03-d86f09d9ff39">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4f38832-7d03-4eec-af03-d86f09d9ff39">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4f38832-7d03-4eec-af03-d86f09d9ff39">
											<gml:posList>35.66992089820814 139.74875617333979 70.6 35.66992089820814 139.74875617333979 65.62 35.669906220104686 139.7487380067862 65.62 35.669906220104686 139.7487380067862 70.6 35.66992089820814 139.74875617333979 70.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0cdf027a-28d8-463a-9825-53bbb08a6dc2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0cdf027a-28d8-463a-9825-53bbb08a6dc2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0cdf027a-28d8-463a-9825-53bbb08a6dc2">
											<gml:posList>35.66971370842521 139.74866619992883 6.39 35.66985805581911 139.7488479782233 6.39 35.66985805581911 139.7488479782233 70.6 35.66971370842521 139.74866619992883 70.6 35.66971370842521 139.74866619992883 6.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-97db5fe6-7346-4832-992b-53bd61ffa3c8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-97db5fe6-7346-4832-992b-53bd61ffa3c8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-97db5fe6-7346-4832-992b-53bd61ffa3c8">
											<gml:posList>35.669906220104686 139.7487380067862 70.6 35.669906220104686 139.7487380067862 65.62 35.669858954629895 139.7487929562116 65.62 35.669858954629895 139.7487929562116 70.6 35.669906220104686 139.7487380067862 70.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3a1224b8-0450-465e-b7cd-b94500f56fbe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a1224b8-0450-465e-b7cd-b94500f56fbe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a1224b8-0450-465e-b7cd-b94500f56fbe">
											<gml:posList>35.669905519465914 139.74879280769807 6.39 35.66992040506289 139.74881123915154 6.39 35.66992040506289 139.74881123915154 70.6 35.669905519465914 139.74879280769807 70.6 35.669905519465914 139.74879280769807 6.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-10261de1-d610-4505-b91b-80a68e73d071">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-10261de1-d610-4505-b91b-80a68e73d071">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-10261de1-d610-4505-b91b-80a68e73d071">
											<gml:posList>35.66985805581911 139.7488479782233 6.39 35.669905519465914 139.74879280769807 6.39 35.669905519465914 139.74879280769807 70.6 35.66985805581911 139.7488479782233 70.6 35.66985805581911 139.7488479782233 6.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7676</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">1153.68905</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>