<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_4a4bdafe-71ec-4c4d-add9-10cd4d625847">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="地区計画">
				<gen:value>赤坂二・六丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:measuredHeight uom="m">5.5</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67195751214109 139.73753679143041 0 35.67184819919896 139.73758910552905 0 35.671857985480514 139.73761981405505 0 35.67196729843585 139.73756749999183 0 35.67195751214109 139.73753679143041 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67195751214109 139.73753679143041 8.8 35.67196729843585 139.73756749999183 8.8 35.671857985480514 139.73761981405505 8.8 35.67184819919896 139.73758910552905 8.8 35.67195751214109 139.73753679143041 8.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67195751214109 139.73753679143041 8.8 35.67184819919896 139.73758910552905 8.8 35.67184819919896 139.73758910552905 14.34 35.67195751214109 139.73753679143041 14.34 35.67195751214109 139.73753679143041 8.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67184819919896 139.73758910552905 8.8 35.671857985480514 139.73761981405505 8.8 35.671857985480514 139.73761981405505 14.34 35.67184819919896 139.73758910552905 14.34 35.67184819919896 139.73758910552905 8.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671857985480514 139.73761981405505 8.8 35.67196729843585 139.73756749999183 8.8 35.67196729843585 139.73756749999183 14.34 35.671857985480514 139.73761981405505 14.34 35.671857985480514 139.73761981405505 8.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67196729843585 139.73756749999183 8.8 35.67195751214109 139.73753679143041 8.8 35.67195751214109 139.73753679143041 14.34 35.67196729843585 139.73756749999183 14.34 35.67196729843585 139.73756749999183 8.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67195751214109 139.73753679143041 14.34 35.67184819919896 139.73758910552905 14.34 35.671857985480514 139.73761981405505 14.34 35.67196729843585 139.73756749999183 14.34 35.67195751214109 139.73753679143041 14.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-43426e69-ea7b-4fb6-82ac-ac95397ea1aa"/>
							<gml:surfaceMember xlink:href="#poly-52499654-1132-4d7d-b787-22be6159877d"/>
							<gml:surfaceMember xlink:href="#poly-8ba03ed9-7677-4a4c-80ab-ae6f3c35e2f0"/>
							<gml:surfaceMember xlink:href="#poly-bea119a0-0f1a-4257-a0f8-7adf03d950bb"/>
							<gml:surfaceMember xlink:href="#poly-52ba52a8-dee9-498d-b9a8-2997a46cdef5"/>
							<gml:surfaceMember xlink:href="#poly-819b4f0a-acbd-47b6-82b3-91ade8d45ea4"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-43426e69-ea7b-4fb6-82ac-ac95397ea1aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-43426e69-ea7b-4fb6-82ac-ac95397ea1aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-43426e69-ea7b-4fb6-82ac-ac95397ea1aa">
											<gml:posList>35.671957512141084 139.73753679143044 8.8 35.67196729843586 139.73756749999183 8.8 35.67185798548049 139.73761981405505 8.8 35.67184819919894 139.73758910552905 8.8 35.671957512141084 139.73753679143044 8.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-52499654-1132-4d7d-b787-22be6159877d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-52499654-1132-4d7d-b787-22be6159877d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-52499654-1132-4d7d-b787-22be6159877d">
											<gml:posList>35.67184819919894 139.73758910552905 14.023 35.67185798548049 139.73761981405505 14.023 35.67196729843586 139.73756749999183 14.023 35.671957512141084 139.73753679143044 14.023 35.67184819919894 139.73758910552905 14.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8ba03ed9-7677-4a4c-80ab-ae6f3c35e2f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ba03ed9-7677-4a4c-80ab-ae6f3c35e2f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ba03ed9-7677-4a4c-80ab-ae6f3c35e2f0">
											<gml:posList>35.67196729843586 139.73756749999183 14.023 35.67196729843586 139.73756749999183 8.8 35.671957512141084 139.73753679143044 8.8 35.671957512141084 139.73753679143044 14.023 35.67196729843586 139.73756749999183 14.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bea119a0-0f1a-4257-a0f8-7adf03d950bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bea119a0-0f1a-4257-a0f8-7adf03d950bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bea119a0-0f1a-4257-a0f8-7adf03d950bb">
											<gml:posList>35.671957512141084 139.73753679143044 14.023 35.671957512141084 139.73753679143044 8.8 35.67184819919894 139.73758910552905 8.8 35.67184819919894 139.73758910552905 14.023 35.671957512141084 139.73753679143044 14.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-52ba52a8-dee9-498d-b9a8-2997a46cdef5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-52ba52a8-dee9-498d-b9a8-2997a46cdef5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-52ba52a8-dee9-498d-b9a8-2997a46cdef5">
											<gml:posList>35.67185798548049 139.73761981405505 14.023 35.67185798548049 139.73761981405505 8.8 35.67196729843586 139.73756749999183 8.8 35.67196729843586 139.73756749999183 14.023 35.67185798548049 139.73761981405505 14.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-819b4f0a-acbd-47b6-82b3-91ade8d45ea4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-819b4f0a-acbd-47b6-82b3-91ade8d45ea4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-819b4f0a-acbd-47b6-82b3-91ade8d45ea4">
											<gml:posList>35.67184819919894 139.73758910552905 14.023 35.67184819919894 139.73758910552905 8.8 35.67185798548049 139.73761981405505 8.8 35.67185798548049 139.73761981405505 14.023 35.67184819919894 139.73758910552905 14.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-11486</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">215</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>