<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_4b425d8b-b73d-47d5-8290-1f9f3fff24e1">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="説明注記">
				<gen:value>通気孔</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">403</bldg:usage>
			<bldg:measuredHeight uom="m">20</bldg:measuredHeight>
			<bldg:storeysAboveGround>1</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66738703495287 139.74087901455354 0 35.66737119105901 139.74090543239086 0 35.66740258070085 139.74093389450033 0 35.66742130551746 139.74090294453833 0 35.66744881654458 139.74092787646026 0 35.66747771398164 139.7408801250456 0 35.66740952252643 139.7408181259907 0 35.66743409876494 139.74077744889445 0 35.667355624385706 139.7407060728713 0 35.66732681698447 139.7407536032551 0 35.66734972790053 139.74077445344452 0 35.667334874096625 139.74079899235488 0 35.667369150277786 139.74083021254094 0 35.667356457042445 139.7408512142854 0 35.66738703495287 139.74087901455354 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66738703495287 139.74087901455354 11.3 35.667356457042445 139.7408512142854 11.3 35.667369150277786 139.74083021254094 11.3 35.667334874096625 139.74079899235488 11.3 35.66734972790053 139.74077445344452 11.3 35.66732681698447 139.7407536032551 11.3 35.667355624385706 139.7407060728713 11.3 35.66743409876494 139.74077744889445 11.3 35.66740952252643 139.7408181259907 11.3 35.66747771398164 139.7408801250456 11.3 35.66744881654458 139.74092787646026 11.3 35.66742130551746 139.74090294453833 11.3 35.66740258070085 139.74093389450033 11.3 35.66737119105901 139.74090543239086 11.3 35.66738703495287 139.74087901455354 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66738703495287 139.74087901455354 11.3 35.66737119105901 139.74090543239086 11.3 35.66737119105901 139.74090543239086 31.28 35.66738703495287 139.74087901455354 31.28 35.66738703495287 139.74087901455354 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66737119105901 139.74090543239086 11.3 35.66740258070085 139.74093389450033 11.3 35.66740258070085 139.74093389450033 31.28 35.66737119105901 139.74090543239086 31.28 35.66737119105901 139.74090543239086 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66740258070085 139.74093389450033 11.3 35.66742130551746 139.74090294453833 11.3 35.66742130551746 139.74090294453833 31.28 35.66740258070085 139.74093389450033 31.28 35.66740258070085 139.74093389450033 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66742130551746 139.74090294453833 11.3 35.66744881654458 139.74092787646026 11.3 35.66744881654458 139.74092787646026 31.28 35.66742130551746 139.74090294453833 31.28 35.66742130551746 139.74090294453833 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66744881654458 139.74092787646026 11.3 35.66747771398164 139.7408801250456 11.3 35.66747771398164 139.7408801250456 31.28 35.66744881654458 139.74092787646026 31.28 35.66744881654458 139.74092787646026 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66747771398164 139.7408801250456 11.3 35.66740952252643 139.7408181259907 11.3 35.66740952252643 139.7408181259907 31.28 35.66747771398164 139.7408801250456 31.28 35.66747771398164 139.7408801250456 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66740952252643 139.7408181259907 11.3 35.66743409876494 139.74077744889445 11.3 35.66743409876494 139.74077744889445 31.28 35.66740952252643 139.7408181259907 31.28 35.66740952252643 139.7408181259907 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66743409876494 139.74077744889445 11.3 35.667355624385706 139.7407060728713 11.3 35.667355624385706 139.7407060728713 31.28 35.66743409876494 139.74077744889445 31.28 35.66743409876494 139.74077744889445 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667355624385706 139.7407060728713 11.3 35.66732681698447 139.7407536032551 11.3 35.66732681698447 139.7407536032551 31.28 35.667355624385706 139.7407060728713 31.28 35.667355624385706 139.7407060728713 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66732681698447 139.7407536032551 11.3 35.66734972790053 139.74077445344452 11.3 35.66734972790053 139.74077445344452 31.28 35.66732681698447 139.7407536032551 31.28 35.66732681698447 139.7407536032551 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66734972790053 139.74077445344452 11.3 35.667334874096625 139.74079899235488 11.3 35.667334874096625 139.74079899235488 31.28 35.66734972790053 139.74077445344452 31.28 35.66734972790053 139.74077445344452 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667334874096625 139.74079899235488 11.3 35.667369150277786 139.74083021254094 11.3 35.667369150277786 139.74083021254094 31.28 35.667334874096625 139.74079899235488 31.28 35.667334874096625 139.74079899235488 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667369150277786 139.74083021254094 11.3 35.667356457042445 139.7408512142854 11.3 35.667356457042445 139.7408512142854 31.28 35.667369150277786 139.74083021254094 31.28 35.667369150277786 139.74083021254094 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667356457042445 139.7408512142854 11.3 35.66738703495287 139.74087901455354 11.3 35.66738703495287 139.74087901455354 31.28 35.667356457042445 139.7408512142854 31.28 35.667356457042445 139.7408512142854 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66738703495287 139.74087901455354 31.28 35.66737119105901 139.74090543239086 31.28 35.66740258070085 139.74093389450033 31.28 35.66742130551746 139.74090294453833 31.28 35.66744881654458 139.74092787646026 31.28 35.66747771398164 139.7408801250456 31.28 35.66740952252643 139.7408181259907 31.28 35.66743409876494 139.74077744889445 31.28 35.667355624385706 139.7407060728713 31.28 35.66732681698447 139.7407536032551 31.28 35.66734972790053 139.74077445344452 31.28 35.667334874096625 139.74079899235488 31.28 35.667369150277786 139.74083021254094 31.28 35.667356457042445 139.7408512142854 31.28 35.66738703495287 139.74087901455354 31.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-054fcd16-f2df-4a3f-b83e-b2730876747e"/>
							<gml:surfaceMember xlink:href="#poly-a659fb80-a15a-4446-8c08-7355baf115a6"/>
							<gml:surfaceMember xlink:href="#poly-6e4d1aa6-27c9-4bdf-bfa9-4e8e4d3052e7"/>
							<gml:surfaceMember xlink:href="#poly-fa73c4a9-021f-4c1f-a9ce-c76d858ff0ab"/>
							<gml:surfaceMember xlink:href="#poly-694b6aa0-0b6c-4d97-a3ef-78474cd8304a"/>
							<gml:surfaceMember xlink:href="#poly-afdb633e-f14c-4547-811a-9bc2b6a15801"/>
							<gml:surfaceMember xlink:href="#poly-a35e7f30-7f85-4f36-8726-895e1cd5da39"/>
							<gml:surfaceMember xlink:href="#poly-0d9698c1-04b8-4845-8ab3-bff2dd588c55"/>
							<gml:surfaceMember xlink:href="#poly-a3fe5cba-4ded-4348-8dba-8731640cafd1"/>
							<gml:surfaceMember xlink:href="#poly-d7afbbcb-7e14-4b55-bd1f-3410162fa836"/>
							<gml:surfaceMember xlink:href="#poly-90d673ce-2b48-4b02-9ed3-62ff2c6cb7d8"/>
							<gml:surfaceMember xlink:href="#poly-8cdbea68-78d6-477f-af39-2324f9afd66d"/>
							<gml:surfaceMember xlink:href="#poly-2281688e-d84c-4928-9e2a-77b6bc327dcb"/>
							<gml:surfaceMember xlink:href="#poly-f8fc42a6-ce61-47bb-88fd-fcb68f8b448e"/>
							<gml:surfaceMember xlink:href="#poly-0ce4cb8f-130f-490d-8184-497fe600ab07"/>
							<gml:surfaceMember xlink:href="#poly-462089c1-c9a3-4b4e-a07f-85910a3278fa"/>
							<gml:surfaceMember xlink:href="#poly-37a03346-3143-4afb-bee2-8cf894cfc0fe"/>
							<gml:surfaceMember xlink:href="#poly-4c04267d-a653-47f1-ba7b-a084ebc6fb90"/>
							<gml:surfaceMember xlink:href="#poly-f9b23efe-c11b-4b2c-98c8-503a99546259"/>
							<gml:surfaceMember xlink:href="#poly-f574c678-86eb-458b-b6da-35ad6ff1cf8c"/>
							<gml:surfaceMember xlink:href="#poly-cc8647c6-80a1-42d9-9406-10b5807650ad"/>
							<gml:surfaceMember xlink:href="#poly-74952d50-b163-40e1-9623-addeb746c073"/>
							<gml:surfaceMember xlink:href="#poly-8da7416a-7bc5-4743-a8ec-009e11b5dc92"/>
							<gml:surfaceMember xlink:href="#poly-394c44b6-5f5e-46d2-ad35-3885e3662675"/>
							<gml:surfaceMember xlink:href="#poly-7017c85d-6087-42cf-9936-f90742fc2076"/>
							<gml:surfaceMember xlink:href="#poly-b868aa16-e46a-43f4-b3e5-deca6121cd59"/>
							<gml:surfaceMember xlink:href="#poly-b199e5e5-b31c-4617-b892-cfe40998d4d3"/>
							<gml:surfaceMember xlink:href="#poly-6bb42e7e-20fd-4a1a-bfd6-24a781f60253"/>
							<gml:surfaceMember xlink:href="#poly-b2aaedb7-1f2e-44e0-9a4b-56edf06c2415"/>
							<gml:surfaceMember xlink:href="#poly-f628bad0-4af0-46d5-b7cf-5d0f86b16349"/>
							<gml:surfaceMember xlink:href="#poly-b1b5b700-1766-4f4f-9ec8-89c225301072"/>
							<gml:surfaceMember xlink:href="#poly-bcc1661f-9d5a-4a5a-9954-f515a6556cb3"/>
							<gml:surfaceMember xlink:href="#poly-f9e6bac7-b4a1-4b13-b168-4a9e289b8795"/>
							<gml:surfaceMember xlink:href="#poly-aa874384-d914-4317-83f5-16c599d8163c"/>
							<gml:surfaceMember xlink:href="#poly-bf470b7b-193e-461c-85bd-e9693c5d7b7c"/>
							<gml:surfaceMember xlink:href="#poly-3c3a3293-ba20-4341-8f5f-3264a5753eeb"/>
							<gml:surfaceMember xlink:href="#poly-0df891b3-a226-4b7c-9c54-85ba642a2826"/>
							<gml:surfaceMember xlink:href="#poly-1e72091b-df50-4811-9584-22f967bd63f4"/>
							<gml:surfaceMember xlink:href="#poly-a9177ed4-2c9a-4c52-8cc1-24604924327d"/>
							<gml:surfaceMember xlink:href="#poly-783438ff-1172-408f-afef-d3ce695dd98c"/>
							<gml:surfaceMember xlink:href="#poly-ba576533-ba57-413f-a677-c2d493deedc1"/>
							<gml:surfaceMember xlink:href="#poly-c8a7a4c6-e1ec-4af5-b063-1d6a6eff299e"/>
							<gml:surfaceMember xlink:href="#poly-4cc7467b-0247-4db9-b1f5-68547289d3fd"/>
							<gml:surfaceMember xlink:href="#poly-c5ebea9e-c1ea-444c-a9dc-9dcffdd14dc0"/>
							<gml:surfaceMember xlink:href="#poly-2d8d32fa-4a9f-4922-95d6-239a105dab6c"/>
							<gml:surfaceMember xlink:href="#poly-6677564d-929f-4b75-a86d-cf24d1710ff7"/>
							<gml:surfaceMember xlink:href="#poly-1494937d-8e7a-4af8-8a02-dded87d60793"/>
							<gml:surfaceMember xlink:href="#poly-1e16fdec-7246-4555-8aae-e7cb41c45b66"/>
							<gml:surfaceMember xlink:href="#poly-37af24d2-5d09-4f17-8590-0be9dfe4bb86"/>
							<gml:surfaceMember xlink:href="#poly-44a843b3-2613-4867-9bac-3909f9121503"/>
							<gml:surfaceMember xlink:href="#poly-6e177696-d69f-474a-aae9-b799e3525e2f"/>
							<gml:surfaceMember xlink:href="#poly-7e0c9484-7ea6-4296-b21e-a03cc0eaf2c8"/>
							<gml:surfaceMember xlink:href="#poly-7cc19782-3fba-40c4-817b-595e4b203015"/>
							<gml:surfaceMember xlink:href="#poly-63b67013-cef5-4ce5-8831-ac8fd4158fd0"/>
							<gml:surfaceMember xlink:href="#poly-540a6601-9704-41b6-95a9-1fb90f77ec7e"/>
							<gml:surfaceMember xlink:href="#poly-a4189bea-7660-4c18-bea0-065244497457"/>
							<gml:surfaceMember xlink:href="#poly-14d0d7f0-c8ab-4a5d-9117-438f9ebe8f6c"/>
							<gml:surfaceMember xlink:href="#poly-1426ad3a-d20e-4eb3-9781-7b171d05b280"/>
							<gml:surfaceMember xlink:href="#poly-cb83f448-8643-4af0-9a40-67e8a028322a"/>
							<gml:surfaceMember xlink:href="#poly-68652c8d-9f99-4c8f-9bda-09efed0d31bb"/>
							<gml:surfaceMember xlink:href="#poly-79568097-8aaa-4631-bc0d-efe986bf6244"/>
							<gml:surfaceMember xlink:href="#poly-9dc5c0f5-9e75-474f-8438-6935164568dd"/>
							<gml:surfaceMember xlink:href="#poly-8eb6f2dc-010c-4e7d-9c09-e9d1d72a9bf4"/>
							<gml:surfaceMember xlink:href="#poly-baa97cc2-eab2-4c43-b68a-d7b562bf6f74"/>
							<gml:surfaceMember xlink:href="#poly-c890de34-c93e-4d8b-8126-2955ab76628c"/>
							<gml:surfaceMember xlink:href="#poly-8694ca14-9949-498a-b38a-c9992be2a3dc"/>
							<gml:surfaceMember xlink:href="#poly-a9c3de3e-1804-4fc3-8da7-863fd28c78da"/>
							<gml:surfaceMember xlink:href="#poly-d62ff30f-eb57-4332-a585-db7ea8b30680"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-054fcd16-f2df-4a3f-b83e-b2730876747e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-054fcd16-f2df-4a3f-b83e-b2730876747e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-054fcd16-f2df-4a3f-b83e-b2730876747e">
											<gml:posList>35.66742130551743 139.74090294453833 11.3 35.667402580700845 139.74093389450033 11.3 35.66737119105899 139.74090543239086 11.3 35.667387034952846 139.7408790145535 11.3 35.66735645704245 139.7408512142854 11.3 35.66736915027779 139.74083021254094 11.3 35.66733487409658 139.74079899235485 11.3 35.66734972790054 139.74077445344452 11.3 35.66732681698449 139.74075360325506 11.3 35.66735562438569 139.7407060728713 11.3 35.66743409876496 139.74077744889445 11.3 35.66740952252643 139.7408181259907 11.3 35.66747771398161 139.7408801250456 11.3 35.667448816544564 139.74092787646026 11.3 35.66742130551743 139.74090294453833 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a659fb80-a15a-4446-8c08-7355baf115a6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a659fb80-a15a-4446-8c08-7355baf115a6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a659fb80-a15a-4446-8c08-7355baf115a6">
											<gml:posList>35.66735556346471 139.74070890067742 29.9 35.66737740099035 139.74072875797503 29.9 35.667378526279144 139.74072690097336 29.9 35.66735562438569 139.7407060728713 29.9 35.66735556346471 139.74070890067742 29.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6e4d1aa6-27c9-4bdf-bfa9-4e8e4d3052e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e4d1aa6-27c9-4bdf-bfa9-4e8e4d3052e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e4d1aa6-27c9-4bdf-bfa9-4e8e4d3052e7">
											<gml:posList>35.66732681698449 139.74075360325506 29.9 35.66732852053649 139.740753546059 29.9 35.66735556346471 139.74070890067742 29.9 35.66735562438569 139.7407060728713 29.9 35.66732681698449 139.74075360325506 29.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fa73c4a9-021f-4c1f-a9ce-c76d858ff0ab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa73c4a9-021f-4c1f-a9ce-c76d858ff0ab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa73c4a9-021f-4c1f-a9ce-c76d858ff0ab">
											<gml:posList>35.66735556346471 139.74070890067742 29.234 35.66732852053649 139.740753546059 29.234 35.66735036706859 139.7407734033517 29.234 35.66737740099035 139.74072875797503 29.234 35.66735556346471 139.74070890067742 29.234</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-694b6aa0-0b6c-4d97-a3ef-78474cd8304a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-694b6aa0-0b6c-4d97-a3ef-78474cd8304a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-694b6aa0-0b6c-4d97-a3ef-78474cd8304a">
											<gml:posList>35.667378526279144 139.74072690097336 35.5 35.66737887096691 139.74072971726602 35.5 35.66741054033894 139.7407585214078 35.5 35.66741282950297 139.74075809902263 35.5 35.667378526279144 139.74072690097336 35.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-afdb633e-f14c-4547-811a-9bc2b6a15801">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-afdb633e-f14c-4547-811a-9bc2b6a15801">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-afdb633e-f14c-4547-811a-9bc2b6a15801">
											<gml:posList>35.66734972790054 139.74077445344452 35.5 35.66735202609535 139.74077405314142 35.5 35.66737887096691 139.74072971726602 35.5 35.667378526279144 139.74072690097336 35.5 35.66734972790054 139.74077445344452 35.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a35e7f30-7f85-4f36-8726-895e1cd5da39">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a35e7f30-7f85-4f36-8726-895e1cd5da39">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a35e7f30-7f85-4f36-8726-895e1cd5da39">
											<gml:posList>35.66734972790054 139.74077445344452 29.9 35.66735036706859 139.7407734033517 29.9 35.66732852053649 139.740753546059 29.9 35.66732681698449 139.74075360325506 29.9 35.66734972790054 139.74077445344452 29.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0d9698c1-04b8-4845-8ab3-bff2dd588c55">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d9698c1-04b8-4845-8ab3-bff2dd588c55">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d9698c1-04b8-4845-8ab3-bff2dd588c55">
											<gml:posList>35.66738820817679 139.74079874302848 35.5 35.66741282950297 139.74075809902263 35.5 35.66741054033894 139.7407585214078 35.5 35.667385919012595 139.74079916541234 35.5 35.66738820817679 139.74079874302848 35.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a3fe5cba-4ded-4348-8dba-8731640cafd1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a3fe5cba-4ded-4348-8dba-8731640cafd1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a3fe5cba-4ded-4348-8dba-8731640cafd1">
											<gml:posList>35.66743409876496 139.74077744889445 30.6 35.66741282950297 139.74075809902263 30.6 35.667411470153986 139.74076034289965 30.6 35.66743095344961 139.74077807109276 30.6 35.66740770949428 139.740816471205 30.6 35.66740952252643 139.7408181259907 30.6 35.66743409876496 139.74077744889445 30.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d7afbbcb-7e14-4b55-bd1f-3410162fa836">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7afbbcb-7e14-4b55-bd1f-3410162fa836">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7afbbcb-7e14-4b55-bd1f-3410162fa836">
											<gml:posList>35.66738820817679 139.74079874302848 29.869 35.66740770949428 139.740816471205 29.869 35.66743095344961 139.74077807109276 29.869 35.667411470153986 139.74076034289965 29.869 35.66738820817679 139.74079874302848 29.869</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-90d673ce-2b48-4b02-9ed3-62ff2c6cb7d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-90d673ce-2b48-4b02-9ed3-62ff2c6cb7d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-90d673ce-2b48-4b02-9ed3-62ff2c6cb7d8">
											<gml:posList>35.66738403111223 139.74080565150297 35.5 35.66738632929865 139.74080524015474 35.5 35.66735202609535 139.74077405314142 35.5 35.66734972790054 139.74077445344452 35.5 35.66738403111223 139.74080565150297 35.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8cdbea68-78d6-477f-af39-2324f9afd66d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8cdbea68-78d6-477f-af39-2324f9afd66d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8cdbea68-78d6-477f-af39-2324f9afd66d">
											<gml:posList>35.66733487409658 139.74079899235485 30.6 35.66736915027779 139.74083021254094 30.6 35.66736992448253 139.74082894137567 30.6 35.667337244876634 139.7407992105358 30.6 35.66735134248694 139.74077592067783 30.6 35.66734972790054 139.74077445344452 30.6 35.66733487409658 139.74079899235485 30.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2281688e-d84c-4928-9e2a-77b6bc327dcb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2281688e-d84c-4928-9e2a-77b6bc327dcb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2281688e-d84c-4928-9e2a-77b6bc327dcb">
											<gml:posList>35.667385919012595 139.74079916541234 34.452 35.66741054033894 139.7407585214078 34.452 35.66737887096691 139.74072971726602 34.452 35.66735202609535 139.74077405314142 34.452 35.66738632929865 139.74080524015474 34.452 35.66735875522903 139.7408508029386 34.452 35.66738532824587 139.7408749626955 34.452 35.66741513490317 139.7408257190609 34.452 35.667385919012595 139.74079916541234 34.452</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f8fc42a6-ce61-47bb-88fd-fcb68f8b448e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f8fc42a6-ce61-47bb-88fd-fcb68f8b448e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f8fc42a6-ce61-47bb-88fd-fcb68f8b448e">
											<gml:posList>35.66738403111223 139.74080565150297 29.736 35.66735134248694 139.74077592067783 29.736 35.667337244876634 139.7407992105358 29.736 35.66736992448253 139.74082894137567 29.736 35.66738403111223 139.74080565150297 29.736</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0ce4cb8f-130f-490d-8184-497fe600ab07">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ce4cb8f-130f-490d-8184-497fe600ab07">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ce4cb8f-130f-490d-8184-497fe600ab07">
											<gml:posList>35.66738820817679 139.74079874302848 35.5 35.667385919012595 139.74079916541234 35.5 35.66741513490317 139.7408257190609 35.5 35.66741742407591 139.74082530772347 35.5 35.66738820817679 139.74079874302848 35.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-462089c1-c9a3-4b4e-a07f-85910a3278fa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-462089c1-c9a3-4b4e-a07f-85910a3278fa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-462089c1-c9a3-4b4e-a07f-85910a3278fa">
											<gml:posList>35.66738403111223 139.74080565150297 35.5 35.66735645704245 139.7408512142854 35.5 35.66735875522903 139.7408508029386 35.5 35.66738632929865 139.74080524015474 35.5 35.66738403111223 139.74080565150297 35.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-37a03346-3143-4afb-bee2-8cf894cfc0fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37a03346-3143-4afb-bee2-8cf894cfc0fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37a03346-3143-4afb-bee2-8cf894cfc0fe">
											<gml:posList>35.66741742407591 139.74082530772347 35.5 35.66741513490317 139.7408257190609 35.5 35.66738532824587 139.7408749626955 35.5 35.667385663907964 139.74087776795363 35.5 35.66741742407591 139.74082530772347 35.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4c04267d-a653-47f1-ba7b-a084ebc6fb90">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c04267d-a653-47f1-ba7b-a084ebc6fb90">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c04267d-a653-47f1-ba7b-a084ebc6fb90">
											<gml:posList>35.667385663907964 139.74087776795363 35.5 35.66738532824587 139.7408749626955 35.5 35.66735875522903 139.7408508029386 35.5 35.66735645704245 139.7408512142854 35.5 35.667385663907964 139.74087776795363 35.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f9b23efe-c11b-4b2c-98c8-503a99546259">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9b23efe-c11b-4b2c-98c8-503a99546259">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9b23efe-c11b-4b2c-98c8-503a99546259">
											<gml:posList>35.66738995563795 139.7408793204697 33.219 35.66737417456882 139.7409053847685 33.219 35.66740220882411 139.740930879412 33.219 35.66744795861998 139.7408553172239 33.219 35.667417074025536 139.7408272411513 33.219 35.66741655085599 139.74082675573737 33.219 35.66738658214624 139.74087625361383 33.219 35.66738995563795 139.7408793204697 33.219</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f574c678-86eb-458b-b6da-35ad6ff1cf8c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f574c678-86eb-458b-b6da-35ad6ff1cf8c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f574c678-86eb-458b-b6da-35ad6ff1cf8c">
											<gml:posList>35.66741655085599 139.74082675573737 33.8 35.667417074025536 139.7408272411513 33.8 35.66744795861998 139.7408553172239 33.8 35.66740220882411 139.740930879412 33.8 35.66737417456882 139.7409053847685 33.8 35.66738995563795 139.7408793204697 33.8 35.66738658214624 139.74087625361383 33.8 35.667385663907964 139.74087776795363 33.8 35.667387034952846 139.7408790145535 33.8 35.66737119105899 139.74090543239086 33.8 35.667402580700845 139.74093389450033 33.8 35.667450184840945 139.7408550937393 33.8 35.66741742407591 139.74082530772347 33.8 35.66741655085599 139.74082675573737 33.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cc8647c6-80a1-42d9-9406-10b5807650ad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc8647c6-80a1-42d9-9406-10b5807650ad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc8647c6-80a1-42d9-9406-10b5807650ad">
											<gml:posList>35.667448732818734 139.74092448547904 30.792 35.667475145527334 139.7408807244834 30.792 35.6674490145494 139.74085703915958 30.792 35.667422601840805 139.7409007891029 30.792 35.667448732818734 139.74092448547904 30.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-74952d50-b163-40e1-9623-addeb746c073">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74952d50-b163-40e1-9623-addeb746c073">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74952d50-b163-40e1-9623-addeb746c073">
											<gml:posList>35.66747771398161 139.7408801250456 31.4 35.667450184840945 139.7408550937393 31.4 35.6674490145494 139.74085703915958 31.4 35.667475145527334 139.7408807244834 31.4 35.667448732818734 139.74092448547904 31.4 35.667422601840805 139.7409007891029 31.4 35.66742130551743 139.74090294453833 31.4 35.667448816544564 139.74092787646026 31.4 35.66747771398161 139.7408801250456 31.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8da7416a-7bc5-4743-a8ec-009e11b5dc92">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8da7416a-7bc5-4743-a8ec-009e11b5dc92">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8da7416a-7bc5-4743-a8ec-009e11b5dc92">
											<gml:posList>35.66738632929865 139.74080524015474 35.5 35.66738632929865 139.74080524015474 34.452 35.66735202609535 139.74077405314142 34.452 35.66735202609535 139.74077405314142 35.5 35.66738632929865 139.74080524015474 35.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-394c44b6-5f5e-46d2-ad35-3885e3662675">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-394c44b6-5f5e-46d2-ad35-3885e3662675">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-394c44b6-5f5e-46d2-ad35-3885e3662675">
											<gml:posList>35.66735875522903 139.7408508029386 35.5 35.66735875522903 139.7408508029386 34.452 35.66738632929865 139.74080524015474 34.452 35.66738632929865 139.74080524015474 35.5 35.66735875522903 139.7408508029386 35.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7017c85d-6087-42cf-9936-f90742fc2076">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7017c85d-6087-42cf-9936-f90742fc2076">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7017c85d-6087-42cf-9936-f90742fc2076">
											<gml:posList>35.66738995563795 139.7408793204697 33.8 35.66738995563795 139.7408793204697 33.219 35.66738658214624 139.74087625361383 33.219 35.66738658214624 139.74087625361383 33.8 35.66738995563795 139.7408793204697 33.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b868aa16-e46a-43f4-b3e5-deca6121cd59">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b868aa16-e46a-43f4-b3e5-deca6121cd59">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b868aa16-e46a-43f4-b3e5-deca6121cd59">
											<gml:posList>35.66742130551743 139.74090294453833 11.3 35.66742130551743 139.74090294453833 31.4 35.667422601840805 139.7409007891029 31.4 35.66742130551743 139.74090294453833 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b199e5e5-b31c-4617-b892-cfe40998d4d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b199e5e5-b31c-4617-b892-cfe40998d4d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b199e5e5-b31c-4617-b892-cfe40998d4d3">
											<gml:posList>35.667402580700845 139.74093389450033 11.3 35.667422601840805 139.7409007891029 31.4 35.6674490145494 139.74085703915958 31.4 35.667402580700845 139.74093389450033 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6bb42e7e-20fd-4a1a-bfd6-24a781f60253">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6bb42e7e-20fd-4a1a-bfd6-24a781f60253">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6bb42e7e-20fd-4a1a-bfd6-24a781f60253">
											<gml:posList>35.667422601840805 139.7409007891029 31.4 35.667422601840805 139.7409007891029 30.792 35.6674490145494 139.74085703915958 30.792 35.667422601840805 139.7409007891029 31.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b2aaedb7-1f2e-44e0-9a4b-56edf06c2415">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b2aaedb7-1f2e-44e0-9a4b-56edf06c2415">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b2aaedb7-1f2e-44e0-9a4b-56edf06c2415">
											<gml:posList>35.667422601840805 139.7409007891029 31.4 35.6674490145494 139.74085703915958 30.792 35.6674490145494 139.74085703915958 31.4 35.667422601840805 139.7409007891029 31.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f628bad0-4af0-46d5-b7cf-5d0f86b16349">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f628bad0-4af0-46d5-b7cf-5d0f86b16349">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f628bad0-4af0-46d5-b7cf-5d0f86b16349">
											<gml:posList>35.66735556346471 139.74070890067742 29.9 35.66735556346471 139.74070890067742 29.234 35.66737740099035 139.74072875797503 29.234 35.66737740099035 139.74072875797503 29.9 35.66735556346471 139.74070890067742 29.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b1b5b700-1766-4f4f-9ec8-89c225301072">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b1b5b700-1766-4f4f-9ec8-89c225301072">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b1b5b700-1766-4f4f-9ec8-89c225301072">
											<gml:posList>35.66735562438569 139.7407060728713 11.3 35.66732681698449 139.74075360325506 11.3 35.66732681698449 139.74075360325506 29.9 35.66735562438569 139.7407060728713 29.9 35.66735562438569 139.7407060728713 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bcc1661f-9d5a-4a5a-9954-f515a6556cb3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bcc1661f-9d5a-4a5a-9954-f515a6556cb3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bcc1661f-9d5a-4a5a-9954-f515a6556cb3">
											<gml:posList>35.66732852053649 139.740753546059 29.9 35.66732852053649 139.740753546059 29.234 35.66735556346471 139.74070890067742 29.234 35.66735556346471 139.74070890067742 29.9 35.66732852053649 139.740753546059 29.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f9e6bac7-b4a1-4b13-b168-4a9e289b8795">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9e6bac7-b4a1-4b13-b168-4a9e289b8795">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9e6bac7-b4a1-4b13-b168-4a9e289b8795">
											<gml:posList>35.667378526279144 139.74072690097336 29.9 35.667378526279144 139.74072690097336 35.5 35.66741282950297 139.74075809902263 35.5 35.66741282950297 139.74075809902263 30.6 35.66743409876496 139.74077744889445 30.6 35.66743409876496 139.74077744889445 11.3 35.66735562438569 139.7407060728713 11.3 35.66735562438569 139.7407060728713 29.9 35.667378526279144 139.74072690097336 29.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aa874384-d914-4317-83f5-16c599d8163c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa874384-d914-4317-83f5-16c599d8163c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa874384-d914-4317-83f5-16c599d8163c">
											<gml:posList>35.66737887096691 139.74072971726602 35.5 35.66737887096691 139.74072971726602 34.452 35.66741054033894 139.7407585214078 34.452 35.66741054033894 139.7407585214078 35.5 35.66737887096691 139.74072971726602 35.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bf470b7b-193e-461c-85bd-e9693c5d7b7c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf470b7b-193e-461c-85bd-e9693c5d7b7c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf470b7b-193e-461c-85bd-e9693c5d7b7c">
											<gml:posList>35.66735202609535 139.74077405314142 35.5 35.66735202609535 139.74077405314142 34.452 35.66737887096691 139.74072971726602 34.452 35.66737887096691 139.74072971726602 35.5 35.66735202609535 139.74077405314142 35.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3c3a3293-ba20-4341-8f5f-3264a5753eeb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c3a3293-ba20-4341-8f5f-3264a5753eeb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c3a3293-ba20-4341-8f5f-3264a5753eeb">
											<gml:posList>35.66734972790054 139.74077445344452 30.6 35.66734972790054 139.74077445344452 35.5 35.667378526279144 139.74072690097336 35.5 35.667378526279144 139.74072690097336 29.9 35.66737740099035 139.74072875797503 29.9 35.66737740099035 139.74072875797503 29.234 35.66735036706859 139.7407734033517 29.234 35.66735036706859 139.7407734033517 29.9 35.66734972790054 139.74077445344452 29.9 35.66734972790054 139.74077445344452 11.3 35.66733487409658 139.74079899235485 11.3 35.66733487409658 139.74079899235485 30.6 35.66734972790054 139.74077445344452 30.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0df891b3-a226-4b7c-9c54-85ba642a2826">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0df891b3-a226-4b7c-9c54-85ba642a2826">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0df891b3-a226-4b7c-9c54-85ba642a2826">
											<gml:posList>35.66735036706859 139.7407734033517 29.9 35.66735036706859 139.7407734033517 29.234 35.66732852053649 139.740753546059 29.234 35.66732852053649 139.740753546059 29.9 35.66735036706859 139.7407734033517 29.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1e72091b-df50-4811-9584-22f967bd63f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e72091b-df50-4811-9584-22f967bd63f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e72091b-df50-4811-9584-22f967bd63f4">
											<gml:posList>35.66732681698449 139.74075360325506 11.3 35.66734972790054 139.74077445344452 11.3 35.66734972790054 139.74077445344452 29.9 35.66732681698449 139.74075360325506 29.9 35.66732681698449 139.74075360325506 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a9177ed4-2c9a-4c52-8cc1-24604924327d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9177ed4-2c9a-4c52-8cc1-24604924327d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9177ed4-2c9a-4c52-8cc1-24604924327d">
											<gml:posList>35.667411470153986 139.74076034289965 30.6 35.667411470153986 139.74076034289965 29.869 35.66743095344961 139.74077807109276 29.869 35.66743095344961 139.74077807109276 30.6 35.667411470153986 139.74076034289965 30.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-783438ff-1172-408f-afef-d3ce695dd98c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-783438ff-1172-408f-afef-d3ce695dd98c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-783438ff-1172-408f-afef-d3ce695dd98c">
											<gml:posList>35.66738820817679 139.74079874302848 29.869 35.667411470153986 139.74076034289965 29.869 35.667411470153986 139.74076034289965 30.6 35.66741282950297 139.74075809902263 30.6 35.66741282950297 139.74075809902263 35.5 35.66738820817679 139.74079874302848 35.5 35.66738820817679 139.74079874302848 29.869</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ba576533-ba57-413f-a677-c2d493deedc1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba576533-ba57-413f-a677-c2d493deedc1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba576533-ba57-413f-a677-c2d493deedc1">
											<gml:posList>35.66741054033894 139.7407585214078 35.5 35.66741054033894 139.7407585214078 34.452 35.667385919012595 139.74079916541234 34.452 35.667385919012595 139.74079916541234 35.5 35.66741054033894 139.7407585214078 35.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c8a7a4c6-e1ec-4af5-b063-1d6a6eff299e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8a7a4c6-e1ec-4af5-b063-1d6a6eff299e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8a7a4c6-e1ec-4af5-b063-1d6a6eff299e">
											<gml:posList>35.667337244876634 139.7407992105358 30.6 35.667337244876634 139.7407992105358 29.736 35.66735134248694 139.74077592067783 29.736 35.66735134248694 139.74077592067783 30.6 35.667337244876634 139.7407992105358 30.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4cc7467b-0247-4db9-b1f5-68547289d3fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4cc7467b-0247-4db9-b1f5-68547289d3fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4cc7467b-0247-4db9-b1f5-68547289d3fd">
											<gml:posList>35.66735134248694 139.74077592067783 30.6 35.66735134248694 139.74077592067783 29.736 35.66738403111223 139.74080565150297 29.736 35.66738403111223 139.74080565150297 35.5 35.66734972790054 139.74077445344452 35.5 35.66734972790054 139.74077445344452 30.6 35.66735134248694 139.74077592067783 30.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c5ebea9e-c1ea-444c-a9dc-9dcffdd14dc0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c5ebea9e-c1ea-444c-a9dc-9dcffdd14dc0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c5ebea9e-c1ea-444c-a9dc-9dcffdd14dc0">
											<gml:posList>35.66743095344961 139.74077807109276 30.6 35.66743095344961 139.74077807109276 29.869 35.66740770949428 139.740816471205 29.869 35.66740770949428 139.740816471205 30.6 35.66743095344961 139.74077807109276 30.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2d8d32fa-4a9f-4922-95d6-239a105dab6c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d8d32fa-4a9f-4922-95d6-239a105dab6c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d8d32fa-4a9f-4922-95d6-239a105dab6c">
											<gml:posList>35.66740952252643 139.7408181259907 11.3 35.66743409876496 139.74077744889445 11.3 35.66743409876496 139.74077744889445 30.6 35.66740952252643 139.7408181259907 30.6 35.66740952252643 139.7408181259907 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6677564d-929f-4b75-a86d-cf24d1710ff7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6677564d-929f-4b75-a86d-cf24d1710ff7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6677564d-929f-4b75-a86d-cf24d1710ff7">
											<gml:posList>35.667385919012595 139.74079916541234 35.5 35.667385919012595 139.74079916541234 34.452 35.66741513490317 139.7408257190609 34.452 35.66741513490317 139.7408257190609 35.5 35.667385919012595 139.74079916541234 35.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1494937d-8e7a-4af8-8a02-dded87d60793">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1494937d-8e7a-4af8-8a02-dded87d60793">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1494937d-8e7a-4af8-8a02-dded87d60793">
											<gml:posList>35.66736992448253 139.74082894137567 30.6 35.66736992448253 139.74082894137567 29.736 35.667337244876634 139.7407992105358 29.736 35.667337244876634 139.7407992105358 30.6 35.66736992448253 139.74082894137567 30.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1e16fdec-7246-4555-8aae-e7cb41c45b66">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e16fdec-7246-4555-8aae-e7cb41c45b66">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e16fdec-7246-4555-8aae-e7cb41c45b66">
											<gml:posList>35.66733487409658 139.74079899235485 11.3 35.66736915027779 139.74083021254094 11.3 35.66736915027779 139.74083021254094 30.6 35.66733487409658 139.74079899235485 30.6 35.66733487409658 139.74079899235485 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-37af24d2-5d09-4f17-8590-0be9dfe4bb86">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37af24d2-5d09-4f17-8590-0be9dfe4bb86">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37af24d2-5d09-4f17-8590-0be9dfe4bb86">
											<gml:posList>35.66741655085599 139.74082675573737 33.8 35.66741655085599 139.74082675573737 33.219 35.667417074025536 139.7408272411513 33.219 35.667417074025536 139.7408272411513 33.8 35.66741655085599 139.74082675573737 33.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-44a843b3-2613-4867-9bac-3909f9121503">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44a843b3-2613-4867-9bac-3909f9121503">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44a843b3-2613-4867-9bac-3909f9121503">
											<gml:posList>35.66736915027779 139.74083021254094 30.6 35.66736915027779 139.74083021254094 11.3 35.66735645704245 139.7408512142854 11.3 35.66735645704245 139.7408512142854 35.5 35.66738403111223 139.74080565150297 35.5 35.66738403111223 139.74080565150297 29.736 35.66736992448253 139.74082894137567 29.736 35.66736992448253 139.74082894137567 30.6 35.66736915027779 139.74083021254094 30.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6e177696-d69f-474a-aae9-b799e3525e2f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e177696-d69f-474a-aae9-b799e3525e2f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e177696-d69f-474a-aae9-b799e3525e2f">
											<gml:posList>35.66747771398161 139.7408801250456 11.3 35.66740952252643 139.7408181259907 11.3 35.66740952252643 139.7408181259907 30.6 35.66740770949428 139.740816471205 30.6 35.66740770949428 139.740816471205 29.869 35.66738820817679 139.74079874302848 29.869 35.66738820817679 139.74079874302848 35.5 35.66741742407591 139.74082530772347 35.5 35.66741742407591 139.74082530772347 33.8 35.667450184840945 139.7408550937393 33.8 35.667450184840945 139.7408550937393 31.4 35.66747771398161 139.7408801250456 31.4 35.66747771398161 139.7408801250456 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7e0c9484-7ea6-4296-b21e-a03cc0eaf2c8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e0c9484-7ea6-4296-b21e-a03cc0eaf2c8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e0c9484-7ea6-4296-b21e-a03cc0eaf2c8">
											<gml:posList>35.667417074025536 139.7408272411513 33.8 35.667417074025536 139.7408272411513 33.219 35.66744795861998 139.7408553172239 33.219 35.66744795861998 139.7408553172239 33.8 35.667417074025536 139.7408272411513 33.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7cc19782-3fba-40c4-817b-595e4b203015">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7cc19782-3fba-40c4-817b-595e4b203015">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7cc19782-3fba-40c4-817b-595e4b203015">
											<gml:posList>35.66741513490317 139.7408257190609 35.5 35.66741513490317 139.7408257190609 34.452 35.66738532824587 139.7408749626955 34.452 35.66738532824587 139.7408749626955 35.5 35.66741513490317 139.7408257190609 35.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-63b67013-cef5-4ce5-8831-ac8fd4158fd0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-63b67013-cef5-4ce5-8831-ac8fd4158fd0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-63b67013-cef5-4ce5-8831-ac8fd4158fd0">
											<gml:posList>35.66738658214624 139.74087625361383 33.8 35.66738658214624 139.74087625361383 33.219 35.66741655085599 139.74082675573737 33.219 35.66741655085599 139.74082675573737 33.8 35.66741742407591 139.74082530772347 33.8 35.66741742407591 139.74082530772347 35.5 35.667385663907964 139.74087776795363 35.5 35.667385663907964 139.74087776795363 33.8 35.66738658214624 139.74087625361383 33.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-540a6601-9704-41b6-95a9-1fb90f77ec7e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-540a6601-9704-41b6-95a9-1fb90f77ec7e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-540a6601-9704-41b6-95a9-1fb90f77ec7e">
											<gml:posList>35.66738532824587 139.7408749626955 35.5 35.66738532824587 139.7408749626955 34.452 35.66735875522903 139.7408508029386 34.452 35.66735875522903 139.7408508029386 35.5 35.66738532824587 139.7408749626955 35.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a4189bea-7660-4c18-bea0-065244497457">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4189bea-7660-4c18-bea0-065244497457">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4189bea-7660-4c18-bea0-065244497457">
											<gml:posList>35.66735645704245 139.7408512142854 35.5 35.66735645704245 139.7408512142854 11.3 35.667387034952846 139.7408790145535 11.3 35.667387034952846 139.7408790145535 33.8 35.667385663907964 139.74087776795363 33.8 35.667385663907964 139.74087776795363 35.5 35.66735645704245 139.7408512142854 35.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-14d0d7f0-c8ab-4a5d-9117-438f9ebe8f6c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-14d0d7f0-c8ab-4a5d-9117-438f9ebe8f6c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-14d0d7f0-c8ab-4a5d-9117-438f9ebe8f6c">
											<gml:posList>35.6674490145494 139.74085703915958 31.4 35.6674490145494 139.74085703915958 30.792 35.667475145527334 139.7408807244834 30.792 35.667475145527334 139.7408807244834 31.4 35.6674490145494 139.74085703915958 31.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1426ad3a-d20e-4eb3-9781-7b171d05b280">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1426ad3a-d20e-4eb3-9781-7b171d05b280">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1426ad3a-d20e-4eb3-9781-7b171d05b280">
											<gml:posList>35.667387034952846 139.7408790145535 11.3 35.66737119105899 139.74090543239086 11.3 35.66737119105899 139.74090543239086 33.8 35.667387034952846 139.7408790145535 33.8 35.667387034952846 139.7408790145535 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cb83f448-8643-4af0-9a40-67e8a028322a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb83f448-8643-4af0-9a40-67e8a028322a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb83f448-8643-4af0-9a40-67e8a028322a">
											<gml:posList>35.66737417456882 139.7409053847685 33.8 35.66737417456882 139.7409053847685 33.219 35.66738995563795 139.7408793204697 33.219 35.66738995563795 139.7408793204697 33.8 35.66737417456882 139.7409053847685 33.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-68652c8d-9f99-4c8f-9bda-09efed0d31bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-68652c8d-9f99-4c8f-9bda-09efed0d31bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-68652c8d-9f99-4c8f-9bda-09efed0d31bb">
											<gml:posList>35.66744795861998 139.7408553172239 33.8 35.66744795861998 139.7408553172239 33.219 35.66740220882411 139.740930879412 33.219 35.66740220882411 139.740930879412 33.8 35.66744795861998 139.7408553172239 33.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-79568097-8aaa-4631-bc0d-efe986bf6244">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79568097-8aaa-4631-bc0d-efe986bf6244">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79568097-8aaa-4631-bc0d-efe986bf6244">
											<gml:posList>35.667450184840945 139.7408550937393 33.8 35.667402580700845 139.74093389450033 33.8 35.667402580700845 139.74093389450033 11.3 35.6674490145494 139.74085703915958 31.4 35.667450184840945 139.7408550937393 31.4 35.667450184840945 139.7408550937393 33.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9dc5c0f5-9e75-474f-8438-6935164568dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9dc5c0f5-9e75-474f-8438-6935164568dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9dc5c0f5-9e75-474f-8438-6935164568dd">
											<gml:posList>35.667448816544564 139.74092787646026 11.3 35.66747771398161 139.7408801250456 11.3 35.66747771398161 139.7408801250456 31.4 35.667448816544564 139.74092787646026 31.4 35.667448816544564 139.74092787646026 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8eb6f2dc-010c-4e7d-9c09-e9d1d72a9bf4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8eb6f2dc-010c-4e7d-9c09-e9d1d72a9bf4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8eb6f2dc-010c-4e7d-9c09-e9d1d72a9bf4">
											<gml:posList>35.667448732818734 139.74092448547904 31.4 35.667448732818734 139.74092448547904 30.792 35.667422601840805 139.7409007891029 30.792 35.667422601840805 139.7409007891029 31.4 35.667448732818734 139.74092448547904 31.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-baa97cc2-eab2-4c43-b68a-d7b562bf6f74">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-baa97cc2-eab2-4c43-b68a-d7b562bf6f74">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-baa97cc2-eab2-4c43-b68a-d7b562bf6f74">
											<gml:posList>35.66742130551743 139.74090294453833 11.3 35.667448816544564 139.74092787646026 11.3 35.667448816544564 139.74092787646026 31.4 35.66742130551743 139.74090294453833 31.4 35.66742130551743 139.74090294453833 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c890de34-c93e-4d8b-8126-2955ab76628c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c890de34-c93e-4d8b-8126-2955ab76628c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c890de34-c93e-4d8b-8126-2955ab76628c">
											<gml:posList>35.667422601840805 139.7409007891029 31.4 35.667402580700845 139.74093389450033 11.3 35.66742130551743 139.74090294453833 11.3 35.667422601840805 139.7409007891029 31.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8694ca14-9949-498a-b38a-c9992be2a3dc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8694ca14-9949-498a-b38a-c9992be2a3dc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8694ca14-9949-498a-b38a-c9992be2a3dc">
											<gml:posList>35.66740220882411 139.740930879412 33.8 35.66740220882411 139.740930879412 33.219 35.66737417456882 139.7409053847685 33.219 35.66737417456882 139.7409053847685 33.8 35.66740220882411 139.740930879412 33.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a9c3de3e-1804-4fc3-8da7-863fd28c78da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9c3de3e-1804-4fc3-8da7-863fd28c78da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9c3de3e-1804-4fc3-8da7-863fd28c78da">
											<gml:posList>35.66737119105899 139.74090543239086 11.3 35.667402580700845 139.74093389450033 11.3 35.667402580700845 139.74093389450033 33.8 35.66737119105899 139.74090543239086 33.8 35.66737119105899 139.74090543239086 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d62ff30f-eb57-4332-a585-db7ea8b30680">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d62ff30f-eb57-4332-a585-db7ea8b30680">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d62ff30f-eb57-4332-a585-db7ea8b30680">
											<gml:posList>35.667475145527334 139.7408807244834 31.4 35.667475145527334 139.7408807244834 30.792 35.667448732818734 139.74092448547904 30.792 35.667448732818734 139.74092448547904 31.4 35.667475145527334 139.7408807244834 31.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6256</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">114.14898</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1241</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>