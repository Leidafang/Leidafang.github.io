<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_4c1440d9-a594-49da-b949-daa40024b0dc">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018002</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門二丁目10地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">422</bldg:usage>
			<bldg:measuredHeight uom="m">13.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66756924940035 139.74465660329005 0 35.667604651954335 139.7446275134809 0 35.66761427173923 139.7445937024498 0 35.66761586921538 139.74455978983332 0 35.6676077322632 139.74452644029043 0 35.66759229654548 139.74449630214488 0 35.667568933385944 139.74447246894397 0 35.6675432336639 139.74445813779428 0 35.66751384524197 139.74445319972807 0 35.667486177499406 139.7444591951607 0 35.66746014054184 139.74447645555648 0 35.66744444026979 139.7444542707851 0 35.667432451685286 139.74445384223918 0 35.66741893826725 139.74446357756727 0 35.667398861289946 139.74449563278085 0 35.6673852803791 139.744536075628 0 35.66738225064567 139.74458346566604 0 35.66742443554489 139.7445843026442 0 35.66742598301903 139.7446048462178 0 35.66743393308463 139.74462924875812 0 35.66745162163212 139.74465861116863 0 35.667472185701534 139.74467593042664 0 35.66749761449832 139.74468959918124 0 35.66752231341419 139.74469133921573 0 35.667545746586335 139.74468788909192 0 35.66757592988883 139.74467062416156 0 35.66756924940035 139.74465660329005 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66756924940035 139.74465660329005 8.93 35.66757592988883 139.74467062416156 8.93 35.667545746586335 139.74468788909192 8.93 35.66752231341419 139.74469133921573 8.93 35.66749761449832 139.74468959918124 8.93 35.667472185701534 139.74467593042664 8.93 35.66745162163212 139.74465861116863 8.93 35.66743393308463 139.74462924875812 8.93 35.66742598301903 139.7446048462178 8.93 35.66742443554489 139.7445843026442 8.93 35.66738225064567 139.74458346566604 8.93 35.6673852803791 139.744536075628 8.93 35.667398861289946 139.74449563278085 8.93 35.66741893826725 139.74446357756727 8.93 35.667432451685286 139.74445384223918 8.93 35.66744444026979 139.7444542707851 8.93 35.66746014054184 139.74447645555648 8.93 35.667486177499406 139.7444591951607 8.93 35.66751384524197 139.74445319972807 8.93 35.6675432336639 139.74445813779428 8.93 35.667568933385944 139.74447246894397 8.93 35.66759229654548 139.74449630214488 8.93 35.6676077322632 139.74452644029043 8.93 35.66761586921538 139.74455978983332 8.93 35.66761427173923 139.7445937024498 8.93 35.667604651954335 139.7446275134809 8.93 35.66756924940035 139.74465660329005 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66756924940035 139.74465660329005 8.93 35.667604651954335 139.7446275134809 8.93 35.667604651954335 139.7446275134809 22.82 35.66756924940035 139.74465660329005 22.82 35.66756924940035 139.74465660329005 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667604651954335 139.7446275134809 8.93 35.66761427173923 139.7445937024498 8.93 35.66761427173923 139.7445937024498 22.82 35.667604651954335 139.7446275134809 22.82 35.667604651954335 139.7446275134809 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66761427173923 139.7445937024498 8.93 35.66761586921538 139.74455978983332 8.93 35.66761586921538 139.74455978983332 22.82 35.66761427173923 139.7445937024498 22.82 35.66761427173923 139.7445937024498 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66761586921538 139.74455978983332 8.93 35.6676077322632 139.74452644029043 8.93 35.6676077322632 139.74452644029043 22.82 35.66761586921538 139.74455978983332 22.82 35.66761586921538 139.74455978983332 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6676077322632 139.74452644029043 8.93 35.66759229654548 139.74449630214488 8.93 35.66759229654548 139.74449630214488 22.82 35.6676077322632 139.74452644029043 22.82 35.6676077322632 139.74452644029043 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66759229654548 139.74449630214488 8.93 35.667568933385944 139.74447246894397 8.93 35.667568933385944 139.74447246894397 22.82 35.66759229654548 139.74449630214488 22.82 35.66759229654548 139.74449630214488 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667568933385944 139.74447246894397 8.93 35.6675432336639 139.74445813779428 8.93 35.6675432336639 139.74445813779428 22.82 35.667568933385944 139.74447246894397 22.82 35.667568933385944 139.74447246894397 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6675432336639 139.74445813779428 8.93 35.66751384524197 139.74445319972807 8.93 35.66751384524197 139.74445319972807 22.82 35.6675432336639 139.74445813779428 22.82 35.6675432336639 139.74445813779428 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66751384524197 139.74445319972807 8.93 35.667486177499406 139.7444591951607 8.93 35.667486177499406 139.7444591951607 22.82 35.66751384524197 139.74445319972807 22.82 35.66751384524197 139.74445319972807 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667486177499406 139.7444591951607 8.93 35.66746014054184 139.74447645555648 8.93 35.66746014054184 139.74447645555648 22.82 35.667486177499406 139.7444591951607 22.82 35.667486177499406 139.7444591951607 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66746014054184 139.74447645555648 8.93 35.66744444026979 139.7444542707851 8.93 35.66744444026979 139.7444542707851 22.82 35.66746014054184 139.74447645555648 22.82 35.66746014054184 139.74447645555648 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66744444026979 139.7444542707851 8.93 35.667432451685286 139.74445384223918 8.93 35.667432451685286 139.74445384223918 22.82 35.66744444026979 139.7444542707851 22.82 35.66744444026979 139.7444542707851 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667432451685286 139.74445384223918 8.93 35.66741893826725 139.74446357756727 8.93 35.66741893826725 139.74446357756727 22.82 35.667432451685286 139.74445384223918 22.82 35.667432451685286 139.74445384223918 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66741893826725 139.74446357756727 8.93 35.667398861289946 139.74449563278085 8.93 35.667398861289946 139.74449563278085 22.82 35.66741893826725 139.74446357756727 22.82 35.66741893826725 139.74446357756727 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667398861289946 139.74449563278085 8.93 35.6673852803791 139.744536075628 8.93 35.6673852803791 139.744536075628 22.82 35.667398861289946 139.74449563278085 22.82 35.667398861289946 139.74449563278085 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6673852803791 139.744536075628 8.93 35.66738225064567 139.74458346566604 8.93 35.66738225064567 139.74458346566604 22.82 35.6673852803791 139.744536075628 22.82 35.6673852803791 139.744536075628 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66738225064567 139.74458346566604 8.93 35.66742443554489 139.7445843026442 8.93 35.66742443554489 139.7445843026442 22.82 35.66738225064567 139.74458346566604 22.82 35.66738225064567 139.74458346566604 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66742443554489 139.7445843026442 8.93 35.66742598301903 139.7446048462178 8.93 35.66742598301903 139.7446048462178 22.82 35.66742443554489 139.7445843026442 22.82 35.66742443554489 139.7445843026442 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66742598301903 139.7446048462178 8.93 35.66743393308463 139.74462924875812 8.93 35.66743393308463 139.74462924875812 22.82 35.66742598301903 139.7446048462178 22.82 35.66742598301903 139.7446048462178 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66743393308463 139.74462924875812 8.93 35.66745162163212 139.74465861116863 8.93 35.66745162163212 139.74465861116863 22.82 35.66743393308463 139.74462924875812 22.82 35.66743393308463 139.74462924875812 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66745162163212 139.74465861116863 8.93 35.667472185701534 139.74467593042664 8.93 35.667472185701534 139.74467593042664 22.82 35.66745162163212 139.74465861116863 22.82 35.66745162163212 139.74465861116863 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667472185701534 139.74467593042664 8.93 35.66749761449832 139.74468959918124 8.93 35.66749761449832 139.74468959918124 22.82 35.667472185701534 139.74467593042664 22.82 35.667472185701534 139.74467593042664 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66749761449832 139.74468959918124 8.93 35.66752231341419 139.74469133921573 8.93 35.66752231341419 139.74469133921573 22.82 35.66749761449832 139.74468959918124 22.82 35.66749761449832 139.74468959918124 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66752231341419 139.74469133921573 8.93 35.667545746586335 139.74468788909192 8.93 35.667545746586335 139.74468788909192 22.82 35.66752231341419 139.74469133921573 22.82 35.66752231341419 139.74469133921573 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667545746586335 139.74468788909192 8.93 35.66757592988883 139.74467062416156 8.93 35.66757592988883 139.74467062416156 22.82 35.667545746586335 139.74468788909192 22.82 35.667545746586335 139.74468788909192 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66757592988883 139.74467062416156 8.93 35.66756924940035 139.74465660329005 8.93 35.66756924940035 139.74465660329005 22.82 35.66757592988883 139.74467062416156 22.82 35.66757592988883 139.74467062416156 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66756924940035 139.74465660329005 22.82 35.667604651954335 139.7446275134809 22.82 35.66761427173923 139.7445937024498 22.82 35.66761586921538 139.74455978983332 22.82 35.6676077322632 139.74452644029043 22.82 35.66759229654548 139.74449630214488 22.82 35.667568933385944 139.74447246894397 22.82 35.6675432336639 139.74445813779428 22.82 35.66751384524197 139.74445319972807 22.82 35.667486177499406 139.7444591951607 22.82 35.66746014054184 139.74447645555648 22.82 35.66744444026979 139.7444542707851 22.82 35.667432451685286 139.74445384223918 22.82 35.66741893826725 139.74446357756727 22.82 35.667398861289946 139.74449563278085 22.82 35.6673852803791 139.744536075628 22.82 35.66738225064567 139.74458346566604 22.82 35.66742443554489 139.7445843026442 22.82 35.66742598301903 139.7446048462178 22.82 35.66743393308463 139.74462924875812 22.82 35.66745162163212 139.74465861116863 22.82 35.667472185701534 139.74467593042664 22.82 35.66749761449832 139.74468959918124 22.82 35.66752231341419 139.74469133921573 22.82 35.667545746586335 139.74468788909192 22.82 35.66757592988883 139.74467062416156 22.82 35.66756924940035 139.74465660329005 22.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-3133b6b2-3ba8-4da5-b424-92694d406a44"/>
							<gml:surfaceMember xlink:href="#poly-7d40c5a1-5eb9-4eb6-bd08-098e8d6450b9"/>
							<gml:surfaceMember xlink:href="#poly-ecd83782-186f-41c7-9c96-7662e5c11cee"/>
							<gml:surfaceMember xlink:href="#poly-2eda2fd2-011a-478d-b62c-54a6976ca774"/>
							<gml:surfaceMember xlink:href="#poly-688dde11-59e0-4456-8710-dab4b7cd773d"/>
							<gml:surfaceMember xlink:href="#poly-674a0333-a15d-4ddc-9820-7d6f2f543d6b"/>
							<gml:surfaceMember xlink:href="#poly-62507709-e81d-4e01-8c3e-bec5bda53276"/>
							<gml:surfaceMember xlink:href="#poly-dbe35904-26b7-48e2-bc62-47f1dda87008"/>
							<gml:surfaceMember xlink:href="#poly-a71871da-106e-4058-bafb-94c75d814e79"/>
							<gml:surfaceMember xlink:href="#poly-9c794fc8-e818-4dd1-babb-4888def016cd"/>
							<gml:surfaceMember xlink:href="#poly-b740eab4-7c0b-4151-b838-613f3801c3d2"/>
							<gml:surfaceMember xlink:href="#poly-3edf4071-56ad-4c28-8037-9b4ab8201a41"/>
							<gml:surfaceMember xlink:href="#poly-95cd3438-5c60-4bb3-a6bb-b105aee823da"/>
							<gml:surfaceMember xlink:href="#poly-1a9fc98a-bd29-4177-b2ac-badbe844dd90"/>
							<gml:surfaceMember xlink:href="#poly-6e1d53c1-b39e-477a-9255-2f40c93223e3"/>
							<gml:surfaceMember xlink:href="#poly-cb0a695e-4b35-476b-857c-fee27ed89c4a"/>
							<gml:surfaceMember xlink:href="#poly-1ac74cbd-7630-4676-8dba-c31c19213e7b"/>
							<gml:surfaceMember xlink:href="#poly-30b3a850-c791-4d08-b200-b66b841dced5"/>
							<gml:surfaceMember xlink:href="#poly-cfa0f692-4792-41a5-a7ed-8cc20c843e44"/>
							<gml:surfaceMember xlink:href="#poly-3df07420-413c-42d6-bc1e-3d3cefc20f09"/>
							<gml:surfaceMember xlink:href="#poly-a9a395a4-72a4-44bb-8b92-0bf6ab9504e5"/>
							<gml:surfaceMember xlink:href="#poly-0b6f611a-cd57-480b-8a38-c7f7e6f13948"/>
							<gml:surfaceMember xlink:href="#poly-7fb3bdcb-efcd-41c5-99bf-370e2c6230f2"/>
							<gml:surfaceMember xlink:href="#poly-551c49be-c6a7-49dd-b393-d6da8052fa0b"/>
							<gml:surfaceMember xlink:href="#poly-584c9ed4-5b37-46a0-8fad-49da0030ac1d"/>
							<gml:surfaceMember xlink:href="#poly-2105ed55-3e25-453b-a067-9a359cabb29c"/>
							<gml:surfaceMember xlink:href="#poly-a432467c-557c-4018-ad70-5c00d5c8b645"/>
							<gml:surfaceMember xlink:href="#poly-e5f5af94-2964-4299-9a91-5ae5440ae6fd"/>
							<gml:surfaceMember xlink:href="#poly-6b9b6e7e-cb95-49ae-8f75-2dec00e0840c"/>
							<gml:surfaceMember xlink:href="#poly-8ad4b2ad-c089-4ef8-a355-ea46e481d6b6"/>
							<gml:surfaceMember xlink:href="#poly-a41db28d-d2b3-47ab-b337-9ef8c1990823"/>
							<gml:surfaceMember xlink:href="#poly-b4a25d73-8555-4179-8c4f-7723dba28eaf"/>
							<gml:surfaceMember xlink:href="#poly-d8d90c3f-ab1d-4827-af50-3f0bb44eb1ff"/>
							<gml:surfaceMember xlink:href="#poly-8bcba706-a2de-4218-abcc-ec17fd6c780c"/>
							<gml:surfaceMember xlink:href="#poly-244a30f9-0bf3-4442-9aee-b4d07958975a"/>
							<gml:surfaceMember xlink:href="#poly-fadf37f8-ec9a-4e5a-9cb3-d3aa8292a4e6"/>
							<gml:surfaceMember xlink:href="#poly-6613738f-7190-447e-be02-6c6a6e3ba2af"/>
							<gml:surfaceMember xlink:href="#poly-d46be7c3-8988-4ce3-9249-9cd2090f7147"/>
							<gml:surfaceMember xlink:href="#poly-e253559e-aec2-41ad-8f5e-c85d51bf868a"/>
							<gml:surfaceMember xlink:href="#poly-649d79e2-599e-4d75-a4b6-6ddb79571012"/>
							<gml:surfaceMember xlink:href="#poly-cf6b3fa6-3dcb-41df-88d9-10ed8a71c557"/>
							<gml:surfaceMember xlink:href="#poly-43a3f2ec-45b8-41c9-ac1a-b2700dc13040"/>
							<gml:surfaceMember xlink:href="#poly-71bea1bb-6b66-4b36-99e2-87875640a2b4"/>
							<gml:surfaceMember xlink:href="#poly-058a158e-922c-48c4-826a-5db8c9cec9b8"/>
							<gml:surfaceMember xlink:href="#poly-3cec4d3e-6c1d-4ba9-a5f8-1a309f9b20fe"/>
							<gml:surfaceMember xlink:href="#poly-f0d9f5ec-ab5b-4605-932d-631b755adda8"/>
							<gml:surfaceMember xlink:href="#poly-a805236f-3b5b-4b4d-86b7-425ad8675a25"/>
							<gml:surfaceMember xlink:href="#poly-f646f18e-fb22-4551-84b8-196673325c0e"/>
							<gml:surfaceMember xlink:href="#poly-5c8224be-5d55-44d3-a9d1-1d066e0a00fa"/>
							<gml:surfaceMember xlink:href="#poly-a4765d46-7e81-4f19-a0a4-d2fe8edb0164"/>
							<gml:surfaceMember xlink:href="#poly-f535b1c3-e877-493f-b596-71193cf6c2ab"/>
							<gml:surfaceMember xlink:href="#poly-f4f6def5-f263-49cb-8063-66f302edb9bb"/>
							<gml:surfaceMember xlink:href="#poly-c9ab1014-e285-4140-b0c5-f8761ec5dd40"/>
							<gml:surfaceMember xlink:href="#poly-ae119de3-50d8-4d6a-8078-0b759dd05876"/>
							<gml:surfaceMember xlink:href="#poly-63b4c778-d8f1-4413-a129-bffbf68a79bb"/>
							<gml:surfaceMember xlink:href="#poly-4ec9ac2b-384b-4cfd-9c5b-dcb94c1ac63a"/>
							<gml:surfaceMember xlink:href="#poly-cf6a5f7b-8227-4718-891b-f88e1c9ece7a"/>
							<gml:surfaceMember xlink:href="#poly-3c71d73b-204e-4995-a1b7-bf16c1930002"/>
							<gml:surfaceMember xlink:href="#poly-2900c6fb-8b25-4e4e-a0b0-2b1e6654f86c"/>
							<gml:surfaceMember xlink:href="#poly-b7ad3db6-ed51-44a9-b6ea-c8c2803f10b6"/>
							<gml:surfaceMember xlink:href="#poly-9b6a39fd-c7ec-4c3f-a387-f19087aa0336"/>
							<gml:surfaceMember xlink:href="#poly-f052bc8d-35ea-4458-a429-ba4f3cbd018a"/>
							<gml:surfaceMember xlink:href="#poly-70b945a9-4d19-4411-badf-34ece2a6c33f"/>
							<gml:surfaceMember xlink:href="#poly-22202f67-0be3-497b-a414-258e796a5fe0"/>
							<gml:surfaceMember xlink:href="#poly-5e7befa9-de64-4ae9-967d-5a0c34664544"/>
							<gml:surfaceMember xlink:href="#poly-55f1337b-fa1d-4dc5-a020-4a24d8a3cc01"/>
							<gml:surfaceMember xlink:href="#poly-43ec65d8-aa12-40d8-a16e-52775bf850af"/>
							<gml:surfaceMember xlink:href="#poly-c5b5f21c-de69-40e7-8c21-b88cac35b1cc"/>
							<gml:surfaceMember xlink:href="#poly-5b7f4b30-5c47-422e-9a64-2c19996580cb"/>
							<gml:surfaceMember xlink:href="#poly-4c98440f-de43-43d4-b61b-f6ef8c0252dc"/>
							<gml:surfaceMember xlink:href="#poly-6ab4407f-2811-4cdf-8889-b959affe7fa5"/>
							<gml:surfaceMember xlink:href="#poly-626145ad-40e7-4b3c-8a62-2af012d1b116"/>
							<gml:surfaceMember xlink:href="#poly-a7d77253-9357-4353-846c-ec44ccc0dfda"/>
							<gml:surfaceMember xlink:href="#poly-4faec500-337d-452b-8932-8cedce4d6eef"/>
							<gml:surfaceMember xlink:href="#poly-c1950a18-3910-4049-b339-e0f6a75f5306"/>
							<gml:surfaceMember xlink:href="#poly-e65db263-896b-4661-b67f-e18b4f787437"/>
							<gml:surfaceMember xlink:href="#poly-bd90a1a7-0573-483f-9457-0b1ed49eafb6"/>
							<gml:surfaceMember xlink:href="#poly-a49c08bc-8635-4d38-ba14-f0fdefc536a3"/>
							<gml:surfaceMember xlink:href="#poly-3b131d8c-78eb-423b-9884-d2731004bee5"/>
							<gml:surfaceMember xlink:href="#poly-e65870cc-8228-4359-9f90-976ece334945"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-3133b6b2-3ba8-4da5-b424-92694d406a44">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3133b6b2-3ba8-4da5-b424-92694d406a44">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3133b6b2-3ba8-4da5-b424-92694d406a44">
											<gml:posList>35.66756893338594 139.74447246894394 8.93 35.66759229654546 139.74449630214485 8.93 35.6676077322632 139.74452644029046 8.93 35.66761586921538 139.7445597898333 8.93 35.66761427173923 139.7445937024498 8.93 35.66760465195433 139.7446275134809 8.93 35.66756924940034 139.74465660329005 8.93 35.66757592988879 139.74467062416156 8.93 35.66754574658634 139.7446878890919 8.93 35.66752231341418 139.74469133921573 8.93 35.66749761449831 139.7446895991812 8.93 35.667472185701534 139.74467593042664 8.93 35.667451621632104 139.74465861116863 8.93 35.667433933084624 139.7446292487581 8.93 35.66742598301904 139.7446048462178 8.93 35.667424435544895 139.7445843026442 8.93 35.66738225064567 139.744583465666 8.93 35.6673852803791 139.74453607562796 8.93 35.667398861289946 139.74449563278085 8.93 35.667418938267225 139.74446357756727 8.93 35.66743245168527 139.74445384223918 8.93 35.667444440269776 139.7444542707851 8.93 35.66746014054184 139.74447645555648 8.93 35.66748617749941 139.7444591951607 8.93 35.66751384524198 139.74445319972807 8.93 35.667543233663906 139.74445813779428 8.93 35.66756893338594 139.74447246894394 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7d40c5a1-5eb9-4eb6-bd08-098e8d6450b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d40c5a1-5eb9-4eb6-bd08-098e8d6450b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d40c5a1-5eb9-4eb6-bd08-098e8d6450b9">
											<gml:posList>35.6673852803791 139.74453607562796 22.891 35.66738225064567 139.744583465666 22.891 35.667388113763096 139.74457692003494 22.891 35.66739061767912 139.74453766031965 22.891 35.6673852803791 139.74453607562796 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ecd83782-186f-41c7-9c96-7662e5c11cee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ecd83782-186f-41c7-9c96-7662e5c11cee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ecd83782-186f-41c7-9c96-7662e5c11cee">
											<gml:posList>35.6673852803791 139.74453607562796 22.891 35.66739061767912 139.74453766031965 22.891 35.66740362299124 139.74449895230623 22.891 35.667398861289946 139.74449563278085 22.891 35.6673852803791 139.74453607562796 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2eda2fd2-011a-478d-b62c-54a6976ca774">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2eda2fd2-011a-478d-b62c-54a6976ca774">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2eda2fd2-011a-478d-b62c-54a6976ca774">
											<gml:posList>35.667424435544895 139.7445843026442 22.891 35.6674293882595 139.7445777359257 22.891 35.667388113763096 139.74457692003494 22.891 35.66738225064567 139.744583465666 22.891 35.667424435544895 139.7445843026442 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-688dde11-59e0-4456-8710-dab4b7cd773d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-688dde11-59e0-4456-8710-dab4b7cd773d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-688dde11-59e0-4456-8710-dab4b7cd773d">
											<gml:posList>35.667398861289946 139.74449563278085 22.891 35.66740362299124 139.74449895230623 22.891 35.66742259257693 139.74446865460934 22.891 35.667418938267225 139.74446357756727 22.891 35.667398861289946 139.74449563278085 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-674a0333-a15d-4ddc-9820-7d6f2f543d6b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-674a0333-a15d-4ddc-9820-7d6f2f543d6b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-674a0333-a15d-4ddc-9820-7d6f2f543d6b">
											<gml:posList>35.667418938267225 139.74446357756727 22.891 35.66742259257693 139.74446865460934 22.891 35.66743385376176 139.74446054551845 22.891 35.66743245168527 139.74445384223918 22.891 35.667418938267225 139.74446357756727 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-62507709-e81d-4e01-8c3e-bec5bda53276">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-62507709-e81d-4e01-8c3e-bec5bda53276">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-62507709-e81d-4e01-8c3e-bec5bda53276">
											<gml:posList>35.667424435544895 139.7445843026442 22.891 35.66742598301904 139.7446048462178 22.891 35.66743131799849 139.74460328284914 22.891 35.6674293882595 139.7445777359257 22.891 35.667424435544895 139.7445843026442 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dbe35904-26b7-48e2-bc62-47f1dda87008">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dbe35904-26b7-48e2-bc62-47f1dda87008">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dbe35904-26b7-48e2-bc62-47f1dda87008">
											<gml:posList>35.667433933084624 139.7446292487581 22.891 35.667438707943866 139.7446259628572 22.891 35.66743131799849 139.74460328284914 22.891 35.66742598301904 139.7446048462178 22.891 35.667433933084624 139.7446292487581 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a71871da-106e-4058-bafb-94c75d814e79">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a71871da-106e-4058-bafb-94c75d814e79">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a71871da-106e-4058-bafb-94c75d814e79">
											<gml:posList>35.66743245168527 139.74445384223918 22.891 35.66743385376176 139.74446054551845 22.891 35.66744190324106 139.74446083483505 22.891 35.667444440269776 139.7444542707851 22.891 35.66743245168527 139.74445384223918 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9c794fc8-e818-4dd1-babb-4888def016cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c794fc8-e818-4dd1-babb-4888def016cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c794fc8-e818-4dd1-babb-4888def016cd">
											<gml:posList>35.667433933084624 139.7446292487581 22.891 35.667451621632104 139.74465861116863 22.891 35.66745544889558 139.744653757805 22.891 35.667438707943866 139.7446259628572 22.891 35.667433933084624 139.7446292487581 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b740eab4-7c0b-4151-b838-613f3801c3d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b740eab4-7c0b-4151-b838-613f3801c3d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b740eab4-7c0b-4151-b838-613f3801c3d2">
											<gml:posList>35.66746014054184 139.74447645555648 22.891 35.667444440269776 139.7444542707851 22.891 35.66744190324106 139.74446083483505 22.891 35.66745889381981 139.74448484074378 22.891 35.66746014054184 139.74447645555648 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3edf4071-56ad-4c28-8037-9b4ab8201a41">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3edf4071-56ad-4c28-8037-9b4ab8201a41">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3edf4071-56ad-4c28-8037-9b4ab8201a41">
											<gml:posList>35.667472185701534 139.74467593042664 22.891 35.66747484044907 139.7446700842317 22.891 35.66745544889558 139.744653757805 22.891 35.667451621632104 139.74465861116863 22.891 35.667472185701534 139.74467593042664 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-95cd3438-5c60-4bb3-a6bb-b105aee823da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-95cd3438-5c60-4bb3-a6bb-b105aee823da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-95cd3438-5c60-4bb3-a6bb-b105aee823da">
											<gml:posList>35.66746014054184 139.74447645555648 22.891 35.66745889381981 139.74448484074378 22.891 35.66748799395437 139.7444655555636 22.891 35.66748617749941 139.7444591951607 22.891 35.66746014054184 139.74447645555648 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1a9fc98a-bd29-4177-b2ac-badbe844dd90">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a9fc98a-bd29-4177-b2ac-badbe844dd90">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a9fc98a-bd29-4177-b2ac-badbe844dd90">
											<gml:posList>35.667472185701534 139.74467593042664 22.891 35.66749761449831 139.7446895991812 22.891 35.66749889861501 139.74468301442735 22.891 35.66747484044907 139.7446700842317 22.891 35.667472185701534 139.74467593042664 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6e1d53c1-b39e-477a-9255-2f40c93223e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e1d53c1-b39e-477a-9255-2f40c93223e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e1d53c1-b39e-477a-9255-2f40c93223e3">
											<gml:posList>35.667522128220114 139.74468465667144 23.344 35.66754422749859 139.74468139580017 23.344 35.667568238999145 139.74466767237166 23.344 35.667561982814455 139.74465454574812 23.344 35.66760011488383 139.74462322165394 23.344 35.66760888956687 139.74459238290078 23.344 35.667610389447 139.74456058015733 23.344 35.66760273168076 139.74452920729797 23.344 35.6675881534983 139.74450073613085 23.344 35.667566017135826 139.74447816079984 23.344 35.66754167904986 139.74446459030474 23.344 35.66751395837168 139.74445992653446 23.344 35.66748799395437 139.7444655555636 23.344 35.66745889381981 139.74448484074378 23.344 35.66744190324106 139.74446083483505 23.344 35.66743385376176 139.74446054551845 23.344 35.66742259257693 139.74446865460934 23.344 35.66740362299124 139.74449895230623 23.344 35.66739061767912 139.74453766031965 23.344 35.667388113763096 139.74457692003494 23.344 35.6674293882595 139.7445777359257 23.344 35.66743131799849 139.74460328284914 23.344 35.667438707943866 139.7446259628572 23.344 35.66745544889558 139.744653757805 23.344 35.66747484044907 139.7446700842317 23.344 35.66749889861501 139.74468301442735 23.344 35.667522128220114 139.74468465667144 23.344</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cb0a695e-4b35-476b-857c-fee27ed89c4a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb0a695e-4b35-476b-857c-fee27ed89c4a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb0a695e-4b35-476b-857c-fee27ed89c4a">
											<gml:posList>35.66748617749941 139.7444591951607 22.891 35.66748799395437 139.7444655555636 22.891 35.66751395837168 139.74445992653446 22.891 35.66751384524198 139.74445319972807 22.891 35.66748617749941 139.7444591951607 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1ac74cbd-7630-4676-8dba-c31c19213e7b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ac74cbd-7630-4676-8dba-c31c19213e7b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ac74cbd-7630-4676-8dba-c31c19213e7b">
											<gml:posList>35.66752231341418 139.74469133921573 22.891 35.667522128220114 139.74468465667144 22.891 35.66749889861501 139.74468301442735 22.891 35.66749761449831 139.7446895991812 22.891 35.66752231341418 139.74469133921573 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-30b3a850-c791-4d08-b200-b66b841dced5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-30b3a850-c791-4d08-b200-b66b841dced5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-30b3a850-c791-4d08-b200-b66b841dced5">
											<gml:posList>35.66751384524198 139.74445319972807 22.891 35.66751395837168 139.74445992653446 22.891 35.66754167904986 139.74446459030474 22.891 35.667543233663906 139.74445813779428 22.891 35.66751384524198 139.74445319972807 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cfa0f692-4792-41a5-a7ed-8cc20c843e44">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cfa0f692-4792-41a5-a7ed-8cc20c843e44">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cfa0f692-4792-41a5-a7ed-8cc20c843e44">
											<gml:posList>35.66752231341418 139.74469133921573 22.891 35.66754574658634 139.7446878890919 22.891 35.66754422749859 139.74468139580017 22.891 35.667522128220114 139.74468465667144 22.891 35.66752231341418 139.74469133921573 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3df07420-413c-42d6-bc1e-3d3cefc20f09">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3df07420-413c-42d6-bc1e-3d3cefc20f09">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3df07420-413c-42d6-bc1e-3d3cefc20f09">
											<gml:posList>35.667543233663906 139.74445813779428 22.891 35.66754167904986 139.74446459030474 22.891 35.667566017135826 139.74447816079984 22.891 35.66756893338594 139.74447246894394 22.891 35.667543233663906 139.74445813779428 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a9a395a4-72a4-44bb-8b92-0bf6ab9504e5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9a395a4-72a4-44bb-8b92-0bf6ab9504e5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9a395a4-72a4-44bb-8b92-0bf6ab9504e5">
											<gml:posList>35.66754574658634 139.7446878890919 22.891 35.66757592988879 139.74467062416156 22.891 35.667568238999145 139.74466767237166 22.891 35.66754422749859 139.74468139580017 22.891 35.66754574658634 139.7446878890919 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0b6f611a-cd57-480b-8a38-c7f7e6f13948">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b6f611a-cd57-480b-8a38-c7f7e6f13948">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b6f611a-cd57-480b-8a38-c7f7e6f13948">
											<gml:posList>35.66756924940034 139.74465660329005 22.891 35.667561982814455 139.74465454574812 22.891 35.667568238999145 139.74466767237166 22.891 35.66757592988879 139.74467062416156 22.891 35.66756924940034 139.74465660329005 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7fb3bdcb-efcd-41c5-99bf-370e2c6230f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7fb3bdcb-efcd-41c5-99bf-370e2c6230f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7fb3bdcb-efcd-41c5-99bf-370e2c6230f2">
											<gml:posList>35.66756893338594 139.74447246894394 22.891 35.667566017135826 139.74447816079984 22.891 35.6675881534983 139.74450073613085 22.891 35.66759229654546 139.74449630214485 22.891 35.66756893338594 139.74447246894394 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-551c49be-c6a7-49dd-b393-d6da8052fa0b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-551c49be-c6a7-49dd-b393-d6da8052fa0b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-551c49be-c6a7-49dd-b393-d6da8052fa0b">
											<gml:posList>35.66756924940034 139.74465660329005 22.891 35.66760465195433 139.7446275134809 22.891 35.66760011488383 139.74462322165394 22.891 35.667561982814455 139.74465454574812 22.891 35.66756924940034 139.74465660329005 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-584c9ed4-5b37-46a0-8fad-49da0030ac1d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-584c9ed4-5b37-46a0-8fad-49da0030ac1d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-584c9ed4-5b37-46a0-8fad-49da0030ac1d">
											<gml:posList>35.66759229654546 139.74449630214485 22.891 35.6675881534983 139.74450073613085 22.891 35.66760273168076 139.74452920729797 22.891 35.6676077322632 139.74452644029046 22.891 35.66759229654546 139.74449630214485 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2105ed55-3e25-453b-a067-9a359cabb29c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2105ed55-3e25-453b-a067-9a359cabb29c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2105ed55-3e25-453b-a067-9a359cabb29c">
											<gml:posList>35.66761427173923 139.7445937024498 22.891 35.66760888956687 139.74459238290078 22.891 35.66760011488383 139.74462322165394 22.891 35.66760465195433 139.7446275134809 22.891 35.66761427173923 139.7445937024498 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a432467c-557c-4018-ad70-5c00d5c8b645">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a432467c-557c-4018-ad70-5c00d5c8b645">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a432467c-557c-4018-ad70-5c00d5c8b645">
											<gml:posList>35.6676077322632 139.74452644029046 22.891 35.66760273168076 139.74452920729797 22.891 35.667610389447 139.74456058015733 22.891 35.66761586921538 139.7445597898333 22.891 35.6676077322632 139.74452644029046 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e5f5af94-2964-4299-9a91-5ae5440ae6fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5f5af94-2964-4299-9a91-5ae5440ae6fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5f5af94-2964-4299-9a91-5ae5440ae6fd">
											<gml:posList>35.66761427173923 139.7445937024498 22.891 35.66761586921538 139.7445597898333 22.891 35.667610389447 139.74456058015733 22.891 35.66760888956687 139.74459238290078 22.891 35.66761427173923 139.7445937024498 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6b9b6e7e-cb95-49ae-8f75-2dec00e0840c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b9b6e7e-cb95-49ae-8f75-2dec00e0840c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b9b6e7e-cb95-49ae-8f75-2dec00e0840c">
											<gml:posList>35.6673852803791 139.74453607562796 8.93 35.66738225064567 139.744583465666 8.93 35.66738225064567 139.744583465666 22.891 35.6673852803791 139.74453607562796 22.891 35.6673852803791 139.74453607562796 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8ad4b2ad-c089-4ef8-a355-ea46e481d6b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ad4b2ad-c089-4ef8-a355-ea46e481d6b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ad4b2ad-c089-4ef8-a355-ea46e481d6b6">
											<gml:posList>35.667388113763096 139.74457692003494 22.891 35.667388113763096 139.74457692003494 23.344 35.66739061767912 139.74453766031965 23.344 35.66739061767912 139.74453766031965 22.891 35.667388113763096 139.74457692003494 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a41db28d-d2b3-47ab-b337-9ef8c1990823">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a41db28d-d2b3-47ab-b337-9ef8c1990823">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a41db28d-d2b3-47ab-b337-9ef8c1990823">
											<gml:posList>35.667398861289946 139.74449563278085 8.93 35.6673852803791 139.74453607562796 8.93 35.6673852803791 139.74453607562796 22.891 35.667398861289946 139.74449563278085 22.891 35.667398861289946 139.74449563278085 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b4a25d73-8555-4179-8c4f-7723dba28eaf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b4a25d73-8555-4179-8c4f-7723dba28eaf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b4a25d73-8555-4179-8c4f-7723dba28eaf">
											<gml:posList>35.66739061767912 139.74453766031965 22.891 35.66739061767912 139.74453766031965 23.344 35.66740362299124 139.74449895230623 23.344 35.66740362299124 139.74449895230623 22.891 35.66739061767912 139.74453766031965 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d8d90c3f-ab1d-4827-af50-3f0bb44eb1ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d8d90c3f-ab1d-4827-af50-3f0bb44eb1ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d8d90c3f-ab1d-4827-af50-3f0bb44eb1ff">
											<gml:posList>35.66738225064567 139.744583465666 8.93 35.667424435544895 139.7445843026442 8.93 35.667424435544895 139.7445843026442 22.891 35.66738225064567 139.744583465666 22.891 35.66738225064567 139.744583465666 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8bcba706-a2de-4218-abcc-ec17fd6c780c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8bcba706-a2de-4218-abcc-ec17fd6c780c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8bcba706-a2de-4218-abcc-ec17fd6c780c">
											<gml:posList>35.6674293882595 139.7445777359257 22.891 35.6674293882595 139.7445777359257 23.344 35.667388113763096 139.74457692003494 23.344 35.667388113763096 139.74457692003494 22.891 35.6674293882595 139.7445777359257 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-244a30f9-0bf3-4442-9aee-b4d07958975a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-244a30f9-0bf3-4442-9aee-b4d07958975a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-244a30f9-0bf3-4442-9aee-b4d07958975a">
											<gml:posList>35.667418938267225 139.74446357756727 8.93 35.667398861289946 139.74449563278085 8.93 35.667398861289946 139.74449563278085 22.891 35.667418938267225 139.74446357756727 22.891 35.667418938267225 139.74446357756727 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fadf37f8-ec9a-4e5a-9cb3-d3aa8292a4e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fadf37f8-ec9a-4e5a-9cb3-d3aa8292a4e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fadf37f8-ec9a-4e5a-9cb3-d3aa8292a4e6">
											<gml:posList>35.66740362299124 139.74449895230623 22.891 35.66740362299124 139.74449895230623 23.344 35.66742259257693 139.74446865460934 23.344 35.66742259257693 139.74446865460934 22.891 35.66740362299124 139.74449895230623 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6613738f-7190-447e-be02-6c6a6e3ba2af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6613738f-7190-447e-be02-6c6a6e3ba2af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6613738f-7190-447e-be02-6c6a6e3ba2af">
											<gml:posList>35.667424435544895 139.7445843026442 8.93 35.66742598301904 139.7446048462178 8.93 35.66742598301904 139.7446048462178 22.891 35.667424435544895 139.7445843026442 22.891 35.667424435544895 139.7445843026442 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d46be7c3-8988-4ce3-9249-9cd2090f7147">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d46be7c3-8988-4ce3-9249-9cd2090f7147">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d46be7c3-8988-4ce3-9249-9cd2090f7147">
											<gml:posList>35.66743245168527 139.74445384223918 8.93 35.667418938267225 139.74446357756727 8.93 35.667418938267225 139.74446357756727 22.891 35.66743245168527 139.74445384223918 22.891 35.66743245168527 139.74445384223918 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e253559e-aec2-41ad-8f5e-c85d51bf868a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e253559e-aec2-41ad-8f5e-c85d51bf868a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e253559e-aec2-41ad-8f5e-c85d51bf868a">
											<gml:posList>35.66742259257693 139.74446865460934 22.891 35.66742259257693 139.74446865460934 23.344 35.66743385376176 139.74446054551845 23.344 35.66743385376176 139.74446054551845 22.891 35.66742259257693 139.74446865460934 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-649d79e2-599e-4d75-a4b6-6ddb79571012">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-649d79e2-599e-4d75-a4b6-6ddb79571012">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-649d79e2-599e-4d75-a4b6-6ddb79571012">
											<gml:posList>35.66742598301904 139.7446048462178 8.93 35.667433933084624 139.7446292487581 8.93 35.667433933084624 139.7446292487581 22.891 35.66742598301904 139.7446048462178 22.891 35.66742598301904 139.7446048462178 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cf6b3fa6-3dcb-41df-88d9-10ed8a71c557">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cf6b3fa6-3dcb-41df-88d9-10ed8a71c557">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cf6b3fa6-3dcb-41df-88d9-10ed8a71c557">
											<gml:posList>35.66743131799849 139.74460328284914 22.891 35.66743131799849 139.74460328284914 23.344 35.6674293882595 139.7445777359257 23.344 35.6674293882595 139.7445777359257 22.891 35.66743131799849 139.74460328284914 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-43a3f2ec-45b8-41c9-ac1a-b2700dc13040">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-43a3f2ec-45b8-41c9-ac1a-b2700dc13040">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-43a3f2ec-45b8-41c9-ac1a-b2700dc13040">
											<gml:posList>35.667438707943866 139.7446259628572 22.891 35.667438707943866 139.7446259628572 23.344 35.66743131799849 139.74460328284914 23.344 35.66743131799849 139.74460328284914 22.891 35.667438707943866 139.7446259628572 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-71bea1bb-6b66-4b36-99e2-87875640a2b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-71bea1bb-6b66-4b36-99e2-87875640a2b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-71bea1bb-6b66-4b36-99e2-87875640a2b4">
											<gml:posList>35.66743385376176 139.74446054551845 22.891 35.66743385376176 139.74446054551845 23.344 35.66744190324106 139.74446083483505 23.344 35.66744190324106 139.74446083483505 22.891 35.66743385376176 139.74446054551845 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-058a158e-922c-48c4-826a-5db8c9cec9b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-058a158e-922c-48c4-826a-5db8c9cec9b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-058a158e-922c-48c4-826a-5db8c9cec9b8">
											<gml:posList>35.667444440269776 139.7444542707851 8.93 35.66743245168527 139.74445384223918 8.93 35.66743245168527 139.74445384223918 22.891 35.667444440269776 139.7444542707851 22.891 35.667444440269776 139.7444542707851 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3cec4d3e-6c1d-4ba9-a5f8-1a309f9b20fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3cec4d3e-6c1d-4ba9-a5f8-1a309f9b20fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3cec4d3e-6c1d-4ba9-a5f8-1a309f9b20fe">
											<gml:posList>35.667433933084624 139.7446292487581 8.93 35.667451621632104 139.74465861116863 8.93 35.667451621632104 139.74465861116863 22.891 35.667433933084624 139.7446292487581 22.891 35.667433933084624 139.7446292487581 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f0d9f5ec-ab5b-4605-932d-631b755adda8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f0d9f5ec-ab5b-4605-932d-631b755adda8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f0d9f5ec-ab5b-4605-932d-631b755adda8">
											<gml:posList>35.66745544889558 139.744653757805 22.891 35.66745544889558 139.744653757805 23.344 35.667438707943866 139.7446259628572 23.344 35.667438707943866 139.7446259628572 22.891 35.66745544889558 139.744653757805 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a805236f-3b5b-4b4d-86b7-425ad8675a25">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a805236f-3b5b-4b4d-86b7-425ad8675a25">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a805236f-3b5b-4b4d-86b7-425ad8675a25">
											<gml:posList>35.66744190324106 139.74446083483505 22.891 35.66744190324106 139.74446083483505 23.344 35.66745889381981 139.74448484074378 23.344 35.66745889381981 139.74448484074378 22.891 35.66744190324106 139.74446083483505 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f646f18e-fb22-4551-84b8-196673325c0e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f646f18e-fb22-4551-84b8-196673325c0e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f646f18e-fb22-4551-84b8-196673325c0e">
											<gml:posList>35.66746014054184 139.74447645555648 8.93 35.667444440269776 139.7444542707851 8.93 35.667444440269776 139.7444542707851 22.891 35.66746014054184 139.74447645555648 22.891 35.66746014054184 139.74447645555648 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5c8224be-5d55-44d3-a9d1-1d066e0a00fa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5c8224be-5d55-44d3-a9d1-1d066e0a00fa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5c8224be-5d55-44d3-a9d1-1d066e0a00fa">
											<gml:posList>35.667451621632104 139.74465861116863 8.93 35.667472185701534 139.74467593042664 8.93 35.667472185701534 139.74467593042664 22.891 35.667451621632104 139.74465861116863 22.891 35.667451621632104 139.74465861116863 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a4765d46-7e81-4f19-a0a4-d2fe8edb0164">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4765d46-7e81-4f19-a0a4-d2fe8edb0164">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4765d46-7e81-4f19-a0a4-d2fe8edb0164">
											<gml:posList>35.66747484044907 139.7446700842317 22.891 35.66747484044907 139.7446700842317 23.344 35.66745544889558 139.744653757805 23.344 35.66745544889558 139.744653757805 22.891 35.66747484044907 139.7446700842317 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f535b1c3-e877-493f-b596-71193cf6c2ab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f535b1c3-e877-493f-b596-71193cf6c2ab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f535b1c3-e877-493f-b596-71193cf6c2ab">
											<gml:posList>35.66748617749941 139.7444591951607 8.93 35.66746014054184 139.74447645555648 8.93 35.66746014054184 139.74447645555648 22.891 35.66748617749941 139.7444591951607 22.891 35.66748617749941 139.7444591951607 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f4f6def5-f263-49cb-8063-66f302edb9bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4f6def5-f263-49cb-8063-66f302edb9bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4f6def5-f263-49cb-8063-66f302edb9bb">
											<gml:posList>35.66745889381981 139.74448484074378 22.891 35.66745889381981 139.74448484074378 23.344 35.66748799395437 139.7444655555636 23.344 35.66748799395437 139.7444655555636 22.891 35.66745889381981 139.74448484074378 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c9ab1014-e285-4140-b0c5-f8761ec5dd40">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c9ab1014-e285-4140-b0c5-f8761ec5dd40">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c9ab1014-e285-4140-b0c5-f8761ec5dd40">
											<gml:posList>35.667472185701534 139.74467593042664 8.93 35.66749761449831 139.7446895991812 8.93 35.66749761449831 139.7446895991812 22.891 35.667472185701534 139.74467593042664 22.891 35.667472185701534 139.74467593042664 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ae119de3-50d8-4d6a-8078-0b759dd05876">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ae119de3-50d8-4d6a-8078-0b759dd05876">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ae119de3-50d8-4d6a-8078-0b759dd05876">
											<gml:posList>35.66749889861501 139.74468301442735 22.891 35.66749889861501 139.74468301442735 23.344 35.66747484044907 139.7446700842317 23.344 35.66747484044907 139.7446700842317 22.891 35.66749889861501 139.74468301442735 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-63b4c778-d8f1-4413-a129-bffbf68a79bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-63b4c778-d8f1-4413-a129-bffbf68a79bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-63b4c778-d8f1-4413-a129-bffbf68a79bb">
											<gml:posList>35.66751384524198 139.74445319972807 8.93 35.66748617749941 139.7444591951607 8.93 35.66748617749941 139.7444591951607 22.891 35.66751384524198 139.74445319972807 22.891 35.66751384524198 139.74445319972807 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4ec9ac2b-384b-4cfd-9c5b-dcb94c1ac63a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ec9ac2b-384b-4cfd-9c5b-dcb94c1ac63a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ec9ac2b-384b-4cfd-9c5b-dcb94c1ac63a">
											<gml:posList>35.66748799395437 139.7444655555636 22.891 35.66748799395437 139.7444655555636 23.344 35.66751395837168 139.74445992653446 23.344 35.66751395837168 139.74445992653446 22.891 35.66748799395437 139.7444655555636 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cf6a5f7b-8227-4718-891b-f88e1c9ece7a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cf6a5f7b-8227-4718-891b-f88e1c9ece7a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cf6a5f7b-8227-4718-891b-f88e1c9ece7a">
											<gml:posList>35.66749761449831 139.7446895991812 8.93 35.66752231341418 139.74469133921573 8.93 35.66752231341418 139.74469133921573 22.891 35.66749761449831 139.7446895991812 22.891 35.66749761449831 139.7446895991812 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3c71d73b-204e-4995-a1b7-bf16c1930002">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c71d73b-204e-4995-a1b7-bf16c1930002">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c71d73b-204e-4995-a1b7-bf16c1930002">
											<gml:posList>35.667522128220114 139.74468465667144 22.891 35.667522128220114 139.74468465667144 23.344 35.66749889861501 139.74468301442735 23.344 35.66749889861501 139.74468301442735 22.891 35.667522128220114 139.74468465667144 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2900c6fb-8b25-4e4e-a0b0-2b1e6654f86c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2900c6fb-8b25-4e4e-a0b0-2b1e6654f86c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2900c6fb-8b25-4e4e-a0b0-2b1e6654f86c">
											<gml:posList>35.66751395837168 139.74445992653446 22.891 35.66751395837168 139.74445992653446 23.344 35.66754167904986 139.74446459030474 23.344 35.66754167904986 139.74446459030474 22.891 35.66751395837168 139.74445992653446 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b7ad3db6-ed51-44a9-b6ea-c8c2803f10b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b7ad3db6-ed51-44a9-b6ea-c8c2803f10b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b7ad3db6-ed51-44a9-b6ea-c8c2803f10b6">
											<gml:posList>35.667543233663906 139.74445813779428 8.93 35.66751384524198 139.74445319972807 8.93 35.66751384524198 139.74445319972807 22.891 35.667543233663906 139.74445813779428 22.891 35.667543233663906 139.74445813779428 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9b6a39fd-c7ec-4c3f-a387-f19087aa0336">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b6a39fd-c7ec-4c3f-a387-f19087aa0336">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b6a39fd-c7ec-4c3f-a387-f19087aa0336">
											<gml:posList>35.66754422749859 139.74468139580017 22.891 35.66754422749859 139.74468139580017 23.344 35.667522128220114 139.74468465667144 23.344 35.667522128220114 139.74468465667144 22.891 35.66754422749859 139.74468139580017 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f052bc8d-35ea-4458-a429-ba4f3cbd018a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f052bc8d-35ea-4458-a429-ba4f3cbd018a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f052bc8d-35ea-4458-a429-ba4f3cbd018a">
											<gml:posList>35.66752231341418 139.74469133921573 8.93 35.66754574658634 139.7446878890919 8.93 35.66754574658634 139.7446878890919 22.891 35.66752231341418 139.74469133921573 22.891 35.66752231341418 139.74469133921573 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-70b945a9-4d19-4411-badf-34ece2a6c33f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70b945a9-4d19-4411-badf-34ece2a6c33f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70b945a9-4d19-4411-badf-34ece2a6c33f">
											<gml:posList>35.66754167904986 139.74446459030474 22.891 35.66754167904986 139.74446459030474 23.344 35.667566017135826 139.74447816079984 23.344 35.667566017135826 139.74447816079984 22.891 35.66754167904986 139.74446459030474 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-22202f67-0be3-497b-a414-258e796a5fe0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22202f67-0be3-497b-a414-258e796a5fe0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22202f67-0be3-497b-a414-258e796a5fe0">
											<gml:posList>35.667568238999145 139.74466767237166 22.891 35.667568238999145 139.74466767237166 23.344 35.66754422749859 139.74468139580017 23.344 35.66754422749859 139.74468139580017 22.891 35.667568238999145 139.74466767237166 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5e7befa9-de64-4ae9-967d-5a0c34664544">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e7befa9-de64-4ae9-967d-5a0c34664544">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e7befa9-de64-4ae9-967d-5a0c34664544">
											<gml:posList>35.66756893338594 139.74447246894394 8.93 35.667543233663906 139.74445813779428 8.93 35.667543233663906 139.74445813779428 22.891 35.66756893338594 139.74447246894394 22.891 35.66756893338594 139.74447246894394 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-55f1337b-fa1d-4dc5-a020-4a24d8a3cc01">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-55f1337b-fa1d-4dc5-a020-4a24d8a3cc01">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-55f1337b-fa1d-4dc5-a020-4a24d8a3cc01">
											<gml:posList>35.66754574658634 139.7446878890919 8.93 35.66757592988879 139.74467062416156 8.93 35.66757592988879 139.74467062416156 22.891 35.66754574658634 139.7446878890919 22.891 35.66754574658634 139.7446878890919 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-43ec65d8-aa12-40d8-a16e-52775bf850af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-43ec65d8-aa12-40d8-a16e-52775bf850af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-43ec65d8-aa12-40d8-a16e-52775bf850af">
											<gml:posList>35.667561982814455 139.74465454574812 22.891 35.667561982814455 139.74465454574812 23.344 35.667568238999145 139.74466767237166 23.344 35.667568238999145 139.74466767237166 22.891 35.667561982814455 139.74465454574812 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c5b5f21c-de69-40e7-8c21-b88cac35b1cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c5b5f21c-de69-40e7-8c21-b88cac35b1cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c5b5f21c-de69-40e7-8c21-b88cac35b1cc">
											<gml:posList>35.66757592988879 139.74467062416156 8.93 35.66756924940034 139.74465660329005 8.93 35.66756924940034 139.74465660329005 22.891 35.66757592988879 139.74467062416156 22.891 35.66757592988879 139.74467062416156 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5b7f4b30-5c47-422e-9a64-2c19996580cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b7f4b30-5c47-422e-9a64-2c19996580cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b7f4b30-5c47-422e-9a64-2c19996580cb">
											<gml:posList>35.667566017135826 139.74447816079984 22.891 35.667566017135826 139.74447816079984 23.344 35.6675881534983 139.74450073613085 23.344 35.6675881534983 139.74450073613085 22.891 35.667566017135826 139.74447816079984 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4c98440f-de43-43d4-b61b-f6ef8c0252dc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c98440f-de43-43d4-b61b-f6ef8c0252dc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c98440f-de43-43d4-b61b-f6ef8c0252dc">
											<gml:posList>35.66759229654546 139.74449630214485 8.93 35.66756893338594 139.74447246894394 8.93 35.66756893338594 139.74447246894394 22.891 35.66759229654546 139.74449630214485 22.891 35.66759229654546 139.74449630214485 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6ab4407f-2811-4cdf-8889-b959affe7fa5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ab4407f-2811-4cdf-8889-b959affe7fa5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ab4407f-2811-4cdf-8889-b959affe7fa5">
											<gml:posList>35.66760011488383 139.74462322165394 22.891 35.66760011488383 139.74462322165394 23.344 35.667561982814455 139.74465454574812 23.344 35.667561982814455 139.74465454574812 22.891 35.66760011488383 139.74462322165394 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-626145ad-40e7-4b3c-8a62-2af012d1b116">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-626145ad-40e7-4b3c-8a62-2af012d1b116">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-626145ad-40e7-4b3c-8a62-2af012d1b116">
											<gml:posList>35.66756924940034 139.74465660329005 8.93 35.66760465195433 139.7446275134809 8.93 35.66760465195433 139.7446275134809 22.891 35.66756924940034 139.74465660329005 22.891 35.66756924940034 139.74465660329005 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a7d77253-9357-4353-846c-ec44ccc0dfda">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a7d77253-9357-4353-846c-ec44ccc0dfda">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a7d77253-9357-4353-846c-ec44ccc0dfda">
											<gml:posList>35.6675881534983 139.74450073613085 22.891 35.6675881534983 139.74450073613085 23.344 35.66760273168076 139.74452920729797 23.344 35.66760273168076 139.74452920729797 22.891 35.6675881534983 139.74450073613085 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4faec500-337d-452b-8932-8cedce4d6eef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4faec500-337d-452b-8932-8cedce4d6eef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4faec500-337d-452b-8932-8cedce4d6eef">
											<gml:posList>35.6676077322632 139.74452644029046 8.93 35.66759229654546 139.74449630214485 8.93 35.66759229654546 139.74449630214485 22.891 35.6676077322632 139.74452644029046 22.891 35.6676077322632 139.74452644029046 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c1950a18-3910-4049-b339-e0f6a75f5306">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c1950a18-3910-4049-b339-e0f6a75f5306">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c1950a18-3910-4049-b339-e0f6a75f5306">
											<gml:posList>35.66760888956687 139.74459238290078 22.891 35.66760888956687 139.74459238290078 23.344 35.66760011488383 139.74462322165394 23.344 35.66760011488383 139.74462322165394 22.891 35.66760888956687 139.74459238290078 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e65db263-896b-4661-b67f-e18b4f787437">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e65db263-896b-4661-b67f-e18b4f787437">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e65db263-896b-4661-b67f-e18b4f787437">
											<gml:posList>35.66760273168076 139.74452920729797 22.891 35.66760273168076 139.74452920729797 23.344 35.667610389447 139.74456058015733 23.344 35.667610389447 139.74456058015733 22.891 35.66760273168076 139.74452920729797 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bd90a1a7-0573-483f-9457-0b1ed49eafb6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd90a1a7-0573-483f-9457-0b1ed49eafb6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd90a1a7-0573-483f-9457-0b1ed49eafb6">
											<gml:posList>35.66760465195433 139.7446275134809 8.93 35.66761427173923 139.7445937024498 8.93 35.66761427173923 139.7445937024498 22.891 35.66760465195433 139.7446275134809 22.891 35.66760465195433 139.7446275134809 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a49c08bc-8635-4d38-ba14-f0fdefc536a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a49c08bc-8635-4d38-ba14-f0fdefc536a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a49c08bc-8635-4d38-ba14-f0fdefc536a3">
											<gml:posList>35.667610389447 139.74456058015733 22.891 35.667610389447 139.74456058015733 23.344 35.66760888956687 139.74459238290078 23.344 35.66760888956687 139.74459238290078 22.891 35.667610389447 139.74456058015733 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3b131d8c-78eb-423b-9884-d2731004bee5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3b131d8c-78eb-423b-9884-d2731004bee5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3b131d8c-78eb-423b-9884-d2731004bee5">
											<gml:posList>35.66761586921538 139.7445597898333 8.93 35.6676077322632 139.74452644029046 8.93 35.6676077322632 139.74452644029046 22.891 35.66761586921538 139.7445597898333 22.891 35.66761586921538 139.7445597898333 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e65870cc-8228-4359-9f90-976ece334945">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e65870cc-8228-4359-9f90-976ece334945">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e65870cc-8228-4359-9f90-976ece334945">
											<gml:posList>35.66761427173923 139.7445937024498 8.93 35.66761586921538 139.7445597898333 8.93 35.66761586921538 139.7445597898333 22.891 35.66761427173923 139.7445937024498 22.891 35.66761427173923 139.7445937024498 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2525</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">408.5596</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1122</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.04</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>