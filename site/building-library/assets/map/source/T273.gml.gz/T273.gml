<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_4c215d68-6be6-4236-be35-d008a0821c2e">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="説明注記">
				<gen:value>倉庫</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>29</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103029002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">3.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>1</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66852349912268 139.73766409037424 0 35.66852079983189 139.73767016889653 0 35.66848589854977 139.73764734531954 0 35.66845206853717 139.7377249285649 0 35.668545589611085 139.73778623284826 0 35.668561155039455 139.7377505356926 0 35.66855267784177 139.73774513325426 0 35.66857274073387 139.7376976114931 0 35.66852349912268 139.73766409037424 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66852349912268 139.73766409037424 24.406 35.66857274073387 139.7376976114931 24.406 35.66855267784177 139.73774513325426 24.406 35.668561155039455 139.7377505356926 24.406 35.668545589611085 139.73778623284826 24.406 35.66845206853717 139.7377249285649 24.406 35.66848589854977 139.73764734531954 24.406 35.66852079983189 139.73767016889653 24.406 35.66852349912268 139.73766409037424 24.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66852349912268 139.73766409037424 24.406 35.66852079983189 139.73767016889653 24.406 35.66852079983189 139.73767016889653 27.5 35.66852349912268 139.73766409037424 27.5 35.66852349912268 139.73766409037424 24.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66852079983189 139.73767016889653 24.406 35.66848589854977 139.73764734531954 24.406 35.66848589854977 139.73764734531954 27.5 35.66852079983189 139.73767016889653 27.5 35.66852079983189 139.73767016889653 24.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66848589854977 139.73764734531954 24.406 35.66845206853717 139.7377249285649 24.406 35.66845206853717 139.7377249285649 27.5 35.66848589854977 139.73764734531954 27.5 35.66848589854977 139.73764734531954 24.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66845206853717 139.7377249285649 24.406 35.668545589611085 139.73778623284826 24.406 35.668545589611085 139.73778623284826 27.5 35.66845206853717 139.7377249285649 27.5 35.66845206853717 139.7377249285649 24.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668545589611085 139.73778623284826 24.406 35.668561155039455 139.7377505356926 24.406 35.668561155039455 139.7377505356926 27.5 35.668545589611085 139.73778623284826 27.5 35.668545589611085 139.73778623284826 24.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668561155039455 139.7377505356926 24.406 35.66855267784177 139.73774513325426 24.406 35.66855267784177 139.73774513325426 27.5 35.668561155039455 139.7377505356926 27.5 35.668561155039455 139.7377505356926 24.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66855267784177 139.73774513325426 24.406 35.66857274073387 139.7376976114931 24.406 35.66857274073387 139.7376976114931 27.5 35.66855267784177 139.73774513325426 27.5 35.66855267784177 139.73774513325426 24.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66857274073387 139.7376976114931 24.406 35.66852349912268 139.73766409037424 24.406 35.66852349912268 139.73766409037424 27.5 35.66857274073387 139.7376976114931 27.5 35.66857274073387 139.7376976114931 24.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66852349912268 139.73766409037424 27.5 35.66852079983189 139.73767016889653 27.5 35.66848589854977 139.73764734531954 27.5 35.66845206853717 139.7377249285649 27.5 35.668545589611085 139.73778623284826 27.5 35.668561155039455 139.7377505356926 27.5 35.66855267784177 139.73774513325426 27.5 35.66857274073387 139.7376976114931 27.5 35.66852349912268 139.73766409037424 27.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-3416a2b8-6335-4d07-9c7c-9dfd153c30b3"/>
							<gml:surfaceMember xlink:href="#poly-93c511bc-f5fd-49dd-bbce-ea374519e232"/>
							<gml:surfaceMember xlink:href="#poly-fc4b2de2-c424-4303-bfd9-336474ca4ebe"/>
							<gml:surfaceMember xlink:href="#poly-cfbcb7ba-71d0-4256-b3f4-bb82bdb03abc"/>
							<gml:surfaceMember xlink:href="#poly-418657ad-de85-4026-a490-a7e0a9e9cdac"/>
							<gml:surfaceMember xlink:href="#poly-2d56e616-cbd9-41c0-8778-fc6fbebc8e44"/>
							<gml:surfaceMember xlink:href="#poly-03690779-f2a4-4619-a9d6-74cb51822625"/>
							<gml:surfaceMember xlink:href="#poly-d44037d8-ce72-42cb-8f39-6c3e10836430"/>
							<gml:surfaceMember xlink:href="#poly-38a558cf-140a-4f2c-bb71-90be2490447e"/>
							<gml:surfaceMember xlink:href="#poly-623e7913-f15d-4b1b-bd5e-c09c8bc50074"/>
							<gml:surfaceMember xlink:href="#poly-77d851f9-6cd1-4abb-88bc-a9750923ff64"/>
							<gml:surfaceMember xlink:href="#poly-496d5ab2-d8f2-4b94-a6a9-64a0c8a68b73"/>
							<gml:surfaceMember xlink:href="#poly-123ca714-8e03-4fed-af43-6f4199416b45"/>
							<gml:surfaceMember xlink:href="#poly-d9d3db88-e447-417d-bedb-3d0df25b7ea2"/>
							<gml:surfaceMember xlink:href="#poly-508b4a11-94a8-46e2-8de9-3adac29f47c4"/>
							<gml:surfaceMember xlink:href="#poly-773b2ab2-a8f1-4b33-8b0d-275b6175720c"/>
							<gml:surfaceMember xlink:href="#poly-2c60e6ac-12be-42ab-9ee7-2d30116d61be"/>
							<gml:surfaceMember xlink:href="#poly-76024ad5-d9d9-4c77-b944-61e98008e8d1"/>
							<gml:surfaceMember xlink:href="#poly-7ec8c957-89bd-4189-af3a-51cc7a9cd526"/>
							<gml:surfaceMember xlink:href="#poly-5b3b15f2-2cf9-4846-b49d-1008d71c47f4"/>
							<gml:surfaceMember xlink:href="#poly-921f472f-ab4e-4ba6-910f-3d5ca68f7d49"/>
							<gml:surfaceMember xlink:href="#poly-c17d49e8-e6d5-497e-a421-e3352f954ebb"/>
							<gml:surfaceMember xlink:href="#poly-a3129b06-1de3-4862-8ab7-e1ef496ef8fb"/>
							<gml:surfaceMember xlink:href="#poly-7de905ee-b338-414b-9a0c-7a18e6b0bb09"/>
							<gml:surfaceMember xlink:href="#poly-62cbd185-24e6-4482-9390-f7b28defdd5b"/>
							<gml:surfaceMember xlink:href="#poly-fbe38f36-7741-4eeb-aed1-bdbc00d59671"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-3416a2b8-6335-4d07-9c7c-9dfd153c30b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3416a2b8-6335-4d07-9c7c-9dfd153c30b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3416a2b8-6335-4d07-9c7c-9dfd153c30b3">
											<gml:posList>35.66852079983186 139.7376701688965 24.406 35.66852349912268 139.7376640903742 24.406 35.668572740733865 139.7376976114931 24.406 35.668552677841745 139.7377451332543 24.406 35.66856115503944 139.7377505356926 24.406 35.66854558961106 139.73778623284824 24.406 35.66845206853717 139.7377249285649 24.406 35.66848589854975 139.73764734531954 24.406 35.66852079983186 139.7376701688965 24.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-93c511bc-f5fd-49dd-bbce-ea374519e232">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-93c511bc-f5fd-49dd-bbce-ea374519e232">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-93c511bc-f5fd-49dd-bbce-ea374519e232">
											<gml:posList>35.66852079983186 139.7376701688965 27.862 35.66848589854975 139.73764734531954 27.862 35.668486350666704 139.73764914527771 27.862 35.66852125195725 139.7376719799016 27.862 35.66852079983186 139.7376701688965 27.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fc4b2de2-c424-4303-bfd9-336474ca4ebe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc4b2de2-c424-4303-bfd9-336474ca4ebe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc4b2de2-c424-4303-bfd9-336474ca4ebe">
											<gml:posList>35.66852079983186 139.7376701688965 27.862 35.66852125195725 139.7376719799016 27.862 35.66852394225199 139.73766592348207 27.862 35.66852349912268 139.7376640903742 27.862 35.66852079983186 139.7376701688965 27.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cfbcb7ba-71d0-4256-b3f4-bb82bdb03abc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cfbcb7ba-71d0-4256-b3f4-bb82bdb03abc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cfbcb7ba-71d0-4256-b3f4-bb82bdb03abc">
											<gml:posList>35.66852349912268 139.7376640903742 27.862 35.66852394225199 139.73766592348207 27.862 35.668571289945284 139.73769814343197 27.862 35.668572740733865 139.7376976114931 27.862 35.66852349912268 139.7376640903742 27.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-418657ad-de85-4026-a490-a7e0a9e9cdac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-418657ad-de85-4026-a490-a7e0a9e9cdac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-418657ad-de85-4026-a490-a7e0a9e9cdac">
											<gml:posList>35.66845206853717 139.7377249285649 27.862 35.6684535463583 139.7377243855491 27.862 35.668486350666704 139.73764914527771 27.862 35.66848589854975 139.73764734531954 27.862 35.66845206853717 139.7377249285649 27.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2d56e616-cbd9-41c0-8778-fc6fbebc8e44">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d56e616-cbd9-41c0-8778-fc6fbebc8e44">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d56e616-cbd9-41c0-8778-fc6fbebc8e44">
											<gml:posList>35.66855120904304 139.73774568730565 27.401 35.668571289945284 139.73769814343197 27.401 35.66852394225199 139.73766592348207 27.401 35.66852125195725 139.7376719799016 27.401 35.668486350666704 139.73764914527771 27.401 35.6684535463583 139.7377243855491 27.401 35.66854514650988 139.73778443287722 27.401 35.668559677226995 139.73775108975465 27.401 35.66855120904304 139.73774568730565 27.401</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-03690779-f2a4-4619-a9d6-74cb51822625">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03690779-f2a4-4619-a9d6-74cb51822625">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03690779-f2a4-4619-a9d6-74cb51822625">
											<gml:posList>35.668552677841745 139.7377451332543 27.862 35.668572740733865 139.7376976114931 27.862 35.668571289945284 139.73769814343197 27.862 35.66855120904304 139.73774568730565 27.862 35.668552677841745 139.7377451332543 27.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d44037d8-ce72-42cb-8f39-6c3e10836430">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d44037d8-ce72-42cb-8f39-6c3e10836430">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d44037d8-ce72-42cb-8f39-6c3e10836430">
											<gml:posList>35.668552677841745 139.7377451332543 27.862 35.66855120904304 139.73774568730565 27.862 35.668559677226995 139.73775108975465 27.862 35.66856115503944 139.7377505356926 27.862 35.668552677841745 139.7377451332543 27.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-38a558cf-140a-4f2c-bb71-90be2490447e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38a558cf-140a-4f2c-bb71-90be2490447e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38a558cf-140a-4f2c-bb71-90be2490447e">
											<gml:posList>35.66854558961106 139.73778623284824 27.862 35.66854514650988 139.73778443287722 27.862 35.6684535463583 139.7377243855491 27.862 35.66845206853717 139.7377249285649 27.862 35.66854558961106 139.73778623284824 27.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-623e7913-f15d-4b1b-bd5e-c09c8bc50074">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-623e7913-f15d-4b1b-bd5e-c09c8bc50074">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-623e7913-f15d-4b1b-bd5e-c09c8bc50074">
											<gml:posList>35.66856115503944 139.7377505356926 27.862 35.668559677226995 139.73775108975465 27.862 35.66854514650988 139.73778443287722 27.862 35.66854558961106 139.73778623284824 27.862 35.66856115503944 139.7377505356926 27.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-77d851f9-6cd1-4abb-88bc-a9750923ff64">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-77d851f9-6cd1-4abb-88bc-a9750923ff64">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-77d851f9-6cd1-4abb-88bc-a9750923ff64">
											<gml:posList>35.66852079983186 139.7376701688965 24.406 35.66848589854975 139.73764734531954 24.406 35.66848589854975 139.73764734531954 27.862 35.66852079983186 139.7376701688965 27.862 35.66852079983186 139.7376701688965 24.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-496d5ab2-d8f2-4b94-a6a9-64a0c8a68b73">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-496d5ab2-d8f2-4b94-a6a9-64a0c8a68b73">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-496d5ab2-d8f2-4b94-a6a9-64a0c8a68b73">
											<gml:posList>35.668486350666704 139.73764914527771 27.862 35.668486350666704 139.73764914527771 27.401 35.66852125195725 139.7376719799016 27.401 35.66852125195725 139.7376719799016 27.862 35.668486350666704 139.73764914527771 27.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-123ca714-8e03-4fed-af43-6f4199416b45">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-123ca714-8e03-4fed-af43-6f4199416b45">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-123ca714-8e03-4fed-af43-6f4199416b45">
											<gml:posList>35.66852349912268 139.7376640903742 24.406 35.66852079983186 139.7376701688965 24.406 35.66852079983186 139.7376701688965 27.862 35.66852349912268 139.7376640903742 27.862 35.66852349912268 139.7376640903742 24.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d9d3db88-e447-417d-bedb-3d0df25b7ea2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d9d3db88-e447-417d-bedb-3d0df25b7ea2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d9d3db88-e447-417d-bedb-3d0df25b7ea2">
											<gml:posList>35.66852125195725 139.7376719799016 27.862 35.66852125195725 139.7376719799016 27.401 35.66852394225199 139.73766592348207 27.401 35.66852394225199 139.73766592348207 27.862 35.66852125195725 139.7376719799016 27.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-508b4a11-94a8-46e2-8de9-3adac29f47c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-508b4a11-94a8-46e2-8de9-3adac29f47c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-508b4a11-94a8-46e2-8de9-3adac29f47c4">
											<gml:posList>35.668572740733865 139.7376976114931 24.406 35.66852349912268 139.7376640903742 24.406 35.66852349912268 139.7376640903742 27.862 35.668572740733865 139.7376976114931 27.862 35.668572740733865 139.7376976114931 24.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-773b2ab2-a8f1-4b33-8b0d-275b6175720c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-773b2ab2-a8f1-4b33-8b0d-275b6175720c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-773b2ab2-a8f1-4b33-8b0d-275b6175720c">
											<gml:posList>35.66852394225199 139.73766592348207 27.862 35.66852394225199 139.73766592348207 27.401 35.668571289945284 139.73769814343197 27.401 35.668571289945284 139.73769814343197 27.862 35.66852394225199 139.73766592348207 27.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2c60e6ac-12be-42ab-9ee7-2d30116d61be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c60e6ac-12be-42ab-9ee7-2d30116d61be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c60e6ac-12be-42ab-9ee7-2d30116d61be">
											<gml:posList>35.66848589854975 139.73764734531954 24.406 35.66845206853717 139.7377249285649 24.406 35.66845206853717 139.7377249285649 27.862 35.66848589854975 139.73764734531954 27.862 35.66848589854975 139.73764734531954 24.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-76024ad5-d9d9-4c77-b944-61e98008e8d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-76024ad5-d9d9-4c77-b944-61e98008e8d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-76024ad5-d9d9-4c77-b944-61e98008e8d1">
											<gml:posList>35.6684535463583 139.7377243855491 27.862 35.6684535463583 139.7377243855491 27.401 35.668486350666704 139.73764914527771 27.401 35.668486350666704 139.73764914527771 27.862 35.6684535463583 139.7377243855491 27.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7ec8c957-89bd-4189-af3a-51cc7a9cd526">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ec8c957-89bd-4189-af3a-51cc7a9cd526">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ec8c957-89bd-4189-af3a-51cc7a9cd526">
											<gml:posList>35.668552677841745 139.7377451332543 24.406 35.668572740733865 139.7376976114931 24.406 35.668572740733865 139.7376976114931 27.862 35.668552677841745 139.7377451332543 27.862 35.668552677841745 139.7377451332543 24.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5b3b15f2-2cf9-4846-b49d-1008d71c47f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b3b15f2-2cf9-4846-b49d-1008d71c47f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b3b15f2-2cf9-4846-b49d-1008d71c47f4">
											<gml:posList>35.668571289945284 139.73769814343197 27.862 35.668571289945284 139.73769814343197 27.401 35.66855120904304 139.73774568730565 27.401 35.66855120904304 139.73774568730565 27.862 35.668571289945284 139.73769814343197 27.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-921f472f-ab4e-4ba6-910f-3d5ca68f7d49">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-921f472f-ab4e-4ba6-910f-3d5ca68f7d49">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-921f472f-ab4e-4ba6-910f-3d5ca68f7d49">
											<gml:posList>35.66856115503944 139.7377505356926 24.406 35.668552677841745 139.7377451332543 24.406 35.668552677841745 139.7377451332543 27.862 35.66856115503944 139.7377505356926 27.862 35.66856115503944 139.7377505356926 24.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c17d49e8-e6d5-497e-a421-e3352f954ebb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c17d49e8-e6d5-497e-a421-e3352f954ebb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c17d49e8-e6d5-497e-a421-e3352f954ebb">
											<gml:posList>35.66855120904304 139.73774568730565 27.862 35.66855120904304 139.73774568730565 27.401 35.668559677226995 139.73775108975465 27.401 35.668559677226995 139.73775108975465 27.862 35.66855120904304 139.73774568730565 27.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a3129b06-1de3-4862-8ab7-e1ef496ef8fb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a3129b06-1de3-4862-8ab7-e1ef496ef8fb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a3129b06-1de3-4862-8ab7-e1ef496ef8fb">
											<gml:posList>35.66854514650988 139.73778443287722 27.862 35.66854514650988 139.73778443287722 27.401 35.6684535463583 139.7377243855491 27.401 35.6684535463583 139.7377243855491 27.862 35.66854514650988 139.73778443287722 27.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7de905ee-b338-414b-9a0c-7a18e6b0bb09">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7de905ee-b338-414b-9a0c-7a18e6b0bb09">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7de905ee-b338-414b-9a0c-7a18e6b0bb09">
											<gml:posList>35.66845206853717 139.7377249285649 24.406 35.66854558961106 139.73778623284824 24.406 35.66854558961106 139.73778623284824 27.862 35.66845206853717 139.7377249285649 27.862 35.66845206853717 139.7377249285649 24.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-62cbd185-24e6-4482-9390-f7b28defdd5b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-62cbd185-24e6-4482-9390-f7b28defdd5b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-62cbd185-24e6-4482-9390-f7b28defdd5b">
											<gml:posList>35.668559677226995 139.73775108975465 27.862 35.668559677226995 139.73775108975465 27.401 35.66854514650988 139.73778443287722 27.401 35.66854514650988 139.73778443287722 27.862 35.668559677226995 139.73775108975465 27.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fbe38f36-7741-4eeb-aed1-bdbc00d59671">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fbe38f36-7741-4eeb-aed1-bdbc00d59671">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fbe38f36-7741-4eeb-aed1-bdbc00d59671">
											<gml:posList>35.66854558961106 139.73778623284824 24.406 35.66856115503944 139.7377505356926 24.406 35.66856115503944 139.7377505356926 27.862 35.66854558961106 139.73778623284824 27.862 35.66854558961106 139.73778623284824 24.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区六本木二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8821</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">92.6601</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">3</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>3</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">105</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key105.xml">3</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">20</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>