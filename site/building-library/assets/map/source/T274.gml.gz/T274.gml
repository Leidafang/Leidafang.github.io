<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_4c8c3246-10aa-49c7-a6c6-3891e46806fd">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">15.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67124968969456 139.74031723754388 0 35.671169974486254 139.74023845895718 0 35.67115336366506 139.74026369709816 0 35.67114636367224 139.74025679019948 0 35.671130302043885 139.7402811992146 0 35.67121701722023 139.74036689576454 0 35.67124968969456 139.74031723754388 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67124968969456 139.74031723754388 9.58 35.67121701722023 139.74036689576454 9.58 35.671130302043885 139.7402811992146 9.58 35.67114636367224 139.74025679019948 9.58 35.67115336366506 139.74026369709816 9.58 35.671169974486254 139.74023845895718 9.58 35.67124968969456 139.74031723754388 9.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67124968969456 139.74031723754388 9.58 35.671169974486254 139.74023845895718 9.58 35.671169974486254 139.74023845895718 24.92 35.67124968969456 139.74031723754388 24.92 35.67124968969456 139.74031723754388 9.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671169974486254 139.74023845895718 9.58 35.67115336366506 139.74026369709816 9.58 35.67115336366506 139.74026369709816 24.92 35.671169974486254 139.74023845895718 24.92 35.671169974486254 139.74023845895718 9.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67115336366506 139.74026369709816 9.58 35.67114636367224 139.74025679019948 9.58 35.67114636367224 139.74025679019948 24.92 35.67115336366506 139.74026369709816 24.92 35.67115336366506 139.74026369709816 9.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67114636367224 139.74025679019948 9.58 35.671130302043885 139.7402811992146 9.58 35.671130302043885 139.7402811992146 24.92 35.67114636367224 139.74025679019948 24.92 35.67114636367224 139.74025679019948 9.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671130302043885 139.7402811992146 9.58 35.67121701722023 139.74036689576454 9.58 35.67121701722023 139.74036689576454 24.92 35.671130302043885 139.7402811992146 24.92 35.671130302043885 139.7402811992146 9.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67121701722023 139.74036689576454 9.58 35.67124968969456 139.74031723754388 9.58 35.67124968969456 139.74031723754388 24.92 35.67121701722023 139.74036689576454 24.92 35.67121701722023 139.74036689576454 9.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67124968969456 139.74031723754388 24.92 35.671169974486254 139.74023845895718 24.92 35.67115336366506 139.74026369709816 24.92 35.67114636367224 139.74025679019948 24.92 35.671130302043885 139.7402811992146 24.92 35.67121701722023 139.74036689576454 24.92 35.67124968969456 139.74031723754388 24.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-2efc1c68-903b-43b2-a4ac-9e781b094b46"/>
							<gml:surfaceMember xlink:href="#poly-3c39c88d-2d7b-4212-bf45-0d5a87c1eb49"/>
							<gml:surfaceMember xlink:href="#poly-5c4b04ee-688b-4f60-bd47-d2d2ebe0c4ea"/>
							<gml:surfaceMember xlink:href="#poly-9cb92355-37ce-41cc-8706-377fe2de221b"/>
							<gml:surfaceMember xlink:href="#poly-d5bbffb6-4e95-4c9f-9911-99054a73e049"/>
							<gml:surfaceMember xlink:href="#poly-f6226676-6709-4810-b9b7-0a8b612650d4"/>
							<gml:surfaceMember xlink:href="#poly-21ad1ee2-1409-47f8-a00f-35b8dd8a0f3a"/>
							<gml:surfaceMember xlink:href="#poly-2e5536d8-8c72-40c5-8fd5-6ed57e483ece"/>
							<gml:surfaceMember xlink:href="#poly-65ab67fb-6e30-4ece-af48-12fd046b0b94"/>
							<gml:surfaceMember xlink:href="#poly-0efbb0a1-7641-4762-b2bb-36ca205e4574"/>
							<gml:surfaceMember xlink:href="#poly-352e6851-de59-476d-b799-70966c47c795"/>
							<gml:surfaceMember xlink:href="#poly-44b15915-677b-4f8e-ae27-5a221a6b9a5e"/>
							<gml:surfaceMember xlink:href="#poly-758c6cee-67c6-4439-9b21-4bfab1bd1aae"/>
							<gml:surfaceMember xlink:href="#poly-e22a0e87-2db5-4d8b-9a36-4b8449a79455"/>
							<gml:surfaceMember xlink:href="#poly-831f0bd3-cadd-422c-a87d-6a90744740a0"/>
							<gml:surfaceMember xlink:href="#poly-032ede4a-ffcf-47b8-a752-47a6505f4df5"/>
							<gml:surfaceMember xlink:href="#poly-d57d957a-a90d-460c-9a85-c4ff7a191ec3"/>
							<gml:surfaceMember xlink:href="#poly-481bf989-db39-4127-91db-ca2fab4662db"/>
							<gml:surfaceMember xlink:href="#poly-03f6a7a9-1906-489b-abe9-24bc9d7cbe7c"/>
							<gml:surfaceMember xlink:href="#poly-cb3f27b7-712f-4dac-b88e-5e2a1c8eb8af"/>
							<gml:surfaceMember xlink:href="#poly-ffc5a838-c998-4532-aaea-f69cead95a1d"/>
							<gml:surfaceMember xlink:href="#poly-1b92c243-dd6b-4351-995d-448c4796a059"/>
							<gml:surfaceMember xlink:href="#poly-2bd28e33-d217-4eae-9615-e40928a42d6c"/>
							<gml:surfaceMember xlink:href="#poly-fc9234a3-26ad-4523-b294-6c6c1e7f99c5"/>
							<gml:surfaceMember xlink:href="#poly-4a1fe5b2-b900-4af5-aeff-0864ab692ca1"/>
							<gml:surfaceMember xlink:href="#poly-278bbfbf-cf40-4f4c-96ac-ea7b6794da33"/>
							<gml:surfaceMember xlink:href="#poly-c1e6eeef-4c96-4cdd-97bd-de0c238b784f"/>
							<gml:surfaceMember xlink:href="#poly-97e0b8c3-c0d6-4023-adf0-9a4d373677d5"/>
							<gml:surfaceMember xlink:href="#poly-434e3419-7071-42e8-9454-7f0551f1e99c"/>
							<gml:surfaceMember xlink:href="#poly-689bb5fa-4505-40d3-b66b-037240eb3ca9"/>
							<gml:surfaceMember xlink:href="#poly-667869fe-b82b-4103-a94f-725c817a72c1"/>
							<gml:surfaceMember xlink:href="#poly-b0475a6e-5d2e-4846-83d4-9f4f3534e61f"/>
							<gml:surfaceMember xlink:href="#poly-ece589f8-4558-4936-abbd-0a08d2779fa7"/>
							<gml:surfaceMember xlink:href="#poly-fa1a3695-9aa4-4508-a168-d2fbec7aea13"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_4c8c3246-10aa-49c7-a6c6-3891e46806fd_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24bbe417-47fb-42d4-a644-84abe81ab354">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671175586869694 139.7402810030538 25.117 35.671158755859864 139.7402662646422 25.117 35.67116772164086 139.74025087769058 25.117 35.67118455265256 139.74026561610063 25.117 35.671175586869694 139.7402810030538 25.117</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63938be5-51bd-41ef-99b1-9fc3e3bb0e16">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-63938be5-51bd-41ef-99b1-9fc3e3bb0e16_0">
											<gml:posList>35.67116772164086 139.74025087769058 25.117 35.67116772164086 139.74025087769058 27.343 35.67118455265256 139.74026561610063 27.343 35.67118455265256 139.74026561610063 25.117 35.67116772164086 139.74025087769058 25.117</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c9e931a5-be00-4860-96e0-319835d5b89e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c9e931a5-be00-4860-96e0-319835d5b89e_0">
											<gml:posList>35.671158755859864 139.7402662646422 25.117 35.671158755859864 139.7402662646422 27.343 35.67116772164086 139.74025087769058 27.343 35.67116772164086 139.74025087769058 25.117 35.671158755859864 139.7402662646422 25.117</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6bcecc4-3016-4f74-a31d-f6a062a7854c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d6bcecc4-3016-4f74-a31d-f6a062a7854c_0">
											<gml:posList>35.67116772164086 139.74025087769058 27.343 35.671158755859864 139.7402662646422 27.343 35.671175586869694 139.7402810030538 27.343 35.67118455265256 139.74026561610063 27.343 35.67116772164086 139.74025087769058 27.343</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0dd5d659-08ca-4cc9-9a5e-5dd304d817a3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0dd5d659-08ca-4cc9-9a5e-5dd304d817a3_0">
											<gml:posList>35.67118455265256 139.74026561610063 25.117 35.67118455265256 139.74026561610063 27.343 35.671175586869694 139.7402810030538 27.343 35.671175586869694 139.7402810030538 25.117 35.67118455265256 139.74026561610063 25.117</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b28c978-6ab4-44e3-953e-07166c5ee29e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5b28c978-6ab4-44e3-953e-07166c5ee29e_0">
											<gml:posList>35.671175586869694 139.7402810030538 25.117 35.671175586869694 139.7402810030538 27.343 35.671158755859864 139.7402662646422 27.343 35.671158755859864 139.7402662646422 25.117 35.671175586869694 139.7402810030538 25.117</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_4c8c3246-10aa-49c7-a6c6-3891e46806fd_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e1a45ba1-338f-463b-9e41-d9b5c829139a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67122038202616 139.74030034849875 25.117 35.671232911668966 139.74031273904097 25.117 35.67121977605936 139.74033270403459 25.117 35.671207237404865 139.74032031350174 25.117 35.67122038202616 139.74030034849875 25.117</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-063fdfae-3221-4d60-ba6c-26823d5ecf1d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-063fdfae-3221-4d60-ba6c-26823d5ecf1d_0">
											<gml:posList>35.67122038202616 139.74030034849875 27.11 35.671232911668966 139.74031273904097 27.11 35.671232911668966 139.74031273904097 25.117 35.67122038202616 139.74030034849875 25.117 35.67122038202616 139.74030034849875 27.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b18de3a-b98c-4247-9940-dda9276a691b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b18de3a-b98c-4247-9940-dda9276a691b_0">
											<gml:posList>35.671207237404865 139.74032031350174 25.117 35.671207237404865 139.74032031350174 27.11 35.67122038202616 139.74030034849875 27.11 35.67122038202616 139.74030034849875 25.117 35.671207237404865 139.74032031350174 25.117</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-416d99ef-1cef-46bd-b351-3650d4c719af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-416d99ef-1cef-46bd-b351-3650d4c719af_0">
											<gml:posList>35.67122038202616 139.74030034849875 27.11 35.671207237404865 139.74032031350174 27.11 35.67121977605936 139.74033270403459 27.11 35.671232911668966 139.74031273904097 27.11 35.67122038202616 139.74030034849875 27.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-781a084b-10ed-45c8-8ab8-6b23a43153ad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-781a084b-10ed-45c8-8ab8-6b23a43153ad_0">
											<gml:posList>35.671232911668966 139.74031273904097 25.117 35.671232911668966 139.74031273904097 27.11 35.67121977605936 139.74033270403459 27.11 35.67121977605936 139.74033270403459 25.117 35.671232911668966 139.74031273904097 25.117</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a8bd14fd-e438-4884-99df-1541638c5089">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a8bd14fd-e438-4884-99df-1541638c5089_0">
											<gml:posList>35.67121977605936 139.74033270403459 25.117 35.67121977605936 139.74033270403459 27.11 35.671207237404865 139.74032031350174 27.11 35.671207237404865 139.74032031350174 25.117 35.67121977605936 139.74033270403459 25.117</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-2efc1c68-903b-43b2-a4ac-9e781b094b46">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2efc1c68-903b-43b2-a4ac-9e781b094b46">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2efc1c68-903b-43b2-a4ac-9e781b094b46">
											<gml:posList>35.6712170172202 139.74036689576454 9.58 35.67113030204389 139.7402811992146 9.58 35.671146363672214 139.74025679019945 9.58 35.67115336366508 139.74026369709816 9.58 35.671169974486254 139.74023845895715 9.58 35.67124968969456 139.74031723754388 9.58 35.6712170172202 139.74036689576454 9.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3c39c88d-2d7b-4212-bf45-0d5a87c1eb49">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c39c88d-2d7b-4212-bf45-0d5a87c1eb49">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c39c88d-2d7b-4212-bf45-0d5a87c1eb49">
											<gml:posList>35.67119491650263 139.7402631075902 25.527 35.671169974486254 139.74023845895715 25.527 35.67117023823273 139.7402414964022 25.527 35.67119380911267 139.7402647879242 25.527 35.67119491650263 139.7402631075902 25.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5c4b04ee-688b-4f60-bd47-d2d2ebe0c4ea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5c4b04ee-688b-4f60-bd47-d2d2ebe0c4ea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5c4b04ee-688b-4f60-bd47-d2d2ebe0c4ea">
											<gml:posList>35.67115336366508 139.74026369709816 25.527 35.67115362740238 139.7402667234963 25.527 35.67117023823273 139.7402414964022 25.527 35.671169974486254 139.74023845895715 25.527 35.67115336366508 139.74026369709816 25.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9cb92355-37ce-41cc-8706-377fe2de221b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9cb92355-37ce-41cc-8706-377fe2de221b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9cb92355-37ce-41cc-8706-377fe2de221b">
											<gml:posList>35.67115336366508 139.74026369709816 25.527 35.671146363672214 139.74025679019945 25.527 35.67114663643194 139.7402598276332 25.527 35.67115362740238 139.7402667234963 25.527 35.67115336366508 139.74026369709816 25.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d5bbffb6-4e95-4c9f-9911-99054a73e049">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5bbffb6-4e95-4c9f-9911-99054a73e049">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5bbffb6-4e95-4c9f-9911-99054a73e049">
											<gml:posList>35.67113030204389 139.7402811992146 25.527 35.67113278056976 139.74028087599348 25.527 35.67114663643194 139.7402598276332 25.527 35.671146363672214 139.74025679019945 25.527 35.67113030204389 139.7402811992146 25.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f6226676-6709-4810-b9b7-0a8b612650d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f6226676-6709-4810-b9b7-0a8b612650d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f6226676-6709-4810-b9b7-0a8b612650d4">
											<gml:posList>35.671180871573775 139.74028444338768 27.786 35.671184044087894 139.74028403099004 27.786 35.67119526202084 139.7402669844656 27.786 35.67119491650263 139.7402631075902 27.786 35.671180871573775 139.74028444338768 27.786</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-21ad1ee2-1409-47f8-a00f-35b8dd8a0f3a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21ad1ee2-1409-47f8-a00f-35b8dd8a0f3a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21ad1ee2-1409-47f8-a00f-35b8dd8a0f3a">
											<gml:posList>35.67119491650263 139.7402631075902 27.786 35.67119526202084 139.7402669844656 27.786 35.67121956356201 139.7402909931688 27.786 35.67122272707094 139.74029059182803 27.786 35.67119491650263 139.7402631075902 27.786</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2e5536d8-8c72-40c5-8fd5-6ed57e483ece">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2e5536d8-8c72-40c5-8fd5-6ed57e483ece">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2e5536d8-8c72-40c5-8fd5-6ed57e483ece">
											<gml:posList>35.67121956356201 139.7402909931688 27.507 35.67119526202084 139.7402669844656 27.507 35.671184044087894 139.74028403099004 27.507 35.671208345625715 139.74030803969507 27.507 35.67121956356201 139.7402909931688 27.507</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-65ab67fb-6e30-4ece-af48-12fd046b0b94">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65ab67fb-6e30-4ece-af48-12fd046b0b94">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65ab67fb-6e30-4ece-af48-12fd046b0b94">
											<gml:posList>35.6712086821373 139.7403119276281 27.786 35.671208345625715 139.74030803969507 27.786 35.671184044087894 139.74028403099004 27.786 35.671180871573775 139.74028444338768 27.786 35.6712086821373 139.7403119276281 27.786</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0efbb0a1-7641-4762-b2bb-36ca205e4574">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0efbb0a1-7641-4762-b2bb-36ca205e4574">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0efbb0a1-7641-4762-b2bb-36ca205e4574">
											<gml:posList>35.67122272707094 139.74029059182803 27.786 35.67121956356201 139.7402909931688 27.786 35.671208345625715 139.74030803969507 27.786 35.6712086821373 139.7403119276281 27.786 35.67122272707094 139.74029059182803 27.786</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-352e6851-de59-476d-b799-70966c47c795">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-352e6851-de59-476d-b799-70966c47c795">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-352e6851-de59-476d-b799-70966c47c795">
											<gml:posList>35.671180871573775 139.74028444338768 25.117 35.67119380911267 139.7402647879242 25.117 35.67117023823273 139.7402414964022 25.117 35.67115362740238 139.7402667234963 25.117 35.67114663643194 139.7402598276332 25.117 35.67113278056976 139.74028087599348 25.117 35.67121674445464 139.7403638472814 25.117 35.671247202146404 139.74031754972845 25.117 35.67122161968061 139.7402922721622 25.117 35.6712086821373 139.7403119276281 25.117 35.671180871573775 139.74028444338768 25.117</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-44b15915-677b-4f8e-ae27-5a221a6b9a5e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44b15915-677b-4f8e-ae27-5a221a6b9a5e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44b15915-677b-4f8e-ae27-5a221a6b9a5e">
											<gml:posList>35.67122272707094 139.74029059182803 25.527 35.67122161968061 139.7402922721622 25.527 35.671247202146404 139.74031754972845 25.527 35.67124968969456 139.74031723754388 25.527 35.67122272707094 139.74029059182803 25.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-758c6cee-67c6-4439-9b21-4bfab1bd1aae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-758c6cee-67c6-4439-9b21-4bfab1bd1aae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-758c6cee-67c6-4439-9b21-4bfab1bd1aae">
											<gml:posList>35.6712170172202 139.74036689576454 25.527 35.67121674445464 139.7403638472814 25.527 35.67113278056976 139.74028087599348 25.527 35.67113030204389 139.7402811992146 25.527 35.6712170172202 139.74036689576454 25.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e22a0e87-2db5-4d8b-9a36-4b8449a79455">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e22a0e87-2db5-4d8b-9a36-4b8449a79455">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e22a0e87-2db5-4d8b-9a36-4b8449a79455">
											<gml:posList>35.67124968969456 139.74031723754388 25.527 35.671247202146404 139.74031754972845 25.527 35.67121674445464 139.7403638472814 25.527 35.6712170172202 139.74036689576454 25.527 35.67124968969456 139.74031723754388 25.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-831f0bd3-cadd-422c-a87d-6a90744740a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-831f0bd3-cadd-422c-a87d-6a90744740a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-831f0bd3-cadd-422c-a87d-6a90744740a0">
											<gml:posList>35.67119526202084 139.7402669844656 27.786 35.67119526202084 139.7402669844656 27.507 35.67121956356201 139.7402909931688 27.507 35.67121956356201 139.7402909931688 27.786 35.67119526202084 139.7402669844656 27.786</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-032ede4a-ffcf-47b8-a752-47a6505f4df5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-032ede4a-ffcf-47b8-a752-47a6505f4df5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-032ede4a-ffcf-47b8-a752-47a6505f4df5">
											<gml:posList>35.671208345625715 139.74030803969507 27.786 35.671208345625715 139.74030803969507 27.507 35.671184044087894 139.74028403099004 27.507 35.671184044087894 139.74028403099004 27.786 35.671208345625715 139.74030803969507 27.786</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d57d957a-a90d-460c-9a85-c4ff7a191ec3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d57d957a-a90d-460c-9a85-c4ff7a191ec3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d57d957a-a90d-460c-9a85-c4ff7a191ec3">
											<gml:posList>35.671146363672214 139.74025679019945 9.58 35.67113030204389 139.7402811992146 9.58 35.67113030204389 139.7402811992146 25.527 35.671146363672214 139.74025679019945 25.527 35.671146363672214 139.74025679019945 9.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-481bf989-db39-4127-91db-ca2fab4662db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-481bf989-db39-4127-91db-ca2fab4662db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-481bf989-db39-4127-91db-ca2fab4662db">
											<gml:posList>35.67113278056976 139.74028087599348 25.527 35.67113278056976 139.74028087599348 25.117 35.67114663643194 139.7402598276332 25.117 35.67114663643194 139.7402598276332 25.527 35.67113278056976 139.74028087599348 25.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-03f6a7a9-1906-489b-abe9-24bc9d7cbe7c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03f6a7a9-1906-489b-abe9-24bc9d7cbe7c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03f6a7a9-1906-489b-abe9-24bc9d7cbe7c">
											<gml:posList>35.67115336366508 139.74026369709816 9.58 35.671146363672214 139.74025679019945 9.58 35.671146363672214 139.74025679019945 25.527 35.67115336366508 139.74026369709816 25.527 35.67115336366508 139.74026369709816 9.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cb3f27b7-712f-4dac-b88e-5e2a1c8eb8af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb3f27b7-712f-4dac-b88e-5e2a1c8eb8af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb3f27b7-712f-4dac-b88e-5e2a1c8eb8af">
											<gml:posList>35.67114663643194 139.7402598276332 25.527 35.67114663643194 139.7402598276332 25.117 35.67115362740238 139.7402667234963 25.117 35.67115362740238 139.7402667234963 25.527 35.67114663643194 139.7402598276332 25.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ffc5a838-c998-4532-aaea-f69cead95a1d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ffc5a838-c998-4532-aaea-f69cead95a1d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ffc5a838-c998-4532-aaea-f69cead95a1d">
											<gml:posList>35.671169974486254 139.74023845895715 9.58 35.67115336366508 139.74026369709816 9.58 35.67115336366508 139.74026369709816 25.527 35.671169974486254 139.74023845895715 25.527 35.671169974486254 139.74023845895715 9.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b92c243-dd6b-4351-995d-448c4796a059">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b92c243-dd6b-4351-995d-448c4796a059">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b92c243-dd6b-4351-995d-448c4796a059">
											<gml:posList>35.67115362740238 139.7402667234963 25.527 35.67115362740238 139.7402667234963 25.117 35.67117023823273 139.7402414964022 25.117 35.67117023823273 139.7402414964022 25.527 35.67115362740238 139.7402667234963 25.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2bd28e33-d217-4eae-9615-e40928a42d6c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2bd28e33-d217-4eae-9615-e40928a42d6c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2bd28e33-d217-4eae-9615-e40928a42d6c">
											<gml:posList>35.67113030204389 139.7402811992146 9.58 35.6712170172202 139.74036689576454 9.58 35.6712170172202 139.74036689576454 25.527 35.67113030204389 139.7402811992146 25.527 35.67113030204389 139.7402811992146 9.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fc9234a3-26ad-4523-b294-6c6c1e7f99c5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc9234a3-26ad-4523-b294-6c6c1e7f99c5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc9234a3-26ad-4523-b294-6c6c1e7f99c5">
											<gml:posList>35.67121674445464 139.7403638472814 25.527 35.67121674445464 139.7403638472814 25.117 35.67113278056976 139.74028087599348 25.117 35.67113278056976 139.74028087599348 25.527 35.67121674445464 139.7403638472814 25.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4a1fe5b2-b900-4af5-aeff-0864ab692ca1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a1fe5b2-b900-4af5-aeff-0864ab692ca1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a1fe5b2-b900-4af5-aeff-0864ab692ca1">
											<gml:posList>35.67117023823273 139.7402414964022 25.527 35.67117023823273 139.7402414964022 25.117 35.67119380911267 139.7402647879242 25.117 35.67119380911267 139.7402647879242 25.527 35.67117023823273 139.7402414964022 25.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-278bbfbf-cf40-4f4c-96ac-ea7b6794da33">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-278bbfbf-cf40-4f4c-96ac-ea7b6794da33">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-278bbfbf-cf40-4f4c-96ac-ea7b6794da33">
											<gml:posList>35.671180871573775 139.74028444338768 25.117 35.671180871573775 139.74028444338768 27.786 35.67119491650263 139.7402631075902 27.786 35.67119491650263 139.7402631075902 25.527 35.67119380911267 139.7402647879242 25.527 35.67119380911267 139.7402647879242 25.117 35.671180871573775 139.74028444338768 25.117</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c1e6eeef-4c96-4cdd-97bd-de0c238b784f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c1e6eeef-4c96-4cdd-97bd-de0c238b784f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c1e6eeef-4c96-4cdd-97bd-de0c238b784f">
											<gml:posList>35.671184044087894 139.74028403099004 27.786 35.671184044087894 139.74028403099004 27.507 35.67119526202084 139.7402669844656 27.507 35.67119526202084 139.7402669844656 27.786 35.671184044087894 139.74028403099004 27.786</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-97e0b8c3-c0d6-4023-adf0-9a4d373677d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-97e0b8c3-c0d6-4023-adf0-9a4d373677d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-97e0b8c3-c0d6-4023-adf0-9a4d373677d5">
											<gml:posList>35.671180871573775 139.74028444338768 25.117 35.6712086821373 139.7403119276281 25.117 35.6712086821373 139.7403119276281 27.786 35.671180871573775 139.74028444338768 27.786 35.671180871573775 139.74028444338768 25.117</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-434e3419-7071-42e8-9454-7f0551f1e99c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-434e3419-7071-42e8-9454-7f0551f1e99c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-434e3419-7071-42e8-9454-7f0551f1e99c">
											<gml:posList>35.67119491650263 139.7402631075902 25.527 35.67119491650263 139.7402631075902 27.786 35.67122272707094 139.74029059182803 27.786 35.67122272707094 139.74029059182803 25.527 35.67124968969456 139.74031723754388 25.527 35.67124968969456 139.74031723754388 9.58 35.671169974486254 139.74023845895715 9.58 35.671169974486254 139.74023845895715 25.527 35.67119491650263 139.7402631075902 25.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-689bb5fa-4505-40d3-b66b-037240eb3ca9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-689bb5fa-4505-40d3-b66b-037240eb3ca9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-689bb5fa-4505-40d3-b66b-037240eb3ca9">
											<gml:posList>35.67121956356201 139.7402909931688 27.786 35.67121956356201 139.7402909931688 27.507 35.671208345625715 139.74030803969507 27.507 35.671208345625715 139.74030803969507 27.786 35.67121956356201 139.7402909931688 27.786</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-667869fe-b82b-4103-a94f-725c817a72c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-667869fe-b82b-4103-a94f-725c817a72c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-667869fe-b82b-4103-a94f-725c817a72c1">
											<gml:posList>35.67122272707094 139.74029059182803 27.786 35.6712086821373 139.7403119276281 27.786 35.6712086821373 139.7403119276281 25.117 35.67122161968061 139.7402922721622 25.117 35.67122161968061 139.7402922721622 25.527 35.67122272707094 139.74029059182803 25.527 35.67122272707094 139.74029059182803 27.786</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b0475a6e-5d2e-4846-83d4-9f4f3534e61f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b0475a6e-5d2e-4846-83d4-9f4f3534e61f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b0475a6e-5d2e-4846-83d4-9f4f3534e61f">
											<gml:posList>35.671247202146404 139.74031754972845 25.527 35.671247202146404 139.74031754972845 25.117 35.67121674445464 139.7403638472814 25.117 35.67121674445464 139.7403638472814 25.527 35.671247202146404 139.74031754972845 25.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ece589f8-4558-4936-abbd-0a08d2779fa7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ece589f8-4558-4936-abbd-0a08d2779fa7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ece589f8-4558-4936-abbd-0a08d2779fa7">
											<gml:posList>35.6712170172202 139.74036689576454 9.58 35.67124968969456 139.74031723754388 9.58 35.67124968969456 139.74031723754388 25.527 35.6712170172202 139.74036689576454 25.527 35.6712170172202 139.74036689576454 9.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fa1a3695-9aa4-4508-a168-d2fbec7aea13">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa1a3695-9aa4-4508-a168-d2fbec7aea13">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa1a3695-9aa4-4508-a168-d2fbec7aea13">
											<gml:posList>35.67122161968061 139.7402922721622 25.527 35.67122161968061 139.7402922721622 25.117 35.671247202146404 139.74031754972845 25.117 35.671247202146404 139.74031754972845 25.527 35.67122161968061 139.7402922721622 25.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-3502</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">64.0378</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.05</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>