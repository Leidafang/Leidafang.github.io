<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_4ec2c617-22e0-4863-9450-7115478705ab">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">3.7</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66793070756197 139.7421321661282 0 35.66792178012402 139.7421270951585 0 35.66791160585946 139.74215385994833 0 35.66793588160073 139.74216808158448 0 35.667963984279886 139.74209384309756 0 35.66795894343053 139.7420909768926 0 35.667969396470205 139.7420633722712 0 35.66795899013353 139.7420574524539 0 35.66793070756197 139.7421321661282 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66793070756197 139.7421321661282 28.745 35.66795899013353 139.7420574524539 28.745 35.667969396470205 139.7420633722712 28.745 35.66795894343053 139.7420909768926 28.745 35.667963984279886 139.74209384309756 28.745 35.66793588160073 139.74216808158448 28.745 35.66791160585946 139.74215385994833 28.745 35.66792178012402 139.7421270951585 28.745 35.66793070756197 139.7421321661282 28.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66793070756197 139.7421321661282 28.745 35.66792178012402 139.7421270951585 28.745 35.66792178012402 139.7421270951585 32.45 35.66793070756197 139.7421321661282 32.45 35.66793070756197 139.7421321661282 28.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66792178012402 139.7421270951585 28.745 35.66791160585946 139.74215385994833 28.745 35.66791160585946 139.74215385994833 32.45 35.66792178012402 139.7421270951585 32.45 35.66792178012402 139.7421270951585 28.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66791160585946 139.74215385994833 28.745 35.66793588160073 139.74216808158448 28.745 35.66793588160073 139.74216808158448 32.45 35.66791160585946 139.74215385994833 32.45 35.66791160585946 139.74215385994833 28.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66793588160073 139.74216808158448 28.745 35.667963984279886 139.74209384309756 28.745 35.667963984279886 139.74209384309756 32.45 35.66793588160073 139.74216808158448 32.45 35.66793588160073 139.74216808158448 28.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667963984279886 139.74209384309756 28.745 35.66795894343053 139.7420909768926 28.745 35.66795894343053 139.7420909768926 32.45 35.667963984279886 139.74209384309756 32.45 35.667963984279886 139.74209384309756 28.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66795894343053 139.7420909768926 28.745 35.667969396470205 139.7420633722712 28.745 35.667969396470205 139.7420633722712 32.45 35.66795894343053 139.7420909768926 32.45 35.66795894343053 139.7420909768926 28.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667969396470205 139.7420633722712 28.745 35.66795899013353 139.7420574524539 28.745 35.66795899013353 139.7420574524539 32.45 35.667969396470205 139.7420633722712 32.45 35.667969396470205 139.7420633722712 28.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66795899013353 139.7420574524539 28.745 35.66793070756197 139.7421321661282 28.745 35.66793070756197 139.7421321661282 32.45 35.66795899013353 139.7420574524539 32.45 35.66795899013353 139.7420574524539 28.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66793070756197 139.7421321661282 32.45 35.66792178012402 139.7421270951585 32.45 35.66791160585946 139.74215385994833 32.45 35.66793588160073 139.74216808158448 32.45 35.667963984279886 139.74209384309756 32.45 35.66795894343053 139.7420909768926 32.45 35.667969396470205 139.7420633722712 32.45 35.66795899013353 139.7420574524539 32.45 35.66793070756197 139.7421321661282 32.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-f49cfea9-e5fc-435f-8fcb-94459f7b7196"/>
							<gml:surfaceMember xlink:href="#poly-74f679be-99f4-4622-a611-063274f940a3"/>
							<gml:surfaceMember xlink:href="#poly-8362157c-c498-4aef-86a1-79a7b35f0ed9"/>
							<gml:surfaceMember xlink:href="#poly-fb23ba51-e4fe-45e9-8c52-5f5b09dd5d4e"/>
							<gml:surfaceMember xlink:href="#poly-3bcdd5b1-7ef9-4bdf-a0cb-727a61eb1b97"/>
							<gml:surfaceMember xlink:href="#poly-8fc7e950-2ccc-481b-acb7-3f565fb0273a"/>
							<gml:surfaceMember xlink:href="#poly-c6f7a5bd-c817-4e85-912a-1e101bb16bae"/>
							<gml:surfaceMember xlink:href="#poly-e3a866aa-a477-4a5a-8f68-ed1c5030334a"/>
							<gml:surfaceMember xlink:href="#poly-dcabbdeb-5873-46e6-b4d8-d252bdafb298"/>
							<gml:surfaceMember xlink:href="#poly-9dbb9236-459e-4619-972c-3ff7f636cd30"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-f49cfea9-e5fc-435f-8fcb-94459f7b7196">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f49cfea9-e5fc-435f-8fcb-94459f7b7196">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f49cfea9-e5fc-435f-8fcb-94459f7b7196">
											<gml:posList>35.66795894343053 139.7420909768926 28.745 35.66796398427987 139.74209384309754 28.745 35.66793588160071 139.74216808158445 28.745 35.66791160585946 139.74215385994833 28.745 35.667921780124004 139.7421270951585 28.745 35.667930707561986 139.7421321661282 28.745 35.667958990133506 139.74205745245388 28.745 35.66796939647021 139.7420633722712 28.745 35.66795894343053 139.7420909768926 28.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-74f679be-99f4-4622-a611-063274f940a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74f679be-99f4-4622-a611-063274f940a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74f679be-99f4-4622-a611-063274f940a3">
											<gml:posList>35.66795894343053 139.7420909768926 32.2 35.66796939647021 139.7420633722712 32.2 35.667958990133506 139.74205745245388 32.2 35.667930707561986 139.7421321661282 32.2 35.667921780124004 139.7421270951585 32.2 35.66791160585946 139.74215385994833 32.2 35.66793588160071 139.74216808158445 32.2 35.66796398427987 139.74209384309754 32.2 35.66795894343053 139.7420909768926 32.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8362157c-c498-4aef-86a1-79a7b35f0ed9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8362157c-c498-4aef-86a1-79a7b35f0ed9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8362157c-c498-4aef-86a1-79a7b35f0ed9">
											<gml:posList>35.66796939647021 139.7420633722712 28.745 35.667958990133506 139.74205745245388 28.745 35.667958990133506 139.74205745245388 32.2 35.66796939647021 139.7420633722712 32.2 35.66796939647021 139.7420633722712 28.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fb23ba51-e4fe-45e9-8c52-5f5b09dd5d4e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb23ba51-e4fe-45e9-8c52-5f5b09dd5d4e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb23ba51-e4fe-45e9-8c52-5f5b09dd5d4e">
											<gml:posList>35.66795894343053 139.7420909768926 28.745 35.66796939647021 139.7420633722712 28.745 35.66796939647021 139.7420633722712 32.2 35.66795894343053 139.7420909768926 32.2 35.66795894343053 139.7420909768926 28.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3bcdd5b1-7ef9-4bdf-a0cb-727a61eb1b97">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3bcdd5b1-7ef9-4bdf-a0cb-727a61eb1b97">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3bcdd5b1-7ef9-4bdf-a0cb-727a61eb1b97">
											<gml:posList>35.66796398427987 139.74209384309754 28.745 35.66795894343053 139.7420909768926 28.745 35.66795894343053 139.7420909768926 32.2 35.66796398427987 139.74209384309754 32.2 35.66796398427987 139.74209384309754 28.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8fc7e950-2ccc-481b-acb7-3f565fb0273a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8fc7e950-2ccc-481b-acb7-3f565fb0273a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8fc7e950-2ccc-481b-acb7-3f565fb0273a">
											<gml:posList>35.667958990133506 139.74205745245388 28.745 35.667930707561986 139.7421321661282 28.745 35.667930707561986 139.7421321661282 32.2 35.667958990133506 139.74205745245388 32.2 35.667958990133506 139.74205745245388 28.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c6f7a5bd-c817-4e85-912a-1e101bb16bae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6f7a5bd-c817-4e85-912a-1e101bb16bae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6f7a5bd-c817-4e85-912a-1e101bb16bae">
											<gml:posList>35.667930707561986 139.7421321661282 28.745 35.667921780124004 139.7421270951585 28.745 35.667921780124004 139.7421270951585 32.2 35.667930707561986 139.7421321661282 32.2 35.667930707561986 139.7421321661282 28.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e3a866aa-a477-4a5a-8f68-ed1c5030334a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e3a866aa-a477-4a5a-8f68-ed1c5030334a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e3a866aa-a477-4a5a-8f68-ed1c5030334a">
											<gml:posList>35.66793588160071 139.74216808158445 28.745 35.66796398427987 139.74209384309754 28.745 35.66796398427987 139.74209384309754 32.2 35.66793588160071 139.74216808158445 32.2 35.66793588160071 139.74216808158445 28.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dcabbdeb-5873-46e6-b4d8-d252bdafb298">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dcabbdeb-5873-46e6-b4d8-d252bdafb298">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dcabbdeb-5873-46e6-b4d8-d252bdafb298">
											<gml:posList>35.667921780124004 139.7421270951585 28.745 35.66791160585946 139.74215385994833 28.745 35.66791160585946 139.74215385994833 32.2 35.667921780124004 139.7421270951585 32.2 35.667921780124004 139.7421270951585 28.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9dbb9236-459e-4619-972c-3ff7f636cd30">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9dbb9236-459e-4619-972c-3ff7f636cd30">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9dbb9236-459e-4619-972c-3ff7f636cd30">
											<gml:posList>35.66791160585946 139.74215385994833 28.745 35.66793588160071 139.74216808158445 28.745 35.66793588160071 139.74216808158445 32.2 35.66791160585946 139.74215385994833 32.2 35.66791160585946 139.74215385994833 28.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-248</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">6</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.04</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>