<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_4f13a092-68c8-4cef-80c9-39b2a0923dc7">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門駅南地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">27.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66847607976871 139.74937710169516 0 35.66852816148617 139.7492226240107 0 35.66845061757519 139.74918570127147 0 35.66843694672836 139.74922868452933 0 35.668425315161905 139.74922317373424 0 35.668397506639 139.74931190218138 0 35.668414683439785 139.7493199808927 0 35.6683992961066 139.7493703998555 0 35.66844391084872 139.74939160562934 0 35.66847607976871 139.74937710169516 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66847607976871 139.74937710169516 5.14 35.66844391084872 139.74939160562934 5.14 35.6683992961066 139.7493703998555 5.14 35.668414683439785 139.7493199808927 5.14 35.668397506639 139.74931190218138 5.14 35.668425315161905 139.74922317373424 5.14 35.66843694672836 139.74922868452933 5.14 35.66845061757519 139.74918570127147 5.14 35.66852816148617 139.7492226240107 5.14 35.66847607976871 139.74937710169516 5.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66847607976871 139.74937710169516 5.14 35.66852816148617 139.7492226240107 5.14 35.66852816148617 139.7492226240107 30.7 35.66847607976871 139.74937710169516 30.7 35.66847607976871 139.74937710169516 5.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66852816148617 139.7492226240107 5.14 35.66845061757519 139.74918570127147 5.14 35.66845061757519 139.74918570127147 30.7 35.66852816148617 139.7492226240107 30.7 35.66852816148617 139.7492226240107 5.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66845061757519 139.74918570127147 5.14 35.66843694672836 139.74922868452933 5.14 35.66843694672836 139.74922868452933 30.7 35.66845061757519 139.74918570127147 30.7 35.66845061757519 139.74918570127147 5.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66843694672836 139.74922868452933 5.14 35.668425315161905 139.74922317373424 5.14 35.668425315161905 139.74922317373424 30.7 35.66843694672836 139.74922868452933 30.7 35.66843694672836 139.74922868452933 5.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668425315161905 139.74922317373424 5.14 35.668397506639 139.74931190218138 5.14 35.668397506639 139.74931190218138 30.7 35.668425315161905 139.74922317373424 30.7 35.668425315161905 139.74922317373424 5.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668397506639 139.74931190218138 5.14 35.668414683439785 139.7493199808927 5.14 35.668414683439785 139.7493199808927 30.7 35.668397506639 139.74931190218138 30.7 35.668397506639 139.74931190218138 5.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668414683439785 139.7493199808927 5.14 35.6683992961066 139.7493703998555 5.14 35.6683992961066 139.7493703998555 30.7 35.668414683439785 139.7493199808927 30.7 35.668414683439785 139.7493199808927 5.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6683992961066 139.7493703998555 5.14 35.66844391084872 139.74939160562934 5.14 35.66844391084872 139.74939160562934 30.7 35.6683992961066 139.7493703998555 30.7 35.6683992961066 139.7493703998555 5.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66844391084872 139.74939160562934 5.14 35.66847607976871 139.74937710169516 5.14 35.66847607976871 139.74937710169516 30.7 35.66844391084872 139.74939160562934 30.7 35.66844391084872 139.74939160562934 5.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66847607976871 139.74937710169516 30.7 35.66852816148617 139.7492226240107 30.7 35.66845061757519 139.74918570127147 30.7 35.66843694672836 139.74922868452933 30.7 35.668425315161905 139.74922317373424 30.7 35.668397506639 139.74931190218138 30.7 35.668414683439785 139.7493199808927 30.7 35.6683992961066 139.7493703998555 30.7 35.66844391084872 139.74939160562934 30.7 35.66847607976871 139.74937710169516 30.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-e11ce2b5-3c38-4d94-8fec-0cc1212246e2"/>
							<gml:surfaceMember xlink:href="#poly-a605d64d-659e-43c6-8013-485bc3188d00"/>
							<gml:surfaceMember xlink:href="#poly-b9ea97d9-8f3b-47e7-9b9c-414cb1f70bec"/>
							<gml:surfaceMember xlink:href="#poly-72c0edf5-38d7-4e52-a6c8-650584d7c3ab"/>
							<gml:surfaceMember xlink:href="#poly-b58df5e7-1587-4191-84c8-dbd80f218c35"/>
							<gml:surfaceMember xlink:href="#poly-98821ad5-df42-46f4-99d1-5554d1b176ca"/>
							<gml:surfaceMember xlink:href="#poly-8b83d3b3-82d1-4f78-984f-feae83599f7c"/>
							<gml:surfaceMember xlink:href="#poly-fa129a04-c906-4ed1-a619-0e2ee198da21"/>
							<gml:surfaceMember xlink:href="#poly-4f6ebabd-29ee-4885-b972-8ecce159876a"/>
							<gml:surfaceMember xlink:href="#poly-46d7b200-9d1f-4571-9690-eafcb58a69f6"/>
							<gml:surfaceMember xlink:href="#poly-788f3f23-23a3-417d-83ea-78bcd0297409"/>
							<gml:surfaceMember xlink:href="#poly-7642d9d8-61ce-47d8-ba40-882324edc45e"/>
							<gml:surfaceMember xlink:href="#poly-c387b262-0e0f-4ad8-ab4b-02b68b7eb72b"/>
							<gml:surfaceMember xlink:href="#poly-f8a57e24-2651-4f84-961d-e25b1cda5ce2"/>
							<gml:surfaceMember xlink:href="#poly-0dc021e6-23ba-40ee-b927-79e0474e7352"/>
							<gml:surfaceMember xlink:href="#poly-9cd6c59e-63b9-4ddf-bf8a-47bb5322ee73"/>
							<gml:surfaceMember xlink:href="#poly-23dcdb38-c195-462d-b649-a03ea9b9480b"/>
							<gml:surfaceMember xlink:href="#poly-df21cf0a-0158-43bc-a1df-e4f918f3eb16"/>
							<gml:surfaceMember xlink:href="#poly-5cf55c80-f141-4c90-a1e1-bed161f0d71c"/>
							<gml:surfaceMember xlink:href="#poly-47bec8ee-d7d4-4b37-95e6-d2e409504e60"/>
							<gml:surfaceMember xlink:href="#poly-b3c9f61b-ed0e-4b77-871d-3b3875d8df26"/>
							<gml:surfaceMember xlink:href="#poly-b822896d-2fa3-44e9-a30f-308fe8a7cd75"/>
							<gml:surfaceMember xlink:href="#poly-63e16182-2803-423d-8e8a-7c1cb9bccbe3"/>
							<gml:surfaceMember xlink:href="#poly-a259d7eb-42db-40c5-93df-8203e93966ac"/>
							<gml:surfaceMember xlink:href="#poly-5a2f9e9d-1209-45b0-ba95-c3d23be08580"/>
							<gml:surfaceMember xlink:href="#poly-83475e81-073e-4104-8868-3cb714520d56"/>
							<gml:surfaceMember xlink:href="#poly-c8eb7611-8b8f-46e7-bf9d-735e4b9e0d1d"/>
							<gml:surfaceMember xlink:href="#poly-75cc94b0-5da9-43d1-ba58-670db32a6dc5"/>
							<gml:surfaceMember xlink:href="#poly-09447cf2-db27-4d4a-bf20-beaa1a38743a"/>
							<gml:surfaceMember xlink:href="#poly-d6ebe436-7d90-4c3b-aacd-192747d09060"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_4f13a092-68c8-4cef-80c9-39b2a0923dc7_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7d0c0a3-28c6-473d-a599-828947df74e7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66842170243208 139.7493031836329 30.687 35.66840756424322 139.7492965156263 30.687 35.668412942502506 139.7492793887062 30.687 35.668427080700006 139.7492860677562 30.687 35.66842170243208 139.7493031836329 30.687</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4f407d7b-f390-40df-9aa0-57161f982230">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6684236325133 139.7492660781273 30.687 35.66843207863334 139.74924061930673 30.687 35.668448516390235 139.74924880924118 30.687 35.66844007928221 139.74927426805667 30.687 35.6684236325133 139.7492660781273 30.687</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e988e6d-89bd-4cbc-af08-10e6668197eb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3e988e6d-89bd-4cbc-af08-10e6668197eb_0">
											<gml:posList>35.668448516390235 139.74924880924118 30.687 35.66843207863334 139.74924061930673 30.687 35.66843207863334 139.74924061930673 33.457 35.668448516390235 139.74924880924118 33.457 35.668448516390235 139.74924880924118 30.687</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fd3358b7-b7af-4ad0-9c13-6488d4c39700">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fd3358b7-b7af-4ad0-9c13-6488d4c39700_0">
											<gml:posList>35.66843207863334 139.74924061930673 30.687 35.6684236325133 139.7492660781273 30.687 35.6684236325133 139.7492660781273 33.457 35.66843207863334 139.74924061930673 33.457 35.66843207863334 139.74924061930673 30.687</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd1d1e89-50ef-486d-a8fa-9f9cc026e83b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dd1d1e89-50ef-486d-a8fa-9f9cc026e83b_0">
											<gml:posList>35.668448516390235 139.74924880924118 33.457 35.66843207863334 139.74924061930673 33.457 35.6684236325133 139.7492660781273 33.457 35.66844007928221 139.74927426805667 33.457 35.668448516390235 139.74924880924118 33.457</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-876d239c-5b8b-4113-9856-81ee73fb2f7a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-876d239c-5b8b-4113-9856-81ee73fb2f7a_0">
											<gml:posList>35.66844007928221 139.74927426805667 30.687 35.668448516390235 139.74924880924118 30.687 35.668448516390235 139.74924880924118 33.457 35.66844007928221 139.74927426805667 33.457 35.66844007928221 139.74927426805667 30.687</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-317225c3-893a-499e-ba14-95e8e181fe80">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-317225c3-893a-499e-ba14-95e8e181fe80_0">
											<gml:posList>35.66844007928221 139.74927426805667 30.687 35.66844007928221 139.74927426805667 33.457 35.6684236325133 139.7492660781273 33.457 35.6684236325133 139.7492660781273 30.687 35.66844007928221 139.74927426805667 30.687</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-457ad85e-e0b6-4c43-9919-8364c1d89124">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-457ad85e-e0b6-4c43-9919-8364c1d89124_0">
											<gml:posList>35.668427080700006 139.7492860677562 30.687 35.668412942502506 139.7492793887062 30.687 35.668412942502506 139.7492793887062 37.362 35.668427080700006 139.7492860677562 37.362 35.668427080700006 139.7492860677562 30.687</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef7da84e-6b57-4a5e-a64a-7d245829aaec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef7da84e-6b57-4a5e-a64a-7d245829aaec_0">
											<gml:posList>35.668412942502506 139.7492793887062 30.687 35.66840756424322 139.7492965156263 30.687 35.66840756424322 139.7492965156263 37.362 35.668412942502506 139.7492793887062 37.362 35.668412942502506 139.7492793887062 30.687</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3cbe0836-3537-4537-9c02-3c0a528422ad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3cbe0836-3537-4537-9c02-3c0a528422ad_0">
											<gml:posList>35.668412942502506 139.7492793887062 37.362 35.66840756424322 139.7492965156263 37.362 35.66842170243208 139.7493031836329 37.362 35.668427080700006 139.7492860677562 37.362 35.668412942502506 139.7492793887062 37.362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7e00117-3184-4fa9-9b01-4cfa45774bca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f7e00117-3184-4fa9-9b01-4cfa45774bca_0">
											<gml:posList>35.66842170243208 139.7493031836329 30.687 35.668427080700006 139.7492860677562 30.687 35.668427080700006 139.7492860677562 37.362 35.66842170243208 139.7493031836329 37.362 35.66842170243208 139.7493031836329 30.687</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11779073-97aa-418d-ae6c-0cc9c411e96c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-11779073-97aa-418d-ae6c-0cc9c411e96c_0">
											<gml:posList>35.66842170243208 139.7493031836329 30.687 35.66842170243208 139.7493031836329 37.362 35.66840756424322 139.7492965156263 37.362 35.66840756424322 139.7492965156263 30.687 35.66842170243208 139.7493031836329 30.687</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_4f13a092-68c8-4cef-80c9-39b2a0923dc7_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-969b7f03-f24a-48b9-88c9-e7fdddd82240">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66838178562405 139.7493620674267 5.14 35.66839750663899 139.74931190218138 5.14 35.668414683439764 139.7493199808927 5.14 35.66839929610658 139.74937039985548 5.14 35.66838178562405 139.7493620674267 5.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-488b9784-3c73-467a-bd59-fc6d77f9049d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-488b9784-3c73-467a-bd59-fc6d77f9049d_0">
											<gml:posList>35.668414683439764 139.7493199808927 30.5 35.668414683439764 139.7493199808927 5.14 35.66839750663899 139.74931190218138 5.14 35.66839750663899 139.74931190218138 30.5 35.668414683439764 139.7493199808927 30.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a59f4e29-35ba-4dd4-a28c-d9410f988c93">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a59f4e29-35ba-4dd4-a28c-d9410f988c93_0">
											<gml:posList>35.668412839833266 139.74932601393448 30.5 35.668414683439764 139.7493199808927 30.5 35.66839750663899 139.74931190218138 30.5 35.668395635953175 139.74931788002047 30.5 35.66840349852101 139.7493215942801 30.5 35.668412839833266 139.74932601393448 30.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ef28775-185d-4a4f-a156-915ff6746dc1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9ef28775-185d-4a4f-a156-915ff6746dc1_0">
											<gml:posList>35.66840349852101 139.7493215942801 30.5 35.668395635953175 139.74931788002047 30.5 35.668395635953175 139.74931788002047 23.866 35.66840349852101 139.7493215942801 23.866 35.66840349852101 139.7493215942801 30.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5cb2f579-519a-4613-96f7-f979342653da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5cb2f579-519a-4613-96f7-f979342653da_0">
											<gml:posList>35.66838178562405 139.7493620674267 27.357 35.668382954812756 139.7493583437053 27.357 35.668395635953175 139.74931788002047 23.866 35.668395635953175 139.74931788002047 30.5 35.66839750663899 139.74931190218138 30.5 35.66839750663899 139.74931190218138 5.14 35.66838178562405 139.7493620674267 5.14 35.66838178562405 139.7493620674267 27.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9c917604-b3ea-4a94-987e-ffcada97b33d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9c917604-b3ea-4a94-987e-ffcada97b33d_0">
											<gml:posList>35.66840349852101 139.7493215942801 23.866 35.668395635953175 139.74931788002047 23.866 35.668382954812756 139.7493583437053 27.357 35.66839113289064 139.7493621018218 27.357 35.66840349852101 139.7493215942801 23.866</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04d0292b-0348-43f4-ab06-63b136e8f611">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-04d0292b-0348-43f4-ab06-63b136e8f611_0">
											<gml:posList>35.66839113289064 139.7493621018218 27.357 35.66840349852101 139.7493215942801 30.5 35.66840349852101 139.7493215942801 23.866 35.66839113289064 139.7493621018218 27.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e987091-c61d-458d-9c50-26697f75736c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9e987091-c61d-458d-9c50-26697f75736c_0">
											<gml:posList>35.66839113289064 139.7493621018218 27.357 35.668400519185354 139.74936639992725 27.357 35.668412839833266 139.74932601393448 30.5 35.66840349852101 139.7493215942801 30.5 35.66839113289064 139.7493621018218 27.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84d1ba19-9236-4dec-8029-f62d52c2b968">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-84d1ba19-9236-4dec-8029-f62d52c2b968_0">
											<gml:posList>35.66839929610658 139.74937039985548 27.357 35.66839929610658 139.74937039985548 5.14 35.668414683439764 139.7493199808927 5.14 35.668414683439764 139.7493199808927 30.5 35.668412839833266 139.74932601393448 30.5 35.668400519185354 139.74936639992725 27.357 35.66839929610658 139.74937039985548 27.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0fccf036-b04c-49a2-9de3-4a7aa0d0819c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0fccf036-b04c-49a2-9de3-4a7aa0d0819c_0">
											<gml:posList>35.668382954812756 139.7493583437053 27.357 35.66838178562405 139.7493620674267 27.357 35.66839929610658 139.74937039985548 27.357 35.668400519185354 139.74936639992725 27.357 35.66839113289064 139.7493621018218 27.357 35.668382954812756 139.7493583437053 27.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01144c5f-4d67-41a4-a5f7-2cff78bde30c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01144c5f-4d67-41a4-a5f7-2cff78bde30c_0">
											<gml:posList>35.66838178562405 139.7493620674267 27.357 35.66838178562405 139.7493620674267 5.14 35.66839929610658 139.74937039985548 5.14 35.66839929610658 139.74937039985548 27.357 35.66838178562405 139.7493620674267 27.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-e11ce2b5-3c38-4d94-8fec-0cc1212246e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e11ce2b5-3c38-4d94-8fec-0cc1212246e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e11ce2b5-3c38-4d94-8fec-0cc1212246e2">
											<gml:posList>35.668414683439764 139.7493199808927 5.14 35.66839750663899 139.74931190218138 5.14 35.66842531516188 139.74922317373424 5.14 35.668436946728356 139.7492286845293 5.14 35.66845061757517 139.74918570127144 5.14 35.66852816148617 139.7492226240107 5.14 35.6684760797687 139.74937710169516 5.14 35.668443910848694 139.74939160562934 5.14 35.66839929610658 139.74937039985548 5.14 35.668414683439764 139.7493199808927 5.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a605d64d-659e-43c6-8013-485bc3188d00">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a605d64d-659e-43c6-8013-485bc3188d00">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a605d64d-659e-43c6-8013-485bc3188d00">
											<gml:posList>35.66845061757517 139.74918570127144 30.5 35.668436946728356 139.7492286845293 37.362 35.66846339276319 139.7492412160876 37.362 35.66851377077756 139.74921576849238 30.5 35.66845061757517 139.74918570127144 30.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b9ea97d9-8f3b-47e7-9b9c-414cb1f70bec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b9ea97d9-8f3b-47e7-9b9c-414cb1f70bec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b9ea97d9-8f3b-47e7-9b9c-414cb1f70bec">
											<gml:posList>35.6684276090696 139.74922950068097 37.362 35.66842531516188 139.74922317373424 37.362 35.6683988826717 139.7493075044365 37.362 35.66840403658932 139.74930472649262 37.362 35.6684276090696 139.74922950068097 37.362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-72c0edf5-38d7-4e52-a6c8-650584d7c3ab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-72c0edf5-38d7-4e52-a6c8-650584d7c3ab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-72c0edf5-38d7-4e52-a6c8-650584d7c3ab">
											<gml:posList>35.668458229848795 139.74924401613907 30.687 35.6684276090696 139.74922950068097 30.687 35.66840403658932 139.74930472649262 30.687 35.66843441414309 139.74931946314987 30.687 35.668458229848795 139.74924401613907 30.687</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b58df5e7-1587-4191-84c8-dbd80f218c35">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b58df5e7-1587-4191-84c8-dbd80f218c35">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b58df5e7-1587-4191-84c8-dbd80f218c35">
											<gml:posList>35.6683988826717 139.7493075044365 37.362 35.668421713176386 139.74931858173235 37.362 35.668436690056815 139.74932584534892 37.362 35.66846339276319 139.7492412160876 37.362 35.668436946728356 139.7492286845293 37.362 35.66842531516188 139.74922317373424 37.362 35.6684276090696 139.74922950068097 37.362 35.668458229848795 139.74924401613907 37.362 35.66843441414309 139.74931946314987 37.362 35.66840403658932 139.74930472649262 37.362 35.6683988826717 139.7493075044365 37.362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-98821ad5-df42-46f4-99d1-5554d1b176ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-98821ad5-df42-46f4-99d1-5554d1b176ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-98821ad5-df42-46f4-99d1-5554d1b176ca">
											<gml:posList>35.66846339276319 139.7492412160876 37.362 35.668436690056815 139.74932584534892 37.362 35.668460373769996 139.74938418757753 30.5 35.66851377077756 139.74921576849238 30.5 35.66846339276319 139.7492412160876 37.362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8b83d3b3-82d1-4f78-984f-feae83599f7c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b83d3b3-82d1-4f78-984f-feae83599f7c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b83d3b3-82d1-4f78-984f-feae83599f7c">
											<gml:posList>35.66851377077756 139.74921576849238 28.1 35.668460373769996 139.74938418757753 28.1 35.6684760797687 139.74937710169516 28.1 35.66852816148617 139.7492226240107 28.1 35.66851377077756 139.74921576849238 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fa129a04-c906-4ed1-a619-0e2ee198da21">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa129a04-c906-4ed1-a619-0e2ee198da21">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa129a04-c906-4ed1-a619-0e2ee198da21">
											<gml:posList>35.668421713176386 139.74931858173235 30.362 35.6683988826717 139.7493075044365 30.362 35.66839750663899 139.74931190218138 30.362 35.668414683439764 139.7493199808927 30.362 35.66840176023752 139.74936232265816 30.362 35.668406421960086 139.7493646484798 30.362 35.668421713176386 139.74931858173235 30.362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4f6ebabd-29ee-4885-b972-8ecce159876a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f6ebabd-29ee-4885-b972-8ecce159876a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f6ebabd-29ee-4885-b972-8ecce159876a">
											<gml:posList>35.668436690056815 139.74932584534892 37.362 35.668421713176386 139.74931858173235 37.362 35.668406421960086 139.7493646484798 30.5 35.66845261537611 139.74938767518867 30.5 35.668436690056815 139.74932584534892 37.362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-46d7b200-9d1f-4571-9690-eafcb58a69f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-46d7b200-9d1f-4571-9690-eafcb58a69f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-46d7b200-9d1f-4571-9690-eafcb58a69f6">
											<gml:posList>35.668436690056815 139.74932584534892 37.362 35.66845261537611 139.74938767518867 30.5 35.668460373769996 139.74938418757753 30.5 35.668436690056815 139.74932584534892 37.362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-788f3f23-23a3-417d-83ea-78bcd0297409">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-788f3f23-23a3-417d-83ea-78bcd0297409">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-788f3f23-23a3-417d-83ea-78bcd0297409">
											<gml:posList>35.668443910848694 139.74939160562934 28.1 35.66845261537611 139.74938767518867 28.1 35.66840176023752 139.74936232265816 28.1 35.66839929610658 139.74937039985548 28.1 35.668443910848694 139.74939160562934 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7642d9d8-61ce-47d8-ba40-882324edc45e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7642d9d8-61ce-47d8-ba40-882324edc45e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7642d9d8-61ce-47d8-ba40-882324edc45e">
											<gml:posList>35.668414683439764 139.7493199808927 30.362 35.66839750663899 139.74931190218138 30.362 35.66839750663899 139.74931190218138 5.14 35.668414683439764 139.7493199808927 5.14 35.668414683439764 139.7493199808927 30.362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c387b262-0e0f-4ad8-ab4b-02b68b7eb72b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c387b262-0e0f-4ad8-ab4b-02b68b7eb72b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c387b262-0e0f-4ad8-ab4b-02b68b7eb72b">
											<gml:posList>35.66839929610658 139.74937039985548 5.14 35.66839929610658 139.74937039985548 28.1 35.66840176023752 139.74936232265816 28.1 35.66840176023752 139.74936232265816 30.362 35.668414683439764 139.7493199808927 30.362 35.668414683439764 139.7493199808927 5.14 35.66839929610658 139.74937039985548 5.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f8a57e24-2651-4f84-961d-e25b1cda5ce2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f8a57e24-2651-4f84-961d-e25b1cda5ce2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f8a57e24-2651-4f84-961d-e25b1cda5ce2">
											<gml:posList>35.6683988826717 139.7493075044365 37.362 35.6683988826717 139.7493075044365 30.362 35.668421713176386 139.74931858173235 30.362 35.6683988826717 139.7493075044365 37.362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0dc021e6-23ba-40ee-b927-79e0474e7352">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0dc021e6-23ba-40ee-b927-79e0474e7352">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0dc021e6-23ba-40ee-b927-79e0474e7352">
											<gml:posList>35.6683988826717 139.7493075044365 37.362 35.668421713176386 139.74931858173235 30.362 35.668421713176386 139.74931858173235 37.362 35.6683988826717 139.7493075044365 37.362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9cd6c59e-63b9-4ddf-bf8a-47bb5322ee73">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9cd6c59e-63b9-4ddf-bf8a-47bb5322ee73">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9cd6c59e-63b9-4ddf-bf8a-47bb5322ee73">
											<gml:posList>35.6683988826717 139.7493075044365 30.362 35.6683988826717 139.7493075044365 37.362 35.66842531516188 139.74922317373424 37.362 35.66842531516188 139.74922317373424 5.14 35.66839750663899 139.74931190218138 5.14 35.66839750663899 139.74931190218138 30.362 35.6683988826717 139.7493075044365 30.362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-23dcdb38-c195-462d-b649-a03ea9b9480b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-23dcdb38-c195-462d-b649-a03ea9b9480b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-23dcdb38-c195-462d-b649-a03ea9b9480b">
											<gml:posList>35.668406421960086 139.7493646484798 30.5 35.668421713176386 139.74931858173235 37.362 35.668421713176386 139.74931858173235 30.362 35.668406421960086 139.7493646484798 30.362 35.668406421960086 139.7493646484798 30.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-df21cf0a-0158-43bc-a1df-e4f918f3eb16">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df21cf0a-0158-43bc-a1df-e4f918f3eb16">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df21cf0a-0158-43bc-a1df-e4f918f3eb16">
											<gml:posList>35.66840403658932 139.74930472649262 37.362 35.66840403658932 139.74930472649262 30.687 35.6684276090696 139.74922950068097 30.687 35.6684276090696 139.74922950068097 37.362 35.66840403658932 139.74930472649262 37.362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5cf55c80-f141-4c90-a1e1-bed161f0d71c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5cf55c80-f141-4c90-a1e1-bed161f0d71c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5cf55c80-f141-4c90-a1e1-bed161f0d71c">
											<gml:posList>35.66843441414309 139.74931946314987 37.362 35.66843441414309 139.74931946314987 30.687 35.66840403658932 139.74930472649262 30.687 35.66840403658932 139.74930472649262 37.362 35.66843441414309 139.74931946314987 37.362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-47bec8ee-d7d4-4b37-95e6-d2e409504e60">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47bec8ee-d7d4-4b37-95e6-d2e409504e60">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47bec8ee-d7d4-4b37-95e6-d2e409504e60">
											<gml:posList>35.66839929610658 139.74937039985548 5.14 35.668443910848694 139.74939160562934 5.14 35.668443910848694 139.74939160562934 28.1 35.66839929610658 139.74937039985548 28.1 35.66839929610658 139.74937039985548 5.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b3c9f61b-ed0e-4b77-871d-3b3875d8df26">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b3c9f61b-ed0e-4b77-871d-3b3875d8df26">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b3c9f61b-ed0e-4b77-871d-3b3875d8df26">
											<gml:posList>35.66845261537611 139.74938767518867 28.1 35.66845261537611 139.74938767518867 30.5 35.668406421960086 139.7493646484798 30.5 35.668406421960086 139.7493646484798 30.362 35.66840176023752 139.74936232265816 30.362 35.66840176023752 139.74936232265816 28.1 35.66845261537611 139.74938767518867 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b822896d-2fa3-44e9-a30f-308fe8a7cd75">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b822896d-2fa3-44e9-a30f-308fe8a7cd75">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b822896d-2fa3-44e9-a30f-308fe8a7cd75">
											<gml:posList>35.668436946728356 139.7492286845293 37.362 35.66842531516188 139.74922317373424 5.14 35.66842531516188 139.74922317373424 37.362 35.668436946728356 139.7492286845293 37.362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-63e16182-2803-423d-8e8a-7c1cb9bccbe3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-63e16182-2803-423d-8e8a-7c1cb9bccbe3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-63e16182-2803-423d-8e8a-7c1cb9bccbe3">
											<gml:posList>35.668436946728356 139.7492286845293 37.362 35.668436946728356 139.7492286845293 5.14 35.66842531516188 139.74922317373424 5.14 35.668436946728356 139.7492286845293 37.362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a259d7eb-42db-40c5-93df-8203e93966ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a259d7eb-42db-40c5-93df-8203e93966ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a259d7eb-42db-40c5-93df-8203e93966ac">
											<gml:posList>35.6684276090696 139.74922950068097 37.362 35.6684276090696 139.74922950068097 30.687 35.668458229848795 139.74924401613907 30.687 35.668458229848795 139.74924401613907 37.362 35.6684276090696 139.74922950068097 37.362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5a2f9e9d-1209-45b0-ba95-c3d23be08580">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a2f9e9d-1209-45b0-ba95-c3d23be08580">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a2f9e9d-1209-45b0-ba95-c3d23be08580">
											<gml:posList>35.66845061757517 139.74918570127144 30.5 35.66845061757517 139.74918570127144 5.14 35.668436946728356 139.7492286845293 5.14 35.668436946728356 139.7492286845293 37.362 35.66845061757517 139.74918570127144 30.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-83475e81-073e-4104-8868-3cb714520d56">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83475e81-073e-4104-8868-3cb714520d56">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83475e81-073e-4104-8868-3cb714520d56">
											<gml:posList>35.668458229848795 139.74924401613907 37.362 35.668458229848795 139.74924401613907 30.687 35.66843441414309 139.74931946314987 30.687 35.66843441414309 139.74931946314987 37.362 35.668458229848795 139.74924401613907 37.362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c8eb7611-8b8f-46e7-bf9d-735e4b9e0d1d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8eb7611-8b8f-46e7-bf9d-735e4b9e0d1d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8eb7611-8b8f-46e7-bf9d-735e4b9e0d1d">
											<gml:posList>35.668460373769996 139.74938418757753 28.1 35.668460373769996 139.74938418757753 30.5 35.66845261537611 139.74938767518867 30.5 35.66845261537611 139.74938767518867 28.1 35.668443910848694 139.74939160562934 28.1 35.668443910848694 139.74939160562934 5.14 35.6684760797687 139.74937710169516 5.14 35.6684760797687 139.74937710169516 28.1 35.668460373769996 139.74938418757753 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-75cc94b0-5da9-43d1-ba58-670db32a6dc5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-75cc94b0-5da9-43d1-ba58-670db32a6dc5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-75cc94b0-5da9-43d1-ba58-670db32a6dc5">
											<gml:posList>35.66851377077756 139.74921576849238 28.1 35.66851377077756 139.74921576849238 30.5 35.668460373769996 139.74938418757753 30.5 35.668460373769996 139.74938418757753 28.1 35.66851377077756 139.74921576849238 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-09447cf2-db27-4d4a-bf20-beaa1a38743a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-09447cf2-db27-4d4a-bf20-beaa1a38743a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-09447cf2-db27-4d4a-bf20-beaa1a38743a">
											<gml:posList>35.66845061757517 139.74918570127144 5.14 35.66845061757517 139.74918570127144 30.5 35.66851377077756 139.74921576849238 30.5 35.66851377077756 139.74921576849238 28.1 35.66852816148617 139.7492226240107 28.1 35.66852816148617 139.7492226240107 5.14 35.66845061757517 139.74918570127144 5.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d6ebe436-7d90-4c3b-aacd-192747d09060">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d6ebe436-7d90-4c3b-aacd-192747d09060">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d6ebe436-7d90-4c3b-aacd-192747d09060">
											<gml:posList>35.6684760797687 139.74937710169516 5.14 35.66852816148617 139.7492226240107 5.14 35.66852816148617 139.7492226240107 28.1 35.6684760797687 139.74937710169516 28.1 35.6684760797687 139.74937710169516 5.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-292</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">174.38805</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.2</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>