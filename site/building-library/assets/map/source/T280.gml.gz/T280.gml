<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_4f36b243-4221-4f2d-974c-63d9f4c47503">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">14.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67222716155843 139.73824657226825 0 35.67219787541343 139.73814321167222 0 35.6721386759706 139.73816946216945 0 35.6721698558465 139.73827392510398 0 35.67222716155843 139.73824657226825 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67222716155843 139.73824657226825 9.587 35.6721698558465 139.73827392510398 9.587 35.6721386759706 139.73816946216945 9.587 35.67219787541343 139.73814321167222 9.587 35.67222716155843 139.73824657226825 9.587</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67222716155843 139.73824657226825 9.587 35.67219787541343 139.73814321167222 9.587 35.67219787541343 139.73814321167222 24.24 35.67222716155843 139.73824657226825 24.24 35.67222716155843 139.73824657226825 9.587</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67219787541343 139.73814321167222 9.587 35.6721386759706 139.73816946216945 9.587 35.6721386759706 139.73816946216945 24.24 35.67219787541343 139.73814321167222 24.24 35.67219787541343 139.73814321167222 9.587</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6721386759706 139.73816946216945 9.587 35.6721698558465 139.73827392510398 9.587 35.6721698558465 139.73827392510398 24.24 35.6721386759706 139.73816946216945 24.24 35.6721386759706 139.73816946216945 9.587</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6721698558465 139.73827392510398 9.587 35.67222716155843 139.73824657226825 9.587 35.67222716155843 139.73824657226825 24.24 35.6721698558465 139.73827392510398 24.24 35.6721698558465 139.73827392510398 9.587</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67222716155843 139.73824657226825 24.24 35.67219787541343 139.73814321167222 24.24 35.6721386759706 139.73816946216945 24.24 35.6721698558465 139.73827392510398 24.24 35.67222716155843 139.73824657226825 24.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-7b157a25-7f79-4ebd-8ebd-eb14a457c173"/>
							<gml:surfaceMember xlink:href="#poly-27c3c2e1-34e0-4772-aaca-95ba99fb20c7"/>
							<gml:surfaceMember xlink:href="#poly-8ac74f6f-c709-48c8-8ace-26fab37c7c09"/>
							<gml:surfaceMember xlink:href="#poly-953b6bf6-a915-4b85-a99c-eacd1f639dd9"/>
							<gml:surfaceMember xlink:href="#poly-a63aac7e-1e00-4819-a62e-2ca4695d4e2e"/>
							<gml:surfaceMember xlink:href="#poly-294b5570-6d07-4db1-b7a1-c84a3afbb9c0"/>
							<gml:surfaceMember xlink:href="#poly-8f2e2e95-b559-4e60-b618-aacc42f2c75b"/>
							<gml:surfaceMember xlink:href="#poly-0cdd820c-4d9e-4604-8b6e-cedf32a14f1e"/>
							<gml:surfaceMember xlink:href="#poly-7884a4f3-485d-455d-b7a0-ebc4fa2fe139"/>
							<gml:surfaceMember xlink:href="#poly-ce5bee6c-fae0-45f9-a8cc-adebbd429e8d"/>
							<gml:surfaceMember xlink:href="#poly-787d7393-bdd2-49b6-a144-32056cd3b60c"/>
							<gml:surfaceMember xlink:href="#poly-1e7597c1-d599-4fed-bf58-f1cbad09cb96"/>
							<gml:surfaceMember xlink:href="#poly-57cc7a68-0fa5-4955-bc7b-70a4e032aba5"/>
							<gml:surfaceMember xlink:href="#poly-9cf3de6f-a466-4b62-8a01-67d36e82621c"/>
							<gml:surfaceMember xlink:href="#poly-3e54ce6e-b03a-435e-8018-71c9d119427c"/>
							<gml:surfaceMember xlink:href="#poly-84de82ee-1f16-4a58-a113-3724d238ced6"/>
							<gml:surfaceMember xlink:href="#poly-7ec93944-00c9-409d-8ff5-199da0ab6422"/>
							<gml:surfaceMember xlink:href="#poly-c6626cad-73fe-43d4-8ceb-dec96748fcaf"/>
							<gml:surfaceMember xlink:href="#poly-bb34152a-41fd-4fa4-b3f5-f3c65652b5b2"/>
							<gml:surfaceMember xlink:href="#poly-c87627c2-6820-4afc-a603-64fb321590b3"/>
							<gml:surfaceMember xlink:href="#poly-d25e5aa0-0a12-4c5d-8650-75ad068570f0"/>
							<gml:surfaceMember xlink:href="#poly-900d13b3-a59c-4e9f-bf7f-38d18714f85c"/>
							<gml:surfaceMember xlink:href="#poly-770c5d82-e279-4bb1-a2d0-8cfecfd4ba6d"/>
							<gml:surfaceMember xlink:href="#poly-06c34dc6-1a70-489b-bc5c-5fefabc4219f"/>
							<gml:surfaceMember xlink:href="#poly-47bfc102-c550-4fb0-9011-06bcebabb32f"/>
							<gml:surfaceMember xlink:href="#poly-6dfb472d-36a4-40d4-a13e-d75de145a7a0"/>
							<gml:surfaceMember xlink:href="#poly-f9326b2c-ae08-47e1-9540-6ed6aee98161"/>
							<gml:surfaceMember xlink:href="#poly-2148bb44-9c94-4b25-b1b1-481965c45fb3"/>
							<gml:surfaceMember xlink:href="#poly-3c6b2dec-bcbe-466a-91c4-af14e955a82e"/>
							<gml:surfaceMember xlink:href="#poly-74ecbfff-c05f-4ca2-bfba-5e71ab05849a"/>
							<gml:surfaceMember xlink:href="#poly-8413be89-efc9-4359-97e1-12133896d96b"/>
							<gml:surfaceMember xlink:href="#poly-f4d16112-a465-43f1-948e-673751890cba"/>
							<gml:surfaceMember xlink:href="#poly-aef70bfe-b0cd-438c-a8a9-ca07a7a01e2c"/>
							<gml:surfaceMember xlink:href="#poly-4303a1e3-ed5c-46aa-87b4-18a01acaa467"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_4f36b243-4221-4f2d-974c-63d9f4c47503_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f3cf80c-5663-4747-bbef-caf934776906">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6721686796788 139.73817708178365 24.407 35.672179258049006 139.73817234132318 24.407 35.67218466256047 139.7381904401346 24.407 35.67217408418955 139.73819518059298 24.407 35.6721686796788 139.73817708178365 24.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d17edc47-641e-4bea-944b-aaf64cf6b95b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672159204748816 139.73822081509354 28.684 35.67215583370461 139.7382095185193 28.684 35.67216395220342 139.73820588563314 28.684 35.672167323239236 139.73821717116186 28.684 35.672159204748816 139.73822081509354 28.684</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-72593f5d-1e32-4900-9920-dec3b9aebdf1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-72593f5d-1e32-4900-9920-dec3b9aebdf1_0">
											<gml:posList>35.67215583370461 139.7382095185193 28.684 35.672159204748816 139.73822081509354 28.684 35.672159204748816 139.73822081509354 33.151 35.67215583370461 139.7382095185193 33.151 35.67215583370461 139.7382095185193 28.684</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6fee67c3-b656-45fc-9845-f7bce1186d5a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6fee67c3-b656-45fc-9845-f7bce1186d5a_0">
											<gml:posList>35.67215583370461 139.7382095185193 33.151 35.67216395220342 139.73820588563314 33.151 35.67216395220342 139.73820588563314 28.684 35.67215583370461 139.7382095185193 28.684 35.67215583370461 139.7382095185193 33.151</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-95e27fef-1e85-46da-8709-5cef52d2386a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-95e27fef-1e85-46da-8709-5cef52d2386a_0">
											<gml:posList>35.67216395220342 139.73820588563314 33.151 35.67215583370461 139.7382095185193 33.151 35.672159204748816 139.73822081509354 33.151 35.672167323239236 139.73821717116186 33.151 35.67216395220342 139.73820588563314 33.151</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-54f33377-e39a-4e3c-9214-c0cfff3ca297">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-54f33377-e39a-4e3c-9214-c0cfff3ca297_0">
											<gml:posList>35.672159204748816 139.73822081509354 28.684 35.672167323239236 139.73821717116186 28.684 35.672167323239236 139.73821717116186 33.151 35.672159204748816 139.73822081509354 33.151 35.672159204748816 139.73822081509354 28.684</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77aef9f9-0c6a-470e-89cb-c7c3c9d57576">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77aef9f9-0c6a-470e-89cb-c7c3c9d57576_0">
											<gml:posList>35.672167323239236 139.73821717116186 28.684 35.67216395220342 139.73820588563314 28.684 35.67216395220342 139.73820588563314 33.151 35.672167323239236 139.73821717116186 33.151 35.672167323239236 139.73821717116186 28.684</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19794997-21fe-4981-9e7c-b22d2ce3f18e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19794997-21fe-4981-9e7c-b22d2ce3f18e_0">
											<gml:posList>35.67217408418955 139.73819518059298 24.407 35.67217408418955 139.73819518059298 26.789 35.6721686796788 139.73817708178365 26.789 35.6721686796788 139.73817708178365 24.407 35.67217408418955 139.73819518059298 24.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7cf89b58-d227-4e34-abce-5d569349ee91">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7cf89b58-d227-4e34-abce-5d569349ee91_0">
											<gml:posList>35.672179258049006 139.73817234132318 24.407 35.6721686796788 139.73817708178365 24.407 35.6721686796788 139.73817708178365 26.789 35.672179258049006 139.73817234132318 26.789 35.672179258049006 139.73817234132318 24.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b8d25f7-bc0e-4d6b-8232-d252922612b5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b8d25f7-bc0e-4d6b-8232-d252922612b5_0">
											<gml:posList>35.6721686796788 139.73817708178365 26.789 35.67217408418955 139.73819518059298 26.789 35.67218466256047 139.7381904401346 26.789 35.672179258049006 139.73817234132318 26.789 35.6721686796788 139.73817708178365 26.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd86720a-6082-4b8e-8073-44d725034c00">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bd86720a-6082-4b8e-8073-44d725034c00_0">
											<gml:posList>35.67217408418955 139.73819518059298 24.407 35.67218466256047 139.7381904401346 24.407 35.67218466256047 139.7381904401346 26.789 35.67217408418955 139.73819518059298 26.789 35.67217408418955 139.73819518059298 24.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0229a9f2-6b6e-43e8-8c2d-c086261ce68f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0229a9f2-6b6e-43e8-8c2d-c086261ce68f_0">
											<gml:posList>35.67218466256047 139.7381904401346 24.407 35.672179258049006 139.73817234132318 24.407 35.672179258049006 139.73817234132318 26.789 35.67218466256047 139.7381904401346 26.789 35.67218466256047 139.7381904401346 24.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-7b157a25-7f79-4ebd-8ebd-eb14a457c173">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b157a25-7f79-4ebd-8ebd-eb14a457c173">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b157a25-7f79-4ebd-8ebd-eb14a457c173">
											<gml:posList>35.67222716155845 139.73824657226822 9.587 35.67216985584648 139.73827392510395 9.587 35.6721386759706 139.73816946216942 9.587 35.672197875413396 139.73814321167222 9.587 35.67222716155845 139.73824657226822 9.587</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-27c3c2e1-34e0-4772-aaca-95ba99fb20c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-27c3c2e1-34e0-4772-aaca-95ba99fb20c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-27c3c2e1-34e0-4772-aaca-95ba99fb20c7">
											<gml:posList>35.67215011821077 139.7381971090313 24.537 35.67214251756115 139.7381716669099 24.537 35.6721386759706 139.73816946216942 24.537 35.6721483281811 139.7382017948726 24.537 35.672151139466635 139.7382005322354 24.537 35.67215011821077 139.7381971090313 24.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8ac74f6f-c709-48c8-8ace-26fab37c7c09">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ac74f6f-c709-48c8-8ace-26fab37c7c09">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ac74f6f-c709-48c8-8ace-26fab37c7c09">
											<gml:posList>35.672157573692424 139.73823276934598 28.828 35.67215903088749 139.73822893448045 28.828 35.672151475383004 139.7382035806717 28.828 35.6721483281811 139.7382017948726 28.828 35.672157573692424 139.73823276934598 28.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-953b6bf6-a915-4b85-a99c-eacd1f639dd9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-953b6bf6-a915-4b85-a99c-eacd1f639dd9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-953b6bf6-a915-4b85-a99c-eacd1f639dd9">
											<gml:posList>35.6721483281811 139.7382017948726 28.828 35.672151475383004 139.7382035806717 28.828 35.672165369616074 139.73819733395635 28.828 35.67216682681002 139.73819349908982 28.828 35.6721483281811 139.7382017948726 28.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a63aac7e-1e00-4819-a62e-2ca4695d4e2e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a63aac7e-1e00-4819-a62e-2ca4695d4e2e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a63aac7e-1e00-4819-a62e-2ca4695d4e2e">
											<gml:posList>35.6721386759706 139.73816946216942 24.537 35.67214251756115 139.7381716669099 24.537 35.67218064128466 139.73815476468826 24.537 35.672182449322456 139.73815005672958 24.537 35.6721386759706 139.73816946216942 24.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-294b5570-6d07-4db1-b7a1-c84a3afbb9c0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-294b5570-6d07-4db1-b7a1-c84a3afbb9c0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-294b5570-6d07-4db1-b7a1-c84a3afbb9c0">
											<gml:posList>35.6721665396084 139.73825212323445 24.537 35.672160393992 139.738231506699 24.537 35.672157573692424 139.73823276934598 24.537 35.67216476765637 139.73825687533312 24.537 35.6721665396084 139.73825212323445 24.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8f2e2e95-b559-4e60-b618-aacc42f2c75b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f2e2e95-b559-4e60-b618-aacc42f2c75b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f2e2e95-b559-4e60-b618-aacc42f2c75b">
											<gml:posList>35.67217292512187 139.7382226877689 28.684 35.672165369616074 139.73819733395635 28.684 35.672151475383004 139.7382035806717 28.684 35.67215903088749 139.73822893448045 28.684 35.67217292512187 139.7382226877689 28.684</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0cdd820c-4d9e-4604-8b6e-cedf32a14f1e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0cdd820c-4d9e-4604-8b6e-cedf32a14f1e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0cdd820c-4d9e-4604-8b6e-cedf32a14f1e">
											<gml:posList>35.67217607232347 139.73822447356937 28.828 35.67217292512187 139.7382226877689 28.828 35.67215903088749 139.73822893448045 28.828 35.672157573692424 139.73823276934598 28.828 35.67217607232347 139.73822447356937 28.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7884a4f3-485d-455d-b7a0-ebc4fa2fe139">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7884a4f3-485d-455d-b7a0-ebc4fa2fe139">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7884a4f3-485d-455d-b7a0-ebc4fa2fe139">
											<gml:posList>35.67216682681002 139.73819349908982 28.828 35.672165369616074 139.73819733395635 28.828 35.67217292512187 139.7382226877689 28.828 35.67217607232347 139.73822447356937 28.828 35.67216682681002 139.73819349908982 28.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ce5bee6c-fae0-45f9-a8cc-adebbd429e8d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce5bee6c-fae0-45f9-a8cc-adebbd429e8d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce5bee6c-fae0-45f9-a8cc-adebbd429e8d">
											<gml:posList>35.67217607232347 139.73822447356937 24.407 35.672160393992 139.738231506699 24.407 35.6721665396084 139.73825212323445 24.407 35.67220413985816 139.73823434899253 24.407 35.67218064128466 139.73815476468826 24.407 35.67214251756115 139.7381716669099 24.407 35.67215011821077 139.7381971090313 24.407 35.672151139466635 139.7382005322354 24.407 35.67216682681002 139.73819349908982 24.407 35.67217607232347 139.73822447356937 24.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-787d7393-bdd2-49b6-a144-32056cd3b60c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-787d7393-bdd2-49b6-a144-32056cd3b60c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-787d7393-bdd2-49b6-a144-32056cd3b60c">
											<gml:posList>35.67220795433653 139.73823646539802 24.537 35.67220413985816 139.73823434899253 24.537 35.6721665396084 139.73825212323445 24.537 35.67216476765637 139.73825687533312 24.537 35.67220795433653 139.73823646539802 24.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1e7597c1-d599-4fed-bf58-f1cbad09cb96">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e7597c1-d599-4fed-bf58-f1cbad09cb96">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e7597c1-d599-4fed-bf58-f1cbad09cb96">
											<gml:posList>35.672182449322456 139.73815005672958 24.537 35.67218064128466 139.73815476468826 24.537 35.67220413985816 139.73823434899253 24.537 35.67220795433653 139.73823646539802 24.537 35.672182449322456 139.73815005672958 24.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-57cc7a68-0fa5-4955-bc7b-70a4e032aba5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-57cc7a68-0fa5-4955-bc7b-70a4e032aba5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-57cc7a68-0fa5-4955-bc7b-70a4e032aba5">
											<gml:posList>35.672197875413396 139.73814321167222 22.471 35.672182449322456 139.73815005672958 24.412 35.67220795433653 139.73823646539802 24.412 35.672197875413396 139.73814321167222 22.471</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9cf3de6f-a466-4b62-8a01-67d36e82621c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9cf3de6f-a466-4b62-8a01-67d36e82621c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9cf3de6f-a466-4b62-8a01-67d36e82621c">
											<gml:posList>35.67220795433653 139.73823646539802 24.412 35.67216476765637 139.73825687533312 24.412 35.67216985584648 139.73827392510395 22.471 35.67222716155845 139.73824657226822 22.471 35.67220795433653 139.73823646539802 24.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3e54ce6e-b03a-435e-8018-71c9d119427c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e54ce6e-b03a-435e-8018-71c9d119427c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e54ce6e-b03a-435e-8018-71c9d119427c">
											<gml:posList>35.67220795433653 139.73823646539802 24.412 35.67222716155845 139.73824657226822 22.471 35.672197875413396 139.73814321167222 22.471 35.67220795433653 139.73823646539802 24.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-84de82ee-1f16-4a58-a113-3724d238ced6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84de82ee-1f16-4a58-a113-3724d238ced6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84de82ee-1f16-4a58-a113-3724d238ced6">
											<gml:posList>35.672165369616074 139.73819733395635 28.828 35.672165369616074 139.73819733395635 28.684 35.67217292512187 139.7382226877689 28.684 35.67217292512187 139.7382226877689 28.828 35.672165369616074 139.73819733395635 28.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7ec93944-00c9-409d-8ff5-199da0ab6422">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ec93944-00c9-409d-8ff5-199da0ab6422">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ec93944-00c9-409d-8ff5-199da0ab6422">
											<gml:posList>35.67215011821077 139.7381971090313 24.537 35.67215011821077 139.7381971090313 24.407 35.67214251756115 139.7381716669099 24.407 35.67214251756115 139.7381716669099 24.537 35.67215011821077 139.7381971090313 24.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c6626cad-73fe-43d4-8ceb-dec96748fcaf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6626cad-73fe-43d4-8ceb-dec96748fcaf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6626cad-73fe-43d4-8ceb-dec96748fcaf">
											<gml:posList>35.672151139466635 139.7382005322354 24.537 35.672151139466635 139.7382005322354 24.407 35.67215011821077 139.7381971090313 24.407 35.67215011821077 139.7381971090313 24.537 35.672151139466635 139.7382005322354 24.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bb34152a-41fd-4fa4-b3f5-f3c65652b5b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb34152a-41fd-4fa4-b3f5-f3c65652b5b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb34152a-41fd-4fa4-b3f5-f3c65652b5b2">
											<gml:posList>35.67216985584648 139.73827392510395 9.587 35.67216985584648 139.73827392510395 22.471 35.67216476765637 139.73825687533312 24.412 35.67216476765637 139.73825687533312 24.537 35.672157573692424 139.73823276934598 24.537 35.672157573692424 139.73823276934598 28.828 35.6721483281811 139.7382017948726 28.828 35.6721483281811 139.7382017948726 24.537 35.6721386759706 139.73816946216942 24.537 35.6721386759706 139.73816946216942 9.587 35.67216985584648 139.73827392510395 9.587</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c87627c2-6820-4afc-a603-64fb321590b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c87627c2-6820-4afc-a603-64fb321590b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c87627c2-6820-4afc-a603-64fb321590b3">
											<gml:posList>35.67215903088749 139.73822893448045 28.828 35.67215903088749 139.73822893448045 28.684 35.672151475383004 139.7382035806717 28.684 35.672151475383004 139.7382035806717 28.828 35.67215903088749 139.73822893448045 28.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d25e5aa0-0a12-4c5d-8650-75ad068570f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d25e5aa0-0a12-4c5d-8650-75ad068570f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d25e5aa0-0a12-4c5d-8650-75ad068570f0">
											<gml:posList>35.672151139466635 139.7382005322354 24.537 35.6721483281811 139.7382017948726 24.537 35.6721483281811 139.7382017948726 28.828 35.67216682681002 139.73819349908982 28.828 35.67216682681002 139.73819349908982 24.407 35.672151139466635 139.7382005322354 24.407 35.672151139466635 139.7382005322354 24.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-900d13b3-a59c-4e9f-bf7f-38d18714f85c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-900d13b3-a59c-4e9f-bf7f-38d18714f85c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-900d13b3-a59c-4e9f-bf7f-38d18714f85c">
											<gml:posList>35.672151475383004 139.7382035806717 28.828 35.672151475383004 139.7382035806717 28.684 35.672165369616074 139.73819733395635 28.684 35.672165369616074 139.73819733395635 28.828 35.672151475383004 139.7382035806717 28.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-770c5d82-e279-4bb1-a2d0-8cfecfd4ba6d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-770c5d82-e279-4bb1-a2d0-8cfecfd4ba6d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-770c5d82-e279-4bb1-a2d0-8cfecfd4ba6d">
											<gml:posList>35.67214251756115 139.7381716669099 24.537 35.67214251756115 139.7381716669099 24.407 35.67218064128466 139.73815476468826 24.407 35.67218064128466 139.73815476468826 24.537 35.67214251756115 139.7381716669099 24.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-06c34dc6-1a70-489b-bc5c-5fefabc4219f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-06c34dc6-1a70-489b-bc5c-5fefabc4219f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-06c34dc6-1a70-489b-bc5c-5fefabc4219f">
											<gml:posList>35.6721665396084 139.73825212323445 24.537 35.6721665396084 139.73825212323445 24.407 35.672160393992 139.738231506699 24.407 35.672160393992 139.738231506699 24.537 35.6721665396084 139.73825212323445 24.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-47bfc102-c550-4fb0-9011-06bcebabb32f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47bfc102-c550-4fb0-9011-06bcebabb32f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47bfc102-c550-4fb0-9011-06bcebabb32f">
											<gml:posList>35.67217292512187 139.7382226877689 28.828 35.67217292512187 139.7382226877689 28.684 35.67215903088749 139.73822893448045 28.684 35.67215903088749 139.73822893448045 28.828 35.67217292512187 139.7382226877689 28.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6dfb472d-36a4-40d4-a13e-d75de145a7a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6dfb472d-36a4-40d4-a13e-d75de145a7a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6dfb472d-36a4-40d4-a13e-d75de145a7a0">
											<gml:posList>35.672157573692424 139.73823276934598 28.828 35.672157573692424 139.73823276934598 24.537 35.672160393992 139.738231506699 24.537 35.672160393992 139.738231506699 24.407 35.67217607232347 139.73822447356937 24.407 35.67217607232347 139.73822447356937 28.828 35.672157573692424 139.73823276934598 28.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f9326b2c-ae08-47e1-9540-6ed6aee98161">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9326b2c-ae08-47e1-9540-6ed6aee98161">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9326b2c-ae08-47e1-9540-6ed6aee98161">
											<gml:posList>35.6721386759706 139.73816946216942 9.587 35.6721386759706 139.73816946216942 24.537 35.672182449322456 139.73815005672958 24.537 35.672182449322456 139.73815005672958 24.412 35.672197875413396 139.73814321167222 22.471 35.672197875413396 139.73814321167222 9.587 35.6721386759706 139.73816946216942 9.587</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2148bb44-9c94-4b25-b1b1-481965c45fb3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2148bb44-9c94-4b25-b1b1-481965c45fb3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2148bb44-9c94-4b25-b1b1-481965c45fb3">
											<gml:posList>35.67216682681002 139.73819349908982 28.828 35.67217607232347 139.73822447356937 28.828 35.67217607232347 139.73822447356937 24.407 35.67216682681002 139.73819349908982 24.407 35.67216682681002 139.73819349908982 28.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3c6b2dec-bcbe-466a-91c4-af14e955a82e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c6b2dec-bcbe-466a-91c4-af14e955a82e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c6b2dec-bcbe-466a-91c4-af14e955a82e">
											<gml:posList>35.67220413985816 139.73823434899253 24.537 35.67220413985816 139.73823434899253 24.407 35.6721665396084 139.73825212323445 24.407 35.6721665396084 139.73825212323445 24.537 35.67220413985816 139.73823434899253 24.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-74ecbfff-c05f-4ca2-bfba-5e71ab05849a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74ecbfff-c05f-4ca2-bfba-5e71ab05849a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74ecbfff-c05f-4ca2-bfba-5e71ab05849a">
											<gml:posList>35.67220795433653 139.73823646539802 24.412 35.67220795433653 139.73823646539802 24.537 35.67216476765637 139.73825687533312 24.537 35.67216476765637 139.73825687533312 24.412 35.67220795433653 139.73823646539802 24.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8413be89-efc9-4359-97e1-12133896d96b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8413be89-efc9-4359-97e1-12133896d96b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8413be89-efc9-4359-97e1-12133896d96b">
											<gml:posList>35.67218064128466 139.73815476468826 24.537 35.67218064128466 139.73815476468826 24.407 35.67220413985816 139.73823434899253 24.407 35.67220413985816 139.73823434899253 24.537 35.67218064128466 139.73815476468826 24.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f4d16112-a465-43f1-948e-673751890cba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4d16112-a465-43f1-948e-673751890cba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4d16112-a465-43f1-948e-673751890cba">
											<gml:posList>35.672182449322456 139.73815005672958 24.412 35.672182449322456 139.73815005672958 24.537 35.67220795433653 139.73823646539802 24.537 35.67220795433653 139.73823646539802 24.412 35.672182449322456 139.73815005672958 24.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aef70bfe-b0cd-438c-a8a9-ca07a7a01e2c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aef70bfe-b0cd-438c-a8a9-ca07a7a01e2c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aef70bfe-b0cd-438c-a8a9-ca07a7a01e2c">
											<gml:posList>35.67216985584648 139.73827392510395 9.587 35.67222716155845 139.73824657226822 9.587 35.67222716155845 139.73824657226822 22.471 35.67216985584648 139.73827392510395 22.471 35.67216985584648 139.73827392510395 9.587</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4303a1e3-ed5c-46aa-87b4-18a01acaa467">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4303a1e3-ed5c-46aa-87b4-18a01acaa467">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4303a1e3-ed5c-46aa-87b4-18a01acaa467">
											<gml:posList>35.67222716155845 139.73824657226822 9.587 35.672197875413396 139.73814321167222 9.587 35.672197875413396 139.73814321167222 22.471 35.67222716155845 139.73824657226822 22.471 35.67222716155845 139.73824657226822 9.587</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5590</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">68.93055</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1221</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.07</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>