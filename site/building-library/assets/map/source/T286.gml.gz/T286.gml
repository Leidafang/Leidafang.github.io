<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_518f00b7-01b5-4b2f-abdd-3563209145a1">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">22.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66896736986058 139.7390794453294 0 35.66898321568337 139.73905600904087 0 35.66889805811699 139.73896928717548 0 35.668814957547525 139.73909210651928 0 35.668891184270215 139.7391696706877 0 35.66889541588341 139.73916347992753 0 35.6689175626024 139.7391288797563 0 35.66893490954357 139.73914617959804 0 35.668974857303944 139.73908716877386 0 35.66896736986058 139.7390794453294 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66896736986058 139.7390794453294 12.84 35.668974857303944 139.73908716877386 12.84 35.66893490954357 139.73914617959804 12.84 35.6689175626024 139.7391288797563 12.84 35.66889541588341 139.73916347992753 12.84 35.668891184270215 139.7391696706877 12.84 35.668814957547525 139.73909210651928 12.84 35.66889805811699 139.73896928717548 12.84 35.66898321568337 139.73905600904087 12.84 35.66896736986058 139.7390794453294 12.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66896736986058 139.7390794453294 12.84 35.66898321568337 139.73905600904087 12.84 35.66898321568337 139.73905600904087 34.94 35.66896736986058 139.7390794453294 34.94 35.66896736986058 139.7390794453294 12.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66898321568337 139.73905600904087 12.84 35.66889805811699 139.73896928717548 12.84 35.66889805811699 139.73896928717548 34.94 35.66898321568337 139.73905600904087 34.94 35.66898321568337 139.73905600904087 12.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66889805811699 139.73896928717548 12.84 35.668814957547525 139.73909210651928 12.84 35.668814957547525 139.73909210651928 34.94 35.66889805811699 139.73896928717548 34.94 35.66889805811699 139.73896928717548 12.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668814957547525 139.73909210651928 12.84 35.668891184270215 139.7391696706877 12.84 35.668891184270215 139.7391696706877 34.94 35.668814957547525 139.73909210651928 34.94 35.668814957547525 139.73909210651928 12.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668891184270215 139.7391696706877 12.84 35.66889541588341 139.73916347992753 12.84 35.66889541588341 139.73916347992753 34.94 35.668891184270215 139.7391696706877 34.94 35.668891184270215 139.7391696706877 12.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66889541588341 139.73916347992753 12.84 35.6689175626024 139.7391288797563 12.84 35.6689175626024 139.7391288797563 34.94 35.66889541588341 139.73916347992753 34.94 35.66889541588341 139.73916347992753 12.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6689175626024 139.7391288797563 12.84 35.66893490954357 139.73914617959804 12.84 35.66893490954357 139.73914617959804 34.94 35.6689175626024 139.7391288797563 34.94 35.6689175626024 139.7391288797563 12.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66893490954357 139.73914617959804 12.84 35.668974857303944 139.73908716877386 12.84 35.668974857303944 139.73908716877386 34.94 35.66893490954357 139.73914617959804 34.94 35.66893490954357 139.73914617959804 12.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668974857303944 139.73908716877386 12.84 35.66896736986058 139.7390794453294 12.84 35.66896736986058 139.7390794453294 34.94 35.668974857303944 139.73908716877386 34.94 35.668974857303944 139.73908716877386 12.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66896736986058 139.7390794453294 34.94 35.66898321568337 139.73905600904087 34.94 35.66889805811699 139.73896928717548 34.94 35.668814957547525 139.73909210651928 34.94 35.668891184270215 139.7391696706877 34.94 35.66889541588341 139.73916347992753 34.94 35.6689175626024 139.7391288797563 34.94 35.66893490954357 139.73914617959804 34.94 35.668974857303944 139.73908716877386 34.94 35.66896736986058 139.7390794453294 34.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-99859090-be0b-4094-812c-84f78b3bfa0a"/>
							<gml:surfaceMember xlink:href="#poly-6c1f73ee-37f8-4fd9-b228-3d5641211ebd"/>
							<gml:surfaceMember xlink:href="#poly-a5839739-4440-4e5d-8bb7-e120b8028248"/>
							<gml:surfaceMember xlink:href="#poly-8fb76309-cb2a-4b64-b914-a3eb91336f1d"/>
							<gml:surfaceMember xlink:href="#poly-8ecc6324-2414-496c-a20e-65e20d042f58"/>
							<gml:surfaceMember xlink:href="#poly-f87848b2-1ba1-4454-84a9-9989248922f7"/>
							<gml:surfaceMember xlink:href="#poly-8e4195b5-456f-4379-b5d2-461dd3ec2f84"/>
							<gml:surfaceMember xlink:href="#poly-0811fe92-0dc6-4ea4-9267-6335cdb2814e"/>
							<gml:surfaceMember xlink:href="#poly-1f1336a8-ec57-4bd4-a5bd-151d6a240d23"/>
							<gml:surfaceMember xlink:href="#poly-73d5ed8a-117e-44fb-ad87-dcc97c209c84"/>
							<gml:surfaceMember xlink:href="#poly-693706e7-f248-4f8b-878f-9f33a4203801"/>
							<gml:surfaceMember xlink:href="#poly-2c76e258-15da-47b7-b0c3-c84f1e9ad114"/>
							<gml:surfaceMember xlink:href="#poly-099f93ed-c101-4b38-aab9-c056126861e7"/>
							<gml:surfaceMember xlink:href="#poly-2c3b43c5-8de7-47fc-a49a-2b25fc6ad05e"/>
							<gml:surfaceMember xlink:href="#poly-ca1a0c4f-a7b2-4791-9827-e2a51b862ed3"/>
							<gml:surfaceMember xlink:href="#poly-158e3d83-f2bd-4402-8727-54a9760e95eb"/>
							<gml:surfaceMember xlink:href="#poly-f5728576-51d9-4e30-8c85-fe8beca31ef6"/>
							<gml:surfaceMember xlink:href="#poly-e2f3f5cd-5859-485b-8ccb-b9f026e8cbe8"/>
							<gml:surfaceMember xlink:href="#poly-f2d5236a-ad71-4ac7-b7cc-7629e74281ba"/>
							<gml:surfaceMember xlink:href="#poly-f43b30a5-797f-4763-acc3-532a0156a477"/>
							<gml:surfaceMember xlink:href="#poly-29d66ca0-5af4-4663-af08-c708d2516d6d"/>
							<gml:surfaceMember xlink:href="#poly-7a00107d-25a0-47af-8f52-e9775edec56f"/>
							<gml:surfaceMember xlink:href="#poly-751be25e-ac7a-40d0-801e-ad862526bd4b"/>
							<gml:surfaceMember xlink:href="#poly-629954ff-fa76-47d3-96b5-2187d487607e"/>
							<gml:surfaceMember xlink:href="#poly-4dca2b3e-fdb6-463f-b127-68f0388f7887"/>
							<gml:surfaceMember xlink:href="#poly-b854079c-2f09-4ebf-9492-8ef6419c61ab"/>
							<gml:surfaceMember xlink:href="#poly-6d1e9c9b-ac2d-4616-bf66-9ca528ef3d31"/>
							<gml:surfaceMember xlink:href="#poly-851705de-ac58-499e-a81c-970b0cd0d066"/>
							<gml:surfaceMember xlink:href="#poly-ae094d6f-5a69-472f-8cdf-4c32ac56b067"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_518f00b7-01b5-4b2f-abdd-3563209145a1_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1bad050b-ea67-46b3-84b3-4a4f62fd9202">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66889541588338 139.73916347992753 12.91 35.66891756260241 139.7391288797563 12.91 35.668934909543566 139.73914617959804 12.91 35.66891183399142 139.7391802506519 12.91 35.66889541588338 139.73916347992753 12.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b6b77cc0-6ab6-4b91-8b58-2ff6d9ce1f4e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b6b77cc0-6ab6-4b91-8b58-2ff6d9ce1f4e_0">
											<gml:posList>35.668934909543566 139.73914617959804 12.91 35.66891756260241 139.7391288797563 12.91 35.66891756260241 139.7391288797563 35.131 35.668934909543566 139.73914617959804 35.131 35.668934909543566 139.73914617959804 12.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-172339a1-6745-48ca-a5a1-71d117612dbb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-172339a1-6745-48ca-a5a1-71d117612dbb_0">
											<gml:posList>35.66891756260241 139.7391288797563 12.91 35.66889541588338 139.73916347992753 12.91 35.66889541588338 139.73916347992753 35.131 35.66891756260241 139.7391288797563 35.131 35.66891756260241 139.7391288797563 12.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-30b900a1-4465-4b6f-aa3c-0fb9b604e023">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-30b900a1-4465-4b6f-aa3c-0fb9b604e023_0">
											<gml:posList>35.66889541588338 139.73916347992753 35.131 35.66891183399142 139.7391802506519 35.131 35.668934909543566 139.73914617959804 35.131 35.66891756260241 139.7391288797563 35.131 35.66889541588338 139.73916347992753 35.131</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a8e03a96-952a-440e-982b-afb2435f8d21">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a8e03a96-952a-440e-982b-afb2435f8d21_0">
											<gml:posList>35.668934909543566 139.73914617959804 12.91 35.668934909543566 139.73914617959804 35.131 35.66891183399142 139.7391802506519 35.131 35.66891183399142 139.7391802506519 12.91 35.668934909543566 139.73914617959804 12.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe93583d-123f-4cb7-9442-9c45a5fc6d62">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe93583d-123f-4cb7-9442-9c45a5fc6d62_0">
											<gml:posList>35.66889541588338 139.73916347992753 12.91 35.66891183399142 139.7391802506519 12.91 35.66891183399142 139.7391802506519 35.131 35.66889541588338 139.73916347992753 35.131 35.66889541588338 139.73916347992753 12.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_518f00b7-01b5-4b2f-abdd-3563209145a1_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c965010-3773-4c9b-b6f9-8e512c9b090b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66889427501514 139.73905324164255 34.886 35.668907140811 139.73903430462005 34.886 35.6689311274971 139.73905878761656 34.886 35.66891826169745 139.73907772464082 34.886 35.66889427501514 139.73905324164255 34.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a0495011-608e-47e8-bf8d-04c02549a4ba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a0495011-608e-47e8-bf8d-04c02549a4ba_0">
											<gml:posList>35.66889427501514 139.73905324164255 34.886 35.66889427501514 139.73905324164255 37.527 35.668907140811 139.73903430462005 37.527 35.668907140811 139.73903430462005 34.886 35.66889427501514 139.73905324164255 34.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f67248e-5ab9-4adc-bcff-6eb5f550a36c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1f67248e-5ab9-4adc-bcff-6eb5f550a36c_0">
											<gml:posList>35.668907140811 139.73903430462005 34.886 35.668907140811 139.73903430462005 37.527 35.6689311274971 139.73905878761656 37.527 35.6689311274971 139.73905878761656 34.886 35.668907140811 139.73903430462005 34.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f69d3724-05b3-4145-b62f-5293df1bd392">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f69d3724-05b3-4145-b62f-5293df1bd392_0">
											<gml:posList>35.66889427501514 139.73905324164255 37.527 35.66891826169745 139.73907772464082 37.527 35.6689311274971 139.73905878761656 37.527 35.668907140811 139.73903430462005 37.527 35.66889427501514 139.73905324164255 37.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c670aac4-96b0-4056-9fff-24d95a79c9e0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c670aac4-96b0-4056-9fff-24d95a79c9e0_0">
											<gml:posList>35.66891826169745 139.73907772464082 34.886 35.66891826169745 139.73907772464082 37.527 35.66889427501514 139.73905324164255 37.527 35.66889427501514 139.73905324164255 34.886 35.66891826169745 139.73907772464082 34.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5eccf229-e584-4b3c-a447-b99695f7f41d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5eccf229-e584-4b3c-a447-b99695f7f41d_0">
											<gml:posList>35.6689311274971 139.73905878761656 34.886 35.6689311274971 139.73905878761656 37.527 35.66891826169745 139.73907772464082 37.527 35.66891826169745 139.73907772464082 34.886 35.6689311274971 139.73905878761656 34.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_518f00b7-01b5-4b2f-abdd-3563209145a1_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-048b9f95-dfa0-4124-a039-4880fe051e50">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-048b9f95-dfa0-4124-a039-4880fe051e50_0">
											<gml:posList>35.668852147155356 139.73909075937507 35.802 35.668903807833395 139.73901397275094 37.126 35.668852147155356 139.73909075937507 37.126 35.668852147155356 139.73909075937507 35.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16a57045-1402-4a0b-9d93-1cf5509e43b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16a57045-1402-4a0b-9d93-1cf5509e43b2_0">
											<gml:posList>35.668852147155356 139.73909075937507 35.802 35.668903807833395 139.73901397275094 35.802 35.668903807833395 139.73901397275094 37.126 35.668852147155356 139.73909075937507 35.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f8bdae5a-e0b8-42aa-881e-7b6b052c55cf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f8bdae5a-e0b8-42aa-881e-7b6b052c55cf_0">
											<gml:posList>35.668886107413115 139.73905176002904 35.802 35.66887928336408 139.73906243853978 36.859 35.668886107413115 139.73905176002904 36.859 35.668886107413115 139.73905176002904 35.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b2577db-d231-406c-9a6b-4c42d694a3f9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6b2577db-d231-406c-9a6b-4c42d694a3f9_0">
											<gml:posList>35.668886107413115 139.73905176002904 35.802 35.66887928336408 139.73906243853978 35.802 35.66887928336408 139.73906243853978 36.859 35.668886107413115 139.73905176002904 35.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61857530-9b0c-4de6-a45b-4173710f0b11">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-61857530-9b0c-4de6-a45b-4173710f0b11_0">
											<gml:posList>35.66893352470338 139.73909276247858 34.886 35.66893882874996 139.73909783743247 36.121 35.66893352470338 139.73909276247858 36.121 35.66893352470338 139.73909276247858 34.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-399cb9f0-f70d-4767-b8d0-eaa0e803bab9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-399cb9f0-f70d-4767-b8d0-eaa0e803bab9_0">
											<gml:posList>35.66893352470338 139.73909276247858 34.886 35.66893882874996 139.73909783743247 34.886 35.66893882874996 139.73909783743247 36.121 35.66893352470338 139.73909276247858 34.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-705f4979-9543-4dd5-b9c5-db8fcacc0fb1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-705f4979-9543-4dd5-b9c5-db8fcacc0fb1_0">
											<gml:posList>35.66889555555463 139.73913461642235 37.126 35.668947216260236 139.73905782978477 35.802 35.66889555555463 139.73913461642235 35.802 35.66889555555463 139.73913461642235 37.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5ee8fcc6-a17b-41f6-b31a-6c7ea3b19a81">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5ee8fcc6-a17b-41f6-b31a-6c7ea3b19a81_0">
											<gml:posList>35.66889555555463 139.73913461642235 37.126 35.668947216260236 139.73905782978477 37.126 35.668947216260236 139.73905782978477 35.802 35.66889555555463 139.73913461642235 37.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40e958a8-830a-415a-bfef-2a990130ca15">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40e958a8-830a-415a-bfef-2a990130ca15_0">
											<gml:posList>35.668888920532225 139.73908736919884 35.802 35.66887665879446 139.73910649328155 36.859 35.668888920532225 139.73908736919884 36.859 35.668888920532225 139.73908736919884 35.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cdfb0988-8dd3-4e17-88c1-848941d55308">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cdfb0988-8dd3-4e17-88c1-848941d55308_0">
											<gml:posList>35.668888920532225 139.73908736919884 35.802 35.66887665879446 139.73910649328155 35.802 35.66887665879446 139.73910649328155 36.859 35.668888920532225 139.73908736919884 35.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1dc7cada-03e0-4a88-ab6f-7aa184664674">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1dc7cada-03e0-4a88-ab6f-7aa184664674_0">
											<gml:posList>35.66888721345221 139.7391174717015 35.802 35.66891013618565 139.7390839531225 36.859 35.66891013618565 139.7390839531225 35.802 35.66888721345221 139.7391174717015 35.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff57393e-2022-4047-8b18-d38abac26355">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ff57393e-2022-4047-8b18-d38abac26355_0">
											<gml:posList>35.66888721345221 139.7391174717015 35.802 35.66888721345221 139.7391174717015 36.859 35.66891013618565 139.7390839531225 36.859 35.66888721345221 139.7391174717015 35.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f43727a-54e2-46e3-8154-e5280ef5c26a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f43727a-54e2-46e3-8154-e5280ef5c26a_0">
											<gml:posList>35.66891562094803 139.73908959121087 35.802 35.6688926982044 139.7391230987445 36.859 35.6688926982044 139.7391230987445 35.802 35.66891562094803 139.73908959121087 35.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c17a3ec0-c32f-4884-98ea-cb021622c1f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c17a3ec0-c32f-4884-98ea-cb021622c1f0_0">
											<gml:posList>35.66891562094803 139.73908959121087 35.802 35.66891562094803 139.73908959121087 36.859 35.6688926982044 139.7391230987445 36.859 35.66891562094803 139.73908959121087 35.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-50e594f8-edb0-42a8-b9a7-0ffb229de236">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-50e594f8-edb0-42a8-b9a7-0ffb229de236_0">
											<gml:posList>35.66887665879446 139.73910649328155 35.802 35.66888252213224 139.73911213092427 36.859 35.66887665879446 139.73910649328155 36.859 35.66887665879446 139.73910649328155 35.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bea4e323-7edc-4201-a8f8-5cbef384da78">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bea4e323-7edc-4201-a8f8-5cbef384da78_0">
											<gml:posList>35.66887665879446 139.73910649328155 35.802 35.66888252213224 139.73911213092427 35.802 35.66888252213224 139.73911213092427 36.859 35.66887665879446 139.73910649328155 35.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-07e9cacd-96b9-4acd-82f6-aa533d799b1b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-07e9cacd-96b9-4acd-82f6-aa533d799b1b_0">
											<gml:posList>35.66888721345221 139.7391174717015 35.802 35.6688926982044 139.7391230987445 36.859 35.66888721345221 139.7391174717015 36.859 35.66888721345221 139.7391174717015 35.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df138639-9a1f-4956-8635-b3f950573eda">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-df138639-9a1f-4956-8635-b3f950573eda_0">
											<gml:posList>35.66888721345221 139.7391174717015 35.802 35.6688926982044 139.7391230987445 35.802 35.6688926982044 139.7391230987445 36.859 35.66888721345221 139.7391174717015 35.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-487b93d6-618b-427b-8551-1d96a7cc04fc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-487b93d6-618b-427b-8551-1d96a7cc04fc_0">
											<gml:posList>35.668831181444276 139.73907953914255 34.886 35.668844171461416 139.73909262448538 35.661 35.668831181444276 139.73907953914255 35.661 35.668831181444276 139.73907953914255 34.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-456fb3f1-361c-4f4e-9e4d-746e30169f2a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-456fb3f1-361c-4f4e-9e4d-746e30169f2a_0">
											<gml:posList>35.668831181444276 139.73907953914255 34.886 35.668844171461416 139.73909262448538 34.886 35.668844171461416 139.73909262448538 35.661 35.668831181444276 139.73907953914255 34.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d5d9d27a-ef73-44a9-8751-e88759d2866b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d5d9d27a-ef73-44a9-8751-e88759d2866b_0">
											<gml:posList>35.668891178924355 139.73899010603745 34.886 35.668831181444276 139.73907953914255 35.661 35.668891178924355 139.73899010603745 35.661 35.668891178924355 139.73899010603745 34.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0c4ff585-35a5-4d70-9b44-f4c7392040dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0c4ff585-35a5-4d70-9b44-f4c7392040dd_0">
											<gml:posList>35.668891178924355 139.73899010603745 34.886 35.668831181444276 139.73907953914255 34.886 35.668831181444276 139.73907953914255 35.661 35.668891178924355 139.73899010603745 34.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d316561b-9e30-4e2e-95fd-c913fdf6d2dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d316561b-9e30-4e2e-95fd-c913fdf6d2dd_0">
											<gml:posList>35.66890415994601 139.7390032024322 35.661 35.668891178924355 139.73899010603745 35.661 35.668831181444276 139.73907953914255 35.661 35.66890415994601 139.7390032024322 35.661</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-64268012-9dde-405d-a35b-5c659a842078">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-64268012-9dde-405d-a35b-5c659a842078_0">
											<gml:posList>35.668844171461416 139.73909262448538 35.661 35.66890415994601 139.7390032024322 35.661 35.668831181444276 139.73907953914255 35.661 35.668844171461416 139.73909262448538 35.661</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b52f3b42-9523-40f8-bb34-cbd78ba7c4cc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b52f3b42-9523-40f8-bb34-cbd78ba7c4cc_0">
											<gml:posList>35.66885055187306 139.73909094903294 34.886 35.668895701303676 139.73913657140284 37.126 35.66885055187306 139.73909094903294 37.126 35.66885055187306 139.73909094903294 34.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2bce26c-7f1e-44f2-a359-5814480c0d18">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a2bce26c-7f1e-44f2-a359-5814480c0d18_0">
											<gml:posList>35.66885055187306 139.73909094903294 34.886 35.668895701303676 139.73913657140284 34.886 35.668895701303676 139.73913657140284 37.126 35.66885055187306 139.73909094903294 34.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-839350b8-6eb2-42a2-b41e-01fa621133ac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-839350b8-6eb2-42a2-b41e-01fa621133ac_0">
											<gml:posList>35.668852147155356 139.73909075937507 37.126 35.66889555555463 139.73913461642235 35.802 35.668852147155356 139.73909075937507 35.802 35.668852147155356 139.73909075937507 37.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-274129e9-e352-4c23-acb3-9333e86f6874">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-274129e9-e352-4c23-acb3-9333e86f6874_0">
											<gml:posList>35.668852147155356 139.73909075937507 37.126 35.66889555555463 139.73913461642235 37.126 35.66889555555463 139.73913461642235 35.802 35.668852147155356 139.73909075937507 37.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-047339ae-964f-453e-ae11-0d13fa4a4de5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-047339ae-964f-453e-ae11-0d13fa4a4de5_0">
											<gml:posList>35.668844171461416 139.73909262448538 34.886 35.66890415994601 139.7390032024322 35.661 35.668844171461416 139.73909262448538 35.661 35.668844171461416 139.73909262448538 34.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-93af57d0-c0e6-4bd9-96a6-b0d9aa1f0302">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-93af57d0-c0e6-4bd9-96a6-b0d9aa1f0302_0">
											<gml:posList>35.668844171461416 139.73909262448538 34.886 35.66890415994601 139.7390032024322 34.886 35.66890415994601 139.7390032024322 35.661 35.668844171461416 139.73909262448538 34.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-063b0359-eae8-4ada-94a4-f890ee810c9d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-063b0359-eae8-4ada-94a4-f890ee810c9d_0">
											<gml:posList>35.66885055187306 139.73909094903294 34.886 35.668903653068625 139.7390120177811 37.126 35.668903653068625 139.7390120177811 34.886 35.66885055187306 139.73909094903294 34.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b969f797-99a1-418f-9da6-a8256da50bf6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b969f797-99a1-418f-9da6-a8256da50bf6_0">
											<gml:posList>35.66885055187306 139.73909094903294 34.886 35.66885055187306 139.73909094903294 37.126 35.668903653068625 139.7390120177811 37.126 35.66885055187306 139.73909094903294 34.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-efc1348b-3fa3-4b6c-aec3-f1b4193b5c05">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-efc1348b-3fa3-4b6c-aec3-f1b4193b5c05_0">
											<gml:posList>35.66887928336408 139.73906243853978 35.802 35.66888283744366 139.7390658475916 36.859 35.66887928336408 139.73906243853978 36.859 35.66887928336408 139.73906243853978 35.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e7b07ff7-a547-4715-ace0-9f1dc6a8020b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e7b07ff7-a547-4715-ace0-9f1dc6a8020b_0">
											<gml:posList>35.66887928336408 139.73906243853978 35.802 35.66888283744366 139.7390658475916 35.802 35.66888283744366 139.7390658475916 36.859 35.66887928336408 139.73906243853978 35.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cfcab0ca-5977-4d6e-9775-8cf97736c90c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cfcab0ca-5977-4d6e-9775-8cf97736c90c_0">
											<gml:posList>35.668886107413115 139.73905176002904 36.859 35.66888283744366 139.7390658475916 36.859 35.668889661493004 139.73905516908064 36.859 35.668886107413115 139.73905176002904 36.859</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1537833d-73aa-4ab5-8008-d8fd30943048">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1537833d-73aa-4ab5-8008-d8fd30943048_0">
											<gml:posList>35.668886107413115 139.73905176002904 36.859 35.66887928336408 139.73906243853978 36.859 35.66888283744366 139.7390658475916 36.859 35.668886107413115 139.73905176002904 36.859</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8598bc62-d12e-4267-80ca-d157957bc620">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8598bc62-d12e-4267-80ca-d157957bc620_0">
											<gml:posList>35.66888252213224 139.73911213092427 36.859 35.668894783870904 139.739093006841 36.859 35.668888920532225 139.73908736919884 36.859 35.66888252213224 139.73911213092427 36.859</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b35c4833-39ba-47de-9ad9-4be381495a7a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b35c4833-39ba-47de-9ad9-4be381495a7a_0">
											<gml:posList>35.66887665879446 139.73910649328155 36.859 35.66888252213224 139.73911213092427 36.859 35.668888920532225 139.73908736919884 36.859 35.66887665879446 139.73910649328155 36.859</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af73add4-72da-4148-9f57-abb02ad4de3e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-af73add4-72da-4148-9f57-abb02ad4de3e_0">
											<gml:posList>35.66888283744366 139.7390658475916 35.802 35.668889661493004 139.73905516908064 36.859 35.66888283744366 139.7390658475916 36.859 35.66888283744366 139.7390658475916 35.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2247dd91-85b1-4d6e-b538-04d18f7c2285">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2247dd91-85b1-4d6e-b538-04d18f7c2285_0">
											<gml:posList>35.66888283744366 139.7390658475916 35.802 35.668889661493004 139.73905516908064 35.802 35.668889661493004 139.73905516908064 36.859 35.66888283744366 139.7390658475916 35.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba0a3d8d-eb85-4a92-ae18-bd4bfb455c4e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba0a3d8d-eb85-4a92-ae18-bd4bfb455c4e_0">
											<gml:posList>35.668889661493004 139.73905516908064 35.802 35.668886107413115 139.73905176002904 36.859 35.668889661493004 139.73905516908064 36.859 35.668889661493004 139.73905516908064 35.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3530d863-495b-47c5-a4cd-c03ba4e50adc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3530d863-495b-47c5-a4cd-c03ba4e50adc_0">
											<gml:posList>35.668889661493004 139.73905516908064 35.802 35.668886107413115 139.73905176002904 35.802 35.668886107413115 139.73905176002904 36.859 35.668889661493004 139.73905516908064 35.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e6d9c66-efc9-424f-b9b7-193e9219aecc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4e6d9c66-efc9-424f-b9b7-193e9219aecc_0">
											<gml:posList>35.668894783870904 139.739093006841 35.802 35.668888920532225 139.73908736919884 36.859 35.668894783870904 139.739093006841 36.859 35.668894783870904 139.739093006841 35.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-197b1f6c-81ee-4db1-b81a-1c90d664024a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-197b1f6c-81ee-4db1-b81a-1c90d664024a_0">
											<gml:posList>35.668894783870904 139.739093006841 35.802 35.668888920532225 139.73908736919884 35.802 35.668888920532225 139.73908736919884 36.859 35.668894783870904 139.739093006841 35.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a7082534-cf68-4272-9767-d8f3d0dc3487">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a7082534-cf68-4272-9767-d8f3d0dc3487_0">
											<gml:posList>35.668891178924355 139.73899010603745 35.661 35.66890415994601 139.7390032024322 34.886 35.668891178924355 139.73899010603745 34.886 35.668891178924355 139.73899010603745 35.661</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99ccfecc-a86a-48a3-9250-caff7114d617">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-99ccfecc-a86a-48a3-9250-caff7114d617_0">
											<gml:posList>35.668891178924355 139.73899010603745 35.661 35.66890415994601 139.7390032024322 35.661 35.66890415994601 139.7390032024322 34.886 35.668891178924355 139.73899010603745 35.661</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5856b250-f65c-4277-9b7f-26fe22939d2c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5856b250-f65c-4277-9b7f-26fe22939d2c_0">
											<gml:posList>35.66889555555463 139.73913461642235 35.802 35.668947216260236 139.73905782978477 35.802 35.66891562094803 139.73908959121087 35.802 35.66889555555463 139.73913461642235 35.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80193bf1-2969-4f95-813e-22151747ae87">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-80193bf1-2969-4f95-813e-22151747ae87_0">
											<gml:posList>35.668852147155356 139.73909075937507 35.802 35.66889555555463 139.73913461642235 35.802 35.66887665879446 139.73910649328155 35.802 35.668852147155356 139.73909075937507 35.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-07626c49-e613-4f17-987f-8636cd805b3f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-07626c49-e613-4f17-987f-8636cd805b3f_0">
											<gml:posList>35.668947216260236 139.73905782978477 35.802 35.668903807833395 139.73901397275094 35.802 35.668889661493004 139.73905516908064 35.802 35.668947216260236 139.73905782978477 35.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-98941db5-dc64-4c9d-bd88-841637025b34">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-98941db5-dc64-4c9d-bd88-841637025b34_0">
											<gml:posList>35.668903807833395 139.73901397275094 35.802 35.668852147155356 139.73909075937507 35.802 35.668886107413115 139.73905176002904 35.802 35.668903807833395 139.73901397275094 35.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e6362afd-88ff-43f1-b233-f69b92fb73e5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e6362afd-88ff-43f1-b233-f69b92fb73e5_0">
											<gml:posList>35.66891562094803 139.73908959121087 35.802 35.668947216260236 139.73905782978477 35.802 35.66891013618565 139.7390839531225 35.802 35.66891562094803 139.73908959121087 35.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97909b04-b7fa-4d3b-9188-3f12254b18dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-97909b04-b7fa-4d3b-9188-3f12254b18dd_0">
											<gml:posList>35.6688926982044 139.7391230987445 35.802 35.66889555555463 139.73913461642235 35.802 35.66891562094803 139.73908959121087 35.802 35.6688926982044 139.7391230987445 35.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-890e3470-6b00-4515-b9e6-0d0e8dc90486">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-890e3470-6b00-4515-b9e6-0d0e8dc90486_0">
											<gml:posList>35.66887665879446 139.73910649328155 35.802 35.66889555555463 139.73913461642235 35.802 35.66888252213224 139.73911213092427 35.802 35.66887665879446 139.73910649328155 35.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da89d80f-d85e-41d1-af68-b9b5ebe75175">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da89d80f-d85e-41d1-af68-b9b5ebe75175_0">
											<gml:posList>35.668852147155356 139.73909075937507 35.802 35.66887665879446 139.73910649328155 35.802 35.668888920532225 139.73908736919884 35.802 35.668852147155356 139.73909075937507 35.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c57a5ae1-fae4-4cf8-ad1a-e207ee51edc4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c57a5ae1-fae4-4cf8-ad1a-e207ee51edc4_0">
											<gml:posList>35.66891013618565 139.7390839531225 35.802 35.668947216260236 139.73905782978477 35.802 35.668889661493004 139.73905516908064 35.802 35.66891013618565 139.7390839531225 35.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba379e8f-e35b-4a9e-9fd3-b77b6eddc0eb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba379e8f-e35b-4a9e-9fd3-b77b6eddc0eb_0">
											<gml:posList>35.668886107413115 139.73905176002904 35.802 35.668852147155356 139.73909075937507 35.802 35.66887928336408 139.73906243853978 35.802 35.668886107413115 139.73905176002904 35.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57482ca8-0b28-46e2-8ea7-97f1a778dc20">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-57482ca8-0b28-46e2-8ea7-97f1a778dc20_0">
											<gml:posList>35.668903807833395 139.73901397275094 35.802 35.668886107413115 139.73905176002904 35.802 35.668889661493004 139.73905516908064 35.802 35.668903807833395 139.73901397275094 35.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cdbd8d98-307a-4f23-8c68-41391e348087">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cdbd8d98-307a-4f23-8c68-41391e348087_0">
											<gml:posList>35.66889555555463 139.73913461642235 35.802 35.6688926982044 139.7391230987445 35.802 35.66888721345221 139.7391174717015 35.802 35.66889555555463 139.73913461642235 35.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d559d9c4-bd40-4343-b239-49b036f9ffe9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d559d9c4-bd40-4343-b239-49b036f9ffe9_0">
											<gml:posList>35.66889555555463 139.73913461642235 35.802 35.66888721345221 139.7391174717015 35.802 35.66888252213224 139.73911213092427 35.802 35.66889555555463 139.73913461642235 35.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29cfb9af-a4bf-402a-be7e-aafb0321beba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29cfb9af-a4bf-402a-be7e-aafb0321beba_0">
											<gml:posList>35.66888283744366 139.7390658475916 35.802 35.668852147155356 139.73909075937507 35.802 35.668888920532225 139.73908736919884 35.802 35.66888283744366 139.7390658475916 35.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eb283ea9-1873-4ab0-a4d4-aac11003c67c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eb283ea9-1873-4ab0-a4d4-aac11003c67c_0">
											<gml:posList>35.66887928336408 139.73906243853978 35.802 35.668852147155356 139.73909075937507 35.802 35.66888283744366 139.7390658475916 35.802 35.66887928336408 139.73906243853978 35.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-efff9ecb-59f5-4fe1-b6c6-9f0746d7288e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-efff9ecb-59f5-4fe1-b6c6-9f0746d7288e_0">
											<gml:posList>35.66888252213224 139.73911213092427 35.802 35.66888721345221 139.7391174717015 35.802 35.668894783870904 139.739093006841 35.802 35.66888252213224 139.73911213092427 35.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-55248c5e-492d-481c-8708-9a17acefd500">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-55248c5e-492d-481c-8708-9a17acefd500_0">
											<gml:posList>35.668894783870904 139.739093006841 35.802 35.66888721345221 139.7391174717015 35.802 35.66891013618565 139.7390839531225 35.802 35.668894783870904 139.739093006841 35.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4bbe7a17-1dae-49d4-819d-78307380e04a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4bbe7a17-1dae-49d4-819d-78307380e04a_0">
											<gml:posList>35.668888920532225 139.73908736919884 35.802 35.668894783870904 139.739093006841 35.802 35.66891013618565 139.7390839531225 35.802 35.668888920532225 139.73908736919884 35.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad7750c1-a52e-48e8-8fa0-4c51319acab3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ad7750c1-a52e-48e8-8fa0-4c51319acab3_0">
											<gml:posList>35.668889661493004 139.73905516908064 35.802 35.668888920532225 139.73908736919884 35.802 35.66891013618565 139.7390839531225 35.802 35.668889661493004 139.73905516908064 35.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc0b629f-b6db-4d8b-a11e-69f22c08faf4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dc0b629f-b6db-4d8b-a11e-69f22c08faf4_0">
											<gml:posList>35.668889661493004 139.73905516908064 35.802 35.66888283744366 139.7390658475916 35.802 35.668888920532225 139.73908736919884 35.802 35.668889661493004 139.73905516908064 35.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3b76ffe-3c82-4f8b-b33f-38153a0d5ca1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3b76ffe-3c82-4f8b-b33f-38153a0d5ca1_0">
											<gml:posList>35.66889555555463 139.73913461642235 37.126 35.668895701303676 139.73913657140284 37.126 35.66894881154245 139.73905764012605 37.126 35.66889555555463 139.73913461642235 37.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d11068d-9e48-428e-8cf3-fdeb4e2ea16c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d11068d-9e48-428e-8cf3-fdeb4e2ea16c_0">
											<gml:posList>35.66894881154245 139.73905764012605 37.126 35.668903653068625 139.7390120177811 37.126 35.668903807833395 139.73901397275094 37.126 35.66894881154245 139.73905764012605 37.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c723d639-27c9-4043-b409-240152631792">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c723d639-27c9-4043-b409-240152631792_0">
											<gml:posList>35.668895701303676 139.73913657140284 37.126 35.668852147155356 139.73909075937507 37.126 35.66885055187306 139.73909094903294 37.126 35.668895701303676 139.73913657140284 37.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b6a7fcc-c9fc-413b-a5e3-cd2bfd466fe6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5b6a7fcc-c9fc-413b-a5e3-cd2bfd466fe6_0">
											<gml:posList>35.668903653068625 139.7390120177811 37.126 35.66885055187306 139.73909094903294 37.126 35.668852147155356 139.73909075937507 37.126 35.668903653068625 139.7390120177811 37.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c3eaf31-ca23-4b3d-b507-154e12c3af4e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c3eaf31-ca23-4b3d-b507-154e12c3af4e_0">
											<gml:posList>35.66889555555463 139.73913461642235 37.126 35.66894881154245 139.73905764012605 37.126 35.668947216260236 139.73905782978477 37.126 35.66889555555463 139.73913461642235 37.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e085a05f-c0a8-42a2-9edc-bfa34162f130">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e085a05f-c0a8-42a2-9edc-bfa34162f130_0">
											<gml:posList>35.668852147155356 139.73909075937507 37.126 35.668895701303676 139.73913657140284 37.126 35.66889555555463 139.73913461642235 37.126 35.668852147155356 139.73909075937507 37.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3d3cf15-0a2d-40b8-b4ff-6422b750f723">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3d3cf15-0a2d-40b8-b4ff-6422b750f723_0">
											<gml:posList>35.668903653068625 139.7390120177811 37.126 35.668852147155356 139.73909075937507 37.126 35.668903807833395 139.73901397275094 37.126 35.668903653068625 139.7390120177811 37.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f23f2491-3fb6-4080-9316-a59ca7667b87">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f23f2491-3fb6-4080-9316-a59ca7667b87_0">
											<gml:posList>35.668947216260236 139.73905782978477 37.126 35.66894881154245 139.73905764012605 37.126 35.668903807833395 139.73901397275094 37.126 35.668947216260236 139.73905782978477 37.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9723b4d-ac02-4343-a033-c6b3861cb4ff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b9723b4d-ac02-4343-a033-c6b3861cb4ff_0">
											<gml:posList>35.66891013618565 139.7390839531225 36.859 35.66888721345221 139.7391174717015 36.859 35.6688926982044 139.7391230987445 36.859 35.66891013618565 139.7390839531225 36.859</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e21e62b-1013-4c2e-beb8-d10b11684224">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e21e62b-1013-4c2e-beb8-d10b11684224_0">
											<gml:posList>35.66891562094803 139.73908959121087 36.859 35.66891013618565 139.7390839531225 36.859 35.6688926982044 139.7391230987445 36.859 35.66891562094803 139.73908959121087 36.859</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-961ec2da-aa38-4c88-a66b-378448f01dae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-961ec2da-aa38-4c88-a66b-378448f01dae_0">
											<gml:posList>35.66891013618565 139.7390839531225 35.802 35.66891562094803 139.73908959121087 36.859 35.66891562094803 139.73908959121087 35.802 35.66891013618565 139.7390839531225 35.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b0acda5-66f2-4f85-a1c1-601ac3ce3809">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4b0acda5-66f2-4f85-a1c1-601ac3ce3809_0">
											<gml:posList>35.66891013618565 139.7390839531225 35.802 35.66891013618565 139.7390839531225 36.859 35.66891562094803 139.73908959121087 36.859 35.66891013618565 139.7390839531225 35.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-98ea0e05-c01b-4b82-9714-ccc87b6fd477">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-98ea0e05-c01b-4b82-9714-ccc87b6fd477_0">
											<gml:posList>35.66891758605669 139.73911277457648 34.886 35.668925235693195 139.73912043155232 36.859 35.66891758605669 139.73911277457648 36.859 35.66891758605669 139.73911277457648 34.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8461ab88-9d99-480a-be5e-d37705bc99a3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8461ab88-9d99-480a-be5e-d37705bc99a3_0">
											<gml:posList>35.66891758605669 139.73911277457648 34.886 35.668925235693195 139.73912043155232 34.886 35.668925235693195 139.73912043155232 36.859 35.66891758605669 139.73911277457648 34.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a62e7453-d234-4d47-8d10-17a3fc2b00e1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a62e7453-d234-4d47-8d10-17a3fc2b00e1_0">
											<gml:posList>35.668895701303676 139.73913657140284 34.886 35.66894881154245 139.73905764012605 37.126 35.668895701303676 139.73913657140284 37.126 35.668895701303676 139.73913657140284 34.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3badb7fa-8295-43e6-a2db-41159c639b70">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3badb7fa-8295-43e6-a2db-41159c639b70_0">
											<gml:posList>35.668895701303676 139.73913657140284 34.886 35.66894881154245 139.73905764012605 34.886 35.66894881154245 139.73905764012605 37.126 35.668895701303676 139.73913657140284 34.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e32a388-fa09-423c-ae18-d9b129554b57">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1e32a388-fa09-423c-ae18-d9b129554b57_0">
											<gml:posList>35.668947216260236 139.73905782978477 37.126 35.668903807833395 139.73901397275094 35.802 35.668947216260236 139.73905782978477 35.802 35.668947216260236 139.73905782978477 37.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4c602b3-1fb3-410a-bf15-3facc4edcf8c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4c602b3-1fb3-410a-bf15-3facc4edcf8c_0">
											<gml:posList>35.668947216260236 139.73905782978477 37.126 35.668903807833395 139.73901397275094 37.126 35.668903807833395 139.73901397275094 35.802 35.668947216260236 139.73905782978477 37.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b6102aa5-70a3-4b2f-8b4f-146c695358d0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b6102aa5-70a3-4b2f-8b4f-146c695358d0_0">
											<gml:posList>35.66894881154245 139.73905764012605 34.886 35.668903653068625 139.7390120177811 37.126 35.66894881154245 139.73905764012605 37.126 35.66894881154245 139.73905764012605 34.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-64dcdb46-984d-4ccf-b1d1-114a5bbdd306">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-64dcdb46-984d-4ccf-b1d1-114a5bbdd306_0">
											<gml:posList>35.66894881154245 139.73905764012605 34.886 35.668903653068625 139.7390120177811 34.886 35.668903653068625 139.7390120177811 37.126 35.66894881154245 139.73905764012605 34.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e6101d6-3b03-4e39-98c9-2d82b27a930c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e6101d6-3b03-4e39-98c9-2d82b27a930c_0">
											<gml:posList>35.668925235693195 139.73912043155232 36.859 35.668929569277616 139.7390948106485 36.859 35.66891758605669 139.73911277457648 36.859 35.668925235693195 139.73912043155232 36.859</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f87e60c1-66e4-4fb8-b2de-eac9f8df8f5a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f87e60c1-66e4-4fb8-b2de-eac9f8df8f5a_0">
											<gml:posList>35.668925235693195 139.73912043155232 36.859 35.66893721892389 139.73910247866985 36.859 35.668929569277616 139.7390948106485 36.859 35.668925235693195 139.73912043155232 36.859</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd4be9f6-667f-44e9-a69f-81535ad593ac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dd4be9f6-667f-44e9-a69f-81535ad593ac_0">
											<gml:posList>35.66893721892389 139.73910247866985 34.886 35.668925235693195 139.73912043155232 36.859 35.668925235693195 139.73912043155232 34.886 35.66893721892389 139.73910247866985 34.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a053c07a-e7ab-43aa-872e-04601fdb084a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a053c07a-e7ab-43aa-872e-04601fdb084a_0">
											<gml:posList>35.66893721892389 139.73910247866985 34.886 35.66893721892389 139.73910247866985 36.859 35.668925235693195 139.73912043155232 36.859 35.66893721892389 139.73910247866985 34.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-07e3064d-31d7-4029-8fce-23e4517a3c40">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-07e3064d-31d7-4029-8fce-23e4517a3c40_0">
											<gml:posList>35.668929569277616 139.7390948106485 34.886 35.66893721892389 139.73910247866985 36.859 35.66893721892389 139.73910247866985 34.886 35.668929569277616 139.7390948106485 34.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a892ceb4-0ee3-44e9-afc3-4eb8f03ff250">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a892ceb4-0ee3-44e9-afc3-4eb8f03ff250_0">
											<gml:posList>35.668929569277616 139.7390948106485 34.886 35.668929569277616 139.7390948106485 36.859 35.66893721892389 139.73910247866985 36.859 35.668929569277616 139.7390948106485 34.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-20eaf52a-6538-4c33-b031-dada4a3f3947">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-20eaf52a-6538-4c33-b031-dada4a3f3947_0">
											<gml:posList>35.668951261453 139.7390783375665 36.121 35.66894595739696 139.73907325156705 36.121 35.66893352470338 139.73909276247858 36.121 35.668951261453 139.7390783375665 36.121</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ffb9431a-2940-410d-8fa4-070dab6bf267">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ffb9431a-2940-410d-8fa4-070dab6bf267_0">
											<gml:posList>35.66893882874996 139.73909783743247 36.121 35.668951261453 139.7390783375665 36.121 35.66893352470338 139.73909276247858 36.121 35.66893882874996 139.73909783743247 36.121</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4bb0b301-fdce-4700-8126-f8c15bc80c79">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4bb0b301-fdce-4700-8126-f8c15bc80c79_0">
											<gml:posList>35.66893882874996 139.73909783743247 34.886 35.668951261453 139.7390783375665 36.121 35.66893882874996 139.73909783743247 36.121 35.66893882874996 139.73909783743247 34.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d11b01b6-4c5e-491a-b789-a086ed0f4f45">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d11b01b6-4c5e-491a-b789-a086ed0f4f45_0">
											<gml:posList>35.66893882874996 139.73909783743247 34.886 35.668951261453 139.7390783375665 34.886 35.668951261453 139.7390783375665 36.121 35.66893882874996 139.73909783743247 34.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ee92d540-90a8-47c8-8321-c940d7f6cf3b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ee92d540-90a8-47c8-8321-c940d7f6cf3b_0">
											<gml:posList>35.668951261453 139.7390783375665 34.886 35.66894595739696 139.73907325156705 36.121 35.668951261453 139.7390783375665 36.121 35.668951261453 139.7390783375665 34.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-45bfc739-5577-4171-90ed-ded0c1ad2f5d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-45bfc739-5577-4171-90ed-ded0c1ad2f5d_0">
											<gml:posList>35.668951261453 139.7390783375665 34.886 35.66894595739696 139.73907325156705 34.886 35.66894595739696 139.73907325156705 36.121 35.668951261453 139.7390783375665 34.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e0c7173f-5bdb-4be2-9efe-02a61f33bd32">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668831181444276 139.73907953914255 34.886 35.668891178924355 139.73899010603745 34.886 35.66890415994601 139.7390032024322 34.886 35.668831181444276 139.73907953914255 34.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f8b59c1d-e425-482f-9682-ea1514f8aab4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668844171461416 139.73909262448538 34.886 35.668831181444276 139.73907953914255 34.886 35.66890415994601 139.7390032024322 34.886 35.668844171461416 139.73909262448538 34.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9c9444a0-b4b7-4389-8a21-816a3c7a81e3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668903653068625 139.7390120177811 34.886 35.668895701303676 139.73913657140284 34.886 35.66885055187306 139.73909094903294 34.886 35.668903653068625 139.7390120177811 34.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd4f89b3-58cf-4bc9-9348-838deaee5c04">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668903653068625 139.7390120177811 34.886 35.66894881154245 139.73905764012605 34.886 35.668895701303676 139.73913657140284 34.886 35.668903653068625 139.7390120177811 34.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-88911e87-bc84-463d-a542-30b86c2eec53">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66894595739696 139.73907325156705 34.886 35.66893352470338 139.73909276247858 36.121 35.66894595739696 139.73907325156705 36.121 35.66894595739696 139.73907325156705 34.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-892dac5c-f447-4cec-8ed2-825dd6545d9a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66894595739696 139.73907325156705 34.886 35.66893352470338 139.73909276247858 34.886 35.66893352470338 139.73909276247858 36.121 35.66894595739696 139.73907325156705 34.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1592b9f2-7544-43ce-a147-c7bc66e4228a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66893352470338 139.73909276247858 34.886 35.66894595739696 139.73907325156705 34.886 35.668951261453 139.7390783375665 34.886 35.66893352470338 139.73909276247858 34.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94aface4-8117-4abf-b029-efc7331ed5f2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66893882874996 139.73909783743247 34.886 35.66893352470338 139.73909276247858 34.886 35.668951261453 139.7390783375665 34.886 35.66893882874996 139.73909783743247 34.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0740f4b4-fd1b-4f87-9a80-449527599576">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66888252213224 139.73911213092427 35.802 35.668894783870904 139.739093006841 36.859 35.66888252213224 139.73911213092427 36.859 35.66888252213224 139.73911213092427 35.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a62b7ef2-2725-4063-8ec3-dc608b27fe15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66888252213224 139.73911213092427 35.802 35.668894783870904 139.739093006841 35.802 35.668894783870904 139.739093006841 36.859 35.66888252213224 139.73911213092427 35.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-49c2e51f-d81a-4ddd-bfd0-b256e7764ab0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668929569277616 139.7390948106485 34.886 35.66891758605669 139.73911277457648 36.859 35.668929569277616 139.7390948106485 36.859 35.668929569277616 139.7390948106485 34.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f90eaa2-c938-4add-acc2-2cb47bedc9b3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668929569277616 139.7390948106485 34.886 35.66891758605669 139.73911277457648 34.886 35.66891758605669 139.73911277457648 36.859 35.668929569277616 139.7390948106485 34.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1884ca2f-22ac-47bc-a967-f8df01eb2ae1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668925235693195 139.73912043155232 34.886 35.668929569277616 139.7390948106485 34.886 35.66893721892389 139.73910247866985 34.886 35.668925235693195 139.73912043155232 34.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e2bc6ce-d5f7-4257-b8a0-d3e68c4aa9a5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668925235693195 139.73912043155232 34.886 35.66891758605669 139.73911277457648 34.886 35.668929569277616 139.7390948106485 34.886 35.668925235693195 139.73912043155232 34.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-99859090-be0b-4094-812c-84f78b3bfa0a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-99859090-be0b-4094-812c-84f78b3bfa0a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-99859090-be0b-4094-812c-84f78b3bfa0a">
											<gml:posList>35.668967369860546 139.7390794453294 12.84 35.668974857303944 139.73908716877386 12.84 35.668934909543566 139.73914617959804 12.84 35.66891756260241 139.7391288797563 12.84 35.66889541588338 139.73916347992753 12.84 35.66889118427021 139.7391696706877 12.84 35.668814957547504 139.73909210651928 12.84 35.66889805811698 139.73896928717548 12.84 35.66898321568335 139.73905600904087 12.84 35.668967369860546 139.7390794453294 12.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6c1f73ee-37f8-4fd9-b228-3d5641211ebd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c1f73ee-37f8-4fd9-b228-3d5641211ebd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c1f73ee-37f8-4fd9-b228-3d5641211ebd">
											<gml:posList>35.66889118427021 139.7391696706877 35.131 35.66889077422985 139.73916401558952 35.131 35.66881959020433 139.73909159295627 35.131 35.668814957547504 139.73909210651928 35.131 35.66889118427021 139.7391696706877 35.131</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a5839739-4440-4e5d-8bb7-e120b8028248">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5839739-4440-4e5d-8bb7-e120b8028248">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5839739-4440-4e5d-8bb7-e120b8028248">
											<gml:posList>35.668814957547504 139.73909210651928 35.131 35.66881959020433 139.73909159295627 35.131 35.66889849522495 139.7389749643334 35.131 35.66889805811698 139.73896928717548 35.131 35.668814957547504 139.73909210651928 35.131</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8fb76309-cb2a-4b64-b914-a3eb91336f1d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8fb76309-cb2a-4b64-b914-a3eb91336f1d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8fb76309-cb2a-4b64-b914-a3eb91336f1d">
											<gml:posList>35.66889541588338 139.73916347992753 35.131 35.66889290804651 139.73916089809612 35.131 35.66889077422985 139.73916401558952 35.131 35.66889118427021 139.7391696706877 35.131 35.66889541588338 139.73916347992753 35.131</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8ecc6324-2414-496c-a20e-65e20d042f58">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ecc6324-2414-496c-a20e-65e20d042f58">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ecc6324-2414-496c-a20e-65e20d042f58">
											<gml:posList>35.66889849522495 139.7389749643334 34.886 35.66881959020433 139.73909159295627 34.886 35.66889077422985 139.73916401558952 34.886 35.66889290804651 139.73916089809612 34.886 35.66891705336595 139.73912316954275 34.886 35.66893445445076 139.73914054664192 34.886 35.668970251688435 139.73908768230632 34.886 35.66896276424508 139.73907995886225 34.886 35.66897859205783 139.73905654468848 34.886 35.66889849522495 139.7389749643334 34.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f87848b2-1ba1-4454-84a9-9989248922f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f87848b2-1ba1-4454-84a9-9989248922f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f87848b2-1ba1-4454-84a9-9989248922f7">
											<gml:posList>35.66891756260241 139.7391288797563 35.131 35.66891705336595 139.73912316954275 35.131 35.66889290804651 139.73916089809612 35.131 35.66889541588338 139.73916347992753 35.131 35.66891756260241 139.7391288797563 35.131</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8e4195b5-456f-4379-b5d2-461dd3ec2f84">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8e4195b5-456f-4379-b5d2-461dd3ec2f84">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8e4195b5-456f-4379-b5d2-461dd3ec2f84">
											<gml:posList>35.66891756260241 139.7391288797563 35.131 35.668934909543566 139.73914617959804 35.131 35.66893445445076 139.73914054664192 35.131 35.66891705336595 139.73912316954275 35.131 35.66891756260241 139.7391288797563 35.131</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0811fe92-0dc6-4ea4-9267-6335cdb2814e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0811fe92-0dc6-4ea4-9267-6335cdb2814e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0811fe92-0dc6-4ea4-9267-6335cdb2814e">
											<gml:posList>35.66889805811698 139.73896928717548 35.131 35.66889849522495 139.7389749643334 35.131 35.66897859205783 139.73905654468848 35.131 35.66898321568335 139.73905600904087 35.131 35.66889805811698 139.73896928717548 35.131</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1f1336a8-ec57-4bd4-a5bd-151d6a240d23">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f1336a8-ec57-4bd4-a5bd-151d6a240d23">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f1336a8-ec57-4bd4-a5bd-151d6a240d23">
											<gml:posList>35.668974857303944 139.73908716877386 35.131 35.668970251688435 139.73908768230632 35.131 35.66893445445076 139.73914054664192 35.131 35.668934909543566 139.73914617959804 35.131 35.668974857303944 139.73908716877386 35.131</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-73d5ed8a-117e-44fb-ad87-dcc97c209c84">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73d5ed8a-117e-44fb-ad87-dcc97c209c84">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73d5ed8a-117e-44fb-ad87-dcc97c209c84">
											<gml:posList>35.668967369860546 139.7390794453294 35.131 35.66896276424508 139.73907995886225 35.131 35.668970251688435 139.73908768230632 35.131 35.668974857303944 139.73908716877386 35.131 35.668967369860546 139.7390794453294 35.131</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-693706e7-f248-4f8b-878f-9f33a4203801">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-693706e7-f248-4f8b-878f-9f33a4203801">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-693706e7-f248-4f8b-878f-9f33a4203801">
											<gml:posList>35.668967369860546 139.7390794453294 35.131 35.66898321568335 139.73905600904087 35.131 35.66897859205783 139.73905654468848 35.131 35.66896276424508 139.73907995886225 35.131 35.668967369860546 139.7390794453294 35.131</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2c76e258-15da-47b7-b0c3-c84f1e9ad114">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c76e258-15da-47b7-b0c3-c84f1e9ad114">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c76e258-15da-47b7-b0c3-c84f1e9ad114">
											<gml:posList>35.66898321568335 139.73905600904087 12.84 35.66889805811698 139.73896928717548 12.84 35.66889805811698 139.73896928717548 35.131 35.66898321568335 139.73905600904087 35.131 35.66898321568335 139.73905600904087 12.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-099f93ed-c101-4b38-aab9-c056126861e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-099f93ed-c101-4b38-aab9-c056126861e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-099f93ed-c101-4b38-aab9-c056126861e7">
											<gml:posList>35.66889849522495 139.7389749643334 35.131 35.66889849522495 139.7389749643334 34.886 35.66897859205783 139.73905654468848 34.886 35.66897859205783 139.73905654468848 35.131 35.66889849522495 139.7389749643334 35.131</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2c3b43c5-8de7-47fc-a49a-2b25fc6ad05e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c3b43c5-8de7-47fc-a49a-2b25fc6ad05e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c3b43c5-8de7-47fc-a49a-2b25fc6ad05e">
											<gml:posList>35.66889805811698 139.73896928717548 12.84 35.668814957547504 139.73909210651928 12.84 35.668814957547504 139.73909210651928 35.131 35.66889805811698 139.73896928717548 35.131 35.66889805811698 139.73896928717548 12.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ca1a0c4f-a7b2-4791-9827-e2a51b862ed3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca1a0c4f-a7b2-4791-9827-e2a51b862ed3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca1a0c4f-a7b2-4791-9827-e2a51b862ed3">
											<gml:posList>35.66881959020433 139.73909159295627 35.131 35.66881959020433 139.73909159295627 34.886 35.66889849522495 139.7389749643334 34.886 35.66889849522495 139.7389749643334 35.131 35.66881959020433 139.73909159295627 35.131</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-158e3d83-f2bd-4402-8727-54a9760e95eb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-158e3d83-f2bd-4402-8727-54a9760e95eb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-158e3d83-f2bd-4402-8727-54a9760e95eb">
											<gml:posList>35.668967369860546 139.7390794453294 12.84 35.66898321568335 139.73905600904087 12.84 35.66898321568335 139.73905600904087 35.131 35.668967369860546 139.7390794453294 35.131 35.668967369860546 139.7390794453294 12.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f5728576-51d9-4e30-8c85-fe8beca31ef6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f5728576-51d9-4e30-8c85-fe8beca31ef6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f5728576-51d9-4e30-8c85-fe8beca31ef6">
											<gml:posList>35.66897859205783 139.73905654468848 35.131 35.66897859205783 139.73905654468848 34.886 35.66896276424508 139.73907995886225 34.886 35.66896276424508 139.73907995886225 35.131 35.66897859205783 139.73905654468848 35.131</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e2f3f5cd-5859-485b-8ccb-b9f026e8cbe8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e2f3f5cd-5859-485b-8ccb-b9f026e8cbe8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e2f3f5cd-5859-485b-8ccb-b9f026e8cbe8">
											<gml:posList>35.668974857303944 139.73908716877386 12.84 35.668967369860546 139.7390794453294 12.84 35.668967369860546 139.7390794453294 35.131 35.668974857303944 139.73908716877386 35.131 35.668974857303944 139.73908716877386 12.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f2d5236a-ad71-4ac7-b7cc-7629e74281ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f2d5236a-ad71-4ac7-b7cc-7629e74281ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f2d5236a-ad71-4ac7-b7cc-7629e74281ba">
											<gml:posList>35.66896276424508 139.73907995886225 35.131 35.66896276424508 139.73907995886225 34.886 35.668970251688435 139.73908768230632 34.886 35.668970251688435 139.73908768230632 35.131 35.66896276424508 139.73907995886225 35.131</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f43b30a5-797f-4763-acc3-532a0156a477">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f43b30a5-797f-4763-acc3-532a0156a477">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f43b30a5-797f-4763-acc3-532a0156a477">
											<gml:posList>35.668970251688435 139.73908768230632 35.131 35.668970251688435 139.73908768230632 34.886 35.66893445445076 139.73914054664192 34.886 35.66893445445076 139.73914054664192 35.131 35.668970251688435 139.73908768230632 35.131</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-29d66ca0-5af4-4663-af08-c708d2516d6d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-29d66ca0-5af4-4663-af08-c708d2516d6d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-29d66ca0-5af4-4663-af08-c708d2516d6d">
											<gml:posList>35.668934909543566 139.73914617959804 12.84 35.668974857303944 139.73908716877386 12.84 35.668974857303944 139.73908716877386 35.131 35.668934909543566 139.73914617959804 35.131 35.668934909543566 139.73914617959804 12.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7a00107d-25a0-47af-8f52-e9775edec56f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a00107d-25a0-47af-8f52-e9775edec56f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a00107d-25a0-47af-8f52-e9775edec56f">
											<gml:posList>35.66889077422985 139.73916401558952 35.131 35.66889077422985 139.73916401558952 34.886 35.66881959020433 139.73909159295627 34.886 35.66881959020433 139.73909159295627 35.131 35.66889077422985 139.73916401558952 35.131</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-751be25e-ac7a-40d0-801e-ad862526bd4b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-751be25e-ac7a-40d0-801e-ad862526bd4b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-751be25e-ac7a-40d0-801e-ad862526bd4b">
											<gml:posList>35.668814957547504 139.73909210651928 12.84 35.66889118427021 139.7391696706877 12.84 35.66889118427021 139.7391696706877 35.131 35.668814957547504 139.73909210651928 35.131 35.668814957547504 139.73909210651928 12.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-629954ff-fa76-47d3-96b5-2187d487607e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-629954ff-fa76-47d3-96b5-2187d487607e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-629954ff-fa76-47d3-96b5-2187d487607e">
											<gml:posList>35.66893445445076 139.73914054664192 35.131 35.66893445445076 139.73914054664192 34.886 35.66891705336595 139.73912316954275 34.886 35.66891705336595 139.73912316954275 35.131 35.66893445445076 139.73914054664192 35.131</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4dca2b3e-fdb6-463f-b127-68f0388f7887">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4dca2b3e-fdb6-463f-b127-68f0388f7887">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4dca2b3e-fdb6-463f-b127-68f0388f7887">
											<gml:posList>35.66891756260241 139.7391288797563 12.84 35.668934909543566 139.73914617959804 12.84 35.668934909543566 139.73914617959804 35.131 35.66891756260241 139.7391288797563 35.131 35.66891756260241 139.7391288797563 12.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b854079c-2f09-4ebf-9492-8ef6419c61ab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b854079c-2f09-4ebf-9492-8ef6419c61ab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b854079c-2f09-4ebf-9492-8ef6419c61ab">
											<gml:posList>35.66891705336595 139.73912316954275 35.131 35.66891705336595 139.73912316954275 34.886 35.66889290804651 139.73916089809612 34.886 35.66889290804651 139.73916089809612 35.131 35.66891705336595 139.73912316954275 35.131</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6d1e9c9b-ac2d-4616-bf66-9ca528ef3d31">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d1e9c9b-ac2d-4616-bf66-9ca528ef3d31">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d1e9c9b-ac2d-4616-bf66-9ca528ef3d31">
											<gml:posList>35.66889541588338 139.73916347992753 12.84 35.66891756260241 139.7391288797563 12.84 35.66891756260241 139.7391288797563 35.131 35.66889541588338 139.73916347992753 35.131 35.66889541588338 139.73916347992753 12.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-851705de-ac58-499e-a81c-970b0cd0d066">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-851705de-ac58-499e-a81c-970b0cd0d066">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-851705de-ac58-499e-a81c-970b0cd0d066">
											<gml:posList>35.66889290804651 139.73916089809612 35.131 35.66889290804651 139.73916089809612 34.886 35.66889077422985 139.73916401558952 34.886 35.66889077422985 139.73916401558952 35.131 35.66889290804651 139.73916089809612 35.131</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ae094d6f-5a69-472f-8cdf-4c32ac56b067">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ae094d6f-5a69-472f-8cdf-4c32ac56b067">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ae094d6f-5a69-472f-8cdf-4c32ac56b067">
											<gml:posList>35.66889118427021 139.7391696706877 12.84 35.66889541588338 139.73916347992753 12.84 35.66889541588338 139.73916347992753 35.131 35.66889118427021 139.7391696706877 35.131 35.66889118427021 139.7391696706877 12.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-3902</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">188.3377</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.06</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>