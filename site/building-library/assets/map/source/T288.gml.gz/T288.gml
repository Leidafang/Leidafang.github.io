<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_53195a29-8abf-44f1-8a3f-6b86df8fd392">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">14.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66823847013435 139.73867193284067 0 35.66818535199533 139.73875196827734 0 35.668298472729596 139.73886472468382 0 35.66835159094251 139.7387846892086 0 35.66823847013435 139.73867193284067 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66823847013435 139.73867193284067 14.09 35.66835159094251 139.7387846892086 14.09 35.668298472729596 139.73886472468382 14.09 35.66818535199533 139.73875196827734 14.09 35.66823847013435 139.73867193284067 14.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66823847013435 139.73867193284067 14.09 35.66818535199533 139.73875196827734 14.09 35.66818535199533 139.73875196827734 28.96 35.66823847013435 139.73867193284067 28.96 35.66823847013435 139.73867193284067 14.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66818535199533 139.73875196827734 14.09 35.668298472729596 139.73886472468382 14.09 35.668298472729596 139.73886472468382 28.96 35.66818535199533 139.73875196827734 28.96 35.66818535199533 139.73875196827734 14.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668298472729596 139.73886472468382 14.09 35.66835159094251 139.7387846892086 14.09 35.66835159094251 139.7387846892086 28.96 35.668298472729596 139.73886472468382 28.96 35.668298472729596 139.73886472468382 14.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66835159094251 139.7387846892086 14.09 35.66823847013435 139.73867193284067 14.09 35.66823847013435 139.73867193284067 28.96 35.66835159094251 139.7387846892086 28.96 35.66835159094251 139.7387846892086 14.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66823847013435 139.73867193284067 28.96 35.66818535199533 139.73875196827734 28.96 35.668298472729596 139.73886472468382 28.96 35.66835159094251 139.7387846892086 28.96 35.66823847013435 139.73867193284067 28.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-40143a78-e73e-44ba-9335-f02da2597eff"/>
							<gml:surfaceMember xlink:href="#poly-fce553c6-4fc1-4af8-818b-75b177901ffb"/>
							<gml:surfaceMember xlink:href="#poly-64e5fa67-1774-411f-af83-6d1309416fdb"/>
							<gml:surfaceMember xlink:href="#poly-aef4b9d2-f30f-4462-b10e-50c594360ff5"/>
							<gml:surfaceMember xlink:href="#poly-6fe9ab67-36fc-40c3-a59a-0cf2f479ae4e"/>
							<gml:surfaceMember xlink:href="#poly-1c2e46ff-0e08-4f17-8c3c-9a234980a3e3"/>
							<gml:surfaceMember xlink:href="#poly-cc69c0e9-0f4e-45d9-83a4-4925b5583f53"/>
							<gml:surfaceMember xlink:href="#poly-93b8b430-ad9b-437f-85ed-26bcb9e52483"/>
							<gml:surfaceMember xlink:href="#poly-72f926a8-59fc-48b4-8124-1c4758949ba4"/>
							<gml:surfaceMember xlink:href="#poly-cd591e17-c631-45eb-b9c3-21b91e948348"/>
							<gml:surfaceMember xlink:href="#poly-956cff1e-d24c-4929-92e2-4a349e12d42b"/>
							<gml:surfaceMember xlink:href="#poly-3e3c1324-bac1-4c70-86e5-4e5f533b5205"/>
							<gml:surfaceMember xlink:href="#poly-72830178-3e5b-45c3-bb49-cfdc980f4f12"/>
							<gml:surfaceMember xlink:href="#poly-9e7bf11d-2418-43aa-9adb-dc7d72f64789"/>
							<gml:surfaceMember xlink:href="#poly-be331d49-3342-49f1-94d1-2e3359978a6d"/>
							<gml:surfaceMember xlink:href="#poly-784a0c4c-e0c1-4001-a03d-14d550c2d785"/>
							<gml:surfaceMember xlink:href="#poly-95cdd8ee-a2d1-43cb-996a-76a8c41430d3"/>
							<gml:surfaceMember xlink:href="#poly-e9238400-4367-421d-ae7f-74c7903ca8cd"/>
							<gml:surfaceMember xlink:href="#poly-96b5b33c-e87e-40d5-9380-f582570965fa"/>
							<gml:surfaceMember xlink:href="#poly-fc128c8e-0fe8-418c-9828-938d6aa1245e"/>
							<gml:surfaceMember xlink:href="#poly-4d269f20-dfe6-4aa7-b045-8f3360caa9bd"/>
							<gml:surfaceMember xlink:href="#poly-10795c4c-7404-4639-bd7c-beb852132c4e"/>
							<gml:surfaceMember xlink:href="#poly-91f0cccc-09e9-4cac-8663-67d275366ff0"/>
							<gml:surfaceMember xlink:href="#poly-a1ac92d6-76be-43fd-875f-afd4db14542f"/>
							<gml:surfaceMember xlink:href="#poly-058502a4-4440-4eb3-8df7-014fee921051"/>
							<gml:surfaceMember xlink:href="#poly-db5b9d8f-26f3-4660-aefd-85638f0f6919"/>
							<gml:surfaceMember xlink:href="#poly-9429cf99-b9d4-4505-812c-f0ae96c14bde"/>
							<gml:surfaceMember xlink:href="#poly-efea7bfd-47af-4cd0-a52b-73a7c31adbd1"/>
							<gml:surfaceMember xlink:href="#poly-535baa1f-e6b6-4106-99a5-ebf83a7d2b47"/>
							<gml:surfaceMember xlink:href="#poly-0e9f4b3e-f544-479e-b121-6eaf28135c21"/>
							<gml:surfaceMember xlink:href="#poly-f509f9ee-112b-41df-8ee6-5497ca79917d"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_53195a29-8abf-44f1-8a3f-6b86df8fd392_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ca30d32-5f53-45d5-832f-f140b0ed7ca1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0ca30d32-5f53-45d5-832f-f140b0ed7ca1_0">
											<gml:posList>35.66825432870598 139.7386877429886 31.856 35.66826866275799 139.73870203059832 31.856 35.66825432870598 139.7386877429886 28.285 35.66825432870598 139.7386877429886 31.856</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-edcbfa51-ff45-43cf-9257-87c8209a333b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-edcbfa51-ff45-43cf-9257-87c8209a333b_0">
											<gml:posList>35.668236088443784 139.73871518060096 28.289 35.668236088443784 139.73871518060096 31.856 35.66825432870598 139.7386877429886 31.856 35.66825432870598 139.7386877429886 28.285 35.668236088443784 139.73871518060096 28.289</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf99cfda-99aa-4e96-a5bf-368a7458535c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bf99cfda-99aa-4e96-a5bf-368a7458535c_0">
											<gml:posList>35.6682505758127 139.73872957849113 31.856 35.668236088443784 139.73871518060096 28.289 35.66825432870598 139.7386877429886 28.285 35.66826866275799 139.73870203059832 31.856 35.6682505758127 139.73872957849113 31.856</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd1a5b97-a64e-4745-983c-f1a3932a1b0e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dd1a5b97-a64e-4745-983c-f1a3932a1b0e_0">
											<gml:posList>35.6682505758127 139.73872957849113 31.856 35.66826866275799 139.73870203059832 31.856 35.66825432870598 139.7386877429886 31.856 35.668236088443784 139.73871518060096 31.856 35.6682505758127 139.73872957849113 31.856</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1bc9b9ca-4f0d-49ac-a047-8c5e3ad2ece5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1bc9b9ca-4f0d-49ac-a047-8c5e3ad2ece5_0">
											<gml:posList>35.668236088443784 139.73871518060096 28.289 35.6682505758127 139.73872957849113 31.856 35.668236088443784 139.73871518060096 31.856 35.668236088443784 139.73871518060096 28.289</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-40143a78-e73e-44ba-9335-f02da2597eff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-40143a78-e73e-44ba-9335-f02da2597eff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-40143a78-e73e-44ba-9335-f02da2597eff">
											<gml:posList>35.66823847013434 139.73867193284065 14.09 35.66835159094249 139.7387846892086 14.09 35.66829847272959 139.7388647246838 14.09 35.66818535199533 139.73875196827734 14.09 35.66823847013434 139.73867193284065 14.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fce553c6-4fc1-4af8-818b-75b177901ffb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fce553c6-4fc1-4af8-818b-75b177901ffb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fce553c6-4fc1-4af8-818b-75b177901ffb">
											<gml:posList>35.66823039701714 139.7387677661013 32.583 35.66819697496213 139.73873444672319 24.119 35.66818535199533 139.73875196827734 24.119 35.66821877404555 139.73878528765792 32.583 35.66823039701714 139.7387677661013 32.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-64e5fa67-1774-411f-af83-6d1309416fdb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-64e5fa67-1774-411f-af83-6d1309416fdb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-64e5fa67-1774-411f-af83-6d1309416fdb">
											<gml:posList>35.66824867245869 139.73872772501454 32.583 35.66822024792051 139.73869939252182 24.119 35.66819697496213 139.73873444672319 24.119 35.66822539949218 139.73876277922017 32.583 35.66824867245869 139.73872772501454 32.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-aef4b9d2-f30f-4462-b10e-50c594360ff5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aef4b9d2-f30f-4462-b10e-50c594360ff5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aef4b9d2-f30f-4462-b10e-50c594360ff5">
											<gml:posList>35.66823039701714 139.7387677661013 32.583 35.66821877404555 139.73878528765792 32.583 35.668221450861836 139.73878495312275 32.583 35.66823307383336 139.73876743156546 32.583 35.66823039701714 139.7387677661013 32.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6fe9ab67-36fc-40c3-a59a-0cf2f479ae4e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6fe9ab67-36fc-40c3-a59a-0cf2f479ae4e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6fe9ab67-36fc-40c3-a59a-0cf2f479ae4e">
											<gml:posList>35.66823039701714 139.7387677661013 32.583 35.66823307383336 139.73876743156546 32.583 35.6682280763084 139.7387624446842 32.583 35.66822539949218 139.73876277922017 32.583 35.66823039701714 139.7387677661013 32.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1c2e46ff-0e08-4f17-8c3c-9a234980a3e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c2e46ff-0e08-4f17-8c3c-9a234980a3e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c2e46ff-0e08-4f17-8c3c-9a234980a3e3">
											<gml:posList>35.66824820888115 139.7388146131266 32.583 35.66824794491666 139.73881134383194 32.583 35.668221450861836 139.73878495312275 32.583 35.66821877404555 139.73878528765792 32.583 35.66824820888115 139.7388146131266 32.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cc69c0e9-0f4e-45d9-83a4-4925b5583f53">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc69c0e9-0f4e-45d9-83a4-4925b5583f53">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc69c0e9-0f4e-45d9-83a4-4925b5583f53">
											<gml:posList>35.66822539949218 139.73876277922017 32.583 35.6682280763084 139.7387624446842 32.583 35.668248954461596 139.73873100533365 32.583 35.66824867245869 139.73872772501454 32.583 35.66822539949218 139.73876277922017 32.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-93b8b430-ad9b-437f-85ed-26bcb9e52483">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-93b8b430-ad9b-437f-85ed-26bcb9e52483">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-93b8b430-ad9b-437f-85ed-26bcb9e52483">
											<gml:posList>35.66827244246899 139.73870579281297 32.583 35.66823847013434 139.73867193284065 24.119 35.66822024792051 139.73869939252182 24.119 35.66825430144049 139.73873334077004 32.583 35.66827244246899 139.73870579281297 32.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-72f926a8-59fc-48b4-8124-1c4758949ba4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-72f926a8-59fc-48b4-8124-1c4758949ba4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-72f926a8-59fc-48b4-8124-1c4758949ba4">
											<gml:posList>35.66825430144049 139.73873334077004 32.583 35.66824867245869 139.73872772501454 32.583 35.668248954461596 139.73873100533365 32.583 35.668254583451926 139.73873663213533 32.583 35.66825430144049 139.73873334077004 32.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cd591e17-c631-45eb-b9c3-21b91e948348">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd591e17-c631-45eb-b9c3-21b91e948348">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd591e17-c631-45eb-b9c3-21b91e948348">
											<gml:posList>35.668254583451926 139.73873663213533 32.436 35.668248954461596 139.73873100533365 32.436 35.6682280763084 139.7387624446842 32.436 35.66823307383336 139.73876743156546 32.436 35.668221450861836 139.73878495312275 32.436 35.66824794491666 139.73881134383194 32.436 35.66829874948287 139.73873502254838 32.436 35.66827272448116 139.7387090841789 32.436 35.668254583451926 139.73873663213533 32.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-956cff1e-d24c-4929-92e2-4a349e12d42b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-956cff1e-d24c-4929-92e2-4a349e12d42b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-956cff1e-d24c-4929-92e2-4a349e12d42b">
											<gml:posList>35.66825430144049 139.73873334077004 32.583 35.668254583451926 139.73873663213533 32.583 35.66827272448116 139.7387090841789 32.583 35.66827244246899 139.73870579281297 32.583 35.66825430144049 139.73873334077004 32.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3e3c1324-bac1-4c70-86e5-4e5f533b5205">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e3c1324-bac1-4c70-86e5-4e5f533b5205">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e3c1324-bac1-4c70-86e5-4e5f533b5205">
											<gml:posList>35.668301417276574 139.7387346769758 32.583 35.66829874948287 139.73873502254838 32.583 35.66824794491666 139.73881134383194 32.583 35.66824820888115 139.7388146131266 32.583 35.668301417276574 139.7387346769758 32.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-72830178-3e5b-45c3-bb49-cfdc980f4f12">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-72830178-3e5b-45c3-bb49-cfdc980f4f12">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-72830178-3e5b-45c3-bb49-cfdc980f4f12">
											<gml:posList>35.66827244246899 139.73870579281297 32.583 35.66827272448116 139.7387090841789 32.583 35.66829874948287 139.73873502254838 32.583 35.668301417276574 139.7387346769758 32.583 35.66827244246899 139.73870579281297 32.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9e7bf11d-2418-43aa-9adb-dc7d72f64789">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e7bf11d-2418-43aa-9adb-dc7d72f64789">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e7bf11d-2418-43aa-9adb-dc7d72f64789">
											<gml:posList>35.668301417276574 139.7387346769758 32.583 35.66824820888115 139.7388146131266 32.583 35.668279709482135 139.73884601282478 26.847 35.66833283670518 139.7387659883913 26.847 35.668301417276574 139.7387346769758 32.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-be331d49-3342-49f1-94d1-2e3359978a6d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-be331d49-3342-49f1-94d1-2e3359978a6d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-be331d49-3342-49f1-94d1-2e3359978a6d">
											<gml:posList>35.668293556401544 139.73885982606447 24.119 35.66834668363363 139.7387798016263 24.119 35.66833283670518 139.7387659883913 24.119 35.668279709482135 139.73884601282478 24.119 35.668293556401544 139.73885982606447 24.119</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-784a0c4c-e0c1-4001-a03d-14d550c2d785">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-784a0c4c-e0c1-4001-a03d-14d550c2d785">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-784a0c4c-e0c1-4001-a03d-14d550c2d785">
											<gml:posList>35.668293556401544 139.73885982606447 24.119 35.66829847272959 139.7388647246838 22.265 35.66835159094249 139.7387846892086 22.265 35.66834668363363 139.7387798016263 24.119 35.668293556401544 139.73885982606447 24.119</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-95cdd8ee-a2d1-43cb-996a-76a8c41430d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-95cdd8ee-a2d1-43cb-996a-76a8c41430d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-95cdd8ee-a2d1-43cb-996a-76a8c41430d3">
											<gml:posList>35.66824794491666 139.73881134383194 32.583 35.66824794491666 139.73881134383194 32.436 35.668221450861836 139.73878495312275 32.436 35.668221450861836 139.73878495312275 32.583 35.66824794491666 139.73881134383194 32.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e9238400-4367-421d-ae7f-74c7903ca8cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e9238400-4367-421d-ae7f-74c7903ca8cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e9238400-4367-421d-ae7f-74c7903ca8cd">
											<gml:posList>35.66823847013434 139.73867193284065 14.09 35.66818535199533 139.73875196827734 14.09 35.66818535199533 139.73875196827734 24.119 35.66819697496213 139.73873444672319 24.119 35.66822024792051 139.73869939252182 24.119 35.66823847013434 139.73867193284065 24.119 35.66823847013434 139.73867193284065 14.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-96b5b33c-e87e-40d5-9380-f582570965fa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96b5b33c-e87e-40d5-9380-f582570965fa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96b5b33c-e87e-40d5-9380-f582570965fa">
											<gml:posList>35.66823039701714 139.7387677661013 32.583 35.66822539949218 139.73876277922017 32.583 35.66819697496213 139.73873444672319 24.119 35.66823039701714 139.7387677661013 32.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fc128c8e-0fe8-418c-9828-938d6aa1245e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc128c8e-0fe8-418c-9828-938d6aa1245e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc128c8e-0fe8-418c-9828-938d6aa1245e">
											<gml:posList>35.668221450861836 139.73878495312275 32.583 35.668221450861836 139.73878495312275 32.436 35.66823307383336 139.73876743156546 32.436 35.66823307383336 139.73876743156546 32.583 35.668221450861836 139.73878495312275 32.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4d269f20-dfe6-4aa7-b045-8f3360caa9bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d269f20-dfe6-4aa7-b045-8f3360caa9bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d269f20-dfe6-4aa7-b045-8f3360caa9bd">
											<gml:posList>35.66823307383336 139.73876743156546 32.583 35.66823307383336 139.73876743156546 32.436 35.6682280763084 139.7387624446842 32.436 35.6682280763084 139.7387624446842 32.583 35.66823307383336 139.73876743156546 32.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-10795c4c-7404-4639-bd7c-beb852132c4e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-10795c4c-7404-4639-bd7c-beb852132c4e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-10795c4c-7404-4639-bd7c-beb852132c4e">
											<gml:posList>35.66822024792051 139.73869939252182 24.119 35.66824867245869 139.73872772501454 32.583 35.66825430144049 139.73873334077004 32.583 35.66822024792051 139.73869939252182 24.119</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-91f0cccc-09e9-4cac-8663-67d275366ff0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-91f0cccc-09e9-4cac-8663-67d275366ff0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-91f0cccc-09e9-4cac-8663-67d275366ff0">
											<gml:posList>35.6682280763084 139.7387624446842 32.583 35.6682280763084 139.7387624446842 32.436 35.668248954461596 139.73873100533365 32.436 35.668248954461596 139.73873100533365 32.583 35.6682280763084 139.7387624446842 32.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a1ac92d6-76be-43fd-875f-afd4db14542f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a1ac92d6-76be-43fd-875f-afd4db14542f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a1ac92d6-76be-43fd-875f-afd4db14542f">
											<gml:posList>35.66829847272959 139.7388647246838 14.09 35.66829847272959 139.7388647246838 22.265 35.668293556401544 139.73885982606447 24.119 35.668279709482135 139.73884601282478 24.119 35.668279709482135 139.73884601282478 26.847 35.66824820888115 139.7388146131266 32.583 35.66821877404555 139.73878528765792 32.583 35.66818535199533 139.73875196827734 24.119 35.66818535199533 139.73875196827734 14.09 35.66829847272959 139.7388647246838 14.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-058502a4-4440-4eb3-8df7-014fee921051">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-058502a4-4440-4eb3-8df7-014fee921051">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-058502a4-4440-4eb3-8df7-014fee921051">
											<gml:posList>35.668248954461596 139.73873100533365 32.583 35.668248954461596 139.73873100533365 32.436 35.668254583451926 139.73873663213533 32.436 35.668254583451926 139.73873663213533 32.583 35.668248954461596 139.73873100533365 32.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-db5b9d8f-26f3-4660-aefd-85638f0f6919">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db5b9d8f-26f3-4660-aefd-85638f0f6919">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db5b9d8f-26f3-4660-aefd-85638f0f6919">
											<gml:posList>35.668254583451926 139.73873663213533 32.583 35.668254583451926 139.73873663213533 32.436 35.66827272448116 139.7387090841789 32.436 35.66827272448116 139.7387090841789 32.583 35.668254583451926 139.73873663213533 32.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9429cf99-b9d4-4505-812c-f0ae96c14bde">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9429cf99-b9d4-4505-812c-f0ae96c14bde">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9429cf99-b9d4-4505-812c-f0ae96c14bde">
											<gml:posList>35.66829874948287 139.73873502254838 32.583 35.66829874948287 139.73873502254838 32.436 35.66824794491666 139.73881134383194 32.436 35.66824794491666 139.73881134383194 32.583 35.66829874948287 139.73873502254838 32.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-efea7bfd-47af-4cd0-a52b-73a7c31adbd1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-efea7bfd-47af-4cd0-a52b-73a7c31adbd1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-efea7bfd-47af-4cd0-a52b-73a7c31adbd1">
											<gml:posList>35.66827272448116 139.7387090841789 32.583 35.66827272448116 139.7387090841789 32.436 35.66829874948287 139.73873502254838 32.436 35.66829874948287 139.73873502254838 32.583 35.66827272448116 139.7387090841789 32.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-535baa1f-e6b6-4106-99a5-ebf83a7d2b47">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-535baa1f-e6b6-4106-99a5-ebf83a7d2b47">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-535baa1f-e6b6-4106-99a5-ebf83a7d2b47">
											<gml:posList>35.66827244246899 139.73870579281297 32.583 35.668301417276574 139.7387346769758 32.583 35.66833283670518 139.7387659883913 26.847 35.66833283670518 139.7387659883913 24.119 35.66834668363363 139.7387798016263 24.119 35.66835159094249 139.7387846892086 22.265 35.66835159094249 139.7387846892086 14.09 35.66823847013434 139.73867193284065 14.09 35.66823847013434 139.73867193284065 24.119 35.66827244246899 139.73870579281297 32.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0e9f4b3e-f544-479e-b121-6eaf28135c21">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e9f4b3e-f544-479e-b121-6eaf28135c21">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e9f4b3e-f544-479e-b121-6eaf28135c21">
											<gml:posList>35.66833283670518 139.7387659883913 24.119 35.66833283670518 139.7387659883913 26.847 35.668279709482135 139.73884601282478 26.847 35.668279709482135 139.73884601282478 24.119 35.66833283670518 139.7387659883913 24.119</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f509f9ee-112b-41df-8ee6-5497ca79917d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f509f9ee-112b-41df-8ee6-5497ca79917d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f509f9ee-112b-41df-8ee6-5497ca79917d">
											<gml:posList>35.66829847272959 139.7388647246838 14.09 35.66835159094249 139.7387846892086 14.09 35.66835159094249 139.7387846892086 22.265 35.66829847272959 139.7388647246838 22.265 35.66829847272959 139.7388647246838 14.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-761</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">151.0876</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingLandSlideRiskAttribute>
					<uro:description codeSpace="../../codelists/LandSlideRiskAttribute_description.xml">1</uro:description>
					<uro:areaType codeSpace="../../codelists/LandSlideRiskAttribute_areaType.xml">1</uro:areaType>
				</uro:BuildingLandSlideRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>