<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_53e1dc96-c46f-4ff6-a76e-a3a676c2c8c3">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">25.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.669058025251246 139.74837582814197 0 35.66911031085239 139.748256585482 0 35.669026628808474 139.74820762970575 0 35.668983080175266 139.74831780523482 0 35.66898931298106 139.74833668740354 0 35.669058025251246 139.74837582814197 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669058025251246 139.74837582814197 5.66 35.66898931298106 139.74833668740354 5.66 35.668983080175266 139.74831780523482 5.66 35.669026628808474 139.74820762970575 5.66 35.66911031085239 139.748256585482 5.66 35.669058025251246 139.74837582814197 5.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669058025251246 139.74837582814197 5.66 35.66911031085239 139.748256585482 5.66 35.66911031085239 139.748256585482 31.41 35.669058025251246 139.74837582814197 31.41 35.669058025251246 139.74837582814197 5.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66911031085239 139.748256585482 5.66 35.669026628808474 139.74820762970575 5.66 35.669026628808474 139.74820762970575 31.41 35.66911031085239 139.748256585482 31.41 35.66911031085239 139.748256585482 5.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669026628808474 139.74820762970575 5.66 35.668983080175266 139.74831780523482 5.66 35.668983080175266 139.74831780523482 31.41 35.669026628808474 139.74820762970575 31.41 35.669026628808474 139.74820762970575 5.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668983080175266 139.74831780523482 5.66 35.66898931298106 139.74833668740354 5.66 35.66898931298106 139.74833668740354 31.41 35.668983080175266 139.74831780523482 31.41 35.668983080175266 139.74831780523482 5.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66898931298106 139.74833668740354 5.66 35.669058025251246 139.74837582814197 5.66 35.669058025251246 139.74837582814197 31.41 35.66898931298106 139.74833668740354 31.41 35.66898931298106 139.74833668740354 5.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669058025251246 139.74837582814197 31.41 35.66911031085239 139.748256585482 31.41 35.669026628808474 139.74820762970575 31.41 35.668983080175266 139.74831780523482 31.41 35.66898931298106 139.74833668740354 31.41 35.669058025251246 139.74837582814197 31.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-2aaf4c4d-7366-4bae-9aa5-3e3cce809405"/>
							<gml:surfaceMember xlink:href="#poly-ef3ec47e-a912-4983-b030-85ac3d77317f"/>
							<gml:surfaceMember xlink:href="#poly-1ec8dfad-60e7-4aef-8f8c-d0d0d2e89b24"/>
							<gml:surfaceMember xlink:href="#poly-b6964b61-543f-4eed-a86b-c73930fd5cac"/>
							<gml:surfaceMember xlink:href="#poly-d780c045-ac51-414f-9849-8a2d3468ac2b"/>
							<gml:surfaceMember xlink:href="#poly-fb08b777-4360-4089-862b-0cded7fd19da"/>
							<gml:surfaceMember xlink:href="#poly-844b4b44-f73e-42a5-8b53-bd83a42ff953"/>
							<gml:surfaceMember xlink:href="#poly-0dc7a6e3-f2d7-4eae-bcb8-9791d6beb8ac"/>
							<gml:surfaceMember xlink:href="#poly-2c972734-eca1-4674-86c9-6033e01d75d1"/>
							<gml:surfaceMember xlink:href="#poly-e00eb737-4d12-4c8b-804c-057cf5ff9c26"/>
							<gml:surfaceMember xlink:href="#poly-03d51893-b29d-4310-857d-b99240486c6a"/>
							<gml:surfaceMember xlink:href="#poly-6f16c1c8-69e8-4750-9924-b18cd0a04e21"/>
							<gml:surfaceMember xlink:href="#poly-0eebf3ce-aa67-46b9-8247-959af673b16f"/>
							<gml:surfaceMember xlink:href="#poly-d263517a-178b-410a-a053-01556a92914f"/>
							<gml:surfaceMember xlink:href="#poly-a8ac9e6b-0d53-499c-a619-16f4fe78a39e"/>
							<gml:surfaceMember xlink:href="#poly-1adef77f-3b25-4f03-a21e-8e1fd0c73b86"/>
							<gml:surfaceMember xlink:href="#poly-50f2d1c8-b35b-47a8-bac7-ecd5736eae89"/>
							<gml:surfaceMember xlink:href="#poly-e9f7dd5b-73e5-4f78-a0cc-f3f92c3b9ff1"/>
							<gml:surfaceMember xlink:href="#poly-f48b8f26-7705-4450-bc02-8e530d18ef2f"/>
							<gml:surfaceMember xlink:href="#poly-402d6b8b-ac55-43e9-bb98-d5436eef7b65"/>
							<gml:surfaceMember xlink:href="#poly-cbd8f22e-4ca9-492f-afd3-8b79f1058038"/>
							<gml:surfaceMember xlink:href="#poly-b14e9803-500e-4a8d-b56f-b62ef6ecbae7"/>
							<gml:surfaceMember xlink:href="#poly-031d6d11-17b2-40a3-8477-66cb11f6ce2d"/>
							<gml:surfaceMember xlink:href="#poly-e956bba5-ffc5-48ae-93cb-36c1f4f15143"/>
							<gml:surfaceMember xlink:href="#poly-57279159-6569-4d96-9e93-e89e2133d0bc"/>
							<gml:surfaceMember xlink:href="#poly-878c1ca9-45c7-4a86-8da4-556137d7a9eb"/>
							<gml:surfaceMember xlink:href="#poly-f11e8970-f460-4642-a3e8-ee8027ef00d6"/>
							<gml:surfaceMember xlink:href="#poly-960df5aa-c8f2-4765-b233-4bdde0fde195"/>
							<gml:surfaceMember xlink:href="#poly-d598477b-fca6-418c-8ba3-90125afcd813"/>
							<gml:surfaceMember xlink:href="#poly-d8e7e9d3-5c38-4f69-bca4-184cdfa29857"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_53e1dc96-c46f-4ff6-a76e-a3a676c2c8c3_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18b52193-0a74-46ed-a596-1e351043084c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66908117883416 139.7482953881378 34.568 35.66908126044916 139.74829608395436 34.568 35.6690812969955 139.74829677981873 34.568 35.66908128848102 139.74829748677695 34.568 35.66908122588417 139.74829819379255 34.568 35.669081109189364 139.74829887877334 34.568 35.66908094741811 139.74829955275584 34.568 35.669080731548895 139.74830020470358 34.568 35.66908047960917 139.7483008345974 34.568 35.66908017357148 139.74830144245638 34.568 35.669079840461414 139.74830200615978 34.568 35.66907945323778 139.74830252573625 34.568 35.669079038949555 139.74830301220314 34.568 35.66907858857524 139.748303454524 34.568 35.66907811112073 139.74830384164315 34.568 35.66907760658604 139.74830417356063 34.568 35.669077083992704 139.7483044613129 34.568 35.66907653431138 139.74830468281743 34.568 35.66907597557733 139.74830484910115 34.568 35.669075407782756 139.748304949118 34.568 35.66907483994918 139.74830499390447 34.568 35.66907426305508 139.74830497242408 34.568 35.66907369513571 139.74830489570377 34.568 35.66907312716954 139.748304752707 34.568 35.66907257719182 139.7483045544608 34.568 35.66907204520255 139.74830430096512 34.568 35.66907153120172 139.74830399221995 34.568 35.66907104419529 139.74830361716968 34.568 35.66907057518511 139.74830319791604 34.568 35.66907015121235 139.7483027344303 34.568 35.66906975424958 139.7483022267316 34.568 35.6690693933105 139.7483016748104 34.568 35.66906907741666 139.74830108970318 34.568 35.66906880656804 139.74830047140998 34.568 35.66906857175093 139.74829981994029 34.568 35.66906839100837 139.7482991573672 34.568 35.66906825531884 139.74829847265417 34.568 35.66906817370387 139.74829777683772 34.568 35.66906813714972 139.74829706992742 34.568 35.66906815468573 139.7482963740058 34.568 35.66906821728257 139.74829566699034 34.568 35.669068333977364 139.74829498200964 34.568 35.66906849574859 139.7482943080272 34.568 35.66906870260405 139.74829365608915 34.568 35.669068963557464 139.74829302618585 34.568 35.66906926058138 139.74829241833646 34.568 35.66906960270513 139.74829185462355 34.568 35.66906998091499 139.74829133505665 34.568 35.669070395203164 139.74829084858973 34.568 35.66907084557744 139.74829040626886 34.568 35.6690713230319 139.74829001914966 34.568 35.66907183658028 139.74828968722255 34.568 35.66907235917358 139.7482893994702 34.568 35.669072899841154 139.74828917797515 34.568 35.66907345857518 139.74828901169133 34.568 35.66907402636975 139.7482889116744 34.568 35.669074603217034 139.74828886687823 34.568 35.669075180103334 139.74828887731243 34.568 35.66907574803053 139.7482889650787 34.568 35.669076306975185 139.74828909703882 34.568 35.669076856960736 139.748289306331 34.568 35.66907739796377 139.74828955981704 34.568 35.66907790295088 139.7482898685717 34.568 35.66907839897109 139.74829024361236 34.568 35.669078858967595 139.74829066287555 34.568 35.66907929195413 139.7482911263517 34.568 35.66907968891694 139.74829163405042 34.568 35.66908004084233 139.7482921859812 34.568 35.66908035673622 139.74829277108847 34.568 35.66908063659861 139.74829338937218 34.568 35.66908086240202 139.74829404085148 34.568 35.669081043144615 139.74829470342468 34.568 35.66908117883416 139.7482953881378 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aca2d12e-3623-4ecb-8753-f23ed24ec692">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aca2d12e-3623-4ecb-8753-f23ed24ec692_0">
											<gml:posList>35.669074603217034 139.74828886687823 34.568 35.669074603217034 139.74828886687823 37.125 35.669075180103334 139.74828887731243 37.125 35.669075180103334 139.74828887731243 34.568 35.669074603217034 139.74828886687823 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84f2e205-fafe-4859-ad77-83deeb8bc4df">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-84f2e205-fafe-4859-ad77-83deeb8bc4df_0">
											<gml:posList>35.66907402636975 139.7482889116744 34.568 35.66907402636975 139.7482889116744 37.125 35.669074603217034 139.74828886687823 37.125 35.669074603217034 139.74828886687823 34.568 35.66907402636975 139.7482889116744 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de15acad-c6dd-4005-9a77-30734de6b913">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de15acad-c6dd-4005-9a77-30734de6b913_0">
											<gml:posList>35.669075180103334 139.74828887731243 37.125 35.66907574803053 139.7482889650787 37.125 35.66907574803053 139.7482889650787 34.568 35.669075180103334 139.74828887731243 34.568 35.669075180103334 139.74828887731243 37.125</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ffe6432c-341f-441f-bec0-2c874dad9c6d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ffe6432c-341f-441f-bec0-2c874dad9c6d_0">
											<gml:posList>35.66907345857518 139.74828901169133 37.125 35.66907402636975 139.7482889116744 37.125 35.66907402636975 139.7482889116744 34.568 35.66907345857518 139.74828901169133 34.568 35.66907345857518 139.74828901169133 37.125</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ee7e44ff-d59f-473a-9588-744158ca255c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ee7e44ff-d59f-473a-9588-744158ca255c_0">
											<gml:posList>35.66907574803053 139.7482889650787 34.568 35.66907574803053 139.7482889650787 37.125 35.669076306975185 139.74828909703882 37.125 35.669076306975185 139.74828909703882 34.568 35.66907574803053 139.7482889650787 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-49e4aad4-2cce-4f68-acf2-a6fb9a3ee2ee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-49e4aad4-2cce-4f68-acf2-a6fb9a3ee2ee_0">
											<gml:posList>35.669072899841154 139.74828917797515 37.125 35.66907345857518 139.74828901169133 37.125 35.66907345857518 139.74828901169133 34.568 35.669072899841154 139.74828917797515 34.568 35.669072899841154 139.74828917797515 37.125</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b62e516-eb26-4471-9021-d41de30e99e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4b62e516-eb26-4471-9021-d41de30e99e4_0">
											<gml:posList>35.669076306975185 139.74828909703882 34.568 35.669076306975185 139.74828909703882 37.125 35.669076856960736 139.748289306331 37.125 35.669076856960736 139.748289306331 34.568 35.669076306975185 139.74828909703882 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-15b04b5c-70a3-4d0d-b97f-b26ec8195777">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-15b04b5c-70a3-4d0d-b97f-b26ec8195777_0">
											<gml:posList>35.66907235917358 139.7482893994702 34.568 35.66907235917358 139.7482893994702 37.125 35.669072899841154 139.74828917797515 37.125 35.669072899841154 139.74828917797515 34.568 35.66907235917358 139.7482893994702 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d552b9a2-7f5b-46db-a44c-50633516cf6b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d552b9a2-7f5b-46db-a44c-50633516cf6b_0">
											<gml:posList>35.669076856960736 139.748289306331 34.568 35.669076856960736 139.748289306331 37.125 35.66907739796377 139.74828955981704 37.125 35.66907739796377 139.74828955981704 34.568 35.669076856960736 139.748289306331 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3599f585-774a-46f9-8d68-89a616470ee5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3599f585-774a-46f9-8d68-89a616470ee5_0">
											<gml:posList>35.66907183658028 139.74828968722255 34.568 35.66907183658028 139.74828968722255 37.125 35.66907235917358 139.7482893994702 37.125 35.66907235917358 139.7482893994702 34.568 35.66907183658028 139.74828968722255 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8bbbeaf9-76a3-46c5-a125-1d85173e4946">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8bbbeaf9-76a3-46c5-a125-1d85173e4946_0">
											<gml:posList>35.66907739796377 139.74828955981704 34.568 35.66907739796377 139.74828955981704 37.125 35.66907790295088 139.7482898685717 37.125 35.66907790295088 139.7482898685717 34.568 35.66907739796377 139.74828955981704 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe8d678b-24b4-43be-b139-aa8eb82cdfa2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe8d678b-24b4-43be-b139-aa8eb82cdfa2_0">
											<gml:posList>35.6690713230319 139.74829001914966 34.568 35.6690713230319 139.74829001914966 37.125 35.66907183658028 139.74828968722255 37.125 35.66907183658028 139.74828968722255 34.568 35.6690713230319 139.74829001914966 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b6d0082e-3dac-48f7-8a27-01ff25627e6d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b6d0082e-3dac-48f7-8a27-01ff25627e6d_0">
											<gml:posList>35.66907790295088 139.7482898685717 34.568 35.66907790295088 139.7482898685717 37.125 35.66907839897109 139.74829024361236 37.125 35.66907839897109 139.74829024361236 34.568 35.66907790295088 139.7482898685717 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1230f45e-5b23-4f12-ac66-986d239c6162">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1230f45e-5b23-4f12-ac66-986d239c6162_0">
											<gml:posList>35.66907084557744 139.74829040626886 34.568 35.66907084557744 139.74829040626886 37.125 35.6690713230319 139.74829001914966 37.125 35.6690713230319 139.74829001914966 34.568 35.66907084557744 139.74829040626886 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d3de75cf-27c1-462c-9fdc-2d504d33f96f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d3de75cf-27c1-462c-9fdc-2d504d33f96f_0">
											<gml:posList>35.66907839897109 139.74829024361236 34.568 35.66907839897109 139.74829024361236 37.125 35.669078858967595 139.74829066287555 37.125 35.669078858967595 139.74829066287555 34.568 35.66907839897109 139.74829024361236 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce1c0eb1-c701-4f77-843d-72d13cf5cd7e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce1c0eb1-c701-4f77-843d-72d13cf5cd7e_0">
											<gml:posList>35.669070395203164 139.74829084858973 34.568 35.669070395203164 139.74829084858973 37.125 35.66907084557744 139.74829040626886 37.125 35.66907084557744 139.74829040626886 34.568 35.669070395203164 139.74829084858973 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c12b19e4-0cf1-43ce-a5a7-5735db97d8d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c12b19e4-0cf1-43ce-a5a7-5735db97d8d4_0">
											<gml:posList>35.669078858967595 139.74829066287555 34.568 35.669078858967595 139.74829066287555 37.125 35.66907929195413 139.7482911263517 37.125 35.66907929195413 139.7482911263517 34.568 35.669078858967595 139.74829066287555 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b56ad287-297f-4a75-bc09-ec78a30a59c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b56ad287-297f-4a75-bc09-ec78a30a59c9_0">
											<gml:posList>35.66906998091499 139.74829133505665 34.568 35.66906998091499 139.74829133505665 37.125 35.669070395203164 139.74829084858973 37.125 35.669070395203164 139.74829084858973 34.568 35.66906998091499 139.74829133505665 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e3b4330d-435c-4238-ba87-7d87f7d5c3fa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e3b4330d-435c-4238-ba87-7d87f7d5c3fa_0">
											<gml:posList>35.66907929195413 139.7482911263517 34.568 35.66907929195413 139.7482911263517 37.125 35.66907968891694 139.74829163405042 37.125 35.66907968891694 139.74829163405042 34.568 35.66907929195413 139.7482911263517 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b37b585d-15d1-449c-9753-a714bcfdc082">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b37b585d-15d1-449c-9753-a714bcfdc082_0">
											<gml:posList>35.66906960270513 139.74829185462355 34.568 35.66906960270513 139.74829185462355 37.125 35.66906998091499 139.74829133505665 37.125 35.66906998091499 139.74829133505665 34.568 35.66906960270513 139.74829185462355 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40f00246-b3c0-4315-b09c-0d85fc04cf67">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40f00246-b3c0-4315-b09c-0d85fc04cf67_0">
											<gml:posList>35.66907968891694 139.74829163405042 34.568 35.66907968891694 139.74829163405042 37.125 35.66908004084233 139.7482921859812 37.125 35.66908004084233 139.7482921859812 34.568 35.66907968891694 139.74829163405042 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82007ad9-bba5-4062-bf89-455ea788758a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-82007ad9-bba5-4062-bf89-455ea788758a_0">
											<gml:posList>35.66906926058138 139.74829241833646 34.568 35.66906926058138 139.74829241833646 37.125 35.66906960270513 139.74829185462355 37.125 35.66906960270513 139.74829185462355 34.568 35.66906926058138 139.74829241833646 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-93c331d5-4f9f-4032-9d9a-bbb3c078db20">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-93c331d5-4f9f-4032-9d9a-bbb3c078db20_0">
											<gml:posList>35.66908004084233 139.7482921859812 34.568 35.66908004084233 139.7482921859812 37.125 35.66908035673622 139.74829277108847 37.125 35.66908035673622 139.74829277108847 34.568 35.66908004084233 139.7482921859812 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c133bea7-79e2-4021-ad2a-c7c9ffc55b0d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c133bea7-79e2-4021-ad2a-c7c9ffc55b0d_0">
											<gml:posList>35.669068963557464 139.74829302618585 34.568 35.669068963557464 139.74829302618585 37.125 35.66906926058138 139.74829241833646 37.125 35.66906926058138 139.74829241833646 34.568 35.669068963557464 139.74829302618585 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b16353d-bec0-4d72-a9db-ed8b069a3f66">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7b16353d-bec0-4d72-a9db-ed8b069a3f66_0">
											<gml:posList>35.66908035673622 139.74829277108847 34.568 35.66908035673622 139.74829277108847 37.125 35.66908063659861 139.74829338937218 37.125 35.66908063659861 139.74829338937218 34.568 35.66908035673622 139.74829277108847 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-39759d63-7333-40da-a14a-b552274cca64">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-39759d63-7333-40da-a14a-b552274cca64_0">
											<gml:posList>35.66906870260405 139.74829365608915 34.568 35.66906870260405 139.74829365608915 37.125 35.669068963557464 139.74829302618585 37.125 35.669068963557464 139.74829302618585 34.568 35.66906870260405 139.74829365608915 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-07d6c246-df12-480c-8dff-f8575402352d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-07d6c246-df12-480c-8dff-f8575402352d_0">
											<gml:posList>35.66908063659861 139.74829338937218 34.568 35.66908063659861 139.74829338937218 37.125 35.66908086240202 139.74829404085148 37.125 35.66908086240202 139.74829404085148 34.568 35.66908063659861 139.74829338937218 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-221c743c-36da-4414-a907-5f55258751ec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-221c743c-36da-4414-a907-5f55258751ec_0">
											<gml:posList>35.66906849574859 139.7482943080272 34.568 35.66906849574859 139.7482943080272 37.125 35.66906870260405 139.74829365608915 37.125 35.66906870260405 139.74829365608915 34.568 35.66906849574859 139.7482943080272 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b79d3896-40de-45ea-887b-41126a98fff1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b79d3896-40de-45ea-887b-41126a98fff1_0">
											<gml:posList>35.66908086240202 139.74829404085148 34.568 35.66908086240202 139.74829404085148 37.125 35.669081043144615 139.74829470342468 37.125 35.669081043144615 139.74829470342468 34.568 35.66908086240202 139.74829404085148 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c1e3ff3-59cd-4dca-99e6-78c4c1ed50f3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c1e3ff3-59cd-4dca-99e6-78c4c1ed50f3_0">
											<gml:posList>35.669068333977364 139.74829498200964 37.125 35.66906849574859 139.7482943080272 37.125 35.66906849574859 139.7482943080272 34.568 35.669068333977364 139.74829498200964 34.568 35.669068333977364 139.74829498200964 37.125</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-495e694d-59cb-4fa4-915e-83ad2e5c42ab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-495e694d-59cb-4fa4-915e-83ad2e5c42ab_0">
											<gml:posList>35.669081043144615 139.74829470342468 34.568 35.669081043144615 139.74829470342468 37.125 35.66908117883416 139.7482953881378 37.125 35.66908117883416 139.7482953881378 34.568 35.669081043144615 139.74829470342468 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00e0180b-fbec-48c4-b066-c56ca241fe0d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-00e0180b-fbec-48c4-b066-c56ca241fe0d_0">
											<gml:posList>35.66906821728257 139.74829566699034 34.568 35.66906821728257 139.74829566699034 37.125 35.669068333977364 139.74829498200964 37.125 35.669068333977364 139.74829498200964 34.568 35.66906821728257 139.74829566699034 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd5c4788-3272-48ab-9922-ca9c5d7e54a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dd5c4788-3272-48ab-9922-ca9c5d7e54a5_0">
											<gml:posList>35.66908117883416 139.7482953881378 34.568 35.66908117883416 139.7482953881378 37.125 35.66908126044916 139.74829608395436 37.125 35.66908126044916 139.74829608395436 34.568 35.66908117883416 139.7482953881378 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-783130bb-3ac1-45e2-9647-ce45d64f5d0b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-783130bb-3ac1-45e2-9647-ce45d64f5d0b_0">
											<gml:posList>35.66906815468573 139.7482963740058 37.125 35.66906821728257 139.74829566699034 37.125 35.66906821728257 139.74829566699034 34.568 35.66906815468573 139.7482963740058 34.568 35.66906815468573 139.7482963740058 37.125</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a6afadd-efe3-47b1-affc-b106a16b6b4a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3a6afadd-efe3-47b1-affc-b106a16b6b4a_0">
											<gml:posList>35.66908126044916 139.74829608395436 34.568 35.66908126044916 139.74829608395436 37.125 35.6690812969955 139.74829677981873 37.125 35.6690812969955 139.74829677981873 34.568 35.66908126044916 139.74829608395436 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-68aa9505-d304-4fe6-ab6e-cf7f2a3e8cc2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-68aa9505-d304-4fe6-ab6e-cf7f2a3e8cc2_0">
											<gml:posList>35.66906813714972 139.74829706992742 34.568 35.66906813714972 139.74829706992742 37.125 35.66906815468573 139.7482963740058 37.125 35.66906815468573 139.7482963740058 34.568 35.66906813714972 139.74829706992742 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb9ef520-96aa-4048-b930-4c2e9e2e7e7b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb9ef520-96aa-4048-b930-4c2e9e2e7e7b_0">
											<gml:posList>35.66908086240202 139.74829404085148 37.125 35.66908063659861 139.74829338937218 37.125 35.66908035673622 139.74829277108847 37.125 35.66908004084233 139.7482921859812 37.125 35.66907968891694 139.74829163405042 37.125 35.66907929195413 139.7482911263517 37.125 35.669078858967595 139.74829066287555 37.125 35.66907839897109 139.74829024361236 37.125 35.66907790295088 139.7482898685717 37.125 35.66907739796377 139.74828955981704 37.125 35.669076856960736 139.748289306331 37.125 35.669076306975185 139.74828909703882 37.125 35.66907574803053 139.7482889650787 37.125 35.669075180103334 139.74828887731243 37.125 35.669074603217034 139.74828886687823 37.125 35.66907402636975 139.7482889116744 37.125 35.66907345857518 139.74828901169133 37.125 35.669072899841154 139.74828917797515 37.125 35.66907235917358 139.7482893994702 37.125 35.66907183658028 139.74828968722255 37.125 35.6690713230319 139.74829001914966 37.125 35.66907084557744 139.74829040626886 37.125 35.669070395203164 139.74829084858973 37.125 35.66906998091499 139.74829133505665 37.125 35.66906960270513 139.74829185462355 37.125 35.66906926058138 139.74829241833646 37.125 35.669068963557464 139.74829302618585 37.125 35.66906870260405 139.74829365608915 37.125 35.66906849574859 139.7482943080272 37.125 35.669068333977364 139.74829498200964 37.125 35.66906821728257 139.74829566699034 37.125 35.66906815468573 139.7482963740058 37.125 35.66906813714972 139.74829706992742 37.125 35.66906817370387 139.74829777683772 37.125 35.66906825531884 139.74829847265417 37.125 35.66906839100837 139.7482991573672 37.125 35.66906857175093 139.74829981994029 37.125 35.66906880656804 139.74830047140998 37.125 35.66906907741666 139.74830108970318 37.125 35.6690693933105 139.7483016748104 37.125 35.66906975424958 139.7483022267316 37.125 35.66907015121235 139.7483027344303 37.125 35.66907057518511 139.74830319791604 37.125 35.66907104419529 139.74830361716968 37.125 35.66907153120172 139.74830399221995 37.125 35.66907204520255 139.74830430096512 37.125 35.66907257719182 139.7483045544608 37.125 35.66907312716954 139.748304752707 37.125 35.66907369513571 139.74830489570377 37.125 35.66907426305508 139.74830497242408 37.125 35.66907483994918 139.74830499390447 37.125 35.669075407782756 139.748304949118 37.125 35.66907597557733 139.74830484910115 37.125 35.66907653431138 139.74830468281743 37.125 35.669077083992704 139.7483044613129 37.125 35.66907760658604 139.74830417356063 37.125 35.66907811112073 139.74830384164315 37.125 35.66907858857524 139.748303454524 37.125 35.669079038949555 139.74830301220314 37.125 35.66907945323778 139.74830252573625 37.125 35.669079840461414 139.74830200615978 37.125 35.66908017357148 139.74830144245638 37.125 35.66908047960917 139.7483008345974 37.125 35.669080731548895 139.74830020470358 37.125 35.66908094741811 139.74829955275584 37.125 35.669081109189364 139.74829887877334 37.125 35.66908122588417 139.74829819379255 37.125 35.66908128848102 139.74829748677695 37.125 35.6690812969955 139.74829677981873 37.125 35.66908126044916 139.74829608395436 37.125 35.66908117883416 139.7482953881378 37.125 35.669081043144615 139.74829470342468 37.125 35.66908086240202 139.74829404085148 37.125</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-32a39bcc-083e-4963-84f6-f06d4126aafb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-32a39bcc-083e-4963-84f6-f06d4126aafb_0">
											<gml:posList>35.6690812969955 139.74829677981873 34.568 35.6690812969955 139.74829677981873 37.125 35.66908128848102 139.74829748677695 37.125 35.66908128848102 139.74829748677695 34.568 35.6690812969955 139.74829677981873 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59d3c3bf-59bb-42ee-a645-843f311b5a90">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-59d3c3bf-59bb-42ee-a645-843f311b5a90_0">
											<gml:posList>35.66906817370387 139.74829777683772 34.568 35.66906817370387 139.74829777683772 37.125 35.66906813714972 139.74829706992742 37.125 35.66906813714972 139.74829706992742 34.568 35.66906817370387 139.74829777683772 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce25dd38-ef01-4b32-9136-02df0fa528e8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce25dd38-ef01-4b32-9136-02df0fa528e8_0">
											<gml:posList>35.66908128848102 139.74829748677695 34.568 35.66908128848102 139.74829748677695 37.125 35.66908122588417 139.74829819379255 37.125 35.66908122588417 139.74829819379255 34.568 35.66908128848102 139.74829748677695 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-86f31450-08cb-4bb0-9706-18d8325ab455">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-86f31450-08cb-4bb0-9706-18d8325ab455_0">
											<gml:posList>35.66906825531884 139.74829847265417 37.125 35.66906817370387 139.74829777683772 37.125 35.66906817370387 139.74829777683772 34.568 35.66906825531884 139.74829847265417 34.568 35.66906825531884 139.74829847265417 37.125</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97a868d2-bec6-4487-9fe0-959ba28009fb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-97a868d2-bec6-4487-9fe0-959ba28009fb_0">
											<gml:posList>35.66908122588417 139.74829819379255 34.568 35.66908122588417 139.74829819379255 37.125 35.669081109189364 139.74829887877334 37.125 35.669081109189364 139.74829887877334 34.568 35.66908122588417 139.74829819379255 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-06544fb8-4639-470f-a0e1-7d72d392f1f3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-06544fb8-4639-470f-a0e1-7d72d392f1f3_0">
											<gml:posList>35.66906839100837 139.7482991573672 34.568 35.66906839100837 139.7482991573672 37.125 35.66906825531884 139.74829847265417 37.125 35.66906825531884 139.74829847265417 34.568 35.66906839100837 139.7482991573672 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-92842b5b-33d7-4b6b-aced-d3ede4568a0b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-92842b5b-33d7-4b6b-aced-d3ede4568a0b_0">
											<gml:posList>35.669081109189364 139.74829887877334 34.568 35.669081109189364 139.74829887877334 37.125 35.66908094741811 139.74829955275584 37.125 35.66908094741811 139.74829955275584 34.568 35.669081109189364 139.74829887877334 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-615b82a4-a84a-492f-873e-e76381bfe336">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-615b82a4-a84a-492f-873e-e76381bfe336_0">
											<gml:posList>35.66906857175093 139.74829981994029 34.568 35.66906857175093 139.74829981994029 37.125 35.66906839100837 139.7482991573672 37.125 35.66906839100837 139.7482991573672 34.568 35.66906857175093 139.74829981994029 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f10b41e-2e3b-45ac-a1cf-86c8fc268312">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f10b41e-2e3b-45ac-a1cf-86c8fc268312_0">
											<gml:posList>35.66908094741811 139.74829955275584 34.568 35.66908094741811 139.74829955275584 37.125 35.669080731548895 139.74830020470358 37.125 35.669080731548895 139.74830020470358 34.568 35.66908094741811 139.74829955275584 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4fce896a-b4ca-4182-8c19-1f47030d3dfe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4fce896a-b4ca-4182-8c19-1f47030d3dfe_0">
											<gml:posList>35.66906880656804 139.74830047140998 34.568 35.66906880656804 139.74830047140998 37.125 35.66906857175093 139.74829981994029 37.125 35.66906857175093 139.74829981994029 34.568 35.66906880656804 139.74830047140998 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1828fc9b-4b21-436c-9955-faf51297c653">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1828fc9b-4b21-436c-9955-faf51297c653_0">
											<gml:posList>35.669080731548895 139.74830020470358 34.568 35.669080731548895 139.74830020470358 37.125 35.66908047960917 139.7483008345974 37.125 35.66908047960917 139.7483008345974 34.568 35.669080731548895 139.74830020470358 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a0fa990-9bfa-43e8-95e1-4b001238a4fb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9a0fa990-9bfa-43e8-95e1-4b001238a4fb_0">
											<gml:posList>35.66906907741666 139.74830108970318 34.568 35.66906907741666 139.74830108970318 37.125 35.66906880656804 139.74830047140998 37.125 35.66906880656804 139.74830047140998 34.568 35.66906907741666 139.74830108970318 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94446278-f1a7-47c7-ac6b-8149b5804c7d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-94446278-f1a7-47c7-ac6b-8149b5804c7d_0">
											<gml:posList>35.66908047960917 139.7483008345974 34.568 35.66908047960917 139.7483008345974 37.125 35.66908017357148 139.74830144245638 37.125 35.66908017357148 139.74830144245638 34.568 35.66908047960917 139.7483008345974 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-39af8885-f756-4017-a1bd-19ef259855bb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-39af8885-f756-4017-a1bd-19ef259855bb_0">
											<gml:posList>35.6690693933105 139.7483016748104 34.568 35.6690693933105 139.7483016748104 37.125 35.66906907741666 139.74830108970318 37.125 35.66906907741666 139.74830108970318 34.568 35.6690693933105 139.7483016748104 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a83e2b2-06f8-4d3b-afba-9e19a550eb1c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0a83e2b2-06f8-4d3b-afba-9e19a550eb1c_0">
											<gml:posList>35.66908017357148 139.74830144245638 37.125 35.669079840461414 139.74830200615978 37.125 35.669079840461414 139.74830200615978 34.568 35.66908017357148 139.74830144245638 34.568 35.66908017357148 139.74830144245638 37.125</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7f99d6d-a279-4b7c-a45f-7b6124f5998a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c7f99d6d-a279-4b7c-a45f-7b6124f5998a_0">
											<gml:posList>35.66906975424958 139.7483022267316 34.568 35.66906975424958 139.7483022267316 37.125 35.6690693933105 139.7483016748104 37.125 35.6690693933105 139.7483016748104 34.568 35.66906975424958 139.7483022267316 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd49e837-83ca-4b36-b18d-a0ab1adbdd16">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dd49e837-83ca-4b36-b18d-a0ab1adbdd16_0">
											<gml:posList>35.669079840461414 139.74830200615978 34.568 35.669079840461414 139.74830200615978 37.125 35.66907945323778 139.74830252573625 37.125 35.66907945323778 139.74830252573625 34.568 35.669079840461414 139.74830200615978 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fd6253b6-09f7-4b83-9e42-0288f5671fc3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fd6253b6-09f7-4b83-9e42-0288f5671fc3_0">
											<gml:posList>35.66907015121235 139.7483027344303 34.568 35.66907015121235 139.7483027344303 37.125 35.66906975424958 139.7483022267316 37.125 35.66906975424958 139.7483022267316 34.568 35.66907015121235 139.7483027344303 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-131c641a-2022-47d2-b580-5511f5555064">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-131c641a-2022-47d2-b580-5511f5555064_0">
											<gml:posList>35.66907945323778 139.74830252573625 34.568 35.66907945323778 139.74830252573625 37.125 35.669079038949555 139.74830301220314 37.125 35.669079038949555 139.74830301220314 34.568 35.66907945323778 139.74830252573625 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d9fc8a3d-d23e-4a59-992c-68a75dee5b55">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d9fc8a3d-d23e-4a59-992c-68a75dee5b55_0">
											<gml:posList>35.66907057518511 139.74830319791604 34.568 35.66907057518511 139.74830319791604 37.125 35.66907015121235 139.7483027344303 37.125 35.66907015121235 139.7483027344303 34.568 35.66907057518511 139.74830319791604 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-687bbdec-f8e6-442c-a817-a4eae820cc61">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-687bbdec-f8e6-442c-a817-a4eae820cc61_0">
											<gml:posList>35.669079038949555 139.74830301220314 34.568 35.669079038949555 139.74830301220314 37.125 35.66907858857524 139.748303454524 37.125 35.66907858857524 139.748303454524 34.568 35.669079038949555 139.74830301220314 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4be8a0d9-592e-490e-9b99-9d1a14346570">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4be8a0d9-592e-490e-9b99-9d1a14346570_0">
											<gml:posList>35.66907104419529 139.74830361716968 37.125 35.66907057518511 139.74830319791604 37.125 35.66907057518511 139.74830319791604 34.568 35.66907104419529 139.74830361716968 34.568 35.66907104419529 139.74830361716968 37.125</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4c74b77-293f-42bc-a053-f71cf5f9909c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b4c74b77-293f-42bc-a053-f71cf5f9909c_0">
											<gml:posList>35.66907858857524 139.748303454524 34.568 35.66907858857524 139.748303454524 37.125 35.66907811112073 139.74830384164315 37.125 35.66907811112073 139.74830384164315 34.568 35.66907858857524 139.748303454524 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef180eeb-1dae-4d3e-8c92-42527385a2f3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef180eeb-1dae-4d3e-8c92-42527385a2f3_0">
											<gml:posList>35.66907153120172 139.74830399221995 34.568 35.66907153120172 139.74830399221995 37.125 35.66907104419529 139.74830361716968 37.125 35.66907104419529 139.74830361716968 34.568 35.66907153120172 139.74830399221995 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e2feae7c-085b-455c-a83e-b414bc8122aa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e2feae7c-085b-455c-a83e-b414bc8122aa_0">
											<gml:posList>35.66907811112073 139.74830384164315 37.125 35.66907760658604 139.74830417356063 37.125 35.66907760658604 139.74830417356063 34.568 35.66907811112073 139.74830384164315 34.568 35.66907811112073 139.74830384164315 37.125</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9dbe6890-ead3-46df-af03-0ebf764c50f7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9dbe6890-ead3-46df-af03-0ebf764c50f7_0">
											<gml:posList>35.66907204520255 139.74830430096512 34.568 35.66907204520255 139.74830430096512 37.125 35.66907153120172 139.74830399221995 37.125 35.66907153120172 139.74830399221995 34.568 35.66907204520255 139.74830430096512 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d773f73-92c4-4ca9-ad51-405db69f127b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6d773f73-92c4-4ca9-ad51-405db69f127b_0">
											<gml:posList>35.66907760658604 139.74830417356063 34.568 35.66907760658604 139.74830417356063 37.125 35.669077083992704 139.7483044613129 37.125 35.669077083992704 139.7483044613129 34.568 35.66907760658604 139.74830417356063 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-734b4fc3-69c0-44a4-8b72-1aba9efdb1b5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-734b4fc3-69c0-44a4-8b72-1aba9efdb1b5_0">
											<gml:posList>35.66907257719182 139.7483045544608 34.568 35.66907257719182 139.7483045544608 37.125 35.66907204520255 139.74830430096512 37.125 35.66907204520255 139.74830430096512 34.568 35.66907257719182 139.7483045544608 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00bd175d-fd3e-42d6-ba35-e931b185ed29">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-00bd175d-fd3e-42d6-ba35-e931b185ed29_0">
											<gml:posList>35.669077083992704 139.7483044613129 34.568 35.669077083992704 139.7483044613129 37.125 35.66907653431138 139.74830468281743 37.125 35.66907653431138 139.74830468281743 34.568 35.669077083992704 139.7483044613129 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8cd2d058-4dbf-46e1-aaa3-58a599957b7e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8cd2d058-4dbf-46e1-aaa3-58a599957b7e_0">
											<gml:posList>35.66907312716954 139.748304752707 34.568 35.66907312716954 139.748304752707 37.125 35.66907257719182 139.7483045544608 37.125 35.66907257719182 139.7483045544608 34.568 35.66907312716954 139.748304752707 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8ea62bb-876c-4bee-8547-e462ab8246a4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b8ea62bb-876c-4bee-8547-e462ab8246a4_0">
											<gml:posList>35.66907653431138 139.74830468281743 34.568 35.66907653431138 139.74830468281743 37.125 35.66907597557733 139.74830484910115 37.125 35.66907597557733 139.74830484910115 34.568 35.66907653431138 139.74830468281743 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c95d00ea-6ae0-41e5-96e4-8970694db47f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c95d00ea-6ae0-41e5-96e4-8970694db47f_0">
											<gml:posList>35.66907369513571 139.74830489570377 34.568 35.66907369513571 139.74830489570377 37.125 35.66907312716954 139.748304752707 37.125 35.66907312716954 139.748304752707 34.568 35.66907369513571 139.74830489570377 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3261e28d-3b68-4698-89a2-617623b47666">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3261e28d-3b68-4698-89a2-617623b47666_0">
											<gml:posList>35.66907597557733 139.74830484910115 37.125 35.669075407782756 139.748304949118 37.125 35.669075407782756 139.748304949118 34.568 35.66907597557733 139.74830484910115 34.568 35.66907597557733 139.74830484910115 37.125</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b8b985b-42c9-420e-9469-9a9ea2151786">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6b8b985b-42c9-420e-9469-9a9ea2151786_0">
											<gml:posList>35.66907426305508 139.74830497242408 34.568 35.66907426305508 139.74830497242408 37.125 35.66907369513571 139.74830489570377 37.125 35.66907369513571 139.74830489570377 34.568 35.66907426305508 139.74830497242408 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19206365-36d2-4a5f-b57c-df3966f7d4ad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19206365-36d2-4a5f-b57c-df3966f7d4ad_0">
											<gml:posList>35.669075407782756 139.748304949118 34.568 35.669075407782756 139.748304949118 37.125 35.66907483994918 139.74830499390447 37.125 35.66907483994918 139.74830499390447 34.568 35.669075407782756 139.748304949118 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b24ff283-3d06-412e-93ce-de137df07664">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b24ff283-3d06-412e-93ce-de137df07664_0">
											<gml:posList>35.66907483994918 139.74830499390447 37.125 35.66907426305508 139.74830497242408 37.125 35.66907426305508 139.74830497242408 34.568 35.66907483994918 139.74830499390447 34.568 35.66907483994918 139.74830499390447 37.125</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_53e1dc96-c46f-4ff6-a76e-a3a676c2c8c3_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c326f14-9b88-4972-ad14-d89bb0d7c5d1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66904218610547 139.7482708298813 31.372 35.669016126212625 139.7482563871729 31.372 35.66902526665892 139.74823161217753 31.372 35.66905132654689 139.74824604383346 31.372 35.66904218610547 139.7482708298813 31.372</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-460816ce-a744-4b1c-afc3-8d6b34f3b9a5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669021969197836 139.74832315448495 31.372 35.6690035916113 139.74831239300437 31.372 35.66902046179139 139.74826910764855 31.372 35.669038839381734 139.74827986912146 31.372 35.669021969197836 139.74832315448495 31.372</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97891839-f988-4522-b5b8-28c0ea03f349">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-97891839-f988-4522-b5b8-28c0ea03f349_0">
											<gml:posList>35.66902046179139 139.74826910764855 31.372 35.6690035916113 139.74831239300437 31.372 35.6690035916113 139.74831239300437 33.902 35.66902046179139 139.74826910764855 33.902 35.66902046179139 139.74826910764855 31.372</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d5801c14-912e-4620-95d9-63959b3a64bb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d5801c14-912e-4620-95d9-63959b3a64bb_0">
											<gml:posList>35.6690035916113 139.74831239300437 31.372 35.669021969197836 139.74832315448495 31.372 35.669021969197836 139.74832315448495 33.902 35.6690035916113 139.74831239300437 33.902 35.6690035916113 139.74831239300437 31.372</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82d2b271-940b-4b74-8fcf-fa6c77c3378a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-82d2b271-940b-4b74-8fcf-fa6c77c3378a_0">
											<gml:posList>35.66902526665892 139.74823161217753 31.372 35.669016126212625 139.7482563871729 31.372 35.669016126212625 139.7482563871729 33.902 35.66902526665892 139.74823161217753 33.902 35.66902526665892 139.74823161217753 31.372</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4507b814-c703-4d2e-8304-54a907706246">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4507b814-c703-4d2e-8304-54a907706246_0">
											<gml:posList>35.669021969197836 139.74832315448495 33.902 35.669038839381734 139.74827986912146 33.902 35.66902046179139 139.74826910764855 33.902 35.6690035916113 139.74831239300437 33.902 35.669021969197836 139.74832315448495 33.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5838cb38-dca8-40c5-ba7e-fa9353f20505">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5838cb38-dca8-40c5-ba7e-fa9353f20505_0">
											<gml:posList>35.669016126212625 139.7482563871729 31.372 35.66904218610547 139.7482708298813 31.372 35.66904218610547 139.7482708298813 33.902 35.669016126212625 139.7482563871729 33.902 35.669016126212625 139.7482563871729 31.372</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81250114-38cc-4ad7-9dd4-edb3ca194d55">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81250114-38cc-4ad7-9dd4-edb3ca194d55_0">
											<gml:posList>35.66902046179139 139.74826910764855 31.372 35.66902046179139 139.74826910764855 33.902 35.669038839381734 139.74827986912146 33.902 35.669038839381734 139.74827986912146 31.372 35.66902046179139 139.74826910764855 31.372</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ced7f406-eef4-44c0-a760-afaf65b3530a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ced7f406-eef4-44c0-a760-afaf65b3530a_0">
											<gml:posList>35.669038839381734 139.74827986912146 31.372 35.669038839381734 139.74827986912146 33.902 35.669021969197836 139.74832315448495 33.902 35.669021969197836 139.74832315448495 31.372 35.669038839381734 139.74827986912146 31.372</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ef372eb-e5cf-47e6-a9a6-24f197d33cc3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2ef372eb-e5cf-47e6-a9a6-24f197d33cc3_0">
											<gml:posList>35.66904218610547 139.7482708298813 33.902 35.66905132654689 139.74824604383346 33.902 35.66902526665892 139.74823161217753 33.902 35.669016126212625 139.7482563871729 33.902 35.66904218610547 139.7482708298813 33.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0516594f-13b7-493e-9c6b-e900be2eb780">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0516594f-13b7-493e-9c6b-e900be2eb780_0">
											<gml:posList>35.66905132654689 139.74824604383346 31.372 35.66902526665892 139.74823161217753 31.372 35.66902526665892 139.74823161217753 33.902 35.66905132654689 139.74824604383346 33.902 35.66905132654689 139.74824604383346 31.372</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f489cc1f-7009-4754-85d2-396e0532646e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f489cc1f-7009-4754-85d2-396e0532646e_0">
											<gml:posList>35.66905132654689 139.74824604383346 31.372 35.66905132654689 139.74824604383346 33.902 35.66904218610547 139.7482708298813 33.902 35.66904218610547 139.7482708298813 31.372 35.66905132654689 139.74824604383346 31.372</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-2aaf4c4d-7366-4bae-9aa5-3e3cce809405">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2aaf4c4d-7366-4bae-9aa5-3e3cce809405">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2aaf4c4d-7366-4bae-9aa5-3e3cce809405">
											<gml:posList>35.66905802525125 139.74837582814197 5.66 35.66898931298104 139.74833668740354 5.66 35.66898308017524 139.74831780523482 5.66 35.66902662880845 139.74820762970575 5.66 35.66911031085239 139.748256585482 5.66 35.66905802525125 139.74837582814197 5.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ef3ec47e-a912-4983-b030-85ac3d77317f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef3ec47e-a912-4983-b030-85ac3d77317f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef3ec47e-a912-4983-b030-85ac3d77317f">
											<gml:posList>35.66898931298104 139.74833668740354 31.7 35.66899125836319 139.74833444298935 31.7 35.668985802398694 139.74831791280917 31.7 35.66898308017524 139.74831780523482 31.7 35.66898931298104 139.74833668740354 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1ec8dfad-60e7-4aef-8f8c-d0d0d2e89b24">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ec8dfad-60e7-4aef-8f8c-d0d0d2e89b24">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ec8dfad-60e7-4aef-8f8c-d0d0d2e89b24">
											<gml:posList>35.66898308017524 139.74831780523482 31.7 35.668985802398694 139.74831791280917 31.7 35.66902779444497 139.74821168237736 31.7 35.66902662880845 139.74820762970575 31.7 35.66898308017524 139.74831780523482 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b6964b61-543f-4eed-a86b-c73930fd5cac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6964b61-543f-4eed-a86b-c73930fd5cac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6964b61-543f-4eed-a86b-c73930fd5cac">
											<gml:posList>35.66898931298104 139.74833668740354 31.7 35.66905802525125 139.74837582814197 31.7 35.66905694981989 139.74837186373952 31.7 35.66899125836319 139.74833444298935 31.7 35.66898931298104 139.74833668740354 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d780c045-ac51-414f-9849-8a2d3468ac2b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d780c045-ac51-414f-9849-8a2d3468ac2b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d780c045-ac51-414f-9849-8a2d3468ac2b">
											<gml:posList>35.66905694981989 139.74837186373952 31.372 35.6690727165103 139.7483359141344 31.372 35.66907377820412 139.7483331846271 31.372 35.66903925036631 139.7483129958658 31.372 35.6690692567439 139.74823595078163 31.372 35.66902779444497 139.74821168237736 31.372 35.668985802398694 139.74831791280917 31.372 35.66899125836319 139.74833444298935 31.372 35.66905694981989 139.74837186373952 31.372</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fb08b777-4360-4089-862b-0cded7fd19da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb08b777-4360-4089-862b-0cded7fd19da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb08b777-4360-4089-862b-0cded7fd19da">
											<gml:posList>35.6690692567439 139.74823595078163 31.7 35.669070327433566 139.74823319917144 31.7 35.66902662880845 139.74820762970575 31.7 35.66902779444497 139.74821168237736 31.7 35.6690692567439 139.74823595078163 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-844b4b44-f73e-42a5-8b53-bd83a42ff953">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-844b4b44-f73e-42a5-8b53-bd83a42ff953">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-844b4b44-f73e-42a5-8b53-bd83a42ff953">
											<gml:posList>35.66903925036631 139.7483129958658 34.947 35.66904251234484 139.74831158955533 34.947 35.66907148401645 139.7482371966248 34.947 35.669070327433566 139.74823319917144 34.947 35.66903925036631 139.7483129958658 34.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0dc7a6e3-f2d7-4eae-bcb8-9791d6beb8ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0dc7a6e3-f2d7-4eae-bcb8-9791d6beb8ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0dc7a6e3-f2d7-4eae-bcb8-9791d6beb8ac">
											<gml:posList>35.66907612274769 139.74833456290173 34.947 35.66907507438733 139.74833064265457 34.947 35.66904251234484 139.74831158955533 34.947 35.66903925036631 139.7483129958658 34.947 35.66907612274769 139.74833456290173 34.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2c972734-eca1-4674-86c9-6033e01d75d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c972734-eca1-4674-86c9-6033e01d75d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c972734-eca1-4674-86c9-6033e01d75d1">
											<gml:posList>35.66905802525125 139.74837582814197 31.7 35.66907612274769 139.74833456290173 31.7 35.6690727165103 139.7483359141344 31.7 35.66905694981989 139.74837186373952 31.7 35.66905802525125 139.74837582814197 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e00eb737-4d12-4c8b-804c-057cf5ff9c26">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e00eb737-4d12-4c8b-804c-057cf5ff9c26">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e00eb737-4d12-4c8b-804c-057cf5ff9c26">
											<gml:posList>35.6690727165103 139.7483359141344 31.7 35.66907612274769 139.74833456290173 31.7 35.66907377820412 139.7483331846271 31.7 35.6690727165103 139.7483359141344 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-03d51893-b29d-4310-857d-b99240486c6a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03d51893-b29d-4310-857d-b99240486c6a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03d51893-b29d-4310-857d-b99240486c6a">
											<gml:posList>35.66907507438733 139.74833064265457 34.568 35.66910695870605 139.74825794770726 34.568 35.66907148401645 139.7482371966248 34.568 35.66904251234484 139.74831158955533 34.568 35.66907507438733 139.74833064265457 34.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6f16c1c8-69e8-4750-9924-b18cd0a04e21">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f16c1c8-69e8-4750-9924-b18cd0a04e21">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f16c1c8-69e8-4750-9924-b18cd0a04e21">
											<gml:posList>35.669070327433566 139.74823319917144 34.947 35.66907148401645 139.7482371966248 34.947 35.66910695870605 139.74825794770726 34.947 35.66911031085239 139.748256585482 34.947 35.669070327433566 139.74823319917144 34.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0eebf3ce-aa67-46b9-8247-959af673b16f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0eebf3ce-aa67-46b9-8247-959af673b16f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0eebf3ce-aa67-46b9-8247-959af673b16f">
											<gml:posList>35.66911031085239 139.748256585482 34.947 35.66910695870605 139.74825794770726 34.947 35.66907507438733 139.74833064265457 34.947 35.66907612274769 139.74833456290173 34.947 35.66911031085239 139.748256585482 34.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d263517a-178b-410a-a053-01556a92914f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d263517a-178b-410a-a053-01556a92914f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d263517a-178b-410a-a053-01556a92914f">
											<gml:posList>35.66904251234484 139.74831158955533 34.947 35.66904251234484 139.74831158955533 34.568 35.66907148401645 139.7482371966248 34.568 35.66907148401645 139.7482371966248 34.947 35.66904251234484 139.74831158955533 34.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a8ac9e6b-0d53-499c-a619-16f4fe78a39e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a8ac9e6b-0d53-499c-a619-16f4fe78a39e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a8ac9e6b-0d53-499c-a619-16f4fe78a39e">
											<gml:posList>35.6690692567439 139.74823595078163 31.372 35.6690692567439 139.74823595078163 31.7 35.66902779444497 139.74821168237736 31.7 35.66902779444497 139.74821168237736 31.372 35.6690692567439 139.74823595078163 31.372</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1adef77f-3b25-4f03-a21e-8e1fd0c73b86">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1adef77f-3b25-4f03-a21e-8e1fd0c73b86">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1adef77f-3b25-4f03-a21e-8e1fd0c73b86">
											<gml:posList>35.66911031085239 139.748256585482 5.66 35.66902662880845 139.74820762970575 5.66 35.66902662880845 139.74820762970575 31.7 35.669070327433566 139.74823319917144 31.7 35.669070327433566 139.74823319917144 34.947 35.66911031085239 139.748256585482 34.947 35.66911031085239 139.748256585482 5.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-50f2d1c8-b35b-47a8-bac7-ecd5736eae89">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50f2d1c8-b35b-47a8-bac7-ecd5736eae89">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50f2d1c8-b35b-47a8-bac7-ecd5736eae89">
											<gml:posList>35.66907148401645 139.7482371966248 34.947 35.66907148401645 139.7482371966248 34.568 35.66910695870605 139.74825794770726 34.568 35.66910695870605 139.74825794770726 34.947 35.66907148401645 139.7482371966248 34.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e9f7dd5b-73e5-4f78-a0cc-f3f92c3b9ff1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e9f7dd5b-73e5-4f78-a0cc-f3f92c3b9ff1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e9f7dd5b-73e5-4f78-a0cc-f3f92c3b9ff1">
											<gml:posList>35.66902662880845 139.74820762970575 5.66 35.66898308017524 139.74831780523482 5.66 35.66898308017524 139.74831780523482 31.7 35.66902662880845 139.74820762970575 31.7 35.66902662880845 139.74820762970575 5.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f48b8f26-7705-4450-bc02-8e530d18ef2f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f48b8f26-7705-4450-bc02-8e530d18ef2f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f48b8f26-7705-4450-bc02-8e530d18ef2f">
											<gml:posList>35.668985802398694 139.74831791280917 31.7 35.668985802398694 139.74831791280917 31.372 35.66902779444497 139.74821168237736 31.372 35.66902779444497 139.74821168237736 31.7 35.668985802398694 139.74831791280917 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-402d6b8b-ac55-43e9-bb98-d5436eef7b65">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-402d6b8b-ac55-43e9-bb98-d5436eef7b65">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-402d6b8b-ac55-43e9-bb98-d5436eef7b65">
											<gml:posList>35.66903925036631 139.7483129958658 31.372 35.66903925036631 139.7483129958658 34.947 35.669070327433566 139.74823319917144 34.947 35.669070327433566 139.74823319917144 31.7 35.6690692567439 139.74823595078163 31.7 35.6690692567439 139.74823595078163 31.372 35.66903925036631 139.7483129958658 31.372</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cbd8f22e-4ca9-492f-afd3-8b79f1058038">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cbd8f22e-4ca9-492f-afd3-8b79f1058038">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cbd8f22e-4ca9-492f-afd3-8b79f1058038">
											<gml:posList>35.66910695870605 139.74825794770726 34.947 35.66910695870605 139.74825794770726 34.568 35.66907507438733 139.74833064265457 34.568 35.66907507438733 139.74833064265457 34.947 35.66910695870605 139.74825794770726 34.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b14e9803-500e-4a8d-b56f-b62ef6ecbae7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b14e9803-500e-4a8d-b56f-b62ef6ecbae7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b14e9803-500e-4a8d-b56f-b62ef6ecbae7">
											<gml:posList>35.66911031085239 139.748256585482 5.66 35.66911031085239 139.748256585482 34.947 35.66907612274769 139.74833456290173 34.947 35.66907612274769 139.74833456290173 31.7 35.66905802525125 139.74837582814197 31.7 35.66905802525125 139.74837582814197 5.66 35.66911031085239 139.748256585482 5.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-031d6d11-17b2-40a3-8477-66cb11f6ce2d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-031d6d11-17b2-40a3-8477-66cb11f6ce2d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-031d6d11-17b2-40a3-8477-66cb11f6ce2d">
											<gml:posList>35.66907507438733 139.74833064265457 34.947 35.66907507438733 139.74833064265457 34.568 35.66904251234484 139.74831158955533 34.568 35.66904251234484 139.74831158955533 34.947 35.66907507438733 139.74833064265457 34.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e956bba5-ffc5-48ae-93cb-36c1f4f15143">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e956bba5-ffc5-48ae-93cb-36c1f4f15143">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e956bba5-ffc5-48ae-93cb-36c1f4f15143">
											<gml:posList>35.66907612274769 139.74833456290173 34.947 35.66903925036631 139.7483129958658 34.947 35.66903925036631 139.7483129958658 31.372 35.66907377820412 139.7483331846271 31.372 35.66907377820412 139.7483331846271 31.7 35.66907612274769 139.74833456290173 31.7 35.66907612274769 139.74833456290173 34.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-57279159-6569-4d96-9e93-e89e2133d0bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-57279159-6569-4d96-9e93-e89e2133d0bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-57279159-6569-4d96-9e93-e89e2133d0bc">
											<gml:posList>35.66899125836319 139.74833444298935 31.7 35.66899125836319 139.74833444298935 31.372 35.668985802398694 139.74831791280917 31.372 35.668985802398694 139.74831791280917 31.7 35.66899125836319 139.74833444298935 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-878c1ca9-45c7-4a86-8da4-556137d7a9eb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-878c1ca9-45c7-4a86-8da4-556137d7a9eb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-878c1ca9-45c7-4a86-8da4-556137d7a9eb">
											<gml:posList>35.66898308017524 139.74831780523482 5.66 35.66898931298104 139.74833668740354 5.66 35.66898931298104 139.74833668740354 31.7 35.66898308017524 139.74831780523482 31.7 35.66898308017524 139.74831780523482 5.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f11e8970-f460-4642-a3e8-ee8027ef00d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f11e8970-f460-4642-a3e8-ee8027ef00d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f11e8970-f460-4642-a3e8-ee8027ef00d6">
											<gml:posList>35.66907377820412 139.7483331846271 31.7 35.66907377820412 139.7483331846271 31.372 35.6690727165103 139.7483359141344 31.372 35.6690727165103 139.7483359141344 31.7 35.66907377820412 139.7483331846271 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-960df5aa-c8f2-4765-b233-4bdde0fde195">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-960df5aa-c8f2-4765-b233-4bdde0fde195">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-960df5aa-c8f2-4765-b233-4bdde0fde195">
											<gml:posList>35.66905694981989 139.74837186373952 31.7 35.66905694981989 139.74837186373952 31.372 35.66899125836319 139.74833444298935 31.372 35.66899125836319 139.74833444298935 31.7 35.66905694981989 139.74837186373952 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d598477b-fca6-418c-8ba3-90125afcd813">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d598477b-fca6-418c-8ba3-90125afcd813">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d598477b-fca6-418c-8ba3-90125afcd813">
											<gml:posList>35.6690727165103 139.7483359141344 31.7 35.6690727165103 139.7483359141344 31.372 35.66905694981989 139.74837186373952 31.372 35.66905694981989 139.74837186373952 31.7 35.6690727165103 139.7483359141344 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d8e7e9d3-5c38-4f69-bca4-184cdfa29857">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d8e7e9d3-5c38-4f69-bca4-184cdfa29857">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d8e7e9d3-5c38-4f69-bca4-184cdfa29857">
											<gml:posList>35.66898931298104 139.74833668740354 5.66 35.66905802525125 139.74837582814197 5.66 35.66905802525125 139.74837582814197 31.7 35.66898931298104 139.74833668740354 31.7 35.66898931298104 139.74833668740354 5.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7478</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">122.4087</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.06</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>