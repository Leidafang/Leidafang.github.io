<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_554ccea1-615b-4c87-98e2-2de338355503">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">17.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67263696995564 139.73887551978618 0 35.67269849889785 139.7388311505117 0 35.67264125831491 139.73871202548568 0 35.67255982037587 139.73877077883367 0 35.67262202667744 139.73890039217082 0 35.67264202587016 139.73888600807166 0 35.67263696995564 139.73887551978618 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67263696995564 139.73887551978618 9.27 35.67264202587016 139.73888600807166 9.27 35.67262202667744 139.73890039217082 9.27 35.67255982037587 139.73877077883367 9.27 35.67264125831491 139.73871202548568 9.27 35.67269849889785 139.7388311505117 9.27 35.67263696995564 139.73887551978618 9.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67263696995564 139.73887551978618 9.27 35.67269849889785 139.7388311505117 9.27 35.67269849889785 139.7388311505117 26.75 35.67263696995564 139.73887551978618 26.75 35.67263696995564 139.73887551978618 9.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67269849889785 139.7388311505117 9.27 35.67264125831491 139.73871202548568 9.27 35.67264125831491 139.73871202548568 26.75 35.67269849889785 139.7388311505117 26.75 35.67269849889785 139.7388311505117 9.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67264125831491 139.73871202548568 9.27 35.67255982037587 139.73877077883367 9.27 35.67255982037587 139.73877077883367 26.75 35.67264125831491 139.73871202548568 26.75 35.67264125831491 139.73871202548568 9.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67255982037587 139.73877077883367 9.27 35.67262202667744 139.73890039217082 9.27 35.67262202667744 139.73890039217082 26.75 35.67255982037587 139.73877077883367 26.75 35.67255982037587 139.73877077883367 9.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67262202667744 139.73890039217082 9.27 35.67264202587016 139.73888600807166 9.27 35.67264202587016 139.73888600807166 26.75 35.67262202667744 139.73890039217082 26.75 35.67262202667744 139.73890039217082 9.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67264202587016 139.73888600807166 9.27 35.67263696995564 139.73887551978618 9.27 35.67263696995564 139.73887551978618 26.75 35.67264202587016 139.73888600807166 26.75 35.67264202587016 139.73888600807166 9.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67263696995564 139.73887551978618 26.75 35.67269849889785 139.7388311505117 26.75 35.67264125831491 139.73871202548568 26.75 35.67255982037587 139.73877077883367 26.75 35.67262202667744 139.73890039217082 26.75 35.67264202587016 139.73888600807166 26.75 35.67263696995564 139.73887551978618 26.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-21b4d564-1d5c-446e-b5ab-86623ede0c9a"/>
							<gml:surfaceMember xlink:href="#poly-ff9483c4-9569-45b5-af62-6ccc8e818dba"/>
							<gml:surfaceMember xlink:href="#poly-7e1b9d4d-223c-4c6c-91b5-105941e14675"/>
							<gml:surfaceMember xlink:href="#poly-8c9e53f4-67f7-4864-942b-9ec110660ba8"/>
							<gml:surfaceMember xlink:href="#poly-2554e997-8e1f-4ea4-b22f-cd200cb8698e"/>
							<gml:surfaceMember xlink:href="#poly-15ee5d6d-8e7d-444d-abfc-9a49c313c849"/>
							<gml:surfaceMember xlink:href="#poly-bf48d6d6-8ac9-4128-babf-b04d464a7769"/>
							<gml:surfaceMember xlink:href="#poly-9740310c-1601-4027-b108-0ea41a4c248b"/>
							<gml:surfaceMember xlink:href="#poly-c19cdc67-33f8-4c27-bb2b-610cdd4514d6"/>
							<gml:surfaceMember xlink:href="#poly-602bb9ce-5195-48fc-9ce0-0496e524859d"/>
							<gml:surfaceMember xlink:href="#poly-1abe0a09-e2b0-4232-a559-12a304e2590a"/>
							<gml:surfaceMember xlink:href="#poly-68f58f76-6daf-4560-adcd-63c85042ebc0"/>
							<gml:surfaceMember xlink:href="#poly-24c6e349-8547-44ed-8e7a-66fa9042b92e"/>
							<gml:surfaceMember xlink:href="#poly-02423135-6079-4398-9a27-236e0d69fc1b"/>
							<gml:surfaceMember xlink:href="#poly-a25542de-ee4c-4f82-9013-41f3f8c115e8"/>
							<gml:surfaceMember xlink:href="#poly-d2fe7421-42c7-4acd-8878-cae1e4bb890a"/>
							<gml:surfaceMember xlink:href="#poly-431fb84c-5ad8-42b5-a35f-8e06296f73fd"/>
							<gml:surfaceMember xlink:href="#poly-1ebac887-245d-427e-9b4d-03ff56e2b73c"/>
							<gml:surfaceMember xlink:href="#poly-76236897-e710-452b-a55d-fc97e494cd17"/>
							<gml:surfaceMember xlink:href="#poly-0b79f638-3159-4b79-9697-6457ca924544"/>
							<gml:surfaceMember xlink:href="#poly-4e9b0a8e-d491-4585-8ba2-b7dd7cbfa7be"/>
							<gml:surfaceMember xlink:href="#poly-9db5ff3d-32ca-4d78-88db-967b1febaec2"/>
							<gml:surfaceMember xlink:href="#poly-6e3e8d52-fe57-4a93-9bf5-967cb19a680a"/>
							<gml:surfaceMember xlink:href="#poly-330c8cc3-5da3-4b51-b8ba-4addd9ee3b7c"/>
							<gml:surfaceMember xlink:href="#poly-3afee56a-96fd-4a4e-b04e-c60c6be1e903"/>
							<gml:surfaceMember xlink:href="#poly-c5020d05-e32f-4885-b151-579f0b52b94a"/>
							<gml:surfaceMember xlink:href="#poly-d69ef479-7b4a-479c-b5c0-e6a1d99ac91c"/>
							<gml:surfaceMember xlink:href="#poly-aded025d-95ff-40d1-b48b-7b4dcd497754"/>
							<gml:surfaceMember xlink:href="#poly-bf155a51-0c47-4654-af1d-d65d62715335"/>
							<gml:surfaceMember xlink:href="#poly-fd6aca93-c3a7-463b-bd25-bfb3bab040ac"/>
							<gml:surfaceMember xlink:href="#poly-b2acc361-7b1b-400b-812b-aebfbe04d21a"/>
							<gml:surfaceMember xlink:href="#poly-d612ed3c-177c-4bb6-a8c6-7c68277b4cc3"/>
							<gml:surfaceMember xlink:href="#poly-1f6a553e-d9ac-42a0-b6ce-5c68bc532c59"/>
							<gml:surfaceMember xlink:href="#poly-9baaff23-d878-464c-92a2-886a79e8633d"/>
							<gml:surfaceMember xlink:href="#poly-90161c5d-a4a1-4de3-9263-fcce52073830"/>
							<gml:surfaceMember xlink:href="#poly-091c7334-ed96-43a6-895c-04a65c579296"/>
							<gml:surfaceMember xlink:href="#poly-3b9b1c75-de72-4b67-863b-001598992060"/>
							<gml:surfaceMember xlink:href="#poly-18d2ed28-6616-480b-bf1e-97af6a5e44bf"/>
							<gml:surfaceMember xlink:href="#poly-2c7d10e1-e665-46ca-bb8f-12c9f8c58330"/>
							<gml:surfaceMember xlink:href="#poly-17b3be2f-31b2-46d8-b80d-711ffcad13af"/>
							<gml:surfaceMember xlink:href="#poly-a57d4570-0e0e-484e-9408-ebbe185c2140"/>
							<gml:surfaceMember xlink:href="#poly-fabc6eda-71c3-47ba-8578-d8f0362cba63"/>
							<gml:surfaceMember xlink:href="#poly-8a4d4f3b-2ef0-4c41-b914-8bfdd2bb4e6d"/>
							<gml:surfaceMember xlink:href="#poly-7ba9eadf-c69f-4bf0-a18e-2e05e24b0ea7"/>
							<gml:surfaceMember xlink:href="#poly-5a370f27-8d28-4874-90d1-ac99d24208cc"/>
							<gml:surfaceMember xlink:href="#poly-ba199c8a-fbd2-4119-8376-3e4efadfc96e"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_554ccea1-615b-4c87-98e2-2de338355503_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-17e6b5da-72cc-488d-833e-f10805aaf811">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67265273728656 139.73877512100572 26.825 35.67264526886059 139.73878015600437 26.825 35.672641512578046 139.7387717871338 26.825 35.67264898100366 139.7387667521346 26.825 35.67265273728656 139.73877512100572 26.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a0ad138-6624-447e-aed9-d27c14cad7b6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672638656747296 139.73877372365212 26.825 35.672642413021045 139.7387820814759 26.825 35.67263396261985 139.7387877804255 26.825 35.67263020634649 139.73877942260233 26.825 35.672638656747296 139.73877372365212 26.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d07d27db-1b72-4668-9605-058674250934">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67261282806844 139.73879114141266 26.825 35.672621476667565 139.73878530967235 26.825 35.67262526906478 139.73879375582484 26.825 35.672616620465256 139.73879958756453 26.825 35.67261282806844 139.73879114141266 26.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d68e7a2d-f81d-4dd4-a26f-2e3253601f46">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672616620465256 139.73879958756453 26.825 35.672616620465256 139.73879958756453 28.618 35.67261282806844 139.73879114141266 28.618 35.67261282806844 139.73879114141266 26.825 35.672616620465256 139.73879958756453 26.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2b4ffbe-6b24-4650-9a06-0e9195a3c952">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67261413399706 139.73880126957465 26.825 35.67260590881647 139.73880681360276 26.825 35.672602116420165 139.7387983674517 26.825 35.67261033258665 139.7387928234336 26.825 35.67261413399706 139.73880126957465 26.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-02cf4521-76b1-4c94-8a6c-5817e8b84b6a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672659339482514 139.7388378135687 26.825 35.67264855044469 139.73881534651187 26.825 35.6726625318278 139.73880525555316 26.825 35.67267332087616 139.73882773365912 26.825 35.672659339482514 139.7388378135687 26.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dcd667c5-ed47-4da8-bb29-99a9aa4d82ca">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67265226248466 139.73885923016738 26.825 35.67265012283568 139.73885490243254 26.825 35.67265843780022 139.73884890539097 26.825 35.67266057744941 139.73885323312612 26.825 35.67265226248466 139.73885923016738 26.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a3550cd-2aad-4fff-b238-7dc157116903">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67266057744941 139.73885323312612 27.069 35.672662301808664 139.7388567218113 27.069 35.672653986843734 139.73886271885232 27.069 35.67265226248466 139.73885923016738 27.069 35.67266057744941 139.73885323312612 27.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19b13f63-aa43-4be5-9ddc-9d0c86e011ab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19b13f63-aa43-4be5-9ddc-9d0c86e011ab_0">
											<gml:posList>35.672642413021045 139.7387820814759 26.825 35.672638656747296 139.73877372365212 26.825 35.672638656747296 139.73877372365212 28.618 35.672642413021045 139.7387820814759 28.618 35.672642413021045 139.7387820814759 26.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eac709bc-6fa2-44d6-a607-652a64c246b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eac709bc-6fa2-44d6-a607-652a64c246b3_0">
											<gml:posList>35.67261413399706 139.73880126957465 26.825 35.67261033258665 139.7387928234336 26.825 35.67261033258665 139.7387928234336 28.618 35.67261413399706 139.73880126957465 28.618 35.67261413399706 139.73880126957465 26.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5dad55ba-dd3c-4c15-8bf9-6fee9713f8d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5dad55ba-dd3c-4c15-8bf9-6fee9713f8d6_0">
											<gml:posList>35.67266057744941 139.73885323312612 27.069 35.67265226248466 139.73885923016738 27.069 35.67265226248466 139.73885923016738 26.825 35.67266057744941 139.73885323312612 26.825 35.67266057744941 139.73885323312612 27.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b92b1878-5508-40eb-ae73-02685d91ad2c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b92b1878-5508-40eb-ae73-02685d91ad2c_0">
											<gml:posList>35.672602116420165 139.7387983674517 26.825 35.67260590881647 139.73880681360276 26.825 35.67260590881647 139.73880681360276 28.618 35.672602116420165 139.7387983674517 28.618 35.672602116420165 139.7387983674517 26.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3220081a-b758-4273-9b5a-1c560b80449f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3220081a-b758-4273-9b5a-1c560b80449f_0">
											<gml:posList>35.67261033258665 139.7387928234336 26.825 35.672602116420165 139.7387983674517 26.825 35.672602116420165 139.7387983674517 28.618 35.67261033258665 139.7387928234336 28.618 35.67261033258665 139.7387928234336 26.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d8f148d-d773-4e70-b375-41cdd0f12adf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d8f148d-d773-4e70-b375-41cdd0f12adf_0">
											<gml:posList>35.672602116420165 139.7387983674517 28.618 35.67260590881647 139.73880681360276 28.618 35.67261413399706 139.73880126957465 28.618 35.67261033258665 139.7387928234336 28.618 35.672602116420165 139.7387983674517 28.618</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4b635a4-71d0-42a4-913e-ee2c3355917b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b4b635a4-71d0-42a4-913e-ee2c3355917b_0">
											<gml:posList>35.67261413399706 139.73880126957465 26.825 35.67261413399706 139.73880126957465 28.618 35.67260590881647 139.73880681360276 28.618 35.67260590881647 139.73880681360276 26.825 35.67261413399706 139.73880126957465 26.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-09d9c28a-ec20-46cb-ab72-e65230579392">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-09d9c28a-ec20-46cb-ab72-e65230579392_0">
											<gml:posList>35.672621476667565 139.73878530967235 26.825 35.67261282806844 139.73879114141266 26.825 35.67261282806844 139.73879114141266 28.618 35.672621476667565 139.73878530967235 28.618 35.672621476667565 139.73878530967235 26.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cfc72cf4-50ec-4c35-96e3-1bca189048ae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cfc72cf4-50ec-4c35-96e3-1bca189048ae_0">
											<gml:posList>35.67262526906478 139.73879375582484 28.618 35.672621476667565 139.73878530967235 28.618 35.67261282806844 139.73879114141266 28.618 35.672616620465256 139.73879958756453 28.618 35.67262526906478 139.73879375582484 28.618</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-719c1865-ceec-4e63-a189-879f9bde7150">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-719c1865-ceec-4e63-a189-879f9bde7150_0">
											<gml:posList>35.672616620465256 139.73879958756453 26.825 35.67262526906478 139.73879375582484 26.825 35.67262526906478 139.73879375582484 28.618 35.672616620465256 139.73879958756453 28.618 35.672616620465256 139.73879958756453 26.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d9d01b8-6651-41e0-98f5-0d427ae7310f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d9d01b8-6651-41e0-98f5-0d427ae7310f_0">
											<gml:posList>35.67262526906478 139.73879375582484 26.825 35.672621476667565 139.73878530967235 26.825 35.672621476667565 139.73878530967235 28.618 35.67262526906478 139.73879375582484 28.618 35.67262526906478 139.73879375582484 26.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c69f411-7751-4031-8df9-ad028751cecd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c69f411-7751-4031-8df9-ad028751cecd_0">
											<gml:posList>35.67263396261985 139.7387877804255 26.825 35.67263396261985 139.7387877804255 28.618 35.67263020634649 139.73877942260233 28.618 35.67263020634649 139.73877942260233 26.825 35.67263396261985 139.7387877804255 26.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b9c4f16-3c1a-41cd-8a78-0ebeb04f91c8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b9c4f16-3c1a-41cd-8a78-0ebeb04f91c8_0">
											<gml:posList>35.672638656747296 139.73877372365212 26.825 35.67263020634649 139.73877942260233 26.825 35.67263020634649 139.73877942260233 28.618 35.672638656747296 139.73877372365212 28.618 35.672638656747296 139.73877372365212 26.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-809d5300-669b-4ce7-be4b-2581a674a108">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-809d5300-669b-4ce7-be4b-2581a674a108_0">
											<gml:posList>35.67263396261985 139.7387877804255 28.618 35.672642413021045 139.7387820814759 28.618 35.672638656747296 139.73877372365212 28.618 35.67263020634649 139.73877942260233 28.618 35.67263396261985 139.7387877804255 28.618</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c61764d3-b09b-48ed-9622-3379686570a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c61764d3-b09b-48ed-9622-3379686570a8_0">
											<gml:posList>35.67263396261985 139.7387877804255 26.825 35.672642413021045 139.7387820814759 26.825 35.672642413021045 139.7387820814759 28.618 35.67263396261985 139.7387877804255 28.618 35.67263396261985 139.7387877804255 26.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e3a5d08-e33d-4dd2-ac40-36196d583f0e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e3a5d08-e33d-4dd2-ac40-36196d583f0e_0">
											<gml:posList>35.672641512578046 139.7387717871338 26.825 35.67264526886059 139.73878015600437 26.825 35.67264526886059 139.73878015600437 28.618 35.672641512578046 139.7387717871338 28.618 35.672641512578046 139.7387717871338 26.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-34ac4a00-866b-42d1-8f7b-5e82a4b8c932">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-34ac4a00-866b-42d1-8f7b-5e82a4b8c932_0">
											<gml:posList>35.67264898100366 139.7387667521346 26.825 35.672641512578046 139.7387717871338 26.825 35.672641512578046 139.7387717871338 28.618 35.67264898100366 139.7387667521346 28.618 35.67264898100366 139.7387667521346 26.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f9db9e97-c579-4143-9ad1-5eca49284101">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f9db9e97-c579-4143-9ad1-5eca49284101_0">
											<gml:posList>35.67265273728656 139.73877512100572 28.618 35.67264898100366 139.7387667521346 28.618 35.672641512578046 139.7387717871338 28.618 35.67264526886059 139.73878015600437 28.618 35.67265273728656 139.73877512100572 28.618</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78b3fa84-f618-4986-9bb7-4e1ea23c2b33">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78b3fa84-f618-4986-9bb7-4e1ea23c2b33_0">
											<gml:posList>35.67265273728656 139.73877512100572 26.825 35.67265273728656 139.73877512100572 28.618 35.67264526886059 139.73878015600437 28.618 35.67264526886059 139.73878015600437 26.825 35.67265273728656 139.73877512100572 26.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77c37c3d-5dab-46f7-93a0-f13af49d1673">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77c37c3d-5dab-46f7-93a0-f13af49d1673_0">
											<gml:posList>35.67264898100366 139.7387667521346 26.825 35.67264898100366 139.7387667521346 28.618 35.67265273728656 139.73877512100572 28.618 35.67265273728656 139.73877512100572 26.825 35.67264898100366 139.7387667521346 26.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0059e695-bbef-43a2-a2f7-f0e50ce12574">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0059e695-bbef-43a2-a2f7-f0e50ce12574_0">
											<gml:posList>35.67265226248466 139.73885923016738 27.069 35.672653986843734 139.73886271885232 27.069 35.672653986843734 139.73886271885232 28.096 35.67265012283568 139.73885490243254 28.096 35.67265012283568 139.73885490243254 26.825 35.67265226248466 139.73885923016738 26.825 35.67265226248466 139.73885923016738 27.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7df992a-02d9-46b9-8d35-c2b283fc946c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c7df992a-02d9-46b9-8d35-c2b283fc946c_0">
											<gml:posList>35.672659339482514 139.7388378135687 26.825 35.672659339482514 139.7388378135687 29.385 35.67264855044469 139.73881534651187 29.385 35.67264855044469 139.73881534651187 26.825 35.672659339482514 139.7388378135687 26.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dbdd8037-42a5-4968-ba11-845460547b3c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dbdd8037-42a5-4968-ba11-845460547b3c_0">
											<gml:posList>35.67265843780022 139.73884890539097 26.825 35.67265012283568 139.73885490243254 26.825 35.67265012283568 139.73885490243254 28.096 35.67265843780022 139.73884890539097 28.096 35.67265843780022 139.73884890539097 26.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f4b12374-b490-40a2-a91c-0807f0782a01">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f4b12374-b490-40a2-a91c-0807f0782a01_0">
											<gml:posList>35.6726625318278 139.73880525555316 26.825 35.67264855044469 139.73881534651187 26.825 35.67264855044469 139.73881534651187 29.385 35.6726625318278 139.73880525555316 29.385 35.6726625318278 139.73880525555316 26.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2e2301d7-af4a-4062-be79-1339d778eb3c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2e2301d7-af4a-4062-be79-1339d778eb3c_0">
											<gml:posList>35.67265843780022 139.73884890539097 28.096 35.67265012283568 139.73885490243254 28.096 35.672653986843734 139.73886271885232 28.096 35.672662301808664 139.7388567218113 28.096 35.67265843780022 139.73884890539097 28.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48072d01-c046-4e1c-9ba7-c5bfd4142e1f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-48072d01-c046-4e1c-9ba7-c5bfd4142e1f_0">
											<gml:posList>35.672653986843734 139.73886271885232 27.069 35.672662301808664 139.7388567218113 27.069 35.672662301808664 139.7388567218113 28.096 35.672653986843734 139.73886271885232 28.096 35.672653986843734 139.73886271885232 27.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e60c0303-f342-46d4-94f0-501db102d481">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e60c0303-f342-46d4-94f0-501db102d481_0">
											<gml:posList>35.67265843780022 139.73884890539097 26.825 35.67265843780022 139.73884890539097 28.096 35.672662301808664 139.7388567218113 28.096 35.672662301808664 139.7388567218113 27.069 35.67266057744941 139.73885323312612 27.069 35.67266057744941 139.73885323312612 26.825 35.67265843780022 139.73884890539097 26.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c597d76f-af94-43c3-8ddf-80f688ce6936">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c597d76f-af94-43c3-8ddf-80f688ce6936_0">
											<gml:posList>35.6726625318278 139.73880525555316 29.385 35.67264855044469 139.73881534651187 29.385 35.672659339482514 139.7388378135687 29.385 35.67267332087616 139.73882773365912 29.385 35.6726625318278 139.73880525555316 29.385</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60b05e68-633b-4491-be9f-e6922cd5403a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-60b05e68-633b-4491-be9f-e6922cd5403a_0">
											<gml:posList>35.672659339482514 139.7388378135687 26.825 35.67267332087616 139.73882773365912 26.825 35.67267332087616 139.73882773365912 29.385 35.672659339482514 139.7388378135687 29.385 35.672659339482514 139.7388378135687 26.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b5b91a7a-e058-49b4-bfad-d10f460f5c78">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b5b91a7a-e058-49b4-bfad-d10f460f5c78_0">
											<gml:posList>35.67267332087616 139.73882773365912 26.825 35.6726625318278 139.73880525555316 26.825 35.6726625318278 139.73880525555316 29.385 35.67267332087616 139.73882773365912 29.385 35.67267332087616 139.73882773365912 26.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-21b4d564-1d5c-446e-b5ab-86623ede0c9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21b4d564-1d5c-446e-b5ab-86623ede0c9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21b4d564-1d5c-446e-b5ab-86623ede0c9a">
											<gml:posList>35.67263696995563 139.73887551978618 9.27 35.67264202587015 139.73888600807163 9.27 35.67262202667742 139.73890039217082 9.27 35.67255982037586 139.73877077883367 9.27 35.67264125831488 139.73871202548568 9.27 35.67269849889783 139.7388311505117 9.27 35.67263696995563 139.73887551978618 9.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ff9483c4-9569-45b5-af62-6ccc8e818dba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff9483c4-9569-45b5-af62-6ccc8e818dba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff9483c4-9569-45b5-af62-6ccc8e818dba">
											<gml:posList>35.67257782521078 139.73879936819253 27.069 35.67257273112396 139.73879767302878 27.069 35.672588115673975 139.7388297230615 27.069 35.672591295722086 139.7388274326742 27.069 35.67257782521078 139.73879936819253 27.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7e1b9d4d-223c-4c6c-91b5-105941e14675">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e1b9d4d-223c-4c6c-91b5-105941e14675">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e1b9d4d-223c-4c6c-91b5-105941e14675">
											<gml:posList>35.672601459786776 139.73885753362984 29.838 35.672602250081766 139.73885382105257 29.838 35.67259114503781 139.7388306805416 29.838 35.672588115673975 139.7388297230615 29.838 35.672601459786776 139.73885753362984 29.838</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8c9e53f4-67f7-4864-942b-9ec110660ba8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c9e53f4-67f7-4864-942b-9ec110660ba8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c9e53f4-67f7-4864-942b-9ec110660ba8">
											<gml:posList>35.67264125831488 139.73871202548568 24.163 35.67255982037586 139.73877077883367 24.163 35.67257273112396 139.73879767302878 27.069 35.67264125831488 139.73871202548568 24.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2554e997-8e1f-4ea4-b22f-cd200cb8698e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2554e997-8e1f-4ea4-b22f-cd200cb8698e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2554e997-8e1f-4ea4-b22f-cd200cb8698e">
											<gml:posList>35.672588115673975 139.7388297230615 29.838 35.67259114503781 139.7388306805416 29.838 35.67262074739234 139.73880933681778 29.838 35.67262152868079 139.7388056352963 29.838 35.672588115673975 139.7388297230615 29.838</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-15ee5d6d-8e7d-444d-abfc-9a49c313c849">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15ee5d6d-8e7d-444d-abfc-9a49c313c849">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15ee5d6d-8e7d-444d-abfc-9a49c313c849">
											<gml:posList>35.672605630945796 139.7388662223618 27.069 35.672608819999645 139.73886392091828 27.069 35.67260464884912 139.73885524323265 27.069 35.672601459786776 139.73885753362984 27.069 35.672605630945796 139.7388662223618 27.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bf48d6d6-8ac9-4128-babf-b04d464a7769">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf48d6d6-8ac9-4128-babf-b04d464a7769">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf48d6d6-8ac9-4128-babf-b04d464a7769">
											<gml:posList>35.672631852449015 139.73883248838084 29.54 35.67262074739234 139.73880933681778 29.54 35.67259114503781 139.7388306805416 29.54 35.672602250081766 139.73885382105257 29.54 35.672631852449015 139.73883248838084 29.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9740310c-1601-4027-b108-0ea41a4c248b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9740310c-1601-4027-b108-0ea41a4c248b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9740310c-1601-4027-b108-0ea41a4c248b">
											<gml:posList>35.672605630945796 139.7388662223618 29.838 35.67260802919302 139.73886698174897 29.838 35.672621064686126 139.73885758785283 29.838 35.67262167532215 139.73885465979268 29.838 35.672605630945796 139.7388662223618 29.838</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c19cdc67-33f8-4c27-bb2b-610cdd4514d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c19cdc67-33f8-4c27-bb2b-610cdd4514d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c19cdc67-33f8-4c27-bb2b-610cdd4514d6">
											<gml:posList>35.67257273112396 139.73879767302878 27.069 35.67265531566668 139.73874127126572 27.069 35.67264125831488 139.73871202548568 24.163 35.67257273112396 139.73879767302878 27.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-602bb9ce-5195-48fc-9ce0-0496e524859d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-602bb9ce-5195-48fc-9ce0-0496e524859d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-602bb9ce-5195-48fc-9ce0-0496e524859d">
											<gml:posList>35.67257273112396 139.73879767302878 27.069 35.67257782521078 139.73879936819253 27.069 35.67265395938524 139.73874737057403 27.069 35.67265531566668 139.73874127126572 27.069 35.67257273112396 139.73879767302878 27.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1abe0a09-e2b0-4232-a559-12a304e2590a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1abe0a09-e2b0-4232-a559-12a304e2590a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1abe0a09-e2b0-4232-a559-12a304e2590a">
											<gml:posList>35.67262202667742 139.73890039217082 29.838 35.67262264631954 139.73889745305377 29.838 35.67260802919302 139.73886698174897 29.838 35.672605630945796 139.7388662223618 29.838 35.67262202667742 139.73890039217082 29.838</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-68f58f76-6daf-4560-adcd-63c85042ebc0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-68f58f76-6daf-4560-adcd-63c85042ebc0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-68f58f76-6daf-4560-adcd-63c85042ebc0">
											<gml:posList>35.67263487280776 139.73883345691877 29.838 35.672631852449015 139.73883248838084 29.838 35.672602250081766 139.73885382105257 29.838 35.672601459786776 139.73885753362984 29.838 35.67263487280776 139.73883345691877 29.838</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-24c6e349-8547-44ed-8e7a-66fa9042b92e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-24c6e349-8547-44ed-8e7a-66fa9042b92e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-24c6e349-8547-44ed-8e7a-66fa9042b92e">
											<gml:posList>35.6726355827334 139.73888814765016 29.553 35.672621064686126 139.73885758785283 29.553 35.67260802919302 139.73886698174897 29.553 35.67262264631954 139.73889745305377 29.553 35.6726355827334 139.73888814765016 29.553</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-02423135-6079-4398-9a27-236e0d69fc1b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-02423135-6079-4398-9a27-236e0d69fc1b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-02423135-6079-4398-9a27-236e0d69fc1b">
											<gml:posList>35.67262152868079 139.7388056352963 29.838 35.67262074739234 139.73880933681778 29.838 35.672631852449015 139.73883248838084 29.838 35.67263487280776 139.73883345691877 29.838 35.67262152868079 139.7388056352963 29.838</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a25542de-ee4c-4f82-9013-41f3f8c115e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a25542de-ee4c-4f82-9013-41f3f8c115e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a25542de-ee4c-4f82-9013-41f3f8c115e8">
											<gml:posList>35.67262167532215 139.73885465979268 29.838 35.672621064686126 139.73885758785283 29.838 35.6726355827334 139.73888814765016 29.838 35.67263796297037 139.73888892915264 29.838 35.67262167532215 139.73885465979268 29.838</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d2fe7421-42c7-4acd-8878-cae1e4bb890a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d2fe7421-42c7-4acd-8878-cae1e4bb890a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d2fe7421-42c7-4acd-8878-cae1e4bb890a">
											<gml:posList>35.67263796297037 139.73888892915264 29.838 35.6726355827334 139.73888814765016 29.838 35.67262264631954 139.73889745305377 29.838 35.67262202667742 139.73890039217082 29.838 35.67263796297037 139.73888892915264 29.838</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-431fb84c-5ad8-42b5-a35f-8e06296f73fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-431fb84c-5ad8-42b5-a35f-8e06296f73fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-431fb84c-5ad8-42b5-a35f-8e06296f73fd">
											<gml:posList>35.67263109218766 139.7388744772873 27.069 35.67263796297037 139.73888892915264 27.069 35.67263428125899 139.7388721979365 27.069 35.67263109218766 139.7388744772873 27.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1ebac887-245d-427e-9b4d-03ff56e2b73c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ebac887-245d-427e-9b4d-03ff56e2b73c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ebac887-245d-427e-9b4d-03ff56e2b73c">
											<gml:posList>35.67262167532215 139.73885465979268 26.825 35.67263109218766 139.7388744772873 26.825 35.67263428125899 139.7388721979365 26.825 35.67269344093579 139.73882954367343 26.825 35.67265395938524 139.73874737057403 26.825 35.67257782521078 139.73879936819253 26.825 35.672591295722086 139.7388274326742 26.825 35.67262152868079 139.7388056352963 26.825 35.67263487280776 139.73883345691877 26.825 35.67260464884912 139.73885524323265 26.825 35.672608819999645 139.73886392091828 26.825 35.67262167532215 139.73885465979268 26.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-76236897-e710-452b-a55d-fc97e494cd17">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-76236897-e710-452b-a55d-fc97e494cd17">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-76236897-e710-452b-a55d-fc97e494cd17">
											<gml:posList>35.67263796297037 139.73888892915264 27.069 35.67264202587015 139.73888600807163 27.069 35.67263696995563 139.73887551978618 27.069 35.67263428125899 139.7388721979365 27.069 35.67263796297037 139.73888892915264 27.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0b79f638-3159-4b79-9697-6457ca924544">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b79f638-3159-4b79-9697-6457ca924544">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b79f638-3159-4b79-9697-6457ca924544">
											<gml:posList>35.67263696995563 139.73887551978618 27.069 35.67269849889783 139.7388311505117 27.069 35.67269344093579 139.73882954367343 27.069 35.67263428125899 139.7388721979365 27.069 35.67263696995563 139.73887551978618 27.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4e9b0a8e-d491-4585-8ba2-b7dd7cbfa7be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4e9b0a8e-d491-4585-8ba2-b7dd7cbfa7be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4e9b0a8e-d491-4585-8ba2-b7dd7cbfa7be">
											<gml:posList>35.67265531566668 139.73874127126572 27.069 35.67265395938524 139.73874737057403 27.069 35.67269344093579 139.73882954367343 27.069 35.67269849889783 139.7388311505117 27.069 35.67265531566668 139.73874127126572 27.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9db5ff3d-32ca-4d78-88db-967b1febaec2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9db5ff3d-32ca-4d78-88db-967b1febaec2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9db5ff3d-32ca-4d78-88db-967b1febaec2">
											<gml:posList>35.67259114503781 139.7388306805416 29.838 35.67259114503781 139.7388306805416 29.54 35.67262074739234 139.73880933681778 29.54 35.67262074739234 139.73880933681778 29.838 35.67259114503781 139.7388306805416 29.838</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6e3e8d52-fe57-4a93-9bf5-967cb19a680a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e3e8d52-fe57-4a93-9bf5-967cb19a680a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e3e8d52-fe57-4a93-9bf5-967cb19a680a">
											<gml:posList>35.67262074739234 139.73880933681778 29.838 35.67262074739234 139.73880933681778 29.54 35.672631852449015 139.73883248838084 29.54 35.672631852449015 139.73883248838084 29.838 35.67262074739234 139.73880933681778 29.838</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-330c8cc3-5da3-4b51-b8ba-4addd9ee3b7c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-330c8cc3-5da3-4b51-b8ba-4addd9ee3b7c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-330c8cc3-5da3-4b51-b8ba-4addd9ee3b7c">
											<gml:posList>35.672631852449015 139.73883248838084 29.838 35.672631852449015 139.73883248838084 29.54 35.672602250081766 139.73885382105257 29.54 35.672602250081766 139.73885382105257 29.838 35.672631852449015 139.73883248838084 29.838</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3afee56a-96fd-4a4e-b04e-c60c6be1e903">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3afee56a-96fd-4a4e-b04e-c60c6be1e903">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3afee56a-96fd-4a4e-b04e-c60c6be1e903">
											<gml:posList>35.672621064686126 139.73885758785283 29.838 35.672621064686126 139.73885758785283 29.553 35.6726355827334 139.73888814765016 29.553 35.6726355827334 139.73888814765016 29.838 35.672621064686126 139.73885758785283 29.838</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c5020d05-e32f-4885-b151-579f0b52b94a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c5020d05-e32f-4885-b151-579f0b52b94a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c5020d05-e32f-4885-b151-579f0b52b94a">
											<gml:posList>35.67262264631954 139.73889745305377 29.838 35.67262264631954 139.73889745305377 29.553 35.67260802919302 139.73886698174897 29.553 35.67260802919302 139.73886698174897 29.838 35.67262264631954 139.73889745305377 29.838</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d69ef479-7b4a-479c-b5c0-e6a1d99ac91c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d69ef479-7b4a-479c-b5c0-e6a1d99ac91c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d69ef479-7b4a-479c-b5c0-e6a1d99ac91c">
											<gml:posList>35.67264125831488 139.73871202548568 9.27 35.67255982037586 139.73877077883367 9.27 35.67255982037586 139.73877077883367 24.163 35.67264125831488 139.73871202548568 24.163 35.67264125831488 139.73871202548568 9.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aded025d-95ff-40d1-b48b-7b4dcd497754">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aded025d-95ff-40d1-b48b-7b4dcd497754">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aded025d-95ff-40d1-b48b-7b4dcd497754">
											<gml:posList>35.67264125831488 139.73871202548568 24.163 35.67265531566668 139.73874127126572 27.069 35.67269849889783 139.7388311505117 27.069 35.67269849889783 139.7388311505117 9.27 35.67264125831488 139.73871202548568 9.27 35.67264125831488 139.73871202548568 24.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bf155a51-0c47-4654-af1d-d65d62715335">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf155a51-0c47-4654-af1d-d65d62715335">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf155a51-0c47-4654-af1d-d65d62715335">
											<gml:posList>35.67257782521078 139.73879936819253 27.069 35.67257782521078 139.73879936819253 26.825 35.67265395938524 139.73874737057403 26.825 35.67265395938524 139.73874737057403 27.069 35.67257782521078 139.73879936819253 27.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fd6aca93-c3a7-463b-bd25-bfb3bab040ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fd6aca93-c3a7-463b-bd25-bfb3bab040ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fd6aca93-c3a7-463b-bd25-bfb3bab040ac">
											<gml:posList>35.67265395938524 139.73874737057403 27.069 35.67265395938524 139.73874737057403 26.825 35.67269344093579 139.73882954367343 26.825 35.67269344093579 139.73882954367343 27.069 35.67265395938524 139.73874737057403 27.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b2acc361-7b1b-400b-812b-aebfbe04d21a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b2acc361-7b1b-400b-812b-aebfbe04d21a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b2acc361-7b1b-400b-812b-aebfbe04d21a">
											<gml:posList>35.672591295722086 139.7388274326742 27.069 35.672591295722086 139.7388274326742 26.825 35.67257782521078 139.73879936819253 26.825 35.67257782521078 139.73879936819253 27.069 35.672591295722086 139.7388274326742 27.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d612ed3c-177c-4bb6-a8c6-7c68277b4cc3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d612ed3c-177c-4bb6-a8c6-7c68277b4cc3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d612ed3c-177c-4bb6-a8c6-7c68277b4cc3">
											<gml:posList>35.672591295722086 139.7388274326742 27.069 35.672588115673975 139.7388297230615 27.069 35.672588115673975 139.7388297230615 29.838 35.67262152868079 139.7388056352963 29.838 35.67262152868079 139.7388056352963 26.825 35.672591295722086 139.7388274326742 26.825 35.672591295722086 139.7388274326742 27.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1f6a553e-d9ac-42a0-b6ce-5c68bc532c59">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f6a553e-d9ac-42a0-b6ce-5c68bc532c59">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f6a553e-d9ac-42a0-b6ce-5c68bc532c59">
											<gml:posList>35.67262152868079 139.7388056352963 29.838 35.67263487280776 139.73883345691877 29.838 35.67263487280776 139.73883345691877 26.825 35.67262152868079 139.7388056352963 26.825 35.67262152868079 139.7388056352963 29.838</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9baaff23-d878-464c-92a2-886a79e8633d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9baaff23-d878-464c-92a2-886a79e8633d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9baaff23-d878-464c-92a2-886a79e8633d">
											<gml:posList>35.672588115673975 139.7388297230615 27.069 35.67257273112396 139.73879767302878 27.069 35.67255982037586 139.73877077883367 24.163 35.67255982037586 139.73877077883367 9.27 35.67262202667742 139.73890039217082 9.27 35.67262202667742 139.73890039217082 29.838 35.672605630945796 139.7388662223618 29.838 35.672605630945796 139.7388662223618 27.069 35.672601459786776 139.73885753362984 27.069 35.672601459786776 139.73885753362984 29.838 35.672588115673975 139.7388297230615 29.838 35.672588115673975 139.7388297230615 27.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-90161c5d-a4a1-4de3-9263-fcce52073830">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-90161c5d-a4a1-4de3-9263-fcce52073830">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-90161c5d-a4a1-4de3-9263-fcce52073830">
											<gml:posList>35.672602250081766 139.73885382105257 29.838 35.672602250081766 139.73885382105257 29.54 35.67259114503781 139.7388306805416 29.54 35.67259114503781 139.7388306805416 29.838 35.672602250081766 139.73885382105257 29.838</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-091c7334-ed96-43a6-895c-04a65c579296">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-091c7334-ed96-43a6-895c-04a65c579296">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-091c7334-ed96-43a6-895c-04a65c579296">
											<gml:posList>35.672601459786776 139.73885753362984 29.838 35.672601459786776 139.73885753362984 27.069 35.67260464884912 139.73885524323265 27.069 35.67260464884912 139.73885524323265 26.825 35.67263487280776 139.73883345691877 26.825 35.67263487280776 139.73883345691877 29.838 35.672601459786776 139.73885753362984 29.838</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3b9b1c75-de72-4b67-863b-001598992060">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3b9b1c75-de72-4b67-863b-001598992060">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3b9b1c75-de72-4b67-863b-001598992060">
											<gml:posList>35.67269344093579 139.73882954367343 27.069 35.67269344093579 139.73882954367343 26.825 35.67263428125899 139.7388721979365 26.825 35.67263428125899 139.7388721979365 27.069 35.67269344093579 139.73882954367343 27.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-18d2ed28-6616-480b-bf1e-97af6a5e44bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18d2ed28-6616-480b-bf1e-97af6a5e44bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18d2ed28-6616-480b-bf1e-97af6a5e44bf">
											<gml:posList>35.67263696995563 139.73887551978618 9.27 35.67269849889783 139.7388311505117 9.27 35.67269849889783 139.7388311505117 27.069 35.67263696995563 139.73887551978618 27.069 35.67263696995563 139.73887551978618 9.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2c7d10e1-e665-46ca-bb8f-12c9f8c58330">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c7d10e1-e665-46ca-bb8f-12c9f8c58330">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c7d10e1-e665-46ca-bb8f-12c9f8c58330">
											<gml:posList>35.672608819999645 139.73886392091828 27.069 35.672608819999645 139.73886392091828 26.825 35.67260464884912 139.73885524323265 26.825 35.67260464884912 139.73885524323265 27.069 35.672608819999645 139.73886392091828 27.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-17b3be2f-31b2-46d8-b80d-711ffcad13af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17b3be2f-31b2-46d8-b80d-711ffcad13af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17b3be2f-31b2-46d8-b80d-711ffcad13af">
											<gml:posList>35.672608819999645 139.73886392091828 27.069 35.672605630945796 139.7388662223618 27.069 35.672605630945796 139.7388662223618 29.838 35.67262167532215 139.73885465979268 29.838 35.67262167532215 139.73885465979268 26.825 35.672608819999645 139.73886392091828 26.825 35.672608819999645 139.73886392091828 27.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a57d4570-0e0e-484e-9408-ebbe185c2140">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a57d4570-0e0e-484e-9408-ebbe185c2140">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a57d4570-0e0e-484e-9408-ebbe185c2140">
											<gml:posList>35.67260802919302 139.73886698174897 29.838 35.67260802919302 139.73886698174897 29.553 35.672621064686126 139.73885758785283 29.553 35.672621064686126 139.73885758785283 29.838 35.67260802919302 139.73886698174897 29.838</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fabc6eda-71c3-47ba-8578-d8f0362cba63">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fabc6eda-71c3-47ba-8578-d8f0362cba63">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fabc6eda-71c3-47ba-8578-d8f0362cba63">
											<gml:posList>35.67262167532215 139.73885465979268 26.825 35.67262167532215 139.73885465979268 29.838 35.67263796297037 139.73888892915264 29.838 35.67263796297037 139.73888892915264 27.069 35.67263109218766 139.7388744772873 27.069 35.67263109218766 139.7388744772873 26.825 35.67262167532215 139.73885465979268 26.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8a4d4f3b-2ef0-4c41-b914-8bfdd2bb4e6d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a4d4f3b-2ef0-4c41-b914-8bfdd2bb4e6d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a4d4f3b-2ef0-4c41-b914-8bfdd2bb4e6d">
											<gml:posList>35.67263428125899 139.7388721979365 27.069 35.67263428125899 139.7388721979365 26.825 35.67263109218766 139.7388744772873 26.825 35.67263109218766 139.7388744772873 27.069 35.67263428125899 139.7388721979365 27.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7ba9eadf-c69f-4bf0-a18e-2e05e24b0ea7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ba9eadf-c69f-4bf0-a18e-2e05e24b0ea7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ba9eadf-c69f-4bf0-a18e-2e05e24b0ea7">
											<gml:posList>35.67264202587015 139.73888600807163 9.27 35.67263696995563 139.73887551978618 9.27 35.67263696995563 139.73887551978618 27.069 35.67264202587015 139.73888600807163 27.069 35.67264202587015 139.73888600807163 9.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5a370f27-8d28-4874-90d1-ac99d24208cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a370f27-8d28-4874-90d1-ac99d24208cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a370f27-8d28-4874-90d1-ac99d24208cc">
											<gml:posList>35.6726355827334 139.73888814765016 29.838 35.6726355827334 139.73888814765016 29.553 35.67262264631954 139.73889745305377 29.553 35.67262264631954 139.73889745305377 29.838 35.6726355827334 139.73888814765016 29.838</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ba199c8a-fbd2-4119-8376-3e4efadfc96e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba199c8a-fbd2-4119-8376-3e4efadfc96e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba199c8a-fbd2-4119-8376-3e4efadfc96e">
											<gml:posList>35.67263796297037 139.73888892915264 27.069 35.67263796297037 139.73888892915264 29.838 35.67262202667742 139.73890039217082 29.838 35.67262202667742 139.73890039217082 9.27 35.67264202587015 139.73888600807163 9.27 35.67264202587015 139.73888600807163 27.069 35.67263796297037 139.73888892915264 27.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-9929</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">134.06855</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.03</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>