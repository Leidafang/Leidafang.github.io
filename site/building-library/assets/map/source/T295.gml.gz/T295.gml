<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_55a69497-7fd6-429a-8249-0c014dbe4e14">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">38</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67058843366017 139.74360792073648 0 35.67061306753865 139.7434740894359 0 35.67051536558006 139.743447080323 0 35.67049582187559 139.7435532238038 0 35.67052811571155 139.7435621461752 0 35.67052301655119 139.7435898338608 0 35.67058843366017 139.74360792073648 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67058843366017 139.74360792073648 7.314 35.67052301655119 139.7435898338608 7.314 35.67052811571155 139.7435621461752 7.314 35.67049582187559 139.7435532238038 7.314 35.67051536558006 139.743447080323 7.314 35.67061306753865 139.7434740894359 7.314 35.67058843366017 139.74360792073648 7.314</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67058843366017 139.74360792073648 7.314 35.67061306753865 139.7434740894359 7.314 35.67061306753865 139.7434740894359 40.91 35.67058843366017 139.74360792073648 40.91 35.67058843366017 139.74360792073648 7.314</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67061306753865 139.7434740894359 7.314 35.67051536558006 139.743447080323 7.314 35.67051536558006 139.743447080323 40.91 35.67061306753865 139.7434740894359 40.91 35.67061306753865 139.7434740894359 7.314</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67051536558006 139.743447080323 7.314 35.67049582187559 139.7435532238038 7.314 35.67049582187559 139.7435532238038 40.91 35.67051536558006 139.743447080323 40.91 35.67051536558006 139.743447080323 7.314</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67049582187559 139.7435532238038 7.314 35.67052811571155 139.7435621461752 7.314 35.67052811571155 139.7435621461752 40.91 35.67049582187559 139.7435532238038 40.91 35.67049582187559 139.7435532238038 7.314</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67052811571155 139.7435621461752 7.314 35.67052301655119 139.7435898338608 7.314 35.67052301655119 139.7435898338608 40.91 35.67052811571155 139.7435621461752 40.91 35.67052811571155 139.7435621461752 7.314</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67052301655119 139.7435898338608 7.314 35.67058843366017 139.74360792073648 7.314 35.67058843366017 139.74360792073648 40.91 35.67052301655119 139.7435898338608 40.91 35.67052301655119 139.7435898338608 7.314</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67058843366017 139.74360792073648 40.91 35.67061306753865 139.7434740894359 40.91 35.67051536558006 139.743447080323 40.91 35.67049582187559 139.7435532238038 40.91 35.67052811571155 139.7435621461752 40.91 35.67052301655119 139.7435898338608 40.91 35.67058843366017 139.74360792073648 40.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-30904da7-e0c9-4b0f-9858-ffd9d486a5fe"/>
							<gml:surfaceMember xlink:href="#poly-ef760337-5d55-4252-8cb3-e0772cd70f9e"/>
							<gml:surfaceMember xlink:href="#poly-f9bf8142-beb7-40f4-89b6-9f8814c94fe6"/>
							<gml:surfaceMember xlink:href="#poly-d38d2be8-9db7-4361-9d45-7484441ff4ea"/>
							<gml:surfaceMember xlink:href="#poly-bf54b899-05a2-4151-a4f3-13a3645dbe2f"/>
							<gml:surfaceMember xlink:href="#poly-267e0df0-1488-4286-9c5d-f91355a12cbf"/>
							<gml:surfaceMember xlink:href="#poly-183d1803-e98c-4117-acf6-57789258f3f3"/>
							<gml:surfaceMember xlink:href="#poly-d536ccfc-8bd5-4c7c-969f-a63523cb83d5"/>
							<gml:surfaceMember xlink:href="#poly-865f0a20-4316-48e6-b6fd-943c49b81a0e"/>
							<gml:surfaceMember xlink:href="#poly-c760c4b5-b964-4f18-beaa-ba3a905c1e76"/>
							<gml:surfaceMember xlink:href="#poly-9653c727-a55e-4b33-94b9-ce0730d22729"/>
							<gml:surfaceMember xlink:href="#poly-6776d368-623e-4424-a627-b2195eb3189d"/>
							<gml:surfaceMember xlink:href="#poly-dc3715c0-2688-4e83-95ab-2d95c69f270b"/>
							<gml:surfaceMember xlink:href="#poly-ebf4e7dd-91ac-498a-baf5-f7d9c43fe5b1"/>
							<gml:surfaceMember xlink:href="#poly-1d8194ec-23c3-43cc-a6d2-eb209deedcd2"/>
							<gml:surfaceMember xlink:href="#poly-10c097f5-dfd0-4b48-b461-1a7ed55fd644"/>
							<gml:surfaceMember xlink:href="#poly-17641392-08e4-4a80-ab83-c037625106e2"/>
							<gml:surfaceMember xlink:href="#poly-fbe2218e-8ecc-4041-b130-ecf254bbe198"/>
							<gml:surfaceMember xlink:href="#poly-102f1fe9-24be-4cc3-a6b7-3cbb88e844cb"/>
							<gml:surfaceMember xlink:href="#poly-8309a86a-4efb-4cab-b5da-240d454b6a8a"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_55a69497-7fd6-429a-8249-0c014dbe4e14_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-426af7ab-ed92-4381-beb4-e0eb032bfadb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-426af7ab-ed92-4381-beb4-e0eb032bfadb_0">
											<gml:posList>35.67052862783844 139.74355992529948 37.398 35.67052862783844 139.74355992529948 38.692 35.67052871758037 139.74355939497755 37.398 35.67052862783844 139.74355992529948 37.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ed9cad51-e1d2-4fdf-82cd-3bc687b52606">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ed9cad51-e1d2-4fdf-82cd-3bc687b52606_0">
											<gml:posList>35.67052871758037 139.74355939497755 37.398 35.67052862783844 139.74355992529948 38.692 35.67052871758037 139.74355939497755 45.918 35.67052871758037 139.74355939497755 37.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cbe54598-f9d4-4df4-a80f-d08907243f9f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cbe54598-f9d4-4df4-a80f-d08907243f9f_0">
											<gml:posList>35.67052871758037 139.74355939497755 45.918 35.67052862783844 139.74355992529948 38.692 35.670524776539146 139.74358084021915 45.918 35.67052871758037 139.74355939497755 45.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-36d19da7-23c8-44d0-8d2d-616418d89532">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-36d19da7-23c8-44d0-8d2d-616418d89532_0">
											<gml:posList>35.670524776539146 139.74358084021915 45.918 35.67052862783844 139.74355992529948 38.692 35.670523079622555 139.74358980065136 38.692 35.670524776539146 139.74358084021915 45.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-28e74889-679e-4ae3-b2e5-10fe0f788968">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-28e74889-679e-4ae3-b2e5-10fe0f788968_0">
											<gml:posList>35.670524776539146 139.74358084021915 45.918 35.670523079622555 139.74358980065136 38.692 35.670523079622555 139.74358980065136 45.918 35.670524776539146 139.74358084021915 45.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37828c05-2b59-4ab8-8dcb-6916e5263942">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-37828c05-2b59-4ab8-8dcb-6916e5263942_0">
											<gml:posList>35.67052526868945 139.74358809707402 37.398 35.67053036784938 139.74356040938756 38.692 35.67053036784938 139.74356040938756 37.398 35.67052526868945 139.74358809707402 37.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ae87840-8005-4b0f-9de4-eca2fa5dafbc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9ae87840-8005-4b0f-9de4-eca2fa5dafbc_0">
											<gml:posList>35.67052526868945 139.74358809707402 37.398 35.67052526868945 139.74358809707402 38.692 35.67053036784938 139.74356040938756 38.692 35.67052526868945 139.74358809707402 37.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-972e692e-703f-4c79-82eb-ebef78772e63">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-972e692e-703f-4c79-82eb-ebef78772e63_0">
											<gml:posList>35.67053036784938 139.74356040938756 38.692 35.67052862783844 139.74355992529948 37.398 35.67053036784938 139.74356040938756 37.398 35.67053036784938 139.74356040938756 38.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f55f3e16-a972-4500-ac2f-ee95cb689954">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f55f3e16-a972-4500-ac2f-ee95cb689954_0">
											<gml:posList>35.67053036784938 139.74356040938756 38.692 35.67052862783844 139.74355992529948 38.692 35.67052862783844 139.74355992529948 37.398 35.67053036784938 139.74356040938756 38.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8439bb0d-a2ef-47b2-98b9-c4c25277fecc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8439bb0d-a2ef-47b2-98b9-c4c25277fecc_0">
											<gml:posList>35.670538290004004 139.74358336573655 37.398 35.67054030932264 139.743571599186 45.918 35.670538290004004 139.74358336573655 45.918 35.670538290004004 139.74358336573655 37.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3125cbb4-fc0f-42a1-bb9a-4dd0b906c30b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3125cbb4-fc0f-42a1-bb9a-4dd0b906c30b_0">
											<gml:posList>35.670538290004004 139.74358336573655 37.398 35.67054030932264 139.743571599186 37.398 35.67054030932264 139.743571599186 45.918 35.670538290004004 139.74358336573655 37.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cbfc14ff-8385-487a-9ac1-e34bc3260a0c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cbfc14ff-8385-487a-9ac1-e34bc3260a0c_0">
											<gml:posList>35.67055729368329 139.74359912960395 38.692 35.670523079622555 139.74358980065136 45.918 35.670523079622555 139.74358980065136 38.692 35.67055729368329 139.74359912960395 38.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-855dc160-8d7c-40b8-a89c-9b9b10efcad4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-855dc160-8d7c-40b8-a89c-9b9b10efcad4_0">
											<gml:posList>35.67055729368329 139.74359912960395 38.692 35.67055729368329 139.74359912960395 45.918 35.670523079622555 139.74358980065136 45.918 35.67055729368329 139.74359912960395 38.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c47a3064-2dee-43c1-8ccc-3bfd9697457d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c47a3064-2dee-43c1-8ccc-3bfd9697457d_0">
											<gml:posList>35.67052526868945 139.74358809707402 37.398 35.67055765268461 139.74359705250072 38.692 35.67052526868945 139.74358809707402 38.692 35.67052526868945 139.74358809707402 37.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0577a37-c8a4-4c71-b539-4e1b4195c52e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d0577a37-c8a4-4c71-b539-4e1b4195c52e_0">
											<gml:posList>35.67052526868945 139.74358809707402 37.398 35.67055765268461 139.74359705250072 37.398 35.67055765268461 139.74359705250072 38.692 35.67052526868945 139.74358809707402 37.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ead6a21-58d3-49bb-9405-cc8489db2cb5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7ead6a21-58d3-49bb-9405-cc8489db2cb5_0">
											<gml:posList>35.67056265225915 139.743568779462 45.918 35.67052871758037 139.74355939497755 45.918 35.67054030932264 139.743571599186 45.918 35.67056265225915 139.743568779462 45.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c6bd6aa-6684-4498-8bd0-7f3ce2553a6c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6c6bd6aa-6684-4498-8bd0-7f3ce2553a6c_0">
											<gml:posList>35.67055729368329 139.74359912960395 45.918 35.67056265225915 139.743568779462 45.918 35.67054774722747 139.74358580742495 45.918 35.67055729368329 139.74359912960395 45.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eed9d96d-b6f9-4642-8848-88b7eae26e98">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eed9d96d-b6f9-4642-8848-88b7eae26e98_0">
											<gml:posList>35.670538290004004 139.74358336573655 45.918 35.670523079622555 139.74358980065136 45.918 35.67055729368329 139.74359912960395 45.918 35.670538290004004 139.74358336573655 45.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c424c4e5-b862-4863-b8b8-5d2e157d5e3c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c424c4e5-b862-4863-b8b8-5d2e157d5e3c_0">
											<gml:posList>35.670524776539146 139.74358084021915 45.918 35.670523079622555 139.74358980065136 45.918 35.670538290004004 139.74358336573655 45.918 35.670524776539146 139.74358084021915 45.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d823c70a-8135-4131-8364-2b476df8a6c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d823c70a-8135-4131-8364-2b476df8a6c3_0">
											<gml:posList>35.67054030932264 139.743571599186 45.918 35.67052871758037 139.74355939497755 45.918 35.670524776539146 139.74358084021915 45.918 35.67054030932264 139.743571599186 45.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-86ede98a-af40-479c-a3b5-d5f4724e73c8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-86ede98a-af40-479c-a3b5-d5f4724e73c8_0">
											<gml:posList>35.67054976654633 139.74357404087309 45.918 35.67056265225915 139.743568779462 45.918 35.67054030932264 139.743571599186 45.918 35.67054976654633 139.74357404087309 45.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa3ff1ab-b181-4d0a-af51-5baccb3a2cc3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aa3ff1ab-b181-4d0a-af51-5baccb3a2cc3_0">
											<gml:posList>35.67054774722747 139.74358580742495 45.918 35.67056265225915 139.743568779462 45.918 35.67054976654633 139.74357404087309 45.918 35.67054774722747 139.74358580742495 45.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4491d403-7177-429f-85eb-e0396b86cd20">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4491d403-7177-429f-85eb-e0396b86cd20_0">
											<gml:posList>35.670538290004004 139.74358336573655 45.918 35.67055729368329 139.74359912960395 45.918 35.67054774722747 139.74358580742495 45.918 35.670538290004004 139.74358336573655 45.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f6242948-8a8e-4a1c-be66-0eb55ac77700">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f6242948-8a8e-4a1c-be66-0eb55ac77700_0">
											<gml:posList>35.67054030932264 139.743571599186 45.918 35.670524776539146 139.74358084021915 45.918 35.670538290004004 139.74358336573655 45.918 35.67054030932264 139.743571599186 45.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81dcfdf7-f6ef-4444-a69f-8569eb07f72c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81dcfdf7-f6ef-4444-a69f-8569eb07f72c_0">
											<gml:posList>35.67054774722747 139.74358580742495 45.918 35.670538290004004 139.74358336573655 37.398 35.670538290004004 139.74358336573655 45.918 35.67054774722747 139.74358580742495 45.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-42057604-d08b-4434-aad5-d7ebef699d1a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-42057604-d08b-4434-aad5-d7ebef699d1a_0">
											<gml:posList>35.67054774722747 139.74358580742495 45.918 35.67054774722747 139.74358580742495 37.398 35.670538290004004 139.74358336573655 37.398 35.67054774722747 139.74358580742495 45.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cfd31eea-c684-4e09-8736-5f77d7612f81">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cfd31eea-c684-4e09-8736-5f77d7612f81_0">
											<gml:posList>35.67054030932264 139.743571599186 45.918 35.67054976654633 139.74357404087309 37.398 35.67054976654633 139.74357404087309 45.918 35.67054030932264 139.743571599186 45.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f1135a01-1860-48bd-b541-6e655a282c6b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f1135a01-1860-48bd-b541-6e655a282c6b_0">
											<gml:posList>35.67054030932264 139.743571599186 45.918 35.67054030932264 139.743571599186 37.398 35.67054976654633 139.74357404087309 37.398 35.67054030932264 139.743571599186 45.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-30499ddf-c734-48cc-bde6-9cc6862f341c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-30499ddf-c734-48cc-bde6-9cc6862f341c_0">
											<gml:posList>35.67052871758037 139.74355939497755 45.918 35.67056265225915 139.743568779462 37.398 35.67052871758037 139.74355939497755 37.398 35.67052871758037 139.74355939497755 45.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5416c53b-ae98-4f52-9880-bdfb108b583b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5416c53b-ae98-4f52-9880-bdfb108b583b_0">
											<gml:posList>35.67052871758037 139.74355939497755 45.918 35.67056265225915 139.743568779462 45.918 35.67056265225915 139.743568779462 37.398 35.67052871758037 139.74355939497755 45.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d1ecb4e-5912-4dd3-8a42-eedf8f63f335">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d1ecb4e-5912-4dd3-8a42-eedf8f63f335_0">
											<gml:posList>35.67054774722747 139.74358580742495 45.918 35.67054976654633 139.74357404087309 37.398 35.67054774722747 139.74358580742495 37.398 35.67054774722747 139.74358580742495 45.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7796949-3baa-4f56-b4ce-05788e2251d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c7796949-3baa-4f56-b4ce-05788e2251d4_0">
											<gml:posList>35.67054774722747 139.74358580742495 45.918 35.67054976654633 139.74357404087309 45.918 35.67054976654633 139.74357404087309 37.398 35.67054774722747 139.74358580742495 45.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e49314e4-98f5-47e8-8234-e944c3d7401b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e49314e4-98f5-47e8-8234-e944c3d7401b_0">
											<gml:posList>35.67055765268461 139.74359705250072 37.398 35.67056265225915 139.743568779462 37.398 35.67055765268461 139.74359705250072 38.692 35.67055765268461 139.74359705250072 37.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4ce53eb5-1fe9-48e4-97f8-dfc8515e21e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4ce53eb5-1fe9-48e4-97f8-dfc8515e21e2_0">
											<gml:posList>35.67055729368329 139.74359912960395 38.692 35.67055765268461 139.74359705250072 38.692 35.67055729368329 139.74359912960395 45.918 35.67055729368329 139.74359912960395 38.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db77dc29-9b6b-4a23-b5a2-733574ae3642">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-db77dc29-9b6b-4a23-b5a2-733574ae3642_0">
											<gml:posList>35.67055729368329 139.74359912960395 45.918 35.67055765268461 139.74359705250072 38.692 35.67056265225915 139.743568779462 45.918 35.67055729368329 139.74359912960395 45.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c542e8e-5cb3-492a-964b-4392a57f4036">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c542e8e-5cb3-492a-964b-4392a57f4036_0">
											<gml:posList>35.67055765268461 139.74359705250072 38.692 35.67056265225915 139.743568779462 37.398 35.67056265225915 139.743568779462 45.918 35.67055765268461 139.74359705250072 38.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a8c6ae9-ac01-4f37-a83c-2276eb720742">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67053036784938 139.74356040938756 38.692 35.67052526868945 139.74358809707402 38.692 35.67052862783844 139.74355992529948 38.692 35.67053036784938 139.74356040938756 38.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-797cad08-d570-4da0-80c4-9f34ba0f3316">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67052862783844 139.74355992529948 38.692 35.67052526868945 139.74358809707402 38.692 35.670523079622555 139.74358980065136 38.692 35.67052862783844 139.74355992529948 38.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a027909e-a0f4-4255-a7b8-fd24958e26ef">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670523079622555 139.74358980065136 38.692 35.67052526868945 139.74358809707402 38.692 35.67055729368329 139.74359912960395 38.692 35.670523079622555 139.74358980065136 38.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b42e1337-05ae-4f5a-b5b8-a71a272b29b9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67052526868945 139.74358809707402 38.692 35.67055765268461 139.74359705250072 38.692 35.67055729368329 139.74359912960395 38.692 35.67052526868945 139.74358809707402 38.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f8262c3b-ce4d-4812-b9d9-26e5077a87d4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67053036784938 139.74356040938756 37.398 35.67052862783844 139.74355992529948 37.398 35.67052871758037 139.74355939497755 37.398 35.67053036784938 139.74356040938756 37.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f5e49427-36e0-49ea-9218-d6d7be303a10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67053036784938 139.74356040938756 37.398 35.67052871758037 139.74355939497755 37.398 35.67056265225915 139.743568779462 37.398 35.67053036784938 139.74356040938756 37.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4f14a2a-c7fa-4360-b2d7-13865483e368">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67056265225915 139.743568779462 37.398 35.67055765268461 139.74359705250072 37.398 35.67054774722747 139.74358580742495 37.398 35.67056265225915 139.743568779462 37.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-067f0ddc-52b8-4b38-81d4-8b82590f89a3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67054030932264 139.743571599186 37.398 35.67052526868945 139.74358809707402 37.398 35.67053036784938 139.74356040938756 37.398 35.67054030932264 139.743571599186 37.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d5dd1f3-5698-4413-8c5b-3e0f8bb10c3b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67055765268461 139.74359705250072 37.398 35.67052526868945 139.74358809707402 37.398 35.670538290004004 139.74358336573655 37.398 35.67055765268461 139.74359705250072 37.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-444a5f0b-2802-40fa-af98-7959550013df">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67054976654633 139.74357404087309 37.398 35.67053036784938 139.74356040938756 37.398 35.67056265225915 139.743568779462 37.398 35.67054976654633 139.74357404087309 37.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1004dee8-81cd-450e-a8c0-25beec7bad31">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67054774722747 139.74358580742495 37.398 35.67055765268461 139.74359705250072 37.398 35.670538290004004 139.74358336573655 37.398 35.67054774722747 139.74358580742495 37.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c5647f9-ff35-468a-b0e6-d77250f68207">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67056265225915 139.743568779462 37.398 35.67054774722747 139.74358580742495 37.398 35.67054976654633 139.74357404087309 37.398 35.67056265225915 139.743568779462 37.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b78e9c6d-6ccc-472e-b559-89f3e4f293a8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67054030932264 139.743571599186 37.398 35.67053036784938 139.74356040938756 37.398 35.67054976654633 139.74357404087309 37.398 35.67054030932264 139.743571599186 37.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a9a6831-bc14-4125-a36b-4d98bd964910">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670538290004004 139.74358336573655 37.398 35.67052526868945 139.74358809707402 37.398 35.67054030932264 139.743571599186 37.398 35.670538290004004 139.74358336573655 37.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_55a69497-7fd6-429a-8249-0c014dbe4e14_BuildingInstallation_1051">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b1a8e47-db86-47e6-8565-d2c0a4a4f152">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5b1a8e47-db86-47e6-8565-d2c0a4a4f152_0">
											<gml:posList>35.670514028166956 139.74345462643035 52.579 35.67051658508779 139.7434506358575 38.692 35.670514028166956 139.74345462643035 38.692 35.670514028166956 139.74345462643035 52.579</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a2d1f77-ac80-43ec-8753-c67ef9b6601d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0a2d1f77-ac80-43ec-8753-c67ef9b6601d_0">
											<gml:posList>35.670514028166956 139.74345462643035 52.579 35.67051658508779 139.7434506358575 52.579 35.67051658508779 139.7434506358575 38.692 35.670514028166956 139.74345462643035 52.579</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-030195b5-9118-4509-bcd1-c563cd1e5518">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-030195b5-9118-4509-bcd1-c563cd1e5518_0">
											<gml:posList>35.67051663921136 139.74345069102822 37.398 35.67051563373928 139.74345613797064 38.692 35.67051663921136 139.74345069102822 38.692 35.67051663921136 139.74345069102822 37.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a23058d4-84c2-428a-a3ca-dbf75aeef8f1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a23058d4-84c2-428a-a3ca-dbf75aeef8f1_0">
											<gml:posList>35.67051663921136 139.74345069102822 37.398 35.67051563373928 139.74345613797064 37.398 35.67051563373928 139.74345613797064 38.692 35.67051663921136 139.74345069102822 37.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c4b9776-2511-42de-a47e-36ed36bb1045">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2c4b9776-2511-42de-a47e-36ed36bb1045_0">
											<gml:posList>35.67051563373928 139.74345613797064 37.398 35.67059903322874 139.7435345946485 37.398 35.67051563373928 139.74345613797064 38.692 35.67051563373928 139.74345613797064 37.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61a152c8-0dde-418f-9c25-facdcd16ec49">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-61a152c8-0dde-418f-9c25-facdcd16ec49_0">
											<gml:posList>35.670514028166956 139.74345462643035 38.692 35.67051563373928 139.74345613797064 38.692 35.670514028166956 139.74345462643035 52.579 35.670514028166956 139.74345462643035 38.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6a01e16-10c6-4e43-8d99-25f5d8697189">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d6a01e16-10c6-4e43-8d99-25f5d8697189_0">
											<gml:posList>35.670514028166956 139.74345462643035 52.579 35.67051563373928 139.74345613797064 38.692 35.67059903322874 139.7435345946485 52.579 35.670514028166956 139.74345462643035 52.579</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e97e0135-4239-4425-b960-af7246c6ac7f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e97e0135-4239-4425-b960-af7246c6ac7f_0">
											<gml:posList>35.67051563373928 139.74345613797064 38.692 35.67059903322874 139.7435345946485 37.398 35.67059903322874 139.7435345946485 52.579 35.67051563373928 139.74345613797064 38.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d9fcf74-4643-4b1d-ad3d-53892cc9f858">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d9fcf74-4643-4b1d-ad3d-53892cc9f858_0">
											<gml:posList>35.67051658508779 139.7434506358575 52.579 35.67059903322874 139.7435345946485 52.579 35.67060154508358 139.74353060412443 52.579 35.67051658508779 139.7434506358575 52.579</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aeeb6602-1bc0-40db-ba70-c8db2c0417f2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aeeb6602-1bc0-40db-ba70-c8db2c0417f2_0">
											<gml:posList>35.67051658508779 139.7434506358575 52.579 35.670514028166956 139.74345462643035 52.579 35.67059903322874 139.7435345946485 52.579 35.67051658508779 139.7434506358575 52.579</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ffe41ebd-68b3-4105-92e1-4b7ba2c5d5ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ffe41ebd-68b3-4105-92e1-4b7ba2c5d5ca_0">
											<gml:posList>35.67060041068903 139.743532394894 37.398 35.67060041068903 139.743532394894 38.692 35.67059903322874 139.7435345946485 37.398 35.67060041068903 139.743532394894 37.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-92331ccc-0099-45e4-8457-8fe74d6570da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-92331ccc-0099-45e4-8457-8fe74d6570da_0">
											<gml:posList>35.67059903322874 139.7435345946485 37.398 35.67060041068903 139.743532394894 38.692 35.67059903322874 139.7435345946485 52.579 35.67059903322874 139.7435345946485 37.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ae55e70-4a8a-45c5-86fe-4028d0e12cdd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3ae55e70-4a8a-45c5-86fe-4028d0e12cdd_0">
											<gml:posList>35.67059903322874 139.7435345946485 52.579 35.67060041068903 139.743532394894 38.692 35.67060154508358 139.74353060412443 52.579 35.67059903322874 139.7435345946485 52.579</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dbcc7279-8d59-4850-b594-b0df8b6fd425">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dbcc7279-8d59-4850-b594-b0df8b6fd425_0">
											<gml:posList>35.67060041068903 139.743532394894 38.692 35.67060154508358 139.74353060412443 38.692 35.67060154508358 139.74353060412443 52.579 35.67060041068903 139.743532394894 38.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7f01bea-dd0f-4080-a426-7131f24e26ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d7f01bea-dd0f-4080-a426-7131f24e26ca_0">
											<gml:posList>35.67060041068903 139.743532394894 37.398 35.670600859562796 139.7435299642074 38.692 35.67060041068903 139.743532394894 38.692 35.67060041068903 139.743532394894 37.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c8a7280a-75c4-4eb2-b45f-6c7614923b0b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c8a7280a-75c4-4eb2-b45f-6c7614923b0b_0">
											<gml:posList>35.67060041068903 139.743532394894 37.398 35.670600859562796 139.7435299642074 37.398 35.670600859562796 139.7435299642074 38.692 35.67060041068903 139.743532394894 37.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-881e6086-dd9d-42ab-9845-93055fef7e22">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-881e6086-dd9d-42ab-9845-93055fef7e22_0">
											<gml:posList>35.67051663921136 139.74345069102822 37.398 35.67051658508779 139.7434506358575 38.692 35.670600859562796 139.7435299642074 38.692 35.67051663921136 139.74345069102822 37.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a9bf6e0b-1951-4f40-98af-45747b4b5596">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a9bf6e0b-1951-4f40-98af-45747b4b5596_0">
											<gml:posList>35.670600859562796 139.7435299642074 37.398 35.67051663921136 139.74345069102822 37.398 35.670600859562796 139.7435299642074 38.692 35.670600859562796 139.7435299642074 37.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00f37a47-85e2-45ff-9815-8cc441585262">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-00f37a47-85e2-45ff-9815-8cc441585262_0">
											<gml:posList>35.67051658508779 139.7434506358575 38.692 35.67051658508779 139.7434506358575 52.579 35.670600859562796 139.7435299642074 38.692 35.67051658508779 139.7434506358575 38.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-643c9123-0adc-499b-8176-65731555228b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-643c9123-0adc-499b-8176-65731555228b_0">
											<gml:posList>35.670600859562796 139.7435299642074 38.692 35.67051658508779 139.7434506358575 52.579 35.67060154508358 139.74353060412443 52.579 35.670600859562796 139.7435299642074 38.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c55426e8-e691-480b-8809-0e57431360ab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c55426e8-e691-480b-8809-0e57431360ab_0">
											<gml:posList>35.670600859562796 139.7435299642074 38.692 35.67060154508358 139.74353060412443 52.579 35.67060154508358 139.74353060412443 38.692 35.670600859562796 139.7435299642074 38.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e5db2469-0539-4179-abc8-ef4f79c17bb2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67060041068903 139.743532394894 38.692 35.670600859562796 139.7435299642074 38.692 35.67060154508358 139.74353060412443 38.692 35.67060041068903 139.743532394894 38.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a576068e-37a4-456e-abbc-004a6ca573ba">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67051663921136 139.74345069102822 38.692 35.67051563373928 139.74345613797064 38.692 35.670514028166956 139.74345462643035 38.692 35.67051663921136 139.74345069102822 38.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8bae7c9e-bab3-45ec-8c66-76ae87d74a73">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67051663921136 139.74345069102822 37.398 35.670600859562796 139.7435299642074 37.398 35.67051563373928 139.74345613797064 37.398 35.67051663921136 139.74345069102822 37.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2e74419b-8b0e-4ca3-a216-34c44c23244e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67051563373928 139.74345613797064 37.398 35.670600859562796 139.7435299642074 37.398 35.67059903322874 139.7435345946485 37.398 35.67051563373928 139.74345613797064 37.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ebc371c7-14bc-4bd2-89a7-e27506cab2e0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670600859562796 139.7435299642074 37.398 35.67060041068903 139.743532394894 37.398 35.67059903322874 139.7435345946485 37.398 35.670600859562796 139.7435299642074 37.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_55a69497-7fd6-429a-8249-0c014dbe4e14_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a3281a55-e92e-4e18-8fb4-719643cb56a1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67052715733131 139.74352196088165 37.398 35.6705122821338 139.7435185531981 37.398 35.670517188701 139.74348645826237 37.398 35.670532054893904 139.7434898769965 37.398 35.67052715733131 139.74352196088165 37.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a7282d07-b628-4de4-b5a7-94e6167f0bea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a7282d07-b628-4de4-b5a7-94e6167f0bea_0">
											<gml:posList>35.670517188701 139.74348645826237 41.876 35.670532054893904 139.7434898769965 41.876 35.670532054893904 139.7434898769965 37.398 35.670517188701 139.74348645826237 37.398 35.670517188701 139.74348645826237 41.876</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4168784e-720d-403f-954e-fe0fe1141b6e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4168784e-720d-403f-954e-fe0fe1141b6e_0">
											<gml:posList>35.6705122821338 139.7435185531981 37.398 35.6705122821338 139.7435185531981 41.876 35.670517188701 139.74348645826237 41.876 35.670517188701 139.74348645826237 37.398 35.6705122821338 139.7435185531981 37.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c4df91d2-e756-4b7f-abe3-9e9cd77c939a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c4df91d2-e756-4b7f-abe3-9e9cd77c939a_0">
											<gml:posList>35.67052715733131 139.74352196088165 41.876 35.670532054893904 139.7434898769965 41.876 35.670517188701 139.74348645826237 41.876 35.6705122821338 139.7435185531981 41.876 35.67052715733131 139.74352196088165 41.876</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e1cceac5-52ef-45c1-a673-50a6ca7fb415">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e1cceac5-52ef-45c1-a673-50a6ca7fb415_0">
											<gml:posList>35.670532054893904 139.7434898769965 37.398 35.670532054893904 139.7434898769965 41.876 35.67052715733131 139.74352196088165 41.876 35.67052715733131 139.74352196088165 37.398 35.670532054893904 139.7434898769965 37.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e77502c5-e110-4554-9ec9-bacceac85383">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e77502c5-e110-4554-9ec9-bacceac85383_0">
											<gml:posList>35.67052715733131 139.74352196088165 41.876 35.6705122821338 139.7435185531981 41.876 35.6705122821338 139.7435185531981 37.398 35.67052715733131 139.74352196088165 37.398 35.67052715733131 139.74352196088165 41.876</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_55a69497-7fd6-429a-8249-0c014dbe4e14_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f1f25ff-968e-432c-accf-8f87c92e0a9b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67049257209246 139.74357091252944 7.57 35.67049582187559 139.74355322380376 7.57 35.670528115711534 139.7435621461752 7.57 35.67052485691341 139.74357983491774 7.57 35.67049257209246 139.74357091252944 7.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-66d4432c-b34c-4c91-a4b1-e129ecd66632">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-66d4432c-b34c-4c91-a4b1-e129ecd66632_0">
											<gml:posList>35.67049582187559 139.74355322380376 38.692 35.67049582187559 139.74355322380376 7.57 35.67049257209246 139.74357091252944 7.57 35.67049257209246 139.74357091252944 38.692 35.67049582187559 139.74355322380376 38.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a3bdcf6-b2f5-42b7-b83b-cb9c931ad5bd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a3bdcf6-b2f5-42b7-b83b-cb9c931ad5bd_0">
											<gml:posList>35.67049257209246 139.74357091252944 38.692 35.67049257209246 139.74357091252944 7.57 35.67052485691341 139.74357983491774 7.57 35.67052485691341 139.74357983491774 38.692 35.67049257209246 139.74357091252944 38.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4239375c-cd0e-4597-afe7-ae7de5294152">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4239375c-cd0e-4597-afe7-ae7de5294152_0">
											<gml:posList>35.67052485691341 139.74357983491774 38.692 35.670528115711534 139.7435621461752 38.692 35.67049582187559 139.74355322380376 38.692 35.67049257209246 139.74357091252944 38.692 35.67052485691341 139.74357983491774 38.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11ae53e6-193a-4a95-a751-3f7954e08291">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-11ae53e6-193a-4a95-a751-3f7954e08291_0">
											<gml:posList>35.670528115711534 139.7435621461752 38.692 35.670528115711534 139.7435621461752 7.57 35.67049582187559 139.74355322380376 7.57 35.67049582187559 139.74355322380376 38.692 35.670528115711534 139.7435621461752 38.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c1956d4-88e8-4eb1-a6c8-ffd0b63e2f27">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3c1956d4-88e8-4eb1-a6c8-ffd0b63e2f27_0">
											<gml:posList>35.67052485691341 139.74357983491774 38.692 35.67052485691341 139.74357983491774 7.57 35.670528115711534 139.7435621461752 7.57 35.670528115711534 139.7435621461752 38.692 35.67052485691341 139.74357983491774 38.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-30904da7-e0c9-4b0f-9858-ffd9d486a5fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-30904da7-e0c9-4b0f-9858-ffd9d486a5fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-30904da7-e0c9-4b0f-9858-ffd9d486a5fe">
											<gml:posList>35.670515365580044 139.74344708032297 7.314 35.67061306753863 139.7434740894359 7.314 35.670588433660186 139.74360792073648 7.314 35.67052301655119 139.7435898338608 7.314 35.670528115711534 139.7435621461752 7.314 35.67049582187559 139.74355322380376 7.314 35.670515365580044 139.74344708032297 7.314</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ef760337-5d55-4252-8cb3-e0772cd70f9e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef760337-5d55-4252-8cb3-e0772cd70f9e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef760337-5d55-4252-8cb3-e0772cd70f9e">
											<gml:posList>35.67049582187559 139.74355322380376 38.692 35.67049807401333 139.74355148701656 38.692 35.670516791809746 139.74344984029366 38.692 35.670515365580044 139.74344708032297 38.692 35.67049582187559 139.74355322380376 38.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f9bf8142-beb7-40f4-89b6-9f8814c94fe6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9bf8142-beb7-40f4-89b6-9f8814c94fe6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9bf8142-beb7-40f4-89b6-9f8814c94fe6">
											<gml:posList>35.670528115711534 139.7435621461752 38.692 35.67053036784938 139.74356040938756 38.692 35.67049807401333 139.74355148701656 38.692 35.67049582187559 139.74355322380376 38.692 35.670528115711534 139.7435621461752 38.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d38d2be8-9db7-4361-9d45-7484441ff4ea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d38d2be8-9db7-4361-9d45-7484441ff4ea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d38d2be8-9db7-4361-9d45-7484441ff4ea">
											<gml:posList>35.670528115711534 139.7435621461752 38.692 35.67052301655119 139.7435898338608 38.692 35.67052526868945 139.74358809707402 38.692 35.67053036784938 139.74356040938756 38.692 35.670528115711534 139.7435621461752 38.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bf54b899-05a2-4151-a4f3-13a3645dbe2f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf54b899-05a2-4151-a4f3-13a3645dbe2f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf54b899-05a2-4151-a4f3-13a3645dbe2f">
											<gml:posList>35.670516791809746 139.74344984029366 37.398 35.67049807401333 139.74355148701656 37.398 35.67053036784938 139.74356040938756 37.398 35.67052526868945 139.74358809707402 37.398 35.67058701645607 139.7436051717967 37.398 35.670610824424024 139.74347583726396 37.398 35.670516791809746 139.74344984029366 37.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-267e0df0-1488-4286-9c5d-f91355a12cbf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-267e0df0-1488-4286-9c5d-f91355a12cbf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-267e0df0-1488-4286-9c5d-f91355a12cbf">
											<gml:posList>35.670515365580044 139.74344708032297 38.692 35.670516791809746 139.74344984029366 38.692 35.670610824424024 139.74347583726396 38.692 35.67061306753863 139.7434740894359 38.692 35.670515365580044 139.74344708032297 38.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-183d1803-e98c-4117-acf6-57789258f3f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-183d1803-e98c-4117-acf6-57789258f3f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-183d1803-e98c-4117-acf6-57789258f3f3">
											<gml:posList>35.67061306753863 139.7434740894359 38.692 35.670610824424024 139.74347583726396 38.692 35.67058701645607 139.7436051717967 38.692 35.670588433660186 139.74360792073648 38.692 35.67061306753863 139.7434740894359 38.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d536ccfc-8bd5-4c7c-969f-a63523cb83d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d536ccfc-8bd5-4c7c-969f-a63523cb83d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d536ccfc-8bd5-4c7c-969f-a63523cb83d5">
											<gml:posList>35.670588433660186 139.74360792073648 38.692 35.67058701645607 139.7436051717967 38.692 35.67052526868945 139.74358809707402 38.692 35.67052301655119 139.7435898338608 38.692 35.670588433660186 139.74360792073648 38.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-865f0a20-4316-48e6-b6fd-943c49b81a0e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-865f0a20-4316-48e6-b6fd-943c49b81a0e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-865f0a20-4316-48e6-b6fd-943c49b81a0e">
											<gml:posList>35.67052301655119 139.7435898338608 7.314 35.670588433660186 139.74360792073648 7.314 35.670588433660186 139.74360792073648 38.692 35.67052301655119 139.7435898338608 38.692 35.67052301655119 139.7435898338608 7.314</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c760c4b5-b964-4f18-beaa-ba3a905c1e76">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c760c4b5-b964-4f18-beaa-ba3a905c1e76">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c760c4b5-b964-4f18-beaa-ba3a905c1e76">
											<gml:posList>35.67061306753863 139.7434740894359 7.314 35.670515365580044 139.74344708032297 7.314 35.670515365580044 139.74344708032297 38.692 35.67061306753863 139.7434740894359 38.692 35.67061306753863 139.7434740894359 7.314</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9653c727-a55e-4b33-94b9-ce0730d22729">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9653c727-a55e-4b33-94b9-ce0730d22729">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9653c727-a55e-4b33-94b9-ce0730d22729">
											<gml:posList>35.670516791809746 139.74344984029366 38.692 35.670516791809746 139.74344984029366 37.398 35.670610824424024 139.74347583726396 37.398 35.670610824424024 139.74347583726396 38.692 35.670516791809746 139.74344984029366 38.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6776d368-623e-4424-a627-b2195eb3189d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6776d368-623e-4424-a627-b2195eb3189d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6776d368-623e-4424-a627-b2195eb3189d">
											<gml:posList>35.670515365580044 139.74344708032297 7.314 35.67049582187559 139.74355322380376 7.314 35.67049582187559 139.74355322380376 38.692 35.670515365580044 139.74344708032297 38.692 35.670515365580044 139.74344708032297 7.314</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dc3715c0-2688-4e83-95ab-2d95c69f270b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc3715c0-2688-4e83-95ab-2d95c69f270b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc3715c0-2688-4e83-95ab-2d95c69f270b">
											<gml:posList>35.67049807401333 139.74355148701656 38.692 35.67049807401333 139.74355148701656 37.398 35.670516791809746 139.74344984029366 37.398 35.670516791809746 139.74344984029366 38.692 35.67049807401333 139.74355148701656 38.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ebf4e7dd-91ac-498a-baf5-f7d9c43fe5b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ebf4e7dd-91ac-498a-baf5-f7d9c43fe5b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ebf4e7dd-91ac-498a-baf5-f7d9c43fe5b1">
											<gml:posList>35.670610824424024 139.74347583726396 38.692 35.670610824424024 139.74347583726396 37.398 35.67058701645607 139.7436051717967 37.398 35.67058701645607 139.7436051717967 38.692 35.670610824424024 139.74347583726396 38.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1d8194ec-23c3-43cc-a6d2-eb209deedcd2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d8194ec-23c3-43cc-a6d2-eb209deedcd2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d8194ec-23c3-43cc-a6d2-eb209deedcd2">
											<gml:posList>35.670588433660186 139.74360792073648 7.314 35.67061306753863 139.7434740894359 7.314 35.67061306753863 139.7434740894359 38.692 35.670588433660186 139.74360792073648 38.692 35.670588433660186 139.74360792073648 7.314</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-10c097f5-dfd0-4b48-b461-1a7ed55fd644">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-10c097f5-dfd0-4b48-b461-1a7ed55fd644">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-10c097f5-dfd0-4b48-b461-1a7ed55fd644">
											<gml:posList>35.67053036784938 139.74356040938756 38.692 35.67053036784938 139.74356040938756 37.398 35.67049807401333 139.74355148701656 37.398 35.67049807401333 139.74355148701656 38.692 35.67053036784938 139.74356040938756 38.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-17641392-08e4-4a80-ab83-c037625106e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17641392-08e4-4a80-ab83-c037625106e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17641392-08e4-4a80-ab83-c037625106e2">
											<gml:posList>35.67049582187559 139.74355322380376 7.314 35.670528115711534 139.7435621461752 7.314 35.670528115711534 139.7435621461752 38.692 35.67049582187559 139.74355322380376 38.692 35.67049582187559 139.74355322380376 7.314</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fbe2218e-8ecc-4041-b130-ecf254bbe198">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fbe2218e-8ecc-4041-b130-ecf254bbe198">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fbe2218e-8ecc-4041-b130-ecf254bbe198">
											<gml:posList>35.67052526868945 139.74358809707402 38.692 35.67052526868945 139.74358809707402 37.398 35.67053036784938 139.74356040938756 37.398 35.67053036784938 139.74356040938756 38.692 35.67052526868945 139.74358809707402 38.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-102f1fe9-24be-4cc3-a6b7-3cbb88e844cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-102f1fe9-24be-4cc3-a6b7-3cbb88e844cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-102f1fe9-24be-4cc3-a6b7-3cbb88e844cb">
											<gml:posList>35.67052301655119 139.7435898338608 38.692 35.670528115711534 139.7435621461752 38.692 35.670528115711534 139.7435621461752 7.314 35.67052301655119 139.7435898338608 7.314 35.67052301655119 139.7435898338608 38.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8309a86a-4efb-4cab-b5da-240d454b6a8a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8309a86a-4efb-4cab-b5da-240d454b6a8a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8309a86a-4efb-4cab-b5da-240d454b6a8a">
											<gml:posList>35.67058701645607 139.7436051717967 38.692 35.67058701645607 139.7436051717967 37.398 35.67052526868945 139.74358809707402 37.398 35.67052526868945 139.74358809707402 38.692 35.67058701645607 139.7436051717967 38.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-9091</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">128.25455</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.43</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>