<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_55d7e2c6-3858-4731-899b-094180a7f70e">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="地区計画">
				<gen:value>虎ノ門二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3003</bldg:class>
			<bldg:measuredHeight uom="m">3.9</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.669607637943336 139.74616921843378 0 35.669572545519955 139.7461291590631 0 35.669536704962304 139.74617625461602 0 35.66957188750744 139.74621631389158 0 35.669607637943336 139.74616921843378 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669607637943336 139.74616921843378 7.61 35.66957188750744 139.74621631389158 7.61 35.669536704962304 139.74617625461602 7.61 35.669572545519955 139.7461291590631 7.61 35.669607637943336 139.74616921843378 7.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669607637943336 139.74616921843378 7.61 35.669572545519955 139.7461291590631 7.61 35.669572545519955 139.7461291590631 11.51 35.669607637943336 139.74616921843378 11.51 35.669607637943336 139.74616921843378 7.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669572545519955 139.7461291590631 7.61 35.669536704962304 139.74617625461602 7.61 35.669536704962304 139.74617625461602 11.51 35.669572545519955 139.7461291590631 11.51 35.669572545519955 139.7461291590631 7.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669536704962304 139.74617625461602 7.61 35.66957188750744 139.74621631389158 7.61 35.66957188750744 139.74621631389158 11.51 35.669536704962304 139.74617625461602 11.51 35.669536704962304 139.74617625461602 7.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66957188750744 139.74621631389158 7.61 35.669607637943336 139.74616921843378 7.61 35.669607637943336 139.74616921843378 11.51 35.66957188750744 139.74621631389158 11.51 35.66957188750744 139.74621631389158 7.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669607637943336 139.74616921843378 11.51 35.669572545519955 139.7461291590631 11.51 35.669536704962304 139.74617625461602 11.51 35.66957188750744 139.74621631389158 11.51 35.669607637943336 139.74616921843378 11.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-9fc822b6-27bd-4b9b-a395-b54531513f8e"/>
							<gml:surfaceMember xlink:href="#poly-1411a48a-5a69-4708-8c23-75a9293a9554"/>
							<gml:surfaceMember xlink:href="#poly-014f1867-3128-4615-8c22-5fb3751bc5df"/>
							<gml:surfaceMember xlink:href="#poly-4abbe4ce-460e-45b0-a2af-28bf519970fe"/>
							<gml:surfaceMember xlink:href="#poly-e91c7fd3-5fc1-49e8-8094-7a85ebfe93ed"/>
							<gml:surfaceMember xlink:href="#poly-70294149-8410-47ea-af48-58cf49c9a83a"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-9fc822b6-27bd-4b9b-a395-b54531513f8e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9fc822b6-27bd-4b9b-a395-b54531513f8e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9fc822b6-27bd-4b9b-a395-b54531513f8e">
											<gml:posList>35.669607637943336 139.74616921843378 7.61 35.669571887507445 139.74621631389155 7.61 35.66953670496228 139.74617625461602 7.61 35.66957254551997 139.7461291590631 7.61 35.669607637943336 139.74616921843378 7.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1411a48a-5a69-4708-8c23-75a9293a9554">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1411a48a-5a69-4708-8c23-75a9293a9554">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1411a48a-5a69-4708-8c23-75a9293a9554">
											<gml:posList>35.669571887507445 139.74621631389155 12.2 35.669607637943336 139.74616921843378 12.2 35.66957254551997 139.7461291590631 12.2 35.66953670496228 139.74617625461602 12.2 35.669571887507445 139.74621631389155 12.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-014f1867-3128-4615-8c22-5fb3751bc5df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-014f1867-3128-4615-8c22-5fb3751bc5df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-014f1867-3128-4615-8c22-5fb3751bc5df">
											<gml:posList>35.669607637943336 139.74616921843378 7.61 35.66957254551997 139.7461291590631 7.61 35.66957254551997 139.7461291590631 12.2 35.669607637943336 139.74616921843378 12.2 35.669607637943336 139.74616921843378 7.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4abbe4ce-460e-45b0-a2af-28bf519970fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4abbe4ce-460e-45b0-a2af-28bf519970fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4abbe4ce-460e-45b0-a2af-28bf519970fe">
											<gml:posList>35.66957254551997 139.7461291590631 7.61 35.66953670496228 139.74617625461602 7.61 35.66953670496228 139.74617625461602 12.2 35.66957254551997 139.7461291590631 12.2 35.66957254551997 139.7461291590631 7.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e91c7fd3-5fc1-49e8-8094-7a85ebfe93ed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e91c7fd3-5fc1-49e8-8094-7a85ebfe93ed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e91c7fd3-5fc1-49e8-8094-7a85ebfe93ed">
											<gml:posList>35.669571887507445 139.74621631389155 7.61 35.669607637943336 139.74616921843378 7.61 35.669607637943336 139.74616921843378 12.2 35.669571887507445 139.74621631389155 12.2 35.669571887507445 139.74621631389155 7.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-70294149-8410-47ea-af48-58cf49c9a83a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70294149-8410-47ea-af48-58cf49c9a83a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70294149-8410-47ea-af48-58cf49c9a83a">
											<gml:posList>35.66953670496228 139.74617625461602 7.61 35.669571887507445 139.74621631389155 7.61 35.669571887507445 139.74621631389155 12.2 35.66953670496228 139.74617625461602 12.2 35.66953670496228 139.74617625461602 7.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6398</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>