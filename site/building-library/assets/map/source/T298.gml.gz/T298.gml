<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_562ba80f-54d9-43c3-b217-a4cf7922e4b4">
			<core:creationDate>2023-08-22</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018002</gen:value>
			</gen:stringAttribute>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">27.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66869445091772 139.74785238752753 0 35.668674226278036 139.74791769993396 0 35.668665315910026 139.74794651966545 0 35.66873835933394 139.7479804669795 0 35.668780525483264 139.74784437133607 0 35.668707490135574 139.74781042632884 0 35.66869445091772 139.74785238752753 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66869445091772 139.74785238752753 5.831 35.668707490135574 139.74781042632884 5.831 35.668780525483264 139.74784437133607 5.831 35.66873835933394 139.7479804669795 5.831 35.668665315910026 139.74794651966545 5.831 35.668674226278036 139.74791769993396 5.831 35.66869445091772 139.74785238752753 5.831</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66869445091772 139.74785238752753 5.831 35.668674226278036 139.74791769993396 5.831 35.668674226278036 139.74791769993396 26.378999999999998 35.66869445091772 139.74785238752753 26.378999999999998 35.66869445091772 139.74785238752753 5.831</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668674226278036 139.74791769993396 5.831 35.668665315910026 139.74794651966545 5.831 35.668665315910026 139.74794651966545 26.378999999999998 35.668674226278036 139.74791769993396 26.378999999999998 35.668674226278036 139.74791769993396 5.831</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668665315910026 139.74794651966545 5.831 35.66873835933394 139.7479804669795 5.831 35.66873835933394 139.7479804669795 26.378999999999998 35.668665315910026 139.74794651966545 26.378999999999998 35.668665315910026 139.74794651966545 5.831</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66873835933394 139.7479804669795 5.831 35.668780525483264 139.74784437133607 5.831 35.668780525483264 139.74784437133607 26.378999999999998 35.66873835933394 139.7479804669795 26.378999999999998 35.66873835933394 139.7479804669795 5.831</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668780525483264 139.74784437133607 5.831 35.668707490135574 139.74781042632884 5.831 35.668707490135574 139.74781042632884 26.378999999999998 35.668780525483264 139.74784437133607 26.378999999999998 35.668780525483264 139.74784437133607 5.831</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668707490135574 139.74781042632884 5.831 35.66869445091772 139.74785238752753 5.831 35.66869445091772 139.74785238752753 26.378999999999998 35.668707490135574 139.74781042632884 26.378999999999998 35.668707490135574 139.74781042632884 5.831</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66869445091772 139.74785238752753 26.378999999999998 35.668674226278036 139.74791769993396 26.378999999999998 35.668665315910026 139.74794651966545 26.378999999999998 35.66873835933394 139.7479804669795 26.378999999999998 35.668780525483264 139.74784437133607 26.378999999999998 35.668707490135574 139.74781042632884 26.378999999999998 35.66869445091772 139.74785238752753 26.378999999999998</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly_TMmnt0160_p1006_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0160_p1006_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0160_p1006_2"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0160_p1006_3"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0160_p1004_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0160_p1004_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0160_p1004_2"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0160_p1005_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0160_p1005_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0160_p1005_2"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0160_p1005_3"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0160_p1003_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0160_p1003_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0160_p1003_2"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0160_b_0"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="gnd_TMmnt0160_b_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0160_b_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0160_b_0">
											<gml:posList>35.668707518905 139.74781043347565 5.85760386 35.668780525919104 139.74784437173957 5.86120346 35.66873839603983 139.74798047496517 5.86022308 35.66866538903403 139.74794653669025 5.85662351 35.668707518905 139.74781043347565 5.85760386</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0160_p1004_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0160_p1004_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0160_p1004_0">
											<gml:posList>35.66869443287123 139.74785238334087 31.05311292 35.66867421609894 139.74791769488962 31.05264311 35.66869836221252 139.74792891983932 31.05383232 35.66870266263766 139.74791502780138 31.05393174 35.66868417143817 139.74790643190832 31.05302092 35.66868942571644 139.74788945811304 31.05314277 35.66870791696941 139.7478980542668 31.05405359 35.66871858002243 139.74786360842896 31.05430218 35.66869443287123 139.74785238334087 31.05311292</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0160_p1005_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0160_p1005_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0160_p1005_0">
											<gml:posList>35.668689418547636 139.74788945646478 32.9731426 35.668684164270985 139.74790643025494 32.97302075 35.66870265546489 139.7479150261454 32.97393157 35.66870790979501 139.74789805261602 32.97405342 35.668689418547636 139.74788945646478 32.9731426</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0160_p1003_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0160_p1003_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0160_p1003_0">
											<gml:posList>35.66871860093841 139.74786361320946 25.45930268 35.668698383110694 139.7479289246772 25.45883282 35.668674236975924 139.74791769971756 25.45764361 35.66866531592374 139.74794651968796 25.45743829 35.66873832270441 139.7479804578587 25.46103784 35.66876746057276 139.74788632620883 25.46171299 35.66871860093841 139.74786361320946 25.45930268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0160_p1006_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0160_p1006_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0160_p1006_0">
											<gml:posList>35.668707460106624 139.7478104201615 21.59341898 35.66869446819988 139.74785239140724 21.59311376 35.66876747505108 139.74788632952502 21.59671334 35.66878046694003 139.74784435834164 21.59701857 35.668707460106624 139.7478104201615 21.59341898</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0160_p1003_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0160_p1003_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0160_p1003_1">
											<gml:posList>35.66873832270441 139.7479804578587 25.46103784 35.66866531592374 139.74794651968796 25.45743829 35.66866538903403 139.74794653669025 5.85662351 35.66873839603983 139.74798047496517 5.86022308 35.66873832270441 139.7479804578587 25.46103784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0160_p1005_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0160_p1005_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0160_p1005_1">
											<gml:posList>35.668684164270985 139.74790643025494 32.97302075 35.66868417143817 139.74790643190832 31.05302092 35.66870266263766 139.74791502780138 31.05393174 35.66870265546489 139.7479150261454 32.97393157 35.668684164270985 139.74790643025494 32.97302075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0160_p1006_2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0160_p1006_2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0160_p1006_2">
											<gml:posList>35.668707518905 139.74781043347565 5.85760386 35.66866538903403 139.74794653669025 5.85662351 35.66866531592374 139.74794651968796 25.45743829 35.668674236975924 139.74791769971756 25.45764361 35.66867421609894 139.74791769488962 31.05264311 35.66869443287123 139.74785238334087 31.05311292 35.66869446819988 139.74785239140724 21.59311376 35.668707460106624 139.7478104201615 21.59341898 35.668707518905 139.74781043347565 5.85760386</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0160_p1006_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0160_p1006_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0160_p1006_1">
											<gml:posList>35.66878046694003 139.74784435834164 21.59701857 35.66876747505108 139.74788632952502 21.59671334 35.66876746057276 139.74788632620883 25.46171299 35.66873832270441 139.7479804578587 25.46103784 35.66873839603983 139.74798047496517 5.86022308 35.668780525919104 139.74784437173957 5.86120346 35.66878046694003 139.74784435834164 21.59701857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0160_p1004_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0160_p1004_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0160_p1004_1">
											<gml:posList>35.66871858002243 139.74786360842896 31.05430218 35.66870791696941 139.7478980542668 31.05405359 35.66870790979501 139.74789805261602 32.97405342 35.66870265546489 139.7479150261454 32.97393157 35.66870266263766 139.74791502780138 31.05393174 35.66869836221252 139.74792891983932 31.05383232 35.668698383110694 139.7479289246772 25.45883282 35.66871860093841 139.74786361320946 25.45930268 35.66871858002243 139.74786360842896 31.05430218</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0160_p1004_2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0160_p1004_2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0160_p1004_2">
											<gml:posList>35.66867421609894 139.74791769488962 31.05264311 35.668674236975924 139.74791769971756 25.45764361 35.668698383110694 139.7479289246772 25.45883282 35.66869836221252 139.74792891983932 31.05383232 35.66867421609894 139.74791769488962 31.05264311</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0160_p1005_3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0160_p1005_3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0160_p1005_3">
											<gml:posList>35.66870790979501 139.74789805261602 32.97405342 35.66870791696941 139.7478980542668 31.05405359 35.66868942571644 139.74788945811304 31.05314277 35.668689418547636 139.74788945646478 32.9731426 35.66870790979501 139.74789805261602 32.97405342</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0160_p1005_2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0160_p1005_2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0160_p1005_2">
											<gml:posList>35.668689418547636 139.74788945646478 32.9731426 35.66868942571644 139.74788945811304 31.05314277 35.66868417143817 139.74790643190832 31.05302092 35.668684164270985 139.74790643025494 32.97302075 35.668689418547636 139.74788945646478 32.9731426</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0160_p1006_3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0160_p1006_3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0160_p1006_3">
											<gml:posList>35.668707460106624 139.7478104201615 21.59341898 35.66878046694003 139.74784435834164 21.59701857 35.668780525919104 139.74784437173957 5.86120346 35.668707518905 139.74781043347565 5.85760386 35.668707460106624 139.7478104201615 21.59341898</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0160_p1003_2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0160_p1003_2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0160_p1003_2">
											<gml:posList>35.66869446819988 139.74785239140724 21.59311376 35.66869443287123 139.74785238334087 31.05311292 35.66871858002243 139.74786360842896 31.05430218 35.66871860093841 139.74786361320946 25.45930268 35.66876746057276 139.74788632620883 25.46171299 35.66876747505108 139.74788632952502 21.59671334 35.66869446819988 139.74785239140724 21.59311376</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">126.9093</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">9</uro:districtsAndZonesType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.16</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2413800000</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>