<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_562c1588-29d2-40cb-97e3-4c2c5d6f78ef">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">5.6</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67107125261906 139.74429805375723 0 35.67107603811168 139.74427259763942 0 35.671057736414625 139.74426742618337 0 35.67105927170643 139.74425923912997 0 35.671076572668156 139.74426412449074 0 35.67108937582669 139.74419598738052 0 35.67104877851257 139.74418452221698 0 35.67103155795586 139.7442761156027 0 35.671054863306175 139.74428268438825 0 35.67105295092309 139.74429288229567 0 35.67107125261906 139.74429805375723 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67107125261906 139.74429805375723 6.797 35.67105295092309 139.74429288229567 6.797 35.671054863306175 139.74428268438825 6.797 35.67103155795586 139.7442761156027 6.797 35.67104877851257 139.74418452221698 6.797 35.67108937582669 139.74419598738052 6.797 35.671076572668156 139.74426412449074 6.797 35.67105927170643 139.74425923912997 6.797 35.671057736414625 139.74426742618337 6.797 35.67107603811168 139.74427259763942 6.797 35.67107125261906 139.74429805375723 6.797</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67107125261906 139.74429805375723 6.797 35.67107603811168 139.74427259763942 6.797 35.67107603811168 139.74427259763942 12.36 35.67107125261906 139.74429805375723 12.36 35.67107125261906 139.74429805375723 6.797</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67107603811168 139.74427259763942 6.797 35.671057736414625 139.74426742618337 6.797 35.671057736414625 139.74426742618337 12.36 35.67107603811168 139.74427259763942 12.36 35.67107603811168 139.74427259763942 6.797</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671057736414625 139.74426742618337 6.797 35.67105927170643 139.74425923912997 6.797 35.67105927170643 139.74425923912997 12.36 35.671057736414625 139.74426742618337 12.36 35.671057736414625 139.74426742618337 6.797</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67105927170643 139.74425923912997 6.797 35.671076572668156 139.74426412449074 6.797 35.671076572668156 139.74426412449074 12.36 35.67105927170643 139.74425923912997 12.36 35.67105927170643 139.74425923912997 6.797</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671076572668156 139.74426412449074 6.797 35.67108937582669 139.74419598738052 6.797 35.67108937582669 139.74419598738052 12.36 35.671076572668156 139.74426412449074 12.36 35.671076572668156 139.74426412449074 6.797</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67108937582669 139.74419598738052 6.797 35.67104877851257 139.74418452221698 6.797 35.67104877851257 139.74418452221698 12.36 35.67108937582669 139.74419598738052 12.36 35.67108937582669 139.74419598738052 6.797</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67104877851257 139.74418452221698 6.797 35.67103155795586 139.7442761156027 6.797 35.67103155795586 139.7442761156027 12.36 35.67104877851257 139.74418452221698 12.36 35.67104877851257 139.74418452221698 6.797</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67103155795586 139.7442761156027 6.797 35.671054863306175 139.74428268438825 6.797 35.671054863306175 139.74428268438825 12.36 35.67103155795586 139.7442761156027 12.36 35.67103155795586 139.7442761156027 6.797</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671054863306175 139.74428268438825 6.797 35.67105295092309 139.74429288229567 6.797 35.67105295092309 139.74429288229567 12.36 35.671054863306175 139.74428268438825 12.36 35.671054863306175 139.74428268438825 6.797</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67105295092309 139.74429288229567 6.797 35.67107125261906 139.74429805375723 6.797 35.67107125261906 139.74429805375723 12.36 35.67105295092309 139.74429288229567 12.36 35.67105295092309 139.74429288229567 6.797</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67107125261906 139.74429805375723 12.36 35.67107603811168 139.74427259763942 12.36 35.671057736414625 139.74426742618337 12.36 35.67105927170643 139.74425923912997 12.36 35.671076572668156 139.74426412449074 12.36 35.67108937582669 139.74419598738052 12.36 35.67104877851257 139.74418452221698 12.36 35.67103155795586 139.7442761156027 12.36 35.671054863306175 139.74428268438825 12.36 35.67105295092309 139.74429288229567 12.36 35.67107125261906 139.74429805375723 12.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-0784358d-c29d-4864-b418-185d70347a4f"/>
							<gml:surfaceMember xlink:href="#poly-899f13e5-2256-42ea-808f-8de2a807b85f"/>
							<gml:surfaceMember xlink:href="#poly-b99d6361-688d-4cd2-aee4-d9f6ce9eb4e7"/>
							<gml:surfaceMember xlink:href="#poly-55f66490-e184-4ca2-8569-1156eae05609"/>
							<gml:surfaceMember xlink:href="#poly-9671328f-6d6a-4613-a4f9-ce66a53ca892"/>
							<gml:surfaceMember xlink:href="#poly-3fa8e1fe-2be7-49ec-afac-8b5eda6cf75b"/>
							<gml:surfaceMember xlink:href="#poly-8dff6e24-d9dd-43cb-9a29-c34d3a9f0012"/>
							<gml:surfaceMember xlink:href="#poly-0fd3a199-9f28-4712-98b9-a5e79ce26acf"/>
							<gml:surfaceMember xlink:href="#poly-a4ae2bd4-fe84-4876-8cff-09746ae3ca41"/>
							<gml:surfaceMember xlink:href="#poly-a1f56933-8ac7-4738-b7fc-742fc02cde49"/>
							<gml:surfaceMember xlink:href="#poly-1cacac8f-740b-4674-9ac6-397e5acb0861"/>
							<gml:surfaceMember xlink:href="#poly-a76089f5-95a8-4969-96e9-d7e97e774207"/>
							<gml:surfaceMember xlink:href="#poly-aa940c2b-6cfc-404c-ad43-01ea8d45129a"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-0784358d-c29d-4864-b418-185d70347a4f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0784358d-c29d-4864-b418-185d70347a4f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0784358d-c29d-4864-b418-185d70347a4f">
											<gml:posList>35.671048778512564 139.74418452221695 6.797 35.671089375826675 139.7441959873805 6.797 35.67107657266816 139.74426412449074 6.797 35.67105927170643 139.74425923912995 6.797 35.67105773641463 139.74426742618337 6.797 35.67107603811168 139.74427259763942 6.797 35.67107125261905 139.74429805375726 6.797 35.67105295092308 139.74429288229567 6.797 35.67105486330617 139.74428268438825 6.797 35.67103155795585 139.7442761156027 6.797 35.671048778512564 139.74418452221695 6.797</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-899f13e5-2256-42ea-808f-8de2a807b85f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-899f13e5-2256-42ea-808f-8de2a807b85f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-899f13e5-2256-42ea-808f-8de2a807b85f">
											<gml:posList>35.671048778512564 139.74418452221695 12.809 35.67103155795585 139.7442761156027 12.809 35.67105486330617 139.74428268438825 12.809 35.67105927170643 139.74425923912995 12.809 35.67107657266816 139.74426412449074 12.809 35.671089375826675 139.7441959873805 12.809 35.671048778512564 139.74418452221695 12.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b99d6361-688d-4cd2-aee4-d9f6ce9eb4e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b99d6361-688d-4cd2-aee4-d9f6ce9eb4e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b99d6361-688d-4cd2-aee4-d9f6ce9eb4e7">
											<gml:posList>35.67105295092308 139.74429288229567 11.1 35.67107125261905 139.74429805375726 11.1 35.67107603811168 139.74427259763942 11.1 35.67105773641463 139.74426742618337 11.1 35.67105486330617 139.74428268438825 11.1 35.67105295092308 139.74429288229567 11.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-55f66490-e184-4ca2-8569-1156eae05609">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-55f66490-e184-4ca2-8569-1156eae05609">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-55f66490-e184-4ca2-8569-1156eae05609">
											<gml:posList>35.671048778512564 139.74418452221695 6.797 35.67103155795585 139.7442761156027 6.797 35.67103155795585 139.7442761156027 12.809 35.671048778512564 139.74418452221695 12.809 35.671048778512564 139.74418452221695 6.797</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9671328f-6d6a-4613-a4f9-ce66a53ca892">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9671328f-6d6a-4613-a4f9-ce66a53ca892">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9671328f-6d6a-4613-a4f9-ce66a53ca892">
											<gml:posList>35.671089375826675 139.7441959873805 6.797 35.671048778512564 139.74418452221695 6.797 35.671048778512564 139.74418452221695 12.809 35.671089375826675 139.7441959873805 12.809 35.671089375826675 139.7441959873805 6.797</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3fa8e1fe-2be7-49ec-afac-8b5eda6cf75b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3fa8e1fe-2be7-49ec-afac-8b5eda6cf75b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3fa8e1fe-2be7-49ec-afac-8b5eda6cf75b">
											<gml:posList>35.67107657266816 139.74426412449074 6.797 35.671089375826675 139.7441959873805 6.797 35.671089375826675 139.7441959873805 12.809 35.67107657266816 139.74426412449074 12.809 35.67107657266816 139.74426412449074 6.797</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8dff6e24-d9dd-43cb-9a29-c34d3a9f0012">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8dff6e24-d9dd-43cb-9a29-c34d3a9f0012">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8dff6e24-d9dd-43cb-9a29-c34d3a9f0012">
											<gml:posList>35.67105927170643 139.74425923912995 6.797 35.67107657266816 139.74426412449074 6.797 35.67107657266816 139.74426412449074 12.809 35.67105927170643 139.74425923912995 12.809 35.67105927170643 139.74425923912995 6.797</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0fd3a199-9f28-4712-98b9-a5e79ce26acf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0fd3a199-9f28-4712-98b9-a5e79ce26acf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0fd3a199-9f28-4712-98b9-a5e79ce26acf">
											<gml:posList>35.67107603811168 139.74427259763942 6.797 35.67105773641463 139.74426742618337 6.797 35.67105773641463 139.74426742618337 11.1 35.67107603811168 139.74427259763942 11.1 35.67107603811168 139.74427259763942 6.797</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a4ae2bd4-fe84-4876-8cff-09746ae3ca41">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4ae2bd4-fe84-4876-8cff-09746ae3ca41">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4ae2bd4-fe84-4876-8cff-09746ae3ca41">
											<gml:posList>35.67105927170643 139.74425923912995 12.809 35.67105486330617 139.74428268438825 12.809 35.67105486330617 139.74428268438825 11.1 35.67105773641463 139.74426742618337 11.1 35.67105773641463 139.74426742618337 6.797 35.67105927170643 139.74425923912995 6.797 35.67105927170643 139.74425923912995 12.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a1f56933-8ac7-4738-b7fc-742fc02cde49">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a1f56933-8ac7-4738-b7fc-742fc02cde49">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a1f56933-8ac7-4738-b7fc-742fc02cde49">
											<gml:posList>35.67103155795585 139.7442761156027 12.809 35.67103155795585 139.7442761156027 6.797 35.67105486330617 139.74428268438825 6.797 35.67105486330617 139.74428268438825 11.1 35.67105486330617 139.74428268438825 12.809 35.67103155795585 139.7442761156027 12.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1cacac8f-740b-4674-9ac6-397e5acb0861">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1cacac8f-740b-4674-9ac6-397e5acb0861">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1cacac8f-740b-4674-9ac6-397e5acb0861">
											<gml:posList>35.67107125261905 139.74429805375726 6.797 35.67107603811168 139.74427259763942 6.797 35.67107603811168 139.74427259763942 11.1 35.67107125261905 139.74429805375726 11.1 35.67107125261905 139.74429805375726 6.797</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a76089f5-95a8-4969-96e9-d7e97e774207">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a76089f5-95a8-4969-96e9-d7e97e774207">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a76089f5-95a8-4969-96e9-d7e97e774207">
											<gml:posList>35.67105486330617 139.74428268438825 6.797 35.67105295092308 139.74429288229567 6.797 35.67105295092308 139.74429288229567 11.1 35.67105486330617 139.74428268438825 11.1 35.67105486330617 139.74428268438825 6.797</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aa940c2b-6cfc-404c-ad43-01ea8d45129a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa940c2b-6cfc-404c-ad43-01ea8d45129a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa940c2b-6cfc-404c-ad43-01ea8d45129a">
											<gml:posList>35.67105295092308 139.74429288229567 6.797 35.67107125261905 139.74429805375726 6.797 35.67107125261905 139.74429805375726 11.1 35.67105295092308 139.74429288229567 11.1 35.67105295092308 139.74429288229567 6.797</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10927</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.21</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>