<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_563f524d-9fc7-41cc-b3ff-545f9bcaded7">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">15.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66829538883419 139.73926618312666 0 35.668303383659435 139.73925418886662 0 35.66831824041447 139.73926844283528 0 35.66834040613457 139.73923504693178 0 35.66826896164623 139.73916377381803 0 35.668214672604115 139.73924535676824 0 35.66827565292965 139.73930614850508 0 35.66829949328919 139.73927028741338 0 35.66829538883419 139.73926618312666 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66829538883419 139.73926618312666 11.637 35.66829949328919 139.73927028741338 11.637 35.66827565292965 139.73930614850508 11.637 35.668214672604115 139.73924535676824 11.637 35.66826896164623 139.73916377381803 11.637 35.66834040613457 139.73923504693178 11.637 35.66831824041447 139.73926844283528 11.637 35.668303383659435 139.73925418886662 11.637 35.66829538883419 139.73926618312666 11.637</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66829538883419 139.73926618312666 11.637 35.668303383659435 139.73925418886662 11.637 35.668303383659435 139.73925418886662 27 35.66829538883419 139.73926618312666 27 35.66829538883419 139.73926618312666 11.637</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668303383659435 139.73925418886662 11.637 35.66831824041447 139.73926844283528 11.637 35.66831824041447 139.73926844283528 27 35.668303383659435 139.73925418886662 27 35.668303383659435 139.73925418886662 11.637</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66831824041447 139.73926844283528 11.637 35.66834040613457 139.73923504693178 11.637 35.66834040613457 139.73923504693178 27 35.66831824041447 139.73926844283528 27 35.66831824041447 139.73926844283528 11.637</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66834040613457 139.73923504693178 11.637 35.66826896164623 139.73916377381803 11.637 35.66826896164623 139.73916377381803 27 35.66834040613457 139.73923504693178 27 35.66834040613457 139.73923504693178 11.637</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66826896164623 139.73916377381803 11.637 35.668214672604115 139.73924535676824 11.637 35.668214672604115 139.73924535676824 27 35.66826896164623 139.73916377381803 27 35.66826896164623 139.73916377381803 11.637</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668214672604115 139.73924535676824 11.637 35.66827565292965 139.73930614850508 11.637 35.66827565292965 139.73930614850508 27 35.668214672604115 139.73924535676824 27 35.668214672604115 139.73924535676824 11.637</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66827565292965 139.73930614850508 11.637 35.66829949328919 139.73927028741338 11.637 35.66829949328919 139.73927028741338 27 35.66827565292965 139.73930614850508 27 35.66827565292965 139.73930614850508 11.637</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66829949328919 139.73927028741338 11.637 35.66829538883419 139.73926618312666 11.637 35.66829538883419 139.73926618312666 27 35.66829949328919 139.73927028741338 27 35.66829949328919 139.73927028741338 11.637</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66829538883419 139.73926618312666 27 35.668303383659435 139.73925418886662 27 35.66831824041447 139.73926844283528 27 35.66834040613457 139.73923504693178 27 35.66826896164623 139.73916377381803 27 35.668214672604115 139.73924535676824 27 35.66827565292965 139.73930614850508 27 35.66829949328919 139.73927028741338 27 35.66829538883419 139.73926618312666 27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-4f3c9b0b-5133-41cf-8195-da1f838b2d7b"/>
							<gml:surfaceMember xlink:href="#poly-1b33f259-7ae2-4f84-9957-b2dcdac1df2d"/>
							<gml:surfaceMember xlink:href="#poly-a5387d59-66a2-489d-8c9d-b70d1ed068a9"/>
							<gml:surfaceMember xlink:href="#poly-51215aaf-7b9f-403b-95fa-f9c435819045"/>
							<gml:surfaceMember xlink:href="#poly-33a14a8e-0f35-4b90-8c4b-aeb0cf5daea0"/>
							<gml:surfaceMember xlink:href="#poly-0dbfeabd-c842-4e7f-83ff-3e1e35e1e2a3"/>
							<gml:surfaceMember xlink:href="#poly-86ac08d4-81bb-4fcc-b2fa-b58be7fae31b"/>
							<gml:surfaceMember xlink:href="#poly-4c324cea-7325-47c2-b6bc-d8d421f4a2ed"/>
							<gml:surfaceMember xlink:href="#poly-1684f5be-ee99-42c1-93b3-06543f266042"/>
							<gml:surfaceMember xlink:href="#poly-27af0206-39d8-4fff-a395-8602f041f1e4"/>
							<gml:surfaceMember xlink:href="#poly-a2fe3b75-1c1b-499d-a0b6-80c7788eb7b5"/>
							<gml:surfaceMember xlink:href="#poly-b656b38a-3320-4399-82d0-c946e38b2c32"/>
							<gml:surfaceMember xlink:href="#poly-d53da70e-484a-421f-a20d-7cd828a03b6c"/>
							<gml:surfaceMember xlink:href="#poly-38bb1fe7-431b-4ea8-91b8-100f50cc4b1d"/>
							<gml:surfaceMember xlink:href="#poly-5b20fb6e-e9cb-496b-9f98-c2cd3ffe2044"/>
							<gml:surfaceMember xlink:href="#poly-07959157-3783-4d3f-a99c-316b730c8830"/>
							<gml:surfaceMember xlink:href="#poly-fe2722fd-ad7c-40a9-89e7-c9c5c52d12ac"/>
							<gml:surfaceMember xlink:href="#poly-0e5cdec7-40e9-4294-8e14-8fba40997985"/>
							<gml:surfaceMember xlink:href="#poly-609c1a1e-e9b5-4343-b5f7-623969b3bb2d"/>
							<gml:surfaceMember xlink:href="#poly-ffb4b774-8819-4171-8050-0a3d684e6ade"/>
							<gml:surfaceMember xlink:href="#poly-e72146fe-556c-41c8-b06e-3bb17bf1e481"/>
							<gml:surfaceMember xlink:href="#poly-412c3f9e-b2d4-4603-a2a6-aa2b0f330b12"/>
							<gml:surfaceMember xlink:href="#poly-4285e359-c2ef-43b9-b9ce-ca27a8aa58dc"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_563f524d-9fc7-41cc-b3ff-545f9bcaded7_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46ce94f4-26cd-49d3-bbf6-c2e50f9dcf03">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66831303659866 139.73927628053593 11.637 35.66830248234275 139.73926579924185 11.637 35.66829949328916 139.73927028741338 11.637 35.66829863631221 139.73926942683283 11.637 35.66829538883417 139.73926618312666 11.637 35.66830338365943 139.73925418886662 11.637 35.66831824041447 139.73926844283528 11.637 35.66831303659866 139.73927628053593 11.637</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7110416e-b397-493d-9f47-fd674f81f441">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7110416e-b397-493d-9f47-fd674f81f441_0">
											<gml:posList>35.66830338365943 139.73925418886662 11.637 35.66829538883417 139.73926618312666 11.637 35.66829538883417 139.73926618312666 27.498 35.66830338365943 139.73925418886662 27.498 35.66830338365943 139.73925418886662 11.637</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f28a2e1d-9b46-4a78-8d04-0cd79cb5acdf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f28a2e1d-9b46-4a78-8d04-0cd79cb5acdf_0">
											<gml:posList>35.66831824041447 139.73926844283528 11.637 35.66830338365943 139.73925418886662 11.637 35.66830338365943 139.73925418886662 27.498 35.66831824041447 139.73926844283528 27.498 35.66831824041447 139.73926844283528 11.637</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f34ee74-77e5-4d02-b09b-f997f909c435">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1f34ee74-77e5-4d02-b09b-f997f909c435_0">
											<gml:posList>35.66829949328916 139.73927028741338 27.498 35.66830248234275 139.73926579924185 27.498 35.66831303659866 139.73927628053593 27.498 35.66831824041447 139.73926844283528 27.498 35.66830338365943 139.73925418886662 27.498 35.66829538883417 139.73926618312666 27.498 35.66829863630358 139.73926941578685 27.497 35.66829949328916 139.73927028741338 27.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b5beea5e-4109-409b-bfe4-0cd0bfe9e6ac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b5beea5e-4109-409b-bfe4-0cd0bfe9e6ac_0">
											<gml:posList>35.66829538883417 139.73926618312666 11.637 35.66829863631221 139.73926942683283 11.637 35.66829863630358 139.73926941578685 27.497 35.66829538883417 139.73926618312666 27.498 35.66829538883417 139.73926618312666 11.637</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-735a6d7a-e894-4dfe-bf87-5dbf51f12efd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-735a6d7a-e894-4dfe-bf87-5dbf51f12efd_0">
											<gml:posList>35.66829949328916 139.73927028741338 11.637 35.66830248234275 139.73926579924185 11.637 35.66830248234275 139.73926579924185 27.498 35.66829949328916 139.73927028741338 27.498 35.66829949328916 139.73927028741338 11.637</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b4d0f7f-a93b-497e-8091-2892d3ef6bf0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7b4d0f7f-a93b-497e-8091-2892d3ef6bf0_0">
											<gml:posList>35.66829863631221 139.73926942683283 11.637 35.66829949328916 139.73927028741338 11.637 35.66829949328916 139.73927028741338 27.498 35.66829863630358 139.73926941578685 27.497 35.66829863631221 139.73926942683283 11.637</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a03a24b-3ab9-45b8-a37f-de1070e460a4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2a03a24b-3ab9-45b8-a37f-de1070e460a4_0">
											<gml:posList>35.66830248234275 139.73926579924185 11.637 35.66831303659866 139.73927628053593 11.637 35.66831303659866 139.73927628053593 27.498 35.66830248234275 139.73926579924185 27.498 35.66830248234275 139.73926579924185 11.637</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-05015cf2-2d14-4187-8756-b461dbc17680">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-05015cf2-2d14-4187-8756-b461dbc17680_0">
											<gml:posList>35.66831303659866 139.73927628053593 11.637 35.66831824041447 139.73926844283528 11.637 35.66831824041447 139.73926844283528 27.498 35.66831303659866 139.73927628053593 27.498 35.66831303659866 139.73927628053593 11.637</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-4f3c9b0b-5133-41cf-8195-da1f838b2d7b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f3c9b0b-5133-41cf-8195-da1f838b2d7b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f3c9b0b-5133-41cf-8195-da1f838b2d7b">
											<gml:posList>35.66829538883417 139.73926618312666 11.637 35.66829949328916 139.73927028741338 11.637 35.668275652929644 139.73930614850505 11.637 35.668214672604115 139.73924535676824 11.637 35.66826896164623 139.73916377381803 11.637 35.66834040613454 139.73923504693178 11.637 35.66831824041447 139.73926844283528 11.637 35.66830338365943 139.73925418886662 11.637 35.66829538883417 139.73926618312666 11.637</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1b33f259-7ae2-4f84-9957-b2dcdac1df2d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b33f259-7ae2-4f84-9957-b2dcdac1df2d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b33f259-7ae2-4f84-9957-b2dcdac1df2d">
											<gml:posList>35.66823860302261 139.73920941825835 27.758 35.66824039658132 139.73920919523368 27.758 35.66826914363109 139.73916596070606 27.758 35.66826896164623 139.73916377381803 27.758 35.66823860302261 139.73920941825835 27.758</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a5387d59-66a2-489d-8c9d-b70d1ed068a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5387d59-66a2-489d-8c9d-b70d1ed068a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5387d59-66a2-489d-8c9d-b70d1ed068a9">
											<gml:posList>35.668275652929644 139.73930614850505 20.472 35.66829949328916 139.73927028741338 27.758 35.66829538883417 139.73926618312666 27.758 35.66823860302261 139.73920941825835 27.758 35.668214672604115 139.73924535676824 20.472 35.668275652929644 139.73930614850505 20.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-51215aaf-7b9f-403b-95fa-f9c435819045">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-51215aaf-7b9f-403b-95fa-f9c435819045">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-51215aaf-7b9f-403b-95fa-f9c435819045">
											<gml:posList>35.66829538883417 139.73926618312666 27.758 35.668295206851106 139.7392639962377 27.758 35.66824039658132 139.73920919523368 27.758 35.66823860302261 139.73920941825835 27.758 35.66829538883417 139.73926618312666 27.758</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-33a14a8e-0f35-4b90-8c4b-aeb0cf5daea0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-33a14a8e-0f35-4b90-8c4b-aeb0cf5daea0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-33a14a8e-0f35-4b90-8c4b-aeb0cf5daea0">
											<gml:posList>35.66830319267969 139.73925202407995 27.335 35.668318031398904 139.73926626702337 27.335 35.6683386215809 139.7392352588996 27.335 35.66826914363109 139.73916596070606 27.335 35.66824039658132 139.73920919523368 27.335 35.668295206851106 139.7392639962377 27.335 35.66830319267969 139.73925202407995 27.335</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0dbfeabd-c842-4e7f-83ff-3e1e35e1e2a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0dbfeabd-c842-4e7f-83ff-3e1e35e1e2a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0dbfeabd-c842-4e7f-83ff-3e1e35e1e2a3">
											<gml:posList>35.66830338365943 139.73925418886662 27.758 35.66830319267969 139.73925202407995 27.758 35.668295206851106 139.7392639962377 27.758 35.66829538883417 139.73926618312666 27.758 35.66830338365943 139.73925418886662 27.758</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-86ac08d4-81bb-4fcc-b2fa-b58be7fae31b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-86ac08d4-81bb-4fcc-b2fa-b58be7fae31b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-86ac08d4-81bb-4fcc-b2fa-b58be7fae31b">
											<gml:posList>35.66826896164623 139.73916377381803 27.758 35.66826914363109 139.73916596070606 27.758 35.6683386215809 139.7392352588996 27.758 35.66834040613454 139.73923504693178 27.758 35.66826896164623 139.73916377381803 27.758</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4c324cea-7325-47c2-b6bc-d8d421f4a2ed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c324cea-7325-47c2-b6bc-d8d421f4a2ed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c324cea-7325-47c2-b6bc-d8d421f4a2ed">
											<gml:posList>35.66830338365943 139.73925418886662 27.758 35.66831824041447 139.73926844283528 27.758 35.668318031398904 139.73926626702337 27.758 35.66830319267969 139.73925202407995 27.758 35.66830338365943 139.73925418886662 27.758</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1684f5be-ee99-42c1-93b3-06543f266042">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1684f5be-ee99-42c1-93b3-06543f266042">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1684f5be-ee99-42c1-93b3-06543f266042">
											<gml:posList>35.66834040613454 139.73923504693178 27.758 35.6683386215809 139.7392352588996 27.758 35.668318031398904 139.73926626702337 27.758 35.66831824041447 139.73926844283528 27.758 35.66834040613454 139.73923504693178 27.758</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-27af0206-39d8-4fff-a395-8602f041f1e4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-27af0206-39d8-4fff-a395-8602f041f1e4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-27af0206-39d8-4fff-a395-8602f041f1e4">
											<gml:posList>35.668295206851106 139.7392639962377 27.758 35.668295206851106 139.7392639962377 27.335 35.66824039658132 139.73920919523368 27.335 35.66824039658132 139.73920919523368 27.758 35.668295206851106 139.7392639962377 27.758</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a2fe3b75-1c1b-499d-a0b6-80c7788eb7b5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2fe3b75-1c1b-499d-a0b6-80c7788eb7b5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2fe3b75-1c1b-499d-a0b6-80c7788eb7b5">
											<gml:posList>35.66826896164623 139.73916377381803 11.637 35.668214672604115 139.73924535676824 11.637 35.668214672604115 139.73924535676824 20.472 35.66823860302261 139.73920941825835 27.758 35.66826896164623 139.73916377381803 27.758 35.66826896164623 139.73916377381803 11.637</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b656b38a-3320-4399-82d0-c946e38b2c32">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b656b38a-3320-4399-82d0-c946e38b2c32">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b656b38a-3320-4399-82d0-c946e38b2c32">
											<gml:posList>35.668214672604115 139.73924535676824 11.637 35.668275652929644 139.73930614850505 11.637 35.668275652929644 139.73930614850505 20.472 35.668214672604115 139.73924535676824 20.472 35.668214672604115 139.73924535676824 11.637</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d53da70e-484a-421f-a20d-7cd828a03b6c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d53da70e-484a-421f-a20d-7cd828a03b6c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d53da70e-484a-421f-a20d-7cd828a03b6c">
											<gml:posList>35.66824039658132 139.73920919523368 27.758 35.66824039658132 139.73920919523368 27.335 35.66826914363109 139.73916596070606 27.335 35.66826914363109 139.73916596070606 27.758 35.66824039658132 139.73920919523368 27.758</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-38bb1fe7-431b-4ea8-91b8-100f50cc4b1d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38bb1fe7-431b-4ea8-91b8-100f50cc4b1d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38bb1fe7-431b-4ea8-91b8-100f50cc4b1d">
											<gml:posList>35.668275652929644 139.73930614850505 20.472 35.668275652929644 139.73930614850505 11.637 35.66829949328916 139.73927028741338 11.637 35.66829949328916 139.73927028741338 27.758 35.668275652929644 139.73930614850505 20.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5b20fb6e-e9cb-496b-9f98-c2cd3ffe2044">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b20fb6e-e9cb-496b-9f98-c2cd3ffe2044">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b20fb6e-e9cb-496b-9f98-c2cd3ffe2044">
											<gml:posList>35.66829949328916 139.73927028741338 11.637 35.66829538883417 139.73926618312666 11.637 35.66829538883417 139.73926618312666 27.758 35.66829949328916 139.73927028741338 27.758 35.66829949328916 139.73927028741338 11.637</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-07959157-3783-4d3f-a99c-316b730c8830">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-07959157-3783-4d3f-a99c-316b730c8830">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-07959157-3783-4d3f-a99c-316b730c8830">
											<gml:posList>35.66830319267969 139.73925202407995 27.758 35.66830319267969 139.73925202407995 27.335 35.668295206851106 139.7392639962377 27.335 35.668295206851106 139.7392639962377 27.758 35.66830319267969 139.73925202407995 27.758</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fe2722fd-ad7c-40a9-89e7-c9c5c52d12ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe2722fd-ad7c-40a9-89e7-c9c5c52d12ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe2722fd-ad7c-40a9-89e7-c9c5c52d12ac">
											<gml:posList>35.66829538883417 139.73926618312666 27.758 35.66829538883417 139.73926618312666 11.637 35.66830338365943 139.73925418886662 11.637 35.66830338365943 139.73925418886662 27.758 35.66829538883417 139.73926618312666 27.758</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0e5cdec7-40e9-4294-8e14-8fba40997985">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e5cdec7-40e9-4294-8e14-8fba40997985">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e5cdec7-40e9-4294-8e14-8fba40997985">
											<gml:posList>35.66826914363109 139.73916596070606 27.758 35.66826914363109 139.73916596070606 27.335 35.6683386215809 139.7392352588996 27.335 35.6683386215809 139.7392352588996 27.758 35.66826914363109 139.73916596070606 27.758</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-609c1a1e-e9b5-4343-b5f7-623969b3bb2d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-609c1a1e-e9b5-4343-b5f7-623969b3bb2d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-609c1a1e-e9b5-4343-b5f7-623969b3bb2d">
											<gml:posList>35.66834040613454 139.73923504693178 11.637 35.66826896164623 139.73916377381803 11.637 35.66826896164623 139.73916377381803 27.758 35.66834040613454 139.73923504693178 27.758 35.66834040613454 139.73923504693178 11.637</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ffb4b774-8819-4171-8050-0a3d684e6ade">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ffb4b774-8819-4171-8050-0a3d684e6ade">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ffb4b774-8819-4171-8050-0a3d684e6ade">
											<gml:posList>35.668318031398904 139.73926626702337 27.758 35.668318031398904 139.73926626702337 27.335 35.66830319267969 139.73925202407995 27.335 35.66830319267969 139.73925202407995 27.758 35.668318031398904 139.73926626702337 27.758</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e72146fe-556c-41c8-b06e-3bb17bf1e481">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e72146fe-556c-41c8-b06e-3bb17bf1e481">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e72146fe-556c-41c8-b06e-3bb17bf1e481">
											<gml:posList>35.66830338365943 139.73925418886662 11.637 35.66831824041447 139.73926844283528 11.637 35.66831824041447 139.73926844283528 27.758 35.66830338365943 139.73925418886662 27.758 35.66830338365943 139.73925418886662 11.637</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-412c3f9e-b2d4-4603-a2a6-aa2b0f330b12">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-412c3f9e-b2d4-4603-a2a6-aa2b0f330b12">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-412c3f9e-b2d4-4603-a2a6-aa2b0f330b12">
											<gml:posList>35.6683386215809 139.7392352588996 27.758 35.6683386215809 139.7392352588996 27.335 35.668318031398904 139.73926626702337 27.335 35.668318031398904 139.73926626702337 27.758 35.6683386215809 139.7392352588996 27.758</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4285e359-c2ef-43b9-b9ce-ca27a8aa58dc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4285e359-c2ef-43b9-b9ce-ca27a8aa58dc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4285e359-c2ef-43b9-b9ce-ca27a8aa58dc">
											<gml:posList>35.66831824041447 139.73926844283528 11.637 35.66834040613454 139.73923504693178 11.637 35.66834040613454 139.73923504693178 27.758 35.66831824041447 139.73926844283528 27.758 35.66831824041447 139.73926844283528 11.637</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5352</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">87.44606</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>