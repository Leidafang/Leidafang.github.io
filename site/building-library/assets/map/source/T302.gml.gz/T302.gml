<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_570a8bac-9ade-4a3b-8758-843e3322a0ca">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門駅南地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">33.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>7</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.669078803225204 139.7500551307741 0 35.669091552890116 139.7500612702001 0 35.669093720569016 139.75005457402247 0 35.66913050894944 139.7500724304758 0 35.669177999746985 139.74992545705487 0 35.66916091297291 139.7499171571217 0 35.66916576998537 139.74990214042828 0 35.66913357110558 139.74988649953258 0 35.6691287140951 139.7499015162209 0 35.66903841116637 139.7498576688962 0 35.66897258111933 139.750061990245 0 35.66906208193642 139.7501061037025 0 35.669078803225204 139.7500551307741 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669078803225204 139.7500551307741 5.719 35.66906208193642 139.7501061037025 5.719 35.66897258111933 139.750061990245 5.719 35.66903841116637 139.7498576688962 5.719 35.6691287140951 139.7499015162209 5.719 35.66913357110558 139.74988649953258 5.719 35.66916576998537 139.74990214042828 5.719 35.66916091297291 139.7499171571217 5.719 35.669177999746985 139.74992545705487 5.719 35.66913050894944 139.7500724304758 5.719 35.669093720569016 139.75005457402247 5.719 35.669091552890116 139.7500612702001 5.719 35.669078803225204 139.7500551307741 5.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669078803225204 139.7500551307741 5.719 35.669091552890116 139.7500612702001 5.719 35.669091552890116 139.7500612702001 37.38 35.669078803225204 139.7500551307741 37.38 35.669078803225204 139.7500551307741 5.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669091552890116 139.7500612702001 5.719 35.669093720569016 139.75005457402247 5.719 35.669093720569016 139.75005457402247 37.38 35.669091552890116 139.7500612702001 37.38 35.669091552890116 139.7500612702001 5.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669093720569016 139.75005457402247 5.719 35.66913050894944 139.7500724304758 5.719 35.66913050894944 139.7500724304758 37.38 35.669093720569016 139.75005457402247 37.38 35.669093720569016 139.75005457402247 5.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66913050894944 139.7500724304758 5.719 35.669177999746985 139.74992545705487 5.719 35.669177999746985 139.74992545705487 37.38 35.66913050894944 139.7500724304758 37.38 35.66913050894944 139.7500724304758 5.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669177999746985 139.74992545705487 5.719 35.66916091297291 139.7499171571217 5.719 35.66916091297291 139.7499171571217 37.38 35.669177999746985 139.74992545705487 37.38 35.669177999746985 139.74992545705487 5.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66916091297291 139.7499171571217 5.719 35.66916576998537 139.74990214042828 5.719 35.66916576998537 139.74990214042828 37.38 35.66916091297291 139.7499171571217 37.38 35.66916091297291 139.7499171571217 5.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66916576998537 139.74990214042828 5.719 35.66913357110558 139.74988649953258 5.719 35.66913357110558 139.74988649953258 37.38 35.66916576998537 139.74990214042828 37.38 35.66916576998537 139.74990214042828 5.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66913357110558 139.74988649953258 5.719 35.6691287140951 139.7499015162209 5.719 35.6691287140951 139.7499015162209 37.38 35.66913357110558 139.74988649953258 37.38 35.66913357110558 139.74988649953258 5.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6691287140951 139.7499015162209 5.719 35.66903841116637 139.7498576688962 5.719 35.66903841116637 139.7498576688962 37.38 35.6691287140951 139.7499015162209 37.38 35.6691287140951 139.7499015162209 5.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66903841116637 139.7498576688962 5.719 35.66897258111933 139.750061990245 5.719 35.66897258111933 139.750061990245 37.38 35.66903841116637 139.7498576688962 37.38 35.66903841116637 139.7498576688962 5.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66897258111933 139.750061990245 5.719 35.66906208193642 139.7501061037025 5.719 35.66906208193642 139.7501061037025 37.38 35.66897258111933 139.750061990245 37.38 35.66897258111933 139.750061990245 5.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66906208193642 139.7501061037025 5.719 35.669078803225204 139.7500551307741 5.719 35.669078803225204 139.7500551307741 37.38 35.66906208193642 139.7501061037025 37.38 35.66906208193642 139.7501061037025 5.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669078803225204 139.7500551307741 37.38 35.669091552890116 139.7500612702001 37.38 35.669093720569016 139.75005457402247 37.38 35.66913050894944 139.7500724304758 37.38 35.669177999746985 139.74992545705487 37.38 35.66916091297291 139.7499171571217 37.38 35.66916576998537 139.74990214042828 37.38 35.66913357110558 139.74988649953258 37.38 35.6691287140951 139.7499015162209 37.38 35.66903841116637 139.7498576688962 37.38 35.66897258111933 139.750061990245 37.38 35.66906208193642 139.7501061037025 37.38 35.669078803225204 139.7500551307741 37.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-220e128e-1796-4e00-b3d9-1f30d6a3c855"/>
							<gml:surfaceMember xlink:href="#poly-23108f67-9620-4654-aa16-8bde61f38ce9"/>
							<gml:surfaceMember xlink:href="#poly-4fe3b89e-ba2d-47e4-a4e7-c511c5037478"/>
							<gml:surfaceMember xlink:href="#poly-e8c88ce1-a352-45e7-ba2c-7c59ed9e4fc3"/>
							<gml:surfaceMember xlink:href="#poly-74bc64e2-3183-4740-b4ce-41b1a0e09d38"/>
							<gml:surfaceMember xlink:href="#poly-2dfeab5c-37a2-4ccc-a19c-2cf442ff86e7"/>
							<gml:surfaceMember xlink:href="#poly-a4ac9212-a078-4bbf-a9cd-0bf9759666aa"/>
							<gml:surfaceMember xlink:href="#poly-38979b09-310d-46bb-81f8-7c02f42959ae"/>
							<gml:surfaceMember xlink:href="#poly-692efe52-e8a0-4236-b014-b48456273ec5"/>
							<gml:surfaceMember xlink:href="#poly-a3efc097-55af-473a-ac16-6a18596cd64e"/>
							<gml:surfaceMember xlink:href="#poly-5b2c3234-6a63-4c76-8bad-586130f78fc5"/>
							<gml:surfaceMember xlink:href="#poly-c14efc60-2851-453f-bd7a-fe0e985f16b1"/>
							<gml:surfaceMember xlink:href="#poly-2bfccfdf-82c2-4178-aea9-6839cdfabca2"/>
							<gml:surfaceMember xlink:href="#poly-cbb00634-ab59-4f65-87a8-d25c6c28a59e"/>
							<gml:surfaceMember xlink:href="#poly-8c391915-b6d6-47e6-b580-43a390cccac1"/>
							<gml:surfaceMember xlink:href="#poly-1b82caa5-37f7-4066-9a1e-899700ad70ee"/>
							<gml:surfaceMember xlink:href="#poly-c4fff939-25b0-4cfe-86ba-d51f04ec2f9e"/>
							<gml:surfaceMember xlink:href="#poly-dd46b1b3-a643-462f-b977-907e1401cafb"/>
							<gml:surfaceMember xlink:href="#poly-5a4c3adf-6d60-4f1d-829b-a9554c483e91"/>
							<gml:surfaceMember xlink:href="#poly-25b5a9ae-bec3-424f-bbc0-6d921078fa0f"/>
							<gml:surfaceMember xlink:href="#poly-476e53e4-c3a1-4d3c-a4f6-2af4b6fc4ef1"/>
							<gml:surfaceMember xlink:href="#poly-5d9e257b-0b2f-4185-b9cd-66aead105405"/>
							<gml:surfaceMember xlink:href="#poly-c34a9c47-c508-4cd4-bf0d-d34127d0abb0"/>
							<gml:surfaceMember xlink:href="#poly-573c3c35-1bff-4e58-b11b-3aefa1dd27e9"/>
							<gml:surfaceMember xlink:href="#poly-0ce977d3-7b1b-413d-8353-12c80eaed44f"/>
							<gml:surfaceMember xlink:href="#poly-1096dab4-76b1-486d-b8d2-37cf7f153e71"/>
							<gml:surfaceMember xlink:href="#poly-8fc067c2-9129-4d06-8ece-68a14b95cadc"/>
							<gml:surfaceMember xlink:href="#poly-8b33569a-4718-46af-a72e-096952c7965f"/>
							<gml:surfaceMember xlink:href="#poly-2f889852-d376-4808-8c45-78430b060ddd"/>
							<gml:surfaceMember xlink:href="#poly-9cf5fc37-c250-46e0-951b-19ff8ebe9732"/>
							<gml:surfaceMember xlink:href="#poly-6774349c-989f-41ed-b464-a408a5ae67ce"/>
							<gml:surfaceMember xlink:href="#poly-948be7f6-4e8d-4437-8be4-68b4da297dc8"/>
							<gml:surfaceMember xlink:href="#poly-de8b3113-fb81-4a2d-bc52-54d2ded7ef1f"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_570a8bac-9ade-4a3b-8758-843e3322a0ca_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-000884da-815e-4960-8419-10fa7803b608">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669110332769556 139.74998927440376 39.067 35.66913703140523 139.75000223685274 39.067 35.66912830647928 139.75002882280788 39.067 35.66910167082023 139.75001568354864 39.067 35.669110332769556 139.74998927440376 39.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d46b3f03-00bf-4860-904a-c199e2271b7c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d46b3f03-00bf-4860-904a-c199e2271b7c_0">
											<gml:posList>35.66910167082023 139.75001568354864 39.067 35.66910167082023 139.75001568354864 41.142 35.669110332769556 139.74998927440376 41.142 35.669110332769556 139.74998927440376 39.067 35.66910167082023 139.75001568354864 39.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a8c48f7-0c99-40c1-a81e-cd86ac5543c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1a8c48f7-0c99-40c1-a81e-cd86ac5543c3_0">
											<gml:posList>35.66912830647928 139.75002882280788 39.067 35.66912830647928 139.75002882280788 41.142 35.66910167082023 139.75001568354864 41.142 35.66910167082023 139.75001568354864 39.067 35.66912830647928 139.75002882280788 39.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c98fe167-3d9a-4392-b600-dc84e78ab408">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c98fe167-3d9a-4392-b600-dc84e78ab408_0">
											<gml:posList>35.66912830647928 139.75002882280788 41.142 35.66913703140523 139.75000223685274 41.142 35.669110332769556 139.74998927440376 41.142 35.66910167082023 139.75001568354864 41.142 35.66912830647928 139.75002882280788 41.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29e96197-5abf-457c-9957-a1679a999c57">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29e96197-5abf-457c-9957-a1679a999c57_0">
											<gml:posList>35.669110332769556 139.74998927440376 39.067 35.669110332769556 139.74998927440376 41.142 35.66913703140523 139.75000223685274 41.142 35.66913703140523 139.75000223685274 39.067 35.669110332769556 139.74998927440376 39.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d1b2e4f-f82c-46d6-9edc-e3ab020c6736">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d1b2e4f-f82c-46d6-9edc-e3ab020c6736_0">
											<gml:posList>35.66913703140523 139.75000223685274 39.067 35.66913703140523 139.75000223685274 41.142 35.66912830647928 139.75002882280788 41.142 35.66912830647928 139.75002882280788 39.067 35.66913703140523 139.75000223685274 39.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_570a8bac-9ade-4a3b-8758-843e3322a0ca_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ae4ae70b-3fb9-4779-9113-4466dc745f07">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6689991107866 139.74998707033785 39.067 35.66900565696199 139.74999025584785 39.067 35.66900297661268 139.7499985542329 39.067 35.668996439443575 139.74999535766693 39.067 35.6689991107866 139.74998707033785 39.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-983a268b-b9f1-4b34-8bc9-20b955d9a01f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66900565696199 139.74999025584785 40.071 35.66900297661268 139.7499985542329 40.071 35.66900297661268 139.7499985542329 39.067 35.66900565696199 139.74999025584785 39.067 35.66900565696199 139.74999025584785 40.071</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3140aa32-e83b-4b08-85ee-d94dfa87ce84">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66900567262677 139.7499998659133 40.071 35.66900835297617 139.74999156752799 40.071 35.66900835297617 139.74999156752799 39.067 35.66900567262677 139.7499998659133 39.067 35.66900567262677 139.7499998659133 40.071</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-93234bbe-0027-4b6f-9680-81edb1551771">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66900835297617 139.74999156752799 39.067 35.669019524745316 139.7499969905838 39.067 35.66901684439555 139.75000528897007 39.067 35.66900567262677 139.7499998659133 39.067 35.66900835297617 139.74999156752799 39.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e6212c0-77d1-4631-a56c-948268b28da4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669019524745316 139.7499969905838 40.071 35.66901684439555 139.75000528897007 40.071 35.66901684439555 139.75000528897007 39.067 35.669019524745316 139.7499969905838 39.067 35.669019524745316 139.7499969905838 40.071</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6406b159-14bf-40cc-a426-713f2807fe73">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66902202389486 139.74998735581045 39.067 35.66900243006217 139.74997725797692 39.067 35.669014933911406 139.74994080398565 39.067 35.669034527739456 139.74995089076575 39.067 35.66902202389486 139.74998735581045 39.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77bd0992-8f3c-4153-b342-2d3c1afc0161">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669021001122545 139.7500073060816 40.071 35.66902368147245 139.74999900769495 40.071 35.66902368147245 139.74999900769495 39.067 35.669021001122545 139.7500073060816 39.067 35.669021001122545 139.7500073060816 40.071</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb167576-ffe4-4113-b137-cf0f8cf60348">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66901972591797 139.7499230258704 39.067 35.66903054586408 139.74992802953255 39.067 35.669027811834525 139.74993690237392 39.067 35.66901699188113 139.7499318876647 39.067 35.66901972591797 139.7499230258704 39.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db885ce5-e850-4bd9-bb6a-872146d9fe63">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66902368147245 139.74999900769495 39.067 35.66903570082204 139.75000484962283 39.067 35.66903301145038 139.75001313697382 39.067 35.669021001122545 139.7500073060816 39.067 35.66902368147245 139.74999900769495 39.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ae566e1d-8e60-456e-8737-e8234e7733df">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669033403383864 139.74992826957376 39.067 35.66904267266267 139.74993283300734 39.067 35.66903940757254 139.74994278891768 39.067 35.669030138286466 139.74993821443707 39.067 35.669033403383864 139.74992826957376 39.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2252c01c-f1b7-4879-91c4-2c2d6beb94a9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66904267266267 139.74993283300734 40.006 35.66903940757254 139.74994278891768 40.006 35.66903940757254 139.74994278891768 39.067 35.66904267266267 139.74993283300734 39.067 35.66904267266267 139.74993283300734 40.006</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af8c9a32-8171-476d-81f3-7f7da64b66cb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66904248240854 139.74994445367724 40.006 35.669045792483274 139.749934376213 40.006 35.669045792483274 139.749934376213 39.067 35.66904248240854 139.74994445367724 39.067 35.66904248240854 139.74994445367724 40.006</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bec7b54d-82b4-4821-b94b-5b71de0078cd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66905062292919 139.74999815123834 39.067 35.66903231858035 139.74998880319134 39.067 35.66904389569418 139.74995476924266 39.067 35.66906219103189 139.74996411729262 39.067 35.66905062292919 139.74999815123834 39.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-746cc3a5-78f6-4a1e-8444-dc352ca0a5b3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669045792483274 139.749934376213 39.067 35.669057487295895 139.74994015219383 39.067 35.66905418622675 139.74995021860389 39.067 35.66904248240854 139.74994445367724 39.067 35.669045792483274 139.749934376213 39.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a64f72a-cf30-4cc5-b26f-a1d50e208c6d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669062338341014 139.7499425441476 39.067 35.66907394297769 139.74994826499415 39.067 35.66907052495123 139.7499586518639 39.067 35.66905892932878 139.74995293100665 39.067 35.669062338341014 139.7499425441476 39.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ffda3eb-770d-411b-a38f-57fb00232c6f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669068606727116 139.75001319939986 39.067 35.66905949047072 139.75000832650633 39.067 35.66907457717756 139.74996596015558 39.067 35.66908369344327 139.74997084409128 39.067 35.669068606727116 139.75001319939986 39.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-579ab6d2-00db-41c6-81d0-34b0148f3f37">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6690892696385 139.75000513638003 39.067 35.669084021768974 139.75000242449772 39.067 35.66909087649059 139.7499825675631 39.067 35.669096115346846 139.74998527945368 39.067 35.6690892696385 139.75000513638003 39.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f126c69-d6c9-4469-a35a-76b278d33fe6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66909731362348 139.75004962164516 39.067 35.669090244584815 139.7500463372551 39.067 35.66909373413263 139.75003508871774 39.067 35.669100803171595 139.75003837310697 39.067 35.66909731362348 139.75004962164516 39.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ed951ec2-9306-4234-af78-dfacb8380de7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66912530410305 139.7500667581916 39.067 35.669096198404254 139.75005321278064 39.067 35.66910539892337 139.75002353344098 39.067 35.66913449561172 139.75003707885205 39.067 35.66912530410305 139.7500667581916 39.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d384764-9f0d-4253-b094-402e205e6d03">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66910503899102 139.75005048626159 44.445 35.66911040821316 139.7500331714688 44.445 35.66912727833663 139.75004101875695 44.445 35.669121909113386 139.75005833355286 44.445 35.66910503899102 139.75005048626159 44.445</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-406f5f73-d52d-4598-8c2f-f4f3a07ee6ce">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669156581038905 139.749974523983 39.067 35.669146856719145 139.7500027347616 39.067 35.669103223629634 139.74998014668148 39.067 35.66911203822321 139.74995289787103 39.067 35.669156581038905 139.749974523983 39.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a9a13930-e4a0-40c3-b8b6-b277f07f672d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a9a13930-e4a0-40c3-b8b6-b277f07f672d_0">
											<gml:posList>35.669100803171595 139.75003837310697 43.551 35.66909731362348 139.75004962164516 43.551 35.66909731362348 139.75004962164516 39.067 35.669100803171595 139.75003837310697 39.067 35.669100803171595 139.75003837310697 43.551</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-baa49136-2d46-47bd-9a75-64e2d0179ac6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-baa49136-2d46-47bd-9a75-64e2d0179ac6_0">
											<gml:posList>35.66900835297617 139.74999156752799 40.071 35.669019524745316 139.7499969905838 40.071 35.669019524745316 139.7499969905838 39.067 35.66900835297617 139.74999156752799 39.067 35.66900835297617 139.74999156752799 40.071</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fd59a695-7680-42f7-9fc5-c70c1434f532">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fd59a695-7680-42f7-9fc5-c70c1434f532_0">
											<gml:posList>35.669096115346846 139.74998527945368 40.8 35.6690892696385 139.75000513638003 40.8 35.6690892696385 139.75000513638003 39.067 35.669096115346846 139.74998527945368 39.067 35.669096115346846 139.74998527945368 40.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-71012753-7c19-4aea-8fce-b19f0ca6f14d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-71012753-7c19-4aea-8fce-b19f0ca6f14d_0">
											<gml:posList>35.66900297661268 139.7499985542329 40.071 35.668996439443575 139.74999535766693 40.071 35.668996439443575 139.74999535766693 39.067 35.66900297661268 139.7499985542329 39.067 35.66900297661268 139.7499985542329 40.071</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01118df8-b4f4-421d-a63f-f5646e60e61a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01118df8-b4f4-421d-a63f-f5646e60e61a_0">
											<gml:posList>35.669019524745316 139.7499969905838 40.071 35.66900835297617 139.74999156752799 40.071 35.66900567262677 139.7499998659133 40.071 35.66901684439555 139.75000528897007 40.071 35.669019524745316 139.7499969905838 40.071</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18b42df9-f74f-41b6-b9b9-95091f181502">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-18b42df9-f74f-41b6-b9b9-95091f181502_0">
											<gml:posList>35.66902368147245 139.74999900769495 40.071 35.66903570082204 139.75000484962283 40.071 35.66903570082204 139.75000484962283 39.067 35.66902368147245 139.74999900769495 39.067 35.66902368147245 139.74999900769495 40.071</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4f02e5a-4aa9-4161-8485-2c13031c971b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4f02e5a-4aa9-4161-8485-2c13031c971b_0">
											<gml:posList>35.66901684439555 139.75000528897007 40.071 35.66900567262677 139.7499998659133 40.071 35.66900567262677 139.7499998659133 39.067 35.66901684439555 139.75000528897007 39.067 35.66901684439555 139.75000528897007 40.071</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e5c08c4a-f03e-4353-890f-02f92fc03379">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e5c08c4a-f03e-4353-890f-02f92fc03379_0">
											<gml:posList>35.6690892696385 139.75000513638003 40.8 35.669084021768974 139.75000242449772 40.8 35.669084021768974 139.75000242449772 39.067 35.6690892696385 139.75000513638003 39.067 35.6690892696385 139.75000513638003 40.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-550b759e-46ef-4b04-a4ae-ad1de6de9d3f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-550b759e-46ef-4b04-a4ae-ad1de6de9d3f_0">
											<gml:posList>35.66903570082204 139.75000484962283 40.071 35.66902368147245 139.74999900769495 40.071 35.669021001122545 139.7500073060816 40.071 35.66903301145038 139.75001313697382 40.071 35.66903570082204 139.75000484962283 40.071</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e59b014-508d-4805-a1f3-c3073bb198d9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9e59b014-508d-4805-a1f3-c3073bb198d9_0">
											<gml:posList>35.66903570082204 139.75000484962283 40.071 35.66903301145038 139.75001313697382 40.071 35.66903301145038 139.75001313697382 39.067 35.66903570082204 139.75000484962283 39.067 35.66903570082204 139.75000484962283 40.071</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb6f33e0-ff4d-4104-b956-ff5fd8d438ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb6f33e0-ff4d-4104-b956-ff5fd8d438ce_0">
											<gml:posList>35.66903301145038 139.75001313697382 40.071 35.669021001122545 139.7500073060816 40.071 35.669021001122545 139.7500073060816 39.067 35.66903301145038 139.75001313697382 39.067 35.66903301145038 139.75001313697382 40.071</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3bd3bd00-eb8a-46aa-a403-c7629660dfab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3bd3bd00-eb8a-46aa-a403-c7629660dfab_0">
											<gml:posList>35.669068606727116 139.75001319939986 40.325 35.66905949047072 139.75000832650633 40.325 35.66905949047072 139.75000832650633 39.067 35.669068606727116 139.75001319939986 39.067 35.669068606727116 139.75001319939986 40.325</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8924217-a4be-43f2-ae8c-1c340a5d48d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8924217-a4be-43f2-ae8c-1c340a5d48d1_0">
											<gml:posList>35.66910539892337 139.75002353344098 44.445 35.66913449561172 139.75003707885205 44.445 35.66913449561172 139.75003707885205 39.067 35.66910539892337 139.75002353344098 39.067 35.66910539892337 139.75002353344098 44.445</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f0aa42b-c607-4dbe-bc85-e05c483f4ff3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f0aa42b-c607-4dbe-bc85-e05c483f4ff3_0">
											<gml:posList>35.66909373413263 139.75003508871774 43.551 35.669100803171595 139.75003837310697 43.551 35.669100803171595 139.75003837310697 39.067 35.66909373413263 139.75003508871774 39.067 35.66909373413263 139.75003508871774 43.551</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0aac04b9-cfa5-4700-9ea1-75f7605b82fa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0aac04b9-cfa5-4700-9ea1-75f7605b82fa_0">
											<gml:posList>35.66911040821316 139.7500331714688 45.346 35.66912727833663 139.75004101875695 45.346 35.66912727833663 139.75004101875695 44.445 35.66911040821316 139.7500331714688 44.445 35.66911040821316 139.7500331714688 45.346</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d96726a-22df-47b0-a989-c229129f5322">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d96726a-22df-47b0-a989-c229129f5322_0">
											<gml:posList>35.66910539892337 139.75002353344098 44.445 35.66910539892337 139.75002353344098 39.067 35.669096198404254 139.75005321278064 39.067 35.669096198404254 139.75005321278064 44.445 35.66910539892337 139.75002353344098 44.445</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-026e9754-4723-4937-aa81-2eeb2aef46ee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-026e9754-4723-4937-aa81-2eeb2aef46ee_0">
											<gml:posList>35.669090244584815 139.7500463372551 43.551 35.66909373413263 139.75003508871774 43.551 35.66909373413263 139.75003508871774 39.067 35.669090244584815 139.7500463372551 39.067 35.669090244584815 139.7500463372551 43.551</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63a895fc-db8d-4766-ad70-eed3a22258b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-63a895fc-db8d-4766-ad70-eed3a22258b8_0">
											<gml:posList>35.66910503899102 139.75005048626159 45.346 35.66911040821316 139.7500331714688 45.346 35.66911040821316 139.7500331714688 44.445 35.66910503899102 139.75005048626159 44.445 35.66910503899102 139.75005048626159 45.346</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-961fa6ce-317e-49df-9697-6f0e65c4cd49">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-961fa6ce-317e-49df-9697-6f0e65c4cd49_0">
											<gml:posList>35.669090244584815 139.7500463372551 43.551 35.66909731362348 139.75004962164516 43.551 35.669100803171595 139.75003837310697 43.551 35.66909373413263 139.75003508871774 43.551 35.669090244584815 139.7500463372551 43.551</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b59da0a9-3ed5-4325-a153-913dcc2d18f4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b59da0a9-3ed5-4325-a153-913dcc2d18f4_0">
											<gml:posList>35.669096198404254 139.75005321278064 44.445 35.66912530410305 139.7500667581916 44.445 35.66913449561172 139.75003707885205 44.445 35.66910539892337 139.75002353344098 44.445 35.669096198404254 139.75005321278064 44.445</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2e7095ff-b063-44b8-a80c-00c13272d949">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2e7095ff-b063-44b8-a80c-00c13272d949_0">
											<gml:posList>35.66911040821316 139.7500331714688 45.346 35.66910503899102 139.75005048626159 45.346 35.669121909113386 139.75005833355286 45.346 35.66912727833663 139.75004101875695 45.346 35.66911040821316 139.7500331714688 45.346</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f006d5b4-a170-45f4-973b-8ba6f10bf28e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f006d5b4-a170-45f4-973b-8ba6f10bf28e_0">
											<gml:posList>35.66909731362348 139.75004962164516 43.551 35.669090244584815 139.7500463372551 43.551 35.669090244584815 139.7500463372551 39.067 35.66909731362348 139.75004962164516 39.067 35.66909731362348 139.75004962164516 43.551</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-91ee5c8e-6fa8-4444-9732-be18fa782a3e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-91ee5c8e-6fa8-4444-9732-be18fa782a3e_0">
											<gml:posList>35.66912727833663 139.75004101875695 45.346 35.669121909113386 139.75005833355286 45.346 35.669121909113386 139.75005833355286 44.445 35.66912727833663 139.75004101875695 44.445 35.66912727833663 139.75004101875695 45.346</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-64d0fa46-2c64-4c36-8578-9d8605f4bd79">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-64d0fa46-2c64-4c36-8578-9d8605f4bd79_0">
											<gml:posList>35.66913449561172 139.75003707885205 44.445 35.66912530410305 139.7500667581916 44.445 35.66912530410305 139.7500667581916 39.067 35.66913449561172 139.75003707885205 39.067 35.66913449561172 139.75003707885205 44.445</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df5857a9-d82c-480e-a929-a3bdb0e03419">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-df5857a9-d82c-480e-a929-a3bdb0e03419_0">
											<gml:posList>35.669121909113386 139.75005833355286 45.346 35.66910503899102 139.75005048626159 45.346 35.66910503899102 139.75005048626159 44.445 35.669121909113386 139.75005833355286 44.445 35.669121909113386 139.75005833355286 45.346</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8abe50c-2719-4de4-81ba-5f39738e9ff8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b8abe50c-2719-4de4-81ba-5f39738e9ff8_0">
											<gml:posList>35.66912530410305 139.7500667581916 44.445 35.669096198404254 139.75005321278064 44.445 35.669096198404254 139.75005321278064 39.067 35.66912530410305 139.7500667581916 39.067 35.66912530410305 139.7500667581916 44.445</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e25580fe-5e24-47f4-83e6-7295c9341b1f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e25580fe-5e24-47f4-83e6-7295c9341b1f_0">
											<gml:posList>35.66901972591797 139.7499230258704 40.268 35.66903054586408 139.74992802953255 40.268 35.66903054586408 139.74992802953255 39.067 35.66901972591797 139.7499230258704 39.067 35.66901972591797 139.7499230258704 40.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-782a62fe-0c23-4bdc-83a0-a4a0686b58c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-782a62fe-0c23-4bdc-83a0-a4a0686b58c9_0">
											<gml:posList>35.66901699188113 139.7499318876647 40.268 35.66901972591797 139.7499230258704 40.268 35.66901972591797 139.7499230258704 39.067 35.66901699188113 139.7499318876647 39.067 35.66901699188113 139.7499318876647 40.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e3d0cd21-4bee-4477-8d05-6507194cc0dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e3d0cd21-4bee-4477-8d05-6507194cc0dd_0">
											<gml:posList>35.66903054586408 139.74992802953255 40.268 35.66901972591797 139.7499230258704 40.268 35.66901699188113 139.7499318876647 40.268 35.669027811834525 139.74993690237392 40.268 35.66903054586408 139.74992802953255 40.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-916d89e8-1f6c-4cef-969d-fa1e2fb2fd8e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-916d89e8-1f6c-4cef-969d-fa1e2fb2fd8e_0">
											<gml:posList>35.669033403383864 139.74992826957376 40.006 35.66904267266267 139.74993283300734 40.006 35.66904267266267 139.74993283300734 39.067 35.669033403383864 139.74992826957376 39.067 35.669033403383864 139.74992826957376 40.006</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-69244aa3-cc8e-4216-ab57-36f7884daa36">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-69244aa3-cc8e-4216-ab57-36f7884daa36_0">
											<gml:posList>35.66903054586408 139.74992802953255 40.268 35.669027811834525 139.74993690237392 40.268 35.669027811834525 139.74993690237392 39.067 35.66903054586408 139.74992802953255 39.067 35.66903054586408 139.74992802953255 40.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7267ccd3-396a-4009-bc4e-d8615262115b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7267ccd3-396a-4009-bc4e-d8615262115b_0">
											<gml:posList>35.669030138286466 139.74993821443707 40.006 35.669033403383864 139.74992826957376 40.006 35.669033403383864 139.74992826957376 39.067 35.669030138286466 139.74993821443707 39.067 35.669030138286466 139.74993821443707 40.006</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2035ca4d-9064-4345-aa1c-f6f3de627f0e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2035ca4d-9064-4345-aa1c-f6f3de627f0e_0">
											<gml:posList>35.669027811834525 139.74993690237392 40.268 35.66901699188113 139.7499318876647 40.268 35.66901699188113 139.7499318876647 39.067 35.669027811834525 139.74993690237392 39.067 35.669027811834525 139.74993690237392 40.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f624bb2-7d14-4217-b303-e9d15a367a1a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5f624bb2-7d14-4217-b303-e9d15a367a1a_0">
											<gml:posList>35.66904267266267 139.74993283300734 40.006 35.669033403383864 139.74992826957376 40.006 35.669030138286466 139.74993821443707 40.006 35.66903940757254 139.74994278891768 40.006 35.66904267266267 139.74993283300734 40.006</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82869acf-bf0b-450f-a08f-48f57c8490ed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-82869acf-bf0b-450f-a08f-48f57c8490ed_0">
											<gml:posList>35.669045792483274 139.749934376213 40.006 35.669057487295895 139.74994015219383 40.006 35.669057487295895 139.74994015219383 39.067 35.669045792483274 139.749934376213 39.067 35.669045792483274 139.749934376213 40.006</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ca5610d-0f14-4e11-afc7-553bf9b0fdde">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0ca5610d-0f14-4e11-afc7-553bf9b0fdde_0">
											<gml:posList>35.66903940757254 139.74994278891768 40.006 35.669030138286466 139.74993821443707 40.006 35.669030138286466 139.74993821443707 39.067 35.66903940757254 139.74994278891768 39.067 35.66903940757254 139.74994278891768 40.006</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3739ac2e-e447-47b7-b2f0-928d13f5086d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3739ac2e-e447-47b7-b2f0-928d13f5086d_0">
											<gml:posList>35.669057487295895 139.74994015219383 40.006 35.669045792483274 139.749934376213 40.006 35.66904248240854 139.74994445367724 40.006 35.66905418622675 139.74995021860389 40.006 35.669057487295895 139.74994015219383 40.006</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-666e3974-b179-4038-9199-ea7bad4adbc7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-666e3974-b179-4038-9199-ea7bad4adbc7_0">
											<gml:posList>35.669057487295895 139.74994015219383 40.006 35.66905418622675 139.74995021860389 40.006 35.66905418622675 139.74995021860389 39.067 35.669057487295895 139.74994015219383 39.067 35.669057487295895 139.74994015219383 40.006</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa026461-bf33-4b13-ab42-4bdcdbc52ead">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aa026461-bf33-4b13-ab42-4bdcdbc52ead_0">
											<gml:posList>35.669062338341014 139.7499425441476 40.006 35.66907394297769 139.74994826499415 40.006 35.66907394297769 139.74994826499415 39.067 35.669062338341014 139.7499425441476 39.067 35.669062338341014 139.7499425441476 40.006</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-be828752-1649-48dc-86fd-ffa75db60553">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-be828752-1649-48dc-86fd-ffa75db60553_0">
											<gml:posList>35.669014933911406 139.74994080398565 40.563 35.669034527739456 139.74995089076575 40.563 35.669034527739456 139.74995089076575 39.067 35.669014933911406 139.74994080398565 39.067 35.669014933911406 139.74994080398565 40.563</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-faf2aa54-92d1-49b7-94e5-e14a875cfb89">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-faf2aa54-92d1-49b7-94e5-e14a875cfb89_0">
											<gml:posList>35.66905418622675 139.74995021860389 40.006 35.66904248240854 139.74994445367724 40.006 35.66904248240854 139.74994445367724 39.067 35.66905418622675 139.74995021860389 39.067 35.66905418622675 139.74995021860389 40.006</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-449a0e04-0a7c-424b-b13d-b7c3f229894d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-449a0e04-0a7c-424b-b13d-b7c3f229894d_0">
											<gml:posList>35.66905892932878 139.74995293100665 40.006 35.669062338341014 139.7499425441476 40.006 35.669062338341014 139.7499425441476 39.067 35.66905892932878 139.74995293100665 39.067 35.66905892932878 139.74995293100665 40.006</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ab81f0b-eac1-4faf-bb2c-4e8b53c3c593">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3ab81f0b-eac1-4faf-bb2c-4e8b53c3c593_0">
											<gml:posList>35.66907394297769 139.74994826499415 40.006 35.669062338341014 139.7499425441476 40.006 35.66905892932878 139.74995293100665 40.006 35.66907052495123 139.7499586518639 40.006 35.66907394297769 139.74994826499415 40.006</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-49508d9c-5e54-48f7-a071-d89f745e0a5d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-49508d9c-5e54-48f7-a071-d89f745e0a5d_0">
											<gml:posList>35.66907394297769 139.74994826499415 40.006 35.66907052495123 139.7499586518639 40.006 35.66907052495123 139.7499586518639 39.067 35.66907394297769 139.74994826499415 39.067 35.66907394297769 139.74994826499415 40.006</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01d66335-bfce-4e36-a6da-00612977f8e3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01d66335-bfce-4e36-a6da-00612977f8e3_0">
											<gml:posList>35.66907052495123 139.7499586518639 40.006 35.66905892932878 139.74995293100665 40.006 35.66905892932878 139.74995293100665 39.067 35.66907052495123 139.7499586518639 39.067 35.66907052495123 139.7499586518639 40.006</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-272f7ac5-60bb-450f-993c-5847603d1c95">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-272f7ac5-60bb-450f-993c-5847603d1c95_0">
											<gml:posList>35.66900243006217 139.74997725797692 40.563 35.669014933911406 139.74994080398565 40.563 35.669014933911406 139.74994080398565 39.067 35.66900243006217 139.74997725797692 39.067 35.66900243006217 139.74997725797692 40.563</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b50aacd2-1bf3-4357-b8ed-ce724d33a0c2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b50aacd2-1bf3-4357-b8ed-ce724d33a0c2_0">
											<gml:posList>35.66904389569418 139.74995476924266 40.563 35.66906219103189 139.74996411729262 40.563 35.66906219103189 139.74996411729262 39.067 35.66904389569418 139.74995476924266 39.067 35.66904389569418 139.74995476924266 40.563</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d6bab04-7bf1-4baf-9cf0-0a3717b24c80">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d6bab04-7bf1-4baf-9cf0-0a3717b24c80_0">
											<gml:posList>35.669156581038905 139.749974523983 39.067 35.66911203822321 139.74995289787103 39.067 35.66911203822321 139.74995289787103 42.253 35.669156581038905 139.749974523983 42.253 35.669156581038905 139.749974523983 39.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1ea2db6a-b1fb-4020-81ea-a73c126abf96">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1ea2db6a-b1fb-4020-81ea-a73c126abf96_0">
											<gml:posList>35.66900243006217 139.74997725797692 40.563 35.66902202389486 139.74998735581045 40.563 35.669034527739456 139.74995089076575 40.563 35.669014933911406 139.74994080398565 40.563 35.66900243006217 139.74997725797692 40.563</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4a71a3c-6f28-4eb9-8a43-a6257f01139e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4a71a3c-6f28-4eb9-8a43-a6257f01139e_0">
											<gml:posList>35.66911203822321 139.74995289787103 39.067 35.669103223629634 139.74998014668148 39.067 35.669103223629634 139.74998014668148 42.253 35.66911203822321 139.74995289787103 42.253 35.66911203822321 139.74995289787103 39.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e5da11b-6367-42f1-b249-0af156336566">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1e5da11b-6367-42f1-b249-0af156336566_0">
											<gml:posList>35.66907457717756 139.74996596015558 40.325 35.66908369344327 139.74997084409128 40.325 35.66908369344327 139.74997084409128 39.067 35.66907457717756 139.74996596015558 39.067 35.66907457717756 139.74996596015558 40.325</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b0f90f4d-6e7b-4d21-9fb6-20ab2187768d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b0f90f4d-6e7b-4d21-9fb6-20ab2187768d_0">
											<gml:posList>35.669034527739456 139.74995089076575 40.563 35.66902202389486 139.74998735581045 40.563 35.66902202389486 139.74998735581045 39.067 35.669034527739456 139.74995089076575 39.067 35.669034527739456 139.74995089076575 40.563</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d5cc64a7-a2c6-4cca-85c3-f266ee93a1a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d5cc64a7-a2c6-4cca-85c3-f266ee93a1a8_0">
											<gml:posList>35.66903231858035 139.74998880319134 40.563 35.66904389569418 139.74995476924266 40.563 35.66904389569418 139.74995476924266 39.067 35.66903231858035 139.74998880319134 39.067 35.66903231858035 139.74998880319134 40.563</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7479a42d-29f9-4347-8aae-ca89a5fea862">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7479a42d-29f9-4347-8aae-ca89a5fea862_0">
											<gml:posList>35.66903231858035 139.74998880319134 40.563 35.66905062292919 139.74999815123834 40.563 35.66906219103189 139.74996411729262 40.563 35.66904389569418 139.74995476924266 40.563 35.66903231858035 139.74998880319134 40.563</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5eed7c00-834c-455e-8783-0b44a77d54be">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5eed7c00-834c-455e-8783-0b44a77d54be_0">
											<gml:posList>35.66911203822321 139.74995289787103 42.253 35.669103223629634 139.74998014668148 42.253 35.669146856719145 139.7500027347616 42.253 35.669156581038905 139.749974523983 42.253 35.66911203822321 139.74995289787103 42.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab025419-c35f-4da7-88ec-d76ac8b47bf7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ab025419-c35f-4da7-88ec-d76ac8b47bf7_0">
											<gml:posList>35.66906219103189 139.74996411729262 40.563 35.66905062292919 139.74999815123834 40.563 35.66905062292919 139.74999815123834 39.067 35.66906219103189 139.74996411729262 39.067 35.66906219103189 139.74996411729262 40.563</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2459bcb-e107-4861-aeee-59356406429b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a2459bcb-e107-4861-aeee-59356406429b_0">
											<gml:posList>35.66902202389486 139.74998735581045 40.563 35.66900243006217 139.74997725797692 40.563 35.66900243006217 139.74997725797692 39.067 35.66902202389486 139.74998735581045 39.067 35.66902202389486 139.74998735581045 40.563</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4f6ec43c-b5a1-4f8f-bdd0-33cbfadba5d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4f6ec43c-b5a1-4f8f-bdd0-33cbfadba5d1_0">
											<gml:posList>35.66909087649059 139.7499825675631 40.8 35.669096115346846 139.74998527945368 40.8 35.669096115346846 139.74998527945368 39.067 35.66909087649059 139.7499825675631 39.067 35.66909087649059 139.7499825675631 40.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0db498c6-b547-4413-9c20-4a3174cb39a9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0db498c6-b547-4413-9c20-4a3174cb39a9_0">
											<gml:posList>35.66905949047072 139.75000832650633 40.325 35.66907457717756 139.74996596015558 40.325 35.66907457717756 139.74996596015558 39.067 35.66905949047072 139.75000832650633 39.067 35.66905949047072 139.75000832650633 40.325</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d058de9-8607-4f32-b685-3a01db0cd4b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d058de9-8607-4f32-b685-3a01db0cd4b2_0">
											<gml:posList>35.6689991107866 139.74998707033785 40.071 35.66900565696199 139.74999025584785 40.071 35.66900565696199 139.74999025584785 39.067 35.6689991107866 139.74998707033785 39.067 35.6689991107866 139.74998707033785 40.071</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ae1add7b-df40-4845-bd47-b8296c823557">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ae1add7b-df40-4845-bd47-b8296c823557_0">
											<gml:posList>35.669146856719145 139.7500027347616 39.067 35.669156581038905 139.749974523983 39.067 35.669156581038905 139.749974523983 42.253 35.669146856719145 139.7500027347616 42.253 35.669146856719145 139.7500027347616 39.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4fd4934f-dbca-4c73-994c-aae650dd635a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4fd4934f-dbca-4c73-994c-aae650dd635a_0">
											<gml:posList>35.66905949047072 139.75000832650633 40.325 35.669068606727116 139.75001319939986 40.325 35.66908369344327 139.74997084409128 40.325 35.66907457717756 139.74996596015558 40.325 35.66905949047072 139.75000832650633 40.325</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fcc35eea-191a-40c6-8d3e-4f53788b36f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fcc35eea-191a-40c6-8d3e-4f53788b36f8_0">
											<gml:posList>35.6689991107866 139.74998707033785 40.071 35.6689991107866 139.74998707033785 39.067 35.668996439443575 139.74999535766693 39.067 35.668996439443575 139.74999535766693 40.071 35.6689991107866 139.74998707033785 40.071</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-acf736a3-de60-4089-8833-59e85ac994a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-acf736a3-de60-4089-8833-59e85ac994a8_0">
											<gml:posList>35.669103223629634 139.74998014668148 39.067 35.669146856719145 139.7500027347616 39.067 35.669146856719145 139.7500027347616 42.253 35.669103223629634 139.74998014668148 42.253 35.669103223629634 139.74998014668148 39.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9eeda4b4-70f3-4846-84b6-684161db816b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9eeda4b4-70f3-4846-84b6-684161db816b_0">
											<gml:posList>35.66908369344327 139.74997084409128 40.325 35.669068606727116 139.75001319939986 40.325 35.669068606727116 139.75001319939986 39.067 35.66908369344327 139.74997084409128 39.067 35.66908369344327 139.74997084409128 40.325</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dab52370-0ff7-4129-865d-458f6336d3c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dab52370-0ff7-4129-865d-458f6336d3c6_0">
											<gml:posList>35.669084021768974 139.75000242449772 40.8 35.66909087649059 139.7499825675631 40.8 35.66909087649059 139.7499825675631 39.067 35.669084021768974 139.75000242449772 39.067 35.669084021768974 139.75000242449772 40.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-048f420d-7d1f-4c56-82e1-c31ad2596e60">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-048f420d-7d1f-4c56-82e1-c31ad2596e60_0">
											<gml:posList>35.66900565696199 139.74999025584785 40.071 35.6689991107866 139.74998707033785 40.071 35.668996439443575 139.74999535766693 40.071 35.66900297661268 139.7499985542329 40.071 35.66900565696199 139.74999025584785 40.071</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b6a40d6-afa9-4485-a439-feb41c23ba85">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b6a40d6-afa9-4485-a439-feb41c23ba85_0">
											<gml:posList>35.66905062292919 139.74999815123834 40.563 35.66903231858035 139.74998880319134 40.563 35.66903231858035 139.74998880319134 39.067 35.66905062292919 139.74999815123834 39.067 35.66905062292919 139.74999815123834 40.563</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61bd4651-d012-4566-9ccc-3320afb1c60b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-61bd4651-d012-4566-9ccc-3320afb1c60b_0">
											<gml:posList>35.669084021768974 139.75000242449772 40.8 35.6690892696385 139.75000513638003 40.8 35.669096115346846 139.74998527945368 40.8 35.66909087649059 139.7499825675631 40.8 35.669084021768974 139.75000242449772 40.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_570a8bac-9ade-4a3b-8758-843e3322a0ca_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a1d53c6-cfa2-46d2-be93-725d3890da36">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66909155289012 139.7500612702001 5.72 35.66907501203365 139.75011247491582 5.72 35.66906208193643 139.7501061037025 5.72 35.669078803225204 139.75005513077406 5.72 35.66909155289012 139.7500612702001 5.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d4f29d4-510b-4d98-9c1e-4f62872de856">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4d4f29d4-510b-4d98-9c1e-4f62872de856_0">
											<gml:posList>35.66909155289012 139.7500612702001 33.9 35.66909155289012 139.7500612702001 5.72 35.669078803225204 139.75005513077406 5.72 35.669078803225204 139.75005513077406 33.9 35.66909155289012 139.7500612702001 33.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-41bdae40-7df3-443b-ad28-c293d18d7748">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-41bdae40-7df3-443b-ad28-c293d18d7748_0">
											<gml:posList>35.66908901644243 139.75006911555286 33.9 35.66909155289012 139.7500612702001 33.9 35.669078803225204 139.75005513077406 33.9 35.66907624871226 139.75006292091413 33.9 35.66908255142329 139.7500659741332 33.9 35.66908901644243 139.75006911555286 33.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7d51c14d-13be-4b79-853b-73fd674173bd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7d51c14d-13be-4b79-853b-73fd674173bd_0">
											<gml:posList>35.66908255142329 139.7500659741332 33.9 35.66907624871226 139.75006292091413 33.9 35.66907624871226 139.75006292091413 28.088 35.66908255142329 139.7500659741332 28.088 35.66908255142329 139.7500659741332 33.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7119855b-5eca-4d88-afaa-ecdd1fa65f06">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7119855b-5eca-4d88-afaa-ecdd1fa65f06_0">
											<gml:posList>35.66906208193643 139.7501061037025 30.064 35.66906407877695 139.75010001524026 30.064 35.66907624871226 139.75006292091413 28.088 35.66907624871226 139.75006292091413 33.9 35.669078803225204 139.75005513077406 33.9 35.669078803225204 139.75005513077406 5.72 35.66906208193643 139.7501061037025 5.72 35.66906208193643 139.7501061037025 30.064</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d8fc2f3-bdda-4649-945d-299daa44f7ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d8fc2f3-bdda-4649-945d-299daa44f7ca_0">
											<gml:posList>35.66908255142329 139.7500659741332 28.088 35.66907624871226 139.75006292091413 28.088 35.66906407877695 139.75010001524026 30.064 35.66907060675388 139.75010295776718 30.064 35.66908255142329 139.7500659741332 28.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59450c3e-e47c-409e-bd1b-a0e2f4f79964">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-59450c3e-e47c-409e-bd1b-a0e2f4f79964_0">
											<gml:posList>35.66907060675388 139.75010295776718 30.064 35.66908255142329 139.7500659741332 33.9 35.66908255142329 139.7500659741332 28.088 35.66907060675388 139.75010295776718 30.064</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff00d5f4-0a04-4c87-adbb-dc09bca00eaa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ff00d5f4-0a04-4c87-adbb-dc09bca00eaa_0">
											<gml:posList>35.66907060675388 139.75010295776718 30.064 35.669077134738366 139.7501059113406 30.064 35.66908901644243 139.75006911555286 33.9 35.66908255142329 139.7500659741332 33.9 35.66907060675388 139.75010295776718 30.064</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-96bc6dfb-06a6-4db6-93e3-597e136b103d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-96bc6dfb-06a6-4db6-93e3-597e136b103d_0">
											<gml:posList>35.66907501203365 139.75011247491582 30.064 35.66907501203365 139.75011247491582 5.72 35.66909155289012 139.7500612702001 5.72 35.66909155289012 139.7500612702001 33.9 35.66908901644243 139.75006911555286 33.9 35.669077134738366 139.7501059113406 30.064 35.66907501203365 139.75011247491582 30.064</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f762164-29a0-4086-8ad3-93d8ab9e69ba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5f762164-29a0-4086-8ad3-93d8ab9e69ba_0">
											<gml:posList>35.66906407877695 139.75010001524026 30.064 35.66906208193643 139.7501061037025 30.064 35.66907501203365 139.75011247491582 30.064 35.669077134738366 139.7501059113406 30.064 35.66907060675388 139.75010295776718 30.064 35.66906407877695 139.75010001524026 30.064</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0b54778-868f-407b-99ed-79520b4b9a6c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0b54778-868f-407b-99ed-79520b4b9a6c_0">
											<gml:posList>35.66906208193643 139.7501061037025 30.064 35.66906208193643 139.7501061037025 5.72 35.66907501203365 139.75011247491582 5.72 35.66907501203365 139.75011247491582 30.064 35.66906208193643 139.7501061037025 30.064</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-220e128e-1796-4e00-b3d9-1f30d6a3c855">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-220e128e-1796-4e00-b3d9-1f30d6a3c855">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-220e128e-1796-4e00-b3d9-1f30d6a3c855">
											<gml:posList>35.669160912972934 139.7499171571217 5.719 35.669177999746964 139.74992545705487 5.719 35.66913050894944 139.7500724304758 5.719 35.669093720569 139.75005457402247 5.719 35.66909155289012 139.7500612702001 5.719 35.669078803225204 139.75005513077406 5.719 35.66906208193643 139.7501061037025 5.719 35.66897258111933 139.750061990245 5.719 35.66903841116637 139.7498576688962 5.719 35.669128714095095 139.74990151622086 5.719 35.66913357110557 139.74988649953255 5.719 35.669165769985334 139.74990214042828 5.719 35.669160912972934 139.7499171571217 5.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-23108f67-9620-4654-aa16-8bde61f38ce9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-23108f67-9620-4654-aa16-8bde61f38ce9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-23108f67-9620-4654-aa16-8bde61f38ce9">
											<gml:posList>35.66898865392877 139.7500117802169 42.1 35.66899116784143 139.75001045207628 42.1 35.669023601781895 139.74990995433356 42.1 35.66902250897813 139.74990686257004 42.1 35.66898865392877 139.7500117802169 42.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4fe3b89e-ba2d-47e4-a4e7-c511c5037478">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4fe3b89e-ba2d-47e4-a4e7-c511c5037478">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4fe3b89e-ba2d-47e4-a4e7-c511c5037478">
											<gml:posList>35.66907108571705 139.75007866694003 30.6 35.66898109872953 139.75003539351445 30.6 35.66897258111933 139.750061990245 30.6 35.66906208193643 139.7501061037025 30.6 35.66907108571705 139.75007866694003 30.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e8c88ce1-a352-45e7-ba2c-7c59ed9e4fc3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8c88ce1-a352-45e7-ba2c-7c59ed9e4fc3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8c88ce1-a352-45e7-ba2c-7c59ed9e4fc3">
											<gml:posList>35.669078803225204 139.75005513077406 33.907 35.66898865392877 139.7500117802169 33.907 35.66898109872953 139.75003539351445 33.907 35.66907108571705 139.75007866694003 33.907 35.669078803225204 139.75005513077406 33.907</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-74bc64e2-3183-4740-b4ce-41b1a0e09d38">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74bc64e2-3183-4740-b4ce-41b1a0e09d38">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74bc64e2-3183-4740-b4ce-41b1a0e09d38">
											<gml:posList>35.66909155289012 139.7500612702001 42.1 35.66909045108416 139.7500581894873 42.1 35.66899116784143 139.75001045207628 42.1 35.66898865392877 139.7500117802169 42.1 35.66909155289012 139.7500612702001 42.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2dfeab5c-37a2-4ccc-a19c-2cf442ff86e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2dfeab5c-37a2-4ccc-a19c-2cf442ff86e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2dfeab5c-37a2-4ccc-a19c-2cf442ff86e7">
											<gml:posList>35.6690926277766 139.75005149330036 39.067 35.66912940714377 139.7500693497614 39.067 35.66915958361931 139.7499759789456 39.067 35.669023601781895 139.74990995433356 39.067 35.66899116784143 139.75001045207628 39.067 35.66909045108416 139.7500581894873 39.067 35.6690926277766 139.75005149330036 39.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a4ac9212-a078-4bbf-a9cd-0bf9759666aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4ac9212-a078-4bbf-a9cd-0bf9759666aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4ac9212-a078-4bbf-a9cd-0bf9759666aa">
											<gml:posList>35.669093720569 139.75005457402247 42.1 35.6690926277766 139.75005149330036 42.1 35.66909045108416 139.7500581894873 42.1 35.66909155289012 139.7500612702001 42.1 35.669093720569 139.75005457402247 42.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-38979b09-310d-46bb-81f8-7c02f42959ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38979b09-310d-46bb-81f8-7c02f42959ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38979b09-310d-46bb-81f8-7c02f42959ae">
											<gml:posList>35.66902250897813 139.74990686257004 42.1 35.669023601781895 139.74990995433356 42.1 35.66915958361931 139.7499759789456 42.1 35.66916210653758 139.74997463974555 42.1 35.66902250897813 139.74990686257004 42.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-692efe52-e8a0-4236-b014-b48456273ec5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-692efe52-e8a0-4236-b014-b48456273ec5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-692efe52-e8a0-4236-b014-b48456273ec5">
											<gml:posList>35.6691705613227 139.74994846275973 34.2 35.66903096377174 139.74988071876086 34.2 35.66902250897813 139.74990686257004 34.2 35.66916210653758 139.74997463974555 34.2 35.6691705613227 139.74994846275973 34.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a3efc097-55af-473a-ac16-6a18596cd64e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a3efc097-55af-473a-ac16-6a18596cd64e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a3efc097-55af-473a-ac16-6a18596cd64e">
											<gml:posList>35.669177999746964 139.74992545705487 30.4 35.66903841116637 139.7498576688962 30.4 35.66903096377174 139.74988071876086 30.4 35.6691705613227 139.74994846275973 30.4 35.669177999746964 139.74992545705487 30.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5b2c3234-6a63-4c76-8bad-586130f78fc5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b2c3234-6a63-4c76-8bad-586130f78fc5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b2c3234-6a63-4c76-8bad-586130f78fc5">
											<gml:posList>35.669093720569 139.75005457402247 42.1 35.66913050894944 139.7500724304758 42.1 35.66912940714377 139.7500693497614 42.1 35.6690926277766 139.75005149330036 42.1 35.669093720569 139.75005457402247 42.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c14efc60-2851-453f-bd7a-fe0e985f16b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c14efc60-2851-453f-bd7a-fe0e985f16b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c14efc60-2851-453f-bd7a-fe0e985f16b1">
											<gml:posList>35.66916210653758 139.74997463974555 42.1 35.66915958361931 139.7499759789456 42.1 35.66912940714377 139.7500693497614 42.1 35.66913050894944 139.7500724304758 42.1 35.66916210653758 139.74997463974555 42.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2bfccfdf-82c2-4178-aea9-6839cdfabca2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2bfccfdf-82c2-4178-aea9-6839cdfabca2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2bfccfdf-82c2-4178-aea9-6839cdfabca2">
											<gml:posList>35.669165769985334 139.74990214042828 9.789 35.66913357110557 139.74988649953255 9.789 35.669128714095095 139.74990151622086 9.789 35.669160912972934 139.7499171571217 9.789 35.669165769985334 139.74990214042828 9.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cbb00634-ab59-4f65-87a8-d25c6c28a59e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cbb00634-ab59-4f65-87a8-d25c6c28a59e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cbb00634-ab59-4f65-87a8-d25c6c28a59e">
											<gml:posList>35.66898865392877 139.7500117802169 33.907 35.66898865392877 139.7500117802169 42.1 35.66902250897813 139.74990686257004 42.1 35.66902250897813 139.74990686257004 34.2 35.66903096377174 139.74988071876086 34.2 35.66903096377174 139.74988071876086 30.4 35.66903841116637 139.7498576688962 30.4 35.66903841116637 139.7498576688962 5.719 35.66897258111933 139.750061990245 5.719 35.66897258111933 139.750061990245 30.6 35.66898109872953 139.75003539351445 30.6 35.66898109872953 139.75003539351445 33.907 35.66898865392877 139.7500117802169 33.907</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8c391915-b6d6-47e6-b580-43a390cccac1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c391915-b6d6-47e6-b580-43a390cccac1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c391915-b6d6-47e6-b580-43a390cccac1">
											<gml:posList>35.66899116784143 139.75001045207628 42.1 35.66899116784143 139.75001045207628 39.067 35.669023601781895 139.74990995433356 39.067 35.669023601781895 139.74990995433356 42.1 35.66899116784143 139.75001045207628 42.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b82caa5-37f7-4066-9a1e-899700ad70ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b82caa5-37f7-4066-9a1e-899700ad70ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b82caa5-37f7-4066-9a1e-899700ad70ee">
											<gml:posList>35.66897258111933 139.750061990245 5.719 35.66906208193643 139.7501061037025 5.719 35.66906208193643 139.7501061037025 30.6 35.66897258111933 139.750061990245 30.6 35.66897258111933 139.750061990245 5.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c4fff939-25b0-4cfe-86ba-d51f04ec2f9e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4fff939-25b0-4cfe-86ba-d51f04ec2f9e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4fff939-25b0-4cfe-86ba-d51f04ec2f9e">
											<gml:posList>35.66907108571705 139.75007866694003 30.6 35.66907108571705 139.75007866694003 33.907 35.66898109872953 139.75003539351445 33.907 35.66898109872953 139.75003539351445 30.6 35.66907108571705 139.75007866694003 30.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dd46b1b3-a643-462f-b977-907e1401cafb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd46b1b3-a643-462f-b977-907e1401cafb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd46b1b3-a643-462f-b977-907e1401cafb">
											<gml:posList>35.669078803225204 139.75005513077406 33.907 35.669078803225204 139.75005513077406 5.719 35.66909155289012 139.7500612702001 5.719 35.66909155289012 139.7500612702001 42.1 35.66898865392877 139.7500117802169 42.1 35.66898865392877 139.7500117802169 33.907 35.669078803225204 139.75005513077406 33.907</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5a4c3adf-6d60-4f1d-829b-a9554c483e91">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a4c3adf-6d60-4f1d-829b-a9554c483e91">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a4c3adf-6d60-4f1d-829b-a9554c483e91">
											<gml:posList>35.66909045108416 139.7500581894873 42.1 35.66909045108416 139.7500581894873 39.067 35.66899116784143 139.75001045207628 39.067 35.66899116784143 139.75001045207628 42.1 35.66909045108416 139.7500581894873 42.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-25b5a9ae-bec3-424f-bbc0-6d921078fa0f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25b5a9ae-bec3-424f-bbc0-6d921078fa0f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25b5a9ae-bec3-424f-bbc0-6d921078fa0f">
											<gml:posList>35.669078803225204 139.75005513077406 5.719 35.669078803225204 139.75005513077406 33.907 35.66907108571705 139.75007866694003 33.907 35.66907108571705 139.75007866694003 30.6 35.66906208193643 139.7501061037025 30.6 35.66906208193643 139.7501061037025 5.719 35.669078803225204 139.75005513077406 5.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-476e53e4-c3a1-4d3c-a4f6-2af4b6fc4ef1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-476e53e4-c3a1-4d3c-a4f6-2af4b6fc4ef1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-476e53e4-c3a1-4d3c-a4f6-2af4b6fc4ef1">
											<gml:posList>35.6690926277766 139.75005149330036 42.1 35.6690926277766 139.75005149330036 39.067 35.66909045108416 139.7500581894873 39.067 35.66909045108416 139.7500581894873 42.1 35.6690926277766 139.75005149330036 42.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5d9e257b-0b2f-4185-b9cd-66aead105405">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d9e257b-0b2f-4185-b9cd-66aead105405">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d9e257b-0b2f-4185-b9cd-66aead105405">
											<gml:posList>35.669023601781895 139.74990995433356 42.1 35.669023601781895 139.74990995433356 39.067 35.66915958361931 139.7499759789456 39.067 35.66915958361931 139.7499759789456 42.1 35.669023601781895 139.74990995433356 42.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c34a9c47-c508-4cd4-bf0d-d34127d0abb0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c34a9c47-c508-4cd4-bf0d-d34127d0abb0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c34a9c47-c508-4cd4-bf0d-d34127d0abb0">
											<gml:posList>35.66902250897813 139.74990686257004 34.2 35.66902250897813 139.74990686257004 42.1 35.66916210653758 139.74997463974555 42.1 35.66916210653758 139.74997463974555 34.2 35.66902250897813 139.74990686257004 34.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-573c3c35-1bff-4e58-b11b-3aefa1dd27e9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-573c3c35-1bff-4e58-b11b-3aefa1dd27e9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-573c3c35-1bff-4e58-b11b-3aefa1dd27e9">
											<gml:posList>35.66909155289012 139.7500612702001 5.719 35.669093720569 139.75005457402247 5.719 35.669093720569 139.75005457402247 42.1 35.66909155289012 139.7500612702001 42.1 35.66909155289012 139.7500612702001 5.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0ce977d3-7b1b-413d-8353-12c80eaed44f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ce977d3-7b1b-413d-8353-12c80eaed44f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ce977d3-7b1b-413d-8353-12c80eaed44f">
											<gml:posList>35.66903096377174 139.74988071876086 30.4 35.66903096377174 139.74988071876086 34.2 35.6691705613227 139.74994846275973 34.2 35.6691705613227 139.74994846275973 30.4 35.66903096377174 139.74988071876086 30.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1096dab4-76b1-486d-b8d2-37cf7f153e71">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1096dab4-76b1-486d-b8d2-37cf7f153e71">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1096dab4-76b1-486d-b8d2-37cf7f153e71">
											<gml:posList>35.669177999746964 139.74992545705487 30.4 35.669177999746964 139.74992545705487 5.719 35.669160912972934 139.7499171571217 5.719 35.669160912972934 139.7499171571217 9.789 35.669128714095095 139.74990151622086 9.789 35.669128714095095 139.74990151622086 5.719 35.66903841116637 139.7498576688962 5.719 35.66903841116637 139.7498576688962 30.4 35.669177999746964 139.74992545705487 30.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8fc067c2-9129-4d06-8ece-68a14b95cadc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8fc067c2-9129-4d06-8ece-68a14b95cadc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8fc067c2-9129-4d06-8ece-68a14b95cadc">
											<gml:posList>35.66912940714377 139.7500693497614 42.1 35.66912940714377 139.7500693497614 39.067 35.6690926277766 139.75005149330036 39.067 35.6690926277766 139.75005149330036 42.1 35.66912940714377 139.7500693497614 42.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8b33569a-4718-46af-a72e-096952c7965f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b33569a-4718-46af-a72e-096952c7965f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b33569a-4718-46af-a72e-096952c7965f">
											<gml:posList>35.669093720569 139.75005457402247 5.719 35.66913050894944 139.7500724304758 5.719 35.66913050894944 139.7500724304758 42.1 35.669093720569 139.75005457402247 42.1 35.669093720569 139.75005457402247 5.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2f889852-d376-4808-8c45-78430b060ddd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f889852-d376-4808-8c45-78430b060ddd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f889852-d376-4808-8c45-78430b060ddd">
											<gml:posList>35.66913357110557 139.74988649953255 5.719 35.669128714095095 139.74990151622086 5.719 35.669128714095095 139.74990151622086 9.789 35.66913357110557 139.74988649953255 9.789 35.66913357110557 139.74988649953255 5.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9cf5fc37-c250-46e0-951b-19ff8ebe9732">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9cf5fc37-c250-46e0-951b-19ff8ebe9732">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9cf5fc37-c250-46e0-951b-19ff8ebe9732">
											<gml:posList>35.66915958361931 139.7499759789456 42.1 35.66915958361931 139.7499759789456 39.067 35.66912940714377 139.7500693497614 39.067 35.66912940714377 139.7500693497614 42.1 35.66915958361931 139.7499759789456 42.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6774349c-989f-41ed-b464-a408a5ae67ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6774349c-989f-41ed-b464-a408a5ae67ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6774349c-989f-41ed-b464-a408a5ae67ce">
											<gml:posList>35.669165769985334 139.74990214042828 5.719 35.66913357110557 139.74988649953255 5.719 35.66913357110557 139.74988649953255 9.789 35.669165769985334 139.74990214042828 9.789 35.669165769985334 139.74990214042828 5.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-948be7f6-4e8d-4437-8be4-68b4da297dc8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-948be7f6-4e8d-4437-8be4-68b4da297dc8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-948be7f6-4e8d-4437-8be4-68b4da297dc8">
											<gml:posList>35.66913050894944 139.7500724304758 42.1 35.66913050894944 139.7500724304758 5.719 35.669177999746964 139.74992545705487 5.719 35.669177999746964 139.74992545705487 30.4 35.6691705613227 139.74994846275973 30.4 35.6691705613227 139.74994846275973 34.2 35.66916210653758 139.74997463974555 34.2 35.66916210653758 139.74997463974555 42.1 35.66913050894944 139.7500724304758 42.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-de8b3113-fb81-4a2d-bc52-54d2ded7ef1f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de8b3113-fb81-4a2d-bc52-54d2ded7ef1f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de8b3113-fb81-4a2d-bc52-54d2ded7ef1f">
											<gml:posList>35.669160912972934 139.7499171571217 5.719 35.669165769985334 139.74990214042828 5.719 35.669165769985334 139.74990214042828 9.789 35.669160912972934 139.7499171571217 9.789 35.669160912972934 139.7499171571217 5.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1997</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">274.93578</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>