<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_573b38dd-30f4-4472-bf32-aca08453ea88">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">4.1</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66977257222251 139.74467667863212 0 35.669766336353675 139.74466665560016 0 35.66974792769076 139.7446753361569 0 35.66973629634415 139.74469488969496 0 35.66974246903331 139.7447048023335 0 35.669761112339806 139.74469650814086 0 35.66977257222251 139.74467667863212 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66977257222251 139.74467667863212 9.568 35.669761112339806 139.74469650814086 9.568 35.66974246903331 139.7447048023335 9.568 35.66973629634415 139.74469488969496 9.568 35.66974792769076 139.7446753361569 9.568 35.669766336353675 139.74466665560016 9.568 35.66977257222251 139.74467667863212 9.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66977257222251 139.74467667863212 9.568 35.669766336353675 139.74466665560016 9.568 35.669766336353675 139.74466665560016 13.68 35.66977257222251 139.74467667863212 13.68 35.66977257222251 139.74467667863212 9.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669766336353675 139.74466665560016 9.568 35.66974792769076 139.7446753361569 9.568 35.66974792769076 139.7446753361569 13.68 35.669766336353675 139.74466665560016 13.68 35.669766336353675 139.74466665560016 9.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66974792769076 139.7446753361569 9.568 35.66973629634415 139.74469488969496 9.568 35.66973629634415 139.74469488969496 13.68 35.66974792769076 139.7446753361569 13.68 35.66974792769076 139.7446753361569 9.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66973629634415 139.74469488969496 9.568 35.66974246903331 139.7447048023335 9.568 35.66974246903331 139.7447048023335 13.68 35.66973629634415 139.74469488969496 13.68 35.66973629634415 139.74469488969496 9.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66974246903331 139.7447048023335 9.568 35.669761112339806 139.74469650814086 9.568 35.669761112339806 139.74469650814086 13.68 35.66974246903331 139.7447048023335 13.68 35.66974246903331 139.7447048023335 9.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669761112339806 139.74469650814086 9.568 35.66977257222251 139.74467667863212 9.568 35.66977257222251 139.74467667863212 13.68 35.669761112339806 139.74469650814086 13.68 35.669761112339806 139.74469650814086 9.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66977257222251 139.74467667863212 13.68 35.669766336353675 139.74466665560016 13.68 35.66974792769076 139.7446753361569 13.68 35.66973629634415 139.74469488969496 13.68 35.66974246903331 139.7447048023335 13.68 35.669761112339806 139.74469650814086 13.68 35.66977257222251 139.74467667863212 13.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-c71521cf-5352-4659-b4d5-d646ef12dd3f"/>
							<gml:surfaceMember xlink:href="#poly-51b9a21f-2188-457c-b22b-4d2c039c8a00"/>
							<gml:surfaceMember xlink:href="#poly-f960364d-2e91-4631-8060-5d6405c113c6"/>
							<gml:surfaceMember xlink:href="#poly-04a7fc56-dbbe-41d5-b8e9-19f241e4c85f"/>
							<gml:surfaceMember xlink:href="#poly-bfa69d3e-72b1-4682-bcd3-e53e1ec47ce9"/>
							<gml:surfaceMember xlink:href="#poly-388e50df-c626-458a-a1e8-5cd8d90c5c6e"/>
							<gml:surfaceMember xlink:href="#poly-50a78d5f-a6fd-497e-9b3d-22f0fa9218eb"/>
							<gml:surfaceMember xlink:href="#poly-07cea828-3596-4732-a4e3-7de67cff48d5"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-c71521cf-5352-4659-b4d5-d646ef12dd3f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c71521cf-5352-4659-b4d5-d646ef12dd3f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c71521cf-5352-4659-b4d5-d646ef12dd3f">
											<gml:posList>35.66977257222249 139.74467667863212 9.568 35.66976111233979 139.74469650814083 9.568 35.66974246903328 139.7447048023335 9.568 35.66973629634414 139.74469488969496 9.568 35.66974792769073 139.7446753361569 9.568 35.66976633635365 139.74466665560016 9.568 35.66977257222249 139.74467667863212 9.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-51b9a21f-2188-457c-b22b-4d2c039c8a00">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-51b9a21f-2188-457c-b22b-4d2c039c8a00">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-51b9a21f-2188-457c-b22b-4d2c039c8a00">
											<gml:posList>35.66974246903328 139.7447048023335 14.048 35.66976111233979 139.74469650814083 14.048 35.66977257222249 139.74467667863212 14.048 35.66976633635365 139.74466665560016 14.048 35.66974792769073 139.7446753361569 14.048 35.66973629634414 139.74469488969496 14.048 35.66974246903328 139.7447048023335 14.048</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f960364d-2e91-4631-8060-5d6405c113c6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f960364d-2e91-4631-8060-5d6405c113c6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f960364d-2e91-4631-8060-5d6405c113c6">
											<gml:posList>35.66976633635365 139.74466665560016 9.568 35.66974792769073 139.7446753361569 9.568 35.66974792769073 139.7446753361569 14.048 35.66976633635365 139.74466665560016 14.048 35.66976633635365 139.74466665560016 9.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-04a7fc56-dbbe-41d5-b8e9-19f241e4c85f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04a7fc56-dbbe-41d5-b8e9-19f241e4c85f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04a7fc56-dbbe-41d5-b8e9-19f241e4c85f">
											<gml:posList>35.66977257222249 139.74467667863212 9.568 35.66976633635365 139.74466665560016 9.568 35.66976633635365 139.74466665560016 14.048 35.66977257222249 139.74467667863212 14.048 35.66977257222249 139.74467667863212 9.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bfa69d3e-72b1-4682-bcd3-e53e1ec47ce9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bfa69d3e-72b1-4682-bcd3-e53e1ec47ce9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bfa69d3e-72b1-4682-bcd3-e53e1ec47ce9">
											<gml:posList>35.66974792769073 139.7446753361569 9.568 35.66973629634414 139.74469488969496 9.568 35.66973629634414 139.74469488969496 14.048 35.66974792769073 139.7446753361569 14.048 35.66974792769073 139.7446753361569 9.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-388e50df-c626-458a-a1e8-5cd8d90c5c6e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-388e50df-c626-458a-a1e8-5cd8d90c5c6e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-388e50df-c626-458a-a1e8-5cd8d90c5c6e">
											<gml:posList>35.66976111233979 139.74469650814083 9.568 35.66977257222249 139.74467667863212 9.568 35.66977257222249 139.74467667863212 14.048 35.66976111233979 139.74469650814083 14.048 35.66976111233979 139.74469650814083 9.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-50a78d5f-a6fd-497e-9b3d-22f0fa9218eb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50a78d5f-a6fd-497e-9b3d-22f0fa9218eb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50a78d5f-a6fd-497e-9b3d-22f0fa9218eb">
											<gml:posList>35.66973629634414 139.74469488969496 9.568 35.66974246903328 139.7447048023335 9.568 35.66974246903328 139.7447048023335 14.048 35.66973629634414 139.74469488969496 14.048 35.66973629634414 139.74469488969496 9.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-07cea828-3596-4732-a4e3-7de67cff48d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-07cea828-3596-4732-a4e3-7de67cff48d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-07cea828-3596-4732-a4e3-7de67cff48d5">
											<gml:posList>35.66974246903328 139.7447048023335 9.568 35.66976111233979 139.74469650814083 9.568 35.66976111233979 139.74469650814083 14.048 35.66974246903328 139.7447048023335 14.048 35.66974246903328 139.7447048023335 9.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8159</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>