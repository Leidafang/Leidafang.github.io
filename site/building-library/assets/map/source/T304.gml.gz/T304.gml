<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_57e277dc-f021-444a-86d1-3b84dc42b931">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">22.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>7</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.6707083262652 139.74111566286862 0 35.67064770826853 139.74105597212693 0 35.67061455258239 139.74107534129723 0 35.670598344891346 139.74109756298915 0 35.67059796889568 139.74110093253995 0 35.6706129341252 139.74111588304964 0 35.670592884079255 139.7411466147936 0 35.67060597570783 139.74117498870785 0 35.67061454407024 139.7411819380229 0 35.67063023242771 139.74118777452725 0 35.670651413407604 139.74118609323983 0 35.67066492824282 139.74117856622405 0 35.6707083262652 139.74111566286862 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6707083262652 139.74111566286862 9.379 35.67066492824282 139.74117856622405 9.379 35.670651413407604 139.74118609323983 9.379 35.67063023242771 139.74118777452725 9.379 35.67061454407024 139.7411819380229 9.379 35.67060597570783 139.74117498870785 9.379 35.670592884079255 139.7411466147936 9.379 35.6706129341252 139.74111588304964 9.379 35.67059796889568 139.74110093253995 9.379 35.670598344891346 139.74109756298915 9.379 35.67061455258239 139.74107534129723 9.379 35.67064770826853 139.74105597212693 9.379 35.6707083262652 139.74111566286862 9.379</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6707083262652 139.74111566286862 9.379 35.67064770826853 139.74105597212693 9.379 35.67064770826853 139.74105597212693 32.23 35.6707083262652 139.74111566286862 32.23 35.6707083262652 139.74111566286862 9.379</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67064770826853 139.74105597212693 9.379 35.67061455258239 139.74107534129723 9.379 35.67061455258239 139.74107534129723 32.23 35.67064770826853 139.74105597212693 32.23 35.67064770826853 139.74105597212693 9.379</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67061455258239 139.74107534129723 9.379 35.670598344891346 139.74109756298915 9.379 35.670598344891346 139.74109756298915 32.23 35.67061455258239 139.74107534129723 32.23 35.67061455258239 139.74107534129723 9.379</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670598344891346 139.74109756298915 9.379 35.67059796889568 139.74110093253995 9.379 35.67059796889568 139.74110093253995 32.23 35.670598344891346 139.74109756298915 32.23 35.670598344891346 139.74109756298915 9.379</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67059796889568 139.74110093253995 9.379 35.6706129341252 139.74111588304964 9.379 35.6706129341252 139.74111588304964 32.23 35.67059796889568 139.74110093253995 32.23 35.67059796889568 139.74110093253995 9.379</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6706129341252 139.74111588304964 9.379 35.670592884079255 139.7411466147936 9.379 35.670592884079255 139.7411466147936 32.23 35.6706129341252 139.74111588304964 32.23 35.6706129341252 139.74111588304964 9.379</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670592884079255 139.7411466147936 9.379 35.67060597570783 139.74117498870785 9.379 35.67060597570783 139.74117498870785 32.23 35.670592884079255 139.7411466147936 32.23 35.670592884079255 139.7411466147936 9.379</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67060597570783 139.74117498870785 9.379 35.67061454407024 139.7411819380229 9.379 35.67061454407024 139.7411819380229 32.23 35.67060597570783 139.74117498870785 32.23 35.67060597570783 139.74117498870785 9.379</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67061454407024 139.7411819380229 9.379 35.67063023242771 139.74118777452725 9.379 35.67063023242771 139.74118777452725 32.23 35.67061454407024 139.7411819380229 32.23 35.67061454407024 139.7411819380229 9.379</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67063023242771 139.74118777452725 9.379 35.670651413407604 139.74118609323983 9.379 35.670651413407604 139.74118609323983 32.23 35.67063023242771 139.74118777452725 32.23 35.67063023242771 139.74118777452725 9.379</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670651413407604 139.74118609323983 9.379 35.67066492824282 139.74117856622405 9.379 35.67066492824282 139.74117856622405 32.23 35.670651413407604 139.74118609323983 32.23 35.670651413407604 139.74118609323983 9.379</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67066492824282 139.74117856622405 9.379 35.6707083262652 139.74111566286862 9.379 35.6707083262652 139.74111566286862 32.23 35.67066492824282 139.74117856622405 32.23 35.67066492824282 139.74117856622405 9.379</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6707083262652 139.74111566286862 32.23 35.67064770826853 139.74105597212693 32.23 35.67061455258239 139.74107534129723 32.23 35.670598344891346 139.74109756298915 32.23 35.67059796889568 139.74110093253995 32.23 35.6706129341252 139.74111588304964 32.23 35.670592884079255 139.7411466147936 32.23 35.67060597570783 139.74117498870785 32.23 35.67061454407024 139.7411819380229 32.23 35.67063023242771 139.74118777452725 32.23 35.670651413407604 139.74118609323983 32.23 35.67066492824282 139.74117856622405 32.23 35.6707083262652 139.74111566286862 32.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-e9de7072-00f7-4d78-ad21-dd3925f10791"/>
							<gml:surfaceMember xlink:href="#poly-f643f0e3-af18-4768-93c1-447cb23f7285"/>
							<gml:surfaceMember xlink:href="#poly-08e6476a-f536-4e51-bfa8-c12bafbb9a58"/>
							<gml:surfaceMember xlink:href="#poly-a5395df9-a7b5-4368-b82b-f39d0336637a"/>
							<gml:surfaceMember xlink:href="#poly-31df0e27-5be6-44dc-a840-51784f64f2be"/>
							<gml:surfaceMember xlink:href="#poly-46348854-77cd-49a4-abfe-0a525a521d63"/>
							<gml:surfaceMember xlink:href="#poly-17ef6bcc-859a-4b42-aa75-8aca5f42d261"/>
							<gml:surfaceMember xlink:href="#poly-00265a49-8c10-44bf-bc37-c076cbe81659"/>
							<gml:surfaceMember xlink:href="#poly-754699d8-d88f-48b5-8f03-90a886cf7d4d"/>
							<gml:surfaceMember xlink:href="#poly-a0c8a2bd-730d-4d24-9aba-6d36126c0546"/>
							<gml:surfaceMember xlink:href="#poly-2ea7a9af-e7b3-4934-9c3b-439529306dc3"/>
							<gml:surfaceMember xlink:href="#poly-7662bfea-279d-413b-9fd5-19cc46902de3"/>
							<gml:surfaceMember xlink:href="#poly-1dd5e5bb-b8bd-46d5-bd58-19fa4f473df3"/>
							<gml:surfaceMember xlink:href="#poly-3bcff63c-f9fa-447c-86c7-165e590649e3"/>
							<gml:surfaceMember xlink:href="#poly-cbe741ec-89f2-48d1-a424-a9da886ef6c2"/>
							<gml:surfaceMember xlink:href="#poly-a2eefe43-a4cc-42bc-bd17-9a64979b19f4"/>
							<gml:surfaceMember xlink:href="#poly-ea8487eb-4d31-4676-9c6a-e6f888053443"/>
							<gml:surfaceMember xlink:href="#poly-d8770a64-0ee1-4fed-910b-f99088384302"/>
							<gml:surfaceMember xlink:href="#poly-765d1f6e-8437-41a6-a260-e26f0acb209c"/>
							<gml:surfaceMember xlink:href="#poly-55ec71e4-8e2d-4d48-a522-726b2ee2d394"/>
							<gml:surfaceMember xlink:href="#poly-a2a398c9-5a44-4199-884f-b3de645b0ee8"/>
							<gml:surfaceMember xlink:href="#poly-2b1d9d18-fdfe-4f9a-9f23-4f58274dadc4"/>
							<gml:surfaceMember xlink:href="#poly-c6912f77-1511-406d-9de8-b9ca2d935845"/>
							<gml:surfaceMember xlink:href="#poly-d9a3d269-4992-478f-a376-413327469acd"/>
							<gml:surfaceMember xlink:href="#poly-4de17a5a-20e8-4e08-972c-8989fb050092"/>
							<gml:surfaceMember xlink:href="#poly-1a6cc064-811b-4834-832a-6b42f8ffc569"/>
							<gml:surfaceMember xlink:href="#poly-3e8e3296-5fbd-404e-b386-cbc8d8885431"/>
							<gml:surfaceMember xlink:href="#poly-74c5c7aa-7ad7-408f-bb85-0be568f1a0be"/>
							<gml:surfaceMember xlink:href="#poly-b943c4b8-ba31-49d7-9e06-69e85ca4319d"/>
							<gml:surfaceMember xlink:href="#poly-9c4c0b78-3a6f-4616-a809-889767c345e0"/>
							<gml:surfaceMember xlink:href="#poly-070bfbc7-0634-4514-8a9f-ec40ef645d07"/>
							<gml:surfaceMember xlink:href="#poly-7efa94d1-66b8-48c9-afe3-b52c1c26841e"/>
							<gml:surfaceMember xlink:href="#poly-4aa6e3dc-96ef-473f-b89b-ba015118ef44"/>
							<gml:surfaceMember xlink:href="#poly-1268874d-e5cc-4dcb-9e98-3737d51f3c59"/>
							<gml:surfaceMember xlink:href="#poly-7d1ca33e-9ba4-40b5-92ba-8196da5c2057"/>
							<gml:surfaceMember xlink:href="#poly-c8d8adb5-8c7c-4f9f-8194-eab134d89036"/>
							<gml:surfaceMember xlink:href="#poly-228e1672-4133-4d16-bcf0-8d31f9262ee9"/>
							<gml:surfaceMember xlink:href="#poly-f5da4cf7-6179-4e34-9b7b-a72b1b50875d"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_57e277dc-f021-444a-86d1-3b84dc42b931_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eba37558-8940-49ac-8dab-2eba51f482b6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67065379315536 139.74112737943508 32.408 35.670666569931576 139.74110948078336 32.408 35.670682997413046 139.74112708073795 32.408 35.67067021162899 139.74114499044725 32.408 35.67065379315536 139.74112737943508 32.408</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b6faa29-debb-4e17-826f-e57b73b545fc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b6faa29-debb-4e17-826f-e57b73b545fc_0">
											<gml:posList>35.670666569931576 139.74110948078336 32.408 35.670666569931576 139.74110948078336 34.943 35.670682997413046 139.74112708073795 34.943 35.670682997413046 139.74112708073795 32.408 35.670666569931576 139.74110948078336 32.408</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9950683e-6347-432a-a8d0-331f903ea532">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9950683e-6347-432a-a8d0-331f903ea532_0">
											<gml:posList>35.67065379315536 139.74112737943508 32.408 35.67065379315536 139.74112737943508 34.943 35.670666569931576 139.74110948078336 34.943 35.670666569931576 139.74110948078336 32.408 35.67065379315536 139.74112737943508 32.408</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9212b79-ddad-4008-a6e4-ef99a2daf135">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b9212b79-ddad-4008-a6e4-ef99a2daf135_0">
											<gml:posList>35.670682997413046 139.74112708073795 34.943 35.670666569931576 139.74110948078336 34.943 35.67065379315536 139.74112737943508 34.943 35.67067021162899 139.74114499044725 34.943 35.670682997413046 139.74112708073795 34.943</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-98395af0-e3a4-4fd8-83b6-85ae72f6aa7f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-98395af0-e3a4-4fd8-83b6-85ae72f6aa7f_0">
											<gml:posList>35.670682997413046 139.74112708073795 32.408 35.670682997413046 139.74112708073795 34.943 35.67067021162899 139.74114499044725 34.943 35.67067021162899 139.74114499044725 32.408 35.670682997413046 139.74112708073795 32.408</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33ca3be4-6a58-4cf9-8e1a-b5c610d7445a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-33ca3be4-6a58-4cf9-8e1a-b5c610d7445a_0">
											<gml:posList>35.67067021162899 139.74114499044725 32.408 35.67067021162899 139.74114499044725 34.943 35.67065379315536 139.74112737943508 34.943 35.67065379315536 139.74112737943508 32.408 35.67067021162899 139.74114499044725 32.408</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_57e277dc-f021-444a-86d1-3b84dc42b931_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e49d76b3-89b7-4cc9-a61c-11d6236e6f57">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e49d76b3-89b7-4cc9-a61c-11d6236e6f57_0">
											<gml:posList>35.67059774601474 139.7411041472666 32.557 35.67058510645418 139.7411128994198 32.558 35.67058512448163 139.74111289939904 32.178 35.670597764042185 139.74110414724586 32.177 35.67059774601474 139.7411041472666 32.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7da50f04-6b1d-4b61-b28b-f6a9f4dfe331">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7da50f04-6b1d-4b61-b28b-f6a9f4dfe331_0">
											<gml:posList>35.67059796889567 139.74110093253995 32.557 35.67059796889567 139.74110093253995 9.379 35.67058243746171 139.74111168739807 9.379 35.67058243746171 139.74111168739807 32.557 35.67059796889567 139.74110093253995 32.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e37b618b-a88b-4940-aad7-d740db5d2808">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e37b618b-a88b-4940-aad7-d740db5d2808_0">
											<gml:posList>35.67059796889567 139.74110093253995 32.557 35.67058243746171 139.74111168739807 32.557 35.67058510645418 139.7411128994198 32.558 35.67059774601474 139.7411041472666 32.557 35.67059796889567 139.74110093253995 32.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24f9fa9b-b013-4376-975c-bf1a99340c33">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-24f9fa9b-b013-4376-975c-bf1a99340c33_0">
											<gml:posList>35.670612934125195 139.74111588304962 32.573 35.670612934125195 139.74111588304962 9.379 35.67059796889567 139.74110093253995 9.379 35.67059796889567 139.74110093253995 32.557 35.670612934125195 139.74111588304962 32.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-580a86b3-2c20-4e88-b0e4-29446236dc01">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-580a86b3-2c20-4e88-b0e4-29446236dc01_0">
											<gml:posList>35.670612934125195 139.74111588304962 32.573 35.67059796889567 139.74110093253995 32.557 35.67059774601474 139.7411041472666 32.557 35.67060989680525 139.74111628420954 32.572 35.670612934125195 139.74111588304962 32.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d158187a-7756-4fe2-90b4-75bdb312cdb5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d158187a-7756-4fe2-90b4-75bdb312cdb5_0">
											<gml:posList>35.67060989680525 139.74111628420954 32.572 35.67059774601474 139.7411041472666 32.557 35.670597764042185 139.74110414724586 32.177 35.6706099148327 139.74111628418882 32.192 35.67060989680525 139.74111628420954 32.572</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6afdf7fb-fee0-4e68-9576-d5789d141249">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6afdf7fb-fee0-4e68-9576-d5789d141249_0">
											<gml:posList>35.67059361009749 139.741141267555 32.177 35.6706099148327 139.74111628418882 32.192 35.670597764042185 139.74110414724586 32.177 35.67058512448163 139.74111289939904 32.178 35.67059361009749 139.741141267555 32.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d422acab-4af8-44a2-a7a6-f3f7f0405a92">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d422acab-4af8-44a2-a7a6-f3f7f0405a92_0">
											<gml:posList>35.67058510645418 139.7411128994198 32.558 35.670593592070055 139.74114126757573 32.557 35.67059361009749 139.741141267555 32.177 35.67058512448163 139.74111289939904 32.178 35.67058510645418 139.7411128994198 32.558</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9d76847-91bc-43b1-8e26-60243da27bd5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b9d76847-91bc-43b1-8e26-60243da27bd5_0">
											<gml:posList>35.670593592070055 139.74114126757573 32.557 35.67060989680525 139.74111628420954 32.572 35.6706099148327 139.74111628418882 32.192 35.67059361009749 139.741141267555 32.177 35.670593592070055 139.74114126757573 32.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-86d0d634-dc0a-4abe-a3df-63ae4b771180">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-86d0d634-dc0a-4abe-a3df-63ae4b771180_0">
											<gml:posList>35.67058243746171 139.74111168739807 9.379 35.670592884079234 139.7411466147936 9.379 35.670592884079234 139.7411466147936 32.557 35.67058243746171 139.74111168739807 32.557 35.67058243746171 139.74111168739807 9.379</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb9799ab-93dc-45a5-991f-15b5b081b15e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb9799ab-93dc-45a5-991f-15b5b081b15e_0">
											<gml:posList>35.67058243746171 139.74111168739807 32.557 35.670592884079234 139.7411466147936 32.557 35.670593592070055 139.74114126757573 32.557 35.67058510645418 139.7411128994198 32.558 35.67058243746171 139.74111168739807 32.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1a8174c-b462-470e-9c48-2841966647ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d1a8174c-b462-470e-9c48-2841966647ea_0">
											<gml:posList>35.670592884079234 139.7411466147936 32.557 35.670612934125195 139.74111588304962 32.573 35.67060989680525 139.74111628420954 32.572 35.670593592070055 139.74114126757573 32.557 35.670592884079234 139.7411466147936 32.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da4e6fc8-08f2-4f92-83ce-3b19d53abcb1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da4e6fc8-08f2-4f92-83ce-3b19d53abcb1_0">
											<gml:posList>35.670592884079234 139.7411466147936 32.557 35.670592884079234 139.7411466147936 9.379 35.670612934125195 139.74111588304962 9.379 35.670612934125195 139.74111588304962 32.573 35.670592884079234 139.7411466147936 32.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb3ecb2d-c20b-40c3-906d-083c1703802d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67059796889567 139.74110093253995 9.379 35.670612934125195 139.74111588304962 9.379 35.670592884079234 139.7411466147936 9.379 35.67058243746171 139.74111168739807 9.379 35.67059796889567 139.74110093253995 9.379</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-e9de7072-00f7-4d78-ad21-dd3925f10791">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e9de7072-00f7-4d78-ad21-dd3925f10791">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e9de7072-00f7-4d78-ad21-dd3925f10791">
											<gml:posList>35.670612934125195 139.74111588304962 9.379 35.67059796889567 139.74110093253995 9.379 35.67059834489133 139.74109756298913 9.379 35.670614552582386 139.7410753412972 9.379 35.6706477082685 139.74105597212693 9.379 35.6707083262652 139.7411156628686 9.379 35.670664928242815 139.74117856622402 9.379 35.6706514134076 139.7411860932398 9.379 35.670630232427726 139.74118777452722 9.379 35.67061454407025 139.74118193802286 9.379 35.67060597570783 139.74117498870785 9.379 35.670592884079234 139.7411466147936 9.379 35.670612934125195 139.74111588304962 9.379</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f643f0e3-af18-4768-93c1-447cb23f7285">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f643f0e3-af18-4768-93c1-447cb23f7285">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f643f0e3-af18-4768-93c1-447cb23f7285">
											<gml:posList>35.670614552582386 139.7410753412972 32.573 35.67059834489133 139.74109756298913 32.573 35.67060059930348 139.74109884176528 32.573 35.67061600561133 139.74107771457804 32.573 35.670614552582386 139.7410753412972 32.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-08e6476a-f536-4e51-bfa8-c12bafbb9a58">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-08e6476a-f536-4e51-bfa8-c12bafbb9a58">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-08e6476a-f536-4e51-bfa8-c12bafbb9a58">
											<gml:posList>35.67059834489133 139.74109756298913 32.573 35.67059796889567 139.74110093253995 32.573 35.670600500820974 139.74109971453547 32.573 35.67060059930348 139.74109884176528 32.573 35.67059834489133 139.74109756298913 32.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a5395df9-a7b5-4368-b82b-f39d0336637a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5395df9-a7b5-4368-b82b-f39d0336637a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5395df9-a7b5-4368-b82b-f39d0336637a">
											<gml:posList>35.670612934125195 139.74111588304962 32.573 35.67061625084515 139.7411154484294 32.573 35.670600500820974 139.74109971453547 32.573 35.67059796889567 139.74110093253995 32.573 35.670612934125195 139.74111588304962 32.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-31df0e27-5be6-44dc-a840-51784f64f2be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31df0e27-5be6-44dc-a840-51784f64f2be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31df0e27-5be6-44dc-a840-51784f64f2be">
											<gml:posList>35.670612934125195 139.74111588304962 32.573 35.670592884079234 139.7411466147936 32.573 35.67059573262698 139.7411468876756 32.573 35.67061625084515 139.7411154484294 32.573 35.670612934125195 139.74111588304962 32.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-46348854-77cd-49a4-abfe-0a525a521d63">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-46348854-77cd-49a4-abfe-0a525a521d63">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-46348854-77cd-49a4-abfe-0a525a521d63">
											<gml:posList>35.67060597570783 139.74117498870785 32.573 35.67060775885238 139.74117293204813 32.573 35.67059573262698 139.7411468876756 32.573 35.670592884079234 139.7411466147936 32.573 35.67060597570783 139.74117498870785 32.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-17ef6bcc-859a-4b42-aa75-8aca5f42d261">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17ef6bcc-859a-4b42-aa75-8aca5f42d261">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17ef6bcc-859a-4b42-aa75-8aca5f42d261">
											<gml:posList>35.67061454407025 139.74118193802286 32.573 35.67061556057507 139.74117926365193 32.573 35.67060775885238 139.74117293204813 32.573 35.67060597570783 139.74117498870785 32.573 35.67061454407025 139.74118193802286 32.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-00265a49-8c10-44bf-bc37-c076cbe81659">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-00265a49-8c10-44bf-bc37-c076cbe81659">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-00265a49-8c10-44bf-bc37-c076cbe81659">
											<gml:posList>35.670614552582386 139.7410753412972 32.573 35.67061600561133 139.74107771457804 32.573 35.670647377376476 139.74105938581332 32.573 35.6706477082685 139.74105597212693 32.573 35.670614552582386 139.7410753412972 32.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-754699d8-d88f-48b5-8f03-90a886cf7d4d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-754699d8-d88f-48b5-8f03-90a886cf7d4d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-754699d8-d88f-48b5-8f03-90a886cf7d4d">
											<gml:posList>35.6706477082685 139.74105597212693 32.573 35.670647377376476 139.74105938581332 32.573 35.67070493741014 139.74111606443336 32.573 35.6707083262652 139.7411156628686 32.573 35.6706477082685 139.74105597212693 32.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a0c8a2bd-730d-4d24-9aba-6d36126c0546">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a0c8a2bd-730d-4d24-9aba-6d36126c0546">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a0c8a2bd-730d-4d24-9aba-6d36126c0546">
											<gml:posList>35.67060775885238 139.74117293204813 32.408 35.67061556057507 139.74117926365193 32.408 35.67063050058238 139.74118482485855 32.408 35.67065081629558 139.74118321084262 32.408 35.670663457171514 139.7411761708681 32.408 35.67070493741014 139.74111606443336 32.408 35.670647377376476 139.74105938581332 32.408 35.67061600561133 139.74107771457804 32.408 35.67060059930348 139.74109884176528 32.408 35.670600500820974 139.74109971453547 32.408 35.67061625084515 139.7411154484294 32.408 35.67059573262698 139.7411468876756 32.408 35.67060775885238 139.74117293204813 32.408</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2ea7a9af-e7b3-4934-9c3b-439529306dc3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2ea7a9af-e7b3-4934-9c3b-439529306dc3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2ea7a9af-e7b3-4934-9c3b-439529306dc3">
											<gml:posList>35.670664928242815 139.74117856622402 32.573 35.6707083262652 139.7411156628686 32.573 35.67070493741014 139.74111606443336 32.573 35.670663457171514 139.7411761708681 32.573 35.670664928242815 139.74117856622402 32.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7662bfea-279d-413b-9fd5-19cc46902de3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7662bfea-279d-413b-9fd5-19cc46902de3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7662bfea-279d-413b-9fd5-19cc46902de3">
											<gml:posList>35.6706514134076 139.7411860932398 32.573 35.670664928242815 139.74117856622402 32.573 35.670663457171514 139.7411761708681 32.573 35.67065081629558 139.74118321084262 32.573 35.6706514134076 139.7411860932398 32.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1dd5e5bb-b8bd-46d5-bd58-19fa4f473df3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1dd5e5bb-b8bd-46d5-bd58-19fa4f473df3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1dd5e5bb-b8bd-46d5-bd58-19fa4f473df3">
											<gml:posList>35.67061454407025 139.74118193802286 32.573 35.670630232427726 139.74118777452722 32.573 35.67063050058238 139.74118482485855 32.573 35.67061556057507 139.74117926365193 32.573 35.67061454407025 139.74118193802286 32.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3bcff63c-f9fa-447c-86c7-165e590649e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3bcff63c-f9fa-447c-86c7-165e590649e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3bcff63c-f9fa-447c-86c7-165e590649e3">
											<gml:posList>35.6706514134076 139.7411860932398 32.573 35.67065081629558 139.74118321084262 32.573 35.67063050058238 139.74118482485855 32.573 35.670630232427726 139.74118777452722 32.573 35.6706514134076 139.7411860932398 32.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cbe741ec-89f2-48d1-a424-a9da886ef6c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cbe741ec-89f2-48d1-a424-a9da886ef6c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cbe741ec-89f2-48d1-a424-a9da886ef6c2">
											<gml:posList>35.67059834489133 139.74109756298913 9.379 35.67059796889567 139.74110093253995 9.379 35.67059796889567 139.74110093253995 32.573 35.67059834489133 139.74109756298913 32.573 35.67059834489133 139.74109756298913 9.379</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a2eefe43-a4cc-42bc-bd17-9a64979b19f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2eefe43-a4cc-42bc-bd17-9a64979b19f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2eefe43-a4cc-42bc-bd17-9a64979b19f4">
											<gml:posList>35.670592884079234 139.7411466147936 9.379 35.67060597570783 139.74117498870785 9.379 35.67060597570783 139.74117498870785 32.573 35.670592884079234 139.7411466147936 32.573 35.670592884079234 139.7411466147936 9.379</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ea8487eb-4d31-4676-9c6a-e6f888053443">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea8487eb-4d31-4676-9c6a-e6f888053443">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea8487eb-4d31-4676-9c6a-e6f888053443">
											<gml:posList>35.670600500820974 139.74109971453547 32.573 35.670600500820974 139.74109971453547 32.408 35.67060059930348 139.74109884176528 32.408 35.67060059930348 139.74109884176528 32.573 35.670600500820974 139.74109971453547 32.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d8770a64-0ee1-4fed-910b-f99088384302">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d8770a64-0ee1-4fed-910b-f99088384302">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d8770a64-0ee1-4fed-910b-f99088384302">
											<gml:posList>35.67060775885238 139.74117293204813 32.573 35.67060775885238 139.74117293204813 32.408 35.67059573262698 139.7411468876756 32.408 35.67059573262698 139.7411468876756 32.573 35.67060775885238 139.74117293204813 32.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-765d1f6e-8437-41a6-a260-e26f0acb209c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-765d1f6e-8437-41a6-a260-e26f0acb209c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-765d1f6e-8437-41a6-a260-e26f0acb209c">
											<gml:posList>35.670612934125195 139.74111588304962 9.379 35.670592884079234 139.7411466147936 9.379 35.670592884079234 139.7411466147936 32.573 35.670612934125195 139.74111588304962 32.573 35.670612934125195 139.74111588304962 9.379</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-55ec71e4-8e2d-4d48-a522-726b2ee2d394">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-55ec71e4-8e2d-4d48-a522-726b2ee2d394">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-55ec71e4-8e2d-4d48-a522-726b2ee2d394">
											<gml:posList>35.67059796889567 139.74110093253995 9.379 35.670612934125195 139.74111588304962 9.379 35.670612934125195 139.74111588304962 32.573 35.67059796889567 139.74110093253995 32.573 35.67059796889567 139.74110093253995 9.379</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a2a398c9-5a44-4199-884f-b3de645b0ee8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2a398c9-5a44-4199-884f-b3de645b0ee8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2a398c9-5a44-4199-884f-b3de645b0ee8">
											<gml:posList>35.67059573262698 139.7411468876756 32.573 35.67059573262698 139.7411468876756 32.408 35.67061625084515 139.7411154484294 32.408 35.67061625084515 139.7411154484294 32.573 35.67059573262698 139.7411468876756 32.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2b1d9d18-fdfe-4f9a-9f23-4f58274dadc4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b1d9d18-fdfe-4f9a-9f23-4f58274dadc4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b1d9d18-fdfe-4f9a-9f23-4f58274dadc4">
											<gml:posList>35.670614552582386 139.7410753412972 9.379 35.67059834489133 139.74109756298913 9.379 35.67059834489133 139.74109756298913 32.573 35.670614552582386 139.7410753412972 32.573 35.670614552582386 139.7410753412972 9.379</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c6912f77-1511-406d-9de8-b9ca2d935845">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6912f77-1511-406d-9de8-b9ca2d935845">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6912f77-1511-406d-9de8-b9ca2d935845">
											<gml:posList>35.67060059930348 139.74109884176528 32.573 35.67060059930348 139.74109884176528 32.408 35.67061600561133 139.74107771457804 32.408 35.67061600561133 139.74107771457804 32.573 35.67060059930348 139.74109884176528 32.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d9a3d269-4992-478f-a376-413327469acd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d9a3d269-4992-478f-a376-413327469acd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d9a3d269-4992-478f-a376-413327469acd">
											<gml:posList>35.67061625084515 139.7411154484294 32.573 35.67061625084515 139.7411154484294 32.408 35.670600500820974 139.74109971453547 32.408 35.670600500820974 139.74109971453547 32.573 35.67061625084515 139.7411154484294 32.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4de17a5a-20e8-4e08-972c-8989fb050092">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4de17a5a-20e8-4e08-972c-8989fb050092">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4de17a5a-20e8-4e08-972c-8989fb050092">
											<gml:posList>35.67060597570783 139.74117498870785 9.379 35.67061454407025 139.74118193802286 9.379 35.67061454407025 139.74118193802286 32.573 35.67060597570783 139.74117498870785 32.573 35.67060597570783 139.74117498870785 9.379</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1a6cc064-811b-4834-832a-6b42f8ffc569">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a6cc064-811b-4834-832a-6b42f8ffc569">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a6cc064-811b-4834-832a-6b42f8ffc569">
											<gml:posList>35.67061556057507 139.74117926365193 32.573 35.67061556057507 139.74117926365193 32.408 35.67060775885238 139.74117293204813 32.408 35.67060775885238 139.74117293204813 32.573 35.67061556057507 139.74117926365193 32.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3e8e3296-5fbd-404e-b386-cbc8d8885431">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e8e3296-5fbd-404e-b386-cbc8d8885431">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e8e3296-5fbd-404e-b386-cbc8d8885431">
											<gml:posList>35.67061454407025 139.74118193802286 9.379 35.670630232427726 139.74118777452722 9.379 35.670630232427726 139.74118777452722 32.573 35.67061454407025 139.74118193802286 32.573 35.67061454407025 139.74118193802286 9.379</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-74c5c7aa-7ad7-408f-bb85-0be568f1a0be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74c5c7aa-7ad7-408f-bb85-0be568f1a0be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74c5c7aa-7ad7-408f-bb85-0be568f1a0be">
											<gml:posList>35.67063050058238 139.74118482485855 32.573 35.67063050058238 139.74118482485855 32.408 35.67061556057507 139.74117926365193 32.408 35.67061556057507 139.74117926365193 32.573 35.67063050058238 139.74118482485855 32.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b943c4b8-ba31-49d7-9e06-69e85ca4319d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b943c4b8-ba31-49d7-9e06-69e85ca4319d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b943c4b8-ba31-49d7-9e06-69e85ca4319d">
											<gml:posList>35.6706477082685 139.74105597212693 9.379 35.670614552582386 139.7410753412972 9.379 35.670614552582386 139.7410753412972 32.573 35.6706477082685 139.74105597212693 32.573 35.6706477082685 139.74105597212693 9.379</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9c4c0b78-3a6f-4616-a809-889767c345e0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c4c0b78-3a6f-4616-a809-889767c345e0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c4c0b78-3a6f-4616-a809-889767c345e0">
											<gml:posList>35.67061600561133 139.74107771457804 32.573 35.67061600561133 139.74107771457804 32.408 35.670647377376476 139.74105938581332 32.408 35.670647377376476 139.74105938581332 32.573 35.67061600561133 139.74107771457804 32.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-070bfbc7-0634-4514-8a9f-ec40ef645d07">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-070bfbc7-0634-4514-8a9f-ec40ef645d07">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-070bfbc7-0634-4514-8a9f-ec40ef645d07">
											<gml:posList>35.67065081629558 139.74118321084262 32.573 35.67065081629558 139.74118321084262 32.408 35.67063050058238 139.74118482485855 32.408 35.67063050058238 139.74118482485855 32.573 35.67065081629558 139.74118321084262 32.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7efa94d1-66b8-48c9-afe3-b52c1c26841e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7efa94d1-66b8-48c9-afe3-b52c1c26841e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7efa94d1-66b8-48c9-afe3-b52c1c26841e">
											<gml:posList>35.670630232427726 139.74118777452722 9.379 35.6706514134076 139.7411860932398 9.379 35.6706514134076 139.7411860932398 32.573 35.670630232427726 139.74118777452722 32.573 35.670630232427726 139.74118777452722 9.379</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4aa6e3dc-96ef-473f-b89b-ba015118ef44">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4aa6e3dc-96ef-473f-b89b-ba015118ef44">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4aa6e3dc-96ef-473f-b89b-ba015118ef44">
											<gml:posList>35.670663457171514 139.7411761708681 32.573 35.670663457171514 139.7411761708681 32.408 35.67065081629558 139.74118321084262 32.408 35.67065081629558 139.74118321084262 32.573 35.670663457171514 139.7411761708681 32.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1268874d-e5cc-4dcb-9e98-3737d51f3c59">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1268874d-e5cc-4dcb-9e98-3737d51f3c59">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1268874d-e5cc-4dcb-9e98-3737d51f3c59">
											<gml:posList>35.6706514134076 139.7411860932398 9.379 35.670664928242815 139.74117856622402 9.379 35.670664928242815 139.74117856622402 32.573 35.6706514134076 139.7411860932398 32.573 35.6706514134076 139.7411860932398 9.379</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7d1ca33e-9ba4-40b5-92ba-8196da5c2057">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d1ca33e-9ba4-40b5-92ba-8196da5c2057">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d1ca33e-9ba4-40b5-92ba-8196da5c2057">
											<gml:posList>35.670647377376476 139.74105938581332 32.573 35.670647377376476 139.74105938581332 32.408 35.67070493741014 139.74111606443336 32.408 35.67070493741014 139.74111606443336 32.573 35.670647377376476 139.74105938581332 32.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c8d8adb5-8c7c-4f9f-8194-eab134d89036">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8d8adb5-8c7c-4f9f-8194-eab134d89036">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8d8adb5-8c7c-4f9f-8194-eab134d89036">
											<gml:posList>35.6707083262652 139.7411156628686 9.379 35.6706477082685 139.74105597212693 9.379 35.6706477082685 139.74105597212693 32.573 35.6707083262652 139.7411156628686 32.573 35.6707083262652 139.7411156628686 9.379</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-228e1672-4133-4d16-bcf0-8d31f9262ee9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-228e1672-4133-4d16-bcf0-8d31f9262ee9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-228e1672-4133-4d16-bcf0-8d31f9262ee9">
											<gml:posList>35.67070493741014 139.74111606443336 32.573 35.67070493741014 139.74111606443336 32.408 35.670663457171514 139.7411761708681 32.408 35.670663457171514 139.7411761708681 32.573 35.67070493741014 139.74111606443336 32.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f5da4cf7-6179-4e34-9b7b-a72b1b50875d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f5da4cf7-6179-4e34-9b7b-a72b1b50875d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f5da4cf7-6179-4e34-9b7b-a72b1b50875d">
											<gml:posList>35.670664928242815 139.74117856622402 9.379 35.6707083262652 139.7411156628686 9.379 35.6707083262652 139.7411156628686 32.573 35.670664928242815 139.74117856622402 32.573 35.670664928242815 139.74117856622402 9.379</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8391</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">99.38505</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>