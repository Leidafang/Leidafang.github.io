<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_58a59163-a73c-4bc4-9f99-ecabf260907a">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>6</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001006</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">14.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.669237301408714 139.73789730559147 0 35.669175778682785 139.7378354102362 0 35.669192074247604 139.73781108941765 0 35.66913848986693 139.7377571378835 0 35.669120393759364 139.73778422236387 0 35.669085121870154 139.73774869601607 0 35.66903227397777 139.73782773844152 0 35.66927177935979 139.73806858966535 0 35.66932489755738 139.73798921545713 0 35.66929052780196 139.73795457154424 0 35.66930574296889 139.7379317984561 0 35.66925107612056 139.73787674344325 0 35.669237301408714 139.73789730559147 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669237301408714 139.73789730559147 22.135 35.66925107612056 139.73787674344325 22.135 35.66930574296889 139.7379317984561 22.135 35.66929052780196 139.73795457154424 22.135 35.66932489755738 139.73798921545713 22.135 35.66927177935979 139.73806858966535 22.135 35.66903227397777 139.73782773844152 22.135 35.669085121870154 139.73774869601607 22.135 35.669120393759364 139.73778422236387 22.135 35.66913848986693 139.7377571378835 22.135 35.669192074247604 139.73781108941765 22.135 35.669175778682785 139.7378354102362 22.135 35.669237301408714 139.73789730559147 22.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669237301408714 139.73789730559147 22.135 35.669175778682785 139.7378354102362 22.135 35.669175778682785 139.7378354102362 36.52 35.669237301408714 139.73789730559147 36.52 35.669237301408714 139.73789730559147 22.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669175778682785 139.7378354102362 22.135 35.669192074247604 139.73781108941765 22.135 35.669192074247604 139.73781108941765 36.52 35.669175778682785 139.7378354102362 36.52 35.669175778682785 139.7378354102362 22.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669192074247604 139.73781108941765 22.135 35.66913848986693 139.7377571378835 22.135 35.66913848986693 139.7377571378835 36.52 35.669192074247604 139.73781108941765 36.52 35.669192074247604 139.73781108941765 22.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66913848986693 139.7377571378835 22.135 35.669120393759364 139.73778422236387 22.135 35.669120393759364 139.73778422236387 36.52 35.66913848986693 139.7377571378835 36.52 35.66913848986693 139.7377571378835 22.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669120393759364 139.73778422236387 22.135 35.669085121870154 139.73774869601607 22.135 35.669085121870154 139.73774869601607 36.52 35.669120393759364 139.73778422236387 36.52 35.669120393759364 139.73778422236387 22.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669085121870154 139.73774869601607 22.135 35.66903227397777 139.73782773844152 22.135 35.66903227397777 139.73782773844152 36.52 35.669085121870154 139.73774869601607 36.52 35.669085121870154 139.73774869601607 22.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66903227397777 139.73782773844152 22.135 35.66927177935979 139.73806858966535 22.135 35.66927177935979 139.73806858966535 36.52 35.66903227397777 139.73782773844152 36.52 35.66903227397777 139.73782773844152 22.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66927177935979 139.73806858966535 22.135 35.66932489755738 139.73798921545713 22.135 35.66932489755738 139.73798921545713 36.52 35.66927177935979 139.73806858966535 36.52 35.66927177935979 139.73806858966535 22.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66932489755738 139.73798921545713 22.135 35.66929052780196 139.73795457154424 22.135 35.66929052780196 139.73795457154424 36.52 35.66932489755738 139.73798921545713 36.52 35.66932489755738 139.73798921545713 22.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66929052780196 139.73795457154424 22.135 35.66930574296889 139.7379317984561 22.135 35.66930574296889 139.7379317984561 36.52 35.66929052780196 139.73795457154424 36.52 35.66929052780196 139.73795457154424 22.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66930574296889 139.7379317984561 22.135 35.66925107612056 139.73787674344325 22.135 35.66925107612056 139.73787674344325 36.52 35.66930574296889 139.7379317984561 36.52 35.66930574296889 139.7379317984561 22.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66925107612056 139.73787674344325 22.135 35.669237301408714 139.73789730559147 22.135 35.669237301408714 139.73789730559147 36.52 35.66925107612056 139.73787674344325 36.52 35.66925107612056 139.73787674344325 22.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669237301408714 139.73789730559147 36.52 35.669175778682785 139.7378354102362 36.52 35.669192074247604 139.73781108941765 36.52 35.66913848986693 139.7377571378835 36.52 35.669120393759364 139.73778422236387 36.52 35.669085121870154 139.73774869601607 36.52 35.66903227397777 139.73782773844152 36.52 35.66927177935979 139.73806858966535 36.52 35.66932489755738 139.73798921545713 36.52 35.66929052780196 139.73795457154424 36.52 35.66930574296889 139.7379317984561 36.52 35.66925107612056 139.73787674344325 36.52 35.669237301408714 139.73789730559147 36.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-73d2a8c3-e6a6-4e95-9175-e2019ba6d368"/>
							<gml:surfaceMember xlink:href="#poly-d063fdfc-45d7-40a8-951c-7de0f1bb3e8d"/>
							<gml:surfaceMember xlink:href="#poly-9a6d8ea3-8479-4700-8687-11b7aba0dc9b"/>
							<gml:surfaceMember xlink:href="#poly-a3e1c43b-20b7-4e1d-9681-6439f8798020"/>
							<gml:surfaceMember xlink:href="#poly-7cbfe3e9-df0c-41ca-ba65-1bdf8fc360f2"/>
							<gml:surfaceMember xlink:href="#poly-5b65f771-21e0-4b9e-b9de-6eba047b726d"/>
							<gml:surfaceMember xlink:href="#poly-7b428907-fda3-4acc-b8ba-8b43e08fcb15"/>
							<gml:surfaceMember xlink:href="#poly-ab8b1cd2-55a1-4b36-bcb8-ebe4977e4bb1"/>
							<gml:surfaceMember xlink:href="#poly-ba92d280-eb67-46cd-a2c5-2cd46d4b8eda"/>
							<gml:surfaceMember xlink:href="#poly-8f48897e-8f99-4dd0-8df7-64df43e5018d"/>
							<gml:surfaceMember xlink:href="#poly-11e5bafb-2ff3-4066-9457-7a16f08718a1"/>
							<gml:surfaceMember xlink:href="#poly-47ddfab3-ac4c-4675-a10c-20c7f450b1b2"/>
							<gml:surfaceMember xlink:href="#poly-af6e48bd-a121-437b-be60-2d4e71d9b642"/>
							<gml:surfaceMember xlink:href="#poly-6ee9bfbd-93ce-4f7b-8e6d-e5711c5a9a1a"/>
							<gml:surfaceMember xlink:href="#poly-b8cde6fe-0d08-4d93-b19f-35abb1e39cfd"/>
							<gml:surfaceMember xlink:href="#poly-9ea119d9-318b-4505-9e72-7adfda267c18"/>
							<gml:surfaceMember xlink:href="#poly-669a9392-29fa-4f61-88c6-e061dc5b7d02"/>
							<gml:surfaceMember xlink:href="#poly-aa9097c2-2cf3-4fa9-be06-583ad38bab15"/>
							<gml:surfaceMember xlink:href="#poly-1866e38c-264c-4903-9751-9cce8ea02346"/>
							<gml:surfaceMember xlink:href="#poly-d492bf36-722f-4408-85ec-089ae5b51d9f"/>
							<gml:surfaceMember xlink:href="#poly-45ef8d96-ddde-4aa8-885c-55d987d12aa6"/>
							<gml:surfaceMember xlink:href="#poly-c37f35ad-2c96-4c74-9955-ed1372305241"/>
							<gml:surfaceMember xlink:href="#poly-eb5e4ea5-c0cb-4616-a9cb-40831fb16f6e"/>
							<gml:surfaceMember xlink:href="#poly-0faa27be-9665-47fa-b57a-df969e3bf36f"/>
							<gml:surfaceMember xlink:href="#poly-70a4912e-4885-4851-aa06-1c0d35f157ae"/>
							<gml:surfaceMember xlink:href="#poly-9231327a-d8b0-44f2-a6a1-01c1d9213dbb"/>
							<gml:surfaceMember xlink:href="#poly-b8897bd7-da40-4059-aaf1-43379ddaa48f"/>
							<gml:surfaceMember xlink:href="#poly-4de90602-644f-413b-9584-21696937c738"/>
							<gml:surfaceMember xlink:href="#poly-5aad6635-0696-41e6-afea-920b7e4b7a4d"/>
							<gml:surfaceMember xlink:href="#poly-70e6c426-c1cc-4c4e-a4a9-ed53d0146b50"/>
							<gml:surfaceMember xlink:href="#poly-345f9e0e-82d5-4ea8-b282-6d8357ca1f81"/>
							<gml:surfaceMember xlink:href="#poly-88ecf2ab-9a4f-4a5b-9e81-635a4bc25934"/>
							<gml:surfaceMember xlink:href="#poly-7507c141-fff5-44fd-9ae6-f250df654292"/>
							<gml:surfaceMember xlink:href="#poly-2c4d66c1-788e-450e-a29b-83b9f0d637a5"/>
							<gml:surfaceMember xlink:href="#poly-c3ebc869-284a-44c4-9459-d64b39a70b4e"/>
							<gml:surfaceMember xlink:href="#poly-b80e3c97-82a1-4f34-8b0f-41a2184581d9"/>
							<gml:surfaceMember xlink:href="#poly-6f6b6186-3c22-4ee6-b624-a74063fcc9f4"/>
							<gml:surfaceMember xlink:href="#poly-5cafb63d-b70e-4477-ade2-928960c37b2f"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-73d2a8c3-e6a6-4e95-9175-e2019ba6d368">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73d2a8c3-e6a6-4e95-9175-e2019ba6d368">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73d2a8c3-e6a6-4e95-9175-e2019ba6d368">
											<gml:posList>35.66923730140873 139.73789730559147 22.135 35.66925107612056 139.73787674344325 22.135 35.669305742968895 139.7379317984561 22.135 35.66929052780193 139.73795457154424 22.135 35.66932489755739 139.7379892154571 22.135 35.66927177935979 139.73806858966535 22.135 35.66903227397774 139.73782773844152 22.135 35.66908512187015 139.73774869601604 22.135 35.66912039375934 139.73778422236384 22.135 35.66913848986692 139.7377571378835 22.135 35.66919207424761 139.73781108941765 22.135 35.669175778682785 139.7378354102362 22.135 35.66923730140873 139.73789730559147 22.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d063fdfc-45d7-40a8-951c-7de0f1bb3e8d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d063fdfc-45d7-40a8-951c-7de0f1bb3e8d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d063fdfc-45d7-40a8-951c-7de0f1bb3e8d">
											<gml:posList>35.66912039375934 139.73778422236384 36.88 35.66908512187015 139.73774869601604 36.88 35.669085695407645 139.7377558421466 36.88 35.66912096729472 139.73779136849782 36.88 35.66912039375934 139.73778422236384 36.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9a6d8ea3-8479-4700-8687-11b7aba0dc9b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a6d8ea3-8479-4700-8687-11b7aba0dc9b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a6d8ea3-8479-4700-8687-11b7aba0dc9b">
											<gml:posList>35.66913848986692 139.7377571378835 36.88 35.66912039375934 139.73778422236384 36.88 35.66912096729472 139.73779136849782 36.88 35.669139063403904 139.7377642840189 36.88 35.66913848986692 139.7377571378835 36.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a3e1c43b-20b7-4e1d-9681-6439f8798020">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a3e1c43b-20b7-4e1d-9681-6439f8798020">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a3e1c43b-20b7-4e1d-9681-6439f8798020">
											<gml:posList>35.66919207424761 139.73781108941765 36.88 35.66913848986692 139.7377571378835 36.88 35.669139063403904 139.7377642840189 36.88 35.669186251934086 139.7378117922579 36.88 35.66919207424761 139.73781108941765 36.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7cbfe3e9-df0c-41ca-ba65-1bdf8fc360f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7cbfe3e9-df0c-41ca-ba65-1bdf8fc360f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7cbfe3e9-df0c-41ca-ba65-1bdf8fc360f2">
											<gml:posList>35.66908512187015 139.73774869601604 36.88 35.66903227397774 139.73782773844152 36.88 35.66903809629151 139.73782703560377 36.88 35.669085695407645 139.7377558421466 36.88 35.66908512187015 139.73774869601604 36.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5b65f771-21e0-4b9e-b9de-6eba047b726d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b65f771-21e0-4b9e-b9de-6eba047b726d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b65f771-21e0-4b9e-b9de-6eba047b726d">
											<gml:posList>35.669175778682785 139.7378354102362 36.88 35.66919207424761 139.73781108941765 36.88 35.669186251934086 139.7378117922579 36.88 35.66916994735536 139.73783611308528 36.88 35.669175778682785 139.7378354102362 36.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7b428907-fda3-4acc-b8ba-8b43e08fcb15">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b428907-fda3-4acc-b8ba-8b43e08fcb15">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b428907-fda3-4acc-b8ba-8b43e08fcb15">
											<gml:posList>35.66923730140873 139.73789730559147 36.88 35.669175778682785 139.7378354102362 36.88 35.66916994735536 139.73783611308528 36.88 35.669237874937416 139.73790445173668 36.88 35.66923730140873 139.73789730559147 36.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ab8b1cd2-55a1-4b36-bcb8-ebe4977e4bb1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab8b1cd2-55a1-4b36-bcb8-ebe4977e4bb1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab8b1cd2-55a1-4b36-bcb8-ebe4977e4bb1">
											<gml:posList>35.66925107612056 139.73787674344325 36.88 35.66923730140873 139.73789730559147 36.88 35.669237874937416 139.73790445173668 36.88 35.66925164965045 139.73788388958954 36.88 35.66925107612056 139.73787674344325 36.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ba92d280-eb67-46cd-a2c5-2cd46d4b8eda">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba92d280-eb67-46cd-a2c5-2cd46d4b8eda">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba92d280-eb67-46cd-a2c5-2cd46d4b8eda">
											<gml:posList>35.669305742968895 139.7379317984561 36.88 35.66925107612056 139.73787674344325 36.88 35.66925164965045 139.73788388958954 36.88 35.66929992065475 139.7379325012886 36.88 35.669305742968895 139.7379317984561 36.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8f48897e-8f99-4dd0-8df7-64df43e5018d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f48897e-8f99-4dd0-8df7-64df43e5018d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f48897e-8f99-4dd0-8df7-64df43e5018d">
											<gml:posList>35.66916994735536 139.73783611308528 36.402 35.669186251934086 139.7378117922579 36.402 35.669139063403904 139.7377642840189 36.402 35.66912096729472 139.73779136849782 36.402 35.669085695407645 139.7377558421466 36.402 35.66903809629151 139.73782703560377 36.402 35.66927120584085 139.7380614435159 36.402 35.66931907524293 139.73798991828565 36.402 35.66928470548765 139.73795527437497 36.402 35.66929992065475 139.7379325012886 36.402 35.66925164965045 139.73788388958954 36.402 35.669237874937416 139.73790445173668 36.402 35.66916994735536 139.73783611308528 36.402</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-11e5bafb-2ff3-4066-9457-7a16f08718a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11e5bafb-2ff3-4066-9457-7a16f08718a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11e5bafb-2ff3-4066-9457-7a16f08718a1">
											<gml:posList>35.66929052780193 139.73795457154424 36.88 35.669305742968895 139.7379317984561 36.88 35.66929992065475 139.7379325012886 36.88 35.66928470548765 139.73795527437497 36.88 35.66929052780193 139.73795457154424 36.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-47ddfab3-ac4c-4675-a10c-20c7f450b1b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47ddfab3-ac4c-4675-a10c-20c7f450b1b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47ddfab3-ac4c-4675-a10c-20c7f450b1b2">
											<gml:posList>35.66903227397774 139.73782773844152 36.88 35.66927177935979 139.73806858966535 36.88 35.66927120584085 139.7380614435159 36.88 35.66903809629151 139.73782703560377 36.88 35.66903227397774 139.73782773844152 36.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-af6e48bd-a121-437b-be60-2d4e71d9b642">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af6e48bd-a121-437b-be60-2d4e71d9b642">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af6e48bd-a121-437b-be60-2d4e71d9b642">
											<gml:posList>35.66932489755739 139.7379892154571 36.88 35.66929052780193 139.73795457154424 36.88 35.66928470548765 139.73795527437497 36.88 35.66931907524293 139.73798991828565 36.88 35.66932489755739 139.7379892154571 36.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6ee9bfbd-93ce-4f7b-8e6d-e5711c5a9a1a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ee9bfbd-93ce-4f7b-8e6d-e5711c5a9a1a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ee9bfbd-93ce-4f7b-8e6d-e5711c5a9a1a">
											<gml:posList>35.66927177935979 139.73806858966535 36.88 35.66932489755739 139.7379892154571 36.88 35.66931907524293 139.73798991828565 36.88 35.66927120584085 139.7380614435159 36.88 35.66927177935979 139.73806858966535 36.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b8cde6fe-0d08-4d93-b19f-35abb1e39cfd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8cde6fe-0d08-4d93-b19f-35abb1e39cfd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8cde6fe-0d08-4d93-b19f-35abb1e39cfd">
											<gml:posList>35.669237874937416 139.73790445173668 36.88 35.66916994735536 139.73783611308528 36.88 35.66916994735536 139.73783611308528 36.402 35.669237874937416 139.73790445173668 36.402 35.669237874937416 139.73790445173668 36.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9ea119d9-318b-4505-9e72-7adfda267c18">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ea119d9-318b-4505-9e72-7adfda267c18">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ea119d9-318b-4505-9e72-7adfda267c18">
											<gml:posList>35.66929992065475 139.7379325012886 36.88 35.66925164965045 139.73788388958954 36.88 35.66925164965045 139.73788388958954 36.402 35.66929992065475 139.7379325012886 36.402 35.66929992065475 139.7379325012886 36.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-669a9392-29fa-4f61-88c6-e061dc5b7d02">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-669a9392-29fa-4f61-88c6-e061dc5b7d02">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-669a9392-29fa-4f61-88c6-e061dc5b7d02">
											<gml:posList>35.66912039375934 139.73778422236384 22.135 35.66908512187015 139.73774869601604 22.135 35.66908512187015 139.73774869601604 36.88 35.66912039375934 139.73778422236384 36.88 35.66912039375934 139.73778422236384 22.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aa9097c2-2cf3-4fa9-be06-583ad38bab15">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa9097c2-2cf3-4fa9-be06-583ad38bab15">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa9097c2-2cf3-4fa9-be06-583ad38bab15">
											<gml:posList>35.66913848986692 139.7377571378835 22.135 35.66912039375934 139.73778422236384 22.135 35.66912039375934 139.73778422236384 36.88 35.66913848986692 139.7377571378835 36.88 35.66913848986692 139.7377571378835 22.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1866e38c-264c-4903-9751-9cce8ea02346">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1866e38c-264c-4903-9751-9cce8ea02346">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1866e38c-264c-4903-9751-9cce8ea02346">
											<gml:posList>35.66912096729472 139.73779136849782 36.88 35.669085695407645 139.7377558421466 36.88 35.669085695407645 139.7377558421466 36.402 35.66912096729472 139.73779136849782 36.402 35.66912096729472 139.73779136849782 36.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d492bf36-722f-4408-85ec-089ae5b51d9f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d492bf36-722f-4408-85ec-089ae5b51d9f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d492bf36-722f-4408-85ec-089ae5b51d9f">
											<gml:posList>35.669139063403904 139.7377642840189 36.88 35.66912096729472 139.73779136849782 36.88 35.66912096729472 139.73779136849782 36.402 35.669139063403904 139.7377642840189 36.402 35.669139063403904 139.7377642840189 36.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-45ef8d96-ddde-4aa8-885c-55d987d12aa6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45ef8d96-ddde-4aa8-885c-55d987d12aa6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45ef8d96-ddde-4aa8-885c-55d987d12aa6">
											<gml:posList>35.66919207424761 139.73781108941765 22.135 35.66913848986692 139.7377571378835 22.135 35.66913848986692 139.7377571378835 36.88 35.66919207424761 139.73781108941765 36.88 35.66919207424761 139.73781108941765 22.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c37f35ad-2c96-4c74-9955-ed1372305241">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c37f35ad-2c96-4c74-9955-ed1372305241">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c37f35ad-2c96-4c74-9955-ed1372305241">
											<gml:posList>35.669186251934086 139.7378117922579 36.88 35.669139063403904 139.7377642840189 36.88 35.669139063403904 139.7377642840189 36.402 35.669186251934086 139.7378117922579 36.402 35.669186251934086 139.7378117922579 36.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eb5e4ea5-c0cb-4616-a9cb-40831fb16f6e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eb5e4ea5-c0cb-4616-a9cb-40831fb16f6e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eb5e4ea5-c0cb-4616-a9cb-40831fb16f6e">
											<gml:posList>35.66908512187015 139.73774869601604 22.135 35.66903227397774 139.73782773844152 22.135 35.66903227397774 139.73782773844152 36.88 35.66908512187015 139.73774869601604 36.88 35.66908512187015 139.73774869601604 22.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0faa27be-9665-47fa-b57a-df969e3bf36f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0faa27be-9665-47fa-b57a-df969e3bf36f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0faa27be-9665-47fa-b57a-df969e3bf36f">
											<gml:posList>35.669085695407645 139.7377558421466 36.88 35.66903809629151 139.73782703560377 36.88 35.66903809629151 139.73782703560377 36.402 35.669085695407645 139.7377558421466 36.402 35.669085695407645 139.7377558421466 36.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-70a4912e-4885-4851-aa06-1c0d35f157ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70a4912e-4885-4851-aa06-1c0d35f157ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70a4912e-4885-4851-aa06-1c0d35f157ae">
											<gml:posList>35.669175778682785 139.7378354102362 22.135 35.66919207424761 139.73781108941765 22.135 35.66919207424761 139.73781108941765 36.88 35.669175778682785 139.7378354102362 36.88 35.669175778682785 139.7378354102362 22.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9231327a-d8b0-44f2-a6a1-01c1d9213dbb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9231327a-d8b0-44f2-a6a1-01c1d9213dbb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9231327a-d8b0-44f2-a6a1-01c1d9213dbb">
											<gml:posList>35.66916994735536 139.73783611308528 36.88 35.669186251934086 139.7378117922579 36.88 35.669186251934086 139.7378117922579 36.402 35.66916994735536 139.73783611308528 36.402 35.66916994735536 139.73783611308528 36.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b8897bd7-da40-4059-aaf1-43379ddaa48f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8897bd7-da40-4059-aaf1-43379ddaa48f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8897bd7-da40-4059-aaf1-43379ddaa48f">
											<gml:posList>35.66923730140873 139.73789730559147 22.135 35.669175778682785 139.7378354102362 22.135 35.669175778682785 139.7378354102362 36.88 35.66923730140873 139.73789730559147 36.88 35.66923730140873 139.73789730559147 22.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4de90602-644f-413b-9584-21696937c738">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4de90602-644f-413b-9584-21696937c738">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4de90602-644f-413b-9584-21696937c738">
											<gml:posList>35.66925107612056 139.73787674344325 22.135 35.66923730140873 139.73789730559147 22.135 35.66923730140873 139.73789730559147 36.88 35.66925107612056 139.73787674344325 36.88 35.66925107612056 139.73787674344325 22.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5aad6635-0696-41e6-afea-920b7e4b7a4d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5aad6635-0696-41e6-afea-920b7e4b7a4d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5aad6635-0696-41e6-afea-920b7e4b7a4d">
											<gml:posList>35.66925164965045 139.73788388958954 36.88 35.669237874937416 139.73790445173668 36.88 35.669237874937416 139.73790445173668 36.402 35.66925164965045 139.73788388958954 36.402 35.66925164965045 139.73788388958954 36.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-70e6c426-c1cc-4c4e-a4a9-ed53d0146b50">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70e6c426-c1cc-4c4e-a4a9-ed53d0146b50">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70e6c426-c1cc-4c4e-a4a9-ed53d0146b50">
											<gml:posList>35.669305742968895 139.7379317984561 22.135 35.66925107612056 139.73787674344325 22.135 35.66925107612056 139.73787674344325 36.88 35.669305742968895 139.7379317984561 36.88 35.669305742968895 139.7379317984561 22.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-345f9e0e-82d5-4ea8-b282-6d8357ca1f81">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-345f9e0e-82d5-4ea8-b282-6d8357ca1f81">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-345f9e0e-82d5-4ea8-b282-6d8357ca1f81">
											<gml:posList>35.66929052780193 139.73795457154424 22.135 35.669305742968895 139.7379317984561 22.135 35.669305742968895 139.7379317984561 36.88 35.66929052780193 139.73795457154424 36.88 35.66929052780193 139.73795457154424 22.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-88ecf2ab-9a4f-4a5b-9e81-635a4bc25934">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-88ecf2ab-9a4f-4a5b-9e81-635a4bc25934">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-88ecf2ab-9a4f-4a5b-9e81-635a4bc25934">
											<gml:posList>35.66928470548765 139.73795527437497 36.88 35.66929992065475 139.7379325012886 36.88 35.66929992065475 139.7379325012886 36.402 35.66928470548765 139.73795527437497 36.402 35.66928470548765 139.73795527437497 36.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7507c141-fff5-44fd-9ae6-f250df654292">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7507c141-fff5-44fd-9ae6-f250df654292">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7507c141-fff5-44fd-9ae6-f250df654292">
											<gml:posList>35.66903809629151 139.73782703560377 36.88 35.66927120584085 139.7380614435159 36.88 35.66927120584085 139.7380614435159 36.402 35.66903809629151 139.73782703560377 36.402 35.66903809629151 139.73782703560377 36.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2c4d66c1-788e-450e-a29b-83b9f0d637a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c4d66c1-788e-450e-a29b-83b9f0d637a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c4d66c1-788e-450e-a29b-83b9f0d637a5">
											<gml:posList>35.66903227397774 139.73782773844152 22.135 35.66927177935979 139.73806858966535 22.135 35.66927177935979 139.73806858966535 36.88 35.66903227397774 139.73782773844152 36.88 35.66903227397774 139.73782773844152 22.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c3ebc869-284a-44c4-9459-d64b39a70b4e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3ebc869-284a-44c4-9459-d64b39a70b4e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3ebc869-284a-44c4-9459-d64b39a70b4e">
											<gml:posList>35.66932489755739 139.7379892154571 22.135 35.66929052780193 139.73795457154424 22.135 35.66929052780193 139.73795457154424 36.88 35.66932489755739 139.7379892154571 36.88 35.66932489755739 139.7379892154571 22.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b80e3c97-82a1-4f34-8b0f-41a2184581d9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b80e3c97-82a1-4f34-8b0f-41a2184581d9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b80e3c97-82a1-4f34-8b0f-41a2184581d9">
											<gml:posList>35.66931907524293 139.73798991828565 36.88 35.66928470548765 139.73795527437497 36.88 35.66928470548765 139.73795527437497 36.402 35.66931907524293 139.73798991828565 36.402 35.66931907524293 139.73798991828565 36.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6f6b6186-3c22-4ee6-b624-a74063fcc9f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f6b6186-3c22-4ee6-b624-a74063fcc9f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f6b6186-3c22-4ee6-b624-a74063fcc9f4">
											<gml:posList>35.66927120584085 139.7380614435159 36.88 35.66931907524293 139.73798991828565 36.88 35.66931907524293 139.73798991828565 36.402 35.66927120584085 139.7380614435159 36.402 35.66927120584085 139.7380614435159 36.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5cafb63d-b70e-4477-ade2-928960c37b2f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5cafb63d-b70e-4477-ade2-928960c37b2f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5cafb63d-b70e-4477-ade2-928960c37b2f">
											<gml:posList>35.66927177935979 139.73806858966535 22.135 35.66932489755739 139.7379892154571 22.135 35.66932489755739 139.7379892154571 36.88 35.66927177935979 139.73806858966535 36.88 35.66927177935979 139.73806858966535 22.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂六丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6906</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">366.59555</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">6</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>