<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_593485c2-6bbb-4e1f-8e7f-cf439242cda2">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">24.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>7</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67138366336781 139.74080028468688 0 35.67131478552108 139.74090077585092 0 35.67139146284074 139.74097977966593 0 35.67146034075244 139.74087928847337 0 35.67138366336781 139.74080028468688 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67138366336781 139.74080028468688 8.06 35.67146034075244 139.74087928847337 8.06 35.67139146284074 139.74097977966593 8.06 35.67131478552108 139.74090077585092 8.06 35.67138366336781 139.74080028468688 8.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67138366336781 139.74080028468688 8.06 35.67131478552108 139.74090077585092 8.06 35.67131478552108 139.74090077585092 32.31 35.67138366336781 139.74080028468688 32.31 35.67138366336781 139.74080028468688 8.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67131478552108 139.74090077585092 8.06 35.67139146284074 139.74097977966593 8.06 35.67139146284074 139.74097977966593 32.31 35.67131478552108 139.74090077585092 32.31 35.67131478552108 139.74090077585092 8.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67139146284074 139.74097977966593 8.06 35.67146034075244 139.74087928847337 8.06 35.67146034075244 139.74087928847337 32.31 35.67139146284074 139.74097977966593 32.31 35.67139146284074 139.74097977966593 8.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67146034075244 139.74087928847337 8.06 35.67138366336781 139.74080028468688 8.06 35.67138366336781 139.74080028468688 32.31 35.67146034075244 139.74087928847337 32.31 35.67146034075244 139.74087928847337 8.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67138366336781 139.74080028468688 32.31 35.67131478552108 139.74090077585092 32.31 35.67139146284074 139.74097977966593 32.31 35.67146034075244 139.74087928847337 32.31 35.67138366336781 139.74080028468688 32.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-e5ccbaed-f26c-4ba3-8a1a-57bff7b98ad1"/>
							<gml:surfaceMember xlink:href="#poly-55f756df-89fd-49c4-9724-c29e01414e21"/>
							<gml:surfaceMember xlink:href="#poly-bdee41dd-8394-4968-86fa-c98d5ca1c21f"/>
							<gml:surfaceMember xlink:href="#poly-7e2425bc-87cb-4c52-816e-52b2e05d8a04"/>
							<gml:surfaceMember xlink:href="#poly-d3b2874d-db77-4b9b-9ef6-0ea4a3c79892"/>
							<gml:surfaceMember xlink:href="#poly-889d4098-09a8-4a5e-ba9e-8863b9d49f24"/>
							<gml:surfaceMember xlink:href="#poly-b9e655fc-abef-47c1-80ac-315fea96ac86"/>
							<gml:surfaceMember xlink:href="#poly-ce9811dd-f072-4030-809e-986b950e5a10"/>
							<gml:surfaceMember xlink:href="#poly-3a7e75f4-5c6e-4553-a77b-74cbf23132a9"/>
							<gml:surfaceMember xlink:href="#poly-dc3b435f-00e6-40d1-ba05-7b87e84533c4"/>
							<gml:surfaceMember xlink:href="#poly-cbaa6ebb-7058-454d-8cdd-6f19ad8ef858"/>
							<gml:surfaceMember xlink:href="#poly-2c80719d-f74d-4978-8b62-43ace1bb4177"/>
							<gml:surfaceMember xlink:href="#poly-80944585-3ceb-4540-92fc-25e0023bad51"/>
							<gml:surfaceMember xlink:href="#poly-315b62bc-f73e-4809-ad39-45d196b103f9"/>
							<gml:surfaceMember xlink:href="#poly-5262a540-2f17-4137-b7c3-ec425ed87167"/>
							<gml:surfaceMember xlink:href="#poly-d371de93-7fc2-4adc-9c26-1b5fdeb8e613"/>
							<gml:surfaceMember xlink:href="#poly-ed21a7a4-f8a3-4d62-8916-221b56d5f202"/>
							<gml:surfaceMember xlink:href="#poly-1f1af1c4-0e57-4afe-b805-c997617e37f5"/>
							<gml:surfaceMember xlink:href="#poly-29f88fb7-d9a7-437f-bed2-b5ffa3c8400a"/>
							<gml:surfaceMember xlink:href="#poly-e073f367-59e7-47ed-8264-cf7305d36321"/>
							<gml:surfaceMember xlink:href="#poly-ac4bbacc-a6ea-4f8a-b69e-ce90e9081431"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_593485c2-6bbb-4e1f-8e7f-cf439242cda2_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8126645b-bebb-4b8e-adbe-0c393ef6bacf">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671336669748435 139.74087585205493 35.929 35.67134259422877 139.74086731740812 35.929 35.67136446123286 139.74089040124727 35.929 35.67135853675092 139.7408989358947 35.929 35.671336669748435 139.74087585205493 35.929</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-02132434-841a-493d-8777-27c50499435e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67139312419486 139.74087775321058 35.929 35.67137625076541 139.74090158869998 35.929 35.67136894367281 139.7408938094152 35.929 35.67138581710924 139.74086998497273 35.929 35.67139312419486 139.74087775321058 35.929</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2678647c-52e4-445b-aaa5-278958e2c740">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671397051217156 139.74087389348858 35.929 35.67137690590713 139.74085090707612 35.929 35.67138240773349 139.74084366533927 35.929 35.671402553044864 139.74086665175147 35.929 35.671397051217156 139.74087389348858 35.929</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ce0fd1c-9f3a-47c5-8af0-146ab38b678e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67138763895258 139.7408361698465 35.929 35.671392744208234 139.74082897275085 35.929 35.67141391675574 139.7408515271677 35.929 35.67140881149874 139.74085872426383 35.929 35.67138763895258 139.7408361698465 35.929</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0fd8c5e-777f-4d9f-b4d8-3b4530edc6bf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d0fd8c5e-777f-4d9f-b4d8-3b4530edc6bf_0">
											<gml:posList>35.671402553044864 139.74086665175147 35.929 35.67138240773349 139.74084366533927 35.929 35.67138240773349 139.74084366533927 37.189 35.671402553044864 139.74086665175147 37.189 35.671402553044864 139.74086665175147 35.929</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8dd5f0ba-4967-4f9c-9b7d-b78461561887">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8dd5f0ba-4967-4f9c-9b7d-b78461561887_0">
											<gml:posList>35.671392744208234 139.74082897275085 35.929 35.67138763895258 139.7408361698465 35.929 35.67138763895258 139.7408361698465 37.189 35.671392744208234 139.74082897275085 37.189 35.671392744208234 139.74082897275085 35.929</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-64b792d4-c5f0-45dc-8fed-3ff8afa547d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-64b792d4-c5f0-45dc-8fed-3ff8afa547d7_0">
											<gml:posList>35.671392744208234 139.74082897275085 35.929 35.671392744208234 139.74082897275085 37.189 35.67141391675574 139.7408515271677 37.189 35.67141391675574 139.7408515271677 35.929 35.671392744208234 139.74082897275085 35.929</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59630b51-d200-449e-9e5c-e2539007d153">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-59630b51-d200-449e-9e5c-e2539007d153_0">
											<gml:posList>35.67141391675574 139.7408515271677 37.189 35.671392744208234 139.74082897275085 37.189 35.67138763895258 139.7408361698465 37.189 35.67140881149874 139.74085872426383 37.189 35.67141391675574 139.7408515271677 37.189</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5184114e-ecb4-4447-8ce3-a2d6b27369bf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5184114e-ecb4-4447-8ce3-a2d6b27369bf_0">
											<gml:posList>35.67138240773349 139.74084366533927 35.929 35.67137690590713 139.74085090707612 35.929 35.67137690590713 139.74085090707612 37.189 35.67138240773349 139.74084366533927 37.189 35.67138240773349 139.74084366533927 35.929</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7aa13e27-4283-4253-8a5a-a1f8c5955c20">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7aa13e27-4283-4253-8a5a-a1f8c5955c20_0">
											<gml:posList>35.67140881149874 139.74085872426383 35.929 35.67140881149874 139.74085872426383 37.189 35.67138763895258 139.7408361698465 37.189 35.67138763895258 139.7408361698465 35.929 35.67140881149874 139.74085872426383 35.929</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-02c106dc-1ea1-4990-9348-523da4dd6afb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-02c106dc-1ea1-4990-9348-523da4dd6afb_0">
											<gml:posList>35.67141391675574 139.7408515271677 35.929 35.67141391675574 139.7408515271677 37.189 35.67140881149874 139.74085872426383 37.189 35.67140881149874 139.74085872426383 35.929 35.67141391675574 139.7408515271677 35.929</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5675ca4a-a4d5-4623-b430-2755660868fa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5675ca4a-a4d5-4623-b430-2755660868fa_0">
											<gml:posList>35.671397051217156 139.74087389348858 37.189 35.671402553044864 139.74086665175147 37.189 35.67138240773349 139.74084366533927 37.189 35.67137690590713 139.74085090707612 37.189 35.671397051217156 139.74087389348858 37.189</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f2192106-d5a0-4ee4-b2ba-ac7a4394b651">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f2192106-d5a0-4ee4-b2ba-ac7a4394b651_0">
											<gml:posList>35.671397051217156 139.74087389348858 35.929 35.671397051217156 139.74087389348858 37.189 35.67137690590713 139.74085090707612 37.189 35.67137690590713 139.74085090707612 35.929 35.671397051217156 139.74087389348858 35.929</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3323df75-f1a5-47fc-8ae4-3d7c3ddb6cf0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3323df75-f1a5-47fc-8ae4-3d7c3ddb6cf0_0">
											<gml:posList>35.671402553044864 139.74086665175147 35.929 35.671402553044864 139.74086665175147 37.189 35.671397051217156 139.74087389348858 37.189 35.671397051217156 139.74087389348858 35.929 35.671402553044864 139.74086665175147 35.929</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80b5551b-459e-4a00-8bd4-d0ac5bc39baa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-80b5551b-459e-4a00-8bd4-d0ac5bc39baa_0">
											<gml:posList>35.671336669748435 139.74087585205493 35.929 35.671336669748435 139.74087585205493 37.097 35.67134259422877 139.74086731740812 37.097 35.67134259422877 139.74086731740812 35.929 35.671336669748435 139.74087585205493 35.929</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4dcbc5a-003d-4614-b427-5c5d0d26894d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a4dcbc5a-003d-4614-b427-5c5d0d26894d_0">
											<gml:posList>35.67138581710924 139.74086998497273 35.929 35.67138581710924 139.74086998497273 38.261 35.67139312419486 139.74087775321058 38.261 35.67139312419486 139.74087775321058 35.929 35.67138581710924 139.74086998497273 35.929</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0595da2c-adb3-4c07-bc5b-304c42dc7135">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0595da2c-adb3-4c07-bc5b-304c42dc7135_0">
											<gml:posList>35.67136446123286 139.74089040124727 35.929 35.67134259422877 139.74086731740812 35.929 35.67134259422877 139.74086731740812 37.097 35.67136446123286 139.74089040124727 37.097 35.67136446123286 139.74089040124727 35.929</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-411756e9-d491-4256-8d47-c6730a042f81">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-411756e9-d491-4256-8d47-c6730a042f81_0">
											<gml:posList>35.67138581710924 139.74086998497273 35.929 35.67136894367281 139.7408938094152 35.929 35.67136894367281 139.7408938094152 38.261 35.67138581710924 139.74086998497273 38.261 35.67138581710924 139.74086998497273 35.929</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d11c576-df77-4459-9256-413c2d626fe2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d11c576-df77-4459-9256-413c2d626fe2_0">
											<gml:posList>35.67136446123286 139.74089040124727 37.097 35.67134259422877 139.74086731740812 37.097 35.671336669748435 139.74087585205493 37.097 35.67135853675092 139.7408989358947 37.097 35.67136446123286 139.74089040124727 37.097</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d9faf3a3-a24e-4214-9e07-6d02174ab793">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d9faf3a3-a24e-4214-9e07-6d02174ab793_0">
											<gml:posList>35.67136894367281 139.7408938094152 38.261 35.67137625076541 139.74090158869998 38.261 35.67139312419486 139.74087775321058 38.261 35.67138581710924 139.74086998497273 38.261 35.67136894367281 139.7408938094152 38.261</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53dfc1aa-ac63-4033-bffd-42dd69694c78">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-53dfc1aa-ac63-4033-bffd-42dd69694c78_0">
											<gml:posList>35.67135853675092 139.7408989358947 35.929 35.67135853675092 139.7408989358947 37.097 35.671336669748435 139.74087585205493 37.097 35.671336669748435 139.74087585205493 35.929 35.67135853675092 139.7408989358947 35.929</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b440d54-fa05-43dd-8ce5-251ec441f6d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2b440d54-fa05-43dd-8ce5-251ec441f6d4_0">
											<gml:posList>35.67137625076541 139.74090158869998 35.929 35.67139312419486 139.74087775321058 35.929 35.67139312419486 139.74087775321058 38.261 35.67137625076541 139.74090158869998 38.261 35.67137625076541 139.74090158869998 35.929</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa65cbf8-ddfa-4414-84f3-e062d395b05c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fa65cbf8-ddfa-4414-84f3-e062d395b05c_0">
											<gml:posList>35.67135853675092 139.7408989358947 35.929 35.67136446123286 139.74089040124727 35.929 35.67136446123286 139.74089040124727 37.097 35.67135853675092 139.7408989358947 37.097 35.67135853675092 139.7408989358947 35.929</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cfb263cc-2b81-4db3-b68c-d369c35f34a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cfb263cc-2b81-4db3-b68c-d369c35f34a5_0">
											<gml:posList>35.67137625076541 139.74090158869998 35.929 35.67137625076541 139.74090158869998 38.261 35.67136894367281 139.7408938094152 38.261 35.67136894367281 139.7408938094152 35.929 35.67137625076541 139.74090158869998 35.929</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_593485c2-6bbb-4e1f-8e7f-cf439242cda2_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37383fad-35ce-41df-8a02-74f42ec4dee7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671426399834864 139.74085030871038 32.82 35.67138428138546 139.7408069007659 32.82 35.67138541590899 139.74080533086806 32.82 35.67142666095281 139.74084994387786 32.82 35.671426399834864 139.74085030871038 32.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19333254-c4f8-425a-9ab5-639f80500a1d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671336444753166 139.74087630521643 32.82 35.671335235905154 139.7408749920899 32.82 35.67137884290351 139.74081446277782 32.82 35.671336444753166 139.74087630521643 32.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81c954f8-fd3e-495e-820d-44dd501ba1d5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67137648093199 139.74091961615414 32.316 35.671336444753166 139.74087630521643 32.316 35.67137884290351 139.74081446277782 32.316 35.67138428138546 139.7408069007659 32.316 35.671426399834864 139.74085030871038 32.316 35.67137648093199 139.74091961615414 32.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ae6ce9a0-1967-4e66-a66d-40bdae4fce92">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ae6ce9a0-1967-4e66-a66d-40bdae4fce92_0">
											<gml:posList>35.67138541590899 139.74080533086806 32.82 35.67138541590899 139.74080533086806 35.929 35.67142666095281 139.74084994387786 35.929 35.67142666095281 139.74084994387786 32.82 35.67138541590899 139.74080533086806 32.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9b84bfdc-dd5d-4f69-9718-6311301945c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9b84bfdc-dd5d-4f69-9718-6311301945c9_0">
											<gml:posList>35.67138428138546 139.7408069007659 32.82 35.671426399834864 139.74085030871038 32.82 35.671426399834864 139.74085030871038 32.316 35.67138428138546 139.7408069007659 32.316 35.67138428138546 139.7408069007659 32.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-600670eb-e243-4322-9bdb-71c187f8b988">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-600670eb-e243-4322-9bdb-71c187f8b988_0">
											<gml:posList>35.67138428138546 139.7408069007659 32.82 35.67138428138546 139.7408069007659 32.316 35.67137884290351 139.74081446277782 32.316 35.67137884290351 139.74081446277782 32.82 35.671335235905154 139.7408749920899 32.82 35.671335235905154 139.7408749920899 35.929 35.67138541590899 139.74080533086806 35.929 35.67138541590899 139.74080533086806 32.82 35.67138428138546 139.7408069007659 32.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b874ce10-6dec-4727-be56-9802305dfd51">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b874ce10-6dec-4727-be56-9802305dfd51_0">
											<gml:posList>35.671336444753166 139.74087630521643 32.316 35.671336444753166 139.74087630521643 32.82 35.67137884290351 139.74081446277782 32.82 35.67137884290351 139.74081446277782 32.316 35.671336444753166 139.74087630521643 32.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48ceebd9-7980-45f1-b9aa-4e4d663c355e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-48ceebd9-7980-45f1-b9aa-4e4d663c355e_0">
											<gml:posList>35.67138541590899 139.74080533086806 35.929 35.671335235905154 139.7408749920899 35.929 35.67137648093199 139.74091961615414 35.929 35.67142666095281 139.74084994387786 35.929 35.67138541590899 139.74080533086806 35.929</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b95b5824-b842-4785-ad38-7508fb2feee5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b95b5824-b842-4785-ad38-7508fb2feee5_0">
											<gml:posList>35.67142666095281 139.74084994387786 35.929 35.67137648093199 139.74091961615414 35.929 35.67137648093199 139.74091961615414 32.316 35.671426399834864 139.74085030871038 32.316 35.671426399834864 139.74085030871038 32.82 35.67142666095281 139.74084994387786 32.82 35.67142666095281 139.74084994387786 35.929</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b00f8970-be26-4cec-ae2f-2b1a3ac5bc76">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b00f8970-be26-4cec-ae2f-2b1a3ac5bc76_0">
											<gml:posList>35.67137648093199 139.74091961615414 32.316 35.67137648093199 139.74091961615414 35.929 35.671335235905154 139.7408749920899 35.929 35.671335235905154 139.7408749920899 32.82 35.671336444753166 139.74087630521643 32.82 35.671336444753166 139.74087630521643 32.316 35.67137648093199 139.74091961615414 32.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-e5ccbaed-f26c-4ba3-8a1a-57bff7b98ad1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5ccbaed-f26c-4ba3-8a1a-57bff7b98ad1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5ccbaed-f26c-4ba3-8a1a-57bff7b98ad1">
											<gml:posList>35.67138366336778 139.74080028468688 8.06 35.67146034075242 139.74087928847334 8.06 35.671391462840724 139.74097977966593 8.06 35.67131478552108 139.74090077585092 8.06 35.67138366336778 139.74080028468688 8.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-55f756df-89fd-49c4-9724-c29e01414e21">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-55f756df-89fd-49c4-9724-c29e01414e21">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-55f756df-89fd-49c4-9724-c29e01414e21">
											<gml:posList>35.67138366336778 139.74080028468688 32.82 35.67138412803336 139.74080674629332 32.82 35.67144393639629 139.74086837144824 32.82 35.67144919997685 139.74086780201102 32.82 35.67138366336778 139.74080028468688 32.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bdee41dd-8394-4968-86fa-c98d5ca1c21f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bdee41dd-8394-4968-86fa-c98d5ca1c21f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bdee41dd-8394-4968-86fa-c98d5ca1c21f">
											<gml:posList>35.67131478552108 139.74090077585092 32.82 35.67132005812412 139.74090021745275 32.82 35.67138412803336 139.74080674629332 32.82 35.67138366336778 139.74080028468688 32.82 35.67131478552108 139.74090077585092 32.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7e2425bc-87cb-4c52-816e-52b2e05d8a04">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e2425bc-87cb-4c52-816e-52b2e05d8a04">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e2425bc-87cb-4c52-816e-52b2e05d8a04">
											<gml:posList>35.67139101622033 139.74097332908352 32.316 35.6714202870811 139.74093061206344 32.316 35.67140893918129 139.7409193688593 32.316 35.67144393639629 139.74086837144824 32.316 35.67138412803336 139.74080674629332 32.316 35.67132005812412 139.74090021745275 32.316 35.67139101622033 139.74097332908352 32.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d3b2874d-db77-4b9b-9ef6-0ea4a3c79892">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3b2874d-db77-4b9b-9ef6-0ea4a3c79892">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3b2874d-db77-4b9b-9ef6-0ea4a3c79892">
											<gml:posList>35.67141424778835 139.74091874414177 32.82 35.67144919997685 139.74086780201102 32.82 35.67144393639629 139.74086837144824 32.82 35.67140893918129 139.7409193688593 32.82 35.67141424778835 139.74091874414177 32.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-889d4098-09a8-4a5e-ba9e-8863b9d49f24">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-889d4098-09a8-4a5e-ba9e-8863b9d49f24">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-889d4098-09a8-4a5e-ba9e-8863b9d49f24">
											<gml:posList>35.67141424778835 139.74091874414177 29.805 35.67142559568822 139.74092998734656 29.805 35.67146034075242 139.74087928847334 29.805 35.67144919997685 139.74086780201102 29.805 35.67141424778835 139.74091874414177 29.805</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b9e655fc-abef-47c1-80ac-315fea96ac86">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b9e655fc-abef-47c1-80ac-315fea96ac86">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b9e655fc-abef-47c1-80ac-315fea96ac86">
											<gml:posList>35.67141424778835 139.74091874414177 32.82 35.67140893918129 139.7409193688593 32.82 35.6714202870811 139.74093061206344 32.82 35.67142559568822 139.74092998734656 32.82 35.67141424778835 139.74091874414177 32.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ce9811dd-f072-4030-809e-986b950e5a10">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce9811dd-f072-4030-809e-986b950e5a10">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce9811dd-f072-4030-809e-986b950e5a10">
											<gml:posList>35.671391462840724 139.74097977966593 32.82 35.67139101622033 139.74097332908352 32.82 35.67132005812412 139.74090021745275 32.82 35.67131478552108 139.74090077585092 32.82 35.671391462840724 139.74097977966593 32.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3a7e75f4-5c6e-4553-a77b-74cbf23132a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a7e75f4-5c6e-4553-a77b-74cbf23132a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a7e75f4-5c6e-4553-a77b-74cbf23132a9">
											<gml:posList>35.67142559568822 139.74092998734656 32.82 35.6714202870811 139.74093061206344 32.82 35.67139101622033 139.74097332908352 32.82 35.671391462840724 139.74097977966593 32.82 35.67142559568822 139.74092998734656 32.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dc3b435f-00e6-40d1-ba05-7b87e84533c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc3b435f-00e6-40d1-ba05-7b87e84533c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc3b435f-00e6-40d1-ba05-7b87e84533c4">
											<gml:posList>35.67138366336778 139.74080028468688 8.06 35.67131478552108 139.74090077585092 8.06 35.67131478552108 139.74090077585092 32.82 35.67138366336778 139.74080028468688 32.82 35.67138366336778 139.74080028468688 8.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cbaa6ebb-7058-454d-8cdd-6f19ad8ef858">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cbaa6ebb-7058-454d-8cdd-6f19ad8ef858">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cbaa6ebb-7058-454d-8cdd-6f19ad8ef858">
											<gml:posList>35.67132005812412 139.74090021745275 32.82 35.67132005812412 139.74090021745275 32.316 35.67138412803336 139.74080674629332 32.316 35.67138412803336 139.74080674629332 32.82 35.67132005812412 139.74090021745275 32.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2c80719d-f74d-4978-8b62-43ace1bb4177">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c80719d-f74d-4978-8b62-43ace1bb4177">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c80719d-f74d-4978-8b62-43ace1bb4177">
											<gml:posList>35.67131478552108 139.74090077585092 8.06 35.671391462840724 139.74097977966593 8.06 35.671391462840724 139.74097977966593 32.82 35.67131478552108 139.74090077585092 32.82 35.67131478552108 139.74090077585092 8.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-80944585-3ceb-4540-92fc-25e0023bad51">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-80944585-3ceb-4540-92fc-25e0023bad51">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-80944585-3ceb-4540-92fc-25e0023bad51">
											<gml:posList>35.67139101622033 139.74097332908352 32.82 35.67139101622033 139.74097332908352 32.316 35.67132005812412 139.74090021745275 32.316 35.67132005812412 139.74090021745275 32.82 35.67139101622033 139.74097332908352 32.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-315b62bc-f73e-4809-ad39-45d196b103f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-315b62bc-f73e-4809-ad39-45d196b103f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-315b62bc-f73e-4809-ad39-45d196b103f9">
											<gml:posList>35.6714202870811 139.74093061206344 32.82 35.6714202870811 139.74093061206344 32.316 35.67139101622033 139.74097332908352 32.316 35.67139101622033 139.74097332908352 32.82 35.6714202870811 139.74093061206344 32.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5262a540-2f17-4137-b7c3-ec425ed87167">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5262a540-2f17-4137-b7c3-ec425ed87167">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5262a540-2f17-4137-b7c3-ec425ed87167">
											<gml:posList>35.67138412803336 139.74080674629332 32.82 35.67138412803336 139.74080674629332 32.316 35.67144393639629 139.74086837144824 32.316 35.67144393639629 139.74086837144824 32.82 35.67138412803336 139.74080674629332 32.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d371de93-7fc2-4adc-9c26-1b5fdeb8e613">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d371de93-7fc2-4adc-9c26-1b5fdeb8e613">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d371de93-7fc2-4adc-9c26-1b5fdeb8e613">
											<gml:posList>35.67140893918129 139.7409193688593 32.82 35.67140893918129 139.7409193688593 32.316 35.6714202870811 139.74093061206344 32.316 35.6714202870811 139.74093061206344 32.82 35.67140893918129 139.7409193688593 32.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ed21a7a4-f8a3-4d62-8916-221b56d5f202">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed21a7a4-f8a3-4d62-8916-221b56d5f202">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed21a7a4-f8a3-4d62-8916-221b56d5f202">
											<gml:posList>35.67141424778835 139.74091874414177 29.805 35.67141424778835 139.74091874414177 32.82 35.67142559568822 139.74092998734656 32.82 35.67142559568822 139.74092998734656 29.805 35.67141424778835 139.74091874414177 29.805</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1f1af1c4-0e57-4afe-b805-c997617e37f5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f1af1c4-0e57-4afe-b805-c997617e37f5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f1af1c4-0e57-4afe-b805-c997617e37f5">
											<gml:posList>35.67138366336778 139.74080028468688 8.06 35.67138366336778 139.74080028468688 32.82 35.67144919997685 139.74086780201102 32.82 35.67144919997685 139.74086780201102 29.805 35.67146034075242 139.74087928847334 29.805 35.67146034075242 139.74087928847334 8.06 35.67138366336778 139.74080028468688 8.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-29f88fb7-d9a7-437f-bed2-b5ffa3c8400a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-29f88fb7-d9a7-437f-bed2-b5ffa3c8400a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-29f88fb7-d9a7-437f-bed2-b5ffa3c8400a">
											<gml:posList>35.67142559568822 139.74092998734656 29.805 35.67142559568822 139.74092998734656 32.82 35.671391462840724 139.74097977966593 32.82 35.671391462840724 139.74097977966593 8.06 35.67146034075242 139.74087928847334 8.06 35.67146034075242 139.74087928847334 29.805 35.67142559568822 139.74092998734656 29.805</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e073f367-59e7-47ed-8264-cf7305d36321">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e073f367-59e7-47ed-8264-cf7305d36321">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e073f367-59e7-47ed-8264-cf7305d36321">
											<gml:posList>35.67144393639629 139.74086837144824 32.82 35.67144393639629 139.74086837144824 32.316 35.67140893918129 139.7409193688593 32.316 35.67140893918129 139.7409193688593 32.82 35.67144393639629 139.74086837144824 32.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ac4bbacc-a6ea-4f8a-b69e-ce90e9081431">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ac4bbacc-a6ea-4f8a-b69e-ce90e9081431">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ac4bbacc-a6ea-4f8a-b69e-ce90e9081431">
											<gml:posList>35.67144919997685 139.74086780201102 29.805 35.67144919997685 139.74086780201102 32.82 35.67141424778835 139.74091874414177 32.82 35.67141424778835 139.74091874414177 29.805 35.67144919997685 139.74086780201102 29.805</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-678</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">105.4482</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.03</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>