<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_5a19c9f4-d91a-4b4c-91bf-234fa37a22da">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">32.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>10</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67234218842392 139.7403389799534 0 35.67240589120849 139.74040094342232 0 35.67245486596776 139.7403233399043 0 35.67232910015217 139.74019859376483 0 35.672230519525414 139.7403534699509 0 35.67229357258264 139.74041448409727 0 35.67234218842392 139.7403389799534 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67234218842392 139.7403389799534 7.179 35.67229357258264 139.74041448409727 7.179 35.672230519525414 139.7403534699509 7.179 35.67232910015217 139.74019859376483 7.179 35.67245486596776 139.7403233399043 7.179 35.67240589120849 139.74040094342232 7.179 35.67234218842392 139.7403389799534 7.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67234218842392 139.7403389799534 7.179 35.67240589120849 139.74040094342232 7.179 35.67240589120849 139.74040094342232 38.78 35.67234218842392 139.7403389799534 38.78 35.67234218842392 139.7403389799534 7.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67240589120849 139.74040094342232 7.179 35.67245486596776 139.7403233399043 7.179 35.67245486596776 139.7403233399043 38.78 35.67240589120849 139.74040094342232 38.78 35.67240589120849 139.74040094342232 7.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67245486596776 139.7403233399043 7.179 35.67232910015217 139.74019859376483 7.179 35.67232910015217 139.74019859376483 38.78 35.67245486596776 139.7403233399043 38.78 35.67245486596776 139.7403233399043 7.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67232910015217 139.74019859376483 7.179 35.672230519525414 139.7403534699509 7.179 35.672230519525414 139.7403534699509 38.78 35.67232910015217 139.74019859376483 38.78 35.67232910015217 139.74019859376483 7.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672230519525414 139.7403534699509 7.179 35.67229357258264 139.74041448409727 7.179 35.67229357258264 139.74041448409727 38.78 35.672230519525414 139.7403534699509 38.78 35.672230519525414 139.7403534699509 7.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67229357258264 139.74041448409727 7.179 35.67234218842392 139.7403389799534 7.179 35.67234218842392 139.7403389799534 38.78 35.67229357258264 139.74041448409727 38.78 35.67229357258264 139.74041448409727 7.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67234218842392 139.7403389799534 38.78 35.67240589120849 139.74040094342232 38.78 35.67245486596776 139.7403233399043 38.78 35.67232910015217 139.74019859376483 38.78 35.672230519525414 139.7403534699509 38.78 35.67229357258264 139.74041448409727 38.78 35.67234218842392 139.7403389799534 38.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-f08a5da6-e526-4d7c-a9db-40bbeed67266"/>
							<gml:surfaceMember xlink:href="#poly-2d7dbff8-e8d8-49d5-a241-00d42886ff39"/>
							<gml:surfaceMember xlink:href="#poly-9d040787-f3fd-45ad-9c86-cf4e5a2aedff"/>
							<gml:surfaceMember xlink:href="#poly-effaffb9-f284-4c39-9f17-be6bce1dd703"/>
							<gml:surfaceMember xlink:href="#poly-f6b44a38-c521-47aa-acfa-adc80026b0a3"/>
							<gml:surfaceMember xlink:href="#poly-0148484f-6463-4393-9e67-42792f0f7af4"/>
							<gml:surfaceMember xlink:href="#poly-e0a8d85c-0557-4a42-8889-57745b5250ba"/>
							<gml:surfaceMember xlink:href="#poly-7585d25d-40e2-434b-b61f-987e8cd22e72"/>
							<gml:surfaceMember xlink:href="#poly-d2ab064c-fa23-4c08-9e9a-d107318e114f"/>
							<gml:surfaceMember xlink:href="#poly-beee7549-35c7-4484-826c-14f556063cbb"/>
							<gml:surfaceMember xlink:href="#poly-4f84681b-7b3f-4cab-98da-c1b6887dc15a"/>
							<gml:surfaceMember xlink:href="#poly-f51ad614-229f-44cc-a6f5-3f597267bfef"/>
							<gml:surfaceMember xlink:href="#poly-f69790c8-2d36-44b5-b2fb-fb133b5ef161"/>
							<gml:surfaceMember xlink:href="#poly-94a03bc3-b96c-4098-80da-b1eea63f4eda"/>
							<gml:surfaceMember xlink:href="#poly-81318b71-4740-4863-933e-3268debfd17e"/>
							<gml:surfaceMember xlink:href="#poly-ffe09b21-f358-4b43-b6e9-901fcd2472c4"/>
							<gml:surfaceMember xlink:href="#poly-38c24c4a-625c-49d3-9e03-4443f05cbb80"/>
							<gml:surfaceMember xlink:href="#poly-5073095f-1af3-4d71-83b2-bb44900cd447"/>
							<gml:surfaceMember xlink:href="#poly-9f65452f-711e-4c7b-ab9d-efc4d6ff550b"/>
							<gml:surfaceMember xlink:href="#poly-e984e19f-36c4-4e5b-94bf-05364c76cd0d"/>
							<gml:surfaceMember xlink:href="#poly-d5c976dd-a8f6-4de9-b3ba-bced00637e12"/>
							<gml:surfaceMember xlink:href="#poly-60dbc7b0-555e-424d-9e9d-37d422d0968a"/>
							<gml:surfaceMember xlink:href="#poly-ae52492c-a8a7-4fc2-ac09-d4fe410487f4"/>
							<gml:surfaceMember xlink:href="#poly-9b69e474-6724-4125-9e74-39ff4e586d22"/>
							<gml:surfaceMember xlink:href="#poly-4b2ffcb3-0c6c-437d-a9b0-ace9cf305635"/>
							<gml:surfaceMember xlink:href="#poly-e3daf1f4-2b21-467f-8984-f42410ecd8dc"/>
							<gml:surfaceMember xlink:href="#poly-7b703516-03a8-43b6-8be0-414b9873b90b"/>
							<gml:surfaceMember xlink:href="#poly-ada837ea-1696-4158-97fa-c8519da8473a"/>
							<gml:surfaceMember xlink:href="#poly-d668f4e8-efc3-43de-aa50-32cb3d4611ef"/>
							<gml:surfaceMember xlink:href="#poly-8ee84cea-a899-4697-b859-ba0d3720324c"/>
							<gml:surfaceMember xlink:href="#poly-c109af0e-d713-4ad9-ad7b-2b68280fd4e2"/>
							<gml:surfaceMember xlink:href="#poly-645db6b8-afcc-4ad6-9520-e203896b6c72"/>
							<gml:surfaceMember xlink:href="#poly-62aa2558-bbfe-4e08-822d-e7426ca30084"/>
							<gml:surfaceMember xlink:href="#poly-b8024ce5-e1f2-4ec2-a80b-2ecad03fc800"/>
							<gml:surfaceMember xlink:href="#poly-0d1e77f8-7408-4e00-b266-999157337a2d"/>
							<gml:surfaceMember xlink:href="#poly-6d8899fd-8502-4ef3-8002-6f507a132559"/>
							<gml:surfaceMember xlink:href="#poly-ce4d6f0b-0611-4edd-84f5-6b05381a577a"/>
							<gml:surfaceMember xlink:href="#poly-86217414-5bf4-4dd9-b1df-bbc630c4dc31"/>
							<gml:surfaceMember xlink:href="#poly-0bee9c89-6a5d-4dcc-9f55-20b1ce47a430"/>
							<gml:surfaceMember xlink:href="#poly-67acc448-a4ca-4dc7-b9b9-d082becd3319"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_5a19c9f4-d91a-4b4c-91bf-234fa37a22da_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af32e161-8d04-4483-be5a-3136d8f713ce">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67235610138272 139.74028682418574 38.923 35.67237183866812 139.74026261401207 38.923 35.67239755622206 139.74028773712232 38.923 35.67238180990943 139.74031193626277 38.923 35.67235610138272 139.74028682418574 38.923</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-561bc47f-d239-4afb-857e-d921504b7109">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67234818584305 139.74029656536587 38.923 35.67232272525209 139.7403356996179 38.923 35.67228061738661 139.74029455598432 38.923 35.67230606895068 139.74025542175028 38.923 35.67234818584305 139.74029656536587 38.923</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3056b3ea-fefd-4590-8bc5-ca3966f44051">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3056b3ea-fefd-4590-8bc5-ca3966f44051_0">
											<gml:posList>35.67237183866812 139.74026261401207 38.923 35.67235610138272 139.74028682418574 38.923 35.67235610138272 139.74028682418574 40.89 35.67237183866812 139.74026261401207 40.89 35.67237183866812 139.74026261401207 38.923</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb1ed43f-f987-4222-adb8-a1654c2b611e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb1ed43f-f987-4222-adb8-a1654c2b611e_0">
											<gml:posList>35.67230606895068 139.74025542175028 38.923 35.67228061738661 139.74029455598432 38.923 35.67228061738661 139.74029455598432 42.059 35.6722933386634 139.74027498887565 43.084 35.67230606895068 139.74025542175028 42.059 35.67230606895068 139.74025542175028 38.923</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a7545050-d9f3-46ec-b840-2da9b190e230">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a7545050-d9f3-46ec-b840-2da9b190e230_0">
											<gml:posList>35.67237183866812 139.74026261401207 38.923 35.67237183866812 139.74026261401207 40.89 35.67239755622206 139.74028773712232 40.89 35.67239755622206 139.74028773712232 38.923 35.67237183866812 139.74026261401207 38.923</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f619d7f9-2117-4e43-9462-304ead0b70d9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f619d7f9-2117-4e43-9462-304ead0b70d9_0">
											<gml:posList>35.67230606895068 139.74025542175028 38.923 35.67230606895068 139.74025542175028 42.059 35.67234818584305 139.74029656536587 42.059 35.67234818584305 139.74029656536587 38.923 35.67230606895068 139.74025542175028 38.923</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d0917e7-a435-42b2-8259-713b85441148">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8d0917e7-a435-42b2-8259-713b85441148_0">
											<gml:posList>35.67234818584305 139.74029656536587 42.059 35.67230606895068 139.74025542175028 42.059 35.6722933386634 139.74027498887565 43.084 35.67233544654399 139.74031614355195 43.084 35.67234818584305 139.74029656536587 42.059</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1dac8686-34a8-4f3e-8a39-be169edbb4f5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1dac8686-34a8-4f3e-8a39-be169edbb4f5_0">
											<gml:posList>35.67239755622206 139.74028773712232 40.89 35.67237183866812 139.74026261401207 40.89 35.67235610138272 139.74028682418574 40.89 35.67238180990943 139.74031193626277 40.89 35.67239755622206 139.74028773712232 40.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a4c2de1-f683-4311-9784-508bcd131edd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0a4c2de1-f683-4311-9784-508bcd131edd_0">
											<gml:posList>35.67238180990943 139.74031193626277 38.923 35.67238180990943 139.74031193626277 40.89 35.67235610138272 139.74028682418574 40.89 35.67235610138272 139.74028682418574 38.923 35.67238180990943 139.74031193626277 38.923</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b52c6786-aff7-4949-aec3-6fcfc4a95e9f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b52c6786-aff7-4949-aec3-6fcfc4a95e9f_0">
											<gml:posList>35.67238180990943 139.74031193626277 38.923 35.67239755622206 139.74028773712232 38.923 35.67239755622206 139.74028773712232 40.89 35.67238180990943 139.74031193626277 40.89 35.67238180990943 139.74031193626277 38.923</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f59c25b8-c660-499f-804d-07e5bfe247ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f59c25b8-c660-499f-804d-07e5bfe247ce_0">
											<gml:posList>35.6722933386634 139.74027498887565 43.084 35.67228061738661 139.74029455598432 42.059 35.67232272525209 139.7403356996179 42.059 35.67233544654399 139.74031614355195 43.084 35.6722933386634 139.74027498887565 43.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81ed811d-339b-487b-aaad-8ebf8e16825f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81ed811d-339b-487b-aaad-8ebf8e16825f_0">
											<gml:posList>35.67232272525209 139.7403356996179 42.059 35.67228061738661 139.74029455598432 42.059 35.67228061738661 139.74029455598432 38.923 35.67232272525209 139.7403356996179 38.923 35.67232272525209 139.7403356996179 42.059</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-046e4bca-0f51-4c0a-a203-e396163b39e6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-046e4bca-0f51-4c0a-a203-e396163b39e6_0">
											<gml:posList>35.67233544654399 139.74031614355195 43.084 35.67232272525209 139.7403356996179 42.059 35.67232272525209 139.7403356996179 38.923 35.67234818584305 139.74029656536587 38.923 35.67234818584305 139.74029656536587 42.059 35.67233544654399 139.74031614355195 43.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_5a19c9f4-d91a-4b4c-91bf-234fa37a22da_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0248b12a-d6df-47b4-950d-d5e6751944ef">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67241630710957 139.740349100983 38.923 35.67241073422791 139.74035766851438 38.923 35.67235760327592 139.74030575619827 38.923 35.67236317615394 139.74029718866896 38.923 35.67241630710957 139.740349100983 38.923</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35f87539-3b40-42c1-8ef0-0397688f593b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-35f87539-3b40-42c1-8ef0-0397688f593b_0">
											<gml:posList>35.67235760327592 139.74030575619827 38.923 35.67235760327592 139.74030575619827 39.592 35.67236317615394 139.74029718866896 39.592 35.67236317615394 139.74029718866896 38.923 35.67235760327592 139.74030575619827 38.923</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b929835a-5e8d-4806-bad0-3d4a35a8ca77">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b929835a-5e8d-4806-bad0-3d4a35a8ca77_0">
											<gml:posList>35.67236317615394 139.74029718866896 38.923 35.67236317615394 139.74029718866896 39.592 35.67241630710957 139.740349100983 39.592 35.67241630710957 139.740349100983 38.923 35.67236317615394 139.74029718866896 38.923</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-87bd90ca-291e-4a1d-9d87-c2f8957715b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-87bd90ca-291e-4a1d-9d87-c2f8957715b0_0">
											<gml:posList>35.67241630710957 139.740349100983 39.592 35.67236317615394 139.74029718866896 39.592 35.67235760327592 139.74030575619827 39.592 35.67241073422791 139.74035766851438 39.592 35.67241630710957 139.740349100983 39.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb3180bc-6a29-468b-b7f7-22877aacb001">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb3180bc-6a29-468b-b7f7-22877aacb001_0">
											<gml:posList>35.67241073422791 139.74035766851438 39.592 35.67235760327592 139.74030575619827 39.592 35.67235760327592 139.74030575619827 38.923 35.67241073422791 139.74035766851438 38.923 35.67241073422791 139.74035766851438 39.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f0b13bb-63ea-4bc0-9e92-8ea5c2ed6a10">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1f0b13bb-63ea-4bc0-9e92-8ea5c2ed6a10_0">
											<gml:posList>35.67241630710957 139.740349100983 38.923 35.67241630710957 139.740349100983 39.592 35.67241073422791 139.74035766851438 39.592 35.67241073422791 139.74035766851438 38.923 35.67241630710957 139.740349100983 38.923</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_5a19c9f4-d91a-4b4c-91bf-234fa37a22da_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d0d493e-a20a-4e2c-a1d3-dd825478065a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6723335455049 139.74028225500797 38.923 35.672320249233785 139.74026926867828 38.923 35.672324930818306 139.74026208300108 38.923 35.67233822709017 139.74027506933032 38.923 35.6723335455049 139.74028225500797 38.923</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd55a15b-d409-46ab-b3fa-c4d1ed7e0d6d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bd55a15b-d409-46ab-b3fa-c4d1ed7e0d6d_0">
											<gml:posList>35.672320249233785 139.74026926867828 38.923 35.672320249233785 139.74026926867828 40.583 35.672324930818306 139.74026208300108 40.583 35.672324930818306 139.74026208300108 38.923 35.672320249233785 139.74026926867828 38.923</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0236a894-e685-4a19-a990-96abae9332fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0236a894-e685-4a19-a990-96abae9332fd_0">
											<gml:posList>35.672324930818306 139.74026208300108 38.923 35.672324930818306 139.74026208300108 40.583 35.67233822709017 139.74027506933032 40.583 35.67233822709017 139.74027506933032 38.923 35.672324930818306 139.74026208300108 38.923</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa59b19c-ed3d-4800-925c-95134337da07">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aa59b19c-ed3d-4800-925c-95134337da07_0">
											<gml:posList>35.672324930818306 139.74026208300108 40.583 35.672320249233785 139.74026926867828 40.583 35.6723335455049 139.74028225500797 40.583 35.67233822709017 139.74027506933032 40.583 35.672324930818306 139.74026208300108 40.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa038259-7104-417b-9877-74a0de2f0599">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aa038259-7104-417b-9877-74a0de2f0599_0">
											<gml:posList>35.6723335455049 139.74028225500797 38.923 35.6723335455049 139.74028225500797 40.583 35.672320249233785 139.74026926867828 40.583 35.672320249233785 139.74026926867828 38.923 35.6723335455049 139.74028225500797 38.923</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f57b02f-2353-42f9-ba09-5a8363059703">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f57b02f-2353-42f9-ba09-5a8363059703_0">
											<gml:posList>35.67233822709017 139.74027506933032 38.923 35.67233822709017 139.74027506933032 40.583 35.6723335455049 139.74028225500797 40.583 35.6723335455049 139.74028225500797 38.923 35.67233822709017 139.74027506933032 38.923</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-f08a5da6-e526-4d7c-a9db-40bbeed67266">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f08a5da6-e526-4d7c-a9db-40bbeed67266">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f08a5da6-e526-4d7c-a9db-40bbeed67266">
											<gml:posList>35.67234218842391 139.7403389799534 7.179 35.67229357258263 139.74041448409727 7.179 35.67223051952538 139.7403534699509 7.179 35.67232910015217 139.74019859376483 7.179 35.672454865967744 139.7403233399043 7.179 35.67240589120847 139.74040094342232 7.179 35.67234218842391 139.7403389799534 7.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2d7dbff8-e8d8-49d5-a241-00d42886ff39">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d7dbff8-e8d8-49d5-a241-00d42886ff39">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d7dbff8-e8d8-49d5-a241-00d42886ff39">
											<gml:posList>35.672445827598985 139.7403147782719 39.679 35.67232910015217 139.74019859376483 39.679 35.67232951820943 139.74020302293692 39.679 35.67244423405653 139.740317221407 39.679 35.672445827598985 139.7403147782719 39.679</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9d040787-f3fd-45ad-9c86-cf4e5a2aedff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d040787-f3fd-45ad-9c86-cf4e5a2aedff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d040787-f3fd-45ad-9c86-cf4e5a2aedff">
											<gml:posList>35.67223051952538 139.7403534699509 39.679 35.67223408854901 139.740352935579 39.679 35.67232951820943 139.74020302293692 39.679 35.67232910015217 139.74019859376483 39.679 35.67223051952538 139.7403534699509 39.679</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-effaffb9-f284-4c39-9f17-be6bce1dd703">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-effaffb9-f284-4c39-9f17-be6bce1dd703">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-effaffb9-f284-4c39-9f17-be6bce1dd703">
											<gml:posList>35.67232951820943 139.74020302293692 38.923 35.67223408854901 139.740352935579 38.923 35.67229315455872 139.74041008806563 38.923 35.67233861937481 139.7403394811871 38.923 35.67234021292629 139.7403370491022 38.923 35.6723289913781 139.74032608187002 38.923 35.67234818584305 139.74029656536587 38.923 35.67241073422791 139.74035766851438 38.923 35.67239313329209 139.74038474189493 38.923 35.67239510878894 139.74038667274854 38.923 35.67239840128644 139.74038989452038 38.923 35.672405428115475 139.7403965474368 38.923 35.67245128795625 139.7403239074291 38.923 35.67244423405653 139.740317221407 38.923 35.67232951820943 139.74020302293692 38.923</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f6b44a38-c521-47aa-acfa-adc80026b0a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f6b44a38-c521-47aa-acfa-adc80026b0a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f6b44a38-c521-47aa-acfa-adc80026b0a3">
											<gml:posList>35.6723289913781 139.74032608187002 46.522 35.6723331733089 139.74032551364562 46.522 35.672348658525266 139.7403017014541 46.522 35.67234818584305 139.74029656536587 46.522 35.6723289913781 139.74032608187002 46.522</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0148484f-6463-4393-9e67-42792f0f7af4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0148484f-6463-4393-9e67-42792f0f7af4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0148484f-6463-4393-9e67-42792f0f7af4">
											<gml:posList>35.672445827598985 139.7403147782719 39.679 35.67244423405653 139.740317221407 39.679 35.67245128795625 139.7403239074291 39.679 35.672454865967744 139.7403233399043 39.679 35.672445827598985 139.7403147782719 39.679</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e0a8d85c-0557-4a42-8889-57745b5250ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e0a8d85c-0557-4a42-8889-57745b5250ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e0a8d85c-0557-4a42-8889-57745b5250ba">
											<gml:posList>35.67234818584305 139.74029656536587 46.522 35.672348658525266 139.7403017014541 46.522 35.67240655229701 139.74035823673768 46.522 35.67241073422791 139.74035766851438 46.522 35.67234818584305 139.74029656536587 46.522</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7585d25d-40e2-434b-b61f-987e8cd22e72">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7585d25d-40e2-434b-b61f-987e8cd22e72">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7585d25d-40e2-434b-b61f-987e8cd22e72">
											<gml:posList>35.67240655229701 139.74035823673768 46.353 35.672348658525266 139.7403017014541 46.353 35.6723331733089 139.74032551364562 46.353 35.67239106706963 139.74038204893552 46.353 35.67240655229701 139.74035823673768 46.353</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d2ab064c-fa23-4c08-9e9a-d107318e114f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d2ab064c-fa23-4c08-9e9a-d107318e114f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d2ab064c-fa23-4c08-9e9a-d107318e114f">
											<gml:posList>35.67239153974818 139.740387185027 46.522 35.67239106706963 139.74038204893552 46.522 35.6723331733089 139.74032551364562 46.522 35.6723289913781 139.74032608187002 46.522 35.67239153974818 139.740387185027 46.522</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-beee7549-35c7-4484-826c-14f556063cbb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-beee7549-35c7-4484-826c-14f556063cbb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-beee7549-35c7-4484-826c-14f556063cbb">
											<gml:posList>35.672454865967744 139.7403233399043 39.679 35.67245128795625 139.7403239074291 39.679 35.672405428115475 139.7403965474368 39.679 35.67240589120847 139.74040094342232 39.679 35.672454865967744 139.7403233399043 39.679</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4f84681b-7b3f-4cab-98da-c1b6887dc15a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f84681b-7b3f-4cab-98da-c1b6887dc15a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f84681b-7b3f-4cab-98da-c1b6887dc15a">
											<gml:posList>35.67241073422791 139.74035766851438 46.522 35.67240655229701 139.74035823673768 46.522 35.67239106706963 139.74038204893552 46.522 35.67239153974818 139.740387185027 46.522 35.67241073422791 139.74035766851438 46.522</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f51ad614-229f-44cc-a6f5-3f597267bfef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f51ad614-229f-44cc-a6f5-3f597267bfef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f51ad614-229f-44cc-a6f5-3f597267bfef">
											<gml:posList>35.67233861937481 139.7403394811871 39.679 35.67229315455872 139.74041008806563 39.679 35.67229357258263 139.74041448409727 39.679 35.67234218842391 139.7403389799534 39.679 35.67234021292629 139.7403370491022 39.679 35.67233861937481 139.7403394811871 39.679</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f69790c8-2d36-44b5-b2fb-fb133b5ef161">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f69790c8-2d36-44b5-b2fb-fb133b5ef161">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f69790c8-2d36-44b5-b2fb-fb133b5ef161">
											<gml:posList>35.67229357258263 139.74041448409727 39.679 35.67229315455872 139.74041008806563 39.679 35.67223408854901 139.740352935579 39.679 35.67223051952538 139.7403534699509 39.679 35.67229357258263 139.74041448409727 39.679</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-94a03bc3-b96c-4098-80da-b1eea63f4eda">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-94a03bc3-b96c-4098-80da-b1eea63f4eda">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-94a03bc3-b96c-4098-80da-b1eea63f4eda">
											<gml:posList>35.67239153974818 139.740387185027 39.679 35.672396852845154 139.74039238178636 39.679 35.67239840128644 139.74038989452038 39.679 35.67239510878894 139.74038667274854 39.679 35.67239313329209 139.74038474189493 39.679 35.67239153974818 139.740387185027 39.679</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-81318b71-4740-4863-933e-3268debfd17e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-81318b71-4740-4863-933e-3268debfd17e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-81318b71-4740-4863-933e-3268debfd17e">
											<gml:posList>35.672396852845154 139.74039238178636 39.679 35.67240589120847 139.74040094342232 39.679 35.672405428115475 139.7403965474368 39.679 35.67239840128644 139.74038989452038 39.679 35.672396852845154 139.74039238178636 39.679</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ffe09b21-f358-4b43-b6e9-901fcd2472c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ffe09b21-f358-4b43-b6e9-901fcd2472c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ffe09b21-f358-4b43-b6e9-901fcd2472c4">
											<gml:posList>35.672348658525266 139.7403017014541 46.522 35.672348658525266 139.7403017014541 46.353 35.67240655229701 139.74035823673768 46.353 35.67240655229701 139.74035823673768 46.522 35.672348658525266 139.7403017014541 46.522</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-38c24c4a-625c-49d3-9e03-4443f05cbb80">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38c24c4a-625c-49d3-9e03-4443f05cbb80">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38c24c4a-625c-49d3-9e03-4443f05cbb80">
											<gml:posList>35.67239106706963 139.74038204893552 46.522 35.67239106706963 139.74038204893552 46.353 35.6723331733089 139.74032551364562 46.353 35.6723331733089 139.74032551364562 46.522 35.67239106706963 139.74038204893552 46.522</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5073095f-1af3-4d71-83b2-bb44900cd447">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5073095f-1af3-4d71-83b2-bb44900cd447">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5073095f-1af3-4d71-83b2-bb44900cd447">
											<gml:posList>35.67233861937481 139.7403394811871 39.679 35.67233861937481 139.7403394811871 38.923 35.67229315455872 139.74041008806563 38.923 35.67229315455872 139.74041008806563 39.679 35.67233861937481 139.7403394811871 39.679</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9f65452f-711e-4c7b-ab9d-efc4d6ff550b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f65452f-711e-4c7b-ab9d-efc4d6ff550b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f65452f-711e-4c7b-ab9d-efc4d6ff550b">
											<gml:posList>35.672445827598985 139.7403147782719 39.679 35.67232910015217 139.74019859376483 7.179 35.67232910015217 139.74019859376483 39.679 35.672445827598985 139.7403147782719 39.679</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e984e19f-36c4-4e5b-94bf-05364c76cd0d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e984e19f-36c4-4e5b-94bf-05364c76cd0d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e984e19f-36c4-4e5b-94bf-05364c76cd0d">
											<gml:posList>35.67232951820943 139.74020302293692 39.679 35.67232951820943 139.74020302293692 38.923 35.67244423405653 139.740317221407 38.923 35.67244423405653 139.740317221407 39.679 35.67232951820943 139.74020302293692 39.679</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d5c976dd-a8f6-4de9-b3ba-bced00637e12">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5c976dd-a8f6-4de9-b3ba-bced00637e12">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5c976dd-a8f6-4de9-b3ba-bced00637e12">
											<gml:posList>35.672445827598985 139.7403147782719 39.679 35.672454865967744 139.7403233399043 7.179 35.67232910015217 139.74019859376483 7.179 35.672445827598985 139.7403147782719 39.679</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-60dbc7b0-555e-424d-9e9d-37d422d0968a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-60dbc7b0-555e-424d-9e9d-37d422d0968a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-60dbc7b0-555e-424d-9e9d-37d422d0968a">
											<gml:posList>35.67232910015217 139.74019859376483 7.179 35.67223051952538 139.7403534699509 7.179 35.67223051952538 139.7403534699509 39.679 35.67232910015217 139.74019859376483 39.679 35.67232910015217 139.74019859376483 7.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ae52492c-a8a7-4fc2-ac09-d4fe410487f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ae52492c-a8a7-4fc2-ac09-d4fe410487f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ae52492c-a8a7-4fc2-ac09-d4fe410487f4">
											<gml:posList>35.67223408854901 139.740352935579 39.679 35.67223408854901 139.740352935579 38.923 35.67232951820943 139.74020302293692 38.923 35.67232951820943 139.74020302293692 39.679 35.67223408854901 139.740352935579 39.679</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9b69e474-6724-4125-9e74-39ff4e586d22">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b69e474-6724-4125-9e74-39ff4e586d22">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b69e474-6724-4125-9e74-39ff4e586d22">
											<gml:posList>35.6723289913781 139.74032608187002 46.522 35.67234818584305 139.74029656536587 46.522 35.67234818584305 139.74029656536587 38.923 35.6723289913781 139.74032608187002 38.923 35.6723289913781 139.74032608187002 46.522</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4b2ffcb3-0c6c-437d-a9b0-ace9cf305635">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b2ffcb3-0c6c-437d-a9b0-ace9cf305635">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b2ffcb3-0c6c-437d-a9b0-ace9cf305635">
											<gml:posList>35.6723331733089 139.74032551364562 46.522 35.6723331733089 139.74032551364562 46.353 35.672348658525266 139.7403017014541 46.353 35.672348658525266 139.7403017014541 46.522 35.6723331733089 139.74032551364562 46.522</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e3daf1f4-2b21-467f-8984-f42410ecd8dc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e3daf1f4-2b21-467f-8984-f42410ecd8dc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e3daf1f4-2b21-467f-8984-f42410ecd8dc">
											<gml:posList>35.672445827598985 139.7403147782719 39.679 35.672454865967744 139.7403233399043 39.679 35.672454865967744 139.7403233399043 7.179 35.672445827598985 139.7403147782719 39.679</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7b703516-03a8-43b6-8be0-414b9873b90b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b703516-03a8-43b6-8be0-414b9873b90b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b703516-03a8-43b6-8be0-414b9873b90b">
											<gml:posList>35.67244423405653 139.740317221407 39.679 35.67244423405653 139.740317221407 38.923 35.67245128795625 139.7403239074291 38.923 35.67245128795625 139.7403239074291 39.679 35.67244423405653 139.740317221407 39.679</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ada837ea-1696-4158-97fa-c8519da8473a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ada837ea-1696-4158-97fa-c8519da8473a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ada837ea-1696-4158-97fa-c8519da8473a">
											<gml:posList>35.67234818584305 139.74029656536587 46.522 35.67241073422791 139.74035766851438 46.522 35.67241073422791 139.74035766851438 38.923 35.67234818584305 139.74029656536587 38.923 35.67234818584305 139.74029656536587 46.522</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d668f4e8-efc3-43de-aa50-32cb3d4611ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d668f4e8-efc3-43de-aa50-32cb3d4611ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d668f4e8-efc3-43de-aa50-32cb3d4611ef">
											<gml:posList>35.67234021292629 139.7403370491022 39.679 35.67234021292629 139.7403370491022 38.923 35.67233861937481 139.7403394811871 38.923 35.67233861937481 139.7403394811871 39.679 35.67234021292629 139.7403370491022 39.679</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8ee84cea-a899-4697-b859-ba0d3720324c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ee84cea-a899-4697-b859-ba0d3720324c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ee84cea-a899-4697-b859-ba0d3720324c">
											<gml:posList>35.67245128795625 139.7403239074291 39.679 35.67245128795625 139.7403239074291 38.923 35.672405428115475 139.7403965474368 38.923 35.672405428115475 139.7403965474368 39.679 35.67245128795625 139.7403239074291 39.679</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c109af0e-d713-4ad9-ad7b-2b68280fd4e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c109af0e-d713-4ad9-ad7b-2b68280fd4e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c109af0e-d713-4ad9-ad7b-2b68280fd4e2">
											<gml:posList>35.67240589120847 139.74040094342232 7.179 35.672454865967744 139.7403233399043 7.179 35.672454865967744 139.7403233399043 39.679 35.67240589120847 139.74040094342232 39.679 35.67240589120847 139.74040094342232 7.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-645db6b8-afcc-4ad6-9520-e203896b6c72">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-645db6b8-afcc-4ad6-9520-e203896b6c72">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-645db6b8-afcc-4ad6-9520-e203896b6c72">
											<gml:posList>35.6723289913781 139.74032608187002 46.522 35.6723289913781 139.74032608187002 38.923 35.67234021292629 139.7403370491022 38.923 35.67234021292629 139.7403370491022 39.679 35.67234218842391 139.7403389799534 39.679 35.67234218842391 139.7403389799534 7.179 35.67240589120847 139.74040094342232 7.179 35.67240589120847 139.74040094342232 39.679 35.672396852845154 139.74039238178636 39.679 35.67239153974818 139.740387185027 39.679 35.67239153974818 139.740387185027 46.522 35.6723289913781 139.74032608187002 46.522</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-62aa2558-bbfe-4e08-822d-e7426ca30084">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-62aa2558-bbfe-4e08-822d-e7426ca30084">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-62aa2558-bbfe-4e08-822d-e7426ca30084">
											<gml:posList>35.67240655229701 139.74035823673768 46.522 35.67240655229701 139.74035823673768 46.353 35.67239106706963 139.74038204893552 46.353 35.67239106706963 139.74038204893552 46.522 35.67240655229701 139.74035823673768 46.522</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b8024ce5-e1f2-4ec2-a80b-2ecad03fc800">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8024ce5-e1f2-4ec2-a80b-2ecad03fc800">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8024ce5-e1f2-4ec2-a80b-2ecad03fc800">
											<gml:posList>35.67239153974818 139.740387185027 46.522 35.67239153974818 139.740387185027 39.679 35.67239313329209 139.74038474189493 39.679 35.67239313329209 139.74038474189493 38.923 35.67241073422791 139.74035766851438 38.923 35.67241073422791 139.74035766851438 46.522 35.67239153974818 139.740387185027 46.522</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0d1e77f8-7408-4e00-b266-999157337a2d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d1e77f8-7408-4e00-b266-999157337a2d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d1e77f8-7408-4e00-b266-999157337a2d">
											<gml:posList>35.67229357258263 139.74041448409727 7.179 35.67234218842391 139.7403389799534 7.179 35.67234218842391 139.7403389799534 39.679 35.67229357258263 139.74041448409727 39.679 35.67229357258263 139.74041448409727 7.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6d8899fd-8502-4ef3-8002-6f507a132559">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d8899fd-8502-4ef3-8002-6f507a132559">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d8899fd-8502-4ef3-8002-6f507a132559">
											<gml:posList>35.67229315455872 139.74041008806563 39.679 35.67229315455872 139.74041008806563 38.923 35.67223408854901 139.740352935579 38.923 35.67223408854901 139.740352935579 39.679 35.67229315455872 139.74041008806563 39.679</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ce4d6f0b-0611-4edd-84f5-6b05381a577a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce4d6f0b-0611-4edd-84f5-6b05381a577a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce4d6f0b-0611-4edd-84f5-6b05381a577a">
											<gml:posList>35.67223051952538 139.7403534699509 7.179 35.67229357258263 139.74041448409727 7.179 35.67229357258263 139.74041448409727 39.679 35.67223051952538 139.7403534699509 39.679 35.67223051952538 139.7403534699509 7.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-86217414-5bf4-4dd9-b1df-bbc630c4dc31">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-86217414-5bf4-4dd9-b1df-bbc630c4dc31">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-86217414-5bf4-4dd9-b1df-bbc630c4dc31">
											<gml:posList>35.67239510878894 139.74038667274854 39.679 35.67239510878894 139.74038667274854 38.923 35.67239313329209 139.74038474189493 38.923 35.67239313329209 139.74038474189493 39.679 35.67239510878894 139.74038667274854 39.679</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0bee9c89-6a5d-4dcc-9f55-20b1ce47a430">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0bee9c89-6a5d-4dcc-9f55-20b1ce47a430">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0bee9c89-6a5d-4dcc-9f55-20b1ce47a430">
											<gml:posList>35.67239840128644 139.74038989452038 39.679 35.67239840128644 139.74038989452038 38.923 35.67239510878894 139.74038667274854 38.923 35.67239510878894 139.74038667274854 39.679 35.67239840128644 139.74038989452038 39.679</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-67acc448-a4ca-4dc7-b9b9-d082becd3319">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67acc448-a4ca-4dc7-b9b9-d082becd3319">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67acc448-a4ca-4dc7-b9b9-d082becd3319">
											<gml:posList>35.672405428115475 139.7403965474368 39.679 35.672405428115475 139.7403965474368 38.923 35.67239840128644 139.74038989452038 38.923 35.67239840128644 139.74038989452038 39.679 35.672405428115475 139.7403965474368 39.679</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-315</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">227.5638</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.27</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>