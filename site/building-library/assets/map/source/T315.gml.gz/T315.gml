<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_5a831fe2-6c1c-4c89-aeb8-096a9fd19573">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>0.80</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>29</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103029002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">18</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66771144101219 139.7385623170208 0 35.6677034385272 139.73858740065032 0 35.667692527138215 139.73858133830413 0 35.66767116834037 139.73863194265516 0 35.66769002467639 139.7386428999986 0 35.66767060610654 139.7386849635719 0 35.66765339031589 139.73867405951393 0 35.667633327034146 139.7387215804863 0 35.6677973653896 139.73882157327958 0 35.667899568471185 139.73880543623528 0 35.66792016714274 139.73875095556457 0 35.667857571963594 139.7387002182049 0 35.667865570911694 139.73867060571828 0 35.66771144101219 139.7385623170208 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66771144101219 139.7385623170208 13.634 35.667865570911694 139.73867060571828 13.634 35.667857571963594 139.7387002182049 13.634 35.66792016714274 139.73875095556457 13.634 35.667899568471185 139.73880543623528 13.634 35.6677973653896 139.73882157327958 13.634 35.667633327034146 139.7387215804863 13.634 35.66765339031589 139.73867405951393 13.634 35.66767060610654 139.7386849635719 13.634 35.66769002467639 139.7386428999986 13.634 35.66767116834037 139.73863194265516 13.634 35.667692527138215 139.73858133830413 13.634 35.6677034385272 139.73858740065032 13.634 35.66771144101219 139.7385623170208 13.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66771144101219 139.7385623170208 13.634 35.6677034385272 139.73858740065032 13.634 35.6677034385272 139.73858740065032 31.65 35.66771144101219 139.7385623170208 31.65 35.66771144101219 139.7385623170208 13.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6677034385272 139.73858740065032 13.634 35.667692527138215 139.73858133830413 13.634 35.667692527138215 139.73858133830413 31.65 35.6677034385272 139.73858740065032 31.65 35.6677034385272 139.73858740065032 13.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667692527138215 139.73858133830413 13.634 35.66767116834037 139.73863194265516 13.634 35.66767116834037 139.73863194265516 31.65 35.667692527138215 139.73858133830413 31.65 35.667692527138215 139.73858133830413 13.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66767116834037 139.73863194265516 13.634 35.66769002467639 139.7386428999986 13.634 35.66769002467639 139.7386428999986 31.65 35.66767116834037 139.73863194265516 31.65 35.66767116834037 139.73863194265516 13.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66769002467639 139.7386428999986 13.634 35.66767060610654 139.7386849635719 13.634 35.66767060610654 139.7386849635719 31.65 35.66769002467639 139.7386428999986 31.65 35.66769002467639 139.7386428999986 13.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66767060610654 139.7386849635719 13.634 35.66765339031589 139.73867405951393 13.634 35.66765339031589 139.73867405951393 31.65 35.66767060610654 139.7386849635719 31.65 35.66767060610654 139.7386849635719 13.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66765339031589 139.73867405951393 13.634 35.667633327034146 139.7387215804863 13.634 35.667633327034146 139.7387215804863 31.65 35.66765339031589 139.73867405951393 31.65 35.66765339031589 139.73867405951393 13.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667633327034146 139.7387215804863 13.634 35.6677973653896 139.73882157327958 13.634 35.6677973653896 139.73882157327958 31.65 35.667633327034146 139.7387215804863 31.65 35.667633327034146 139.7387215804863 13.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6677973653896 139.73882157327958 13.634 35.667899568471185 139.73880543623528 13.634 35.667899568471185 139.73880543623528 31.65 35.6677973653896 139.73882157327958 31.65 35.6677973653896 139.73882157327958 13.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667899568471185 139.73880543623528 13.634 35.66792016714274 139.73875095556457 13.634 35.66792016714274 139.73875095556457 31.65 35.667899568471185 139.73880543623528 31.65 35.667899568471185 139.73880543623528 13.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66792016714274 139.73875095556457 13.634 35.667857571963594 139.7387002182049 13.634 35.667857571963594 139.7387002182049 31.65 35.66792016714274 139.73875095556457 31.65 35.66792016714274 139.73875095556457 13.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667857571963594 139.7387002182049 13.634 35.667865570911694 139.73867060571828 13.634 35.667865570911694 139.73867060571828 31.65 35.667857571963594 139.7387002182049 31.65 35.667857571963594 139.7387002182049 13.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667865570911694 139.73867060571828 13.634 35.66771144101219 139.7385623170208 13.634 35.66771144101219 139.7385623170208 31.65 35.667865570911694 139.73867060571828 31.65 35.667865570911694 139.73867060571828 13.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66771144101219 139.7385623170208 31.65 35.6677034385272 139.73858740065032 31.65 35.667692527138215 139.73858133830413 31.65 35.66767116834037 139.73863194265516 31.65 35.66769002467639 139.7386428999986 31.65 35.66767060610654 139.7386849635719 31.65 35.66765339031589 139.73867405951393 31.65 35.667633327034146 139.7387215804863 31.65 35.6677973653896 139.73882157327958 31.65 35.667899568471185 139.73880543623528 31.65 35.66792016714274 139.73875095556457 31.65 35.667857571963594 139.7387002182049 31.65 35.667865570911694 139.73867060571828 31.65 35.66771144101219 139.7385623170208 31.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-98da6cf8-d953-470b-af95-6ffec7418d02"/>
							<gml:surfaceMember xlink:href="#poly-432d6068-06ce-4d2f-a554-02b5014423b6"/>
							<gml:surfaceMember xlink:href="#poly-cd13b993-85a4-49ef-86f9-0fcfb8ecfba3"/>
							<gml:surfaceMember xlink:href="#poly-be8a77c0-c7b5-43cc-b26a-3dc71cebb018"/>
							<gml:surfaceMember xlink:href="#poly-308267ac-6a85-4897-bb68-fb4c75127226"/>
							<gml:surfaceMember xlink:href="#poly-016621da-043d-4803-8baf-78a597d6ed76"/>
							<gml:surfaceMember xlink:href="#poly-89575c11-2ebe-4629-81c6-9ef29e5611cf"/>
							<gml:surfaceMember xlink:href="#poly-ee8f06bd-49ca-4837-9eff-f636c9063aa9"/>
							<gml:surfaceMember xlink:href="#poly-9a9672d1-45fd-473c-991e-5a4003e1d13c"/>
							<gml:surfaceMember xlink:href="#poly-8d2d085c-b1d6-4c82-8304-be895bd697cd"/>
							<gml:surfaceMember xlink:href="#poly-d53e31d3-b6a8-4b64-b987-e79f9c554591"/>
							<gml:surfaceMember xlink:href="#poly-2046624f-c2d8-424d-9ba2-dcc7bf3aa126"/>
							<gml:surfaceMember xlink:href="#poly-ecc4d102-bf04-4b40-a9da-986000e0e6a9"/>
							<gml:surfaceMember xlink:href="#poly-3ff53478-9c5b-45c9-9613-ae7e0cd155a2"/>
							<gml:surfaceMember xlink:href="#poly-0c80636b-20ec-48ed-84ac-d1a2d534f744"/>
							<gml:surfaceMember xlink:href="#poly-487db695-df02-41c0-a18d-db3a9cab0470"/>
							<gml:surfaceMember xlink:href="#poly-8efa5814-02da-4ae0-91c1-573d1667259b"/>
							<gml:surfaceMember xlink:href="#poly-1517d27b-b101-467d-9b0b-b1ba7a4cb8fc"/>
							<gml:surfaceMember xlink:href="#poly-6271e2fa-54e4-4cb6-a6aa-9365610ee897"/>
							<gml:surfaceMember xlink:href="#poly-1897dcd1-775d-4cc7-8eba-3d98d28eeed5"/>
							<gml:surfaceMember xlink:href="#poly-0d9ed98a-b1d3-44d0-91b4-a1b237718e84"/>
							<gml:surfaceMember xlink:href="#poly-b5a7d008-b1f2-4811-91fe-37ca8d37d12f"/>
							<gml:surfaceMember xlink:href="#poly-0fbbe007-fb0b-4185-8314-6028c6753f2a"/>
							<gml:surfaceMember xlink:href="#poly-d11debea-282b-4890-ab88-35c6df657226"/>
							<gml:surfaceMember xlink:href="#poly-fc8b5f16-d1af-4af9-b067-ba19e8faefec"/>
							<gml:surfaceMember xlink:href="#poly-d99d69c2-fa46-44c5-8249-ab77110e0204"/>
							<gml:surfaceMember xlink:href="#poly-669e5cf5-65ca-4533-be80-0022cfeb14e9"/>
							<gml:surfaceMember xlink:href="#poly-ea1f7492-acb4-46bd-93b1-4c86d90e5b64"/>
							<gml:surfaceMember xlink:href="#poly-18f3c4d8-a09a-426a-aa45-b1598777f0bd"/>
							<gml:surfaceMember xlink:href="#poly-ab32d5ee-f860-458f-91e9-e363a59ce887"/>
							<gml:surfaceMember xlink:href="#poly-3ceb31a9-a72b-4077-b911-63847ff813e4"/>
							<gml:surfaceMember xlink:href="#poly-c6d49acb-9e06-4869-8b50-e89d467d5f27"/>
							<gml:surfaceMember xlink:href="#poly-144cdf34-2418-4c96-bfce-4553d27cebfc"/>
							<gml:surfaceMember xlink:href="#poly-2665a5b1-320a-4c0f-a479-6eaf1f6334cb"/>
							<gml:surfaceMember xlink:href="#poly-cb33d478-d899-42c1-bcf9-147898e59a25"/>
							<gml:surfaceMember xlink:href="#poly-8883450d-1716-4d86-b2f8-548d33e68355"/>
							<gml:surfaceMember xlink:href="#poly-c39a2ca8-f5d4-4de5-990f-a11b967fb681"/>
							<gml:surfaceMember xlink:href="#poly-877f255a-e1d7-401b-b4ee-7280f21f9417"/>
							<gml:surfaceMember xlink:href="#poly-50d1ac57-0f76-45b2-a1ac-03e8db9da7be"/>
							<gml:surfaceMember xlink:href="#poly-ca52423d-5f98-40b9-89b6-5c9a03d8b690"/>
							<gml:surfaceMember xlink:href="#poly-e96a8ae7-ea78-4661-8199-5bdf3dd897f8"/>
							<gml:surfaceMember xlink:href="#poly-4766247c-feac-415e-8447-04957fb9b67e"/>
							<gml:surfaceMember xlink:href="#poly-0f6a0462-02bb-4609-9bcc-25c0731890b7"/>
							<gml:surfaceMember xlink:href="#poly-5d3a460f-c482-45cf-8c3b-0f8b6185412f"/>
							<gml:surfaceMember xlink:href="#poly-bd09598d-6f5c-4ee3-8f0a-0ed034c0567b"/>
							<gml:surfaceMember xlink:href="#poly-8371ffdd-8d3b-4bea-a2b0-b60fc89dc835"/>
							<gml:surfaceMember xlink:href="#poly-c05509fa-27c3-496c-88f1-43e7cd8664fb"/>
							<gml:surfaceMember xlink:href="#poly-2aee22d5-0c18-4dc0-a6c3-f741b51c8147"/>
							<gml:surfaceMember xlink:href="#poly-b846475a-8abe-4937-8b3d-36fa43e16267"/>
							<gml:surfaceMember xlink:href="#poly-90d80c34-0bd7-4ea3-981e-23aa52094ad2"/>
							<gml:surfaceMember xlink:href="#poly-21024737-ff70-49df-9b20-cead4f7d93da"/>
							<gml:surfaceMember xlink:href="#poly-7a371046-81a8-497d-b107-52beb8e0b65a"/>
							<gml:surfaceMember xlink:href="#poly-efa0c7c5-d2ab-4165-9755-955c87f4c0d6"/>
							<gml:surfaceMember xlink:href="#poly-995ff6cb-63ff-4e8c-869b-6728a8acab86"/>
							<gml:surfaceMember xlink:href="#poly-722f0c81-87a1-4fe8-ad51-cbad05c1a29d"/>
							<gml:surfaceMember xlink:href="#poly-eef6e084-93fc-4c21-aeb2-fbfb802eb09e"/>
							<gml:surfaceMember xlink:href="#poly-7a0eeba6-a04e-439c-91ae-56a8b5211e17"/>
							<gml:surfaceMember xlink:href="#poly-5e14e7e3-9930-4c17-8178-00b66fe3294b"/>
							<gml:surfaceMember xlink:href="#poly-9bc10668-93d1-44b8-9fae-5a5118cff61e"/>
							<gml:surfaceMember xlink:href="#poly-6166d132-8b8b-4a4b-a9b7-ef712c2a0301"/>
							<gml:surfaceMember xlink:href="#poly-740c47a6-68c2-49bb-ba32-38bc9a4b5c9c"/>
							<gml:surfaceMember xlink:href="#poly-b20d298d-b360-43ef-9344-da328af4f799"/>
							<gml:surfaceMember xlink:href="#poly-e558f625-4ada-4171-8fb1-8a612b41bee2"/>
							<gml:surfaceMember xlink:href="#poly-bf3cf173-47fc-489f-8f33-282e49619dac"/>
							<gml:surfaceMember xlink:href="#poly-78382684-8a56-49ce-98b0-7bfc28e9eaca"/>
							<gml:surfaceMember xlink:href="#poly-80ce69d8-a7c3-4b4b-9f6a-29b23fd391d3"/>
							<gml:surfaceMember xlink:href="#poly-d571653c-1cd1-4208-89dd-3bf1f77dce0f"/>
							<gml:surfaceMember xlink:href="#poly-1aeb33db-1931-4739-a69f-ca02355e01c1"/>
							<gml:surfaceMember xlink:href="#poly-043c633b-207c-455e-8491-0d4b8bf5823d"/>
							<gml:surfaceMember xlink:href="#poly-fa10682f-bf76-488d-ac70-841e232a975e"/>
							<gml:surfaceMember xlink:href="#poly-04fdcc94-2c7a-4a03-ad92-1d003b573b0f"/>
							<gml:surfaceMember xlink:href="#poly-7ed4de05-093c-4908-bbbb-800c6094cb7b"/>
							<gml:surfaceMember xlink:href="#poly-2b2913bc-dcf3-479a-9f16-52d94abc9d3e"/>
							<gml:surfaceMember xlink:href="#poly-732ec590-468b-4ae3-92df-22ba900945f5"/>
							<gml:surfaceMember xlink:href="#poly-9c9a1d2c-8d6c-4a6f-8e7f-0028c777e653"/>
							<gml:surfaceMember xlink:href="#poly-85b4befd-e867-4052-8cc4-dfc2bb0555bd"/>
							<gml:surfaceMember xlink:href="#poly-c1dd7518-24fe-452d-9629-d1d2cfac212c"/>
							<gml:surfaceMember xlink:href="#poly-ced2a7eb-9ae2-47df-b843-0e1be18f602b"/>
							<gml:surfaceMember xlink:href="#poly-f4a24cda-1afd-407f-8d6e-e85e6be93c32"/>
							<gml:surfaceMember xlink:href="#poly-45af0ea7-cc3f-436d-be5e-4960e93c2f06"/>
							<gml:surfaceMember xlink:href="#poly-92c58f50-744f-43bb-b785-d9bd649d5ee1"/>
							<gml:surfaceMember xlink:href="#poly-f2d851a4-566c-41c9-b8fd-adbb8373d726"/>
							<gml:surfaceMember xlink:href="#poly-8cffbc35-bd6b-4bc1-af2d-cc122e1a31b8"/>
							<gml:surfaceMember xlink:href="#poly-8774e541-b990-4e5c-876e-0bb695e97188"/>
							<gml:surfaceMember xlink:href="#poly-8187398d-f1c9-4f0e-a75c-b9f55f5b4c01"/>
							<gml:surfaceMember xlink:href="#poly-026981f5-dfd8-4c3a-82e9-ce5a9fa00aed"/>
							<gml:surfaceMember xlink:href="#poly-99db6e71-dddd-47aa-8acd-bfe86eb791ac"/>
							<gml:surfaceMember xlink:href="#poly-0f4012b9-1062-4e15-9aa0-d2bc7da2d13a"/>
							<gml:surfaceMember xlink:href="#poly-433d432f-1920-44c2-9489-38fa09b7e913"/>
							<gml:surfaceMember xlink:href="#poly-b5dc6029-f5ef-431c-bdc8-ddd9774847e9"/>
							<gml:surfaceMember xlink:href="#poly-60840eeb-b04f-4f44-8f76-b5df32954b20"/>
							<gml:surfaceMember xlink:href="#poly-104396f9-24bd-4fe2-a6ad-a79e50a6010e"/>
							<gml:surfaceMember xlink:href="#poly-c6beb353-567c-4e8b-adce-cad47a56e083"/>
							<gml:surfaceMember xlink:href="#poly-3c334cee-844c-453c-b186-66a81811b6f5"/>
							<gml:surfaceMember xlink:href="#poly-587df122-104d-494a-b516-82d208548c33"/>
							<gml:surfaceMember xlink:href="#poly-767c30cb-0e49-4ebc-87df-e86ac05676f3"/>
							<gml:surfaceMember xlink:href="#poly-667e48f8-c670-4002-9f56-43d831d46c80"/>
							<gml:surfaceMember xlink:href="#poly-ba4fd3d8-b6e6-4d53-893d-59572172b8a7"/>
							<gml:surfaceMember xlink:href="#poly-4b9ca8d8-faa3-4a21-a764-fa66c8a44cb0"/>
							<gml:surfaceMember xlink:href="#poly-0c2f1da6-e91d-41a3-ad23-36aa767b9ad1"/>
							<gml:surfaceMember xlink:href="#poly-225e961c-87f9-4830-b3cf-b54f24b84920"/>
							<gml:surfaceMember xlink:href="#poly-68436440-340a-43fd-a3a8-2c303df6024b"/>
							<gml:surfaceMember xlink:href="#poly-99cbcc0d-8df7-426a-9ae1-6a170d427e6d"/>
							<gml:surfaceMember xlink:href="#poly-9f5c2d73-1142-486a-be02-299b0565fe69"/>
							<gml:surfaceMember xlink:href="#poly-5ebd5132-eb39-4716-b16f-8f45a4de2b20"/>
							<gml:surfaceMember xlink:href="#poly-4e3f6242-9e7c-4048-8a37-4b6b8462d5c0"/>
							<gml:surfaceMember xlink:href="#poly-7b4d2074-bc15-48c9-94f9-40ad92ce7bda"/>
							<gml:surfaceMember xlink:href="#poly-054ac0ff-fc4b-4a23-a450-45f41bae1246"/>
							<gml:surfaceMember xlink:href="#poly-659b80a1-a407-42ca-be2a-86188bb925f1"/>
							<gml:surfaceMember xlink:href="#poly-c71ae075-0ee1-4b1d-b9f7-77d976938ec1"/>
							<gml:surfaceMember xlink:href="#poly-c6ce5a93-8d3a-4bbc-aab0-c895864e92db"/>
							<gml:surfaceMember xlink:href="#poly-abe34204-edd3-47b0-8ee4-32c7967fa485"/>
							<gml:surfaceMember xlink:href="#poly-6c961131-c62f-409d-bef6-2bf6701afb68"/>
							<gml:surfaceMember xlink:href="#poly-85278fac-6dbc-4b59-a208-0863acd8efee"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_5a831fe2-6c1c-4c89-aeb8-096a9fd19573_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fd945c90-47ee-427e-b427-848379bbeb1b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66767116834037 139.7386319426552 13.634 35.66769002467637 139.7386428999986 13.634 35.66767059710149 139.7386849746284 13.634 35.66765339031589 139.73867405951393 13.634 35.66767116834037 139.7386319426552 13.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d82ed395-378a-448f-b2b8-1452f14f8812">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d82ed395-378a-448f-b2b8-1452f14f8812_0">
											<gml:posList>35.66769002467637 139.7386428999986 13.634 35.66767116834037 139.7386319426552 13.634 35.66767116834037 139.7386319426552 31.554 35.66769002467637 139.7386428999986 31.554 35.66769002467637 139.7386428999986 13.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1e693ae-0ec9-463e-bcdb-5704e5da7529">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d1e693ae-0ec9-463e-bcdb-5704e5da7529_0">
											<gml:posList>35.66767116834037 139.7386319426552 13.634 35.66765339031589 139.73867405951393 13.634 35.66765339031589 139.73867405951393 30.039 35.66767116834037 139.7386319426552 31.554 35.66767116834037 139.7386319426552 13.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d3a4987-24e5-4513-8f7a-102bb9492f7b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3d3a4987-24e5-4513-8f7a-102bb9492f7b_0">
											<gml:posList>35.66769002467637 139.7386428999986 31.554 35.66767116834037 139.7386319426552 31.554 35.66765339031589 139.73867405951393 30.039 35.667670615111575 139.73868495251537 30.04 35.66769002467637 139.7386428999986 31.554</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-79b2de2a-5be9-445a-a876-a3dd280b786a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-79b2de2a-5be9-445a-a876-a3dd280b786a_0">
											<gml:posList>35.667670615111575 139.73868495251537 30.04 35.66767059710149 139.7386849746284 13.634 35.66769002467637 139.7386428999986 13.634 35.66769002467637 139.7386428999986 31.554 35.667670615111575 139.73868495251537 30.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ea5e36d-0aa1-434e-85fc-4f5e9d6f862e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6ea5e36d-0aa1-434e-85fc-4f5e9d6f862e_0">
											<gml:posList>35.66767059710149 139.7386849746284 13.634 35.667670615111575 139.73868495251537 30.04 35.66765339031589 139.73867405951393 30.039 35.66765339031589 139.73867405951393 13.634 35.66767059710149 139.7386849746284 13.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-98da6cf8-d953-470b-af95-6ffec7418d02">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-98da6cf8-d953-470b-af95-6ffec7418d02">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-98da6cf8-d953-470b-af95-6ffec7418d02">
											<gml:posList>35.66770343852719 139.73858740065035 13.634 35.66771144101218 139.7385623170208 13.634 35.66786557091169 139.73867060571826 13.634 35.66785757196359 139.7387002182049 13.634 35.66792016714274 139.73875095556457 13.634 35.667899568471185 139.73880543623528 13.634 35.66779736538959 139.73882157327958 13.634 35.667633327034146 139.7387215804863 13.634 35.66765339031589 139.73867405951393 13.634 35.66767060610654 139.7386849635719 13.634 35.66769002467637 139.7386428999986 13.634 35.66767116834037 139.7386319426552 13.634 35.6676925271382 139.73858133830413 13.634 35.66770343852719 139.73858740065035 13.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-432d6068-06ce-4d2f-a554-02b5014423b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-432d6068-06ce-4d2f-a554-02b5014423b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-432d6068-06ce-4d2f-a554-02b5014423b6">
											<gml:posList>35.66770343852719 139.73858740065035 31.904 35.66770492028941 139.73859186143935 31.904 35.66771282387643 139.73856709825753 31.904 35.66771144101218 139.7385623170208 31.904 35.66770343852719 139.73858740065035 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cd13b993-85a4-49ef-86f9-0fcfb8ecfba3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd13b993-85a4-49ef-86f9-0fcfb8ecfba3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd13b993-85a4-49ef-86f9-0fcfb8ecfba3">
											<gml:posList>35.66770343852719 139.73858740065035 31.904 35.6676925271382 139.73858133830413 31.904 35.66769375640332 139.7385856557942 31.904 35.66770492028941 139.73859186143935 31.904 35.66770343852719 139.73858740065035 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-be8a77c0-c7b5-43cc-b26a-3dc71cebb018">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-be8a77c0-c7b5-43cc-b26a-3dc71cebb018">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-be8a77c0-c7b5-43cc-b26a-3dc71cebb018">
											<gml:posList>35.66771144101218 139.7385623170208 31.904 35.66771282387643 139.73856709825753 31.904 35.66781436563256 139.73863843421574 31.904 35.667817925029354 139.7386371265953 31.904 35.66771144101218 139.7385623170208 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-308267ac-6a85-4897-bb68-fb4c75127226">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-308267ac-6a85-4897-bb68-fb4c75127226">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-308267ac-6a85-4897-bb68-fb4c75127226">
											<gml:posList>35.66767116834037 139.7386319426552 31.904 35.66767485377298 139.738630436062 31.904 35.66769375640332 139.7385856557942 31.904 35.6676925271382 139.73858133830413 31.904 35.66767116834037 139.7386319426552 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-016621da-043d-4803-8baf-78a597d6ed76">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-016621da-043d-4803-8baf-78a597d6ed76">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-016621da-043d-4803-8baf-78a597d6ed76">
											<gml:posList>35.66768892163152 139.73863861549646 31.904 35.66767485377298 139.738630436062 31.904 35.66767116834037 139.7386319426552 31.904 35.66769002467637 139.7386428999986 31.904 35.667691257463524 139.73864023648363 31.904 35.66768892163152 139.73863861549646 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-89575c11-2ebe-4629-81c6-9ef29e5611cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-89575c11-2ebe-4629-81c6-9ef29e5611cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-89575c11-2ebe-4629-81c6-9ef29e5611cf">
											<gml:posList>35.66767060610654 139.7386849635719 35.238 35.667673003089206 139.73868411020933 35.238 35.66770696308965 139.73861055971915 35.238 35.66770642876865 139.73860736808788 35.238 35.66767060610654 139.7386849635719 35.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ee8f06bd-49ca-4837-9eff-f636c9063aa9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee8f06bd-49ca-4837-9eff-f636c9063aa9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee8f06bd-49ca-4837-9eff-f636c9063aa9">
											<gml:posList>35.667790950396785 139.73868740626224 35.238 35.66770642876865 139.73860736808788 35.238 35.66770696308965 139.73861055971915 35.238 35.667788715444175 139.73868798328718 35.238 35.667790950396785 139.73868740626224 35.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9a9672d1-45fd-473c-991e-5a4003e1d13c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a9672d1-45fd-473c-991e-5a4003e1d13c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a9672d1-45fd-473c-991e-5a4003e1d13c">
											<gml:posList>35.66780669714343 139.73866415813805 31.904 35.667817925029354 139.7386371265953 31.904 35.66781436563256 139.73863843421574 31.904 35.66780312874129 139.73866547681365 31.904 35.66780669714343 139.73866415813805 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8d2d085c-b1d6-4c82-8304-be895bd697cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d2d085c-b1d6-4c82-8304-be895bd697cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d2d085c-b1d6-4c82-8304-be895bd697cd">
											<gml:posList>35.66780669714343 139.73866415813805 31.904 35.66785364841454 139.7386969421998 31.904 35.66786557091169 139.73867060571826 29.511 35.667817925029354 139.7386371265953 29.511 35.66780669714343 139.73866415813805 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d53e31d3-b6a8-4b64-b987-e79f9c554591">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d53e31d3-b6a8-4b64-b987-e79f9c554591">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d53e31d3-b6a8-4b64-b987-e79f9c554591">
											<gml:posList>35.66780669714343 139.73866415813805 31.904 35.66780312874129 139.73866547681365 31.904 35.66785098188817 139.7386989004731 31.904 35.66785364841454 139.7386969421998 31.904 35.66780669714343 139.73866415813805 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2046624f-c2d8-424d-9ba2-dcc7bf3aa126">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2046624f-c2d8-424d-9ba2-dcc7bf3aa126">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2046624f-c2d8-424d-9ba2-dcc7bf3aa126">
											<gml:posList>35.66777292745911 139.7387505327626 34.811 35.66777145181949 139.73875385931908 34.811 35.667787748141826 139.73876468717324 34.811 35.66780480788523 139.73872611684675 34.811 35.66780439027709 139.73872232859424 34.811 35.667803505291644 139.73872024196254 34.811 35.66780060072811 139.73871751705147 34.811 35.66779208667581 139.73871104315285 34.811 35.66779574106663 139.73870444443628 34.811 35.66778473851336 139.73869706771248 34.811 35.667788715444175 139.73868798328718 34.811 35.66770696308965 139.73861055971915 34.811 35.667673003089206 139.73868411020933 34.811 35.66777292745911 139.7387505327626 34.811</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ecc4d102-bf04-4b40-a9da-986000e0e6a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ecc4d102-bf04-4b40-a9da-986000e0e6a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ecc4d102-bf04-4b40-a9da-986000e0e6a9">
											<gml:posList>35.667787090427446 139.73869621440227 35.238 35.667790950396785 139.73868740626224 35.238 35.667788715444175 139.73868798328718 35.238 35.66778473851336 139.73869706771248 35.238 35.667787090427446 139.73869621440227 35.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3ff53478-9c5b-45c9-9613-ae7e0cd155a2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ff53478-9c5b-45c9-9613-ae7e0cd155a2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ff53478-9c5b-45c9-9613-ae7e0cd155a2">
											<gml:posList>35.66779825531462 139.73870370139363 31.635 35.6677945469283 139.73871041063316 31.635 35.667801599880384 139.73871577061968 31.635 35.667804865262056 139.73871883752798 31.635 35.667806075340515 139.73872168594355 31.635 35.66780661096891 139.73872654550965 31.635 35.66778844448018 139.73876759142428 31.635 35.66776909089993 139.73875472368397 31.635 35.66775419307129 139.73879154618646 31.635 35.66779784043812 139.73881815953544 31.635 35.667801220177935 139.73881763639423 31.635 35.667813906422694 139.73878818410194 31.635 35.66782816150324 139.73879374547735 31.635 35.66783492914645 139.73879161668373 31.635 35.66784144125709 139.7387854785259 31.635 35.66784781306999 139.73877285658307 31.635 35.66785333228069 139.7387764289496 31.635 35.667859205821934 139.73876060427736 31.635 35.667840418630895 139.73874585805473 31.635 35.66785135023645 139.73872029596777 31.635 35.66785098188817 139.7386989004731 31.635 35.66780312874129 139.73866547681365 31.635 35.66781436563256 139.73863843421574 31.635 35.66771282387643 139.73856709825753 31.635 35.66770492028941 139.73859186143935 31.635 35.66769375640332 139.7385856557942 31.635 35.66767485377298 139.738630436062 31.635 35.66768892163152 139.73863861549646 31.635 35.667691257463524 139.73864023648363 31.635 35.66770642876865 139.73860736808788 31.635 35.667790950396785 139.73868740626224 31.635 35.667787090427446 139.73869621440227 31.635 35.66779825531462 139.73870370139363 31.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0c80636b-20ec-48ed-84ac-d1a2d534f744">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c80636b-20ec-48ed-84ac-d1a2d534f744">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c80636b-20ec-48ed-84ac-d1a2d534f744">
											<gml:posList>35.667787090427446 139.73869621440227 35.238 35.66778473851336 139.73869706771248 35.238 35.66779574106663 139.73870444443628 35.238 35.66779825531462 139.73870370139363 35.238 35.667787090427446 139.73869621440227 35.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-487db695-df02-41c0-a18d-db3a9cab0470">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-487db695-df02-41c0-a18d-db3a9cab0470">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-487db695-df02-41c0-a18d-db3a9cab0470">
											<gml:posList>35.66765339031589 139.73867405951393 31.904 35.667633327034146 139.7387215804863 31.904 35.667649902221186 139.7387316900039 31.904 35.66767060610654 139.7386849635719 31.904 35.66765339031589 139.73867405951393 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8efa5814-02da-4ae0-91c1-573d1667259b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8efa5814-02da-4ae0-91c1-573d1667259b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8efa5814-02da-4ae0-91c1-573d1667259b">
											<gml:posList>35.6677945469283 139.73871041063316 35.238 35.66779825531462 139.73870370139363 35.238 35.66779574106663 139.73870444443628 35.238 35.66779208667581 139.73871104315285 35.238 35.6677945469283 139.73871041063316 35.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1517d27b-b101-467d-9b0b-b1ba7a4cb8fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1517d27b-b101-467d-9b0b-b1ba7a4cb8fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1517d27b-b101-467d-9b0b-b1ba7a4cb8fc">
											<gml:posList>35.66785406398418 139.73872107702542 31.904 35.66785364841454 139.7386969421998 31.904 35.66785098188817 139.7386989004731 31.904 35.66785135023645 139.73872029596777 31.904 35.66785406398418 139.73872107702542 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6271e2fa-54e4-4cb6-a6aa-9365610ee897">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6271e2fa-54e4-4cb6-a6aa-9365610ee897">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6271e2fa-54e4-4cb6-a6aa-9365610ee897">
											<gml:posList>35.6677945469283 139.73871041063316 35.238 35.66779208667581 139.73871104315285 35.238 35.66780060072811 139.73871751705147 35.238 35.667801599880384 139.73871577061968 35.238 35.6677945469283 139.73871041063316 35.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1897dcd1-775d-4cc7-8eba-3d98d28eeed5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1897dcd1-775d-4cc7-8eba-3d98d28eeed5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1897dcd1-775d-4cc7-8eba-3d98d28eeed5">
											<gml:posList>35.667673003089206 139.73868411020933 35.238 35.66767060610654 139.7386849635719 35.238 35.66777056653959 139.73875139712763 35.238 35.66777292745911 139.7387505327626 35.238 35.667673003089206 139.73868411020933 35.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0d9ed98a-b1d3-44d0-91b4-a1b237718e84">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d9ed98a-b1d3-44d0-91b4-a1b237718e84">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d9ed98a-b1d3-44d0-91b4-a1b237718e84">
											<gml:posList>35.667801599880384 139.73871577061968 35.238 35.66780060072811 139.73871751705147 35.238 35.667803505291644 139.73872024196254 35.238 35.667804865262056 139.73871883752798 35.238 35.667801599880384 139.73871577061968 35.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b5a7d008-b1f2-4811-91fe-37ca8d37d12f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b5a7d008-b1f2-4811-91fe-37ca8d37d12f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b5a7d008-b1f2-4811-91fe-37ca8d37d12f">
											<gml:posList>35.66767060610654 139.7386849635719 35.238 35.66776914499098 139.73875473466606 34.986 35.66777056653959 139.73875139712763 35.238 35.66767060610654 139.7386849635719 35.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0fbbe007-fb0b-4185-8314-6028c6753f2a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0fbbe007-fb0b-4185-8314-6028c6753f2a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0fbbe007-fb0b-4185-8314-6028c6753f2a">
											<gml:posList>35.667806075340515 139.73872168594355 35.238 35.667804865262056 139.73871883752798 35.238 35.667803505291644 139.73872024196254 35.238 35.66780439027709 139.73872232859424 35.238 35.667806075340515 139.73872168594355 35.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d11debea-282b-4890-ab88-35c6df657226">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d11debea-282b-4890-ab88-35c6df657226">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d11debea-282b-4890-ab88-35c6df657226">
											<gml:posList>35.667806075340515 139.73872168594355 35.238 35.66780439027709 139.73872232859424 35.238 35.66780480788523 139.73872611684675 35.238 35.66780661096891 139.73872654550965 35.238 35.667806075340515 139.73872168594355 35.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fc8b5f16-d1af-4af9-b067-ba19e8faefec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc8b5f16-d1af-4af9-b067-ba19e8faefec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc8b5f16-d1af-4af9-b067-ba19e8faefec">
											<gml:posList>35.66784395110914 139.73874470511316 31.904 35.66785406398418 139.73872107702542 31.904 35.66785135023645 139.73872029596777 31.904 35.667840418630895 139.73874585805473 31.904 35.66784395110914 139.73874470511316 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d99d69c2-fa46-44c5-8249-ab77110e0204">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d99d69c2-fa46-44c5-8249-ab77110e0204">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d99d69c2-fa46-44c5-8249-ab77110e0204">
											<gml:posList>35.66767060610654 139.7386849635719 35.238 35.66775298756481 139.7387945189542 31.904 35.66776914499098 139.73875473466606 34.986 35.66767060610654 139.7386849635719 35.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-669e5cf5-65ca-4533-be80-0022cfeb14e9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-669e5cf5-65ca-4533-be80-0022cfeb14e9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-669e5cf5-65ca-4533-be80-0022cfeb14e9">
											<gml:posList>35.66767060610654 139.7386849635719 35.238 35.667649902221186 139.7387316900039 31.904 35.66775298756481 139.7387945189542 31.904 35.66767060610654 139.7386849635719 35.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ea1f7492-acb4-46bd-93b1-4c86d90e5b64">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea1f7492-acb4-46bd-93b1-4c86d90e5b64">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea1f7492-acb4-46bd-93b1-4c86d90e5b64">
											<gml:posList>35.66785406398418 139.73872107702542 29.511 35.66784395110914 139.73874470511316 29.511 35.66786263006619 139.7387593630965 29.511 35.66785459778452 139.73878098941864 29.511 35.66784878096487 139.7387772185763 29.511 35.667843480119764 139.7387877184415 29.511 35.66783612134316 139.73879465290298 29.511 35.66782808307671 139.73879718084711 29.511 35.66781523457121 139.73879217010796 29.511 35.66780294420116 139.73882069407756 29.511 35.667882597714836 139.73880811830722 29.511 35.66791054336288 139.7387431574516 29.511 35.66785757196359 139.7387002182049 29.511 35.66786557091169 139.73867060571826 29.511 35.66785364841454 139.7386969421998 29.511 35.66785406398418 139.73872107702542 29.511</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-18f3c4d8-a09a-426a-aa45-b1598777f0bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18f3c4d8-a09a-426a-aa45-b1598777f0bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18f3c4d8-a09a-426a-aa45-b1598777f0bd">
											<gml:posList>35.66780661096891 139.73872654550965 35.238 35.66780480788523 139.73872611684675 35.238 35.667787748141826 139.73876468717324 35.238 35.66778844448018 139.73876759142428 35.238 35.66780661096891 139.73872654550965 35.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ab32d5ee-f860-458f-91e9-e363a59ce887">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab32d5ee-f860-458f-91e9-e363a59ce887">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab32d5ee-f860-458f-91e9-e363a59ce887">
											<gml:posList>35.66777056653959 139.73875139712763 35.238 35.66776909089993 139.73875472368397 35.238 35.66777145181949 139.73875385931908 35.238 35.66777292745911 139.7387505327626 35.238 35.66777056653959 139.73875139712763 35.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3ceb31a9-a72b-4077-b911-63847ff813e4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ceb31a9-a72b-4077-b911-63847ff813e4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ceb31a9-a72b-4077-b911-63847ff813e4">
											<gml:posList>35.66784395110914 139.73874470511316 31.904 35.667840418630895 139.73874585805473 31.904 35.667859205821934 139.73876060427736 31.904 35.66786263006619 139.7387593630965 31.904 35.66784395110914 139.73874470511316 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c6d49acb-9e06-4869-8b50-e89d467d5f27">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6d49acb-9e06-4869-8b50-e89d467d5f27">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6d49acb-9e06-4869-8b50-e89d467d5f27">
											<gml:posList>35.66778844448018 139.73876759142428 35.238 35.667787748141826 139.73876468717324 35.238 35.66777145181949 139.73875385931908 35.238 35.66776909089993 139.73875472368397 35.238 35.66778844448018 139.73876759142428 35.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-144cdf34-2418-4c96-bfce-4553d27cebfc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-144cdf34-2418-4c96-bfce-4553d27cebfc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-144cdf34-2418-4c96-bfce-4553d27cebfc">
											<gml:posList>35.66786263006619 139.7387593630965 31.904 35.667859205821934 139.73876060427736 31.904 35.66785333228069 139.7387764289496 31.904 35.66785459778452 139.73878098941864 31.904 35.66786263006619 139.7387593630965 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2665a5b1-320a-4c0f-a479-6eaf1f6334cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2665a5b1-320a-4c0f-a479-6eaf1f6334cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2665a5b1-320a-4c0f-a479-6eaf1f6334cb">
											<gml:posList>35.667899568471185 139.73880543623528 27.023 35.66792016714274 139.73875095556457 27.023 35.66791054336288 139.7387431574516 29.511 35.667899568471185 139.73880543623528 27.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cb33d478-d899-42c1-bcf9-147898e59a25">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb33d478-d899-42c1-bcf9-147898e59a25">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb33d478-d899-42c1-bcf9-147898e59a25">
											<gml:posList>35.66791054336288 139.7387431574516 29.511 35.667882597714836 139.73880811830722 29.511 35.667899568471185 139.73880543623528 27.023 35.66791054336288 139.7387431574516 29.511</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8883450d-1716-4d86-b2f8-548d33e68355">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8883450d-1716-4d86-b2f8-548d33e68355">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8883450d-1716-4d86-b2f8-548d33e68355">
											<gml:posList>35.66784878096487 139.7387772185763 31.904 35.66785459778452 139.73878098941864 31.904 35.66785333228069 139.7387764289496 31.904 35.66784781306999 139.73877285658307 31.904 35.66784878096487 139.7387772185763 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c39a2ca8-f5d4-4de5-990f-a11b967fb681">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c39a2ca8-f5d4-4de5-990f-a11b967fb681">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c39a2ca8-f5d4-4de5-990f-a11b967fb681">
											<gml:posList>35.66784878096487 139.7387772185763 31.904 35.66784781306999 139.73877285658307 31.904 35.66784144125709 139.7387854785259 31.904 35.667843480119764 139.7387877184415 31.904 35.66784878096487 139.7387772185763 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-877f255a-e1d7-401b-b4ee-7280f21f9417">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-877f255a-e1d7-401b-b4ee-7280f21f9417">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-877f255a-e1d7-401b-b4ee-7280f21f9417">
											<gml:posList>35.667843480119764 139.7387877184415 31.904 35.66784144125709 139.7387854785259 31.904 35.66783492914645 139.73879161668373 31.904 35.66783612134316 139.73879465290298 31.904 35.667843480119764 139.7387877184415 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-50d1ac57-0f76-45b2-a1ac-03e8db9da7be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50d1ac57-0f76-45b2-a1ac-03e8db9da7be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50d1ac57-0f76-45b2-a1ac-03e8db9da7be">
											<gml:posList>35.66781523457121 139.73879217010796 31.904 35.66782808307671 139.73879718084711 31.904 35.66782816150324 139.73879374547735 31.904 35.667813906422694 139.73878818410194 31.904 35.66781523457121 139.73879217010796 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ca52423d-5f98-40b9-89b6-5c9a03d8b690">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca52423d-5f98-40b9-89b6-5c9a03d8b690">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca52423d-5f98-40b9-89b6-5c9a03d8b690">
											<gml:posList>35.66783612134316 139.73879465290298 31.904 35.66783492914645 139.73879161668373 31.904 35.66782816150324 139.73879374547735 31.904 35.66782808307671 139.73879718084711 31.904 35.66783612134316 139.73879465290298 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e96a8ae7-ea78-4661-8199-5bdf3dd897f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e96a8ae7-ea78-4661-8199-5bdf3dd897f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e96a8ae7-ea78-4661-8199-5bdf3dd897f8">
											<gml:posList>35.66781523457121 139.73879217010796 31.904 35.667813906422694 139.73878818410194 31.904 35.667801220177935 139.73881763639423 31.904 35.66780294420116 139.73882069407756 31.904 35.66781523457121 139.73879217010796 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4766247c-feac-415e-8447-04957fb9b67e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4766247c-feac-415e-8447-04957fb9b67e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4766247c-feac-415e-8447-04957fb9b67e">
											<gml:posList>35.66779784043812 139.73881815953544 31.904 35.66775419307129 139.73879154618646 31.904 35.66775298756481 139.7387945189542 31.904 35.66779736538959 139.73882157327958 31.904 35.66779784043812 139.73881815953544 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0f6a0462-02bb-4609-9bcc-25c0731890b7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0f6a0462-02bb-4609-9bcc-25c0731890b7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0f6a0462-02bb-4609-9bcc-25c0731890b7">
											<gml:posList>35.66779736538959 139.73882157327958 31.904 35.66780294420116 139.73882069407756 31.904 35.667801220177935 139.73881763639423 31.904 35.66779784043812 139.73881815953544 31.904 35.66779736538959 139.73882157327958 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5d3a460f-c482-45cf-8c3b-0f8b6185412f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d3a460f-c482-45cf-8c3b-0f8b6185412f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d3a460f-c482-45cf-8c3b-0f8b6185412f">
											<gml:posList>35.66771144101218 139.7385623170208 13.634 35.66770343852719 139.73858740065035 13.634 35.66770343852719 139.73858740065035 31.904 35.66771144101218 139.7385623170208 31.904 35.66771144101218 139.7385623170208 13.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bd09598d-6f5c-4ee3-8f0a-0ed034c0567b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd09598d-6f5c-4ee3-8f0a-0ed034c0567b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd09598d-6f5c-4ee3-8f0a-0ed034c0567b">
											<gml:posList>35.66770492028941 139.73859186143935 31.904 35.66770492028941 139.73859186143935 31.635 35.66771282387643 139.73856709825753 31.635 35.66771282387643 139.73856709825753 31.904 35.66770492028941 139.73859186143935 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8371ffdd-8d3b-4bea-a2b0-b60fc89dc835">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8371ffdd-8d3b-4bea-a2b0-b60fc89dc835">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8371ffdd-8d3b-4bea-a2b0-b60fc89dc835">
											<gml:posList>35.66770343852719 139.73858740065035 13.634 35.6676925271382 139.73858133830413 13.634 35.6676925271382 139.73858133830413 31.904 35.66770343852719 139.73858740065035 31.904 35.66770343852719 139.73858740065035 13.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c05509fa-27c3-496c-88f1-43e7cd8664fb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c05509fa-27c3-496c-88f1-43e7cd8664fb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c05509fa-27c3-496c-88f1-43e7cd8664fb">
											<gml:posList>35.66769375640332 139.7385856557942 31.904 35.66769375640332 139.7385856557942 31.635 35.66770492028941 139.73859186143935 31.635 35.66770492028941 139.73859186143935 31.904 35.66769375640332 139.7385856557942 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2aee22d5-0c18-4dc0-a6c3-f741b51c8147">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2aee22d5-0c18-4dc0-a6c3-f741b51c8147">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2aee22d5-0c18-4dc0-a6c3-f741b51c8147">
											<gml:posList>35.66771282387643 139.73856709825753 31.904 35.66771282387643 139.73856709825753 31.635 35.66781436563256 139.73863843421574 31.635 35.66781436563256 139.73863843421574 31.904 35.66771282387643 139.73856709825753 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b846475a-8abe-4937-8b3d-36fa43e16267">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b846475a-8abe-4937-8b3d-36fa43e16267">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b846475a-8abe-4937-8b3d-36fa43e16267">
											<gml:posList>35.6676925271382 139.73858133830413 13.634 35.66767116834037 139.7386319426552 13.634 35.66767116834037 139.7386319426552 31.904 35.6676925271382 139.73858133830413 31.904 35.6676925271382 139.73858133830413 13.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-90d80c34-0bd7-4ea3-981e-23aa52094ad2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-90d80c34-0bd7-4ea3-981e-23aa52094ad2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-90d80c34-0bd7-4ea3-981e-23aa52094ad2">
											<gml:posList>35.66767485377298 139.738630436062 31.904 35.66767485377298 139.738630436062 31.635 35.66769375640332 139.7385856557942 31.635 35.66769375640332 139.7385856557942 31.904 35.66767485377298 139.738630436062 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-21024737-ff70-49df-9b20-cead4f7d93da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21024737-ff70-49df-9b20-cead4f7d93da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21024737-ff70-49df-9b20-cead4f7d93da">
											<gml:posList>35.667817925029354 139.7386371265953 29.511 35.66786557091169 139.73867060571826 29.511 35.66786557091169 139.73867060571826 13.634 35.66771144101218 139.7385623170208 13.634 35.66771144101218 139.7385623170208 31.904 35.667817925029354 139.7386371265953 31.904 35.667817925029354 139.7386371265953 29.511</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7a371046-81a8-497d-b107-52beb8e0b65a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a371046-81a8-497d-b107-52beb8e0b65a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a371046-81a8-497d-b107-52beb8e0b65a">
											<gml:posList>35.66768892163152 139.73863861549646 31.904 35.66768892163152 139.73863861549646 31.635 35.66767485377298 139.738630436062 31.635 35.66767485377298 139.738630436062 31.904 35.66768892163152 139.73863861549646 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-efa0c7c5-d2ab-4165-9755-955c87f4c0d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-efa0c7c5-d2ab-4165-9755-955c87f4c0d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-efa0c7c5-d2ab-4165-9755-955c87f4c0d6">
											<gml:posList>35.66767116834037 139.7386319426552 13.634 35.66769002467637 139.7386428999986 13.634 35.66769002467637 139.7386428999986 31.904 35.66767116834037 139.7386319426552 31.904 35.66767116834037 139.7386319426552 13.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-995ff6cb-63ff-4e8c-869b-6728a8acab86">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-995ff6cb-63ff-4e8c-869b-6728a8acab86">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-995ff6cb-63ff-4e8c-869b-6728a8acab86">
											<gml:posList>35.667691257463524 139.73864023648363 31.904 35.667691257463524 139.73864023648363 31.635 35.66768892163152 139.73863861549646 31.635 35.66768892163152 139.73863861549646 31.904 35.667691257463524 139.73864023648363 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-722f0c81-87a1-4fe8-ad51-cbad05c1a29d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-722f0c81-87a1-4fe8-ad51-cbad05c1a29d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-722f0c81-87a1-4fe8-ad51-cbad05c1a29d">
											<gml:posList>35.66770642876865 139.73860736808788 35.238 35.66770642876865 139.73860736808788 31.635 35.667691257463524 139.73864023648363 31.635 35.667691257463524 139.73864023648363 31.904 35.66769002467637 139.7386428999986 31.904 35.66769002467637 139.7386428999986 13.634 35.66767060610654 139.7386849635719 13.634 35.66767060610654 139.7386849635719 31.904 35.66767060610654 139.7386849635719 35.238 35.66770642876865 139.73860736808788 35.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eef6e084-93fc-4c21-aeb2-fbfb802eb09e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eef6e084-93fc-4c21-aeb2-fbfb802eb09e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eef6e084-93fc-4c21-aeb2-fbfb802eb09e">
											<gml:posList>35.667673003089206 139.73868411020933 35.238 35.667673003089206 139.73868411020933 34.811 35.66770696308965 139.73861055971915 34.811 35.66770696308965 139.73861055971915 35.238 35.667673003089206 139.73868411020933 35.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7a0eeba6-a04e-439c-91ae-56a8b5211e17">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a0eeba6-a04e-439c-91ae-56a8b5211e17">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a0eeba6-a04e-439c-91ae-56a8b5211e17">
											<gml:posList>35.66770642876865 139.73860736808788 35.238 35.667790950396785 139.73868740626224 35.238 35.667790950396785 139.73868740626224 31.635 35.66770642876865 139.73860736808788 31.635 35.66770642876865 139.73860736808788 35.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5e14e7e3-9930-4c17-8178-00b66fe3294b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e14e7e3-9930-4c17-8178-00b66fe3294b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e14e7e3-9930-4c17-8178-00b66fe3294b">
											<gml:posList>35.66770696308965 139.73861055971915 35.238 35.66770696308965 139.73861055971915 34.811 35.667788715444175 139.73868798328718 34.811 35.667788715444175 139.73868798328718 35.238 35.66770696308965 139.73861055971915 35.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9bc10668-93d1-44b8-9fae-5a5118cff61e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9bc10668-93d1-44b8-9fae-5a5118cff61e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9bc10668-93d1-44b8-9fae-5a5118cff61e">
											<gml:posList>35.66767060610654 139.7386849635719 13.634 35.66765339031589 139.73867405951393 13.634 35.66765339031589 139.73867405951393 31.904 35.66767060610654 139.7386849635719 31.904 35.66767060610654 139.7386849635719 13.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6166d132-8b8b-4a4b-a9b7-ef712c2a0301">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6166d132-8b8b-4a4b-a9b7-ef712c2a0301">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6166d132-8b8b-4a4b-a9b7-ef712c2a0301">
											<gml:posList>35.667787090427446 139.73869621440227 31.635 35.667790950396785 139.73868740626224 31.635 35.667790950396785 139.73868740626224 35.238 35.667787090427446 139.73869621440227 35.238 35.667787090427446 139.73869621440227 31.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-740c47a6-68c2-49bb-ba32-38bc9a4b5c9c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-740c47a6-68c2-49bb-ba32-38bc9a4b5c9c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-740c47a6-68c2-49bb-ba32-38bc9a4b5c9c">
											<gml:posList>35.667788715444175 139.73868798328718 35.238 35.667788715444175 139.73868798328718 34.811 35.66778473851336 139.73869706771248 34.811 35.66778473851336 139.73869706771248 35.238 35.667788715444175 139.73868798328718 35.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b20d298d-b360-43ef-9344-da328af4f799">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b20d298d-b360-43ef-9344-da328af4f799">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b20d298d-b360-43ef-9344-da328af4f799">
											<gml:posList>35.66765339031589 139.73867405951393 13.634 35.667633327034146 139.7387215804863 13.634 35.667633327034146 139.7387215804863 31.904 35.66765339031589 139.73867405951393 31.904 35.66765339031589 139.73867405951393 13.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e558f625-4ada-4171-8fb1-8a612b41bee2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e558f625-4ada-4171-8fb1-8a612b41bee2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e558f625-4ada-4171-8fb1-8a612b41bee2">
											<gml:posList>35.667787090427446 139.73869621440227 35.238 35.66779825531462 139.73870370139363 35.238 35.66779825531462 139.73870370139363 31.635 35.667787090427446 139.73869621440227 31.635 35.667787090427446 139.73869621440227 35.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bf3cf173-47fc-489f-8f33-282e49619dac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf3cf173-47fc-489f-8f33-282e49619dac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf3cf173-47fc-489f-8f33-282e49619dac">
											<gml:posList>35.66778473851336 139.73869706771248 35.238 35.66778473851336 139.73869706771248 34.811 35.66779574106663 139.73870444443628 34.811 35.66779574106663 139.73870444443628 35.238 35.66778473851336 139.73869706771248 35.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-78382684-8a56-49ce-98b0-7bfc28e9eaca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78382684-8a56-49ce-98b0-7bfc28e9eaca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78382684-8a56-49ce-98b0-7bfc28e9eaca">
											<gml:posList>35.6677945469283 139.73871041063316 31.635 35.66779825531462 139.73870370139363 31.635 35.66779825531462 139.73870370139363 35.238 35.6677945469283 139.73871041063316 35.238 35.6677945469283 139.73871041063316 31.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-80ce69d8-a7c3-4b4b-9f6a-29b23fd391d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-80ce69d8-a7c3-4b4b-9f6a-29b23fd391d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-80ce69d8-a7c3-4b4b-9f6a-29b23fd391d3">
											<gml:posList>35.66779574106663 139.73870444443628 35.238 35.66779574106663 139.73870444443628 34.811 35.66779208667581 139.73871104315285 34.811 35.66779208667581 139.73871104315285 35.238 35.66779574106663 139.73870444443628 35.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d571653c-1cd1-4208-89dd-3bf1f77dce0f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d571653c-1cd1-4208-89dd-3bf1f77dce0f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d571653c-1cd1-4208-89dd-3bf1f77dce0f">
											<gml:posList>35.667649902221186 139.7387316900039 31.904 35.66767060610654 139.7386849635719 35.238 35.66767060610654 139.7386849635719 31.904 35.667649902221186 139.7387316900039 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1aeb33db-1931-4739-a69f-ca02355e01c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1aeb33db-1931-4739-a69f-ca02355e01c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1aeb33db-1931-4739-a69f-ca02355e01c1">
											<gml:posList>35.66779208667581 139.73871104315285 35.238 35.66779208667581 139.73871104315285 34.811 35.66780060072811 139.73871751705147 34.811 35.66780060072811 139.73871751705147 35.238 35.66779208667581 139.73871104315285 35.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-043c633b-207c-455e-8491-0d4b8bf5823d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-043c633b-207c-455e-8491-0d4b8bf5823d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-043c633b-207c-455e-8491-0d4b8bf5823d">
											<gml:posList>35.66777292745911 139.7387505327626 35.238 35.66777292745911 139.7387505327626 34.811 35.667673003089206 139.73868411020933 34.811 35.667673003089206 139.73868411020933 35.238 35.66777292745911 139.7387505327626 35.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fa10682f-bf76-488d-ac70-841e232a975e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa10682f-bf76-488d-ac70-841e232a975e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa10682f-bf76-488d-ac70-841e232a975e">
											<gml:posList>35.66780480788523 139.73872611684675 35.238 35.66780480788523 139.73872611684675 34.811 35.667787748141826 139.73876468717324 34.811 35.667787748141826 139.73876468717324 35.238 35.66780480788523 139.73872611684675 35.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-04fdcc94-2c7a-4a03-ad92-1d003b573b0f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04fdcc94-2c7a-4a03-ad92-1d003b573b0f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04fdcc94-2c7a-4a03-ad92-1d003b573b0f">
											<gml:posList>35.66777145181949 139.73875385931908 35.238 35.66777145181949 139.73875385931908 34.811 35.66777292745911 139.7387505327626 34.811 35.66777292745911 139.7387505327626 35.238 35.66777145181949 139.73875385931908 35.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7ed4de05-093c-4908-bbbb-800c6094cb7b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ed4de05-093c-4908-bbbb-800c6094cb7b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ed4de05-093c-4908-bbbb-800c6094cb7b">
											<gml:posList>35.66776909089993 139.73875472368397 35.238 35.66777056653959 139.73875139712763 35.238 35.66776914499098 139.73875473466606 34.986 35.66776909089993 139.73875472368397 35.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2b2913bc-dcf3-479a-9f16-52d94abc9d3e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b2913bc-dcf3-479a-9f16-52d94abc9d3e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b2913bc-dcf3-479a-9f16-52d94abc9d3e">
											<gml:posList>35.667787748141826 139.73876468717324 35.238 35.667787748141826 139.73876468717324 34.811 35.66777145181949 139.73875385931908 34.811 35.66777145181949 139.73875385931908 35.238 35.667787748141826 139.73876468717324 35.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-732ec590-468b-4ae3-92df-22ba900945f5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-732ec590-468b-4ae3-92df-22ba900945f5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-732ec590-468b-4ae3-92df-22ba900945f5">
											<gml:posList>35.66778844448018 139.73876759142428 31.635 35.66778844448018 139.73876759142428 35.238 35.66776909089993 139.73875472368397 35.238 35.66776914499098 139.73875473466606 34.986 35.66776909089993 139.73875472368397 31.635 35.66778844448018 139.73876759142428 31.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9c9a1d2c-8d6c-4a6f-8e7f-0028c777e653">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c9a1d2c-8d6c-4a6f-8e7f-0028c777e653">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c9a1d2c-8d6c-4a6f-8e7f-0028c777e653">
											<gml:posList>35.667633327034146 139.7387215804863 13.634 35.66779736538959 139.73882157327958 13.634 35.66779736538959 139.73882157327958 31.904 35.66775298756481 139.7387945189542 31.904 35.667649902221186 139.7387316900039 31.904 35.667633327034146 139.7387215804863 31.904 35.667633327034146 139.7387215804863 13.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-85b4befd-e867-4052-8cc4-dfc2bb0555bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85b4befd-e867-4052-8cc4-dfc2bb0555bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85b4befd-e867-4052-8cc4-dfc2bb0555bd">
											<gml:posList>35.66775419307129 139.73879154618646 31.904 35.66775419307129 139.73879154618646 31.635 35.66776909089993 139.73875472368397 31.635 35.66776914499098 139.73875473466606 34.986 35.66775298756481 139.7387945189542 31.904 35.66775419307129 139.73879154618646 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c1dd7518-24fe-452d-9629-d1d2cfac212c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c1dd7518-24fe-452d-9629-d1d2cfac212c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c1dd7518-24fe-452d-9629-d1d2cfac212c">
											<gml:posList>35.66779784043812 139.73881815953544 31.904 35.66779784043812 139.73881815953544 31.635 35.66775419307129 139.73879154618646 31.635 35.66775419307129 139.73879154618646 31.904 35.66779784043812 139.73881815953544 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ced2a7eb-9ae2-47df-b843-0e1be18f602b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ced2a7eb-9ae2-47df-b843-0e1be18f602b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ced2a7eb-9ae2-47df-b843-0e1be18f602b">
											<gml:posList>35.667817925029354 139.7386371265953 31.904 35.66780669714343 139.73866415813805 31.904 35.667817925029354 139.7386371265953 29.511 35.667817925029354 139.7386371265953 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f4a24cda-1afd-407f-8d6e-e85e6be93c32">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4a24cda-1afd-407f-8d6e-e85e6be93c32">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4a24cda-1afd-407f-8d6e-e85e6be93c32">
											<gml:posList>35.66781436563256 139.73863843421574 31.904 35.66781436563256 139.73863843421574 31.635 35.66780312874129 139.73866547681365 31.635 35.66780312874129 139.73866547681365 31.904 35.66781436563256 139.73863843421574 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-45af0ea7-cc3f-436d-be5e-4960e93c2f06">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45af0ea7-cc3f-436d-be5e-4960e93c2f06">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45af0ea7-cc3f-436d-be5e-4960e93c2f06">
											<gml:posList>35.66780312874129 139.73866547681365 31.904 35.66780312874129 139.73866547681365 31.635 35.66785098188817 139.7386989004731 31.635 35.66785098188817 139.7386989004731 31.904 35.66780312874129 139.73866547681365 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-92c58f50-744f-43bb-b785-d9bd649d5ee1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-92c58f50-744f-43bb-b785-d9bd649d5ee1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-92c58f50-744f-43bb-b785-d9bd649d5ee1">
											<gml:posList>35.66785364841454 139.7386969421998 29.511 35.66786557091169 139.73867060571826 29.511 35.66785364841454 139.7386969421998 31.904 35.66785364841454 139.7386969421998 29.511</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f2d851a4-566c-41c9-b8fd-adbb8373d726">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f2d851a4-566c-41c9-b8fd-adbb8373d726">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f2d851a4-566c-41c9-b8fd-adbb8373d726">
											<gml:posList>35.66785757196359 139.7387002182049 13.634 35.66786557091169 139.73867060571826 13.634 35.66786557091169 139.73867060571826 29.511 35.66785757196359 139.7387002182049 29.511 35.66785757196359 139.7387002182049 13.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8cffbc35-bd6b-4bc1-af2d-cc122e1a31b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8cffbc35-bd6b-4bc1-af2d-cc122e1a31b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8cffbc35-bd6b-4bc1-af2d-cc122e1a31b8">
											<gml:posList>35.66785406398418 139.73872107702542 31.904 35.66785406398418 139.73872107702542 29.511 35.66785364841454 139.7386969421998 29.511 35.66785364841454 139.7386969421998 31.904 35.66785406398418 139.73872107702542 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8774e541-b990-4e5c-876e-0bb695e97188">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8774e541-b990-4e5c-876e-0bb695e97188">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8774e541-b990-4e5c-876e-0bb695e97188">
											<gml:posList>35.66785098188817 139.7386989004731 31.904 35.66785098188817 139.7386989004731 31.635 35.66785135023645 139.73872029596777 31.635 35.66785135023645 139.73872029596777 31.904 35.66785098188817 139.7386989004731 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8187398d-f1c9-4f0e-a75c-b9f55f5b4c01">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8187398d-f1c9-4f0e-a75c-b9f55f5b4c01">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8187398d-f1c9-4f0e-a75c-b9f55f5b4c01">
											<gml:posList>35.6677945469283 139.73871041063316 35.238 35.667801599880384 139.73871577061968 35.238 35.667801599880384 139.73871577061968 31.635 35.6677945469283 139.73871041063316 31.635 35.6677945469283 139.73871041063316 35.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-026981f5-dfd8-4c3a-82e9-ce5a9fa00aed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-026981f5-dfd8-4c3a-82e9-ce5a9fa00aed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-026981f5-dfd8-4c3a-82e9-ce5a9fa00aed">
											<gml:posList>35.667801599880384 139.73871577061968 35.238 35.667804865262056 139.73871883752798 35.238 35.667804865262056 139.73871883752798 31.635 35.667801599880384 139.73871577061968 31.635 35.667801599880384 139.73871577061968 35.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-99db6e71-dddd-47aa-8acd-bfe86eb791ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-99db6e71-dddd-47aa-8acd-bfe86eb791ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-99db6e71-dddd-47aa-8acd-bfe86eb791ac">
											<gml:posList>35.66780060072811 139.73871751705147 35.238 35.66780060072811 139.73871751705147 34.811 35.667803505291644 139.73872024196254 34.811 35.667803505291644 139.73872024196254 35.238 35.66780060072811 139.73871751705147 35.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0f4012b9-1062-4e15-9aa0-d2bc7da2d13a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0f4012b9-1062-4e15-9aa0-d2bc7da2d13a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0f4012b9-1062-4e15-9aa0-d2bc7da2d13a">
											<gml:posList>35.667804865262056 139.73871883752798 35.238 35.667806075340515 139.73872168594355 35.238 35.667806075340515 139.73872168594355 31.635 35.667804865262056 139.73871883752798 31.635 35.667804865262056 139.73871883752798 35.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-433d432f-1920-44c2-9489-38fa09b7e913">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-433d432f-1920-44c2-9489-38fa09b7e913">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-433d432f-1920-44c2-9489-38fa09b7e913">
											<gml:posList>35.667803505291644 139.73872024196254 35.238 35.667803505291644 139.73872024196254 34.811 35.66780439027709 139.73872232859424 34.811 35.66780439027709 139.73872232859424 35.238 35.667803505291644 139.73872024196254 35.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b5dc6029-f5ef-431c-bdc8-ddd9774847e9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b5dc6029-f5ef-431c-bdc8-ddd9774847e9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b5dc6029-f5ef-431c-bdc8-ddd9774847e9">
											<gml:posList>35.667806075340515 139.73872168594355 35.238 35.66780661096891 139.73872654550965 35.238 35.66780661096891 139.73872654550965 31.635 35.667806075340515 139.73872168594355 31.635 35.667806075340515 139.73872168594355 35.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-60840eeb-b04f-4f44-8f76-b5df32954b20">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-60840eeb-b04f-4f44-8f76-b5df32954b20">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-60840eeb-b04f-4f44-8f76-b5df32954b20">
											<gml:posList>35.66780439027709 139.73872232859424 35.238 35.66780439027709 139.73872232859424 34.811 35.66780480788523 139.73872611684675 34.811 35.66780480788523 139.73872611684675 35.238 35.66780439027709 139.73872232859424 35.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-104396f9-24bd-4fe2-a6ad-a79e50a6010e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-104396f9-24bd-4fe2-a6ad-a79e50a6010e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-104396f9-24bd-4fe2-a6ad-a79e50a6010e">
											<gml:posList>35.66785757196359 139.7387002182049 29.511 35.66791054336288 139.7387431574516 29.511 35.66792016714274 139.73875095556457 27.023 35.66792016714274 139.73875095556457 13.634 35.66785757196359 139.7387002182049 13.634 35.66785757196359 139.7387002182049 29.511</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c6beb353-567c-4e8b-adce-cad47a56e083">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6beb353-567c-4e8b-adce-cad47a56e083">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6beb353-567c-4e8b-adce-cad47a56e083">
											<gml:posList>35.66784395110914 139.73874470511316 31.904 35.66784395110914 139.73874470511316 29.511 35.66785406398418 139.73872107702542 29.511 35.66785406398418 139.73872107702542 31.904 35.66784395110914 139.73874470511316 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3c334cee-844c-453c-b186-66a81811b6f5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c334cee-844c-453c-b186-66a81811b6f5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c334cee-844c-453c-b186-66a81811b6f5">
											<gml:posList>35.66785135023645 139.73872029596777 31.904 35.66785135023645 139.73872029596777 31.635 35.667840418630895 139.73874585805473 31.635 35.667840418630895 139.73874585805473 31.904 35.66785135023645 139.73872029596777 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-587df122-104d-494a-b516-82d208548c33">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-587df122-104d-494a-b516-82d208548c33">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-587df122-104d-494a-b516-82d208548c33">
											<gml:posList>35.66778844448018 139.73876759142428 31.635 35.66780661096891 139.73872654550965 31.635 35.66780661096891 139.73872654550965 35.238 35.66778844448018 139.73876759142428 35.238 35.66778844448018 139.73876759142428 31.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-767c30cb-0e49-4ebc-87df-e86ac05676f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-767c30cb-0e49-4ebc-87df-e86ac05676f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-767c30cb-0e49-4ebc-87df-e86ac05676f3">
											<gml:posList>35.66786263006619 139.7387593630965 31.904 35.66786263006619 139.7387593630965 29.511 35.66784395110914 139.73874470511316 29.511 35.66784395110914 139.73874470511316 31.904 35.66786263006619 139.7387593630965 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-667e48f8-c670-4002-9f56-43d831d46c80">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-667e48f8-c670-4002-9f56-43d831d46c80">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-667e48f8-c670-4002-9f56-43d831d46c80">
											<gml:posList>35.667840418630895 139.73874585805473 31.904 35.667840418630895 139.73874585805473 31.635 35.667859205821934 139.73876060427736 31.635 35.667859205821934 139.73876060427736 31.904 35.667840418630895 139.73874585805473 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ba4fd3d8-b6e6-4d53-893d-59572172b8a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba4fd3d8-b6e6-4d53-893d-59572172b8a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba4fd3d8-b6e6-4d53-893d-59572172b8a7">
											<gml:posList>35.667859205821934 139.73876060427736 31.904 35.667859205821934 139.73876060427736 31.635 35.66785333228069 139.7387764289496 31.635 35.66785333228069 139.7387764289496 31.904 35.667859205821934 139.73876060427736 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4b9ca8d8-faa3-4a21-a764-fa66c8a44cb0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b9ca8d8-faa3-4a21-a764-fa66c8a44cb0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b9ca8d8-faa3-4a21-a764-fa66c8a44cb0">
											<gml:posList>35.66785459778452 139.73878098941864 31.904 35.66785459778452 139.73878098941864 29.511 35.66786263006619 139.7387593630965 29.511 35.66786263006619 139.7387593630965 31.904 35.66785459778452 139.73878098941864 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0c2f1da6-e91d-41a3-ad23-36aa767b9ad1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c2f1da6-e91d-41a3-ad23-36aa767b9ad1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c2f1da6-e91d-41a3-ad23-36aa767b9ad1">
											<gml:posList>35.66785333228069 139.7387764289496 31.904 35.66785333228069 139.7387764289496 31.635 35.66784781306999 139.73877285658307 31.635 35.66784781306999 139.73877285658307 31.904 35.66785333228069 139.7387764289496 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-225e961c-87f9-4830-b3cf-b54f24b84920">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-225e961c-87f9-4830-b3cf-b54f24b84920">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-225e961c-87f9-4830-b3cf-b54f24b84920">
											<gml:posList>35.667899568471185 139.73880543623528 13.634 35.66792016714274 139.73875095556457 13.634 35.66792016714274 139.73875095556457 27.023 35.667899568471185 139.73880543623528 27.023 35.667899568471185 139.73880543623528 13.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-68436440-340a-43fd-a3a8-2c303df6024b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-68436440-340a-43fd-a3a8-2c303df6024b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-68436440-340a-43fd-a3a8-2c303df6024b">
											<gml:posList>35.66784878096487 139.7387772185763 31.904 35.66784878096487 139.7387772185763 29.511 35.66785459778452 139.73878098941864 29.511 35.66785459778452 139.73878098941864 31.904 35.66784878096487 139.7387772185763 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-99cbcc0d-8df7-426a-9ae1-6a170d427e6d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-99cbcc0d-8df7-426a-9ae1-6a170d427e6d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-99cbcc0d-8df7-426a-9ae1-6a170d427e6d">
											<gml:posList>35.66784781306999 139.73877285658307 31.904 35.66784781306999 139.73877285658307 31.635 35.66784144125709 139.7387854785259 31.635 35.66784144125709 139.7387854785259 31.904 35.66784781306999 139.73877285658307 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9f5c2d73-1142-486a-be02-299b0565fe69">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f5c2d73-1142-486a-be02-299b0565fe69">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f5c2d73-1142-486a-be02-299b0565fe69">
											<gml:posList>35.667843480119764 139.7387877184415 31.904 35.667843480119764 139.7387877184415 29.511 35.66784878096487 139.7387772185763 29.511 35.66784878096487 139.7387772185763 31.904 35.667843480119764 139.7387877184415 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5ebd5132-eb39-4716-b16f-8f45a4de2b20">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5ebd5132-eb39-4716-b16f-8f45a4de2b20">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5ebd5132-eb39-4716-b16f-8f45a4de2b20">
											<gml:posList>35.66784144125709 139.7387854785259 31.904 35.66784144125709 139.7387854785259 31.635 35.66783492914645 139.73879161668373 31.635 35.66783492914645 139.73879161668373 31.904 35.66784144125709 139.7387854785259 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4e3f6242-9e7c-4048-8a37-4b6b8462d5c0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4e3f6242-9e7c-4048-8a37-4b6b8462d5c0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4e3f6242-9e7c-4048-8a37-4b6b8462d5c0">
											<gml:posList>35.66782816150324 139.73879374547735 31.904 35.66782816150324 139.73879374547735 31.635 35.667813906422694 139.73878818410194 31.635 35.667813906422694 139.73878818410194 31.904 35.66782816150324 139.73879374547735 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7b4d2074-bc15-48c9-94f9-40ad92ce7bda">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b4d2074-bc15-48c9-94f9-40ad92ce7bda">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b4d2074-bc15-48c9-94f9-40ad92ce7bda">
											<gml:posList>35.66783612134316 139.73879465290298 31.904 35.66783612134316 139.73879465290298 29.511 35.667843480119764 139.7387877184415 29.511 35.667843480119764 139.7387877184415 31.904 35.66783612134316 139.73879465290298 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-054ac0ff-fc4b-4a23-a450-45f41bae1246">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-054ac0ff-fc4b-4a23-a450-45f41bae1246">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-054ac0ff-fc4b-4a23-a450-45f41bae1246">
											<gml:posList>35.66783492914645 139.73879161668373 31.904 35.66783492914645 139.73879161668373 31.635 35.66782816150324 139.73879374547735 31.635 35.66782816150324 139.73879374547735 31.904 35.66783492914645 139.73879161668373 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-659b80a1-a407-42ca-be2a-86188bb925f1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-659b80a1-a407-42ca-be2a-86188bb925f1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-659b80a1-a407-42ca-be2a-86188bb925f1">
											<gml:posList>35.66781523457121 139.73879217010796 31.904 35.66781523457121 139.73879217010796 29.511 35.66782808307671 139.73879718084711 29.511 35.66782808307671 139.73879718084711 31.904 35.66781523457121 139.73879217010796 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c71ae075-0ee1-4b1d-b9f7-77d976938ec1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c71ae075-0ee1-4b1d-b9f7-77d976938ec1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c71ae075-0ee1-4b1d-b9f7-77d976938ec1">
											<gml:posList>35.66782808307671 139.73879718084711 31.904 35.66782808307671 139.73879718084711 29.511 35.66783612134316 139.73879465290298 29.511 35.66783612134316 139.73879465290298 31.904 35.66782808307671 139.73879718084711 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c6ce5a93-8d3a-4bbc-aab0-c895864e92db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6ce5a93-8d3a-4bbc-aab0-c895864e92db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6ce5a93-8d3a-4bbc-aab0-c895864e92db">
											<gml:posList>35.667813906422694 139.73878818410194 31.904 35.667813906422694 139.73878818410194 31.635 35.667801220177935 139.73881763639423 31.635 35.667801220177935 139.73881763639423 31.904 35.667813906422694 139.73878818410194 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-abe34204-edd3-47b0-8ee4-32c7967fa485">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-abe34204-edd3-47b0-8ee4-32c7967fa485">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-abe34204-edd3-47b0-8ee4-32c7967fa485">
											<gml:posList>35.66780294420116 139.73882069407756 31.904 35.66780294420116 139.73882069407756 29.511 35.66781523457121 139.73879217010796 29.511 35.66781523457121 139.73879217010796 31.904 35.66780294420116 139.73882069407756 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6c961131-c62f-409d-bef6-2bf6701afb68">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c961131-c62f-409d-bef6-2bf6701afb68">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c961131-c62f-409d-bef6-2bf6701afb68">
											<gml:posList>35.66779736538959 139.73882157327958 13.634 35.667899568471185 139.73880543623528 13.634 35.667899568471185 139.73880543623528 27.023 35.667882597714836 139.73880811830722 29.511 35.66780294420116 139.73882069407756 29.511 35.66780294420116 139.73882069407756 31.904 35.66779736538959 139.73882157327958 31.904 35.66779736538959 139.73882157327958 13.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-85278fac-6dbc-4b59-a208-0863acd8efee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85278fac-6dbc-4b59-a208-0863acd8efee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85278fac-6dbc-4b59-a208-0863acd8efee">
											<gml:posList>35.667801220177935 139.73881763639423 31.904 35.667801220177935 139.73881763639423 31.635 35.66779784043812 139.73881815953544 31.635 35.66779784043812 139.73881815953544 31.904 35.667801220177935 139.73881763639423 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区六本木二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4786</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">414.2718</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">5</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>3</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingLandSlideRiskAttribute>
					<uro:description codeSpace="../../codelists/LandSlideRiskAttribute_description.xml">1</uro:description>
					<uro:areaType codeSpace="../../codelists/LandSlideRiskAttribute_areaType.xml">2</uro:areaType>
				</uro:BuildingLandSlideRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">105</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key105.xml">3</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">20</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>