<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_5ae88dbb-e6ae-4c07-ab85-baa30efead7b">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">24.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66887785571573 139.73792501716997 0 35.66879522844866 139.7378474618208 0 35.66867216667448 139.738044338055 0 35.66868723069498 139.7380583486059 0 35.66866598390813 139.73809073869938 0 35.66872939956454 139.73815285253173 0 35.66887785571573 139.73792501716997 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66887785571573 139.73792501716997 21.23 35.66872939956454 139.73815285253173 21.23 35.66866598390813 139.73809073869938 21.23 35.66868723069498 139.7380583486059 21.23 35.66867216667448 139.738044338055 21.23 35.66879522844866 139.7378474618208 21.23 35.66887785571573 139.73792501716997 21.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66887785571573 139.73792501716997 21.23 35.66879522844866 139.7378474618208 21.23 35.66879522844866 139.7378474618208 45.53 35.66887785571573 139.73792501716997 45.53 35.66887785571573 139.73792501716997 21.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66879522844866 139.7378474618208 21.23 35.66867216667448 139.738044338055 21.23 35.66867216667448 139.738044338055 45.53 35.66879522844866 139.7378474618208 45.53 35.66879522844866 139.7378474618208 21.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66867216667448 139.738044338055 21.23 35.66868723069498 139.7380583486059 21.23 35.66868723069498 139.7380583486059 45.53 35.66867216667448 139.738044338055 45.53 35.66867216667448 139.738044338055 21.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66868723069498 139.7380583486059 21.23 35.66866598390813 139.73809073869938 21.23 35.66866598390813 139.73809073869938 45.53 35.66868723069498 139.7380583486059 45.53 35.66868723069498 139.7380583486059 21.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66866598390813 139.73809073869938 21.23 35.66872939956454 139.73815285253173 21.23 35.66872939956454 139.73815285253173 45.53 35.66866598390813 139.73809073869938 45.53 35.66866598390813 139.73809073869938 21.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66872939956454 139.73815285253173 21.23 35.66887785571573 139.73792501716997 21.23 35.66887785571573 139.73792501716997 45.53 35.66872939956454 139.73815285253173 45.53 35.66872939956454 139.73815285253173 21.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66887785571573 139.73792501716997 45.53 35.66879522844866 139.7378474618208 45.53 35.66867216667448 139.738044338055 45.53 35.66868723069498 139.7380583486059 45.53 35.66866598390813 139.73809073869938 45.53 35.66872939956454 139.73815285253173 45.53 35.66887785571573 139.73792501716997 45.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-6fa2a7eb-2296-4bd4-9383-799fc87e83cb"/>
							<gml:surfaceMember xlink:href="#poly-70310a95-074c-4bd3-8f2a-21451d0db707"/>
							<gml:surfaceMember xlink:href="#poly-59d3d515-65e2-4d20-bc38-5363fa90f473"/>
							<gml:surfaceMember xlink:href="#poly-d4f48cd1-133a-4067-85e3-797505ad9476"/>
							<gml:surfaceMember xlink:href="#poly-991e0363-9097-4e79-a27f-855e5910c283"/>
							<gml:surfaceMember xlink:href="#poly-48c919f3-ebb9-445e-b40a-1fffbf8db5f6"/>
							<gml:surfaceMember xlink:href="#poly-4ca4c95f-5bc8-4674-bd54-fe4afa0347b6"/>
							<gml:surfaceMember xlink:href="#poly-f6ca353a-5d37-48ae-8b84-f557f7b26c8e"/>
							<gml:surfaceMember xlink:href="#poly-0e338592-5121-411e-be22-258e889f9e5c"/>
							<gml:surfaceMember xlink:href="#poly-e29f4166-a552-4d3d-ba36-3ab673d7f418"/>
							<gml:surfaceMember xlink:href="#poly-d86bfe1d-3b8e-42c7-a0c6-8184ae8e17c3"/>
							<gml:surfaceMember xlink:href="#poly-cf3abede-6072-4bdc-a10e-619ab7801b71"/>
							<gml:surfaceMember xlink:href="#poly-e21bc631-69c5-4229-8f46-6270d5039da6"/>
							<gml:surfaceMember xlink:href="#poly-fa4b7f02-44ff-4be7-8916-aa258e7c8d27"/>
							<gml:surfaceMember xlink:href="#poly-9b27aeb8-2bd5-4f1f-bc69-9bedce695110"/>
							<gml:surfaceMember xlink:href="#poly-250e07a6-32bf-4ea6-bf4c-c9db5483ce48"/>
							<gml:surfaceMember xlink:href="#poly-a8fb1943-1ae5-4f19-a7d6-2877aa35829f"/>
							<gml:surfaceMember xlink:href="#poly-148d750a-a2aa-45cf-b46b-ddcf1509a307"/>
							<gml:surfaceMember xlink:href="#poly-8b8669ea-6877-4ea0-a9be-1371c542012b"/>
							<gml:surfaceMember xlink:href="#poly-755405e8-7254-4f43-be86-44203fd2c40f"/>
							<gml:surfaceMember xlink:href="#poly-f167a358-c4c5-43ea-88f1-83a537f14350"/>
							<gml:surfaceMember xlink:href="#poly-23cc6bef-4960-4136-930a-6b8ec4f3e44f"/>
							<gml:surfaceMember xlink:href="#poly-23c246ca-54f7-438f-a864-b95531adc50c"/>
							<gml:surfaceMember xlink:href="#poly-c26e29ad-bd91-476b-92e0-d2e287ecafda"/>
							<gml:surfaceMember xlink:href="#poly-15971189-b2e6-4d98-b1cc-8c61693b8a70"/>
							<gml:surfaceMember xlink:href="#poly-96d59ce2-e65b-4094-8db0-f2418f581728"/>
							<gml:surfaceMember xlink:href="#poly-479f090d-d921-4404-af52-4253db5db8d8"/>
							<gml:surfaceMember xlink:href="#poly-0e1876b0-6222-40d1-b3e0-b59ae408d351"/>
							<gml:surfaceMember xlink:href="#poly-f2d26769-ebd1-4ee6-b550-85614170a6df"/>
							<gml:surfaceMember xlink:href="#poly-10d440a9-4472-451b-936a-b70260a9f087"/>
							<gml:surfaceMember xlink:href="#poly-d4719e0e-a442-4534-9da1-7f192ec5d9dc"/>
							<gml:surfaceMember xlink:href="#poly-5cabedbc-a06f-4e05-bd04-4a3a40c8edbc"/>
							<gml:surfaceMember xlink:href="#poly-b764807b-6ef5-42a3-879a-0015908060e8"/>
							<gml:surfaceMember xlink:href="#poly-7be6843c-3271-4198-9e20-2b0ce5fff5cd"/>
							<gml:surfaceMember xlink:href="#poly-5e4d8a6b-e9bc-435a-bc3b-7477c408a062"/>
							<gml:surfaceMember xlink:href="#poly-2b5c12f2-0538-4602-87f7-6cde80d088f7"/>
							<gml:surfaceMember xlink:href="#poly-6196e13a-6ea4-4a24-8ea9-e534bdbe00da"/>
							<gml:surfaceMember xlink:href="#poly-03d43e75-6afc-4226-9f63-7f74cb3fb636"/>
							<gml:surfaceMember xlink:href="#poly-9e071dc9-0f19-4f41-b24b-ce9e7ce39b49"/>
							<gml:surfaceMember xlink:href="#poly-52657872-fb3a-46c5-b875-10bf67773c7e"/>
							<gml:surfaceMember xlink:href="#poly-674326de-fe7c-41ab-9266-0c45d8c5f245"/>
							<gml:surfaceMember xlink:href="#poly-dadd39c8-c3a9-47c7-a828-4d581fdf6d97"/>
							<gml:surfaceMember xlink:href="#poly-b42050e4-fa1e-4fae-b9e9-919f701fb6f0"/>
							<gml:surfaceMember xlink:href="#poly-67a5fcb1-e0fc-41e5-ad8e-49ca1faf1307"/>
							<gml:surfaceMember xlink:href="#poly-d9096314-a22b-48e7-8a86-379655284c93"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_5ae88dbb-e6ae-4c07-ab85-baa30efead7b_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6bdacd44-3e71-4352-bdba-eb5589000388">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668818018547135 139.73787446435048 42.146 35.66886629741673 139.73792161769353 42.095 35.66884259312293 139.73795805367226 42.095 35.66884110471227 139.7379566084105 42.097 35.668863701665444 139.73792187484148 42.096 35.66881895889915 139.73787815260968 42.144 35.66880924491947 139.73789308737773 42.143 35.668807197219365 139.7378910904814 42.146 35.668818018547135 139.73787446435048 42.146</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf3ab5a3-280b-4c5a-b023-8cffb41c0022">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66875044723253 139.73797133015137 48.158 35.6687749091387 139.73793546771108 48.158 35.66879085836278 139.73795180792087 48.158 35.66877798367092 139.73797067882373 48.158 35.6687799502637 139.7379726979099 48.158 35.668774809383976 139.7379802263758 48.158 35.668772842800074 139.73797821833563 48.158 35.668766396451815 139.7379876703633 48.158 35.66875044723253 139.73797133015137 48.158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84e953e3-aacd-4a0f-94f0-9bedab4e9a9f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668694094339166 139.73804086563575 48.158 35.66870077462891 139.7380308831335 48.158 35.6687141706748 139.73804434336756 48.158 35.668707499397684 139.73805432585968 48.158 35.668694094339166 139.73804086563575 48.158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70f821aa-1370-4b0f-ac9f-ae6baac32fbd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66869126836288 139.73805773627677 48.158 35.66868202243405 139.73804907613328 48.158 35.66868749577702 139.73804022176228 48.158 35.66870678263473 139.7380598055416 48.158 35.668721143066804 139.7380389888027 48.158 35.66871565832512 139.73803343916813 48.158 35.668751246939635 139.73797953640408 48.158 35.66877277890652 139.73799997910595 48.158 35.66869530674548 139.73811500512863 48.158 35.668669976568744 139.73809020374767 48.159 35.66869126836288 139.73805773627677 48.158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4885f40-f63b-406d-bc3e-d02c74eb6c6a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668707499397684 139.73805432585968 48.158 35.6687141706748 139.73804434336756 48.158 35.6687141706748 139.73804434336756 49.453 35.668707499397684 139.73805432585968 49.453 35.668707499397684 139.73805432585968 48.158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1a387e9-fa25-466d-b1d1-6834df3dc594">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66868969146798 139.73805837882 48.732 35.66868116721404 139.7380504468567 48.732 35.66868200442408 139.73804909824673 48.732 35.66869126836288 139.73805773627677 48.732 35.66868969146798 139.73805837882 48.732</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63b55915-0a37-4d9d-bdd3-9d6662e3e714">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668670184688196 139.73809121973466 48.732 35.66869393639729 139.73811467537516 48.732 35.66869435054822 139.73811406735183 48.732 35.66869530674548 139.73811500512863 48.732 35.66869403731264 139.73811690655276 48.732 35.6686679855316 139.73809146535933 48.732 35.66868969146798 139.73805837882 48.732 35.66869126836288 139.73805773627677 48.732 35.668669976568744 139.73809020374767 48.732 35.668670508789134 139.7380907222786 48.732 35.668670184688196 139.73809121973466 48.732</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8bd20cb1-4921-4fa0-945e-ed83f9c18be8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8bd20cb1-4921-4fa0-945e-ed83f9c18be8_0">
											<gml:posList>35.668772842800074 139.73797821833563 48.158 35.668774809383976 139.7379802263758 48.158 35.668774809383976 139.7379802263758 49.304 35.668772842800074 139.73797821833563 49.304 35.668772842800074 139.73797821833563 48.158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fadedb8e-ef4a-4855-b4e8-c68969666581">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fadedb8e-ef4a-4855-b4e8-c68969666581_0">
											<gml:posList>35.66871764115219 139.7380331937988 49.517 35.66871764115219 139.7380331937988 48.578 35.6687514832033 139.73798194415872 48.578 35.6687514832033 139.73798194415872 49.517 35.66871764115219 139.7380331937988 49.517</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b64e9afe-b868-4a99-8751-4244e96c0a99">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b64e9afe-b868-4a99-8751-4244e96c0a99_0">
											<gml:posList>35.668707499397684 139.73805432585968 48.158 35.668707499397684 139.73805432585968 49.453 35.668694094339166 139.73804086563575 49.453 35.668694094339166 139.73804086563575 48.158 35.668707499397684 139.73805432585968 48.158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48a80220-c615-42d9-92f1-feb16951b06b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-48a80220-c615-42d9-92f1-feb16951b06b_0">
											<gml:posList>35.66872314393882 139.73803876550414 49.517 35.66870695580946 139.7380622244161 49.517 35.66870695580946 139.7380622244161 48.578 35.66872314393882 139.73803876550414 48.578 35.66872314393882 139.73803876550414 49.517</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-21084f2a-e52f-4c09-a889-30de7b43dc68">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-21084f2a-e52f-4c09-a889-30de7b43dc68_0">
											<gml:posList>35.66868314096626 139.7380501241765 48.578 35.66868314096626 139.7380501241765 49.517 35.6686917012926 139.73805807818917 49.517 35.6686917012926 139.73805807818917 48.578 35.66868314096626 139.7380501241765 48.578</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-52e67ba4-bb52-40db-9941-c32cc4f401ee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-52e67ba4-bb52-40db-9941-c32cc4f401ee_0">
											<gml:posList>35.668670508789134 139.7380907222786 48.578 35.6686917012926 139.73805807818917 48.578 35.6686917012926 139.73805807818917 49.517 35.668670184688196 139.73809121973466 49.517 35.668670184688196 139.73809121973466 48.732 35.668670508789134 139.7380907222786 48.732 35.668670508789134 139.7380907222786 48.578</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb96fcff-cb02-487a-8901-809a52eed258">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb96fcff-cb02-487a-8901-809a52eed258_0">
											<gml:posList>35.668807197219365 139.7378910904814 43.611 35.668818018547135 139.73787446435048 43.611 35.668818018547135 139.73787446435048 42.146 35.668807197219365 139.7378910904814 42.146 35.668807197219365 139.7378910904814 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6800204f-de02-436a-8ba1-6038e1b2bfbf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6800204f-de02-436a-8ba1-6038e1b2bfbf_0">
											<gml:posList>35.66881895889915 139.73787815260968 42.144 35.66881895889915 139.73787815260968 43.611 35.66880924491947 139.73789308737773 43.611 35.66880924491947 139.73789308737773 42.143 35.66881895889915 139.73787815260968 42.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a2626ca-a43a-401a-8d05-4c4f8892a872">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1a2626ca-a43a-401a-8d05-4c4f8892a872_0">
											<gml:posList>35.668807197219365 139.7378910904814 42.146 35.66880924491947 139.73789308737773 42.143 35.66880924491947 139.73789308737773 43.611 35.668807197219365 139.7378910904814 43.611 35.668807197219365 139.7378910904814 42.146</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-069df16b-5b61-4f27-a0e7-d3819de6e2f4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-069df16b-5b61-4f27-a0e7-d3819de6e2f4_0">
											<gml:posList>35.668818018547135 139.73787446435048 42.146 35.668818018547135 139.73787446435048 43.611 35.66886629741673 139.73792161769353 43.611 35.66886629741673 139.73792161769353 42.095 35.668818018547135 139.73787446435048 42.146</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-207ff2b1-7aa0-499e-8bb5-0bdebd2f727b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-207ff2b1-7aa0-499e-8bb5-0bdebd2f727b_0">
											<gml:posList>35.66881895889915 139.73787815260968 42.144 35.668863701665444 139.73792187484148 42.096 35.668863701665444 139.73792187484148 43.611 35.66881895889915 139.73787815260968 43.611 35.66881895889915 139.73787815260968 42.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b740cbb-d436-47ca-a855-0f8f475a3731">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6b740cbb-d436-47ca-a855-0f8f475a3731_0">
											<gml:posList>35.66881895889915 139.73787815260968 43.611 35.668863701665444 139.73792187484148 43.611 35.66884110471227 139.7379566084105 43.611 35.66884259312293 139.73795805367226 43.611 35.66886629741673 139.73792161769353 43.611 35.668818018547135 139.73787446435048 43.611 35.668807197219365 139.7378910904814 43.611 35.66880924491947 139.73789308737773 43.611 35.66881895889915 139.73787815260968 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d073dcc-b71a-43e3-91fc-451f0d5244e8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d073dcc-b71a-43e3-91fc-451f0d5244e8_0">
											<gml:posList>35.66884110471227 139.7379566084105 42.097 35.66884110471227 139.7379566084105 43.611 35.668863701665444 139.73792187484148 43.611 35.668863701665444 139.73792187484148 42.096 35.66884110471227 139.7379566084105 42.097</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-54f8c9eb-1cd0-43ff-a8a0-c300ff9b3e80">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-54f8c9eb-1cd0-43ff-a8a0-c300ff9b3e80_0">
											<gml:posList>35.66886629741673 139.73792161769353 42.095 35.66886629741673 139.73792161769353 43.611 35.66884259312293 139.73795805367226 43.611 35.66884259312293 139.73795805367226 42.095 35.66886629741673 139.73792161769353 42.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c6e0ad4-ba7f-4ea4-88f1-77af567dcbc7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6c6e0ad4-ba7f-4ea4-88f1-77af567dcbc7_0">
											<gml:posList>35.6687749091387 139.73793546771108 48.158 35.6687749091387 139.73793546771108 49.304 35.66879085836278 139.73795180792087 49.304 35.66879085836278 139.73795180792087 48.158 35.6687749091387 139.73793546771108 48.158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9054c1f8-b3bd-4d19-85ec-34395844054f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9054c1f8-b3bd-4d19-85ec-34395844054f_0">
											<gml:posList>35.6687749091387 139.73793546771108 48.158 35.66875044723253 139.73797133015137 48.158 35.66875044723253 139.73797133015137 49.304 35.6687749091387 139.73793546771108 49.304 35.6687749091387 139.73793546771108 48.158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0c20f2f-6aac-421d-8e17-2be9648437e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d0c20f2f-6aac-421d-8e17-2be9648437e2_0">
											<gml:posList>35.66884259312293 139.73795805367226 43.611 35.66884110471227 139.7379566084105 43.611 35.66884110471227 139.7379566084105 42.097 35.66884259312293 139.73795805367226 42.095 35.66884259312293 139.73795805367226 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1cc1df33-82ea-4662-a38c-d2ac3297be33">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1cc1df33-82ea-4662-a38c-d2ac3297be33_0">
											<gml:posList>35.66877798367092 139.73797067882373 48.158 35.66879085836278 139.73795180792087 48.158 35.66879085836278 139.73795180792087 49.304 35.66877798367092 139.73797067882373 49.304 35.66877798367092 139.73797067882373 48.158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d28e2545-ac4a-43da-95d3-492cb271605e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d28e2545-ac4a-43da-95d3-492cb271605e_0">
											<gml:posList>35.668772842800074 139.73797821833563 49.304 35.668774809383976 139.7379802263758 49.304 35.6687799502637 139.7379726979099 49.304 35.66877798367092 139.73797067882373 49.304 35.66879085836278 139.73795180792087 49.304 35.6687749091387 139.73793546771108 49.304 35.66875044723253 139.73797133015137 49.304 35.668766396451815 139.7379876703633 49.304 35.668772842800074 139.73797821833563 49.304</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b9b71cf-247f-4e53-8475-23abb7af47c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b9b71cf-247f-4e53-8475-23abb7af47c7_0">
											<gml:posList>35.6687799502637 139.7379726979099 48.158 35.66877798367092 139.73797067882373 48.158 35.66877798367092 139.73797067882373 49.304 35.6687799502637 139.7379726979099 49.304 35.6687799502637 139.7379726979099 48.158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-15491fbf-1ca9-434c-ba37-368e40483c35">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-15491fbf-1ca9-434c-ba37-368e40483c35_0">
											<gml:posList>35.668774809383976 139.7379802263758 48.158 35.6687799502637 139.7379726979099 48.158 35.6687799502637 139.7379726979099 49.304 35.668774809383976 139.7379802263758 49.304 35.668774809383976 139.7379802263758 48.158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a06efe0-f7ab-4ceb-bae4-03b727508784">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2a06efe0-f7ab-4ceb-bae4-03b727508784_0">
											<gml:posList>35.668766396451815 139.7379876703633 48.158 35.668766396451815 139.7379876703633 49.304 35.66875044723253 139.73797133015137 49.304 35.66875044723253 139.73797133015137 48.158 35.668766396451815 139.7379876703633 48.158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3de1e08-a629-4086-be07-57519bf8a353">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b3de1e08-a629-4086-be07-57519bf8a353_0">
											<gml:posList>35.668766396451815 139.7379876703633 48.158 35.668772842800074 139.73797821833563 48.158 35.668772842800074 139.73797821833563 49.304 35.668766396451815 139.7379876703633 49.304 35.668766396451815 139.7379876703633 48.158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8bdd72b-6a8f-4b26-8c5d-d13b842c1189">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b8bdd72b-6a8f-4b26-8c5d-d13b842c1189_0">
											<gml:posList>35.66877277890652 139.73799997910595 48.158 35.668751246939635 139.73797953640408 48.158 35.668751246939635 139.73797953640408 49.517 35.66877277890652 139.73799997910595 49.517 35.66877277890652 139.73799997910595 48.158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f145b79-6139-472e-865a-a44fa516dc6f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f145b79-6139-472e-865a-a44fa516dc6f_0">
											<gml:posList>35.6687514832033 139.73798194415872 49.517 35.6687514832033 139.73798194415872 48.578 35.66877076005087 139.73800025765723 48.578 35.66877076005087 139.73800025765723 49.517 35.6687514832033 139.73798194415872 49.517</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4fc8b1b2-e21e-4d1c-92ae-40c3d86add06">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4fc8b1b2-e21e-4d1c-92ae-40c3d86add06_0">
											<gml:posList>35.66871565832512 139.73803343916813 48.158 35.66871565832512 139.73803343916813 49.517 35.668751246939635 139.73797953640408 49.517 35.668751246939635 139.73797953640408 48.158 35.66871565832512 139.73803343916813 48.158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11e99884-ebfb-4998-83b5-d6a16286d505">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-11e99884-ebfb-4998-83b5-d6a16286d505_0">
											<gml:posList>35.66868314096626 139.7380501241765 49.517 35.668687732100665 139.73804270683723 49.517 35.66870695580946 139.7380622244161 49.517 35.66872314393882 139.73803876550414 49.517 35.66871764115219 139.7380331937988 49.517 35.6687514832033 139.73798194415872 49.517 35.66877076005087 139.73800025765723 49.517 35.66877277890652 139.73799997910595 49.517 35.668751246939635 139.73797953640408 49.517 35.66871565832512 139.73803343916813 49.517 35.668721143066804 139.7380389888027 49.517 35.66870678263473 139.7380598055416 49.517 35.66868749577702 139.73804022176228 49.517 35.66868116721404 139.7380504468567 49.517 35.66868969146798 139.73805837882 49.517 35.6686917012926 139.73805807818917 49.517 35.66868314096626 139.7380501241765 49.517</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b0e1f92-55cd-406b-ae07-ce2eb9d8dd05">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0b0e1f92-55cd-406b-ae07-ce2eb9d8dd05_0">
											<gml:posList>35.668694094339166 139.73804086563575 48.158 35.668694094339166 139.73804086563575 49.453 35.66870077462891 139.7380308831335 49.453 35.66870077462891 139.7380308831335 48.158 35.668694094339166 139.73804086563575 48.158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8eee289-be8c-46ed-963f-9a62795e3f78">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d8eee289-be8c-46ed-963f-9a62795e3f78_0">
											<gml:posList>35.66872314393882 139.73803876550414 49.517 35.66872314393882 139.73803876550414 48.578 35.66871764115219 139.7380331937988 48.578 35.66871764115219 139.7380331937988 49.517 35.66872314393882 139.73803876550414 49.517</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f1772d35-765b-4834-9cb1-167b85895f14">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f1772d35-765b-4834-9cb1-167b85895f14_0">
											<gml:posList>35.66871565832512 139.73803343916813 48.158 35.668721143066804 139.7380389888027 48.158 35.668721143066804 139.7380389888027 49.517 35.66871565832512 139.73803343916813 49.517 35.66871565832512 139.73803343916813 48.158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8fa4973-9b37-4916-89b4-42d3579b9cb4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b8fa4973-9b37-4916-89b4-42d3579b9cb4_0">
											<gml:posList>35.6687141706748 139.73804434336756 48.158 35.66870077462891 139.7380308831335 48.158 35.66870077462891 139.7380308831335 49.453 35.6687141706748 139.73804434336756 49.453 35.6687141706748 139.73804434336756 48.158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f25d61e8-038f-425e-b3a4-bd7654a41cfb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f25d61e8-038f-425e-b3a4-bd7654a41cfb_0">
											<gml:posList>35.668694094339166 139.73804086563575 49.453 35.668707499397684 139.73805432585968 49.453 35.6687141706748 139.73804434336756 49.453 35.66870077462891 139.7380308831335 49.453 35.668694094339166 139.73804086563575 49.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b0cdf123-7bae-42e0-956d-79d774329f43">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b0cdf123-7bae-42e0-956d-79d774329f43_0">
											<gml:posList>35.66868116721404 139.7380504468567 48.732 35.66868116721404 139.7380504468567 49.517 35.66868749577702 139.73804022176228 49.517 35.66868749577702 139.73804022176228 48.158 35.66868202243405 139.73804907613328 48.158 35.66868200442408 139.73804909824673 48.732 35.66868116721404 139.7380504468567 48.732</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-254755a7-9b11-4e60-80df-b977308f53f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-254755a7-9b11-4e60-80df-b977308f53f8_0">
											<gml:posList>35.668687732100665 139.73804270683723 48.578 35.668687732100665 139.73804270683723 49.517 35.66868314096626 139.7380501241765 49.517 35.66868314096626 139.7380501241765 48.578 35.668687732100665 139.73804270683723 48.578</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d278fc9-31fb-449d-85c0-68ec4efd4527">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d278fc9-31fb-449d-85c0-68ec4efd4527_0">
											<gml:posList>35.668687732100665 139.73804270683723 48.578 35.66868314096626 139.7380501241765 48.578 35.6686917012926 139.73805807818917 48.578 35.668670508789134 139.7380907222786 48.578 35.66869435054822 139.73811406735183 48.578 35.66877076005087 139.73800025765723 48.578 35.6687514832033 139.73798194415872 48.578 35.66871764115219 139.7380331937988 48.578 35.66872314393882 139.73803876550414 48.578 35.66870695580946 139.7380622244161 48.578 35.668687732100665 139.73804270683723 48.578</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eced7619-912c-4deb-a915-9ba178e0c25a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eced7619-912c-4deb-a915-9ba178e0c25a_0">
											<gml:posList>35.668721143066804 139.7380389888027 48.158 35.66870678263473 139.7380598055416 48.158 35.66870678263473 139.7380598055416 49.517 35.668721143066804 139.7380389888027 49.517 35.668721143066804 139.7380389888027 48.158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f86d05b6-7c9f-4c79-ac4a-18623af21c29">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f86d05b6-7c9f-4c79-ac4a-18623af21c29_0">
											<gml:posList>35.66870678263473 139.7380598055416 48.158 35.66868749577702 139.73804022176228 48.158 35.66868749577702 139.73804022176228 49.517 35.66870678263473 139.7380598055416 49.517 35.66870678263473 139.7380598055416 48.158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9e50e58-6393-46f1-bc1c-2211c505eae4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e9e50e58-6393-46f1-bc1c-2211c505eae4_0">
											<gml:posList>35.66870695580946 139.7380622244161 49.517 35.668687732100665 139.73804270683723 49.517 35.668687732100665 139.73804270683723 48.578 35.66870695580946 139.7380622244161 48.578 35.66870695580946 139.7380622244161 49.517</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-83fb9ec9-26e4-4de2-aa8a-49a079f4ffa0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-83fb9ec9-26e4-4de2-aa8a-49a079f4ffa0_0">
											<gml:posList>35.66868969146798 139.73805837882 48.732 35.66868969146798 139.73805837882 49.517 35.66868116721404 139.7380504468567 49.517 35.66868116721404 139.7380504468567 48.732 35.66868969146798 139.73805837882 48.732</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-899f0419-ca0c-4fac-875e-71b4da3a86bc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-899f0419-ca0c-4fac-875e-71b4da3a86bc_0">
											<gml:posList>35.66869435054822 139.73811406735183 48.732 35.66869393639729 139.73811467537516 48.732 35.66869393639729 139.73811467537516 49.517 35.66877076005087 139.73800025765723 49.517 35.66877076005087 139.73800025765723 48.578 35.66869435054822 139.73811406735183 48.578 35.66869435054822 139.73811406735183 48.732</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ee747427-c9d9-4ada-a542-fbddfabe62ff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ee747427-c9d9-4ada-a542-fbddfabe62ff_0">
											<gml:posList>35.66877076005087 139.73800025765723 49.517 35.66869393639729 139.73811467537516 49.517 35.66869403731264 139.73811690655276 49.518 35.66877277890652 139.73799997910595 49.517 35.66877076005087 139.73800025765723 49.517</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e74f70f-f06c-4efb-b4f7-a2f532fdf253">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9e74f70f-f06c-4efb-b4f7-a2f532fdf253_0">
											<gml:posList>35.66877277890652 139.73799997910595 49.517 35.66869403731264 139.73811690655276 49.518 35.66869403731264 139.73811690655276 48.732 35.66869530674548 139.73811500512863 48.732 35.66869530674548 139.73811500512863 48.158 35.66877277890652 139.73799997910595 48.158 35.66877277890652 139.73799997910595 49.517</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b4abbf3-5ee1-476c-89e5-dcb74a29b819">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2b4abbf3-5ee1-476c-89e5-dcb74a29b819_0">
											<gml:posList>35.66869126836288 139.73805773627677 48.732 35.66869126836288 139.73805773627677 48.158 35.668669976568744 139.73809020374767 48.159 35.668669976568744 139.73809020374767 48.732 35.66869126836288 139.73805773627677 48.732</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-15cdf7ce-f1c3-4832-ae42-d990637a5f29">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-15cdf7ce-f1c3-4832-ae42-d990637a5f29_0">
											<gml:posList>35.668670184688196 139.73809121973466 49.517 35.6686917012926 139.73805807818917 49.517 35.66868969146798 139.73805837882 49.517 35.6686679855316 139.73809146535933 49.517 35.668670184688196 139.73809121973466 49.517</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6aa820fb-30ff-4fac-ab6a-95731225e925">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6aa820fb-30ff-4fac-ab6a-95731225e925_0">
											<gml:posList>35.6686679855316 139.73809146535933 48.732 35.6686679855316 139.73809146535933 49.517 35.66868969146798 139.73805837882 49.517 35.66868969146798 139.73805837882 48.732 35.6686679855316 139.73809146535933 48.732</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-62ba890d-d6f7-426c-be1c-69842d18dcac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-62ba890d-d6f7-426c-be1c-69842d18dcac_0">
											<gml:posList>35.668669976568744 139.73809020374767 48.732 35.668669976568744 139.73809020374767 48.159 35.66869530674548 139.73811500512863 48.158 35.66869530674548 139.73811500512863 48.732 35.66869435054822 139.73811406735183 48.732 35.66869435054822 139.73811406735183 48.578 35.668670508789134 139.7380907222786 48.578 35.668670508789134 139.7380907222786 48.732 35.668669976568744 139.73809020374767 48.732</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4da1267-1da4-41f1-9652-3d4ed85d8dad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a4da1267-1da4-41f1-9652-3d4ed85d8dad_0">
											<gml:posList>35.668670184688196 139.73809121973466 48.732 35.668670184688196 139.73809121973466 49.517 35.66869393639729 139.73811467537516 49.517 35.66869393639729 139.73811467537516 48.732 35.668670184688196 139.73809121973466 48.732</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-096bf1fa-77c6-445b-b545-c23e60b5ae74">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-096bf1fa-77c6-445b-b545-c23e60b5ae74_0">
											<gml:posList>35.66869393639729 139.73811467537516 49.517 35.668670184688196 139.73809121973466 49.517 35.6686679855316 139.73809146535933 49.517 35.66869403731264 139.73811690655276 49.518 35.66869393639729 139.73811467537516 49.517</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3afb0edb-734d-4afa-a953-29942b1a3b78">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3afb0edb-734d-4afa-a953-29942b1a3b78_0">
											<gml:posList>35.66869403731264 139.73811690655276 48.732 35.66869403731264 139.73811690655276 49.518 35.6686679855316 139.73809146535933 49.517 35.6686679855316 139.73809146535933 48.732 35.66869403731264 139.73811690655276 48.732</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-6fa2a7eb-2296-4bd4-9383-799fc87e83cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6fa2a7eb-2296-4bd4-9383-799fc87e83cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6fa2a7eb-2296-4bd4-9383-799fc87e83cb">
											<gml:posList>35.668687230694935 139.73805834860588 21.23 35.668672166674455 139.738044338055 21.23 35.66879522844866 139.73784746182076 21.23 35.66887785571573 139.73792501716997 21.23 35.66872939956451 139.7381528525317 21.23 35.668665983908085 139.73809073869936 21.23 35.668687230694935 139.73805834860588 21.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-70310a95-074c-4bd3-8f2a-21451d0db707">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70310a95-074c-4bd3-8f2a-21451d0db707">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70310a95-074c-4bd3-8f2a-21451d0db707">
											<gml:posList>35.66879544631964 139.7378494056645 42.675 35.66879522844866 139.73784746182076 42.624 35.66877675570457 139.73787702092557 42.624 35.66877832391749 139.73787679813785 42.675 35.66879544631964 139.7378494056645 42.675</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-59d3d515-65e2-4d20-bc38-5363fa90f473">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-59d3d515-65e2-4d20-bc38-5363fa90f473">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-59d3d515-65e2-4d20-bc38-5363fa90f473">
											<gml:posList>35.66877832391749 139.73787679813785 42.675 35.66877675570457 139.73787702092557 42.624 35.66882762415547 139.73792750707025 42.624 35.66877832391749 139.73787679813785 42.675</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d4f48cd1-133a-4067-85e3-797505ad9476">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4f48cd1-133a-4067-85e3-797505ad9476">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4f48cd1-133a-4067-85e3-797505ad9476">
											<gml:posList>35.668669976568744 139.73809020374767 48.732 35.66869126836288 139.73805773627677 48.732 35.668687230694935 139.73805834860588 48.732 35.668665983908085 139.73809073869936 48.732 35.668669976568744 139.73809020374767 48.732</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-991e0363-9097-4e79-a27f-855e5910c283">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-991e0363-9097-4e79-a27f-855e5910c283">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-991e0363-9097-4e79-a27f-855e5910c283">
											<gml:posList>35.668676141211286 139.73804368161623 48.732 35.668672166674455 139.738044338055 48.732 35.668687230694935 139.73805834860588 48.732 35.66869126836288 139.73805773627677 48.732 35.668676141211286 139.73804368161623 48.732</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-48c919f3-ebb9-445e-b40a-1fffbf8db5f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-48c919f3-ebb9-445e-b40a-1fffbf8db5f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-48c919f3-ebb9-445e-b40a-1fffbf8db5f6">
											<gml:posList>35.668669976568744 139.73809020374767 48.732 35.668665983908085 139.73809073869936 48.732 35.668697727821474 139.7381218286985 48.732 35.66869730934709 139.7381169689434 48.732 35.668669976568744 139.73809020374767 48.732</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4ca4c95f-5bc8-4674-bd54-fe4afa0347b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ca4c95f-5bc8-4674-bd54-fe4afa0347b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ca4c95f-5bc8-4674-bd54-fe4afa0347b6">
											<gml:posList>35.66877721932732 139.7378819689988 48.732 35.66877675570457 139.73787702092557 48.732 35.668672166674455 139.738044338055 48.732 35.668676141211286 139.73804368161623 48.732 35.66877721932732 139.7378819689988 48.732</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f6ca353a-5d37-48ae-8b84-f557f7b26c8e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f6ca353a-5d37-48ae-8b84-f557f7b26c8e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f6ca353a-5d37-48ae-8b84-f557f7b26c8e">
											<gml:posList>35.66877721932732 139.7378819689988 48.158 35.668676141211286 139.73804368161623 48.158 35.66869126836288 139.73805773627677 48.158 35.668669976568744 139.73809020374767 48.158 35.66869730934709 139.7381169689434 48.158 35.668823613450705 139.73792801996052 48.158 35.66877721932732 139.7378819689988 48.158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0e338592-5121-411e-be22-258e889f9e5c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e338592-5121-411e-be22-258e889f9e5c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e338592-5121-411e-be22-258e889f9e5c">
											<gml:posList>35.66881625328945 139.73794452046133 48.732 35.66882762415547 139.73792750707025 48.732 35.668823613450705 139.73792801996052 48.732 35.66869730934709 139.7381169689434 48.732 35.668697727821474 139.7381218286985 48.732 35.66881625328945 139.73794452046133 48.732</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e29f4166-a552-4d3d-ba36-3ab673d7f418">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e29f4166-a552-4d3d-ba36-3ab673d7f418">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e29f4166-a552-4d3d-ba36-3ab673d7f418">
											<gml:posList>35.668697727821474 139.7381218286985 48.732 35.668835729424295 139.73796407088577 42.635 35.66881625328945 139.73794452046133 48.732 35.668697727821474 139.7381218286985 48.732</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d86bfe1d-3b8e-42c7-a0c6-8184ae8e17c3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d86bfe1d-3b8e-42c7-a0c6-8184ae8e17c3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d86bfe1d-3b8e-42c7-a0c6-8184ae8e17c3">
											<gml:posList>35.668697727821474 139.7381218286985 48.732 35.668845814790075 139.73797418811597 39.549 35.668835729424295 139.73796407088577 42.635 35.668697727821474 139.7381218286985 48.732</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cf3abede-6072-4bdc-a10e-619ab7801b71">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cf3abede-6072-4bdc-a10e-619ab7801b71">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cf3abede-6072-4bdc-a10e-619ab7801b71">
											<gml:posList>35.668697727821474 139.7381218286985 48.732 35.66872939956451 139.7381528525317 39.549 35.668845814790075 139.73797418811597 39.549 35.668697727821474 139.7381218286985 48.732</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e21bc631-69c5-4229-8f46-6270d5039da6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e21bc631-69c5-4229-8f46-6270d5039da6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e21bc631-69c5-4229-8f46-6270d5039da6">
											<gml:posList>35.668823613450705 139.73792801996052 48.732 35.66882762415547 139.73792750707025 48.732 35.66877675570457 139.73787702092557 48.732 35.66877721932732 139.7378819689988 48.732 35.668823613450705 139.73792801996052 48.732</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fa4b7f02-44ff-4be7-8916-aa258e7c8d27">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa4b7f02-44ff-4be7-8916-aa258e7c8d27">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa4b7f02-44ff-4be7-8916-aa258e7c8d27">
											<gml:posList>35.66882762415547 139.73792750707025 42.624 35.66882921041342 139.737927306354 42.621 35.66877832391749 139.73787679813785 42.675 35.66882762415547 139.73792750707025 42.624</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9b27aeb8-2bd5-4f1f-bc69-9bedce695110">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b27aeb8-2bd5-4f1f-bc69-9bedce695110">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b27aeb8-2bd5-4f1f-bc69-9bedce695110">
											<gml:posList>35.66881783955619 139.7379443307915 42.621 35.66882921041342 139.737927306354 42.621 35.66882762415547 139.73792750707025 42.624 35.66881625328945 139.73794452046133 42.624 35.66881783955619 139.7379443307915 42.621</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-250e07a6-32bf-4ea6-bf4c-c9db5483ce48">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-250e07a6-32bf-4ea6-bf4c-c9db5483ce48">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-250e07a6-32bf-4ea6-bf4c-c9db5483ce48">
											<gml:posList>35.66881783955619 139.7379443307915 42.621 35.66881625328945 139.73794452046133 42.624 35.668835729424295 139.73796407088577 42.635 35.66881783955619 139.7379443307915 42.621</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a8fb1943-1ae5-4f19-a7d6-2877aa35829f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a8fb1943-1ae5-4f19-a7d6-2877aa35829f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a8fb1943-1ae5-4f19-a7d6-2877aa35829f">
											<gml:posList>35.668835729424295 139.73796407088577 42.635 35.66883643163744 139.737962987538 42.601 35.66881783955619 139.7379443307915 42.621 35.668835729424295 139.73796407088577 42.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-148d750a-a2aa-45cf-b46b-ddcf1509a307">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-148d750a-a2aa-45cf-b46b-ddcf1509a307">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-148d750a-a2aa-45cf-b46b-ddcf1509a307">
											<gml:posList>35.66879541926095 139.7378493836046 42.171 35.668778296858804 139.73787677607797 42.17 35.66882919236847 139.73792728428342 42.116 35.66881782151124 139.73794430872087 42.116 35.66883640457877 139.7379629654781 42.097 35.66884560589983 139.7379722000758 42.087 35.66887622438917 139.73792521794002 42.087 35.66879541926095 139.7378493836046 42.171</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8b8669ea-6877-4ea0-a9be-1371c542012b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b8669ea-6877-4ea0-a9be-1371c542012b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b8669ea-6877-4ea0-a9be-1371c542012b">
											<gml:posList>35.66879522844866 139.73784746182076 42.624 35.66879544631964 139.7378494056645 42.675 35.66887625144784 139.73792523999995 42.592 35.66879522844866 139.73784746182076 42.624</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-755405e8-7254-4f43-be86-44203fd2c40f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-755405e8-7254-4f43-be86-44203fd2c40f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-755405e8-7254-4f43-be86-44203fd2c40f">
											<gml:posList>35.66887625144784 139.73792523999995 42.592 35.66887785571573 139.73792501716997 42.624 35.66879522844866 139.73784746182076 42.624 35.66887625144784 139.73792523999995 42.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f167a358-c4c5-43ea-88f1-83a537f14350">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f167a358-c4c5-43ea-88f1-83a537f14350">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f167a358-c4c5-43ea-88f1-83a537f14350">
											<gml:posList>35.6688456329585 139.7379722221357 42.592 35.66883643163744 139.737962987538 42.601 35.668835729424295 139.73796407088577 42.635 35.668845814790075 139.73797418811597 42.624 35.6688456329585 139.7379722221357 42.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-23cc6bef-4960-4136-930a-6b8ec4f3e44f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-23cc6bef-4960-4136-930a-6b8ec4f3e44f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-23cc6bef-4960-4136-930a-6b8ec4f3e44f">
											<gml:posList>35.6688456329585 139.7379722221357 42.592 35.668845814790075 139.73797418811597 42.624 35.66887785571573 139.73792501716997 42.624 35.66887625144784 139.73792523999995 42.592 35.6688456329585 139.7379722221357 42.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-23c246ca-54f7-438f-a864-b95531adc50c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-23c246ca-54f7-438f-a864-b95531adc50c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-23c246ca-54f7-438f-a864-b95531adc50c">
											<gml:posList>35.66882919236847 139.73792728428342 42.116 35.66882921041342 139.737927306354 42.621 35.66881783955619 139.7379443307915 42.621 35.66881782151124 139.73794430872087 42.116 35.66882919236847 139.73792728428342 42.116</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c26e29ad-bd91-476b-92e0-d2e287ecafda">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c26e29ad-bd91-476b-92e0-d2e287ecafda">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c26e29ad-bd91-476b-92e0-d2e287ecafda">
											<gml:posList>35.66879541926095 139.7378493836046 42.171 35.66879544631964 139.7378494056645 42.675 35.66877832391749 139.73787679813785 42.675 35.668778296858804 139.73787677607797 42.17 35.66879541926095 139.7378493836046 42.171</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-15971189-b2e6-4d98-b1cc-8c61693b8a70">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15971189-b2e6-4d98-b1cc-8c61693b8a70">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15971189-b2e6-4d98-b1cc-8c61693b8a70">
											<gml:posList>35.66879522844866 139.73784746182076 42.624 35.66887785571573 139.73792501716997 42.624 35.66887785571573 139.73792501716997 21.23 35.66879522844866 139.73784746182076 21.23 35.66879522844866 139.73784746182076 42.624</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-96d59ce2-e65b-4094-8db0-f2418f581728">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96d59ce2-e65b-4094-8db0-f2418f581728">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96d59ce2-e65b-4094-8db0-f2418f581728">
											<gml:posList>35.66887622438917 139.73792521794002 42.087 35.66887625144784 139.73792523999995 42.592 35.66879544631964 139.7378494056645 42.675 35.66879541926095 139.7378493836046 42.171 35.66887622438917 139.73792521794002 42.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-479f090d-d921-4404-af52-4253db5db8d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-479f090d-d921-4404-af52-4253db5db8d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-479f090d-d921-4404-af52-4253db5db8d8">
											<gml:posList>35.668778296858804 139.73787677607797 42.17 35.66877832391749 139.73787679813785 42.675 35.66882921041342 139.737927306354 42.621 35.66882919236847 139.73792728428342 42.116 35.668778296858804 139.73787677607797 42.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0e1876b0-6222-40d1-b3e0-b59ae408d351">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e1876b0-6222-40d1-b3e0-b59ae408d351">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e1876b0-6222-40d1-b3e0-b59ae408d351">
											<gml:posList>35.66882762415547 139.73792750707025 42.624 35.66877675570457 139.73787702092557 42.624 35.66877675570457 139.73787702092557 48.732 35.66882762415547 139.73792750707025 48.732 35.66882762415547 139.73792750707025 42.624</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f2d26769-ebd1-4ee6-b550-85614170a6df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f2d26769-ebd1-4ee6-b550-85614170a6df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f2d26769-ebd1-4ee6-b550-85614170a6df">
											<gml:posList>35.668823613450705 139.73792801996052 48.158 35.668823613450705 139.73792801996052 48.732 35.66877721932732 139.7378819689988 48.732 35.66877721932732 139.7378819689988 48.158 35.668823613450705 139.73792801996052 48.158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-10d440a9-4472-451b-936a-b70260a9f087">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-10d440a9-4472-451b-936a-b70260a9f087">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-10d440a9-4472-451b-936a-b70260a9f087">
											<gml:posList>35.66881625328945 139.73794452046133 48.732 35.66881625328945 139.73794452046133 42.624 35.66882762415547 139.73792750707025 42.624 35.66882762415547 139.73792750707025 48.732 35.66881625328945 139.73794452046133 48.732</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d4719e0e-a442-4534-9da1-7f192ec5d9dc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4719e0e-a442-4534-9da1-7f192ec5d9dc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4719e0e-a442-4534-9da1-7f192ec5d9dc">
											<gml:posList>35.668672166674455 139.738044338055 21.23 35.668672166674455 139.738044338055 48.732 35.66877675570457 139.73787702092557 48.732 35.66877675570457 139.73787702092557 42.624 35.66879522844866 139.73784746182076 42.624 35.66879522844866 139.73784746182076 21.23 35.668672166674455 139.738044338055 21.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5cabedbc-a06f-4e05-bd04-4a3a40c8edbc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5cabedbc-a06f-4e05-bd04-4a3a40c8edbc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5cabedbc-a06f-4e05-bd04-4a3a40c8edbc">
											<gml:posList>35.66884560589983 139.7379722000758 42.087 35.6688456329585 139.7379722221357 42.592 35.66887625144784 139.73792523999995 42.592 35.66887622438917 139.73792521794002 42.087 35.66884560589983 139.7379722000758 42.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b764807b-6ef5-42a3-879a-0015908060e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b764807b-6ef5-42a3-879a-0015908060e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b764807b-6ef5-42a3-879a-0015908060e8">
											<gml:posList>35.66881782151124 139.73794430872087 42.116 35.66881783955619 139.7379443307915 42.621 35.66883643163744 139.737962987538 42.601 35.66883640457877 139.7379629654781 42.097 35.66881782151124 139.73794430872087 42.116</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7be6843c-3271-4198-9e20-2b0ce5fff5cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7be6843c-3271-4198-9e20-2b0ce5fff5cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7be6843c-3271-4198-9e20-2b0ce5fff5cd">
											<gml:posList>35.66881625328945 139.73794452046133 42.624 35.66881625328945 139.73794452046133 48.732 35.668835729424295 139.73796407088577 42.635 35.66881625328945 139.73794452046133 42.624</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5e4d8a6b-e9bc-435a-bc3b-7477c408a062">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e4d8a6b-e9bc-435a-bc3b-7477c408a062">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e4d8a6b-e9bc-435a-bc3b-7477c408a062">
											<gml:posList>35.66877721932732 139.7378819689988 48.158 35.66877721932732 139.7378819689988 48.732 35.668676141211286 139.73804368161623 48.732 35.668676141211286 139.73804368161623 48.158 35.66877721932732 139.7378819689988 48.158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2b5c12f2-0538-4602-87f7-6cde80d088f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b5c12f2-0538-4602-87f7-6cde80d088f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b5c12f2-0538-4602-87f7-6cde80d088f7">
											<gml:posList>35.66883640457877 139.7379629654781 42.097 35.66883643163744 139.737962987538 42.601 35.6688456329585 139.7379722221357 42.592 35.66884560589983 139.7379722000758 42.087 35.66883640457877 139.7379629654781 42.097</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6196e13a-6ea4-4a24-8ea9-e534bdbe00da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6196e13a-6ea4-4a24-8ea9-e534bdbe00da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6196e13a-6ea4-4a24-8ea9-e534bdbe00da">
											<gml:posList>35.668845814790075 139.73797418811597 42.624 35.668835729424295 139.73796407088577 42.635 35.668845814790075 139.73797418811597 39.549 35.668845814790075 139.73797418811597 42.624</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-03d43e75-6afc-4226-9f63-7f74cb3fb636">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03d43e75-6afc-4226-9f63-7f74cb3fb636">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03d43e75-6afc-4226-9f63-7f74cb3fb636">
											<gml:posList>35.66869730934709 139.7381169689434 48.158 35.66869730934709 139.7381169689434 48.732 35.668823613450705 139.73792801996052 48.732 35.668823613450705 139.73792801996052 48.158 35.66869730934709 139.7381169689434 48.158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9e071dc9-0f19-4f41-b24b-ce9e7ce39b49">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e071dc9-0f19-4f41-b24b-ce9e7ce39b49">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e071dc9-0f19-4f41-b24b-ce9e7ce39b49">
											<gml:posList>35.66887785571573 139.73792501716997 21.23 35.66887785571573 139.73792501716997 42.624 35.668845814790075 139.73797418811597 42.624 35.668845814790075 139.73797418811597 39.549 35.66872939956451 139.7381528525317 39.549 35.66872939956451 139.7381528525317 21.23 35.66887785571573 139.73792501716997 21.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-52657872-fb3a-46c5-b875-10bf67773c7e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-52657872-fb3a-46c5-b875-10bf67773c7e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-52657872-fb3a-46c5-b875-10bf67773c7e">
											<gml:posList>35.668676141211286 139.73804368161623 48.158 35.668676141211286 139.73804368161623 48.732 35.66869126836288 139.73805773627677 48.732 35.66869126836288 139.73805773627677 48.158 35.668676141211286 139.73804368161623 48.158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-674326de-fe7c-41ab-9266-0c45d8c5f245">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-674326de-fe7c-41ab-9266-0c45d8c5f245">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-674326de-fe7c-41ab-9266-0c45d8c5f245">
											<gml:posList>35.668687230694935 139.73805834860588 48.732 35.668672166674455 139.738044338055 48.732 35.668672166674455 139.738044338055 21.23 35.668687230694935 139.73805834860588 21.23 35.668687230694935 139.73805834860588 48.732</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dadd39c8-c3a9-47c7-a828-4d581fdf6d97">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dadd39c8-c3a9-47c7-a828-4d581fdf6d97">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dadd39c8-c3a9-47c7-a828-4d581fdf6d97">
											<gml:posList>35.66869126836288 139.73805773627677 48.158 35.66869126836288 139.73805773627677 48.732 35.668669976568744 139.73809020374767 48.732 35.668669976568744 139.73809020374767 48.158 35.66869126836288 139.73805773627677 48.158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b42050e4-fa1e-4fae-b9e9-919f701fb6f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b42050e4-fa1e-4fae-b9e9-919f701fb6f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b42050e4-fa1e-4fae-b9e9-919f701fb6f0">
											<gml:posList>35.668665983908085 139.73809073869936 48.732 35.668687230694935 139.73805834860588 48.732 35.668687230694935 139.73805834860588 21.23 35.668665983908085 139.73809073869936 21.23 35.668665983908085 139.73809073869936 48.732</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-67a5fcb1-e0fc-41e5-ad8e-49ca1faf1307">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67a5fcb1-e0fc-41e5-ad8e-49ca1faf1307">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67a5fcb1-e0fc-41e5-ad8e-49ca1faf1307">
											<gml:posList>35.668669976568744 139.73809020374767 48.158 35.668669976568744 139.73809020374767 48.732 35.66869730934709 139.7381169689434 48.732 35.66869730934709 139.7381169689434 48.158 35.668669976568744 139.73809020374767 48.158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d9096314-a22b-48e7-8a86-379655284c93">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d9096314-a22b-48e7-8a86-379655284c93">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d9096314-a22b-48e7-8a86-379655284c93">
											<gml:posList>35.66872939956451 139.7381528525317 39.549 35.668697727821474 139.7381218286985 48.732 35.668665983908085 139.73809073869936 48.732 35.668665983908085 139.73809073869936 21.23 35.66872939956451 139.7381528525317 21.23 35.66872939956451 139.7381528525317 39.549</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5919</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">288.7621</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>