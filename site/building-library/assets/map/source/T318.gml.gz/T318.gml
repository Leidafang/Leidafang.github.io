<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_5b0b61f1-0ddc-4f5f-812f-659852086fb1">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:measuredHeight uom="m">15</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66731542329652 139.74055408440555 0 35.667325316062524 139.74053678622178 0 35.667088313899754 139.7403329560905 0 35.66706735830125 139.7403697076897 0 35.66712706893903 139.74042115612906 0 35.66710406986405 139.7404613674278 0 35.667256953986744 139.74059281245903 0 35.667268782109716 139.74060724672586 0 35.667289744172706 139.7406373223827 0 35.66732565827184 139.7406182930692 0 35.66746351518274 139.740736534221 0 35.667484758982575 139.74069932932252 0 35.66731542329652 139.74055408440555 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66731542329652 139.74055408440555 11.3 35.667484758982575 139.74069932932252 11.3 35.66746351518274 139.740736534221 11.3 35.66732565827184 139.7406182930692 11.3 35.667289744172706 139.7406373223827 11.3 35.667268782109716 139.74060724672586 11.3 35.667256953986744 139.74059281245903 11.3 35.66710406986405 139.7404613674278 11.3 35.66712706893903 139.74042115612906 11.3 35.66706735830125 139.7403697076897 11.3 35.667088313899754 139.7403329560905 11.3 35.667325316062524 139.74053678622178 11.3 35.66731542329652 139.74055408440555 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66731542329652 139.74055408440555 11.3 35.667325316062524 139.74053678622178 11.3 35.667325316062524 139.74053678622178 26.3 35.66731542329652 139.74055408440555 26.3 35.66731542329652 139.74055408440555 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667325316062524 139.74053678622178 11.3 35.667088313899754 139.7403329560905 11.3 35.667088313899754 139.7403329560905 26.3 35.667325316062524 139.74053678622178 26.3 35.667325316062524 139.74053678622178 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667088313899754 139.7403329560905 11.3 35.66706735830125 139.7403697076897 11.3 35.66706735830125 139.7403697076897 26.3 35.667088313899754 139.7403329560905 26.3 35.667088313899754 139.7403329560905 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66706735830125 139.7403697076897 11.3 35.66712706893903 139.74042115612906 11.3 35.66712706893903 139.74042115612906 26.3 35.66706735830125 139.7403697076897 26.3 35.66706735830125 139.7403697076897 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66712706893903 139.74042115612906 11.3 35.66710406986405 139.7404613674278 11.3 35.66710406986405 139.7404613674278 26.3 35.66712706893903 139.74042115612906 26.3 35.66712706893903 139.74042115612906 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66710406986405 139.7404613674278 11.3 35.667256953986744 139.74059281245903 11.3 35.667256953986744 139.74059281245903 26.3 35.66710406986405 139.7404613674278 26.3 35.66710406986405 139.7404613674278 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667256953986744 139.74059281245903 11.3 35.667268782109716 139.74060724672586 11.3 35.667268782109716 139.74060724672586 26.3 35.667256953986744 139.74059281245903 26.3 35.667256953986744 139.74059281245903 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667268782109716 139.74060724672586 11.3 35.667289744172706 139.7406373223827 11.3 35.667289744172706 139.7406373223827 26.3 35.667268782109716 139.74060724672586 26.3 35.667268782109716 139.74060724672586 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667289744172706 139.7406373223827 11.3 35.66732565827184 139.7406182930692 11.3 35.66732565827184 139.7406182930692 26.3 35.667289744172706 139.7406373223827 26.3 35.667289744172706 139.7406373223827 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66732565827184 139.7406182930692 11.3 35.66746351518274 139.740736534221 11.3 35.66746351518274 139.740736534221 26.3 35.66732565827184 139.7406182930692 26.3 35.66732565827184 139.7406182930692 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66746351518274 139.740736534221 11.3 35.667484758982575 139.74069932932252 11.3 35.667484758982575 139.74069932932252 26.3 35.66746351518274 139.740736534221 26.3 35.66746351518274 139.740736534221 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667484758982575 139.74069932932252 11.3 35.66731542329652 139.74055408440555 11.3 35.66731542329652 139.74055408440555 26.3 35.667484758982575 139.74069932932252 26.3 35.667484758982575 139.74069932932252 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66731542329652 139.74055408440555 26.3 35.667325316062524 139.74053678622178 26.3 35.667088313899754 139.7403329560905 26.3 35.66706735830125 139.7403697076897 26.3 35.66712706893903 139.74042115612906 26.3 35.66710406986405 139.7404613674278 26.3 35.667256953986744 139.74059281245903 26.3 35.667268782109716 139.74060724672586 26.3 35.667289744172706 139.7406373223827 26.3 35.66732565827184 139.7406182930692 26.3 35.66746351518274 139.740736534221 26.3 35.667484758982575 139.74069932932252 26.3 35.66731542329652 139.74055408440555 26.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-bb51cc11-caf2-4c93-bceb-0aa9ab521c58"/>
							<gml:surfaceMember xlink:href="#poly-a906c172-b94a-42e3-ac3f-343d2a98237b"/>
							<gml:surfaceMember xlink:href="#poly-edc773b5-659e-4a25-a1b7-7a0af2369d3a"/>
							<gml:surfaceMember xlink:href="#poly-023edb8b-8f44-4589-ab25-6e8a3bce5299"/>
							<gml:surfaceMember xlink:href="#poly-f9ce5163-d7d4-44f4-b9a0-b1f29fed4208"/>
							<gml:surfaceMember xlink:href="#poly-ff09343d-1b17-4c3e-996a-7ece7c5607e7"/>
							<gml:surfaceMember xlink:href="#poly-a1cba5e1-d78e-48c4-a636-fa686dfa7657"/>
							<gml:surfaceMember xlink:href="#poly-7c1f6081-3d2f-45a5-b6ef-6092fce4f24b"/>
							<gml:surfaceMember xlink:href="#poly-5ac07b16-5bc7-46c5-b6b8-1873e7e5f412"/>
							<gml:surfaceMember xlink:href="#poly-f49b7725-a49f-4892-9c27-123677baf20b"/>
							<gml:surfaceMember xlink:href="#poly-99a47d96-d8c5-4064-be4f-42cbec6f4ea3"/>
							<gml:surfaceMember xlink:href="#poly-9478fc2b-727b-474e-b9f4-f26667897a8a"/>
							<gml:surfaceMember xlink:href="#poly-646d5005-292f-4d6c-8a2c-ee86344ffbe7"/>
							<gml:surfaceMember xlink:href="#poly-ccd0bc8b-9cbd-4fe7-8e02-66221de85cc2"/>
							<gml:surfaceMember xlink:href="#poly-0ab0a832-b737-4e9a-befa-4ad94b83e508"/>
							<gml:surfaceMember xlink:href="#poly-e760df0f-42f6-455f-bdda-caad17ce140a"/>
							<gml:surfaceMember xlink:href="#poly-b9e136c7-8e92-441f-ba39-c7cf2d18bae1"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-bb51cc11-caf2-4c93-bceb-0aa9ab521c58">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb51cc11-caf2-4c93-bceb-0aa9ab521c58">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb51cc11-caf2-4c93-bceb-0aa9ab521c58">
											<gml:posList>35.667315423296515 139.74055408440552 11.3 35.66748475898257 139.7406993293225 11.3 35.667463515182725 139.74073653422099 11.3 35.66732565827183 139.7406182930692 11.3 35.66728974417269 139.74063732238267 11.3 35.66726878210969 139.74060724672586 11.3 35.66725695398672 139.74059281245903 11.3 35.667104069864045 139.7404613674278 11.3 35.66712706893901 139.74042115612906 11.3 35.667067358301225 139.7403697076897 11.3 35.66708831389975 139.74033295609047 11.3 35.66732531606252 139.74053678622175 11.3 35.667315423296515 139.74055408440552 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a906c172-b94a-42e3-ac3f-343d2a98237b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a906c172-b94a-42e3-ac3f-343d2a98237b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a906c172-b94a-42e3-ac3f-343d2a98237b">
											<gml:posList>35.66732565827183 139.7406182930692 22.3 35.667116888107856 139.74043891854197 22.3 35.667104069864045 139.7404613674278 22.3 35.66725695398672 139.74059281245903 22.3 35.66726878210969 139.74060724672586 22.3 35.66728974417269 139.74063732238267 22.3 35.66732565827183 139.7406182930692 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-edc773b5-659e-4a25-a1b7-7a0af2369d3a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-edc773b5-659e-4a25-a1b7-7a0af2369d3a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-edc773b5-659e-4a25-a1b7-7a0af2369d3a">
											<gml:posList>35.66708831389975 139.74033295609047 26.4 35.667067358301225 139.7403697076897 26.4 35.66712706893901 139.74042115612906 26.4 35.667116888107856 139.74043891854197 26.4 35.667463515182725 139.74073653422099 26.4 35.66748475898257 139.7406993293225 26.4 35.667315423296515 139.74055408440552 26.4 35.66732531606252 139.74053678622175 26.4 35.66708831389975 139.74033295609047 26.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-023edb8b-8f44-4589-ab25-6e8a3bce5299">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-023edb8b-8f44-4589-ab25-6e8a3bce5299">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-023edb8b-8f44-4589-ab25-6e8a3bce5299">
											<gml:posList>35.667067358301225 139.7403697076897 26.4 35.66708831389975 139.74033295609047 26.4 35.66708831389975 139.74033295609047 11.3 35.667067358301225 139.7403697076897 11.3 35.667067358301225 139.7403697076897 26.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f9ce5163-d7d4-44f4-b9a0-b1f29fed4208">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9ce5163-d7d4-44f4-b9a0-b1f29fed4208">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9ce5163-d7d4-44f4-b9a0-b1f29fed4208">
											<gml:posList>35.66712706893901 139.74042115612906 26.4 35.667067358301225 139.7403697076897 26.4 35.667067358301225 139.7403697076897 11.3 35.66712706893901 139.74042115612906 11.3 35.66712706893901 139.74042115612906 26.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ff09343d-1b17-4c3e-996a-7ece7c5607e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff09343d-1b17-4c3e-996a-7ece7c5607e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff09343d-1b17-4c3e-996a-7ece7c5607e7">
											<gml:posList>35.667104069864045 139.7404613674278 11.3 35.667104069864045 139.7404613674278 22.3 35.667116888107856 139.74043891854197 22.3 35.667116888107856 139.74043891854197 26.4 35.66712706893901 139.74042115612906 26.4 35.66712706893901 139.74042115612906 11.3 35.667104069864045 139.7404613674278 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a1cba5e1-d78e-48c4-a636-fa686dfa7657">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a1cba5e1-d78e-48c4-a636-fa686dfa7657">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a1cba5e1-d78e-48c4-a636-fa686dfa7657">
											<gml:posList>35.66725695398672 139.74059281245903 22.3 35.667104069864045 139.7404613674278 22.3 35.667104069864045 139.7404613674278 11.3 35.66725695398672 139.74059281245903 11.3 35.66725695398672 139.74059281245903 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7c1f6081-3d2f-45a5-b6ef-6092fce4f24b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c1f6081-3d2f-45a5-b6ef-6092fce4f24b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c1f6081-3d2f-45a5-b6ef-6092fce4f24b">
											<gml:posList>35.66732531606252 139.74053678622175 11.3 35.66708831389975 139.74033295609047 26.4 35.66732531606252 139.74053678622175 26.4 35.66732531606252 139.74053678622175 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5ac07b16-5bc7-46c5-b6b8-1873e7e5f412">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5ac07b16-5bc7-46c5-b6b8-1873e7e5f412">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5ac07b16-5bc7-46c5-b6b8-1873e7e5f412">
											<gml:posList>35.66732531606252 139.74053678622175 11.3 35.66708831389975 139.74033295609047 11.3 35.66708831389975 139.74033295609047 26.4 35.66732531606252 139.74053678622175 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f49b7725-a49f-4892-9c27-123677baf20b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f49b7725-a49f-4892-9c27-123677baf20b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f49b7725-a49f-4892-9c27-123677baf20b">
											<gml:posList>35.66726878210969 139.74060724672586 22.3 35.66725695398672 139.74059281245903 22.3 35.66725695398672 139.74059281245903 11.3 35.66726878210969 139.74060724672586 11.3 35.66726878210969 139.74060724672586 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-99a47d96-d8c5-4064-be4f-42cbec6f4ea3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-99a47d96-d8c5-4064-be4f-42cbec6f4ea3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-99a47d96-d8c5-4064-be4f-42cbec6f4ea3">
											<gml:posList>35.66728974417269 139.74063732238267 22.3 35.66726878210969 139.74060724672586 22.3 35.66726878210969 139.74060724672586 11.3 35.66728974417269 139.74063732238267 11.3 35.66728974417269 139.74063732238267 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9478fc2b-727b-474e-b9f4-f26667897a8a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9478fc2b-727b-474e-b9f4-f26667897a8a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9478fc2b-727b-474e-b9f4-f26667897a8a">
											<gml:posList>35.66732565827183 139.7406182930692 22.3 35.66732565827183 139.7406182930692 11.3 35.667463515182725 139.74073653422099 11.3 35.667463515182725 139.74073653422099 26.4 35.667116888107856 139.74043891854197 26.4 35.667116888107856 139.74043891854197 22.3 35.66732565827183 139.7406182930692 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-646d5005-292f-4d6c-8a2c-ee86344ffbe7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-646d5005-292f-4d6c-8a2c-ee86344ffbe7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-646d5005-292f-4d6c-8a2c-ee86344ffbe7">
											<gml:posList>35.66732565827183 139.7406182930692 22.3 35.66728974417269 139.74063732238267 22.3 35.66728974417269 139.74063732238267 11.3 35.66732565827183 139.7406182930692 11.3 35.66732565827183 139.7406182930692 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ccd0bc8b-9cbd-4fe7-8e02-66221de85cc2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ccd0bc8b-9cbd-4fe7-8e02-66221de85cc2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ccd0bc8b-9cbd-4fe7-8e02-66221de85cc2">
											<gml:posList>35.66732531606252 139.74053678622175 26.4 35.667315423296515 139.74055408440552 26.4 35.667315423296515 139.74055408440552 11.3 35.66732531606252 139.74053678622175 11.3 35.66732531606252 139.74053678622175 26.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0ab0a832-b737-4e9a-befa-4ad94b83e508">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ab0a832-b737-4e9a-befa-4ad94b83e508">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ab0a832-b737-4e9a-befa-4ad94b83e508">
											<gml:posList>35.667315423296515 139.74055408440552 26.4 35.66748475898257 139.7406993293225 26.4 35.66748475898257 139.7406993293225 11.3 35.667315423296515 139.74055408440552 26.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e760df0f-42f6-455f-bdda-caad17ce140a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e760df0f-42f6-455f-bdda-caad17ce140a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e760df0f-42f6-455f-bdda-caad17ce140a">
											<gml:posList>35.667315423296515 139.74055408440552 26.4 35.66748475898257 139.7406993293225 11.3 35.667315423296515 139.74055408440552 11.3 35.667315423296515 139.74055408440552 26.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b9e136c7-8e92-441f-ba39-c7cf2d18bae1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b9e136c7-8e92-441f-ba39-c7cf2d18bae1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b9e136c7-8e92-441f-ba39-c7cf2d18bae1">
											<gml:posList>35.66748475898257 139.7406993293225 26.4 35.667463515182725 139.74073653422099 26.4 35.667463515182725 139.74073653422099 11.3 35.66748475898257 139.7406993293225 11.3 35.66748475898257 139.7406993293225 26.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-3993</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">2</uro:rank>
					<uro:depth uom="m">1.12</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>