<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_5b678071-33ce-4ffd-9f38-58463cd3e25b">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>46</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13101046002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">44.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67218607536967 139.74219599071398 0 35.67211960415148 139.7420836129138 0 35.67201057427517 139.74217905712044 0 35.67192828330689 139.74230398687337 0 35.671970466287924 139.7423738742351 0 35.67194770415131 139.74239446859733 0 35.67197809147322 139.74244492758854 0 35.67199295398099 139.7424314892641 0 35.6719972679432 139.74243864249345 0 35.67209491001709 139.74235027029076 0 35.67206686924651 139.74230380742765 0 35.67218607536967 139.74219599071398 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67218607536967 139.74219599071398 7.3 35.67206686924651 139.74230380742765 7.3 35.67209491001709 139.74235027029076 7.3 35.6719972679432 139.74243864249345 7.3 35.67199295398099 139.7424314892641 7.3 35.67197809147322 139.74244492758854 7.3 35.67194770415131 139.74239446859733 7.3 35.671970466287924 139.7423738742351 7.3 35.67192828330689 139.74230398687337 7.3 35.67201057427517 139.74217905712044 7.3 35.67211960415148 139.7420836129138 7.3 35.67218607536967 139.74219599071398 7.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67218607536967 139.74219599071398 7.3 35.67211960415148 139.7420836129138 7.3 35.67211960415148 139.7420836129138 49.19 35.67218607536967 139.74219599071398 49.19 35.67218607536967 139.74219599071398 7.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67211960415148 139.7420836129138 7.3 35.67201057427517 139.74217905712044 7.3 35.67201057427517 139.74217905712044 49.19 35.67211960415148 139.7420836129138 49.19 35.67211960415148 139.7420836129138 7.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67201057427517 139.74217905712044 7.3 35.67192828330689 139.74230398687337 7.3 35.67192828330689 139.74230398687337 49.19 35.67201057427517 139.74217905712044 49.19 35.67201057427517 139.74217905712044 7.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67192828330689 139.74230398687337 7.3 35.671970466287924 139.7423738742351 7.3 35.671970466287924 139.7423738742351 49.19 35.67192828330689 139.74230398687337 49.19 35.67192828330689 139.74230398687337 7.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671970466287924 139.7423738742351 7.3 35.67194770415131 139.74239446859733 7.3 35.67194770415131 139.74239446859733 49.19 35.671970466287924 139.7423738742351 49.19 35.671970466287924 139.7423738742351 7.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67194770415131 139.74239446859733 7.3 35.67197809147322 139.74244492758854 7.3 35.67197809147322 139.74244492758854 49.19 35.67194770415131 139.74239446859733 49.19 35.67194770415131 139.74239446859733 7.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67197809147322 139.74244492758854 7.3 35.67199295398099 139.7424314892641 7.3 35.67199295398099 139.7424314892641 49.19 35.67197809147322 139.74244492758854 49.19 35.67197809147322 139.74244492758854 7.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67199295398099 139.7424314892641 7.3 35.6719972679432 139.74243864249345 7.3 35.6719972679432 139.74243864249345 49.19 35.67199295398099 139.7424314892641 49.19 35.67199295398099 139.7424314892641 7.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6719972679432 139.74243864249345 7.3 35.67209491001709 139.74235027029076 7.3 35.67209491001709 139.74235027029076 49.19 35.6719972679432 139.74243864249345 49.19 35.6719972679432 139.74243864249345 7.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67209491001709 139.74235027029076 7.3 35.67206686924651 139.74230380742765 7.3 35.67206686924651 139.74230380742765 49.19 35.67209491001709 139.74235027029076 49.19 35.67209491001709 139.74235027029076 7.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67206686924651 139.74230380742765 7.3 35.67218607536967 139.74219599071398 7.3 35.67218607536967 139.74219599071398 49.19 35.67206686924651 139.74230380742765 49.19 35.67206686924651 139.74230380742765 7.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67218607536967 139.74219599071398 49.19 35.67211960415148 139.7420836129138 49.19 35.67201057427517 139.74217905712044 49.19 35.67192828330689 139.74230398687337 49.19 35.671970466287924 139.7423738742351 49.19 35.67194770415131 139.74239446859733 49.19 35.67197809147322 139.74244492758854 49.19 35.67199295398099 139.7424314892641 49.19 35.6719972679432 139.74243864249345 49.19 35.67209491001709 139.74235027029076 49.19 35.67206686924651 139.74230380742765 49.19 35.67218607536967 139.74219599071398 49.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-54311b0f-d0e6-461e-bddb-c3d3231f3d07"/>
							<gml:surfaceMember xlink:href="#poly-e398f9f6-9e9c-4314-8674-6741f3e92c88"/>
							<gml:surfaceMember xlink:href="#poly-bccec0ba-5798-4570-8f67-4ae23bc0fe12"/>
							<gml:surfaceMember xlink:href="#poly-181af634-6f6a-4ab9-a12d-63d7556c77f0"/>
							<gml:surfaceMember xlink:href="#poly-afd8d60c-0c96-4b29-bbf9-4c8cc474f555"/>
							<gml:surfaceMember xlink:href="#poly-9902b266-8476-4c34-b223-defa2fbf3c6b"/>
							<gml:surfaceMember xlink:href="#poly-e58ca11f-61ff-4e01-ac09-dd33c72acad2"/>
							<gml:surfaceMember xlink:href="#poly-72e53ea1-8ddd-4ee1-ad16-66322d8570ec"/>
							<gml:surfaceMember xlink:href="#poly-f2acf778-e22f-4378-8382-3e4598e8321b"/>
							<gml:surfaceMember xlink:href="#poly-fa96f186-7160-480e-8149-42ebe24e330e"/>
							<gml:surfaceMember xlink:href="#poly-d9202a59-02e9-4cc8-affe-739b35b1962c"/>
							<gml:surfaceMember xlink:href="#poly-c3e15cc7-9e3b-4835-9235-02dd2102c550"/>
							<gml:surfaceMember xlink:href="#poly-0feca356-aae6-497f-a1fa-976c123a3c49"/>
							<gml:surfaceMember xlink:href="#poly-6a44c21f-b8f6-4667-8271-6ab4883efd01"/>
							<gml:surfaceMember xlink:href="#poly-68a80556-3b98-4530-b5fb-561efa45b2d6"/>
							<gml:surfaceMember xlink:href="#poly-36ed4b98-79cf-4ded-9ee9-b645b5964d68"/>
							<gml:surfaceMember xlink:href="#poly-0ad9b2a0-6f53-4e91-8791-d480990f39df"/>
							<gml:surfaceMember xlink:href="#poly-c28f3d79-3019-431b-b9a3-aed50edcb818"/>
							<gml:surfaceMember xlink:href="#poly-1e05aa56-34dc-44d9-8cb3-a35c3557a1e0"/>
							<gml:surfaceMember xlink:href="#poly-539dfdba-592d-4e22-9936-4ff7108336f6"/>
							<gml:surfaceMember xlink:href="#poly-86902419-70cb-4b8b-b80e-f887584cd399"/>
							<gml:surfaceMember xlink:href="#poly-0faf64d4-c81b-4b82-810c-664fe4badd99"/>
							<gml:surfaceMember xlink:href="#poly-f9c56f48-c5c5-4d2f-ac45-92a863e37784"/>
							<gml:surfaceMember xlink:href="#poly-93453ab3-fa5a-4198-9eeb-1c85ec544640"/>
							<gml:surfaceMember xlink:href="#poly-e7685c75-52a4-4987-abc3-b80f808b048c"/>
							<gml:surfaceMember xlink:href="#poly-6d0cf163-8414-409c-90de-7967aef75c01"/>
							<gml:surfaceMember xlink:href="#poly-6d902bdf-00b8-41f9-8499-16f9772db55e"/>
							<gml:surfaceMember xlink:href="#poly-756cc9d1-3d38-40bc-b45f-2885dec10572"/>
							<gml:surfaceMember xlink:href="#poly-4412e65d-e7fd-4c09-ac9a-111bf0d7b905"/>
							<gml:surfaceMember xlink:href="#poly-4cf7c291-7549-4795-b228-70679e901697"/>
							<gml:surfaceMember xlink:href="#poly-27f834a2-e5f7-4ba9-992b-9edebec26221"/>
							<gml:surfaceMember xlink:href="#poly-78a0e6f1-2cb2-484d-9934-716840ec80bd"/>
							<gml:surfaceMember xlink:href="#poly-4a3bbc17-b401-4464-a4ff-933ba6f1e104"/>
							<gml:surfaceMember xlink:href="#poly-e10994d2-897d-49ca-ba50-7f60c634dd11"/>
							<gml:surfaceMember xlink:href="#poly-a74c7351-e79e-4cec-8fd3-3446a8851851"/>
							<gml:surfaceMember xlink:href="#poly-62eac342-b917-4367-b4f2-bdd84b88bdd6"/>
							<gml:surfaceMember xlink:href="#poly-45e82517-5f96-4701-9b7b-cbc54a8b79e6"/>
							<gml:surfaceMember xlink:href="#poly-8a85ebc5-3362-4252-bd14-2e9c8fb81792"/>
							<gml:surfaceMember xlink:href="#poly-2da3f40e-b7c0-4ba1-890c-2ed1955d6a9d"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-54311b0f-d0e6-461e-bddb-c3d3231f3d07">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-54311b0f-d0e6-461e-bddb-c3d3231f3d07">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-54311b0f-d0e6-461e-bddb-c3d3231f3d07">
											<gml:posList>35.671978091473214 139.74244492758854 7.3 35.671947704142944 139.7423944575508 7.3 35.6719704662879 139.7423738742351 7.3 35.67192828330689 139.74230398687337 7.3 35.67201056526142 139.7421790571307 7.3 35.67211960415149 139.7420836129138 7.3 35.672186066355955 139.7421959907242 7.3 35.67206686924651 139.74230380742765 7.3 35.67209491001706 139.74235027029076 7.3 35.671997258929466 139.74243864250369 7.3 35.671992953981 139.7424314892641 7.3 35.671978091473214 139.74244492758854 7.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e398f9f6-9e9c-4314-8674-6741f3e92c88">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e398f9f6-9e9c-4314-8674-6741f3e92c88">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e398f9f6-9e9c-4314-8674-6741f3e92c88">
											<gml:posList>35.67211960415149 139.7420836129138 48.9 35.67201056526142 139.7421790571307 48.9 35.67206481627477 139.74222323664796 48.9 35.672142077966384 139.7421584273883 48.9 35.67211960415149 139.7420836129138 48.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bccec0ba-5798-4570-8f67-4ae23bc0fe12">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bccec0ba-5798-4570-8f67-4ae23bc0fe12">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bccec0ba-5798-4570-8f67-4ae23bc0fe12">
											<gml:posList>35.67207794903943 139.74224675075482 51.733 35.67215521074355 139.7421819415071 51.733 35.672142077966384 139.7421584273883 51.733 35.67206481627477 139.74222323664796 51.733 35.67207794903943 139.74224675075482 51.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-181af634-6f6a-4ab9-a12d-63d7556c77f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-181af634-6f6a-4ab9-a12d-63d7556c77f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-181af634-6f6a-4ab9-a12d-63d7556c77f0">
											<gml:posList>35.67202577775269 139.74227081404305 48.9 35.67201056526142 139.7421790571307 48.9 35.67192828330689 139.74230398687337 48.9 35.67198652205092 139.74230536783728 48.9 35.67202577775269 139.74227081404305 48.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-afd8d60c-0c96-4b29-bbf9-4c8cc474f555">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-afd8d60c-0c96-4b29-bbf9-4c8cc474f555">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-afd8d60c-0c96-4b29-bbf9-4c8cc474f555">
											<gml:posList>35.67206929911149 139.74226296578652 48.9 35.67207714282826 139.74227722894614 48.9 35.67207794903943 139.74224675075482 48.9 35.67206481627477 139.74222323664796 48.9 35.67206929911149 139.74226296578652 48.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9902b266-8476-4c34-b223-defa2fbf3c6b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9902b266-8476-4c34-b223-defa2fbf3c6b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9902b266-8476-4c34-b223-defa2fbf3c6b">
											<gml:posList>35.671992953981 139.7424314892641 48.9 35.671997258929466 139.74243864250369 48.9 35.67209491001706 139.74235027029076 48.9 35.67206686924651 139.74230380742765 48.9 35.672186066355955 139.7421959907242 48.9 35.67211960415149 139.7420836129138 48.9 35.672142077966384 139.7421584273883 48.9 35.67215521074355 139.7421819415071 48.9 35.67207794903943 139.74224675075482 48.9 35.67207714282826 139.74227722894614 48.9 35.67205074907285 139.74229900946128 48.9 35.672058033174814 139.74231226802576 48.9 35.67204251221139 139.7423250885273 48.9 35.67203067064535 139.74232836068296 48.9 35.67200823202579 139.7423476512213 48.9 35.67199703119752 139.7423280785195 48.9 35.67201946080026 139.74230878798863 48.9 35.67202738438141 139.74229754471568 48.9 35.67206929911149 139.74226296578652 48.9 35.67206481627477 139.74222323664796 48.9 35.67201056526142 139.7421790571307 48.9 35.67202577775269 139.74227081404305 48.9 35.67203224895233 139.7422818642266 48.9 35.67199299324744 139.74231641801822 48.9 35.67198652205092 139.74230536783728 48.9 35.67192828330689 139.74230398687337 48.9 35.6719704662879 139.7423738742351 48.9 35.671947704142944 139.7423944575508 48.9 35.671978091473214 139.74244492758854 48.9 35.671992953981 139.7424314892641 48.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e58ca11f-61ff-4e01-ac09-dd33c72acad2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e58ca11f-61ff-4e01-ac09-dd33c72acad2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e58ca11f-61ff-4e01-ac09-dd33c72acad2">
											<gml:posList>35.67199299324744 139.74231641801822 51.9 35.67203224895233 139.7422818642266 51.9 35.67202577775269 139.74227081404305 51.9 35.67198652205092 139.74230536783728 51.9 35.67199299324744 139.74231641801822 51.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-72e53ea1-8ddd-4ee1-ad16-66322d8570ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-72e53ea1-8ddd-4ee1-ad16-66322d8570ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-72e53ea1-8ddd-4ee1-ad16-66322d8570ec">
											<gml:posList>35.67204251221139 139.7423250885273 50.567 35.672058033174814 139.74231226802576 50.567 35.67205074907285 139.74229900946128 50.567 35.67207714282826 139.74227722894614 50.567 35.67206929911149 139.74226296578652 50.567 35.67202738438141 139.74229754471568 50.567 35.67204251221139 139.7423250885273 50.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f2acf778-e22f-4378-8382-3e4598e8321b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f2acf778-e22f-4378-8382-3e4598e8321b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f2acf778-e22f-4378-8382-3e4598e8321b">
											<gml:posList>35.67203067064535 139.74232836068296 48.9 35.67204251221139 139.7423250885273 48.9 35.67202738438141 139.74229754471568 48.9 35.67201946080026 139.74230878798863 48.9 35.67203067064535 139.74232836068296 48.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fa96f186-7160-480e-8149-42ebe24e330e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa96f186-7160-480e-8149-42ebe24e330e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa96f186-7160-480e-8149-42ebe24e330e">
											<gml:posList>35.67200823202579 139.7423476512213 51.733 35.67203067064535 139.74232836068296 51.733 35.67201946080026 139.74230878798863 51.733 35.67199703119752 139.7423280785195 51.733 35.67200823202579 139.7423476512213 51.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d9202a59-02e9-4cc8-affe-739b35b1962c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d9202a59-02e9-4cc8-affe-739b35b1962c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d9202a59-02e9-4cc8-affe-739b35b1962c">
											<gml:posList>35.67211960415149 139.7420836129138 7.3 35.67201056526142 139.7421790571307 7.3 35.67201056526142 139.7421790571307 48.9 35.67211960415149 139.7420836129138 48.9 35.67211960415149 139.7420836129138 7.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c3e15cc7-9e3b-4835-9235-02dd2102c550">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3e15cc7-9e3b-4835-9235-02dd2102c550">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3e15cc7-9e3b-4835-9235-02dd2102c550">
											<gml:posList>35.672186066355955 139.7421959907242 7.3 35.67211960415149 139.7420836129138 7.3 35.67211960415149 139.7420836129138 48.9 35.672186066355955 139.7421959907242 48.9 35.672186066355955 139.7421959907242 7.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0feca356-aae6-497f-a1fa-976c123a3c49">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0feca356-aae6-497f-a1fa-976c123a3c49">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0feca356-aae6-497f-a1fa-976c123a3c49">
											<gml:posList>35.672142077966384 139.7421584273883 48.9 35.672142077966384 139.7421584273883 51.733 35.67215521074355 139.7421819415071 51.733 35.67215521074355 139.7421819415071 48.9 35.672142077966384 139.7421584273883 48.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6a44c21f-b8f6-4667-8271-6ab4883efd01">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a44c21f-b8f6-4667-8271-6ab4883efd01">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a44c21f-b8f6-4667-8271-6ab4883efd01">
											<gml:posList>35.67206481627477 139.74222323664796 48.9 35.67206481627477 139.74222323664796 51.733 35.672142077966384 139.7421584273883 51.733 35.672142077966384 139.7421584273883 48.9 35.67206481627477 139.74222323664796 48.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-68a80556-3b98-4530-b5fb-561efa45b2d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-68a80556-3b98-4530-b5fb-561efa45b2d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-68a80556-3b98-4530-b5fb-561efa45b2d6">
											<gml:posList>35.67215521074355 139.7421819415071 48.9 35.67215521074355 139.7421819415071 51.733 35.67207794903943 139.74224675075482 51.733 35.67207794903943 139.74224675075482 48.9 35.67215521074355 139.7421819415071 48.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-36ed4b98-79cf-4ded-9ee9-b645b5964d68">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36ed4b98-79cf-4ded-9ee9-b645b5964d68">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36ed4b98-79cf-4ded-9ee9-b645b5964d68">
											<gml:posList>35.67207794903943 139.74224675075482 48.9 35.67207794903943 139.74224675075482 51.733 35.67206481627477 139.74222323664796 51.733 35.67206481627477 139.74222323664796 48.9 35.67207794903943 139.74224675075482 48.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0ad9b2a0-6f53-4e91-8791-d480990f39df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ad9b2a0-6f53-4e91-8791-d480990f39df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ad9b2a0-6f53-4e91-8791-d480990f39df">
											<gml:posList>35.67201056526142 139.7421790571307 7.3 35.67192828330689 139.74230398687337 7.3 35.67192828330689 139.74230398687337 48.9 35.67201056526142 139.7421790571307 48.9 35.67201056526142 139.7421790571307 7.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c28f3d79-3019-431b-b9a3-aed50edcb818">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c28f3d79-3019-431b-b9a3-aed50edcb818">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c28f3d79-3019-431b-b9a3-aed50edcb818">
											<gml:posList>35.67206686924651 139.74230380742765 7.3 35.672186066355955 139.7421959907242 7.3 35.672186066355955 139.7421959907242 48.9 35.67206686924651 139.74230380742765 48.9 35.67206686924651 139.74230380742765 7.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1e05aa56-34dc-44d9-8cb3-a35c3557a1e0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e05aa56-34dc-44d9-8cb3-a35c3557a1e0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e05aa56-34dc-44d9-8cb3-a35c3557a1e0">
											<gml:posList>35.67206929911149 139.74226296578652 48.9 35.67206929911149 139.74226296578652 50.567 35.67207714282826 139.74227722894614 50.567 35.67207714282826 139.74227722894614 48.9 35.67206929911149 139.74226296578652 48.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-539dfdba-592d-4e22-9936-4ff7108336f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-539dfdba-592d-4e22-9936-4ff7108336f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-539dfdba-592d-4e22-9936-4ff7108336f6">
											<gml:posList>35.67202577775269 139.74227081404305 48.9 35.67202577775269 139.74227081404305 51.9 35.67203224895233 139.7422818642266 51.9 35.67203224895233 139.7422818642266 48.9 35.67202577775269 139.74227081404305 48.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-86902419-70cb-4b8b-b80e-f887584cd399">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-86902419-70cb-4b8b-b80e-f887584cd399">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-86902419-70cb-4b8b-b80e-f887584cd399">
											<gml:posList>35.67202738438141 139.74229754471568 48.9 35.67202738438141 139.74229754471568 50.567 35.67206929911149 139.74226296578652 50.567 35.67206929911149 139.74226296578652 48.9 35.67202738438141 139.74229754471568 48.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0faf64d4-c81b-4b82-810c-664fe4badd99">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0faf64d4-c81b-4b82-810c-664fe4badd99">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0faf64d4-c81b-4b82-810c-664fe4badd99">
											<gml:posList>35.67198652205092 139.74230536783728 48.9 35.67198652205092 139.74230536783728 51.9 35.67202577775269 139.74227081404305 51.9 35.67202577775269 139.74227081404305 48.9 35.67198652205092 139.74230536783728 48.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f9c56f48-c5c5-4d2f-ac45-92a863e37784">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9c56f48-c5c5-4d2f-ac45-92a863e37784">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9c56f48-c5c5-4d2f-ac45-92a863e37784">
											<gml:posList>35.67207714282826 139.74227722894614 48.9 35.67207714282826 139.74227722894614 50.567 35.67205074907285 139.74229900946128 50.567 35.67205074907285 139.74229900946128 48.9 35.67207714282826 139.74227722894614 48.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-93453ab3-fa5a-4198-9eeb-1c85ec544640">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-93453ab3-fa5a-4198-9eeb-1c85ec544640">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-93453ab3-fa5a-4198-9eeb-1c85ec544640">
											<gml:posList>35.67203224895233 139.7422818642266 48.9 35.67203224895233 139.7422818642266 51.9 35.67199299324744 139.74231641801822 51.9 35.67199299324744 139.74231641801822 48.9 35.67203224895233 139.7422818642266 48.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e7685c75-52a4-4987-abc3-b80f808b048c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e7685c75-52a4-4987-abc3-b80f808b048c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e7685c75-52a4-4987-abc3-b80f808b048c">
											<gml:posList>35.67205074907285 139.74229900946128 48.9 35.67205074907285 139.74229900946128 50.567 35.672058033174814 139.74231226802576 50.567 35.672058033174814 139.74231226802576 48.9 35.67205074907285 139.74229900946128 48.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6d0cf163-8414-409c-90de-7967aef75c01">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d0cf163-8414-409c-90de-7967aef75c01">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d0cf163-8414-409c-90de-7967aef75c01">
											<gml:posList>35.67199299324744 139.74231641801822 48.9 35.67199299324744 139.74231641801822 51.9 35.67198652205092 139.74230536783728 51.9 35.67198652205092 139.74230536783728 48.9 35.67199299324744 139.74231641801822 48.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6d902bdf-00b8-41f9-8499-16f9772db55e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d902bdf-00b8-41f9-8499-16f9772db55e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d902bdf-00b8-41f9-8499-16f9772db55e">
											<gml:posList>35.67204251221139 139.7423250885273 48.9 35.67204251221139 139.7423250885273 50.567 35.67202738438141 139.74229754471568 50.567 35.67202738438141 139.74229754471568 48.9 35.67204251221139 139.7423250885273 48.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-756cc9d1-3d38-40bc-b45f-2885dec10572">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-756cc9d1-3d38-40bc-b45f-2885dec10572">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-756cc9d1-3d38-40bc-b45f-2885dec10572">
											<gml:posList>35.67199703119752 139.7423280785195 48.9 35.67199703119752 139.7423280785195 51.733 35.67201946080026 139.74230878798863 51.733 35.67201946080026 139.74230878798863 48.9 35.67199703119752 139.7423280785195 48.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4412e65d-e7fd-4c09-ac9a-111bf0d7b905">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4412e65d-e7fd-4c09-ac9a-111bf0d7b905">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4412e65d-e7fd-4c09-ac9a-111bf0d7b905">
											<gml:posList>35.67201946080026 139.74230878798863 48.9 35.67201946080026 139.74230878798863 51.733 35.67203067064535 139.74232836068296 51.733 35.67203067064535 139.74232836068296 48.9 35.67201946080026 139.74230878798863 48.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4cf7c291-7549-4795-b228-70679e901697">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4cf7c291-7549-4795-b228-70679e901697">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4cf7c291-7549-4795-b228-70679e901697">
											<gml:posList>35.672058033174814 139.74231226802576 48.9 35.672058033174814 139.74231226802576 50.567 35.67204251221139 139.7423250885273 50.567 35.67204251221139 139.7423250885273 48.9 35.672058033174814 139.74231226802576 48.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-27f834a2-e5f7-4ba9-992b-9edebec26221">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-27f834a2-e5f7-4ba9-992b-9edebec26221">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-27f834a2-e5f7-4ba9-992b-9edebec26221">
											<gml:posList>35.67209491001706 139.74235027029076 7.3 35.67206686924651 139.74230380742765 7.3 35.67206686924651 139.74230380742765 48.9 35.67209491001706 139.74235027029076 48.9 35.67209491001706 139.74235027029076 7.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-78a0e6f1-2cb2-484d-9934-716840ec80bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78a0e6f1-2cb2-484d-9934-716840ec80bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78a0e6f1-2cb2-484d-9934-716840ec80bd">
											<gml:posList>35.67200823202579 139.7423476512213 48.9 35.67200823202579 139.7423476512213 51.733 35.67199703119752 139.7423280785195 51.733 35.67199703119752 139.7423280785195 48.9 35.67200823202579 139.7423476512213 48.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4a3bbc17-b401-4464-a4ff-933ba6f1e104">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a3bbc17-b401-4464-a4ff-933ba6f1e104">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a3bbc17-b401-4464-a4ff-933ba6f1e104">
											<gml:posList>35.67203067064535 139.74232836068296 48.9 35.67203067064535 139.74232836068296 51.733 35.67200823202579 139.7423476512213 51.733 35.67200823202579 139.7423476512213 48.9 35.67203067064535 139.74232836068296 48.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e10994d2-897d-49ca-ba50-7f60c634dd11">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e10994d2-897d-49ca-ba50-7f60c634dd11">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e10994d2-897d-49ca-ba50-7f60c634dd11">
											<gml:posList>35.67192828330689 139.74230398687337 7.3 35.6719704662879 139.7423738742351 7.3 35.6719704662879 139.7423738742351 48.9 35.67192828330689 139.74230398687337 48.9 35.67192828330689 139.74230398687337 7.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a74c7351-e79e-4cec-8fd3-3446a8851851">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a74c7351-e79e-4cec-8fd3-3446a8851851">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a74c7351-e79e-4cec-8fd3-3446a8851851">
											<gml:posList>35.6719704662879 139.7423738742351 7.3 35.671947704142944 139.7423944575508 7.3 35.671947704142944 139.7423944575508 48.9 35.6719704662879 139.7423738742351 48.9 35.6719704662879 139.7423738742351 7.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-62eac342-b917-4367-b4f2-bdd84b88bdd6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-62eac342-b917-4367-b4f2-bdd84b88bdd6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-62eac342-b917-4367-b4f2-bdd84b88bdd6">
											<gml:posList>35.671997258929466 139.74243864250369 7.3 35.67209491001706 139.74235027029076 7.3 35.67209491001706 139.74235027029076 48.9 35.671997258929466 139.74243864250369 48.9 35.671997258929466 139.74243864250369 7.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-45e82517-5f96-4701-9b7b-cbc54a8b79e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45e82517-5f96-4701-9b7b-cbc54a8b79e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45e82517-5f96-4701-9b7b-cbc54a8b79e6">
											<gml:posList>35.671947704142944 139.7423944575508 7.3 35.671978091473214 139.74244492758854 7.3 35.671978091473214 139.74244492758854 48.9 35.671947704142944 139.7423944575508 48.9 35.671947704142944 139.7423944575508 7.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8a85ebc5-3362-4252-bd14-2e9c8fb81792">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a85ebc5-3362-4252-bd14-2e9c8fb81792">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a85ebc5-3362-4252-bd14-2e9c8fb81792">
											<gml:posList>35.671992953981 139.7424314892641 7.3 35.671997258929466 139.74243864250369 7.3 35.671997258929466 139.74243864250369 48.9 35.671992953981 139.7424314892641 48.9 35.671992953981 139.7424314892641 7.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2da3f40e-b7c0-4ba1-890c-2ed1955d6a9d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2da3f40e-b7c0-4ba1-890c-2ed1955d6a9d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2da3f40e-b7c0-4ba1-890c-2ed1955d6a9d">
											<gml:posList>35.671978091473214 139.74244492758854 7.3 35.671992953981 139.7424314892641 7.3 35.671992953981 139.7424314892641 48.9 35.671978091473214 139.74244492758854 48.9 35.671978091473214 139.74244492758854 7.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都千代田区永田町二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4493</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">475.3428</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.06</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>