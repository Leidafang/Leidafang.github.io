<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_5bf25129-75f6-453d-a1ef-a14790dd1a7f">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">14.8</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67165448042189 139.74131725458426 0 35.671658016721224 139.74132107259234 0 35.67165534249066 139.74132479831013 0 35.67166796310148 139.74133841512972 0 35.6716645955481 139.7413431026829 0 35.67167534877246 139.74135470015108 0 35.671680697243715 139.74134725976185 0 35.671692758528735 139.7413602586303 0 35.67172686197799 139.7413425672884 0 35.67173698263948 139.74132847145677 0 35.671742885951424 139.74132758096653 0 35.671780446139124 139.7412803805575 0 35.67177745110944 139.7412771473859 0 35.67180344605796 139.74124094039595 0 35.67172167814832 139.74115276218308 0 35.671720390556175 139.74115455318744 0 35.67171481547624 139.74114855033213 0 35.6717030650857 139.74116491257672 0 35.67169941150161 139.74116096215096 0 35.67160219382987 139.74129634847378 0 35.67164011880584 139.74133725406472 0 35.67165448042189 139.74131725458426 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67165448042189 139.74131725458426 7.16 35.67164011880584 139.74133725406472 7.16 35.67160219382987 139.74129634847378 7.16 35.67169941150161 139.74116096215096 7.16 35.6717030650857 139.74116491257672 7.16 35.67171481547624 139.74114855033213 7.16 35.671720390556175 139.74115455318744 7.16 35.67172167814832 139.74115276218308 7.16 35.67180344605796 139.74124094039595 7.16 35.67177745110944 139.7412771473859 7.16 35.671780446139124 139.7412803805575 7.16 35.671742885951424 139.74132758096653 7.16 35.67173698263948 139.74132847145677 7.16 35.67172686197799 139.7413425672884 7.16 35.671692758528735 139.7413602586303 7.16 35.671680697243715 139.74134725976185 7.16 35.67167534877246 139.74135470015108 7.16 35.6716645955481 139.7413431026829 7.16 35.67166796310148 139.74133841512972 7.16 35.67165534249066 139.74132479831013 7.16 35.671658016721224 139.74132107259234 7.16 35.67165448042189 139.74131725458426 7.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67165448042189 139.74131725458426 7.16 35.671658016721224 139.74132107259234 7.16 35.671658016721224 139.74132107259234 21.91 35.67165448042189 139.74131725458426 21.91 35.67165448042189 139.74131725458426 7.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671658016721224 139.74132107259234 7.16 35.67165534249066 139.74132479831013 7.16 35.67165534249066 139.74132479831013 21.91 35.671658016721224 139.74132107259234 21.91 35.671658016721224 139.74132107259234 7.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67165534249066 139.74132479831013 7.16 35.67166796310148 139.74133841512972 7.16 35.67166796310148 139.74133841512972 21.91 35.67165534249066 139.74132479831013 21.91 35.67165534249066 139.74132479831013 7.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67166796310148 139.74133841512972 7.16 35.6716645955481 139.7413431026829 7.16 35.6716645955481 139.7413431026829 21.91 35.67166796310148 139.74133841512972 21.91 35.67166796310148 139.74133841512972 7.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6716645955481 139.7413431026829 7.16 35.67167534877246 139.74135470015108 7.16 35.67167534877246 139.74135470015108 21.91 35.6716645955481 139.7413431026829 21.91 35.6716645955481 139.7413431026829 7.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67167534877246 139.74135470015108 7.16 35.671680697243715 139.74134725976185 7.16 35.671680697243715 139.74134725976185 21.91 35.67167534877246 139.74135470015108 21.91 35.67167534877246 139.74135470015108 7.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671680697243715 139.74134725976185 7.16 35.671692758528735 139.7413602586303 7.16 35.671692758528735 139.7413602586303 21.91 35.671680697243715 139.74134725976185 21.91 35.671680697243715 139.74134725976185 7.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671692758528735 139.7413602586303 7.16 35.67172686197799 139.7413425672884 7.16 35.67172686197799 139.7413425672884 21.91 35.671692758528735 139.7413602586303 21.91 35.671692758528735 139.7413602586303 7.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67172686197799 139.7413425672884 7.16 35.67173698263948 139.74132847145677 7.16 35.67173698263948 139.74132847145677 21.91 35.67172686197799 139.7413425672884 21.91 35.67172686197799 139.7413425672884 7.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67173698263948 139.74132847145677 7.16 35.671742885951424 139.74132758096653 7.16 35.671742885951424 139.74132758096653 21.91 35.67173698263948 139.74132847145677 21.91 35.67173698263948 139.74132847145677 7.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671742885951424 139.74132758096653 7.16 35.671780446139124 139.7412803805575 7.16 35.671780446139124 139.7412803805575 21.91 35.671742885951424 139.74132758096653 21.91 35.671742885951424 139.74132758096653 7.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671780446139124 139.7412803805575 7.16 35.67177745110944 139.7412771473859 7.16 35.67177745110944 139.7412771473859 21.91 35.671780446139124 139.7412803805575 21.91 35.671780446139124 139.7412803805575 7.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67177745110944 139.7412771473859 7.16 35.67180344605796 139.74124094039595 7.16 35.67180344605796 139.74124094039595 21.91 35.67177745110944 139.7412771473859 21.91 35.67177745110944 139.7412771473859 7.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67180344605796 139.74124094039595 7.16 35.67172167814832 139.74115276218308 7.16 35.67172167814832 139.74115276218308 21.91 35.67180344605796 139.74124094039595 21.91 35.67180344605796 139.74124094039595 7.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67172167814832 139.74115276218308 7.16 35.671720390556175 139.74115455318744 7.16 35.671720390556175 139.74115455318744 21.91 35.67172167814832 139.74115276218308 21.91 35.67172167814832 139.74115276218308 7.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671720390556175 139.74115455318744 7.16 35.67171481547624 139.74114855033213 7.16 35.67171481547624 139.74114855033213 21.91 35.671720390556175 139.74115455318744 21.91 35.671720390556175 139.74115455318744 7.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67171481547624 139.74114855033213 7.16 35.6717030650857 139.74116491257672 7.16 35.6717030650857 139.74116491257672 21.91 35.67171481547624 139.74114855033213 21.91 35.67171481547624 139.74114855033213 7.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6717030650857 139.74116491257672 7.16 35.67169941150161 139.74116096215096 7.16 35.67169941150161 139.74116096215096 21.91 35.6717030650857 139.74116491257672 21.91 35.6717030650857 139.74116491257672 7.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67169941150161 139.74116096215096 7.16 35.67160219382987 139.74129634847378 7.16 35.67160219382987 139.74129634847378 21.91 35.67169941150161 139.74116096215096 21.91 35.67169941150161 139.74116096215096 7.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67160219382987 139.74129634847378 7.16 35.67164011880584 139.74133725406472 7.16 35.67164011880584 139.74133725406472 21.91 35.67160219382987 139.74129634847378 21.91 35.67160219382987 139.74129634847378 7.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67164011880584 139.74133725406472 7.16 35.67165448042189 139.74131725458426 7.16 35.67165448042189 139.74131725458426 21.91 35.67164011880584 139.74133725406472 21.91 35.67164011880584 139.74133725406472 7.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67165448042189 139.74131725458426 21.91 35.671658016721224 139.74132107259234 21.91 35.67165534249066 139.74132479831013 21.91 35.67166796310148 139.74133841512972 21.91 35.6716645955481 139.7413431026829 21.91 35.67167534877246 139.74135470015108 21.91 35.671680697243715 139.74134725976185 21.91 35.671692758528735 139.7413602586303 21.91 35.67172686197799 139.7413425672884 21.91 35.67173698263948 139.74132847145677 21.91 35.671742885951424 139.74132758096653 21.91 35.671780446139124 139.7412803805575 21.91 35.67177745110944 139.7412771473859 21.91 35.67180344605796 139.74124094039595 21.91 35.67172167814832 139.74115276218308 21.91 35.671720390556175 139.74115455318744 21.91 35.67171481547624 139.74114855033213 21.91 35.6717030650857 139.74116491257672 21.91 35.67169941150161 139.74116096215096 21.91 35.67160219382987 139.74129634847378 21.91 35.67164011880584 139.74133725406472 21.91 35.67165448042189 139.74131725458426 21.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-c437bb82-a717-45ee-bd2f-3052104be0e0"/>
							<gml:surfaceMember xlink:href="#poly-a953eebf-1b84-4013-81e9-fe31a6a0091c"/>
							<gml:surfaceMember xlink:href="#poly-4c7a0850-d591-4cb1-b394-d35cf82ba23f"/>
							<gml:surfaceMember xlink:href="#poly-bc117816-a4db-43cb-be49-f7896f68652e"/>
							<gml:surfaceMember xlink:href="#poly-6f67f659-913f-4bf9-b300-c7139a2f3a77"/>
							<gml:surfaceMember xlink:href="#poly-d273dbf8-f81f-491a-bb6e-70003ca02de8"/>
							<gml:surfaceMember xlink:href="#poly-c87cfcd8-14d9-4a3d-8d84-d74380b31ff6"/>
							<gml:surfaceMember xlink:href="#poly-c10362a1-456d-445d-87b1-075284abf835"/>
							<gml:surfaceMember xlink:href="#poly-d0436b49-a67c-4025-8155-c2c2209622ee"/>
							<gml:surfaceMember xlink:href="#poly-70963632-6fd2-4ae9-8c2a-223167126f12"/>
							<gml:surfaceMember xlink:href="#poly-45e34c5d-aba2-4f12-bb30-5ed630861461"/>
							<gml:surfaceMember xlink:href="#poly-473fcb86-4d80-44fc-a739-1163e75e7b7f"/>
							<gml:surfaceMember xlink:href="#poly-a4022a35-2c46-4fe5-97e1-0501ee64bd7d"/>
							<gml:surfaceMember xlink:href="#poly-1e7b9abd-08bc-4cb9-8d51-625df631de82"/>
							<gml:surfaceMember xlink:href="#poly-7748c67e-19d9-46d3-9910-81bc8d44fea1"/>
							<gml:surfaceMember xlink:href="#poly-0d45d954-45e6-4742-ac6d-71aacc300153"/>
							<gml:surfaceMember xlink:href="#poly-135a16f3-d652-4093-8407-19d57d9b5b8d"/>
							<gml:surfaceMember xlink:href="#poly-babd45b5-9084-4142-89c9-5d730b5f9c19"/>
							<gml:surfaceMember xlink:href="#poly-f5d9a643-eeac-4938-83df-8ac6ee0ed518"/>
							<gml:surfaceMember xlink:href="#poly-83821f79-db6d-4405-9c83-86700aa70b17"/>
							<gml:surfaceMember xlink:href="#poly-6be96d6f-ab8a-4d81-b89e-0db4ffbfbb13"/>
							<gml:surfaceMember xlink:href="#poly-fac77b74-e8b7-4395-8a8e-e5a733f34251"/>
							<gml:surfaceMember xlink:href="#poly-eb7c6a55-1bd9-42cc-80b9-0257f71994d6"/>
							<gml:surfaceMember xlink:href="#poly-bbadfdd2-4aaf-4aac-a14d-1dcae7e97526"/>
							<gml:surfaceMember xlink:href="#poly-827488af-8ec9-4f15-a06c-33bd0a906c69"/>
							<gml:surfaceMember xlink:href="#poly-18d68198-9156-47f5-bb98-76d1c6715f53"/>
							<gml:surfaceMember xlink:href="#poly-981cd3b8-46d9-45ec-a8b8-2645fb7fdf93"/>
							<gml:surfaceMember xlink:href="#poly-d0907306-492b-4a5c-a8ff-1764d9390232"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-c437bb82-a717-45ee-bd2f-3052104be0e0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c437bb82-a717-45ee-bd2f-3052104be0e0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c437bb82-a717-45ee-bd2f-3052104be0e0">
											<gml:posList>35.671720390556175 139.74115455318744 7.16 35.67172167814831 139.74115276218308 7.16 35.671803446057936 139.74124094039595 7.16 35.67177745110942 139.7412771473859 7.16 35.671780446139124 139.74128038055753 7.16 35.67174288595142 139.74132758096653 7.16 35.67173698263948 139.74132847145677 7.16 35.67172686197796 139.7413425672884 7.16 35.67169275852872 139.74136025863027 7.16 35.67168069724367 139.74134725976182 7.16 35.671675348772446 139.74135470015108 7.16 35.6716645955481 139.74134310268286 7.16 35.67166796310148 139.74133841512972 7.16 35.671655342490666 139.7413247983101 7.16 35.671658016721196 139.74132107259234 7.16 35.671654480421886 139.74131725458423 7.16 35.671640118805804 139.7413372540647 7.16 35.67160219382986 139.74129634847378 7.16 35.671699411501606 139.74116096215093 7.16 35.67170306508569 139.74116491257672 7.16 35.67171481547625 139.74114855033213 7.16 35.671720390556175 139.74115455318744 7.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a953eebf-1b84-4013-81e9-fe31a6a0091c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a953eebf-1b84-4013-81e9-fe31a6a0091c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a953eebf-1b84-4013-81e9-fe31a6a0091c">
											<gml:posList>35.671640118805804 139.7413372540647 10.433 35.671654480421886 139.74131725458423 10.433 35.671641553705165 139.74130411311825 10.433 35.671627516239134 139.74132365932218 10.433 35.671640118805804 139.7413372540647 10.433</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4c7a0850-d591-4cb1-b394-d35cf82ba23f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c7a0850-d591-4cb1-b394-d35cf82ba23f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c7a0850-d591-4cb1-b394-d35cf82ba23f">
											<gml:posList>35.671720390556175 139.74115455318744 22.096 35.67171481547625 139.74114855033213 22.096 35.67170306508569 139.74116491257672 22.096 35.671699411501606 139.74116096215093 22.096 35.67160219382986 139.74129634847378 22.096 35.671627516239134 139.74132365932218 22.096 35.671641553705165 139.74130411311825 22.096 35.671654480421886 139.74131725458423 22.096 35.671658016721196 139.74132107259234 22.096 35.671655342490666 139.7413247983101 22.096 35.67166796310148 139.74133841512972 22.096 35.6716645955481 139.74134310268286 22.096 35.671675348772446 139.74135470015108 22.096 35.67168069724367 139.74134725976182 22.096 35.67168890649729 139.74135610958783 22.096 35.67178550295555 139.74122159657423 22.096 35.67172167814831 139.74115276218308 22.096 35.671720390556175 139.74115455318744 22.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bc117816-a4db-43cb-be49-f7896f68652e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc117816-a4db-43cb-be49-f7896f68652e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc117816-a4db-43cb-be49-f7896f68652e">
											<gml:posList>35.67173698263948 139.74132847145677 11.567 35.67174288595142 139.74132758096653 11.567 35.671780446139124 139.74128038055753 11.567 35.67177745110942 139.7412771473859 11.567 35.671803446057936 139.74124094039595 11.567 35.67178550295555 139.74122159657423 11.567 35.67168890649729 139.74135610958783 11.567 35.67169275852872 139.74136025863027 11.567 35.67172686197796 139.7413425672884 11.567 35.67173698263948 139.74132847145677 11.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6f67f659-913f-4bf9-b300-c7139a2f3a77">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f67f659-913f-4bf9-b300-c7139a2f3a77">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f67f659-913f-4bf9-b300-c7139a2f3a77">
											<gml:posList>35.671720390556175 139.74115455318744 22.096 35.671720390556175 139.74115455318744 7.16 35.67171481547625 139.74114855033213 7.16 35.67171481547625 139.74114855033213 22.096 35.671720390556175 139.74115455318744 22.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d273dbf8-f81f-491a-bb6e-70003ca02de8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d273dbf8-f81f-491a-bb6e-70003ca02de8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d273dbf8-f81f-491a-bb6e-70003ca02de8">
											<gml:posList>35.67172167814831 139.74115276218308 22.096 35.67172167814831 139.74115276218308 7.16 35.671720390556175 139.74115455318744 7.16 35.671720390556175 139.74115455318744 22.096 35.67172167814831 139.74115276218308 22.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c87cfcd8-14d9-4a3d-8d84-d74380b31ff6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c87cfcd8-14d9-4a3d-8d84-d74380b31ff6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c87cfcd8-14d9-4a3d-8d84-d74380b31ff6">
											<gml:posList>35.67171481547625 139.74114855033213 22.096 35.67171481547625 139.74114855033213 7.16 35.67170306508569 139.74116491257672 7.16 35.67170306508569 139.74116491257672 22.096 35.67171481547625 139.74114855033213 22.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c10362a1-456d-445d-87b1-075284abf835">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c10362a1-456d-445d-87b1-075284abf835">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c10362a1-456d-445d-87b1-075284abf835">
											<gml:posList>35.67170306508569 139.74116491257672 22.096 35.67170306508569 139.74116491257672 7.16 35.671699411501606 139.74116096215093 7.16 35.671699411501606 139.74116096215093 22.096 35.67170306508569 139.74116491257672 22.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d0436b49-a67c-4025-8155-c2c2209622ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d0436b49-a67c-4025-8155-c2c2209622ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d0436b49-a67c-4025-8155-c2c2209622ee">
											<gml:posList>35.67172167814831 139.74115276218308 7.16 35.67172167814831 139.74115276218308 22.096 35.67178550295555 139.74122159657423 22.096 35.67178550295555 139.74122159657423 11.567 35.671803446057936 139.74124094039595 11.567 35.671803446057936 139.74124094039595 7.16 35.67172167814831 139.74115276218308 7.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-70963632-6fd2-4ae9-8c2a-223167126f12">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70963632-6fd2-4ae9-8c2a-223167126f12">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70963632-6fd2-4ae9-8c2a-223167126f12">
											<gml:posList>35.671699411501606 139.74116096215093 22.096 35.671699411501606 139.74116096215093 7.16 35.67160219382986 139.74129634847378 7.16 35.67160219382986 139.74129634847378 22.096 35.671699411501606 139.74116096215093 22.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-45e34c5d-aba2-4f12-bb30-5ed630861461">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45e34c5d-aba2-4f12-bb30-5ed630861461">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45e34c5d-aba2-4f12-bb30-5ed630861461">
											<gml:posList>35.67177745110942 139.7412771473859 11.567 35.67177745110942 139.7412771473859 7.16 35.671803446057936 139.74124094039595 7.16 35.671803446057936 139.74124094039595 11.567 35.67177745110942 139.7412771473859 11.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-473fcb86-4d80-44fc-a739-1163e75e7b7f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-473fcb86-4d80-44fc-a739-1163e75e7b7f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-473fcb86-4d80-44fc-a739-1163e75e7b7f">
											<gml:posList>35.671780446139124 139.74128038055753 11.567 35.671780446139124 139.74128038055753 7.16 35.67177745110942 139.7412771473859 7.16 35.67177745110942 139.7412771473859 11.567 35.671780446139124 139.74128038055753 11.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a4022a35-2c46-4fe5-97e1-0501ee64bd7d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4022a35-2c46-4fe5-97e1-0501ee64bd7d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4022a35-2c46-4fe5-97e1-0501ee64bd7d">
											<gml:posList>35.67168890649729 139.74135610958783 11.567 35.67178550295555 139.74122159657423 11.567 35.67178550295555 139.74122159657423 22.096 35.67168890649729 139.74135610958783 22.096 35.67168890649729 139.74135610958783 11.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1e7b9abd-08bc-4cb9-8d51-625df631de82">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e7b9abd-08bc-4cb9-8d51-625df631de82">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e7b9abd-08bc-4cb9-8d51-625df631de82">
											<gml:posList>35.67174288595142 139.74132758096653 11.567 35.67174288595142 139.74132758096653 7.16 35.671780446139124 139.74128038055753 7.16 35.671780446139124 139.74128038055753 11.567 35.67174288595142 139.74132758096653 11.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7748c67e-19d9-46d3-9910-81bc8d44fea1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7748c67e-19d9-46d3-9910-81bc8d44fea1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7748c67e-19d9-46d3-9910-81bc8d44fea1">
											<gml:posList>35.671641553705165 139.74130411311825 10.433 35.671654480421886 139.74131725458423 10.433 35.671654480421886 139.74131725458423 22.096 35.671641553705165 139.74130411311825 22.096 35.671641553705165 139.74130411311825 10.433</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0d45d954-45e6-4742-ac6d-71aacc300153">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d45d954-45e6-4742-ac6d-71aacc300153">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d45d954-45e6-4742-ac6d-71aacc300153">
											<gml:posList>35.671627516239134 139.74132365932218 10.433 35.671641553705165 139.74130411311825 10.433 35.671641553705165 139.74130411311825 22.096 35.671627516239134 139.74132365932218 22.096 35.671627516239134 139.74132365932218 10.433</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-135a16f3-d652-4093-8407-19d57d9b5b8d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-135a16f3-d652-4093-8407-19d57d9b5b8d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-135a16f3-d652-4093-8407-19d57d9b5b8d">
											<gml:posList>35.671627516239134 139.74132365932218 10.433 35.671627516239134 139.74132365932218 22.096 35.67160219382986 139.74129634847378 22.096 35.67160219382986 139.74129634847378 7.16 35.671640118805804 139.7413372540647 7.16 35.671640118805804 139.7413372540647 10.433 35.671627516239134 139.74132365932218 10.433</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-babd45b5-9084-4142-89c9-5d730b5f9c19">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-babd45b5-9084-4142-89c9-5d730b5f9c19">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-babd45b5-9084-4142-89c9-5d730b5f9c19">
											<gml:posList>35.671658016721196 139.74132107259234 7.16 35.671658016721196 139.74132107259234 22.096 35.671654480421886 139.74131725458423 22.096 35.671654480421886 139.74131725458423 10.433 35.671654480421886 139.74131725458423 7.16 35.671658016721196 139.74132107259234 7.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f5d9a643-eeac-4938-83df-8ac6ee0ed518">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f5d9a643-eeac-4938-83df-8ac6ee0ed518">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f5d9a643-eeac-4938-83df-8ac6ee0ed518">
											<gml:posList>35.671658016721196 139.74132107259234 22.096 35.671658016721196 139.74132107259234 7.16 35.671655342490666 139.7413247983101 7.16 35.671655342490666 139.7413247983101 22.096 35.671658016721196 139.74132107259234 22.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-83821f79-db6d-4405-9c83-86700aa70b17">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83821f79-db6d-4405-9c83-86700aa70b17">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83821f79-db6d-4405-9c83-86700aa70b17">
											<gml:posList>35.671640118805804 139.7413372540647 10.433 35.671640118805804 139.7413372540647 7.16 35.671654480421886 139.74131725458423 7.16 35.671654480421886 139.74131725458423 10.433 35.671640118805804 139.7413372540647 10.433</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6be96d6f-ab8a-4d81-b89e-0db4ffbfbb13">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6be96d6f-ab8a-4d81-b89e-0db4ffbfbb13">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6be96d6f-ab8a-4d81-b89e-0db4ffbfbb13">
											<gml:posList>35.67173698263948 139.74132847145677 11.567 35.67173698263948 139.74132847145677 7.16 35.67174288595142 139.74132758096653 7.16 35.67174288595142 139.74132758096653 11.567 35.67173698263948 139.74132847145677 11.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fac77b74-e8b7-4395-8a8e-e5a733f34251">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fac77b74-e8b7-4395-8a8e-e5a733f34251">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fac77b74-e8b7-4395-8a8e-e5a733f34251">
											<gml:posList>35.671655342490666 139.7413247983101 22.096 35.671655342490666 139.7413247983101 7.16 35.67166796310148 139.74133841512972 7.16 35.67166796310148 139.74133841512972 22.096 35.671655342490666 139.7413247983101 22.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eb7c6a55-1bd9-42cc-80b9-0257f71994d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eb7c6a55-1bd9-42cc-80b9-0257f71994d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eb7c6a55-1bd9-42cc-80b9-0257f71994d6">
											<gml:posList>35.67172686197796 139.7413425672884 11.567 35.67172686197796 139.7413425672884 7.16 35.67173698263948 139.74132847145677 7.16 35.67173698263948 139.74132847145677 11.567 35.67172686197796 139.7413425672884 11.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bbadfdd2-4aaf-4aac-a14d-1dcae7e97526">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bbadfdd2-4aaf-4aac-a14d-1dcae7e97526">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bbadfdd2-4aaf-4aac-a14d-1dcae7e97526">
											<gml:posList>35.67166796310148 139.74133841512972 22.096 35.67166796310148 139.74133841512972 7.16 35.6716645955481 139.74134310268286 7.16 35.6716645955481 139.74134310268286 22.096 35.67166796310148 139.74133841512972 22.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-827488af-8ec9-4f15-a06c-33bd0a906c69">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-827488af-8ec9-4f15-a06c-33bd0a906c69">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-827488af-8ec9-4f15-a06c-33bd0a906c69">
											<gml:posList>35.6716645955481 139.74134310268286 22.096 35.6716645955481 139.74134310268286 7.16 35.671675348772446 139.74135470015108 7.16 35.671675348772446 139.74135470015108 22.096 35.6716645955481 139.74134310268286 22.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-18d68198-9156-47f5-bb98-76d1c6715f53">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18d68198-9156-47f5-bb98-76d1c6715f53">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18d68198-9156-47f5-bb98-76d1c6715f53">
											<gml:posList>35.671675348772446 139.74135470015108 22.096 35.671675348772446 139.74135470015108 7.16 35.67168069724367 139.74134725976182 7.16 35.67168069724367 139.74134725976182 22.096 35.671675348772446 139.74135470015108 22.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-981cd3b8-46d9-45ec-a8b8-2645fb7fdf93">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-981cd3b8-46d9-45ec-a8b8-2645fb7fdf93">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-981cd3b8-46d9-45ec-a8b8-2645fb7fdf93">
											<gml:posList>35.67169275852872 139.74136025863027 11.567 35.67169275852872 139.74136025863027 7.16 35.67172686197796 139.7413425672884 7.16 35.67172686197796 139.7413425672884 11.567 35.67169275852872 139.74136025863027 11.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d0907306-492b-4a5c-a8ff-1764d9390232">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d0907306-492b-4a5c-a8ff-1764d9390232">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d0907306-492b-4a5c-a8ff-1764d9390232">
											<gml:posList>35.67168890649729 139.74135610958783 11.567 35.67168890649729 139.74135610958783 22.096 35.67168069724367 139.74134725976182 22.096 35.67168069724367 139.74134725976182 7.16 35.67169275852872 139.74136025863027 7.16 35.67169275852872 139.74136025863027 11.567 35.67168890649729 139.74135610958783 11.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4492</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">2</uro:rank>
					<uro:depth uom="m">0.65</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>