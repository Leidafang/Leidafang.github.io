<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_5d34a513-f00e-4b34-88a5-918636fa938f">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">14.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.670599356477574 139.74290661270487 0 35.67052511361757 139.74282694229976 0 35.67046795202476 139.7430477113356 0 35.67055387839449 139.74308174759227 0 35.670599356477574 139.74290661270487 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670599356477574 139.74290661270487 7.21 35.67055387839449 139.74308174759227 7.21 35.67046795202476 139.7430477113356 7.21 35.67052511361757 139.74282694229976 7.21 35.670599356477574 139.74290661270487 7.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670599356477574 139.74290661270487 7.21 35.67052511361757 139.74282694229976 7.21 35.67052511361757 139.74282694229976 21.58 35.670599356477574 139.74290661270487 21.58 35.670599356477574 139.74290661270487 7.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67052511361757 139.74282694229976 7.21 35.67046795202476 139.7430477113356 7.21 35.67046795202476 139.7430477113356 21.58 35.67052511361757 139.74282694229976 21.58 35.67052511361757 139.74282694229976 7.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67046795202476 139.7430477113356 7.21 35.67055387839449 139.74308174759227 7.21 35.67055387839449 139.74308174759227 21.58 35.67046795202476 139.7430477113356 21.58 35.67046795202476 139.7430477113356 7.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67055387839449 139.74308174759227 7.21 35.670599356477574 139.74290661270487 7.21 35.670599356477574 139.74290661270487 21.58 35.67055387839449 139.74308174759227 21.58 35.67055387839449 139.74308174759227 7.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670599356477574 139.74290661270487 21.58 35.67052511361757 139.74282694229976 21.58 35.67046795202476 139.7430477113356 21.58 35.67055387839449 139.74308174759227 21.58 35.670599356477574 139.74290661270487 21.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-311f34b3-65ef-4df2-8b00-a2ab342307d5"/>
							<gml:surfaceMember xlink:href="#poly-a153776a-6920-401e-867d-a94438313572"/>
							<gml:surfaceMember xlink:href="#poly-67966bf9-db01-458c-bad0-745e5b4fdd2e"/>
							<gml:surfaceMember xlink:href="#poly-d25db255-045f-4ea1-a89b-e6c04c6bfa7e"/>
							<gml:surfaceMember xlink:href="#poly-97a1088b-10af-432b-b904-2c3675f13af7"/>
							<gml:surfaceMember xlink:href="#poly-4705f523-ec8f-4b3c-ac97-f8a1449b88cc"/>
							<gml:surfaceMember xlink:href="#poly-920bb01e-600a-4ca2-a020-c91ea5921d31"/>
							<gml:surfaceMember xlink:href="#poly-68d2b3da-ea65-458a-affc-e9d6e76a14d1"/>
							<gml:surfaceMember xlink:href="#poly-2898e7bc-9a60-4df0-8a4f-9aa288951d48"/>
							<gml:surfaceMember xlink:href="#poly-de8a1725-d95d-48a4-9655-960053ff5892"/>
							<gml:surfaceMember xlink:href="#poly-2fbaf69c-49c2-4cbe-9596-8e82e4a56503"/>
							<gml:surfaceMember xlink:href="#poly-394d8792-c25a-4693-aa51-4223a6c8c24c"/>
							<gml:surfaceMember xlink:href="#poly-52b80c71-1ffb-4157-ad39-afb1859d75d0"/>
							<gml:surfaceMember xlink:href="#poly-736df56e-f24d-4879-8bc7-56009ed9d8e8"/>
							<gml:surfaceMember xlink:href="#poly-b046acd6-48a0-400a-8ed0-3194475294cc"/>
							<gml:surfaceMember xlink:href="#poly-c0ba9895-58ae-44d3-9cb2-cad5f34eb380"/>
							<gml:surfaceMember xlink:href="#poly-3e644997-9762-4704-98df-163bfc1795e5"/>
							<gml:surfaceMember xlink:href="#poly-2844a2f8-8569-4ec8-b7af-654a6ce54b16"/>
							<gml:surfaceMember xlink:href="#poly-e89be035-8112-45a8-914e-1e369ae2a0dd"/>
							<gml:surfaceMember xlink:href="#poly-e49920fe-8458-4f2c-a79e-60cbae29c371"/>
							<gml:surfaceMember xlink:href="#poly-d794bbe5-d820-446d-a328-3ef7cf90dd40"/>
							<gml:surfaceMember xlink:href="#poly-cffab7ef-e153-4db1-9b15-b978fcbb2407"/>
							<gml:surfaceMember xlink:href="#poly-0102e398-76f8-4de8-a8aa-417048271b33"/>
							<gml:surfaceMember xlink:href="#poly-3db12bc0-9b34-4b0f-b8d6-e26d60a35332"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_5d34a513-f00e-4b34-88a5-918636fa938f_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f1c757c1-bae8-4d8b-97f5-41324659b727">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67055235333794 139.74288722425803 25.585 35.670551911872934 139.74288750091313 25.585 35.67055146136102 139.7428877333933 25.585 35.6705510018022 139.74288792169853 25.585 35.670550524174445 139.74288805479273 25.585 35.67055003749147 139.7428881326657 25.585 35.67054955077533 139.74288816635362 25.585 35.67054906400939 139.74288813376387 25.585 35.670548577210255 139.74288805698902 25.585 35.670548099391674 139.74288793601892 25.585 35.67054763054532 139.7428877598073 25.585 35.670547179684924 139.74288752834397 25.585 35.67054674681879 139.7428872526752 25.585 35.67054633194691 139.742886932801 25.585 35.670545944091295 139.7428865797575 25.585 35.67054558323539 139.74288617145214 25.585 35.67054524939574 139.74288572997744 25.585 35.67054495158609 139.74288525532327 25.585 35.67054468980644 139.7428847474896 25.585 35.67054446407338 139.74288422856898 25.585 35.67054427437032 139.74288367646886 25.585 35.67054412070556 139.74288310223554 25.585 35.67054402111483 139.74288251689492 25.585 35.670543948556976 139.74288192047754 25.585 35.67054393008144 139.74288132399914 25.585 35.67054394766081 139.74288072748007 25.585 35.67054401030878 139.74288013091015 25.585 35.67054410901995 139.74287954534583 25.585 35.67054425281633 139.7428789818232 25.585 35.670544441681315 139.74287841824972 25.585 35.670544666626085 139.7428778877744 25.585 35.67054492764234 139.74287737935092 25.585 35.670545224738376 139.7428769040256 25.585 35.67054554890048 139.74287646180858 25.585 35.67054590914237 139.74287605268972 25.585 35.670546296458625 139.7428756877254 25.585 35.67054671084923 139.74287536691568 25.585 35.670547143300475 139.7428750902707 25.585 35.67054759381236 139.7428748577905 25.585 35.67054805337118 139.7428746694852 25.585 35.67054853099891 139.74287453639093 25.585 35.670549017681864 139.74287445851786 25.585 35.67054950440632 139.74287443587613 25.585 35.67054999116395 139.7428744574195 25.585 35.67055047796308 139.74287453419427 25.585 35.67055095578169 139.7428746551643 25.585 35.67055142463637 139.74287484242214 25.585 35.670551875488485 139.74287506283915 25.585 35.670552308354644 139.74287533850784 25.585 35.67055272322656 139.742875658382 25.585 35.67055311109049 139.74287602247173 25.585 35.670553471938156 139.74287641973086 25.585 35.67055380577783 139.74287686120553 25.585 35.670554103587506 139.74287733585976 25.585 35.67055436536719 139.74287784369346 25.585 35.670554591108576 139.7428783736604 25.585 35.67055478081166 139.74287892576058 25.585 35.67055493446814 139.7428794889477 25.585 35.6705550430726 139.74288007427822 25.585 35.67055510661675 139.74288067070583 25.585 35.670555125092285 139.74288126718432 25.585 35.67055510751292 139.74288186370347 25.585 35.670555044864926 139.74288246027348 25.585 35.67055494615375 139.74288304583789 25.585 35.67055480236566 139.74288362040684 25.585 35.67055461349235 139.7428841729341 25.585 35.67055438854756 139.7428847034095 25.585 35.67055412753126 139.74288521183297 25.585 35.670553830435196 139.74288568715835 25.585 35.67055350627305 139.74288612937536 25.585 35.67055314603113 139.74288653849425 25.585 35.670552758714855 139.74288690345853 25.585 35.67055235333794 139.74288722425803 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa1dfd31-f49f-426d-abc9-76491ce7ba60">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67058413901205 139.74292757362937 22.5 35.6705160473769 139.74290101783066 22.5 35.67051680234777 139.74289811180788 22.5 35.67058489398356 139.74292466760437 22.5 35.67058413901205 139.74292757362937 22.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b0b7d82-655d-424e-9439-836179cb578b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6705160473769 139.74290101783066 21.508 35.67058413901205 139.74292757362937 21.508 35.670582763876624 139.74293285530544 21.508 35.670514672242604 139.74290629950266 21.508 35.6705160473769 139.74290101783066 21.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c3f2e34-3c3b-45ad-a02b-5b03ec3505bf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c3f2e34-3c3b-45ad-a02b-5b03ec3505bf_0">
											<gml:posList>35.67054999116395 139.7428744574195 25.585 35.67054950440632 139.74287443587613 25.585 35.67054950440632 139.74287443587613 28.11 35.67054999116395 139.7428744574195 28.11 35.67054999116395 139.7428744574195 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-90177e3e-5038-4585-ada8-862fbf60f4d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-90177e3e-5038-4585-ada8-862fbf60f4d8_0">
											<gml:posList>35.67054950440632 139.74287443587613 25.585 35.670549017681864 139.74287445851786 25.585 35.670549017681864 139.74287445851786 28.11 35.67054950440632 139.74287443587613 28.11 35.67054950440632 139.74287443587613 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e5fdad94-1bb6-42a7-a818-bf32fa79b817">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e5fdad94-1bb6-42a7-a818-bf32fa79b817_0">
											<gml:posList>35.67054999116395 139.7428744574195 25.585 35.67054999116395 139.7428744574195 28.11 35.67055047796308 139.74287453419427 28.11 35.67055047796308 139.74287453419427 25.585 35.67054999116395 139.7428744574195 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c6af4f9-e32d-4348-a665-583b1900f134">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c6af4f9-e32d-4348-a665-583b1900f134_0">
											<gml:posList>35.67054853099891 139.74287453639093 25.585 35.67054853099891 139.74287453639093 28.11 35.670549017681864 139.74287445851786 28.11 35.670549017681864 139.74287445851786 25.585 35.67054853099891 139.74287453639093 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8270ec14-e1f0-4e2d-9a93-47eb9aafd49c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8270ec14-e1f0-4e2d-9a93-47eb9aafd49c_0">
											<gml:posList>35.67055095578169 139.7428746551643 25.585 35.67055047796308 139.74287453419427 25.585 35.67055047796308 139.74287453419427 28.11 35.67055095578169 139.7428746551643 28.11 35.67055095578169 139.7428746551643 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b155f3b8-7386-4a47-b5e7-4316e1621f06">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b155f3b8-7386-4a47-b5e7-4316e1621f06_0">
											<gml:posList>35.67054853099891 139.74287453639093 25.585 35.67054805337118 139.7428746694852 25.585 35.67054805337118 139.7428746694852 28.11 35.67054853099891 139.74287453639093 28.11 35.67054853099891 139.74287453639093 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-09dccdf7-71d9-4c83-ac9c-ff81cd77b839">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-09dccdf7-71d9-4c83-ac9c-ff81cd77b839_0">
											<gml:posList>35.67055142463637 139.74287484242214 25.585 35.67055095578169 139.7428746551643 25.585 35.67055095578169 139.7428746551643 28.11 35.67055142463637 139.74287484242214 28.11 35.67055142463637 139.74287484242214 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1fc305b-2f9d-4cbd-9d31-1be6ce99c288">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d1fc305b-2f9d-4cbd-9d31-1be6ce99c288_0">
											<gml:posList>35.67054805337118 139.7428746694852 25.585 35.67054759381236 139.7428748577905 25.585 35.67054759381236 139.7428748577905 28.11 35.67054805337118 139.7428746694852 28.11 35.67054805337118 139.7428746694852 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0450b9f2-87ab-4c51-bc40-2463bcd869e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0450b9f2-87ab-4c51-bc40-2463bcd869e2_0">
											<gml:posList>35.670551875488485 139.74287506283915 25.585 35.67055142463637 139.74287484242214 25.585 35.67055142463637 139.74287484242214 28.11 35.670551875488485 139.74287506283915 28.11 35.670551875488485 139.74287506283915 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f25b888e-84c4-483c-b8eb-dd7e395ad483">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f25b888e-84c4-483c-b8eb-dd7e395ad483_0">
											<gml:posList>35.67054759381236 139.7428748577905 25.585 35.670547143300475 139.7428750902707 25.585 35.670547143300475 139.7428750902707 28.11 35.67054759381236 139.7428748577905 28.11 35.67054759381236 139.7428748577905 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca2ca160-a05a-4a02-8e88-3b26bc73c431">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ca2ca160-a05a-4a02-8e88-3b26bc73c431_0">
											<gml:posList>35.670552308354644 139.74287533850784 25.585 35.670551875488485 139.74287506283915 25.585 35.670551875488485 139.74287506283915 28.11 35.670552308354644 139.74287533850784 28.11 35.670552308354644 139.74287533850784 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6bcfda0d-73c7-452e-8ea8-b55dd014945b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6bcfda0d-73c7-452e-8ea8-b55dd014945b_0">
											<gml:posList>35.670547143300475 139.7428750902707 25.585 35.67054671084923 139.74287536691568 25.585 35.67054671084923 139.74287536691568 28.11 35.670547143300475 139.7428750902707 28.11 35.670547143300475 139.7428750902707 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7aa52f09-4d03-418b-a642-0a5d8892f49d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7aa52f09-4d03-418b-a642-0a5d8892f49d_0">
											<gml:posList>35.670552308354644 139.74287533850784 25.585 35.670552308354644 139.74287533850784 28.11 35.67055272322656 139.742875658382 28.11 35.67055272322656 139.742875658382 25.585 35.670552308354644 139.74287533850784 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-96d6c211-48d6-4993-80f8-d937acbe0021">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-96d6c211-48d6-4993-80f8-d937acbe0021_0">
											<gml:posList>35.67054671084923 139.74287536691568 25.585 35.670546296458625 139.7428756877254 25.585 35.670546296458625 139.7428756877254 28.11 35.67054671084923 139.74287536691568 28.11 35.67054671084923 139.74287536691568 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c67823c-5749-4670-be00-cb45a3b11f80">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c67823c-5749-4670-be00-cb45a3b11f80_0">
											<gml:posList>35.67055311109049 139.74287602247173 25.585 35.67055272322656 139.742875658382 25.585 35.67055272322656 139.742875658382 28.11 35.67055311109049 139.74287602247173 28.11 35.67055311109049 139.74287602247173 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-23233636-bf20-4e61-9e42-cddf33f6562a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-23233636-bf20-4e61-9e42-cddf33f6562a_0">
											<gml:posList>35.670546296458625 139.7428756877254 25.585 35.67054590914237 139.74287605268972 25.585 35.67054590914237 139.74287605268972 28.11 35.670546296458625 139.7428756877254 28.11 35.670546296458625 139.7428756877254 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab56e566-bee6-491f-9de1-25d90f896fb1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ab56e566-bee6-491f-9de1-25d90f896fb1_0">
											<gml:posList>35.670553471938156 139.74287641973086 25.585 35.67055311109049 139.74287602247173 25.585 35.67055311109049 139.74287602247173 28.11 35.670553471938156 139.74287641973086 28.11 35.670553471938156 139.74287641973086 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6b770cf-0a1b-4b59-9fba-56673ea612b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d6b770cf-0a1b-4b59-9fba-56673ea612b3_0">
											<gml:posList>35.67054590914237 139.74287605268972 25.585 35.67054554890048 139.74287646180858 25.585 35.67054554890048 139.74287646180858 28.11 35.67054590914237 139.74287605268972 28.11 35.67054590914237 139.74287605268972 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76a80907-c4e7-4d6e-a947-d855845601a4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-76a80907-c4e7-4d6e-a947-d855845601a4_0">
											<gml:posList>35.67055380577783 139.74287686120553 25.585 35.670553471938156 139.74287641973086 25.585 35.670553471938156 139.74287641973086 28.11 35.67055380577783 139.74287686120553 28.11 35.67055380577783 139.74287686120553 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-86f29e8f-eea9-4f6d-8909-c18477a59fb3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-86f29e8f-eea9-4f6d-8909-c18477a59fb3_0">
											<gml:posList>35.67054554890048 139.74287646180858 25.585 35.670545224738376 139.7428769040256 25.585 35.670545224738376 139.7428769040256 28.11 35.67054554890048 139.74287646180858 28.11 35.67054554890048 139.74287646180858 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8525dde-a0f0-4210-8ab3-fd390facd70c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d8525dde-a0f0-4210-8ab3-fd390facd70c_0">
											<gml:posList>35.670554103587506 139.74287733585976 25.585 35.67055380577783 139.74287686120553 25.585 35.67055380577783 139.74287686120553 28.11 35.670554103587506 139.74287733585976 28.11 35.670554103587506 139.74287733585976 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b32075e-36e9-4f86-b6bb-7907f28b9d0c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b32075e-36e9-4f86-b6bb-7907f28b9d0c_0">
											<gml:posList>35.670545224738376 139.7428769040256 25.585 35.67054492764234 139.74287737935092 25.585 35.67054492764234 139.74287737935092 28.11 35.670545224738376 139.7428769040256 28.11 35.670545224738376 139.7428769040256 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-86d65906-62bd-40f8-beaa-aed0d99030e7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-86d65906-62bd-40f8-beaa-aed0d99030e7_0">
											<gml:posList>35.67055436536719 139.74287784369346 25.585 35.670554103587506 139.74287733585976 25.585 35.670554103587506 139.74287733585976 28.11 35.67055436536719 139.74287784369346 28.11 35.67055436536719 139.74287784369346 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9b435b11-9217-4a34-ab6c-6c305eb05259">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9b435b11-9217-4a34-ab6c-6c305eb05259_0">
											<gml:posList>35.67054492764234 139.74287737935092 25.585 35.670544666626085 139.7428778877744 25.585 35.670544666626085 139.7428778877744 28.11 35.67054492764234 139.74287737935092 28.11 35.67054492764234 139.74287737935092 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d555ba0d-b543-4936-b93e-be68793b3d2d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d555ba0d-b543-4936-b93e-be68793b3d2d_0">
											<gml:posList>35.670554591108576 139.7428783736604 25.585 35.67055436536719 139.74287784369346 25.585 35.67055436536719 139.74287784369346 28.11 35.670554591108576 139.7428783736604 28.11 35.670554591108576 139.7428783736604 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d20c6d4d-3e3f-4c63-8bb0-424c6f4be540">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d20c6d4d-3e3f-4c63-8bb0-424c6f4be540_0">
											<gml:posList>35.670544666626085 139.7428778877744 25.585 35.670544441681315 139.74287841824972 25.585 35.670544441681315 139.74287841824972 28.11 35.670544666626085 139.7428778877744 28.11 35.670544666626085 139.7428778877744 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e4e91ad-4333-4822-9eb8-4dcdf62cc386">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3e4e91ad-4333-4822-9eb8-4dcdf62cc386_0">
											<gml:posList>35.67055478081166 139.74287892576058 25.585 35.670554591108576 139.7428783736604 25.585 35.670554591108576 139.7428783736604 28.11 35.67055478081166 139.74287892576058 28.11 35.67055478081166 139.74287892576058 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-724e9e17-6297-4740-964e-c477873ebbfe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-724e9e17-6297-4740-964e-c477873ebbfe_0">
											<gml:posList>35.670544441681315 139.74287841824972 25.585 35.67054425281633 139.7428789818232 25.585 35.67054425281633 139.7428789818232 28.11 35.670544441681315 139.74287841824972 28.11 35.670544441681315 139.74287841824972 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7538a04-be47-40ff-9187-668b2e92189f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c7538a04-be47-40ff-9187-668b2e92189f_0">
											<gml:posList>35.67055493446814 139.7428794889477 25.585 35.67055478081166 139.74287892576058 25.585 35.67055478081166 139.74287892576058 28.11 35.67055493446814 139.7428794889477 28.11 35.67055493446814 139.7428794889477 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f0eb3cd-edf8-4e03-90fb-c0b176666631">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2f0eb3cd-edf8-4e03-90fb-c0b176666631_0">
											<gml:posList>35.67054425281633 139.7428789818232 25.585 35.67054410901995 139.74287954534583 25.585 35.67054410901995 139.74287954534583 28.11 35.67054425281633 139.7428789818232 28.11 35.67054425281633 139.7428789818232 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e259b021-92a5-42c7-a43f-a8e1c92300f2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e259b021-92a5-42c7-a43f-a8e1c92300f2_0">
											<gml:posList>35.6705550430726 139.74288007427822 25.585 35.67055493446814 139.7428794889477 25.585 35.67055493446814 139.7428794889477 28.11 35.6705550430726 139.74288007427822 28.11 35.6705550430726 139.74288007427822 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-96a369df-5c48-4295-8d05-35945b38e10c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-96a369df-5c48-4295-8d05-35945b38e10c_0">
											<gml:posList>35.67054410901995 139.74287954534583 25.585 35.67054401030878 139.74288013091015 25.585 35.67054401030878 139.74288013091015 28.11 35.67054410901995 139.74287954534583 28.11 35.67054410901995 139.74287954534583 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7693bc45-eac4-4484-a2fc-478ce21e2619">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7693bc45-eac4-4484-a2fc-478ce21e2619_0">
											<gml:posList>35.67055510661675 139.74288067070583 25.585 35.6705550430726 139.74288007427822 25.585 35.6705550430726 139.74288007427822 28.11 35.67055510661675 139.74288067070583 28.11 35.67055510661675 139.74288067070583 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d84124c-6342-43bb-86c2-2342f83b9a60">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d84124c-6342-43bb-86c2-2342f83b9a60_0">
											<gml:posList>35.67054401030878 139.74288013091015 25.585 35.67054394766081 139.74288072748007 25.585 35.67054394766081 139.74288072748007 28.11 35.67054401030878 139.74288013091015 28.11 35.67054401030878 139.74288013091015 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3669a7bd-1e79-4b8a-864d-e943533797f5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3669a7bd-1e79-4b8a-864d-e943533797f5_0">
											<gml:posList>35.670555125092285 139.74288126718432 25.585 35.67055510661675 139.74288067070583 25.585 35.67055510661675 139.74288067070583 28.11 35.670555125092285 139.74288126718432 28.11 35.670555125092285 139.74288126718432 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0f8224e-bdea-45db-8294-922d7448e6a4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d0f8224e-bdea-45db-8294-922d7448e6a4_0">
											<gml:posList>35.67054394766081 139.74288072748007 25.585 35.67054393008144 139.74288132399914 25.585 35.67054393008144 139.74288132399914 28.11 35.67054394766081 139.74288072748007 28.11 35.67054394766081 139.74288072748007 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37f26dd7-09cb-4cf5-b1a5-d822ad3a6840">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-37f26dd7-09cb-4cf5-b1a5-d822ad3a6840_0">
											<gml:posList>35.67055314603113 139.74288653849425 28.11 35.67055350627305 139.74288612937536 28.11 35.670553830435196 139.74288568715835 28.11 35.67055412753126 139.74288521183297 28.11 35.67055438854756 139.7428847034095 28.11 35.67055461349235 139.7428841729341 28.11 35.67055480236566 139.74288362040684 28.11 35.67055494615375 139.74288304583789 28.11 35.670555044864926 139.74288246027348 28.11 35.67055510751292 139.74288186370347 28.11 35.670555125092285 139.74288126718432 28.11 35.67055510661675 139.74288067070583 28.11 35.6705550430726 139.74288007427822 28.11 35.67055493446814 139.7428794889477 28.11 35.67055478081166 139.74287892576058 28.11 35.670554591108576 139.7428783736604 28.11 35.67055436536719 139.74287784369346 28.11 35.670554103587506 139.74287733585976 28.11 35.67055380577783 139.74287686120553 28.11 35.670553471938156 139.74287641973086 28.11 35.67055311109049 139.74287602247173 28.11 35.67055272322656 139.742875658382 28.11 35.670552308354644 139.74287533850784 28.11 35.670551875488485 139.74287506283915 28.11 35.67055142463637 139.74287484242214 28.11 35.67055095578169 139.7428746551643 28.11 35.67055047796308 139.74287453419427 28.11 35.67054999116395 139.7428744574195 28.11 35.67054950440632 139.74287443587613 28.11 35.670549017681864 139.74287445851786 28.11 35.67054853099891 139.74287453639093 28.11 35.67054805337118 139.7428746694852 28.11 35.67054759381236 139.7428748577905 28.11 35.670547143300475 139.7428750902707 28.11 35.67054671084923 139.74287536691568 28.11 35.670546296458625 139.7428756877254 28.11 35.67054590914237 139.74287605268972 28.11 35.67054554890048 139.74287646180858 28.11 35.670545224738376 139.7428769040256 28.11 35.67054492764234 139.74287737935092 28.11 35.670544666626085 139.7428778877744 28.11 35.670544441681315 139.74287841824972 28.11 35.67054425281633 139.7428789818232 28.11 35.67054410901995 139.74287954534583 28.11 35.67054401030878 139.74288013091015 28.11 35.67054394766081 139.74288072748007 28.11 35.67054393008144 139.74288132399914 28.11 35.670543948556976 139.74288192047754 28.11 35.67054402111483 139.74288251689492 28.11 35.67054412070556 139.74288310223554 28.11 35.67054427437032 139.74288367646886 28.11 35.67054446407338 139.74288422856898 28.11 35.67054468980644 139.7428847474896 28.11 35.67054495158609 139.74288525532327 28.11 35.67054524939574 139.74288572997744 28.11 35.67054558323539 139.74288617145214 28.11 35.670545944091295 139.7428865797575 28.11 35.67054633194691 139.742886932801 28.11 35.67054674681879 139.7428872526752 28.11 35.670547179684924 139.74288752834397 28.11 35.67054763054532 139.7428877598073 28.11 35.670548099391674 139.74288793601892 28.11 35.670548577210255 139.74288805698902 28.11 35.67054906400939 139.74288813376387 28.11 35.67054955077533 139.74288816635362 28.11 35.67055003749147 139.7428881326657 28.11 35.670550524174445 139.74288805479273 28.11 35.6705510018022 139.74288792169853 28.11 35.67055146136102 139.7428877333933 28.11 35.670551911872934 139.74288750091313 28.11 35.67055235333794 139.74288722425803 28.11 35.670552758714855 139.74288690345853 28.11 35.67055314603113 139.74288653849425 28.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e4e4cf5-8173-4c94-b8ae-f69dcf055462">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3e4e4cf5-8173-4c94-b8ae-f69dcf055462_0">
											<gml:posList>35.67055510751292 139.74288186370347 25.585 35.670555125092285 139.74288126718432 25.585 35.670555125092285 139.74288126718432 28.11 35.67055510751292 139.74288186370347 28.11 35.67055510751292 139.74288186370347 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb00110c-52db-4ee1-b6c5-9d0d50bee1ec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb00110c-52db-4ee1-b6c5-9d0d50bee1ec_0">
											<gml:posList>35.67054393008144 139.74288132399914 25.585 35.670543948556976 139.74288192047754 25.585 35.670543948556976 139.74288192047754 28.11 35.67054393008144 139.74288132399914 28.11 35.67054393008144 139.74288132399914 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a27fc0c6-abd8-4958-a63a-9c88b16e4e76">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a27fc0c6-abd8-4958-a63a-9c88b16e4e76_0">
											<gml:posList>35.670555044864926 139.74288246027348 25.585 35.67055510751292 139.74288186370347 25.585 35.67055510751292 139.74288186370347 28.11 35.670555044864926 139.74288246027348 28.11 35.670555044864926 139.74288246027348 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d5795c0-2bf1-4873-9d78-961f22b0c307">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6d5795c0-2bf1-4873-9d78-961f22b0c307_0">
											<gml:posList>35.670543948556976 139.74288192047754 25.585 35.67054402111483 139.74288251689492 25.585 35.67054402111483 139.74288251689492 28.11 35.670543948556976 139.74288192047754 28.11 35.670543948556976 139.74288192047754 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4c1c055-f35e-4a47-97bc-fcff430358b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b4c1c055-f35e-4a47-97bc-fcff430358b8_0">
											<gml:posList>35.67055494615375 139.74288304583789 25.585 35.670555044864926 139.74288246027348 25.585 35.670555044864926 139.74288246027348 28.11 35.67055494615375 139.74288304583789 28.11 35.67055494615375 139.74288304583789 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-88e91064-0b4e-480b-84b5-ac97c0021cb8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-88e91064-0b4e-480b-84b5-ac97c0021cb8_0">
											<gml:posList>35.67054402111483 139.74288251689492 25.585 35.67054412070556 139.74288310223554 25.585 35.67054412070556 139.74288310223554 28.11 35.67054402111483 139.74288251689492 28.11 35.67054402111483 139.74288251689492 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cba1cc24-9e13-4214-b53f-e391db68c7f3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cba1cc24-9e13-4214-b53f-e391db68c7f3_0">
											<gml:posList>35.67055480236566 139.74288362040684 25.585 35.67055494615375 139.74288304583789 25.585 35.67055494615375 139.74288304583789 28.11 35.67055480236566 139.74288362040684 28.11 35.67055480236566 139.74288362040684 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ef45fa1-d355-4925-b78a-2c5019f0649f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7ef45fa1-d355-4925-b78a-2c5019f0649f_0">
											<gml:posList>35.67054412070556 139.74288310223554 25.585 35.67054427437032 139.74288367646886 25.585 35.67054427437032 139.74288367646886 28.11 35.67054412070556 139.74288310223554 28.11 35.67054412070556 139.74288310223554 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-feaddee0-91c8-4a28-9c11-e8d57688fb5f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-feaddee0-91c8-4a28-9c11-e8d57688fb5f_0">
											<gml:posList>35.67055461349235 139.7428841729341 25.585 35.67055480236566 139.74288362040684 25.585 35.67055480236566 139.74288362040684 28.11 35.67055461349235 139.7428841729341 28.11 35.67055461349235 139.7428841729341 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc1ece5e-d724-489a-84b3-32e9d8483912">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cc1ece5e-d724-489a-84b3-32e9d8483912_0">
											<gml:posList>35.67054427437032 139.74288367646886 25.585 35.67054446407338 139.74288422856898 25.585 35.67054446407338 139.74288422856898 28.11 35.67054427437032 139.74288367646886 28.11 35.67054427437032 139.74288367646886 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a3b3cdb-f330-42ae-866b-213ebfa61a5b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5a3b3cdb-f330-42ae-866b-213ebfa61a5b_0">
											<gml:posList>35.67055438854756 139.7428847034095 25.585 35.67055461349235 139.7428841729341 25.585 35.67055461349235 139.7428841729341 28.11 35.67055438854756 139.7428847034095 28.11 35.67055438854756 139.7428847034095 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f34a47b0-2464-481b-9cc0-032b271f3451">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f34a47b0-2464-481b-9cc0-032b271f3451_0">
											<gml:posList>35.67054446407338 139.74288422856898 25.585 35.67054468980644 139.7428847474896 25.585 35.67054468980644 139.7428847474896 28.11 35.67054446407338 139.74288422856898 28.11 35.67054446407338 139.74288422856898 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0fce4f9d-a9b5-401f-a96e-f3a0e291b4b5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0fce4f9d-a9b5-401f-a96e-f3a0e291b4b5_0">
											<gml:posList>35.67055412753126 139.74288521183297 25.585 35.67055438854756 139.7428847034095 25.585 35.67055438854756 139.7428847034095 28.11 35.67055412753126 139.74288521183297 28.11 35.67055412753126 139.74288521183297 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78b69e38-4371-4fac-9117-a8a60d241fe4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78b69e38-4371-4fac-9117-a8a60d241fe4_0">
											<gml:posList>35.67054468980644 139.7428847474896 25.585 35.67054495158609 139.74288525532327 25.585 35.67054495158609 139.74288525532327 28.11 35.67054468980644 139.7428847474896 28.11 35.67054468980644 139.7428847474896 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c2dd4704-a8d1-4c94-adae-cbae652fa978">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c2dd4704-a8d1-4c94-adae-cbae652fa978_0">
											<gml:posList>35.670553830435196 139.74288568715835 25.585 35.67055412753126 139.74288521183297 25.585 35.67055412753126 139.74288521183297 28.11 35.670553830435196 139.74288568715835 28.11 35.670553830435196 139.74288568715835 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99d829a2-5267-4338-9bc4-4f9f902f4a5a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-99d829a2-5267-4338-9bc4-4f9f902f4a5a_0">
											<gml:posList>35.67054495158609 139.74288525532327 25.585 35.67054524939574 139.74288572997744 25.585 35.67054524939574 139.74288572997744 28.11 35.67054495158609 139.74288525532327 28.11 35.67054495158609 139.74288525532327 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73fc4448-fbf0-4d9e-ba08-8e72e3c7c16d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73fc4448-fbf0-4d9e-ba08-8e72e3c7c16d_0">
											<gml:posList>35.67055350627305 139.74288612937536 25.585 35.670553830435196 139.74288568715835 25.585 35.670553830435196 139.74288568715835 28.11 35.67055350627305 139.74288612937536 28.11 35.67055350627305 139.74288612937536 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe6f88ae-5358-4bb3-be2c-ddd42168c523">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe6f88ae-5358-4bb3-be2c-ddd42168c523_0">
											<gml:posList>35.67054524939574 139.74288572997744 25.585 35.67054558323539 139.74288617145214 25.585 35.67054558323539 139.74288617145214 28.11 35.67054524939574 139.74288572997744 28.11 35.67054524939574 139.74288572997744 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a6f9a9a5-226c-4a0b-8a91-20eac8d9dfbd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a6f9a9a5-226c-4a0b-8a91-20eac8d9dfbd_0">
											<gml:posList>35.67055314603113 139.74288653849425 25.585 35.67055350627305 139.74288612937536 25.585 35.67055350627305 139.74288612937536 28.11 35.67055314603113 139.74288653849425 28.11 35.67055314603113 139.74288653849425 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d3978f28-a21b-4d49-9e47-54368b154091">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d3978f28-a21b-4d49-9e47-54368b154091_0">
											<gml:posList>35.67054558323539 139.74288617145214 25.585 35.670545944091295 139.7428865797575 25.585 35.670545944091295 139.7428865797575 28.11 35.67054558323539 139.74288617145214 28.11 35.67054558323539 139.74288617145214 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-778a6e56-7931-4acc-854d-405b5300d239">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-778a6e56-7931-4acc-854d-405b5300d239_0">
											<gml:posList>35.670552758714855 139.74288690345853 25.585 35.67055314603113 139.74288653849425 25.585 35.67055314603113 139.74288653849425 28.11 35.670552758714855 139.74288690345853 28.11 35.670552758714855 139.74288690345853 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c3ba755-3538-413b-a425-3d4e0faf93b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c3ba755-3538-413b-a425-3d4e0faf93b4_0">
											<gml:posList>35.670545944091295 139.7428865797575 25.585 35.67054633194691 139.742886932801 25.585 35.67054633194691 139.742886932801 28.11 35.670545944091295 139.7428865797575 28.11 35.670545944091295 139.7428865797575 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3b06f18-037f-412e-a14c-9c79c19c3b96">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3b06f18-037f-412e-a14c-9c79c19c3b96_0">
											<gml:posList>35.670552758714855 139.74288690345853 25.585 35.670552758714855 139.74288690345853 28.11 35.67055235333794 139.74288722425803 28.11 35.67055235333794 139.74288722425803 25.585 35.670552758714855 139.74288690345853 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3202b799-39f1-40e3-8f5b-4351ab6b6d22">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3202b799-39f1-40e3-8f5b-4351ab6b6d22_0">
											<gml:posList>35.67054674681879 139.7428872526752 25.585 35.67054674681879 139.7428872526752 28.11 35.67054633194691 139.742886932801 28.11 35.67054633194691 139.742886932801 25.585 35.67054674681879 139.7428872526752 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2db94f11-1ce3-43a0-ba47-4a9f344010aa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2db94f11-1ce3-43a0-ba47-4a9f344010aa_0">
											<gml:posList>35.67055235333794 139.74288722425803 25.585 35.67055235333794 139.74288722425803 28.11 35.670551911872934 139.74288750091313 28.11 35.670551911872934 139.74288750091313 25.585 35.67055235333794 139.74288722425803 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c4a200e-69cb-4199-a532-b47181de1ef3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c4a200e-69cb-4199-a532-b47181de1ef3_0">
											<gml:posList>35.67054674681879 139.7428872526752 25.585 35.670547179684924 139.74288752834397 25.585 35.670547179684924 139.74288752834397 28.11 35.67054674681879 139.7428872526752 28.11 35.67054674681879 139.7428872526752 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0456b34b-2042-4e77-bc00-77bda58696c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0456b34b-2042-4e77-bc00-77bda58696c9_0">
											<gml:posList>35.67055146136102 139.7428877333933 25.585 35.670551911872934 139.74288750091313 25.585 35.670551911872934 139.74288750091313 28.11 35.67055146136102 139.7428877333933 28.11 35.67055146136102 139.7428877333933 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4dca8232-504b-4eb6-9615-28267485802d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4dca8232-504b-4eb6-9615-28267485802d_0">
											<gml:posList>35.670547179684924 139.74288752834397 25.585 35.67054763054532 139.7428877598073 25.585 35.67054763054532 139.7428877598073 28.11 35.670547179684924 139.74288752834397 28.11 35.670547179684924 139.74288752834397 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4df7b386-a2d5-4efa-a6a5-8bc24fef7868">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4df7b386-a2d5-4efa-a6a5-8bc24fef7868_0">
											<gml:posList>35.6705510018022 139.74288792169853 25.585 35.67055146136102 139.7428877333933 25.585 35.67055146136102 139.7428877333933 28.11 35.6705510018022 139.74288792169853 28.11 35.6705510018022 139.74288792169853 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27ae4506-6561-4d3d-bb50-cacc943bb314">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-27ae4506-6561-4d3d-bb50-cacc943bb314_0">
											<gml:posList>35.67054763054532 139.7428877598073 25.585 35.670548099391674 139.74288793601892 25.585 35.670548099391674 139.74288793601892 28.11 35.67054763054532 139.7428877598073 28.11 35.67054763054532 139.7428877598073 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-34d79e32-e4ec-4896-9640-8990a83fde87">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-34d79e32-e4ec-4896-9640-8990a83fde87_0">
											<gml:posList>35.670550524174445 139.74288805479273 25.585 35.6705510018022 139.74288792169853 25.585 35.6705510018022 139.74288792169853 28.11 35.670550524174445 139.74288805479273 28.11 35.670550524174445 139.74288805479273 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-95948d77-2c45-441c-9380-ea086ef97ff8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-95948d77-2c45-441c-9380-ea086ef97ff8_0">
											<gml:posList>35.670548099391674 139.74288793601892 25.585 35.670548577210255 139.74288805698902 25.585 35.670548577210255 139.74288805698902 28.11 35.670548099391674 139.74288793601892 28.11 35.670548099391674 139.74288793601892 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d85855ce-273f-4be2-82e3-7009b30bd101">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d85855ce-273f-4be2-82e3-7009b30bd101_0">
											<gml:posList>35.67054906400939 139.74288813376387 25.585 35.67054906400939 139.74288813376387 28.11 35.670548577210255 139.74288805698902 28.11 35.670548577210255 139.74288805698902 25.585 35.67054906400939 139.74288813376387 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dfa59bf9-0a7a-4444-81e1-e2f2d1c6ce90">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dfa59bf9-0a7a-4444-81e1-e2f2d1c6ce90_0">
											<gml:posList>35.67055003749147 139.7428881326657 25.585 35.670550524174445 139.74288805479273 25.585 35.670550524174445 139.74288805479273 28.11 35.67055003749147 139.7428881326657 28.11 35.67055003749147 139.7428881326657 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cdacc45c-6c56-4d2d-920e-f33183793cc0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cdacc45c-6c56-4d2d-920e-f33183793cc0_0">
											<gml:posList>35.67054955077533 139.74288816635362 25.585 35.67054955077533 139.74288816635362 28.11 35.67054906400939 139.74288813376387 28.11 35.67054906400939 139.74288813376387 25.585 35.67054955077533 139.74288816635362 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f75ed441-5501-47f0-9423-407e15051a50">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f75ed441-5501-47f0-9423-407e15051a50_0">
											<gml:posList>35.67054955077533 139.74288816635362 25.585 35.67055003749147 139.7428881326657 25.585 35.67055003749147 139.7428881326657 28.11 35.67054955077533 139.74288816635362 28.11 35.67054955077533 139.74288816635362 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa890f5c-3419-4c35-96d2-b1ace5bd560e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fa890f5c-3419-4c35-96d2-b1ace5bd560e_0">
											<gml:posList>35.670514672242604 139.74290629950266 21.508 35.670514672242604 139.74290629950266 24.528 35.67051680234777 139.74289811180788 24.528 35.67051680234777 139.74289811180788 22.5 35.6705160473769 139.74290101783066 22.5 35.6705160473769 139.74290101783066 21.508 35.670514672242604 139.74290629950266 21.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c847e8c3-3fb3-42c9-b0d7-275391cb2ce1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c847e8c3-3fb3-42c9-b0d7-275391cb2ce1_0">
											<gml:posList>35.67051680234777 139.74289811180788 24.528 35.67058489398356 139.74292466760437 24.528 35.67058489398356 139.74292466760437 22.5 35.67051680234777 139.74289811180788 22.5 35.67051680234777 139.74289811180788 24.528</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-72e12160-5e5f-456e-8f99-c35fa139eda1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-72e12160-5e5f-456e-8f99-c35fa139eda1_0">
											<gml:posList>35.6705160473769 139.74290101783066 22.5 35.67058413901205 139.74292757362937 22.5 35.67058413901205 139.74292757362937 21.508 35.6705160473769 139.74290101783066 21.508 35.6705160473769 139.74290101783066 22.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-004b6e4d-f404-48eb-811a-c5c86946a0c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-004b6e4d-f404-48eb-811a-c5c86946a0c9_0">
											<gml:posList>35.67051680234777 139.74289811180788 24.528 35.670514672242604 139.74290629950266 24.528 35.670582763876624 139.74293285530544 24.528 35.67058489398356 139.74292466760437 24.528 35.67051680234777 139.74289811180788 24.528</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ddafd14b-2066-4638-b4fd-71632dddf902">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ddafd14b-2066-4638-b4fd-71632dddf902_0">
											<gml:posList>35.670514672242604 139.74290629950266 21.508 35.670582763876624 139.74293285530544 21.508 35.670582763876624 139.74293285530544 24.528 35.670514672242604 139.74290629950266 24.528 35.670514672242604 139.74290629950266 21.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76dcc9db-6f7a-44bb-b9e2-7e0799b073fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-76dcc9db-6f7a-44bb-b9e2-7e0799b073fd_0">
											<gml:posList>35.67058413901205 139.74292757362937 22.5 35.67058489398356 139.74292466760437 22.5 35.67058489398356 139.74292466760437 24.528 35.670582763876624 139.74293285530544 24.528 35.670582763876624 139.74293285530544 21.508 35.67058413901205 139.74292757362937 21.508 35.67058413901205 139.74292757362937 22.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_5d34a513-f00e-4b34-88a5-918636fa938f_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f1c2b92-1d4b-45f3-8206-705f0fc765a5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670542806812605 139.74295794227896 21.508 35.670546205956214 139.74295923086254 21.508 35.67054217976228 139.74297516413944 21.508 35.67052336275059 139.7429680273568 21.508 35.670527299071686 139.74295244766554 21.508 35.670529345775506 139.74295322964429 21.508 35.67053433356561 139.74293347327145 21.508 35.67054770473159 139.7429385394855 21.508 35.670542806812605 139.74295794227896 21.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f463e7d6-680c-4746-b9f7-6e31599ffc1c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f463e7d6-680c-4746-b9f7-6e31599ffc1c_0">
											<gml:posList>35.67052336275059 139.7429680273568 21.508 35.67052336275059 139.7429680273568 24.238 35.670527299071686 139.74295244766554 24.238 35.670527299071686 139.74295244766554 21.508 35.67052336275059 139.7429680273568 21.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d197cfc-42b2-4129-bf6b-bb2a5a131e4a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3d197cfc-42b2-4129-bf6b-bb2a5a131e4a_0">
											<gml:posList>35.670527299071686 139.74295244766554 21.508 35.670527299071686 139.74295244766554 24.238 35.670529345775506 139.74295322964429 24.238 35.670529345775506 139.74295322964429 21.508 35.670527299071686 139.74295244766554 21.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf3a3138-b5ff-454d-96b8-9de12f1541cb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cf3a3138-b5ff-454d-96b8-9de12f1541cb_0">
											<gml:posList>35.670529345775506 139.74295322964429 21.508 35.670529345775506 139.74295322964429 24.238 35.67053433356561 139.74293347327145 24.238 35.67053433356561 139.74293347327145 21.508 35.670529345775506 139.74295322964429 21.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2673600-9b41-44a0-9abf-b62ac7304860">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b2673600-9b41-44a0-9abf-b62ac7304860_0">
											<gml:posList>35.67054217976228 139.74297516413944 21.508 35.67054217976228 139.74297516413944 24.238 35.67052336275059 139.7429680273568 24.238 35.67052336275059 139.7429680273568 21.508 35.67054217976228 139.74297516413944 21.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94f13e75-1c6c-43a3-99dc-1b97d4204dd1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-94f13e75-1c6c-43a3-99dc-1b97d4204dd1_0">
											<gml:posList>35.67053433356561 139.74293347327145 24.238 35.670529345775506 139.74295322964429 24.238 35.670527299071686 139.74295244766554 24.238 35.67052336275059 139.7429680273568 24.238 35.67054217976228 139.74297516413944 24.238 35.670546205956214 139.74295923086254 24.238 35.670542806812605 139.74295794227896 24.238 35.67054770473159 139.7429385394855 24.238 35.67053433356561 139.74293347327145 24.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1fe42ac7-971f-42eb-8c04-4999cb6d286a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1fe42ac7-971f-42eb-8c04-4999cb6d286a_0">
											<gml:posList>35.67053433356561 139.74293347327145 21.508 35.67053433356561 139.74293347327145 24.238 35.67054770473159 139.7429385394855 24.238 35.67054770473159 139.7429385394855 21.508 35.67053433356561 139.74293347327145 21.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24869a4d-cdb8-445e-b09c-026f8e484ff1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-24869a4d-cdb8-445e-b09c-026f8e484ff1_0">
											<gml:posList>35.670546205956214 139.74295923086254 21.508 35.670546205956214 139.74295923086254 24.238 35.67054217976228 139.74297516413944 24.238 35.67054217976228 139.74297516413944 21.508 35.670546205956214 139.74295923086254 21.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01134ec4-13bd-4020-924f-e3cc5aa78239">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01134ec4-13bd-4020-924f-e3cc5aa78239_0">
											<gml:posList>35.670542806812605 139.74295794227896 24.238 35.670546205956214 139.74295923086254 24.238 35.670546205956214 139.74295923086254 21.508 35.670542806812605 139.74295794227896 21.508 35.670542806812605 139.74295794227896 24.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1ffa65e-33ae-4272-bfb7-3ff6e26b2d6e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c1ffa65e-33ae-4272-bfb7-3ff6e26b2d6e_0">
											<gml:posList>35.67054770473159 139.7429385394855 24.238 35.670542806812605 139.74295794227896 24.238 35.670542806812605 139.74295794227896 21.508 35.67054770473159 139.7429385394855 21.508 35.67054770473159 139.7429385394855 24.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-311f34b3-65ef-4df2-8b00-a2ab342307d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-311f34b3-65ef-4df2-8b00-a2ab342307d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-311f34b3-65ef-4df2-8b00-a2ab342307d5">
											<gml:posList>35.670599356477574 139.74290661270484 7.21 35.67055387839447 139.74308174759227 7.21 35.67046795202473 139.7430477113356 7.21 35.67052511361755 139.74282694229973 7.21 35.670599356477574 139.74290661270484 7.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a153776a-6920-401e-867d-a94438313572">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a153776a-6920-401e-867d-a94438313572">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a153776a-6920-401e-867d-a94438313572">
											<gml:posList>35.67046795202473 139.7430477113356 22.5 35.6704710783041 139.74304573053246 22.5 35.67050924001659 139.74289836335583 22.5 35.670507614667585 139.74289453213095 22.5 35.67046795202473 139.7430477113356 22.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-67966bf9-db01-458c-bad0-745e5b4fdd2e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67966bf9-db01-458c-bad0-745e5b4fdd2e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67966bf9-db01-458c-bad0-745e5b4fdd2e">
											<gml:posList>35.67055387839447 139.74308174759227 22.5 35.67055226204848 139.74307789425882 22.5 35.6704710783041 139.74304573053246 22.5 35.67046795202473 139.7430477113356 22.5 35.67055387839447 139.74308174759227 22.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d25db255-045f-4ea1-a89b-e6c04c6bfa7e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d25db255-045f-4ea1-a89b-e6c04c6bfa7e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d25db255-045f-4ea1-a89b-e6c04c6bfa7e">
											<gml:posList>35.670507614667585 139.74289453213095 26.4 35.67051202028744 139.74289174349943 26.4 35.6705268409175 139.74283449600534 26.4 35.67052511361755 139.74282694229973 26.4 35.670507614667585 139.74289453213095 26.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-97a1088b-10af-432b-b904-2c3675f13af7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-97a1088b-10af-432b-b904-2c3675f13af7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-97a1088b-10af-432b-b904-2c3675f13af7">
											<gml:posList>35.670590639813824 139.7429301069456 21.508 35.67050924001659 139.74289836335583 21.508 35.6704710783041 139.74304573053246 21.508 35.67055226204848 139.74307789425882 21.508 35.670590639813824 139.7429301069456 21.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4705f523-ec8f-4b3c-ac97-f8a1449b88cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4705f523-ec8f-4b3c-ac97-f8a1449b88cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4705f523-ec8f-4b3c-ac97-f8a1449b88cc">
											<gml:posList>35.670507614667585 139.74289453213095 22.5 35.67050924001659 139.74289836335583 22.5 35.670590639813824 139.7429301069456 22.5 35.670593766091194 139.74292812613484 22.5 35.670507614667585 139.74289453213095 22.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-920bb01e-600a-4ca2-a020-c91ea5921d31">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-920bb01e-600a-4ca2-a020-c91ea5921d31">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-920bb01e-600a-4ca2-a020-c91ea5921d31">
											<gml:posList>35.670593766091194 139.74292812613484 26.4 35.67059149057737 139.74292272706543 26.4 35.67051202028744 139.74289174349943 26.4 35.670507614667585 139.74289453213095 26.4 35.670593766091194 139.74292812613484 26.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-68d2b3da-ea65-458a-affc-e9d6e76a14d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-68d2b3da-ea65-458a-affc-e9d6e76a14d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-68d2b3da-ea65-458a-affc-e9d6e76a14d1">
											<gml:posList>35.67059532837203 139.7429079869878 25.585 35.6705268409175 139.74283449600534 25.585 35.67051202028744 139.74289174349943 25.585 35.67059149057737 139.74292272706543 25.585 35.67059532837203 139.7429079869878 25.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2898e7bc-9a60-4df0-8a4f-9aa288951d48">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2898e7bc-9a60-4df0-8a4f-9aa288951d48">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2898e7bc-9a60-4df0-8a4f-9aa288951d48">
											<gml:posList>35.670599356477574 139.74290661270484 26.4 35.67052511361755 139.74282694229973 26.4 35.6705268409175 139.74283449600534 26.4 35.67059532837203 139.7429079869878 26.4 35.670599356477574 139.74290661270484 26.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-de8a1725-d95d-48a4-9655-960053ff5892">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de8a1725-d95d-48a4-9655-960053ff5892">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de8a1725-d95d-48a4-9655-960053ff5892">
											<gml:posList>35.670593766091194 139.74292812613484 22.5 35.670590639813824 139.7429301069456 22.5 35.67055226204848 139.74307789425882 22.5 35.67055387839447 139.74308174759227 22.5 35.670593766091194 139.74292812613484 22.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2fbaf69c-49c2-4cbe-9596-8e82e4a56503">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2fbaf69c-49c2-4cbe-9596-8e82e4a56503">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2fbaf69c-49c2-4cbe-9596-8e82e4a56503">
											<gml:posList>35.670599356477574 139.74290661270484 26.4 35.67059532837203 139.7429079869878 26.4 35.67059149057737 139.74292272706543 26.4 35.670593766091194 139.74292812613484 26.4 35.670599356477574 139.74290661270484 26.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-394d8792-c25a-4693-aa51-4223a6c8c24c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-394d8792-c25a-4693-aa51-4223a6c8c24c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-394d8792-c25a-4693-aa51-4223a6c8c24c">
											<gml:posList>35.67059149057737 139.74292272706543 26.4 35.67059149057737 139.74292272706543 25.585 35.67051202028744 139.74289174349943 25.585 35.67051202028744 139.74289174349943 26.4 35.67059149057737 139.74292272706543 26.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-52b80c71-1ffb-4157-ad39-afb1859d75d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-52b80c71-1ffb-4157-ad39-afb1859d75d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-52b80c71-1ffb-4157-ad39-afb1859d75d0">
											<gml:posList>35.6705268409175 139.74283449600534 26.4 35.6705268409175 139.74283449600534 25.585 35.67059532837203 139.7429079869878 25.585 35.67059532837203 139.7429079869878 26.4 35.6705268409175 139.74283449600534 26.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-736df56e-f24d-4879-8bc7-56009ed9d8e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-736df56e-f24d-4879-8bc7-56009ed9d8e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-736df56e-f24d-4879-8bc7-56009ed9d8e8">
											<gml:posList>35.67051202028744 139.74289174349943 26.4 35.67051202028744 139.74289174349943 25.585 35.6705268409175 139.74283449600534 25.585 35.6705268409175 139.74283449600534 26.4 35.67051202028744 139.74289174349943 26.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b046acd6-48a0-400a-8ed0-3194475294cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b046acd6-48a0-400a-8ed0-3194475294cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b046acd6-48a0-400a-8ed0-3194475294cc">
											<gml:posList>35.670599356477574 139.74290661270484 7.21 35.67052511361755 139.74282694229973 7.21 35.67052511361755 139.74282694229973 26.4 35.670599356477574 139.74290661270484 26.4 35.670599356477574 139.74290661270484 7.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c0ba9895-58ae-44d3-9cb2-cad5f34eb380">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0ba9895-58ae-44d3-9cb2-cad5f34eb380">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0ba9895-58ae-44d3-9cb2-cad5f34eb380">
											<gml:posList>35.670593766091194 139.74292812613484 26.4 35.670507614667585 139.74289453213095 26.4 35.670507614667585 139.74289453213095 22.5 35.670593766091194 139.74292812613484 22.5 35.670593766091194 139.74292812613484 26.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3e644997-9762-4704-98df-163bfc1795e5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e644997-9762-4704-98df-163bfc1795e5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e644997-9762-4704-98df-163bfc1795e5">
											<gml:posList>35.67050924001659 139.74289836335583 22.5 35.67050924001659 139.74289836335583 21.508 35.670590639813824 139.7429301069456 21.508 35.670590639813824 139.7429301069456 22.5 35.67050924001659 139.74289836335583 22.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2844a2f8-8569-4ec8-b7af-654a6ce54b16">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2844a2f8-8569-4ec8-b7af-654a6ce54b16">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2844a2f8-8569-4ec8-b7af-654a6ce54b16">
											<gml:posList>35.67059532837203 139.7429079869878 26.4 35.67059532837203 139.7429079869878 25.585 35.67059149057737 139.74292272706543 25.585 35.67059149057737 139.74292272706543 26.4 35.67059532837203 139.7429079869878 26.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e89be035-8112-45a8-914e-1e369ae2a0dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e89be035-8112-45a8-914e-1e369ae2a0dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e89be035-8112-45a8-914e-1e369ae2a0dd">
											<gml:posList>35.67046795202473 139.7430477113356 7.21 35.67046795202473 139.7430477113356 22.5 35.670507614667585 139.74289453213095 22.5 35.670507614667585 139.74289453213095 26.4 35.67052511361755 139.74282694229973 26.4 35.67052511361755 139.74282694229973 7.21 35.67046795202473 139.7430477113356 7.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e49920fe-8458-4f2c-a79e-60cbae29c371">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e49920fe-8458-4f2c-a79e-60cbae29c371">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e49920fe-8458-4f2c-a79e-60cbae29c371">
											<gml:posList>35.6704710783041 139.74304573053246 22.5 35.6704710783041 139.74304573053246 21.508 35.67050924001659 139.74289836335583 21.508 35.67050924001659 139.74289836335583 22.5 35.6704710783041 139.74304573053246 22.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d794bbe5-d820-446d-a328-3ef7cf90dd40">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d794bbe5-d820-446d-a328-3ef7cf90dd40">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d794bbe5-d820-446d-a328-3ef7cf90dd40">
											<gml:posList>35.670599356477574 139.74290661270484 7.21 35.670599356477574 139.74290661270484 26.4 35.670593766091194 139.74292812613484 26.4 35.670593766091194 139.74292812613484 22.5 35.67055387839447 139.74308174759227 22.5 35.67055387839447 139.74308174759227 7.21 35.670599356477574 139.74290661270484 7.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cffab7ef-e153-4db1-9b15-b978fcbb2407">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cffab7ef-e153-4db1-9b15-b978fcbb2407">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cffab7ef-e153-4db1-9b15-b978fcbb2407">
											<gml:posList>35.670590639813824 139.7429301069456 22.5 35.670590639813824 139.7429301069456 21.508 35.67055226204848 139.74307789425882 21.508 35.67055226204848 139.74307789425882 22.5 35.670590639813824 139.7429301069456 22.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0102e398-76f8-4de8-a8aa-417048271b33">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0102e398-76f8-4de8-a8aa-417048271b33">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0102e398-76f8-4de8-a8aa-417048271b33">
											<gml:posList>35.67055226204848 139.74307789425882 22.5 35.67055226204848 139.74307789425882 21.508 35.6704710783041 139.74304573053246 21.508 35.6704710783041 139.74304573053246 22.5 35.67055226204848 139.74307789425882 22.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3db12bc0-9b34-4b0f-b8d6-e26d60a35332">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3db12bc0-9b34-4b0f-b8d6-e26d60a35332">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3db12bc0-9b34-4b0f-b8d6-e26d60a35332">
											<gml:posList>35.67046795202473 139.7430477113356 7.21 35.67055387839447 139.74308174759227 7.21 35.67055387839447 139.74308174759227 22.5 35.67046795202473 139.7430477113356 22.5 35.67046795202473 139.7430477113356 7.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-525</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">140.718</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.31</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>