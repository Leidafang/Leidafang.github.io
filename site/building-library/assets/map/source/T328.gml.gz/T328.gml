<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_5e3ff9f0-c6ed-4aaf-9699-fb1bec99ecf9">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="説明注記">
				<gen:value>料金所</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>8</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13101008002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3003</bldg:class>
			<bldg:measuredHeight uom="m">6</bldg:measuredHeight>
			<bldg:storeysAboveGround>1</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67460690873183 139.74829317237433 0 35.67467923018611 139.74833761447042 0 35.674716841754766 139.7482444495815 0 35.674602135714366 139.74817166217645 0 35.67456317409457 139.74826759010782 0 35.67460690873183 139.74829317237433 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67460690873183 139.74829317237433 19.353 35.67456317409457 139.74826759010782 19.353 35.674602135714366 139.74817166217645 19.353 35.674716841754766 139.7482444495815 19.353 35.67467923018611 139.74833761447042 19.353 35.67460690873183 139.74829317237433 19.353</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67460690873183 139.74829317237433 19.353 35.67467923018611 139.74833761447042 19.353 35.67467923018611 139.74833761447042 25.37 35.67460690873183 139.74829317237433 25.37 35.67460690873183 139.74829317237433 19.353</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67467923018611 139.74833761447042 19.353 35.674716841754766 139.7482444495815 19.353 35.674716841754766 139.7482444495815 25.37 35.67467923018611 139.74833761447042 25.37 35.67467923018611 139.74833761447042 19.353</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674716841754766 139.7482444495815 19.353 35.674602135714366 139.74817166217645 19.353 35.674602135714366 139.74817166217645 25.37 35.674716841754766 139.7482444495815 25.37 35.674716841754766 139.7482444495815 19.353</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674602135714366 139.74817166217645 19.353 35.67456317409457 139.74826759010782 19.353 35.67456317409457 139.74826759010782 25.37 35.674602135714366 139.74817166217645 25.37 35.674602135714366 139.74817166217645 19.353</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67456317409457 139.74826759010782 19.353 35.67460690873183 139.74829317237433 19.353 35.67460690873183 139.74829317237433 25.37 35.67456317409457 139.74826759010782 25.37 35.67456317409457 139.74826759010782 19.353</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67460690873183 139.74829317237433 25.37 35.67467923018611 139.74833761447042 25.37 35.674716841754766 139.7482444495815 25.37 35.674602135714366 139.74817166217645 25.37 35.67456317409457 139.74826759010782 25.37 35.67460690873183 139.74829317237433 25.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-c3ccc692-ccc2-4287-89fe-966f5ed63e6c"/>
							<gml:surfaceMember xlink:href="#poly-40ac59d9-cc6a-4eb9-a164-19cc870a491a"/>
							<gml:surfaceMember xlink:href="#poly-11799cf3-40bf-4ec3-b925-7e89129b96b0"/>
							<gml:surfaceMember xlink:href="#poly-5af71718-e9cd-4ff4-8a18-d29095ee35d3"/>
							<gml:surfaceMember xlink:href="#poly-f15433ed-9e51-4d02-9595-e584aac7cc30"/>
							<gml:surfaceMember xlink:href="#poly-be47e7cf-161c-45fc-84bc-9c4db1b1ad72"/>
							<gml:surfaceMember xlink:href="#poly-f339b042-f6f8-4c3d-95b4-2b17f2972873"/>
							<gml:surfaceMember xlink:href="#poly-f5128e33-105d-4702-9035-57715bdc0bfb"/>
							<gml:surfaceMember xlink:href="#poly-c65cf362-555a-4c13-b427-305901c6e7cd"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-c3ccc692-ccc2-4287-89fe-966f5ed63e6c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3ccc692-ccc2-4287-89fe-966f5ed63e6c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3ccc692-ccc2-4287-89fe-966f5ed63e6c">
											<gml:posList>35.674606908731825 139.74829317237433 19.353 35.67456317409456 139.7482675901078 19.353 35.67460213571436 139.74817166217645 19.353 35.674716841754744 139.7482444495815 19.353 35.67467923018611 139.74833761447042 19.353 35.674606908731825 139.74829317237433 19.353</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-40ac59d9-cc6a-4eb9-a164-19cc870a491a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-40ac59d9-cc6a-4eb9-a164-19cc870a491a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-40ac59d9-cc6a-4eb9-a164-19cc870a491a">
											<gml:posList>35.67460213571436 139.74817166217645 25.2 35.67456317409456 139.7482675901078 25.2 35.674606908731825 139.74829317237433 25.2 35.67467923018611 139.74833761447042 25.2 35.674716841754744 139.7482444495815 25.2 35.67460213571436 139.74817166217645 25.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-11799cf3-40bf-4ec3-b925-7e89129b96b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11799cf3-40bf-4ec3-b925-7e89129b96b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11799cf3-40bf-4ec3-b925-7e89129b96b0">
											<gml:posList>35.674716841754744 139.7482444495815 19.353 35.67460213571436 139.74817166217645 19.353 35.67460213571436 139.74817166217645 25.2 35.674716841754744 139.7482444495815 25.2 35.674716841754744 139.7482444495815 19.353</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5af71718-e9cd-4ff4-8a18-d29095ee35d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5af71718-e9cd-4ff4-8a18-d29095ee35d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5af71718-e9cd-4ff4-8a18-d29095ee35d3">
											<gml:posList>35.67460213571436 139.74817166217645 19.353 35.67456317409456 139.7482675901078 19.353 35.67456317409456 139.7482675901078 25.2 35.67460213571436 139.74817166217645 25.2 35.67460213571436 139.74817166217645 19.353</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f15433ed-9e51-4d02-9595-e584aac7cc30">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f15433ed-9e51-4d02-9595-e584aac7cc30">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f15433ed-9e51-4d02-9595-e584aac7cc30">
											<gml:posList>35.674606908731825 139.74829317237433 19.353 35.674606908731825 139.74829317237433 25.2 35.67456317409456 139.7482675901078 19.353 35.674606908731825 139.74829317237433 19.353</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-be47e7cf-161c-45fc-84bc-9c4db1b1ad72">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-be47e7cf-161c-45fc-84bc-9c4db1b1ad72">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-be47e7cf-161c-45fc-84bc-9c4db1b1ad72">
											<gml:posList>35.674606908731825 139.74829317237433 25.2 35.67456317409456 139.7482675901078 25.2 35.67456317409456 139.7482675901078 19.353 35.674606908731825 139.74829317237433 25.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f339b042-f6f8-4c3d-95b4-2b17f2972873">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f339b042-f6f8-4c3d-95b4-2b17f2972873">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f339b042-f6f8-4c3d-95b4-2b17f2972873">
											<gml:posList>35.67467923018611 139.74833761447042 19.353 35.674716841754744 139.7482444495815 19.353 35.674716841754744 139.7482444495815 25.2 35.67467923018611 139.74833761447042 25.2 35.67467923018611 139.74833761447042 19.353</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f5128e33-105d-4702-9035-57715bdc0bfb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f5128e33-105d-4702-9035-57715bdc0bfb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f5128e33-105d-4702-9035-57715bdc0bfb">
											<gml:posList>35.674606908731825 139.74829317237433 19.353 35.67467923018611 139.74833761447042 25.2 35.674606908731825 139.74829317237433 25.2 35.674606908731825 139.74829317237433 19.353</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c65cf362-555a-4c13-b427-305901c6e7cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c65cf362-555a-4c13-b427-305901c6e7cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c65cf362-555a-4c13-b427-305901c6e7cd">
											<gml:posList>35.674606908731825 139.74829317237433 19.353 35.67467923018611 139.74833761447042 19.353 35.67467923018611 139.74833761447042 25.2 35.674606908731825 139.74829317237433 19.353</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都千代田区霞が関二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4604</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">136.5428</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">215</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>