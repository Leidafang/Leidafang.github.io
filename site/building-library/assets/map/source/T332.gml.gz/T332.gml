<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_5fff859b-e3f9-4a50-b44d-91204415daf6">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">23.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67090557572763 139.73832406109955 0 35.67092616639792 139.73831683448935 0 35.67090672081488 139.7382217375715 0 35.67082696857373 139.73824613408593 0 35.67085420508855 139.7383794309211 0 35.670913194665296 139.73836130030475 0 35.67090557572763 139.73832406109955 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67090557572763 139.73832406109955 17.729 35.670913194665296 139.73836130030475 17.729 35.67085420508855 139.7383794309211 17.729 35.67082696857373 139.73824613408593 17.729 35.67090672081488 139.7382217375715 17.729 35.67092616639792 139.73831683448935 17.729 35.67090557572763 139.73832406109955 17.729</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67090557572763 139.73832406109955 17.729 35.67092616639792 139.73831683448935 17.729 35.67092616639792 139.73831683448935 41.5 35.67090557572763 139.73832406109955 41.5 35.67090557572763 139.73832406109955 17.729</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67092616639792 139.73831683448935 17.729 35.67090672081488 139.7382217375715 17.729 35.67090672081488 139.7382217375715 41.5 35.67092616639792 139.73831683448935 41.5 35.67092616639792 139.73831683448935 17.729</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67090672081488 139.7382217375715 17.729 35.67082696857373 139.73824613408593 17.729 35.67082696857373 139.73824613408593 41.5 35.67090672081488 139.7382217375715 41.5 35.67090672081488 139.7382217375715 17.729</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67082696857373 139.73824613408593 17.729 35.67085420508855 139.7383794309211 17.729 35.67085420508855 139.7383794309211 41.5 35.67082696857373 139.73824613408593 41.5 35.67082696857373 139.73824613408593 17.729</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67085420508855 139.7383794309211 17.729 35.670913194665296 139.73836130030475 17.729 35.670913194665296 139.73836130030475 41.5 35.67085420508855 139.7383794309211 41.5 35.67085420508855 139.7383794309211 17.729</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670913194665296 139.73836130030475 17.729 35.67090557572763 139.73832406109955 17.729 35.67090557572763 139.73832406109955 41.5 35.670913194665296 139.73836130030475 41.5 35.670913194665296 139.73836130030475 17.729</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67090557572763 139.73832406109955 41.5 35.67092616639792 139.73831683448935 41.5 35.67090672081488 139.7382217375715 41.5 35.67082696857373 139.73824613408593 41.5 35.67085420508855 139.7383794309211 41.5 35.670913194665296 139.73836130030475 41.5 35.67090557572763 139.73832406109955 41.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-96be0951-6333-4ac5-b9d1-07a669a6251f"/>
							<gml:surfaceMember xlink:href="#poly-bdcc8e08-838a-4265-9727-0aa4e9e21229"/>
							<gml:surfaceMember xlink:href="#poly-e2625d1a-1e75-4845-868a-95e838a8a67e"/>
							<gml:surfaceMember xlink:href="#poly-bf28caa0-9a5a-4233-89ba-06c7ff5ddf91"/>
							<gml:surfaceMember xlink:href="#poly-d2f04e1c-eceb-4b11-a5c5-a707b6d5c9e9"/>
							<gml:surfaceMember xlink:href="#poly-e6d00136-3c9e-48d1-a454-fadf94733d40"/>
							<gml:surfaceMember xlink:href="#poly-cbb0fdb1-3ab4-4c50-ba45-29e21e27d1e9"/>
							<gml:surfaceMember xlink:href="#poly-e6c509d2-f5a9-4c4d-9235-4778e2d640e6"/>
							<gml:surfaceMember xlink:href="#poly-abd0a499-85f0-4d17-af86-1156de5bd117"/>
							<gml:surfaceMember xlink:href="#poly-c43529cf-c2f2-4af1-81b2-5d1635824669"/>
							<gml:surfaceMember xlink:href="#poly-935d93ed-9043-442d-b602-c6232d1b355f"/>
							<gml:surfaceMember xlink:href="#poly-c681c0ac-75a0-4938-b528-759a8b1f1b58"/>
							<gml:surfaceMember xlink:href="#poly-daf77441-f3eb-4ff0-8be5-f7c9ee441759"/>
							<gml:surfaceMember xlink:href="#poly-906b9258-19df-460e-8921-5086646dbd91"/>
							<gml:surfaceMember xlink:href="#poly-54667f71-895a-4509-9be0-f9673aa26ee9"/>
							<gml:surfaceMember xlink:href="#poly-29688b80-f380-4747-9a32-7736578191d6"/>
							<gml:surfaceMember xlink:href="#poly-d300d195-d922-4a11-b751-186431f5f178"/>
							<gml:surfaceMember xlink:href="#poly-e05ddc92-2f21-4b41-a5a4-be96498106cf"/>
							<gml:surfaceMember xlink:href="#poly-3b42c346-2404-4622-9038-24f66d500fdc"/>
							<gml:surfaceMember xlink:href="#poly-5bd194f2-233f-4711-b66b-ebfaecbb4973"/>
							<gml:surfaceMember xlink:href="#poly-af339a34-e9ce-4e94-bf4d-d20bdd1200ef"/>
							<gml:surfaceMember xlink:href="#poly-f3cc74e7-39c0-4378-9382-2b7659234797"/>
							<gml:surfaceMember xlink:href="#poly-48d52030-e98d-4b16-a3b3-d83a9d2c9a3f"/>
							<gml:surfaceMember xlink:href="#poly-246c938a-8175-4fb3-a37d-613353ec2bf4"/>
							<gml:surfaceMember xlink:href="#poly-54fb1d6f-bd29-4c8f-bf20-8d559e50cac4"/>
							<gml:surfaceMember xlink:href="#poly-8706620d-9b69-4529-8e87-f993baecd90a"/>
							<gml:surfaceMember xlink:href="#poly-a26753f4-975c-462d-bc08-4b7b3e556cf4"/>
							<gml:surfaceMember xlink:href="#poly-cc48e88f-eab9-415c-b51c-e5435e1b0b28"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_5fff859b-e3f9-4a50-b44d-91204415daf6_BuildingInstallation_1061">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d2b59643-3d84-4f16-8c1b-569a94a2a321">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d2b59643-3d84-4f16-8c1b-569a94a2a321_0">
											<gml:posList>35.670846667122696 139.7382506286702 41.623 35.67089558172121 139.73823552555942 43.752 35.67089558172121 139.73823552555942 41.623 35.670846667122696 139.7382506286702 41.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16ae543c-f904-4214-ae46-a9427d06732e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16ae543c-f904-4214-ae46-a9427d06732e_0">
											<gml:posList>35.670846667122696 139.7382506286702 41.623 35.670846667122696 139.7382506286702 43.752 35.67089558172121 139.73823552555942 43.752 35.670846667122696 139.7382506286702 41.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ef12e58-ee92-49be-86ae-94aaac345b1a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2ef12e58-ee92-49be-86ae-94aaac345b1a_0">
											<gml:posList>35.67089417784889 139.73823839927036 43.752 35.67084901205098 139.73825234911578 41.722 35.67089417784889 139.73823839927036 41.722 35.67089417784889 139.73823839927036 43.752</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b0d4a39d-e9e0-4bbe-b85c-d9ff42e2e2b9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b0d4a39d-e9e0-4bbe-b85c-d9ff42e2e2b9_0">
											<gml:posList>35.67089417784889 139.73823839927036 43.752 35.67084901205098 139.73825234911578 43.752 35.67084901205098 139.73825234911578 41.722 35.67089417784889 139.73823839927036 43.752</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d79d1b5e-3497-4701-9592-0b4ca33d5450">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d79d1b5e-3497-4701-9592-0b4ca33d5450_0">
											<gml:posList>35.67089558172121 139.73823552555942 43.752 35.670911841816505 139.73831459801357 41.623 35.67089558172121 139.73823552555942 41.623 35.67089558172121 139.73823552555942 43.752</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6538c2f2-0249-4996-b3ce-9a827269b088">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6538c2f2-0249-4996-b3ce-9a827269b088_0">
											<gml:posList>35.67089558172121 139.73823552555942 43.752 35.670911841816505 139.73831459801357 43.752 35.670911841816505 139.73831459801357 41.623 35.67089558172121 139.73823552555942 43.752</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29fff899-e604-46fd-ae4c-cef8f00ff352">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29fff899-e604-46fd-ae4c-cef8f00ff352_0">
											<gml:posList>35.67090948787541 139.73831287757548 43.752 35.67089417784889 139.73823839927036 41.722 35.67090948787541 139.73831287757548 41.722 35.67090948787541 139.73831287757548 43.752</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d9a5e1e2-576e-4fcd-89a4-257754263bea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d9a5e1e2-576e-4fcd-89a4-257754263bea_0">
											<gml:posList>35.67090948787541 139.73831287757548 43.752 35.67089417784889 139.73823839927036 43.752 35.67089417784889 139.73823839927036 41.722 35.67090948787541 139.73831287757548 43.752</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da3bdb81-73d1-4534-b18a-996db304dbd4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da3bdb81-73d1-4534-b18a-996db304dbd4_0">
											<gml:posList>35.67090948787541 139.73831287757548 41.722 35.67089417784889 139.73823839927036 41.722 35.67089474500984 139.73831743508964 41.722 35.67090948787541 139.73831287757548 41.722</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-67e2f30e-4aaa-43c3-ad23-721639e50628">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-67e2f30e-4aaa-43c3-ad23-721639e50628_0">
											<gml:posList>35.67090141372722 139.7383498813072 41.722 35.67089474500984 139.73831743508964 41.722 35.67087099078379 139.73835927358766 41.722 35.67090141372722 139.7383498813072 41.722</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b61cd235-8a59-4126-b620-c6893b659a4a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b61cd235-8a59-4126-b620-c6893b659a4a_0">
											<gml:posList>35.67087099078379 139.73835927358766 41.722 35.67089474500984 139.73831743508964 41.722 35.67084901205098 139.73825234911578 41.722 35.67087099078379 139.73835927358766 41.722</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0dc2ec7-f396-40c2-a6d4-d3e1819e9dcc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0dc2ec7-f396-40c2-a6d4-d3e1819e9dcc_0">
											<gml:posList>35.67089474500984 139.73831743508964 41.722 35.67089417784889 139.73823839927036 41.722 35.67084901205098 139.73825234911578 41.722 35.67089474500984 139.73831743508964 41.722</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73b9c467-32f5-4d77-ab2d-c219980e7d0e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73b9c467-32f5-4d77-ab2d-c219980e7d0e_0">
											<gml:posList>35.67089417784889 139.73823839927036 43.752 35.67089558172121 139.73823552555942 43.752 35.670846667122696 139.7382506286702 43.752 35.67089417784889 139.73823839927036 43.752</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-286e9d3f-0166-4d14-b07e-19dac9ff8494">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-286e9d3f-0166-4d14-b07e-19dac9ff8494_0">
											<gml:posList>35.670846667122696 139.7382506286702 43.752 35.67086958691722 139.7383621583419 43.752 35.67087099078379 139.73835927358766 43.752 35.670846667122696 139.7382506286702 43.752</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7d021499-a50a-440c-8dfc-541acf4af8f9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7d021499-a50a-440c-8dfc-541acf4af8f9_0">
											<gml:posList>35.67089558172121 139.73823552555942 43.752 35.67090948787541 139.73831287757548 43.752 35.670911841816505 139.73831459801357 43.752 35.67089558172121 139.73823552555942 43.752</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f71b6529-88ac-486c-8721-ed7774405ec5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f71b6529-88ac-486c-8721-ed7774405ec5_0">
											<gml:posList>35.67086958691722 139.7383621583419 43.752 35.67090375865407 139.73835160175688 43.752 35.67087099078379 139.73835927358766 43.752 35.67086958691722 139.7383621583419 43.752</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e093a840-9e20-4d23-bab2-eb7a94029ad3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e093a840-9e20-4d23-bab2-eb7a94029ad3_0">
											<gml:posList>35.67089708993716 139.73831915553825 43.752 35.670911841816505 139.73831459801357 43.752 35.67090948787541 139.73831287757548 43.752 35.67089708993716 139.73831915553825 43.752</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc720bf3-2df8-4550-8968-ba38913ca031">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dc720bf3-2df8-4550-8968-ba38913ca031_0">
											<gml:posList>35.67090375865407 139.73835160175688 43.752 35.67089708993716 139.73831915553825 43.752 35.67090141372722 139.7383498813072 43.752 35.67090375865407 139.73835160175688 43.752</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4fe2487f-826f-4876-93de-bbbad777a6d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4fe2487f-826f-4876-93de-bbbad777a6d8_0">
											<gml:posList>35.67090948787541 139.73831287757548 43.752 35.67089558172121 139.73823552555942 43.752 35.67089417784889 139.73823839927036 43.752 35.67090948787541 139.73831287757548 43.752</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de4d2c43-3753-48eb-974b-03ac85c69d08">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de4d2c43-3753-48eb-974b-03ac85c69d08_0">
											<gml:posList>35.67084901205098 139.73825234911578 43.752 35.670846667122696 139.7382506286702 43.752 35.67087099078379 139.73835927358766 43.752 35.67084901205098 139.73825234911578 43.752</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0c666608-24c8-41ca-afe2-3d3311c0986d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0c666608-24c8-41ca-afe2-3d3311c0986d_0">
											<gml:posList>35.67087099078379 139.73835927358766 43.752 35.67090375865407 139.73835160175688 43.752 35.67090141372722 139.7383498813072 43.752 35.67087099078379 139.73835927358766 43.752</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eadd5376-e145-4275-b09c-148b30256e4a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eadd5376-e145-4275-b09c-148b30256e4a_0">
											<gml:posList>35.67089708993716 139.73831915553825 43.752 35.67090948787541 139.73831287757548 43.752 35.67089474500984 139.73831743508964 43.752 35.67089708993716 139.73831915553825 43.752</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c628d17-9390-4ad4-aa2c-45e3ce649c00">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4c628d17-9390-4ad4-aa2c-45e3ce649c00_0">
											<gml:posList>35.67090141372722 139.7383498813072 43.752 35.67089708993716 139.73831915553825 43.752 35.67089474500984 139.73831743508964 43.752 35.67090141372722 139.7383498813072 43.752</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-71fca442-605c-40b9-a1b6-c1140f350a5a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-71fca442-605c-40b9-a1b6-c1140f350a5a_0">
											<gml:posList>35.67084901205098 139.73825234911578 43.752 35.67089417784889 139.73823839927036 43.752 35.670846667122696 139.7382506286702 43.752 35.67084901205098 139.73825234911578 43.752</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce6ffcaa-1912-420a-b1b1-be4b63b376bc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce6ffcaa-1912-420a-b1b1-be4b63b376bc_0">
											<gml:posList>35.67084901205098 139.73825234911578 43.752 35.67087099078379 139.73835927358766 41.722 35.67084901205098 139.73825234911578 41.722 35.67084901205098 139.73825234911578 43.752</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f1af5800-f9f0-43e2-b96a-4801f3bdc74d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f1af5800-f9f0-43e2-b96a-4801f3bdc74d_0">
											<gml:posList>35.67084901205098 139.73825234911578 43.752 35.67087099078379 139.73835927358766 43.752 35.67087099078379 139.73835927358766 41.722 35.67084901205098 139.73825234911578 43.752</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a23bea8b-be8f-471f-9aad-061e5b0b507b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a23bea8b-be8f-471f-9aad-061e5b0b507b_0">
											<gml:posList>35.67086958691722 139.7383621583419 41.623 35.670846667122696 139.7382506286702 43.752 35.670846667122696 139.7382506286702 41.623 35.67086958691722 139.7383621583419 41.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c532e4b4-29ac-4ab0-b930-66e05e0abf5b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c532e4b4-29ac-4ab0-b930-66e05e0abf5b_0">
											<gml:posList>35.67086958691722 139.7383621583419 41.623 35.67086958691722 139.7383621583419 43.752 35.670846667122696 139.7382506286702 43.752 35.67086958691722 139.7383621583419 41.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7a49d85-42a3-4e3f-849e-c3813cdf8738">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d7a49d85-42a3-4e3f-849e-c3813cdf8738_0">
											<gml:posList>35.67089474500984 139.73831743508964 43.752 35.67090948787541 139.73831287757548 41.722 35.67089474500984 139.73831743508964 41.722 35.67089474500984 139.73831743508964 43.752</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d604063-c768-4bb6-a5c3-33daea82608c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8d604063-c768-4bb6-a5c3-33daea82608c_0">
											<gml:posList>35.67089474500984 139.73831743508964 43.752 35.67090948787541 139.73831287757548 43.752 35.67090948787541 139.73831287757548 41.722 35.67089474500984 139.73831743508964 43.752</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f6687a54-ecd7-40a0-a160-1576e8eb3ee7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f6687a54-ecd7-40a0-a160-1576e8eb3ee7_0">
											<gml:posList>35.670911841816505 139.73831459801357 41.623 35.67089708993716 139.73831915553825 43.752 35.67089708993716 139.73831915553825 41.623 35.670911841816505 139.73831459801357 41.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a115b63b-67f7-4f3e-b3e7-492903889f08">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a115b63b-67f7-4f3e-b3e7-492903889f08_0">
											<gml:posList>35.670911841816505 139.73831459801357 41.623 35.670911841816505 139.73831459801357 43.752 35.67089708993716 139.73831915553825 43.752 35.670911841816505 139.73831459801357 41.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16481d25-11da-4226-b233-e9e64617cf05">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16481d25-11da-4226-b233-e9e64617cf05_0">
											<gml:posList>35.67090141372722 139.7383498813072 43.752 35.67089474500984 139.73831743508964 41.722 35.67090141372722 139.7383498813072 41.722 35.67090141372722 139.7383498813072 43.752</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-875130a6-9d08-466f-885e-48e6d6e00c94">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-875130a6-9d08-466f-885e-48e6d6e00c94_0">
											<gml:posList>35.67090141372722 139.7383498813072 43.752 35.67089474500984 139.73831743508964 43.752 35.67089474500984 139.73831743508964 41.722 35.67090141372722 139.7383498813072 43.752</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-895ccdf8-fd32-41b2-97a2-cc2f2ce5fd60">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-895ccdf8-fd32-41b2-97a2-cc2f2ce5fd60_0">
											<gml:posList>35.67089708993716 139.73831915553825 43.752 35.67090375865407 139.73835160175688 41.623 35.67089708993716 139.73831915553825 41.623 35.67089708993716 139.73831915553825 43.752</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bda98ea1-ad2f-4fe7-ba23-78e4642a6a71">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bda98ea1-ad2f-4fe7-ba23-78e4642a6a71_0">
											<gml:posList>35.67089708993716 139.73831915553825 43.752 35.67090375865407 139.73835160175688 43.752 35.67090375865407 139.73835160175688 41.623 35.67089708993716 139.73831915553825 43.752</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb6ad143-7273-4700-a678-4016fc0ea7dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb6ad143-7273-4700-a678-4016fc0ea7dc_0">
											<gml:posList>35.67090141372722 139.7383498813072 43.752 35.67087099078379 139.73835927358766 41.722 35.67087099078379 139.73835927358766 43.752 35.67090141372722 139.7383498813072 43.752</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-930a4c60-3813-456b-9dbd-de1be6e473e8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-930a4c60-3813-456b-9dbd-de1be6e473e8_0">
											<gml:posList>35.67090141372722 139.7383498813072 43.752 35.67090141372722 139.7383498813072 41.722 35.67087099078379 139.73835927358766 41.722 35.67090141372722 139.7383498813072 43.752</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a70d02a6-9a61-4443-b8a4-f7679821bc08">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a70d02a6-9a61-4443-b8a4-f7679821bc08_0">
											<gml:posList>35.67090375865407 139.73835160175688 41.623 35.67086958691722 139.7383621583419 43.752 35.67086958691722 139.7383621583419 41.623 35.67090375865407 139.73835160175688 41.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4ddfcc49-b2cf-4ff1-84cd-520cd5a1bbd0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4ddfcc49-b2cf-4ff1-84cd-520cd5a1bbd0_0">
											<gml:posList>35.67090375865407 139.73835160175688 41.623 35.67090375865407 139.73835160175688 43.752 35.67086958691722 139.7383621583419 43.752 35.67090375865407 139.73835160175688 41.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-23dc8da4-854c-49d2-bb80-dffb02bd95c4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670911841816505 139.73831459801357 41.623 35.67089708993716 139.73831915553825 41.623 35.67089558172121 139.73823552555942 41.623 35.670911841816505 139.73831459801357 41.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa62ce02-2ebe-4a54-a1b4-845bc9a15a71">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67089558172121 139.73823552555942 41.623 35.67089708993716 139.73831915553825 41.623 35.670846667122696 139.7382506286702 41.623 35.67089558172121 139.73823552555942 41.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cecea1bc-aee0-4c23-a75b-9ee33f6efffc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670846667122696 139.7382506286702 41.623 35.67089708993716 139.73831915553825 41.623 35.67086958691722 139.7383621583419 41.623 35.670846667122696 139.7382506286702 41.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a435dd59-37e7-4f16-8f31-b09212d5e6bb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67089708993716 139.73831915553825 41.623 35.67090375865407 139.73835160175688 41.623 35.67086958691722 139.7383621583419 41.623 35.67089708993716 139.73831915553825 41.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_5fff859b-e3f9-4a50-b44d-91204415daf6_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4f464664-f17d-4413-8f1b-0bed3b0df3b8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67093395726938 139.73835492406758 17.729 35.67091319466528 139.73836130030475 17.729 35.67090557572763 139.73832406109955 17.729 35.670926166397905 139.73831683448932 17.729 35.67093395726938 139.73835492406758 17.729</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a5c08ee4-bcb8-48ae-8c37-bdd4cf131e12">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a5c08ee4-bcb8-48ae-8c37-bdd4cf131e12_0">
											<gml:posList>35.67090557572763 139.73832406109955 17.729 35.67091319466528 139.73836130030475 17.729 35.67091319466528 139.73836130030475 40.689 35.67091152970175 139.73835313903732 40.689 35.67090557572763 139.73832406109955 41.954 35.67090557572763 139.73832406109955 17.729</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b888677c-c00c-4c24-a8a6-d74c690be786">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b888677c-c00c-4c24-a8a6-d74c690be786_0">
											<gml:posList>35.6709158755697 139.73832044778956 41.954 35.67090557572763 139.73832406109955 41.954 35.67091152970175 139.73835313903732 40.689 35.670921865765116 139.73834973556822 40.689 35.6709158755697 139.73832044778956 41.954</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e55ebb3a-d244-4ef0-802f-f23ab911bafc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e55ebb3a-d244-4ef0-802f-f23ab911bafc_0">
											<gml:posList>35.6709158755697 139.73832044778956 40.001 35.670926166397905 139.73831683448932 40.001 35.670926166397905 139.73831683448932 17.729 35.67090557572763 139.73832406109955 17.729 35.67090557572763 139.73832406109955 41.954 35.6709158755697 139.73832044778956 41.954 35.6709158755697 139.73832044778956 40.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1045cd4-0cb8-48cc-bcab-551189891c2e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d1045cd4-0cb8-48cc-bcab-551189891c2e_0">
											<gml:posList>35.67091152970175 139.73835313903732 40.689 35.67091319466528 139.73836130030475 40.689 35.67092357596303 139.7383581066634 40.689 35.670921865765116 139.73834973556822 40.689 35.67091152970175 139.73835313903732 40.689</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c096c969-63ca-4bc5-b5e3-a4cffc6d1210">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c096c969-63ca-4bc5-b5e3-a4cffc6d1210_0">
											<gml:posList>35.670921865765116 139.73834973556822 40.689 35.6709158755697 139.73832044778956 40.001 35.6709158755697 139.73832044778956 41.954 35.670921865765116 139.73834973556822 40.689</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a1281ae-67d7-4e76-9b00-329b01c25b2f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2a1281ae-67d7-4e76-9b00-329b01c25b2f_0">
											<gml:posList>35.67091319466528 139.73836130030475 17.729 35.67093395726938 139.73835492406758 17.729 35.67093395726938 139.73835492406758 40.689 35.67092357596303 139.7383581066634 40.689 35.67091319466528 139.73836130030475 40.689 35.67091319466528 139.73836130030475 17.729</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27d4ff9b-e7c7-4365-8d0c-ba6ff11a9f58">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-27d4ff9b-e7c7-4365-8d0c-ba6ff11a9f58_0">
											<gml:posList>35.67093220183709 139.7383463431446 40.689 35.670926166397905 139.73831683448932 40.001 35.6709158755697 139.73832044778956 40.001 35.670921865765116 139.73834973556822 40.689 35.67093220183709 139.7383463431446 40.689</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ede54abe-99ba-4abe-895f-63aabc6fc444">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ede54abe-99ba-4abe-895f-63aabc6fc444_0">
											<gml:posList>35.67092357596303 139.7383581066634 40.689 35.67093395726938 139.73835492406758 40.689 35.67093220183709 139.7383463431446 40.689 35.670921865765116 139.73834973556822 40.689 35.67092357596303 139.7383581066634 40.689</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e0da9545-6d3b-43ef-ae20-0a34d5a6a2a4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e0da9545-6d3b-43ef-ae20-0a34d5a6a2a4_0">
											<gml:posList>35.67093395726938 139.73835492406758 40.689 35.67093395726938 139.73835492406758 17.729 35.670926166397905 139.73831683448932 17.729 35.670926166397905 139.73831683448932 40.001 35.67093220183709 139.7383463431446 40.689 35.67093395726938 139.73835492406758 40.689</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_5fff859b-e3f9-4a50-b44d-91204415daf6_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4ceb7bc4-5918-42b8-b700-854fb220a684">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67088190893339 139.7382710888615 41.722 35.670891713751786 139.7382684040244 41.722 35.670893696337735 139.73827927126237 41.722 35.67088389151911 139.73828195609815 41.722 35.67088190893339 139.7382710888615 41.722</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-212fe3e0-98ad-4b58-ac27-88207876597c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-212fe3e0-98ad-4b58-ac27-88207876597c_0">
											<gml:posList>35.670891713751786 139.7382684040244 42.39 35.670891713751786 139.7382684040244 41.722 35.67088190893339 139.7382710888615 41.722 35.67088190893339 139.7382710888615 42.39 35.670891713751786 139.7382684040244 42.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d9b11f3a-2e93-4b3b-a6ae-a6eb5af753ec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d9b11f3a-2e93-4b3b-a6ae-a6eb5af753ec_0">
											<gml:posList>35.670893696337735 139.73827927126237 42.39 35.670893696337735 139.73827927126237 41.722 35.670891713751786 139.7382684040244 41.722 35.670891713751786 139.7382684040244 42.39 35.670893696337735 139.73827927126237 42.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18bd5d65-3a87-4381-b780-6be2c90858f2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-18bd5d65-3a87-4381-b780-6be2c90858f2_0">
											<gml:posList>35.67088190893339 139.7382710888615 42.39 35.67088389151911 139.73828195609815 42.39 35.670893696337735 139.73827927126237 42.39 35.670891713751786 139.7382684040244 42.39 35.67088190893339 139.7382710888615 42.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6680ee81-95f0-40ea-a1be-6c6809e5fcfd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6680ee81-95f0-40ea-a1be-6c6809e5fcfd_0">
											<gml:posList>35.67088190893339 139.7382710888615 42.39 35.67088190893339 139.7382710888615 41.722 35.67088389151911 139.73828195609815 41.722 35.67088389151911 139.73828195609815 42.39 35.67088190893339 139.7382710888615 42.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8194d157-2dcf-41be-ba51-c85dab971c5f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8194d157-2dcf-41be-ba51-c85dab971c5f_0">
											<gml:posList>35.67088389151911 139.73828195609815 42.39 35.67088389151911 139.73828195609815 41.722 35.670893696337735 139.73827927126237 41.722 35.670893696337735 139.73827927126237 42.39 35.67088389151911 139.73828195609815 42.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-96be0951-6333-4ac5-b9d1-07a669a6251f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96be0951-6333-4ac5-b9d1-07a669a6251f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96be0951-6333-4ac5-b9d1-07a669a6251f">
											<gml:posList>35.67090557572763 139.73832406109955 17.729 35.67091319466528 139.73836130030475 17.729 35.670854205088546 139.7383794309211 17.729 35.670826968573714 139.73824613408593 17.729 35.670906720814855 139.73822173757148 17.729 35.670926166397905 139.73831683448932 17.729 35.67090557572763 139.73832406109955 17.729</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bdcc8e08-838a-4265-9727-0aa4e9e21229">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bdcc8e08-838a-4265-9727-0aa4e9e21229">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bdcc8e08-838a-4265-9727-0aa4e9e21229">
											<gml:posList>35.67083734087226 139.73824296253645 39.606 35.670826968573714 139.73824613408593 39.606 35.6708297644411 139.7382481743395 39.606 35.67083790187763 139.73824569031268 39.606 35.67083734087226 139.73824296253645 39.606</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e2625d1a-1e75-4845-868a-95e838a8a67e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e2625d1a-1e75-4845-868a-95e838a8a67e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e2625d1a-1e75-4845-868a-95e838a8a67e">
											<gml:posList>35.670854205088546 139.7383794309211 39.606 35.670855869926605 139.73837600458873 39.606 35.6708297644411 139.7382481743395 39.606 35.670826968573714 139.73824613408593 39.606 35.670854205088546 139.7383794309211 39.606</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bf28caa0-9a5a-4233-89ba-06c7ff5ddf91">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf28caa0-9a5a-4233-89ba-06c7ff5ddf91">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf28caa0-9a5a-4233-89ba-06c7ff5ddf91">
											<gml:posList>35.67086405240822 139.73837348738175 39.267 35.67083790187763 139.73824569031268 39.267 35.6708297644411 139.7382481743395 39.267 35.670855869926605 139.73837600458873 39.267 35.67086405240822 139.73837348738175 39.267</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d2f04e1c-eceb-4b11-a5c5-a707b6d5c9e9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d2f04e1c-eceb-4b11-a5c5-a707b6d5c9e9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d2f04e1c-eceb-4b11-a5c5-a707b6d5c9e9">
											<gml:posList>35.67086461341934 139.73837622620613 41.954 35.67086733117268 139.73837065563885 41.954 35.67084188643971 139.73824631522746 41.954 35.67083734087226 139.73824296253645 41.954 35.67086461341934 139.73837622620613 41.954</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e6d00136-3c9e-48d1-a454-fadf94733d40">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e6d00136-3c9e-48d1-a454-fadf94733d40">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e6d00136-3c9e-48d1-a454-fadf94733d40">
											<gml:posList>35.67086461341934 139.73837622620613 39.606 35.67086405240822 139.73837348738175 39.606 35.670855869926605 139.73837600458873 39.606 35.670854205088546 139.7383794309211 39.606 35.67086461341934 139.73837622620613 39.606</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cbb0fdb1-3ab4-4c50-ba45-29e21e27d1e9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cbb0fdb1-3ab4-4c50-ba45-29e21e27d1e9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cbb0fdb1-3ab4-4c50-ba45-29e21e27d1e9">
											<gml:posList>35.67083734087226 139.73824296253645 41.954 35.67084188643971 139.73824631522746 41.954 35.670903985040994 139.73822730816792 41.954 35.670906720814855 139.73822173757148 41.954 35.67083734087226 139.73824296253645 41.954</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e6c509d2-f5a9-4c4d-9235-4778e2d640e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e6c509d2-f5a9-4c4d-9235-4778e2d640e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e6c509d2-f5a9-4c4d-9235-4778e2d640e6">
											<gml:posList>35.67086733117268 139.73837065563885 41.623 35.67090864010477 139.73835796970755 41.623 35.67090104832058 139.7383208740749 41.623 35.67092164799568 139.7383136364073 41.623 35.670903985040994 139.73822730816792 41.623 35.67084188643971 139.73824631522746 41.623 35.67086733117268 139.73837065563885 41.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-abd0a499-85f0-4d17-af86-1156de5bd117">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-abd0a499-85f0-4d17-af86-1156de5bd117">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-abd0a499-85f0-4d17-af86-1156de5bd117">
											<gml:posList>35.67091319466528 139.73836130030475 41.954 35.67090864010477 139.73835796970755 41.954 35.67086733117268 139.73837065563885 41.954 35.67086461341934 139.73837622620613 41.954 35.67091319466528 139.73836130030475 41.954</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c43529cf-c2f2-4af1-81b2-5d1635824669">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c43529cf-c2f2-4af1-81b2-5d1635824669">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c43529cf-c2f2-4af1-81b2-5d1635824669">
											<gml:posList>35.67090557572763 139.73832406109955 41.954 35.67090104832058 139.7383208740749 41.954 35.67090864010477 139.73835796970755 41.954 35.67091319466528 139.73836130030475 41.954 35.67090557572763 139.73832406109955 41.954</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-935d93ed-9043-442d-b602-c6232d1b355f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-935d93ed-9043-442d-b602-c6232d1b355f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-935d93ed-9043-442d-b602-c6232d1b355f">
											<gml:posList>35.67090557572763 139.73832406109955 41.954 35.670926166397905 139.73831683448932 41.954 35.67092164799568 139.7383136364073 41.954 35.67090104832058 139.7383208740749 41.954 35.67090557572763 139.73832406109955 41.954</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c681c0ac-75a0-4938-b528-759a8b1f1b58">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c681c0ac-75a0-4938-b528-759a8b1f1b58">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c681c0ac-75a0-4938-b528-759a8b1f1b58">
											<gml:posList>35.670906720814855 139.73822173757148 41.954 35.670903985040994 139.73822730816792 41.954 35.67092164799568 139.7383136364073 41.954 35.670926166397905 139.73831683448932 41.954 35.670906720814855 139.73822173757148 41.954</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-daf77441-f3eb-4ff0-8be5-f7c9ee441759">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-daf77441-f3eb-4ff0-8be5-f7c9ee441759">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-daf77441-f3eb-4ff0-8be5-f7c9ee441759">
											<gml:posList>35.6708297644411 139.7382481743395 39.606 35.6708297644411 139.7382481743395 39.267 35.67083790187763 139.73824569031268 39.267 35.67083790187763 139.73824569031268 39.606 35.6708297644411 139.7382481743395 39.606</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-906b9258-19df-460e-8921-5086646dbd91">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-906b9258-19df-460e-8921-5086646dbd91">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-906b9258-19df-460e-8921-5086646dbd91">
											<gml:posList>35.670826968573714 139.73824613408593 17.729 35.670854205088546 139.7383794309211 17.729 35.670854205088546 139.7383794309211 39.606 35.670826968573714 139.73824613408593 39.606 35.670826968573714 139.73824613408593 17.729</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-54667f71-895a-4509-9be0-f9673aa26ee9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-54667f71-895a-4509-9be0-f9673aa26ee9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-54667f71-895a-4509-9be0-f9673aa26ee9">
											<gml:posList>35.670855869926605 139.73837600458873 39.606 35.670855869926605 139.73837600458873 39.267 35.6708297644411 139.7382481743395 39.267 35.6708297644411 139.7382481743395 39.606 35.670855869926605 139.73837600458873 39.606</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-29688b80-f380-4747-9a32-7736578191d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-29688b80-f380-4747-9a32-7736578191d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-29688b80-f380-4747-9a32-7736578191d6">
											<gml:posList>35.67083790187763 139.73824569031268 39.606 35.67083790187763 139.73824569031268 39.267 35.67086405240822 139.73837348738175 39.267 35.67086405240822 139.73837348738175 39.606 35.67086461341934 139.73837622620613 39.606 35.67086461341934 139.73837622620613 41.954 35.67083734087226 139.73824296253645 41.954 35.67083734087226 139.73824296253645 39.606 35.67083790187763 139.73824569031268 39.606</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d300d195-d922-4a11-b751-186431f5f178">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d300d195-d922-4a11-b751-186431f5f178">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d300d195-d922-4a11-b751-186431f5f178">
											<gml:posList>35.67086733117268 139.73837065563885 41.954 35.67086733117268 139.73837065563885 41.623 35.67084188643971 139.73824631522746 41.623 35.67084188643971 139.73824631522746 41.954 35.67086733117268 139.73837065563885 41.954</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e05ddc92-2f21-4b41-a5a4-be96498106cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e05ddc92-2f21-4b41-a5a4-be96498106cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e05ddc92-2f21-4b41-a5a4-be96498106cf">
											<gml:posList>35.67086405240822 139.73837348738175 39.606 35.67086405240822 139.73837348738175 39.267 35.670855869926605 139.73837600458873 39.267 35.670855869926605 139.73837600458873 39.606 35.67086405240822 139.73837348738175 39.606</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3b42c346-2404-4622-9038-24f66d500fdc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3b42c346-2404-4622-9038-24f66d500fdc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3b42c346-2404-4622-9038-24f66d500fdc">
											<gml:posList>35.670906720814855 139.73822173757148 41.954 35.670906720814855 139.73822173757148 17.729 35.670826968573714 139.73824613408593 17.729 35.670826968573714 139.73824613408593 39.606 35.67083734087226 139.73824296253645 39.606 35.67083734087226 139.73824296253645 41.954 35.670906720814855 139.73822173757148 41.954</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5bd194f2-233f-4711-b66b-ebfaecbb4973">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5bd194f2-233f-4711-b66b-ebfaecbb4973">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5bd194f2-233f-4711-b66b-ebfaecbb4973">
											<gml:posList>35.67084188643971 139.73824631522746 41.954 35.67084188643971 139.73824631522746 41.623 35.670903985040994 139.73822730816792 41.623 35.670903985040994 139.73822730816792 41.954 35.67084188643971 139.73824631522746 41.954</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-af339a34-e9ce-4e94-bf4d-d20bdd1200ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af339a34-e9ce-4e94-bf4d-d20bdd1200ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af339a34-e9ce-4e94-bf4d-d20bdd1200ef">
											<gml:posList>35.670854205088546 139.7383794309211 17.729 35.67091319466528 139.73836130030475 17.729 35.67091319466528 139.73836130030475 41.954 35.67086461341934 139.73837622620613 41.954 35.67086461341934 139.73837622620613 39.606 35.670854205088546 139.7383794309211 39.606 35.670854205088546 139.7383794309211 17.729</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f3cc74e7-39c0-4378-9382-2b7659234797">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f3cc74e7-39c0-4378-9382-2b7659234797">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f3cc74e7-39c0-4378-9382-2b7659234797">
											<gml:posList>35.67090864010477 139.73835796970755 41.954 35.67090864010477 139.73835796970755 41.623 35.67086733117268 139.73837065563885 41.623 35.67086733117268 139.73837065563885 41.954 35.67090864010477 139.73835796970755 41.954</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-48d52030-e98d-4b16-a3b3-d83a9d2c9a3f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-48d52030-e98d-4b16-a3b3-d83a9d2c9a3f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-48d52030-e98d-4b16-a3b3-d83a9d2c9a3f">
											<gml:posList>35.67090104832058 139.7383208740749 41.954 35.67090104832058 139.7383208740749 41.623 35.67090864010477 139.73835796970755 41.623 35.67090864010477 139.73835796970755 41.954 35.67090104832058 139.7383208740749 41.954</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-246c938a-8175-4fb3-a37d-613353ec2bf4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-246c938a-8175-4fb3-a37d-613353ec2bf4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-246c938a-8175-4fb3-a37d-613353ec2bf4">
											<gml:posList>35.67091319466528 139.73836130030475 17.729 35.67090557572763 139.73832406109955 17.729 35.67090557572763 139.73832406109955 41.954 35.67091319466528 139.73836130030475 41.954 35.67091319466528 139.73836130030475 17.729</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-54fb1d6f-bd29-4c8f-bf20-8d559e50cac4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-54fb1d6f-bd29-4c8f-bf20-8d559e50cac4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-54fb1d6f-bd29-4c8f-bf20-8d559e50cac4">
											<gml:posList>35.67092164799568 139.7383136364073 41.954 35.67092164799568 139.7383136364073 41.623 35.67090104832058 139.7383208740749 41.623 35.67090104832058 139.7383208740749 41.954 35.67092164799568 139.7383136364073 41.954</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8706620d-9b69-4529-8e87-f993baecd90a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8706620d-9b69-4529-8e87-f993baecd90a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8706620d-9b69-4529-8e87-f993baecd90a">
											<gml:posList>35.670903985040994 139.73822730816792 41.954 35.670903985040994 139.73822730816792 41.623 35.67092164799568 139.7383136364073 41.623 35.67092164799568 139.7383136364073 41.954 35.670903985040994 139.73822730816792 41.954</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a26753f4-975c-462d-bc08-4b7b3e556cf4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a26753f4-975c-462d-bc08-4b7b3e556cf4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a26753f4-975c-462d-bc08-4b7b3e556cf4">
											<gml:posList>35.67090557572763 139.73832406109955 17.729 35.670926166397905 139.73831683448932 17.729 35.670926166397905 139.73831683448932 41.954 35.67090557572763 139.73832406109955 41.954 35.67090557572763 139.73832406109955 17.729</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cc48e88f-eab9-415c-b51c-e5435e1b0b28">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc48e88f-eab9-415c-b51c-e5435e1b0b28">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc48e88f-eab9-415c-b51c-e5435e1b0b28">
											<gml:posList>35.670926166397905 139.73831683448932 17.729 35.670906720814855 139.73822173757148 17.729 35.670906720814855 139.73822173757148 41.954 35.670926166397905 139.73831683448932 41.954 35.670926166397905 139.73831683448932 17.729</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7961</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">113.4123</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.04</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>