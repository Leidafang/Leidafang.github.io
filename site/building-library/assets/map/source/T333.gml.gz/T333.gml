<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_6033de74-0d00-4afc-9497-e90a321d093f">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">18.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66891852186838 139.73843349614617 0 35.668897917727236 139.7384122126922 0 35.66885287404632 139.7384782330194 0 35.668994954801235 139.7386236521194 0 35.66903051808025 139.7385715831071 0 35.66904152377685 139.73858294755715 0 35.6690573696765 139.73855973207037 0 35.6690443793933 139.73854638167373 0 35.669060855463854 139.73852217128675 0 35.66894142632258 139.73839990005797 0 35.66891852186838 139.73843349614617 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66891852186838 139.73843349614617 15.72 35.66894142632258 139.73839990005797 15.72 35.669060855463854 139.73852217128675 15.72 35.6690443793933 139.73854638167373 15.72 35.6690573696765 139.73855973207037 15.72 35.66904152377685 139.73858294755715 15.72 35.66903051808025 139.7385715831071 15.72 35.668994954801235 139.7386236521194 15.72 35.66885287404632 139.7384782330194 15.72 35.668897917727236 139.7384122126922 15.72 35.66891852186838 139.73843349614617 15.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66891852186838 139.73843349614617 15.72 35.668897917727236 139.7384122126922 15.72 35.668897917727236 139.7384122126922 34.37 35.66891852186838 139.73843349614617 34.37 35.66891852186838 139.73843349614617 15.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668897917727236 139.7384122126922 15.72 35.66885287404632 139.7384782330194 15.72 35.66885287404632 139.7384782330194 34.37 35.668897917727236 139.7384122126922 34.37 35.668897917727236 139.7384122126922 15.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66885287404632 139.7384782330194 15.72 35.668994954801235 139.7386236521194 15.72 35.668994954801235 139.7386236521194 34.37 35.66885287404632 139.7384782330194 34.37 35.66885287404632 139.7384782330194 15.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668994954801235 139.7386236521194 15.72 35.66903051808025 139.7385715831071 15.72 35.66903051808025 139.7385715831071 34.37 35.668994954801235 139.7386236521194 34.37 35.668994954801235 139.7386236521194 15.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66903051808025 139.7385715831071 15.72 35.66904152377685 139.73858294755715 15.72 35.66904152377685 139.73858294755715 34.37 35.66903051808025 139.7385715831071 34.37 35.66903051808025 139.7385715831071 15.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66904152377685 139.73858294755715 15.72 35.6690573696765 139.73855973207037 15.72 35.6690573696765 139.73855973207037 34.37 35.66904152377685 139.73858294755715 34.37 35.66904152377685 139.73858294755715 15.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6690573696765 139.73855973207037 15.72 35.6690443793933 139.73854638167373 15.72 35.6690443793933 139.73854638167373 34.37 35.6690573696765 139.73855973207037 34.37 35.6690573696765 139.73855973207037 15.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6690443793933 139.73854638167373 15.72 35.669060855463854 139.73852217128675 15.72 35.669060855463854 139.73852217128675 34.37 35.6690443793933 139.73854638167373 34.37 35.6690443793933 139.73854638167373 15.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669060855463854 139.73852217128675 15.72 35.66894142632258 139.73839990005797 15.72 35.66894142632258 139.73839990005797 34.37 35.669060855463854 139.73852217128675 34.37 35.669060855463854 139.73852217128675 15.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66894142632258 139.73839990005797 15.72 35.66891852186838 139.73843349614617 15.72 35.66891852186838 139.73843349614617 34.37 35.66894142632258 139.73839990005797 34.37 35.66894142632258 139.73839990005797 15.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66891852186838 139.73843349614617 34.37 35.668897917727236 139.7384122126922 34.37 35.66885287404632 139.7384782330194 34.37 35.668994954801235 139.7386236521194 34.37 35.66903051808025 139.7385715831071 34.37 35.66904152377685 139.73858294755715 34.37 35.6690573696765 139.73855973207037 34.37 35.6690443793933 139.73854638167373 34.37 35.669060855463854 139.73852217128675 34.37 35.66894142632258 139.73839990005797 34.37 35.66891852186838 139.73843349614617 34.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-8ff48b29-c99e-4126-bf79-2dcd4a5cb015"/>
							<gml:surfaceMember xlink:href="#poly-882f4507-2351-45c1-b72d-3ddb92191d81"/>
							<gml:surfaceMember xlink:href="#poly-f834c95f-8a79-403d-b225-428dc0cd6baf"/>
							<gml:surfaceMember xlink:href="#poly-c913bf35-b62d-4a05-bcbd-2e8e8e8e0911"/>
							<gml:surfaceMember xlink:href="#poly-acea02ca-c29a-4f58-9b4a-e852c897d254"/>
							<gml:surfaceMember xlink:href="#poly-1d3b8651-1bf4-4e04-866f-0817417e52c3"/>
							<gml:surfaceMember xlink:href="#poly-930a282d-f63e-4b7f-89e2-a3d6735894bd"/>
							<gml:surfaceMember xlink:href="#poly-d6800ac0-a6a7-4e45-be63-a657b7c409c6"/>
							<gml:surfaceMember xlink:href="#poly-978315eb-17d6-4cab-b111-93037579aefe"/>
							<gml:surfaceMember xlink:href="#poly-f4bad43c-0972-435b-861c-68e891196917"/>
							<gml:surfaceMember xlink:href="#poly-762c5b3d-495e-4360-b974-d384dacd6160"/>
							<gml:surfaceMember xlink:href="#poly-6f55f38e-57a1-445a-abe9-c7d35835a89b"/>
							<gml:surfaceMember xlink:href="#poly-2525476b-fe57-4efc-b41b-d3e96eec2c0d"/>
							<gml:surfaceMember xlink:href="#poly-4d1eef62-700a-4224-bed1-336902263f71"/>
							<gml:surfaceMember xlink:href="#poly-4ee96823-f010-4fab-a6ef-80865548ba04"/>
							<gml:surfaceMember xlink:href="#poly-9af921e9-b221-45cd-b29d-c6250cf0b3f5"/>
							<gml:surfaceMember xlink:href="#poly-b3ea1c30-caf0-46a9-a66c-70b00ea9f381"/>
							<gml:surfaceMember xlink:href="#poly-a11efa9a-b1b8-421d-bb0d-1c724af2a97a"/>
							<gml:surfaceMember xlink:href="#poly-0a9ec632-c24f-4ca6-93f5-61eda7b7cbbe"/>
							<gml:surfaceMember xlink:href="#poly-6f9b9464-8aa3-49b3-bcb7-178c92b51dd7"/>
							<gml:surfaceMember xlink:href="#poly-487430b5-2640-46b0-8478-84e6094563c7"/>
							<gml:surfaceMember xlink:href="#poly-2299a745-8e9a-49bd-9293-52e21d955863"/>
							<gml:surfaceMember xlink:href="#poly-9e0b0c02-ebf6-4d82-864a-8975ebd7b060"/>
							<gml:surfaceMember xlink:href="#poly-f877ccbd-1005-438b-b03d-f3f773e5216d"/>
							<gml:surfaceMember xlink:href="#poly-a460216c-0160-4784-aad3-48f92d36b316"/>
							<gml:surfaceMember xlink:href="#poly-f4bfee71-483c-4e15-b177-7f0e8194eb92"/>
							<gml:surfaceMember xlink:href="#poly-35ce3801-abd3-4b1e-9410-a568a28069be"/>
							<gml:surfaceMember xlink:href="#poly-374c59a6-f05b-413b-8d45-f7f829b4b61a"/>
							<gml:surfaceMember xlink:href="#poly-949c303b-d4e9-40e0-a154-b5d75f8a9644"/>
							<gml:surfaceMember xlink:href="#poly-c76ccaf6-71d9-4dd5-a3d8-7503dfea4d29"/>
							<gml:surfaceMember xlink:href="#poly-a78439cb-6431-47cc-8c38-dfdc72dc1adf"/>
							<gml:surfaceMember xlink:href="#poly-77698d56-07ec-4fca-ab74-3ccf1519a5a9"/>
							<gml:surfaceMember xlink:href="#poly-3a81ea49-8b8c-419f-a5c9-1093530b0bf0"/>
							<gml:surfaceMember xlink:href="#poly-433044c9-fed4-40f5-a0c3-a077f6689ffc"/>
							<gml:surfaceMember xlink:href="#poly-2513ff4a-944b-4fc2-bc4b-1d9b7dd04609"/>
							<gml:surfaceMember xlink:href="#poly-e4d9669e-1e9e-4879-9c37-51deee09e85f"/>
							<gml:surfaceMember xlink:href="#poly-6172394e-4aaa-4fb7-a0d0-23c850516b3f"/>
							<gml:surfaceMember xlink:href="#poly-f3944c82-1024-4ef7-a331-204e55ccb3b8"/>
							<gml:surfaceMember xlink:href="#poly-c5d58706-7e41-42f7-b1cb-1ee05d5a8886"/>
							<gml:surfaceMember xlink:href="#poly-ede722be-db46-46e5-8875-27cf4c88fab0"/>
							<gml:surfaceMember xlink:href="#poly-221dfe30-e3dd-480c-b9ab-58ae2c1a9acc"/>
							<gml:surfaceMember xlink:href="#poly-8aeef402-60fd-48f5-8227-b161ff802b87"/>
							<gml:surfaceMember xlink:href="#poly-9ad03543-c1c3-4832-93c8-6b9ba8458c4a"/>
							<gml:surfaceMember xlink:href="#poly-634e00f8-90c1-428f-b1de-a9fe4e87ade2"/>
							<gml:surfaceMember xlink:href="#poly-b2f82f57-e247-4622-94b0-6a095c580387"/>
							<gml:surfaceMember xlink:href="#poly-5a9e45a3-6fa8-4825-b70a-83b47ea9a86f"/>
							<gml:surfaceMember xlink:href="#poly-71ad0feb-40a9-4592-8be9-92be27a104b4"/>
							<gml:surfaceMember xlink:href="#poly-c5427a0e-74b1-443a-b31c-6bf8018feb6c"/>
							<gml:surfaceMember xlink:href="#poly-8d7dd8c8-1bb1-4ff0-958c-085bc4e217e5"/>
							<gml:surfaceMember xlink:href="#poly-21513b89-8cba-4ff9-9d66-f8116b0a6ed1"/>
							<gml:surfaceMember xlink:href="#poly-e08e7d62-4e9d-4e8e-bba0-4e53d22a955b"/>
							<gml:surfaceMember xlink:href="#poly-699a1676-71b8-4798-9c70-809731396ec2"/>
							<gml:surfaceMember xlink:href="#poly-5951c3e2-f9aa-4a17-b2ad-2562eab4a052"/>
							<gml:surfaceMember xlink:href="#poly-a5481d12-43fc-45c3-93f3-8909b74a7fc9"/>
							<gml:surfaceMember xlink:href="#poly-21134cce-2e60-4eb6-928c-899fbf38d843"/>
							<gml:surfaceMember xlink:href="#poly-fac7c7a2-184d-4095-8c5a-22075e534962"/>
							<gml:surfaceMember xlink:href="#poly-e844b1ad-7325-4ca5-bd0b-61881fed9a7e"/>
							<gml:surfaceMember xlink:href="#poly-cc3eb393-6e31-401a-9701-21d9315b3684"/>
							<gml:surfaceMember xlink:href="#poly-542ddd4f-65ef-4c7d-93a5-a3f8467284f2"/>
							<gml:surfaceMember xlink:href="#poly-b4de7300-6083-468d-bb90-893259a7a324"/>
							<gml:surfaceMember xlink:href="#poly-a5ab443c-1297-43d6-9937-88bb241527b3"/>
							<gml:surfaceMember xlink:href="#poly-d9ab6852-bdfa-464f-919f-68d6983f85a3"/>
							<gml:surfaceMember xlink:href="#poly-46734a7c-3d92-4bea-bac4-48d781083797"/>
							<gml:surfaceMember xlink:href="#poly-31bbc54c-cb56-4d19-834d-8111912ce71d"/>
							<gml:surfaceMember xlink:href="#poly-85b45113-5616-4144-8a1b-95f6eb906b9e"/>
							<gml:surfaceMember xlink:href="#poly-bf9445c2-f9cc-4ecb-9d6b-14640d9eaf42"/>
							<gml:surfaceMember xlink:href="#poly-24176140-9dcf-4352-bbee-7c3f0c1e513b"/>
							<gml:surfaceMember xlink:href="#poly-06a7c5b3-6a36-4551-82ce-94ced859343f"/>
							<gml:surfaceMember xlink:href="#poly-c0521008-8d04-4cd5-aef3-0ab8661c98d9"/>
							<gml:surfaceMember xlink:href="#poly-b10b1afe-7667-49b1-9739-a0cb53873235"/>
							<gml:surfaceMember xlink:href="#poly-f0a944bd-ceeb-431c-aaee-3a17a35c500f"/>
							<gml:surfaceMember xlink:href="#poly-f3b3dc91-9ae2-46ca-89c1-49a06fb65d02"/>
							<gml:surfaceMember xlink:href="#poly-5b8e43f1-2e95-4256-bf05-f56812b051b0"/>
							<gml:surfaceMember xlink:href="#poly-a00ea53d-b275-444f-a8a1-5a43aa5bd772"/>
							<gml:surfaceMember xlink:href="#poly-3bbfa3cd-2070-441c-9f1c-38acd86ef64b"/>
							<gml:surfaceMember xlink:href="#poly-3cdff4a5-ea8f-4c5b-8aac-cf190e388206"/>
							<gml:surfaceMember xlink:href="#poly-1df52d69-3d6c-4116-9ed4-ef42626ed7d4"/>
							<gml:surfaceMember xlink:href="#poly-d8521afe-1490-444e-9bfb-e7a056835205"/>
							<gml:surfaceMember xlink:href="#poly-a3d03a85-c5f2-43d7-a32d-c2a722e301ba"/>
							<gml:surfaceMember xlink:href="#poly-918204ad-ef76-45e7-abc2-cc0fbfae1ae3"/>
							<gml:surfaceMember xlink:href="#poly-8b7bcebb-9345-49d5-9f90-ee449252134e"/>
							<gml:surfaceMember xlink:href="#poly-7658e567-3327-4ed2-8828-1f164c5d154e"/>
							<gml:surfaceMember xlink:href="#poly-8db1863b-adf1-40ea-bb56-c0deaa3d8492"/>
							<gml:surfaceMember xlink:href="#poly-ef15cf42-a6f4-4018-8094-ccbf39e3e8e1"/>
							<gml:surfaceMember xlink:href="#poly-a95c3d20-f805-4136-bb93-e8aede9a7282"/>
							<gml:surfaceMember xlink:href="#poly-fda3fb75-6b45-4ebe-990a-0989a21378d4"/>
							<gml:surfaceMember xlink:href="#poly-5d1a19b9-4278-4f55-8f64-d58ad38d3c49"/>
							<gml:surfaceMember xlink:href="#poly-85a32bd1-4113-4e3a-a9d1-9ba36f63c2c2"/>
							<gml:surfaceMember xlink:href="#poly-abf0b07e-1974-43a4-89fc-78c3aad66ebd"/>
							<gml:surfaceMember xlink:href="#poly-e583af28-ee35-4187-8207-fb8a4c0ea7d5"/>
							<gml:surfaceMember xlink:href="#poly-eacac7b1-cb82-4466-97d9-3f095b3a355e"/>
							<gml:surfaceMember xlink:href="#poly-04d9d1c3-2f64-499c-b4e0-d32484b87cb0"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_6033de74-0d00-4afc-9497-e90a321d093f_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e092b077-402b-44b7-a3eb-2e8ea27ea7d3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66894076106687 139.73845931760735 34.564 35.66894663123514 139.73845070577948 34.564 35.668954019437265 139.73845826358968 34.564 35.66894873449048 139.73846602417862 34.564 35.66894814927718 139.73846688646387 34.564 35.66894076106687 139.73845931760735 34.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f408f6b-181b-4853-88b4-fc84af6f8f03">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668984363453845 139.73846307690846 37.789 35.66897422569587 139.73847793481548 37.789 35.66896522272432 139.73846871095625 37.789 35.668975351467445 139.73845385306046 37.789 35.668984363453845 139.73846307690846 37.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b1bb12c-130f-458e-8391-0debdf6ea683">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668901927486125 139.7385249108505 34.564 35.66889255466833 139.73851532291187 34.564 35.66889570583606 139.73851070193462 34.564 35.66890506964049 139.73852028988372 34.564 35.668901927486125 139.7385249108505 34.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9285b68a-3952-4f5b-aee4-41208eecc671">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668891141148784 139.73851740124158 35.209 35.66889255466833 139.73851532291187 35.209 35.668901927486125 139.7385249108505 35.209 35.668900504952695 139.73852698919092 35.209 35.668891141148784 139.73851740124158 35.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c4229411-8572-4b0a-8127-e33a86135293">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668928929238774 139.73854350257915 34.564 35.66892529188517 139.73854883107953 34.564 35.668916532489526 139.7385398609893 34.564 35.668920169842735 139.73853453248913 34.564 35.668928929238774 139.73854350257915 34.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ffea1e31-0d7b-4eea-8d4a-cff10077fb8f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66892387835635 139.73855089836343 35.209 35.66891511896956 139.73854193931922 35.209 35.668916532489526 139.7385398609893 35.209 35.66892529188517 139.73854883107953 35.209 35.66892387835635 139.73855089836343 35.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2813e260-86ad-4ba9-a6e8-9ccaaa11bbfa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2813e260-86ad-4ba9-a6e8-9ccaaa11bbfa_0">
											<gml:posList>35.66894663123514 139.73845070577948 34.564 35.66894663123514 139.73845070577948 36.138 35.668954019437265 139.73845826358968 36.138 35.668954019437265 139.73845826358968 34.564 35.66894663123514 139.73845070577948 34.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-03114906-6c0a-41d0-9fae-56848a8a888e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-03114906-6c0a-41d0-9fae-56848a8a888e_0">
											<gml:posList>35.66894663123514 139.73845070577948 34.564 35.66894076106687 139.73845931760735 34.564 35.66894076106687 139.73845931760735 36.138 35.66894663123514 139.73845070577948 36.138 35.66894663123514 139.73845070577948 34.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d17e4de-46cc-4f84-92e4-0ff499b053c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3d17e4de-46cc-4f84-92e4-0ff499b053c9_0">
											<gml:posList>35.668975351467445 139.73845385306046 40.493 35.668984363453845 139.73846307690846 40.493 35.668984363453845 139.73846307690846 37.789 35.668975351467445 139.73845385306046 37.789 35.668975351467445 139.73845385306046 40.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9c99b91b-890c-4c2d-8d0e-2b5fb3ecb3ff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9c99b91b-890c-4c2d-8d0e-2b5fb3ecb3ff_0">
											<gml:posList>35.66894873449048 139.73846602417862 36.138 35.668954019437265 139.73845826358968 36.138 35.66894663123514 139.73845070577948 36.138 35.66894076106687 139.73845931760735 36.138 35.66894814927718 139.73846688646387 36.138 35.66894873449048 139.73846602417862 36.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-787da672-5484-4677-bc66-f25f41959b6d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-787da672-5484-4677-bc66-f25f41959b6d_0">
											<gml:posList>35.668975351467445 139.73845385306046 37.789 35.66896522272432 139.73846871095625 37.789 35.66896522272432 139.73846871095625 40.493 35.668975351467445 139.73845385306046 40.493 35.668975351467445 139.73845385306046 37.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2bc954f8-7498-4116-8f58-28973a41116d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2bc954f8-7498-4116-8f58-28973a41116d_0">
											<gml:posList>35.668954019437265 139.73845826358968 34.564 35.668954019437265 139.73845826358968 36.138 35.66894873449048 139.73846602417862 36.138 35.66894873449048 139.73846602417862 34.564 35.668954019437265 139.73845826358968 34.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c830f561-b1f3-494e-aa23-1c262abc9290">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c830f561-b1f3-494e-aa23-1c262abc9290_0">
											<gml:posList>35.66894076106687 139.73845931760735 34.564 35.66894814927718 139.73846688646387 34.564 35.66894814927718 139.73846688646387 36.138 35.66894076106687 139.73845931760735 36.138 35.66894076106687 139.73845931760735 34.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-beb7adeb-55db-4dcd-874c-a549463c4753">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-beb7adeb-55db-4dcd-874c-a549463c4753_0">
											<gml:posList>35.668984363453845 139.73846307690846 40.493 35.668975351467445 139.73845385306046 40.493 35.66896522272432 139.73846871095625 40.493 35.66897422569587 139.73847793481548 40.493 35.668984363453845 139.73846307690846 40.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-34e13cfc-937d-427b-b5a6-1695d6f9cdec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-34e13cfc-937d-427b-b5a6-1695d6f9cdec_0">
											<gml:posList>35.66894814927718 139.73846688646387 34.564 35.66894873449048 139.73846602417862 34.564 35.66894873449048 139.73846602417862 36.138 35.66894814927718 139.73846688646387 36.138 35.66894814927718 139.73846688646387 34.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d2f23eb-a123-47ef-be73-9174447dd6b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d2f23eb-a123-47ef-be73-9174447dd6b8_0">
											<gml:posList>35.66897422569587 139.73847793481548 37.789 35.668984363453845 139.73846307690846 37.789 35.668984363453845 139.73846307690846 40.493 35.66897422569587 139.73847793481548 40.493 35.66897422569587 139.73847793481548 37.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef18f826-7c9f-4633-b497-3ac71dbaf51a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef18f826-7c9f-4633-b497-3ac71dbaf51a_0">
											<gml:posList>35.66896522272432 139.73846871095625 37.789 35.66897422569587 139.73847793481548 37.789 35.66897422569587 139.73847793481548 40.493 35.66896522272432 139.73846871095625 40.493 35.66896522272432 139.73846871095625 37.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d78081a3-9db9-4595-a871-33b5d7a949ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d78081a3-9db9-4595-a871-33b5d7a949ca_0">
											<gml:posList>35.66889255466833 139.73851532291187 35.209 35.668891141148784 139.73851740124158 35.209 35.668891141148784 139.73851740124158 35.727 35.66889570583606 139.73851070193462 35.727 35.66889570583606 139.73851070193462 34.564 35.66889255466833 139.73851532291187 34.564 35.66889255466833 139.73851532291187 35.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5ec8efb-750e-46d3-b23e-a901cb68fd8a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c5ec8efb-750e-46d3-b23e-a901cb68fd8a_0">
											<gml:posList>35.66890506964049 139.73852028988372 34.564 35.66889570583606 139.73851070193462 34.564 35.66889570583606 139.73851070193462 35.727 35.66890506964049 139.73852028988372 35.727 35.66890506964049 139.73852028988372 34.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-69529a9d-71f5-42f9-81cf-5f98a3a8ea71">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-69529a9d-71f5-42f9-81cf-5f98a3a8ea71_0">
											<gml:posList>35.668900504952695 139.73852698919092 35.727 35.66890506964049 139.73852028988372 35.727 35.66889570583606 139.73851070193462 35.727 35.668891141148784 139.73851740124158 35.727 35.668900504952695 139.73852698919092 35.727</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4ddab6e-6423-4caa-a29b-39724cba8f26">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4ddab6e-6423-4caa-a29b-39724cba8f26_0">
											<gml:posList>35.668901927486125 139.7385249108505 35.209 35.66889255466833 139.73851532291187 35.209 35.66889255466833 139.73851532291187 34.564 35.668901927486125 139.7385249108505 34.564 35.668901927486125 139.7385249108505 35.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8b3bd3b-ebfa-41fd-9819-7a18c657c77d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d8b3bd3b-ebfa-41fd-9819-7a18c657c77d_0">
											<gml:posList>35.668891141148784 139.73851740124158 35.727 35.668891141148784 139.73851740124158 35.209 35.668900504952695 139.73852698919092 35.209 35.668900504952695 139.73852698919092 35.727 35.668891141148784 139.73851740124158 35.727</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46d6afdb-fce3-4ae0-9b58-4dd6f934d02d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46d6afdb-fce3-4ae0-9b58-4dd6f934d02d_0">
											<gml:posList>35.668900504952695 139.73852698919092 35.209 35.668901927486125 139.7385249108505 35.209 35.668901927486125 139.7385249108505 34.564 35.66890506964049 139.73852028988372 34.564 35.66890506964049 139.73852028988372 35.727 35.668900504952695 139.73852698919092 35.727 35.668900504952695 139.73852698919092 35.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f53a894-0401-4fb6-8b60-a33f72a96091">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0f53a894-0401-4fb6-8b60-a33f72a96091_0">
											<gml:posList>35.668916532489526 139.7385398609893 35.209 35.66891511896956 139.73854193931922 35.209 35.66891511896956 139.73854193931922 35.727 35.668920169842735 139.73853453248913 35.727 35.668920169842735 139.73853453248913 34.564 35.668916532489526 139.7385398609893 34.564 35.668916532489526 139.7385398609893 35.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f36fafc-a807-40e9-81e8-698bfadaee4b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f36fafc-a807-40e9-81e8-698bfadaee4b_0">
											<gml:posList>35.668928929238774 139.73854350257915 34.564 35.668920169842735 139.73853453248913 34.564 35.668920169842735 139.73853453248913 35.727 35.668928929238774 139.73854350257915 35.727 35.668928929238774 139.73854350257915 34.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-89d993f4-8e71-46f0-bb44-5faa23b3e118">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-89d993f4-8e71-46f0-bb44-5faa23b3e118_0">
											<gml:posList>35.668928929238774 139.73854350257915 35.727 35.668920169842735 139.73853453248913 35.727 35.66891511896956 139.73854193931922 35.727 35.66892387835635 139.73855089836343 35.727 35.668928929238774 139.73854350257915 35.727</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5ce603c9-d1b7-4a71-99b3-d20277c8ef94">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5ce603c9-d1b7-4a71-99b3-d20277c8ef94_0">
											<gml:posList>35.66892529188517 139.73854883107953 35.209 35.668916532489526 139.7385398609893 35.209 35.668916532489526 139.7385398609893 34.564 35.66892529188517 139.73854883107953 34.564 35.66892529188517 139.73854883107953 35.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b5a9c06-dcca-49f0-9b83-5ff5f1a92f1b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2b5a9c06-dcca-49f0-9b83-5ff5f1a92f1b_0">
											<gml:posList>35.66891511896956 139.73854193931922 35.727 35.66891511896956 139.73854193931922 35.209 35.66892387835635 139.73855089836343 35.209 35.66892387835635 139.73855089836343 35.727 35.66891511896956 139.73854193931922 35.727</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4d53361-e599-429d-9c00-a0152ba107d0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4d53361-e599-429d-9c00-a0152ba107d0_0">
											<gml:posList>35.668928929238774 139.73854350257915 34.564 35.668928929238774 139.73854350257915 35.727 35.66892387835635 139.73855089836343 35.727 35.66892387835635 139.73855089836343 35.209 35.66892529188517 139.73854883107953 35.209 35.66892529188517 139.73854883107953 34.564 35.668928929238774 139.73854350257915 34.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_6033de74-0d00-4afc-9497-e90a321d093f_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53a02853-2e05-4423-9489-b3716682bcdc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668888940443075 139.73845846210088 34.564 35.668902328262284 139.73843866277414 34.564 35.66891511996852 139.73845164884483 34.564 35.66890173214719 139.73847144817253 34.564 35.668888940443075 139.73845846210088 34.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2517cec2-51fe-4729-890d-46b51f7fec74">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2517cec2-51fe-4729-890d-46b51f7fec74_0">
											<gml:posList>35.668902328262284 139.73843866277414 34.564 35.668902328262284 139.73843866277414 37.439 35.66891511996852 139.73845164884483 37.439 35.66891511996852 139.73845164884483 34.564 35.668902328262284 139.73843866277414 34.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c570d185-cb07-4c1e-9582-1fe51f761573">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c570d185-cb07-4c1e-9582-1fe51f761573_0">
											<gml:posList>35.668888940443075 139.73845846210088 34.564 35.668888940443075 139.73845846210088 37.439 35.668902328262284 139.73843866277414 37.439 35.668902328262284 139.73843866277414 34.564 35.668888940443075 139.73845846210088 34.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c4a09cc9-67c5-41db-8956-5e507ebba69a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c4a09cc9-67c5-41db-8956-5e507ebba69a_0">
											<gml:posList>35.66891511996852 139.73845164884483 37.439 35.668902328262284 139.73843866277414 37.439 35.668888940443075 139.73845846210088 37.439 35.66890173214719 139.73847144817253 37.439 35.66891511996852 139.73845164884483 37.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13cb04e7-d2e1-4840-91da-28b141a3f778">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-13cb04e7-d2e1-4840-91da-28b141a3f778_0">
											<gml:posList>35.66891511996852 139.73845164884483 34.564 35.66891511996852 139.73845164884483 37.439 35.66890173214719 139.73847144817253 37.439 35.66890173214719 139.73847144817253 34.564 35.66891511996852 139.73845164884483 34.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-413bcb64-e461-4d69-84c8-ef45049ac7ba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-413bcb64-e461-4d69-84c8-ef45049ac7ba_0">
											<gml:posList>35.66890173214719 139.73847144817253 34.564 35.66890173214719 139.73847144817253 37.439 35.668888940443075 139.73845846210088 37.439 35.668888940443075 139.73845846210088 34.564 35.66890173214719 139.73847144817253 34.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_6033de74-0d00-4afc-9497-e90a321d093f_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-997a45e0-b957-4327-9fab-0da8da0bab21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668897917727215 139.7384122126922 15.72 35.66892075917529 139.73837873818783 15.72 35.66894142632256 139.73839990005797 15.72 35.66891852186837 139.73843349614617 15.72 35.668897917727215 139.7384122126922 15.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b5087ee-6e8b-45ac-b1a7-f13ed7fc751b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b5087ee-6e8b-45ac-b1a7-f13ed7fc751b_0">
											<gml:posList>35.668897917727215 139.7384122126922 15.72 35.66891852186837 139.73843349614617 15.72 35.66891852186837 139.73843349614617 34.97 35.668897917727215 139.7384122126922 34.97 35.668897917727215 139.7384122126922 15.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fff58057-8079-4635-92aa-30c287720462">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fff58057-8079-4635-92aa-30c287720462_0">
											<gml:posList>35.668897917727215 139.7384122126922 15.72 35.668897917727215 139.7384122126922 34.97 35.66892075917529 139.73837873818783 34.97 35.66892075917529 139.73837873818783 15.72 35.668897917727215 139.7384122126922 15.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3aeab2c7-74b0-49c7-868b-1576b7dd0b9b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3aeab2c7-74b0-49c7-868b-1576b7dd0b9b_0">
											<gml:posList>35.668897917727215 139.7384122126922 34.97 35.66891852186837 139.73843349614617 34.97 35.66894142632256 139.73839990005797 34.97 35.66892075917529 139.73837873818783 34.97 35.668897917727215 139.7384122126922 34.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f41ef641-cff3-418f-936b-7dc547f1adf4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f41ef641-cff3-418f-936b-7dc547f1adf4_0">
											<gml:posList>35.66894142632256 139.73839990005797 34.97 35.66891852186837 139.73843349614617 34.97 35.66891852186837 139.73843349614617 15.72 35.66894142632256 139.73839990005797 15.72 35.66894142632256 139.73839990005797 34.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63a762f7-296e-40e2-b6d2-fc2f46153c8e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-63a762f7-296e-40e2-b6d2-fc2f46153c8e_0">
											<gml:posList>35.66892075917529 139.73837873818783 34.97 35.66894142632256 139.73839990005797 34.97 35.66894142632256 139.73839990005797 15.72 35.66892075917529 139.73837873818783 15.72 35.66892075917529 139.73837873818783 34.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-8ff48b29-c99e-4126-bf79-2dcd4a5cb015">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ff48b29-c99e-4126-bf79-2dcd4a5cb015">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ff48b29-c99e-4126-bf79-2dcd4a5cb015">
											<gml:posList>35.66903051808022 139.73857158310707 15.72 35.6689949548012 139.7386236521194 15.72 35.668852874046316 139.7384782330194 15.72 35.668897917727215 139.7384122126922 15.72 35.66891852186837 139.73843349614617 15.72 35.66894142632256 139.73839990005797 15.72 35.66906085546382 139.73852217128675 15.72 35.6690443793933 139.73854638167373 15.72 35.66905736967649 139.73855973207037 15.72 35.66904152377683 139.73858294755715 15.72 35.66903051808022 139.73857158310707 15.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-882f4507-2351-45c1-b72d-3ddb92191d81">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-882f4507-2351-45c1-b72d-3ddb92191d81">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-882f4507-2351-45c1-b72d-3ddb92191d81">
											<gml:posList>35.668898191160345 139.7384160453496 35.209 35.668897917727215 139.7384122126922 35.209 35.668852874046316 139.7384782330194 35.209 35.66885598351152 139.7384778869134 35.209 35.668898191160345 139.7384160453496 35.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f834c95f-8a79-403d-b225-428dc0cd6baf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f834c95f-8a79-403d-b225-428dc0cd6baf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f834c95f-8a79-403d-b225-428dc0cd6baf">
											<gml:posList>35.66885598351152 139.7384778869134 35.209 35.668852874046316 139.7384782330194 35.209 35.66895474821855 139.7385824977964 35.209 35.668954086913736 139.738578301074 35.209 35.66885598351152 139.7384778869134 35.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c913bf35-b62d-4a05-bcbd-2e8e8e8e0911">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c913bf35-b62d-4a05-bcbd-2e8e8e8e0911">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c913bf35-b62d-4a05-bcbd-2e8e8e8e0911">
											<gml:posList>35.668898191160345 139.7384160453496 35.209 35.668918795300826 139.73843732880465 35.209 35.66891852186837 139.73843349614617 35.209 35.668897917727215 139.7384122126922 35.209 35.668898191160345 139.7384160453496 35.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-acea02ca-c29a-4f58-9b4a-e852c897d254">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-acea02ca-c29a-4f58-9b4a-e852c897d254">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-acea02ca-c29a-4f58-9b4a-e852c897d254">
											<gml:posList>35.66894170876111 139.73840372166072 35.209 35.66894142632256 139.73839990005797 35.209 35.66891852186837 139.73843349614617 35.209 35.668918795300826 139.73843732880465 35.209 35.66894170876111 139.73840372166072 35.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1d3b8651-1bf4-4e04-866f-0817417e52c3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d3b8651-1bf4-4e04-866f-0817417e52c3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d3b8651-1bf4-4e04-866f-0817417e52c3">
											<gml:posList>35.668918795300826 139.73843732880465 34.564 35.668898191160345 139.7384160453496 34.564 35.66885598351152 139.7384778869134 34.564 35.668954086913736 139.738578301074 34.564 35.66898689275315 139.73850433097718 34.564 35.669009203965715 139.73847282328967 34.564 35.668994012583454 139.73845726630586 34.564 35.668971018080626 139.73849099505904 34.564 35.66894787017372 139.73846729549837 34.564 35.66897085566497 139.73843357780487 34.564 35.66894170876111 139.73840372166072 34.564 35.668918795300826 139.73843732880465 34.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-930a282d-f63e-4b7f-89e2-a3d6735894bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-930a282d-f63e-4b7f-89e2-a3d6735894bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-930a282d-f63e-4b7f-89e2-a3d6735894bd">
											<gml:posList>35.668972278188065 139.7384314884149 35.209 35.66894142632256 139.73839990005797 35.209 35.66894170876111 139.73840372166072 35.209 35.66897085566497 139.73843357780487 35.209 35.668972278188065 139.7384314884149 35.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d6800ac0-a6a7-4e45-be63-a657b7c409c6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d6800ac0-a6a7-4e45-be63-a657b7c409c6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d6800ac0-a6a7-4e45-be63-a657b7c409c6">
											<gml:posList>35.668950213541876 139.7384670386664 39.545 35.66894787017372 139.73846729549837 39.545 35.668971018080626 139.73849099505904 39.545 35.66897081752531 139.7384881343654 39.545 35.668950213541876 139.7384670386664 39.545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-978315eb-17d6-4cab-b111-93037579aefe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-978315eb-17d6-4cab-b111-93037579aefe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-978315eb-17d6-4cab-b111-93037579aefe">
											<gml:posList>35.66897248776716 139.73843436014383 39.545 35.668972278188065 139.7384314884149 39.545 35.66894787017372 139.73846729549837 39.545 35.668950213541876 139.7384670386664 39.545 35.66897248776716 139.73843436014383 39.545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f4bad43c-0972-435b-861c-68e891196917">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4bad43c-0972-435b-861c-68e891196917">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4bad43c-0972-435b-861c-68e891196917">
											<gml:posList>35.668971047229995 139.73859672795984 32.257 35.66895669482665 139.7385820426075 32.257 35.66895474821855 139.7385824977964 32.257 35.66897148217432 139.73859963256106 32.257 35.668971047229995 139.73859672795984 32.257</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-762c5b3d-495e-4360-b974-d384dacd6160">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-762c5b3d-495e-4360-b974-d384dacd6160">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-762c5b3d-495e-4360-b974-d384dacd6160">
											<gml:posList>35.668954086913736 139.738578301074 35.209 35.66895474821855 139.7385824977964 35.209 35.668988723765736 139.7385058863072 35.209 35.66898689275315 139.73850433097718 35.209 35.668954086913736 139.738578301074 35.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6f55f38e-57a1-445a-abe9-c7d35835a89b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f55f38e-57a1-445a-abe9-c7d35835a89b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f55f38e-57a1-445a-abe9-c7d35835a89b">
											<gml:posList>35.668950213541876 139.7384670386664 37.789 35.66897081752531 139.7384881343654 37.789 35.66899310076995 139.7384554558296 37.789 35.66897248776716 139.73843436014383 37.789 35.668950213541876 139.7384670386664 37.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2525476b-fe57-4efc-b41b-d3e96eec2c0d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2525476b-fe57-4efc-b41b-d3e96eec2c0d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2525476b-fe57-4efc-b41b-d3e96eec2c0d">
											<gml:posList>35.66895669482665 139.7385820426075 32.257 35.66898999555333 139.73850696731773 32.257 35.668988723765736 139.7385058863072 32.257 35.66895474821855 139.7385824977964 32.257 35.66895669482665 139.7385820426075 32.257</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4d1eef62-700a-4224-bed1-336902263f71">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d1eef62-700a-4224-bed1-336902263f71">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d1eef62-700a-4224-bed1-336902263f71">
											<gml:posList>35.66898837595919 139.73861369633735 28.982 35.668974050625174 139.73859904408502 28.982 35.66897148217432 139.73859963256106 28.982 35.66898895583516 139.73861750654567 28.982 35.66898837595919 139.73861369633735 28.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4ee96823-f010-4fab-a6ef-80865548ba04">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ee96823-f010-4fab-a6ef-80865548ba04">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ee96823-f010-4fab-a6ef-80865548ba04">
											<gml:posList>35.66897081752531 139.7384881343654 39.545 35.668971018080626 139.73849099505904 39.545 35.668995435115654 139.73845518796176 39.545 35.66899310076995 139.7384554558296 39.545 35.66897081752531 139.7384881343654 39.545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9af921e9-b221-45cd-b29d-c6250cf0b3f5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9af921e9-b221-45cd-b29d-c6250cf0b3f5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9af921e9-b221-45cd-b29d-c6250cf0b3f5">
											<gml:posList>35.66899310076995 139.7384554558296 39.545 35.668995435115654 139.73845518796176 39.545 35.668972278188065 139.7384314884149 39.545 35.66897248776716 139.73843436014383 39.545 35.66899310076995 139.7384554558296 39.545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b3ea1c30-caf0-46a9-a66c-70b00ea9f381">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b3ea1c30-caf0-46a9-a66c-70b00ea9f381">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b3ea1c30-caf0-46a9-a66c-70b00ea9f381">
											<gml:posList>35.668971047229995 139.73859672795984 32.257 35.66897148217432 139.73859963256106 32.257 35.66900413603711 139.73852724222454 32.257 35.66900286429318 139.73852621644377 32.257 35.668971047229995 139.73859672795984 32.257</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a11efa9a-b1b8-421d-bb0d-1c724af2a97a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a11efa9a-b1b8-421d-bb0d-1c724af2a97a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a11efa9a-b1b8-421d-bb0d-1c724af2a97a">
											<gml:posList>35.668974050625174 139.73859904408502 28.982 35.66900580469798 139.73852866519456 28.982 35.66900413603711 139.73852724222454 28.982 35.66897148217432 139.73859963256106 28.982 35.668974050625174 139.73859904408502 28.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0a9ec632-c24f-4ca6-93f5-61eda7b7cbbe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a9ec632-c24f-4ca6-93f5-61eda7b7cbbe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a9ec632-c24f-4ca6-93f5-61eda7b7cbbe">
											<gml:posList>35.66898999555333 139.73850696731773 31.55 35.66895669482665 139.7385820426075 31.55 35.668971047229995 139.73859672795984 31.55 35.66900286429318 139.73852621644377 31.55 35.669026460306604 139.73848941616757 31.55 35.66901253186602 139.73847515007344 31.55 35.66898999555333 139.73850696731773 31.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6f9b9464-8aa3-49b3-bcb7-178c92b51dd7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f9b9464-8aa3-49b3-bcb7-178c92b51dd7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f9b9464-8aa3-49b3-bcb7-178c92b51dd7">
											<gml:posList>35.669009203965715 139.73847282328967 35.209 35.66898689275315 139.73850433097718 35.209 35.668988723765736 139.7385058863072 35.209 35.66901235853424 139.73847252131364 35.209 35.669009203965715 139.73847282328967 35.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-487430b5-2640-46b0-8478-84e6094563c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-487430b5-2640-46b0-8478-84e6094563c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-487430b5-2640-46b0-8478-84e6094563c7">
											<gml:posList>35.66901253186602 139.73847515007344 32.257 35.66901235853424 139.73847252131364 32.257 35.668988723765736 139.7385058863072 32.257 35.66898999555333 139.73850696731773 32.257 35.66901253186602 139.73847515007344 32.257</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2299a745-8e9a-49bd-9293-52e21d955863">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2299a745-8e9a-49bd-9293-52e21d955863">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2299a745-8e9a-49bd-9293-52e21d955863">
											<gml:posList>35.668995435115654 139.73845518796176 35.209 35.668994012583454 139.73845726630586 35.209 35.669009203965715 139.73847282328967 35.209 35.66901235853424 139.73847252131364 35.209 35.668995435115654 139.73845518796176 35.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9e0b0c02-ebf6-4d82-864a-8975ebd7b060">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e0b0c02-ebf6-4d82-864a-8975ebd7b060">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e0b0c02-ebf6-4d82-864a-8975ebd7b060">
											<gml:posList>35.66898837595919 139.73861369633735 28.982 35.66898895583516 139.73861750654567 28.982 35.66902247287835 139.73854238680033 28.982 35.66902079523 139.7385409969786 28.982 35.66898837595919 139.73861369633735 28.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f877ccbd-1005-438b-b03d-f3f773e5216d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f877ccbd-1005-438b-b03d-f3f773e5216d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f877ccbd-1005-438b-b03d-f3f773e5216d">
											<gml:posList>35.66899079430475 139.73861708462334 25.598 35.669023690496324 139.7385433574152 25.598 35.66902247287835 139.73854238680033 25.598 35.66898895583516 139.73861750654567 25.598 35.66899079430475 139.73861708462334 25.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a460216c-0160-4784-aad3-48f92d36b316">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a460216c-0160-4784-aad3-48f92d36b316">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a460216c-0160-4784-aad3-48f92d36b316">
											<gml:posList>35.66900580469798 139.73852866519456 28.483 35.668974050625174 139.73859904408502 28.483 35.66898837595919 139.73861369633735 28.483 35.66902079523 139.7385409969786 28.483 35.66904373614272 139.73850787581625 28.483 35.66902888756497 139.738492671888 28.483 35.66900580469798 139.73852866519456 28.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f4bfee71-483c-4e15-b177-7f0e8194eb92">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4bfee71-483c-4e15-b177-7f0e8194eb92">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4bfee71-483c-4e15-b177-7f0e8194eb92">
											<gml:posList>35.6689947815943 139.73862117800465 25.598 35.6689949548012 139.7386236521194 25.598 35.66903051808022 139.73857158310707 25.598 35.669029345487644 139.7385705572081 25.598 35.6689947815943 139.73862117800465 25.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-35ce3801-abd3-4b1e-9410-a568a28069be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-35ce3801-abd3-4b1e-9410-a568a28069be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-35ce3801-abd3-4b1e-9410-a568a28069be">
											<gml:posList>35.669026460306604 139.73848941616757 32.257 35.66900286429318 139.73852621644377 32.257 35.66900413603711 139.73852724222454 32.257 35.66902858732801 139.73848913749978 32.257 35.669026460306604 139.73848941616757 32.257</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-374c59a6-f05b-413b-8d45-f7f829b4b61a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-374c59a6-f05b-413b-8d45-f7f829b4b61a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-374c59a6-f05b-413b-8d45-f7f829b4b61a">
											<gml:posList>35.66902888756497 139.738492671888 28.982 35.66902858732801 139.73848913749978 28.982 35.66900413603711 139.73852724222454 28.982 35.66900580469798 139.73852866519456 28.982 35.66902888756497 139.738492671888 28.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-949c303b-d4e9-40e0-a154-b5d75f8a9644">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-949c303b-d4e9-40e0-a154-b5d75f8a9644">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-949c303b-d4e9-40e0-a154-b5d75f8a9644">
											<gml:posList>35.669026460306604 139.73848941616757 32.257 35.66902858732801 139.73848913749978 32.257 35.66901235853424 139.73847252131364 32.257 35.66901253186602 139.73847515007344 32.257 35.669026460306604 139.73848941616757 32.257</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c76ccaf6-71d9-4dd5-a3d8-7503dfea4d29">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c76ccaf6-71d9-4dd5-a3d8-7503dfea4d29">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c76ccaf6-71d9-4dd5-a3d8-7503dfea4d29">
											<gml:posList>35.6689947815943 139.73862117800465 24.877 35.669029345487644 139.7385705572081 24.877 35.669036554552974 139.73855666377287 24.877 35.66904324282062 139.73854531154802 24.877 35.669058836572255 139.73852240564162 24.877 35.669046766467666 139.73851004830937 24.877 35.669023690496324 139.7385433574152 24.877 35.66899079430475 139.73861708462334 24.877 35.6689947815943 139.73862117800465 24.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a78439cb-6431-47cc-8c38-dfdc72dc1adf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a78439cb-6431-47cc-8c38-dfdc72dc1adf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a78439cb-6431-47cc-8c38-dfdc72dc1adf">
											<gml:posList>35.669029345487644 139.7385705572081 25.598 35.66903051808022 139.73857158310707 25.598 35.66903774513834 139.73855764546616 25.598 35.669036554552974 139.73855666377287 25.598 35.669029345487644 139.7385705572081 25.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-77698d56-07ec-4fca-ab74-3ccf1519a5a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-77698d56-07ec-4fca-ab74-3ccf1519a5a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-77698d56-07ec-4fca-ab74-3ccf1519a5a9">
											<gml:posList>35.66904373614272 139.73850787581625 28.982 35.66902079523 139.7385409969786 28.982 35.66902247287835 139.73854238680033 28.982 35.66904659325842 139.73850757419328 28.982 35.66904373614272 139.73850787581625 28.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3a81ea49-8b8c-419f-a5c9-1093530b0bf0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a81ea49-8b8c-419f-a5c9-1093530b0bf0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a81ea49-8b8c-419f-a5c9-1093530b0bf0">
											<gml:posList>35.669046766467666 139.73851004830937 25.598 35.66904659325842 139.73850757419328 25.598 35.66902247287835 139.73854238680033 25.598 35.669023690496324 139.7385433574152 25.598 35.669046766467666 139.73851004830937 25.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-433044c9-fed4-40f5-a0c3-a077f6689ffc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-433044c9-fed4-40f5-a0c3-a077f6689ffc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-433044c9-fed4-40f5-a0c3-a077f6689ffc">
											<gml:posList>35.66904373614272 139.73850787581625 28.982 35.66904659325842 139.73850757419328 28.982 35.66902858732801 139.73848913749978 28.982 35.66902888756497 139.738492671888 28.982 35.66904373614272 139.73850787581625 28.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2513ff4a-944b-4fc2-bc4b-1d9b7dd04609">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2513ff4a-944b-4fc2-bc4b-1d9b7dd04609">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2513ff4a-944b-4fc2-bc4b-1d9b7dd04609">
											<gml:posList>35.669036554552974 139.73855666377287 25.598 35.66903774513834 139.73855764546616 25.598 35.6690443793933 139.73854638167373 25.598 35.66904324282062 139.73854531154802 25.598 35.669036554552974 139.73855666377287 25.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e4d9669e-1e9e-4879-9c37-51deee09e85f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e4d9669e-1e9e-4879-9c37-51deee09e85f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e4d9669e-1e9e-4879-9c37-51deee09e85f">
											<gml:posList>35.66904152377683 139.73858294755715 21.128 35.66905736967649 139.73855973207037 21.128 35.6690443793933 139.73854638167373 21.128 35.66903774513834 139.73855764546616 21.128 35.66903051808022 139.73857158310707 21.128 35.66904152377683 139.73858294755715 21.128</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6172394e-4aaa-4fb7-a0d0-23c850516b3f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6172394e-4aaa-4fb7-a0d0-23c850516b3f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6172394e-4aaa-4fb7-a0d0-23c850516b3f">
											<gml:posList>35.669058836572255 139.73852240564162 25.598 35.66904324282062 139.73854531154802 25.598 35.6690443793933 139.73854638167373 25.598 35.66906085546382 139.73852217128675 25.598 35.669058836572255 139.73852240564162 25.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f3944c82-1024-4ef7-a331-204e55ccb3b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f3944c82-1024-4ef7-a331-204e55ccb3b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f3944c82-1024-4ef7-a331-204e55ccb3b8">
											<gml:posList>35.669058836572255 139.73852240564162 25.598 35.66906085546382 139.73852217128675 25.598 35.66904659325842 139.73850757419328 25.598 35.669046766467666 139.73851004830937 25.598 35.669058836572255 139.73852240564162 25.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c5d58706-7e41-42f7-b1cb-1ee05d5a8886">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c5d58706-7e41-42f7-b1cb-1ee05d5a8886">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c5d58706-7e41-42f7-b1cb-1ee05d5a8886">
											<gml:posList>35.6689947815943 139.73862117800465 25.598 35.66899079430475 139.73861708462334 25.598 35.66898895583516 139.73861750654567 25.598 35.6689949548012 139.7386236521194 25.598 35.6689947815943 139.73862117800465 25.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ede722be-db46-46e5-8875-27cf4c88fab0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ede722be-db46-46e5-8875-27cf4c88fab0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ede722be-db46-46e5-8875-27cf4c88fab0">
											<gml:posList>35.66897248776716 139.73843436014383 37.789 35.66897248776716 139.73843436014383 39.545 35.668950213541876 139.7384670386664 39.545 35.668950213541876 139.7384670386664 37.789 35.66897248776716 139.73843436014383 37.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-221dfe30-e3dd-480c-b9ab-58ae2c1a9acc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-221dfe30-e3dd-480c-b9ab-58ae2c1a9acc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-221dfe30-e3dd-480c-b9ab-58ae2c1a9acc">
											<gml:posList>35.66897081752531 139.7384881343654 37.789 35.66897081752531 139.7384881343654 39.545 35.66899310076995 139.7384554558296 39.545 35.66899310076995 139.7384554558296 37.789 35.66897081752531 139.7384881343654 37.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8aeef402-60fd-48f5-8227-b161ff802b87">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8aeef402-60fd-48f5-8227-b161ff802b87">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8aeef402-60fd-48f5-8227-b161ff802b87">
											<gml:posList>35.668950213541876 139.7384670386664 37.789 35.668950213541876 139.7384670386664 39.545 35.66897081752531 139.7384881343654 39.545 35.66897081752531 139.7384881343654 37.789 35.668950213541876 139.7384670386664 37.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9ad03543-c1c3-4832-93c8-6b9ba8458c4a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ad03543-c1c3-4832-93c8-6b9ba8458c4a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ad03543-c1c3-4832-93c8-6b9ba8458c4a">
											<gml:posList>35.66901253186602 139.73847515007344 31.55 35.66901253186602 139.73847515007344 32.257 35.66898999555333 139.73850696731773 32.257 35.66898999555333 139.73850696731773 31.55 35.66901253186602 139.73847515007344 31.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-634e00f8-90c1-428f-b1de-a9fe4e87ade2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-634e00f8-90c1-428f-b1de-a9fe4e87ade2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-634e00f8-90c1-428f-b1de-a9fe4e87ade2">
											<gml:posList>35.669046766467666 139.73851004830937 24.877 35.669046766467666 139.73851004830937 25.598 35.669023690496324 139.7385433574152 25.598 35.669023690496324 139.7385433574152 24.877 35.669046766467666 139.73851004830937 24.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b2f82f57-e247-4622-94b0-6a095c580387">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b2f82f57-e247-4622-94b0-6a095c580387">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b2f82f57-e247-4622-94b0-6a095c580387">
											<gml:posList>35.66891852186837 139.73843349614617 35.209 35.66894142632256 139.73839990005797 35.209 35.66894142632256 139.73839990005797 15.72 35.66891852186837 139.73843349614617 15.72 35.66891852186837 139.73843349614617 35.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5a9e45a3-6fa8-4825-b70a-83b47ea9a86f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a9e45a3-6fa8-4825-b70a-83b47ea9a86f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a9e45a3-6fa8-4825-b70a-83b47ea9a86f">
											<gml:posList>35.66897085566497 139.73843357780487 34.564 35.66897085566497 139.73843357780487 35.209 35.66894170876111 139.73840372166072 35.209 35.66894170876111 139.73840372166072 34.564 35.66897085566497 139.73843357780487 34.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-71ad0feb-40a9-4592-8be9-92be27a104b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-71ad0feb-40a9-4592-8be9-92be27a104b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-71ad0feb-40a9-4592-8be9-92be27a104b4">
											<gml:posList>35.66894170876111 139.73840372166072 34.564 35.66894170876111 139.73840372166072 35.209 35.668918795300826 139.73843732880465 35.209 35.668918795300826 139.73843732880465 34.564 35.66894170876111 139.73840372166072 34.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c5427a0e-74b1-443a-b31c-6bf8018feb6c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c5427a0e-74b1-443a-b31c-6bf8018feb6c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c5427a0e-74b1-443a-b31c-6bf8018feb6c">
											<gml:posList>35.668897917727215 139.7384122126922 35.209 35.66891852186837 139.73843349614617 35.209 35.66891852186837 139.73843349614617 15.72 35.668897917727215 139.7384122126922 15.72 35.668897917727215 139.7384122126922 35.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8d7dd8c8-1bb1-4ff0-958c-085bc4e217e5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d7dd8c8-1bb1-4ff0-958c-085bc4e217e5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d7dd8c8-1bb1-4ff0-958c-085bc4e217e5">
											<gml:posList>35.668918795300826 139.73843732880465 34.564 35.668918795300826 139.73843732880465 35.209 35.668898191160345 139.7384160453496 35.209 35.668898191160345 139.7384160453496 34.564 35.668918795300826 139.73843732880465 34.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-21513b89-8cba-4ff9-9d66-f8116b0a6ed1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21513b89-8cba-4ff9-9d66-f8116b0a6ed1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21513b89-8cba-4ff9-9d66-f8116b0a6ed1">
											<gml:posList>35.66899310076995 139.7384554558296 37.789 35.66899310076995 139.7384554558296 39.545 35.66897248776716 139.73843436014383 39.545 35.66897248776716 139.73843436014383 37.789 35.66899310076995 139.7384554558296 37.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e08e7d62-4e9d-4e8e-bba0-4e53d22a955b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e08e7d62-4e9d-4e8e-bba0-4e53d22a955b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e08e7d62-4e9d-4e8e-bba0-4e53d22a955b">
											<gml:posList>35.668852874046316 139.7384782330194 35.209 35.668897917727215 139.7384122126922 35.209 35.668897917727215 139.7384122126922 15.72 35.668852874046316 139.7384782330194 15.72 35.668852874046316 139.7384782330194 35.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-699a1676-71b8-4798-9c70-809731396ec2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-699a1676-71b8-4798-9c70-809731396ec2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-699a1676-71b8-4798-9c70-809731396ec2">
											<gml:posList>35.668898191160345 139.7384160453496 34.564 35.668898191160345 139.7384160453496 35.209 35.66885598351152 139.7384778869134 35.209 35.66885598351152 139.7384778869134 34.564 35.668898191160345 139.7384160453496 34.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5951c3e2-f9aa-4a17-b2ad-2562eab4a052">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5951c3e2-f9aa-4a17-b2ad-2562eab4a052">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5951c3e2-f9aa-4a17-b2ad-2562eab4a052">
											<gml:posList>35.668972278188065 139.7384314884149 39.545 35.668972278188065 139.7384314884149 35.209 35.66897085566497 139.73843357780487 35.209 35.66897085566497 139.73843357780487 34.564 35.66894787017372 139.73846729549837 34.564 35.66894787017372 139.73846729549837 39.545 35.668972278188065 139.7384314884149 39.545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a5481d12-43fc-45c3-93f3-8909b74a7fc9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5481d12-43fc-45c3-93f3-8909b74a7fc9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5481d12-43fc-45c3-93f3-8909b74a7fc9">
											<gml:posList>35.66902858732801 139.73848913749978 28.982 35.66904659325842 139.73850757419328 28.982 35.66904659325842 139.73850757419328 25.598 35.66906085546382 139.73852217128675 25.598 35.66906085546382 139.73852217128675 15.72 35.66894142632256 139.73839990005797 15.72 35.66894142632256 139.73839990005797 35.209 35.668972278188065 139.7384314884149 35.209 35.668972278188065 139.7384314884149 39.545 35.668995435115654 139.73845518796176 39.545 35.668995435115654 139.73845518796176 35.209 35.66901235853424 139.73847252131364 35.209 35.66901235853424 139.73847252131364 32.257 35.66902858732801 139.73848913749978 32.257 35.66902858732801 139.73848913749978 28.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-21134cce-2e60-4eb6-928c-899fbf38d843">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21134cce-2e60-4eb6-928c-899fbf38d843">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21134cce-2e60-4eb6-928c-899fbf38d843">
											<gml:posList>35.669009203965715 139.73847282328967 34.564 35.669009203965715 139.73847282328967 35.209 35.668994012583454 139.73845726630586 35.209 35.668994012583454 139.73845726630586 34.564 35.669009203965715 139.73847282328967 34.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fac7c7a2-184d-4095-8c5a-22075e534962">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fac7c7a2-184d-4095-8c5a-22075e534962">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fac7c7a2-184d-4095-8c5a-22075e534962">
											<gml:posList>35.668971018080626 139.73849099505904 34.564 35.668994012583454 139.73845726630586 34.564 35.668994012583454 139.73845726630586 35.209 35.668995435115654 139.73845518796176 35.209 35.668995435115654 139.73845518796176 39.545 35.668971018080626 139.73849099505904 39.545 35.668971018080626 139.73849099505904 34.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e844b1ad-7325-4ca5-bd0b-61881fed9a7e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e844b1ad-7325-4ca5-bd0b-61881fed9a7e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e844b1ad-7325-4ca5-bd0b-61881fed9a7e">
											<gml:posList>35.668971018080626 139.73849099505904 39.545 35.66894787017372 139.73846729549837 39.545 35.66894787017372 139.73846729549837 34.564 35.668971018080626 139.73849099505904 34.564 35.668971018080626 139.73849099505904 39.545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cc3eb393-6e31-401a-9701-21d9315b3684">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc3eb393-6e31-401a-9701-21d9315b3684">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc3eb393-6e31-401a-9701-21d9315b3684">
											<gml:posList>35.669026460306604 139.73848941616757 31.55 35.669026460306604 139.73848941616757 32.257 35.66901253186602 139.73847515007344 32.257 35.66901253186602 139.73847515007344 31.55 35.669026460306604 139.73848941616757 31.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-542ddd4f-65ef-4c7d-93a5-a3f8467284f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-542ddd4f-65ef-4c7d-93a5-a3f8467284f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-542ddd4f-65ef-4c7d-93a5-a3f8467284f2">
											<gml:posList>35.66898689275315 139.73850433097718 34.564 35.66898689275315 139.73850433097718 35.209 35.669009203965715 139.73847282328967 35.209 35.669009203965715 139.73847282328967 34.564 35.66898689275315 139.73850433097718 34.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b4de7300-6083-468d-bb90-893259a7a324">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b4de7300-6083-468d-bb90-893259a7a324">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b4de7300-6083-468d-bb90-893259a7a324">
											<gml:posList>35.668988723765736 139.7385058863072 35.209 35.668988723765736 139.7385058863072 32.257 35.66901235853424 139.73847252131364 32.257 35.66901235853424 139.73847252131364 35.209 35.668988723765736 139.7385058863072 35.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a5ab443c-1297-43d6-9937-88bb241527b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5ab443c-1297-43d6-9937-88bb241527b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5ab443c-1297-43d6-9937-88bb241527b3">
											<gml:posList>35.66904373614272 139.73850787581625 28.483 35.66904373614272 139.73850787581625 28.982 35.66902888756497 139.738492671888 28.982 35.66902888756497 139.738492671888 28.483 35.66904373614272 139.73850787581625 28.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d9ab6852-bdfa-464f-919f-68d6983f85a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d9ab6852-bdfa-464f-919f-68d6983f85a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d9ab6852-bdfa-464f-919f-68d6983f85a3">
											<gml:posList>35.66900286429318 139.73852621644377 31.55 35.66900286429318 139.73852621644377 32.257 35.669026460306604 139.73848941616757 32.257 35.669026460306604 139.73848941616757 31.55 35.66900286429318 139.73852621644377 31.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-46734a7c-3d92-4bea-bac4-48d781083797">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-46734a7c-3d92-4bea-bac4-48d781083797">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-46734a7c-3d92-4bea-bac4-48d781083797">
											<gml:posList>35.66900413603711 139.73852724222454 32.257 35.66900413603711 139.73852724222454 28.982 35.66902858732801 139.73848913749978 28.982 35.66902858732801 139.73848913749978 32.257 35.66900413603711 139.73852724222454 32.257</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-31bbc54c-cb56-4d19-834d-8111912ce71d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31bbc54c-cb56-4d19-834d-8111912ce71d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31bbc54c-cb56-4d19-834d-8111912ce71d">
											<gml:posList>35.66902888756497 139.738492671888 28.483 35.66902888756497 139.738492671888 28.982 35.66900580469798 139.73852866519456 28.982 35.66900580469798 139.73852866519456 28.483 35.66902888756497 139.738492671888 28.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-85b45113-5616-4144-8a1b-95f6eb906b9e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85b45113-5616-4144-8a1b-95f6eb906b9e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85b45113-5616-4144-8a1b-95f6eb906b9e">
											<gml:posList>35.669058836572255 139.73852240564162 24.877 35.669058836572255 139.73852240564162 25.598 35.669046766467666 139.73851004830937 25.598 35.669046766467666 139.73851004830937 24.877 35.669058836572255 139.73852240564162 24.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bf9445c2-f9cc-4ecb-9d6b-14640d9eaf42">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf9445c2-f9cc-4ecb-9d6b-14640d9eaf42">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf9445c2-f9cc-4ecb-9d6b-14640d9eaf42">
											<gml:posList>35.66902079523 139.7385409969786 28.483 35.66902079523 139.7385409969786 28.982 35.66904373614272 139.73850787581625 28.982 35.66904373614272 139.73850787581625 28.483 35.66902079523 139.7385409969786 28.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-24176140-9dcf-4352-bbee-7c3f0c1e513b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-24176140-9dcf-4352-bbee-7c3f0c1e513b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-24176140-9dcf-4352-bbee-7c3f0c1e513b">
											<gml:posList>35.66902247287835 139.73854238680033 28.982 35.66902247287835 139.73854238680033 25.598 35.66904659325842 139.73850757419328 25.598 35.66904659325842 139.73850757419328 28.982 35.66902247287835 139.73854238680033 28.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-06a7c5b3-6a36-4551-82ce-94ced859343f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-06a7c5b3-6a36-4551-82ce-94ced859343f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-06a7c5b3-6a36-4551-82ce-94ced859343f">
											<gml:posList>35.66885598351152 139.7384778869134 34.564 35.66885598351152 139.7384778869134 35.209 35.668954086913736 139.738578301074 35.209 35.668954086913736 139.738578301074 34.564 35.66885598351152 139.7384778869134 34.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c0521008-8d04-4cd5-aef3-0ab8661c98d9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0521008-8d04-4cd5-aef3-0ab8661c98d9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0521008-8d04-4cd5-aef3-0ab8661c98d9">
											<gml:posList>35.66904324282062 139.73854531154802 24.877 35.66904324282062 139.73854531154802 25.598 35.669058836572255 139.73852240564162 25.598 35.669058836572255 139.73852240564162 24.877 35.66904324282062 139.73854531154802 24.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b10b1afe-7667-49b1-9739-a0cb53873235">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b10b1afe-7667-49b1-9739-a0cb53873235">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b10b1afe-7667-49b1-9739-a0cb53873235">
											<gml:posList>35.66906085546382 139.73852217128675 25.598 35.6690443793933 139.73854638167373 25.598 35.6690443793933 139.73854638167373 21.128 35.6690443793933 139.73854638167373 15.72 35.66906085546382 139.73852217128675 15.72 35.66906085546382 139.73852217128675 25.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f0a944bd-ceeb-431c-aaee-3a17a35c500f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f0a944bd-ceeb-431c-aaee-3a17a35c500f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f0a944bd-ceeb-431c-aaee-3a17a35c500f">
											<gml:posList>35.668954086913736 139.738578301074 34.564 35.668954086913736 139.738578301074 35.209 35.66898689275315 139.73850433097718 35.209 35.66898689275315 139.73850433097718 34.564 35.668954086913736 139.738578301074 34.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f3b3dc91-9ae2-46ca-89c1-49a06fb65d02">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f3b3dc91-9ae2-46ca-89c1-49a06fb65d02">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f3b3dc91-9ae2-46ca-89c1-49a06fb65d02">
											<gml:posList>35.66895474821855 139.7385824977964 35.209 35.66895474821855 139.7385824977964 32.257 35.668988723765736 139.7385058863072 32.257 35.668988723765736 139.7385058863072 35.209 35.66895474821855 139.7385824977964 35.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5b8e43f1-2e95-4256-bf05-f56812b051b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b8e43f1-2e95-4256-bf05-f56812b051b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b8e43f1-2e95-4256-bf05-f56812b051b0">
											<gml:posList>35.66898999555333 139.73850696731773 31.55 35.66898999555333 139.73850696731773 32.257 35.66895669482665 139.7385820426075 32.257 35.66895669482665 139.7385820426075 31.55 35.66898999555333 139.73850696731773 31.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a00ea53d-b275-444f-a8a1-5a43aa5bd772">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a00ea53d-b275-444f-a8a1-5a43aa5bd772">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a00ea53d-b275-444f-a8a1-5a43aa5bd772">
											<gml:posList>35.6689949548012 139.7386236521194 15.72 35.6689949548012 139.7386236521194 25.598 35.66898895583516 139.73861750654567 25.598 35.66898895583516 139.73861750654567 28.982 35.66897148217432 139.73859963256106 28.982 35.66897148217432 139.73859963256106 32.257 35.66895474821855 139.7385824977964 32.257 35.66895474821855 139.7385824977964 35.209 35.668852874046316 139.7384782330194 35.209 35.668852874046316 139.7384782330194 15.72 35.6689949548012 139.7386236521194 15.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3bbfa3cd-2070-441c-9f1c-38acd86ef64b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3bbfa3cd-2070-441c-9f1c-38acd86ef64b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3bbfa3cd-2070-441c-9f1c-38acd86ef64b">
											<gml:posList>35.669036554552974 139.73855666377287 24.877 35.669036554552974 139.73855666377287 25.598 35.66904324282062 139.73854531154802 25.598 35.66904324282062 139.73854531154802 24.877 35.669036554552974 139.73855666377287 24.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3cdff4a5-ea8f-4c5b-8aac-cf190e388206">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3cdff4a5-ea8f-4c5b-8aac-cf190e388206">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3cdff4a5-ea8f-4c5b-8aac-cf190e388206">
											<gml:posList>35.66903774513834 139.73855764546616 21.128 35.6690443793933 139.73854638167373 21.128 35.6690443793933 139.73854638167373 25.598 35.66903774513834 139.73855764546616 25.598 35.66903774513834 139.73855764546616 21.128</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1df52d69-3d6c-4116-9ed4-ef42626ed7d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1df52d69-3d6c-4116-9ed4-ef42626ed7d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1df52d69-3d6c-4116-9ed4-ef42626ed7d4">
											<gml:posList>35.6690443793933 139.73854638167373 21.128 35.66905736967649 139.73855973207037 21.128 35.66905736967649 139.73855973207037 15.72 35.6690443793933 139.73854638167373 15.72 35.6690443793933 139.73854638167373 21.128</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d8521afe-1490-444e-9bfb-e7a056835205">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d8521afe-1490-444e-9bfb-e7a056835205">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d8521afe-1490-444e-9bfb-e7a056835205">
											<gml:posList>35.668971047229995 139.73859672795984 31.55 35.668971047229995 139.73859672795984 32.257 35.66900286429318 139.73852621644377 32.257 35.66900286429318 139.73852621644377 31.55 35.668971047229995 139.73859672795984 31.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a3d03a85-c5f2-43d7-a32d-c2a722e301ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a3d03a85-c5f2-43d7-a32d-c2a722e301ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a3d03a85-c5f2-43d7-a32d-c2a722e301ba">
											<gml:posList>35.66897148217432 139.73859963256106 32.257 35.66897148217432 139.73859963256106 28.982 35.66900413603711 139.73852724222454 28.982 35.66900413603711 139.73852724222454 32.257 35.66897148217432 139.73859963256106 32.257</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-918204ad-ef76-45e7-abc2-cc0fbfae1ae3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-918204ad-ef76-45e7-abc2-cc0fbfae1ae3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-918204ad-ef76-45e7-abc2-cc0fbfae1ae3">
											<gml:posList>35.669029345487644 139.7385705572081 24.877 35.669029345487644 139.7385705572081 25.598 35.669036554552974 139.73855666377287 25.598 35.669036554552974 139.73855666377287 24.877 35.669029345487644 139.7385705572081 24.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8b7bcebb-9345-49d5-9f90-ee449252134e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b7bcebb-9345-49d5-9f90-ee449252134e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b7bcebb-9345-49d5-9f90-ee449252134e">
											<gml:posList>35.66900580469798 139.73852866519456 28.483 35.66900580469798 139.73852866519456 28.982 35.668974050625174 139.73859904408502 28.982 35.668974050625174 139.73859904408502 28.483 35.66900580469798 139.73852866519456 28.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7658e567-3327-4ed2-8828-1f164c5d154e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7658e567-3327-4ed2-8828-1f164c5d154e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7658e567-3327-4ed2-8828-1f164c5d154e">
											<gml:posList>35.66903051808022 139.73857158310707 21.128 35.66903774513834 139.73855764546616 21.128 35.66903774513834 139.73855764546616 25.598 35.66903051808022 139.73857158310707 25.598 35.66903051808022 139.73857158310707 21.128</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8db1863b-adf1-40ea-bb56-c0deaa3d8492">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8db1863b-adf1-40ea-bb56-c0deaa3d8492">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8db1863b-adf1-40ea-bb56-c0deaa3d8492">
											<gml:posList>35.66905736967649 139.73855973207037 21.128 35.66904152377683 139.73858294755715 21.128 35.66904152377683 139.73858294755715 15.72 35.66905736967649 139.73855973207037 15.72 35.66905736967649 139.73855973207037 21.128</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ef15cf42-a6f4-4018-8094-ccbf39e3e8e1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef15cf42-a6f4-4018-8094-ccbf39e3e8e1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef15cf42-a6f4-4018-8094-ccbf39e3e8e1">
											<gml:posList>35.66904152377683 139.73858294755715 21.128 35.66903051808022 139.73857158310707 21.128 35.66903051808022 139.73857158310707 15.72 35.66904152377683 139.73858294755715 15.72 35.66904152377683 139.73858294755715 21.128</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a95c3d20-f805-4136-bb93-e8aede9a7282">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a95c3d20-f805-4136-bb93-e8aede9a7282">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a95c3d20-f805-4136-bb93-e8aede9a7282">
											<gml:posList>35.66898837595919 139.73861369633735 28.483 35.66898837595919 139.73861369633735 28.982 35.66902079523 139.7385409969786 28.982 35.66902079523 139.7385409969786 28.483 35.66898837595919 139.73861369633735 28.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fda3fb75-6b45-4ebe-990a-0989a21378d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fda3fb75-6b45-4ebe-990a-0989a21378d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fda3fb75-6b45-4ebe-990a-0989a21378d4">
											<gml:posList>35.66898895583516 139.73861750654567 28.982 35.66898895583516 139.73861750654567 25.598 35.66902247287835 139.73854238680033 25.598 35.66902247287835 139.73854238680033 28.982 35.66898895583516 139.73861750654567 28.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5d1a19b9-4278-4f55-8f64-d58ad38d3c49">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d1a19b9-4278-4f55-8f64-d58ad38d3c49">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d1a19b9-4278-4f55-8f64-d58ad38d3c49">
											<gml:posList>35.669023690496324 139.7385433574152 24.877 35.669023690496324 139.7385433574152 25.598 35.66899079430475 139.73861708462334 25.598 35.66899079430475 139.73861708462334 24.877 35.669023690496324 139.7385433574152 24.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-85a32bd1-4113-4e3a-a9d1-9ba36f63c2c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85a32bd1-4113-4e3a-a9d1-9ba36f63c2c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85a32bd1-4113-4e3a-a9d1-9ba36f63c2c2">
											<gml:posList>35.66895669482665 139.7385820426075 31.55 35.66895669482665 139.7385820426075 32.257 35.668971047229995 139.73859672795984 32.257 35.668971047229995 139.73859672795984 31.55 35.66895669482665 139.7385820426075 31.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-abf0b07e-1974-43a4-89fc-78c3aad66ebd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-abf0b07e-1974-43a4-89fc-78c3aad66ebd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-abf0b07e-1974-43a4-89fc-78c3aad66ebd">
											<gml:posList>35.6689947815943 139.73862117800465 24.877 35.6689947815943 139.73862117800465 25.598 35.669029345487644 139.7385705572081 25.598 35.669029345487644 139.7385705572081 24.877 35.6689947815943 139.73862117800465 24.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e583af28-ee35-4187-8207-fb8a4c0ea7d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e583af28-ee35-4187-8207-fb8a4c0ea7d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e583af28-ee35-4187-8207-fb8a4c0ea7d5">
											<gml:posList>35.6689949548012 139.7386236521194 25.598 35.6689949548012 139.7386236521194 15.72 35.66903051808022 139.73857158310707 15.72 35.66903051808022 139.73857158310707 21.128 35.66903051808022 139.73857158310707 25.598 35.6689949548012 139.7386236521194 25.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eacac7b1-cb82-4466-97d9-3f095b3a355e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eacac7b1-cb82-4466-97d9-3f095b3a355e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eacac7b1-cb82-4466-97d9-3f095b3a355e">
											<gml:posList>35.668974050625174 139.73859904408502 28.483 35.668974050625174 139.73859904408502 28.982 35.66898837595919 139.73861369633735 28.982 35.66898837595919 139.73861369633735 28.483 35.668974050625174 139.73859904408502 28.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-04d9d1c3-2f64-499c-b4e0-d32484b87cb0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04d9d1c3-2f64-499c-b4e0-d32484b87cb0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04d9d1c3-2f64-499c-b4e0-d32484b87cb0">
											<gml:posList>35.66899079430475 139.73861708462334 24.877 35.66899079430475 139.73861708462334 25.598 35.6689947815943 139.73862117800465 25.598 35.6689947815943 139.73862117800465 24.877 35.66899079430475 139.73861708462334 24.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5448</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">244.679</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>