<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_60a05338-8343-43e6-baa6-a002aa5d672a">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>霞が関三丁目南地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:measuredHeight uom="m">6.9</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.671278220494266 139.7466376468118 0 35.67123014417709 139.7465916354055 0 35.67121519826464 139.74661506989074 0 35.67126336471019 139.7466610812051 0 35.671278220494266 139.7466376468118 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671278220494266 139.7466376468118 7.4 35.67126336471019 139.7466610812051 7.4 35.67121519826464 139.74661506989074 7.4 35.67123014417709 139.7465916354055 7.4 35.671278220494266 139.7466376468118 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671278220494266 139.7466376468118 7.4 35.67123014417709 139.7465916354055 7.4 35.67123014417709 139.7465916354055 14.32 35.671278220494266 139.7466376468118 14.32 35.671278220494266 139.7466376468118 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67123014417709 139.7465916354055 7.4 35.67121519826464 139.74661506989074 7.4 35.67121519826464 139.74661506989074 14.32 35.67123014417709 139.7465916354055 14.32 35.67123014417709 139.7465916354055 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67121519826464 139.74661506989074 7.4 35.67126336471019 139.7466610812051 7.4 35.67126336471019 139.7466610812051 14.32 35.67121519826464 139.74661506989074 14.32 35.67121519826464 139.74661506989074 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67126336471019 139.7466610812051 7.4 35.671278220494266 139.7466376468118 7.4 35.671278220494266 139.7466376468118 14.32 35.67126336471019 139.7466610812051 14.32 35.67126336471019 139.7466610812051 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671278220494266 139.7466376468118 14.32 35.67123014417709 139.7465916354055 14.32 35.67121519826464 139.74661506989074 14.32 35.67126336471019 139.7466610812051 14.32 35.671278220494266 139.7466376468118 14.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-d66e3343-d695-442b-b812-e8ec09037e7b"/>
							<gml:surfaceMember xlink:href="#poly-d3475976-44c0-4c96-a3dc-5acf13191e05"/>
							<gml:surfaceMember xlink:href="#poly-a787da77-c7c2-4356-bcb4-5d1f997c9032"/>
							<gml:surfaceMember xlink:href="#poly-cabe060d-344e-4f31-9b53-4d014a31bbee"/>
							<gml:surfaceMember xlink:href="#poly-f384ba6c-2927-4632-aaec-bce44c13470b"/>
							<gml:surfaceMember xlink:href="#poly-b5326f64-04aa-49e4-bf0d-fd768392a460"/>
							<gml:surfaceMember xlink:href="#poly-bee0dbbc-e500-4000-a666-8ff6c29ce7b4"/>
							<gml:surfaceMember xlink:href="#poly-3826e35b-e3cb-44e4-b1b7-906907dc693d"/>
							<gml:surfaceMember xlink:href="#poly-b8b04f80-03d8-41c5-a689-51a8da869ccb"/>
							<gml:surfaceMember xlink:href="#poly-0ed86d0e-43c1-466d-a9a4-373a50b76575"/>
							<gml:surfaceMember xlink:href="#poly-e62ac6b0-8756-469f-b324-a6a7278878e2"/>
							<gml:surfaceMember xlink:href="#poly-1203a3e3-d496-4631-972e-d95a3e1733ce"/>
							<gml:surfaceMember xlink:href="#poly-11572da6-26fd-4c1a-a1f0-2f11719377f3"/>
							<gml:surfaceMember xlink:href="#poly-98c70f65-3504-4c4d-8eb3-11b5d212ddab"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-d66e3343-d695-442b-b812-e8ec09037e7b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d66e3343-d695-442b-b812-e8ec09037e7b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d66e3343-d695-442b-b812-e8ec09037e7b">
											<gml:posList>35.671278220494244 139.7466376468118 7.4 35.67126336471021 139.7466610812051 7.4 35.67121519826464 139.7466150698907 7.4 35.67123014417708 139.7465916354055 7.4 35.671278220494244 139.7466376468118 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d3475976-44c0-4c96-a3dc-5acf13191e05">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3475976-44c0-4c96-a3dc-5acf13191e05">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3475976-44c0-4c96-a3dc-5acf13191e05">
											<gml:posList>35.67121519826464 139.7466150698907 15 35.67121782998535 139.7466146693747 15 35.67123047100261 139.74659487164044 15 35.67123014417708 139.7465916354055 15 35.67121519826464 139.7466150698907 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a787da77-c7c2-4356-bcb4-5d1f997c9032">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a787da77-c7c2-4356-bcb4-5d1f997c9032">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a787da77-c7c2-4356-bcb4-5d1f997c9032">
											<gml:posList>35.67126336471021 139.7466610812051 15 35.67126302888069 139.74665785602468 15 35.67121782998535 139.7466146693747 15 35.67121519826464 139.7466150698907 15 35.67126336471021 139.7466610812051 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cabe060d-344e-4f31-9b53-4d014a31bbee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cabe060d-344e-4f31-9b53-4d014a31bbee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cabe060d-344e-4f31-9b53-4d014a31bbee">
											<gml:posList>35.671275579751814 139.74663803629073 14.844 35.67123047100261 139.74659487164044 14.844 35.67121782998535 139.7466146693747 14.844 35.67126302888069 139.74665785602468 14.844 35.671275579751814 139.74663803629073 14.844</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f384ba6c-2927-4632-aaec-bce44c13470b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f384ba6c-2927-4632-aaec-bce44c13470b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f384ba6c-2927-4632-aaec-bce44c13470b">
											<gml:posList>35.67123014417708 139.7465916354055 15 35.67123047100261 139.74659487164044 15 35.671275579751814 139.74663803629073 15 35.671278220494244 139.7466376468118 15 35.67123014417708 139.7465916354055 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b5326f64-04aa-49e4-bf0d-fd768392a460">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b5326f64-04aa-49e4-bf0d-fd768392a460">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b5326f64-04aa-49e4-bf0d-fd768392a460">
											<gml:posList>35.671278220494244 139.7466376468118 15 35.671275579751814 139.74663803629073 15 35.67126302888069 139.74665785602468 15 35.67126336471021 139.7466610812051 15 35.671278220494244 139.7466376468118 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bee0dbbc-e500-4000-a666-8ff6c29ce7b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bee0dbbc-e500-4000-a666-8ff6c29ce7b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bee0dbbc-e500-4000-a666-8ff6c29ce7b4">
											<gml:posList>35.67126302888069 139.74665785602468 15 35.67126302888069 139.74665785602468 14.844 35.67121782998535 139.7466146693747 14.844 35.67121782998535 139.7466146693747 15 35.67126302888069 139.74665785602468 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3826e35b-e3cb-44e4-b1b7-906907dc693d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3826e35b-e3cb-44e4-b1b7-906907dc693d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3826e35b-e3cb-44e4-b1b7-906907dc693d">
											<gml:posList>35.67123047100261 139.74659487164044 15 35.67123047100261 139.74659487164044 14.844 35.671275579751814 139.74663803629073 14.844 35.671275579751814 139.74663803629073 15 35.67123047100261 139.74659487164044 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b8b04f80-03d8-41c5-a689-51a8da869ccb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8b04f80-03d8-41c5-a689-51a8da869ccb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8b04f80-03d8-41c5-a689-51a8da869ccb">
											<gml:posList>35.67123014417708 139.7465916354055 7.4 35.67121519826464 139.7466150698907 7.4 35.67121519826464 139.7466150698907 15 35.67123014417708 139.7465916354055 15 35.67123014417708 139.7465916354055 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0ed86d0e-43c1-466d-a9a4-373a50b76575">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ed86d0e-43c1-466d-a9a4-373a50b76575">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ed86d0e-43c1-466d-a9a4-373a50b76575">
											<gml:posList>35.67121782998535 139.7466146693747 15 35.67121782998535 139.7466146693747 14.844 35.67123047100261 139.74659487164044 14.844 35.67123047100261 139.74659487164044 15 35.67121782998535 139.7466146693747 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e62ac6b0-8756-469f-b324-a6a7278878e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e62ac6b0-8756-469f-b324-a6a7278878e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e62ac6b0-8756-469f-b324-a6a7278878e2">
											<gml:posList>35.671278220494244 139.7466376468118 7.4 35.67123014417708 139.7465916354055 7.4 35.67123014417708 139.7465916354055 15 35.671278220494244 139.7466376468118 15 35.671278220494244 139.7466376468118 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1203a3e3-d496-4631-972e-d95a3e1733ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1203a3e3-d496-4631-972e-d95a3e1733ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1203a3e3-d496-4631-972e-d95a3e1733ce">
											<gml:posList>35.67121519826464 139.7466150698907 7.4 35.67126336471021 139.7466610812051 7.4 35.67126336471021 139.7466610812051 15 35.67121519826464 139.7466150698907 15 35.67121519826464 139.7466150698907 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-11572da6-26fd-4c1a-a1f0-2f11719377f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11572da6-26fd-4c1a-a1f0-2f11719377f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11572da6-26fd-4c1a-a1f0-2f11719377f3">
											<gml:posList>35.671275579751814 139.74663803629073 15 35.671275579751814 139.74663803629073 14.844 35.67126302888069 139.74665785602468 14.844 35.67126302888069 139.74665785602468 15 35.671275579751814 139.74663803629073 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-98c70f65-3504-4c4d-8eb3-11b5d212ddab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-98c70f65-3504-4c4d-8eb3-11b5d212ddab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-98c70f65-3504-4c4d-8eb3-11b5d212ddab">
											<gml:posList>35.67126336471021 139.7466610812051 7.4 35.671278220494244 139.7466376468118 7.4 35.671278220494244 139.7466376468118 15 35.67126336471021 139.7466610812051 15 35.67126336471021 139.7466610812051 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-3154</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>