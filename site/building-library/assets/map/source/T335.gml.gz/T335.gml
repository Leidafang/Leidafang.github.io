<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_60a208aa-8a82-4e86-b6f9-6d6edf4712e6">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">18.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67184811803105 139.73925865676827 0 35.671839514423 139.73920674849987 0 35.67177589879744 139.73923399745806 0 35.671743375839846 139.73925524480865 0 35.67185820804797 139.73936723165963 0 35.671917600175995 139.73924112181382 0 35.67184811803105 139.73925865676827 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67184811803105 139.73925865676827 9.61 35.671917600175995 139.73924112181382 9.61 35.67185820804797 139.73936723165963 9.61 35.671743375839846 139.73925524480865 9.61 35.67177589879744 139.73923399745806 9.61 35.671839514423 139.73920674849987 9.61 35.67184811803105 139.73925865676827 9.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67184811803105 139.73925865676827 9.61 35.671839514423 139.73920674849987 9.61 35.671839514423 139.73920674849987 28.43 35.67184811803105 139.73925865676827 28.43 35.67184811803105 139.73925865676827 9.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671839514423 139.73920674849987 9.61 35.67177589879744 139.73923399745806 9.61 35.67177589879744 139.73923399745806 28.43 35.671839514423 139.73920674849987 28.43 35.671839514423 139.73920674849987 9.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67177589879744 139.73923399745806 9.61 35.671743375839846 139.73925524480865 9.61 35.671743375839846 139.73925524480865 28.43 35.67177589879744 139.73923399745806 28.43 35.67177589879744 139.73923399745806 9.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671743375839846 139.73925524480865 9.61 35.67185820804797 139.73936723165963 9.61 35.67185820804797 139.73936723165963 28.43 35.671743375839846 139.73925524480865 28.43 35.671743375839846 139.73925524480865 9.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67185820804797 139.73936723165963 9.61 35.671917600175995 139.73924112181382 9.61 35.671917600175995 139.73924112181382 28.43 35.67185820804797 139.73936723165963 28.43 35.67185820804797 139.73936723165963 9.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671917600175995 139.73924112181382 9.61 35.67184811803105 139.73925865676827 9.61 35.67184811803105 139.73925865676827 28.43 35.671917600175995 139.73924112181382 28.43 35.671917600175995 139.73924112181382 9.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67184811803105 139.73925865676827 28.43 35.671839514423 139.73920674849987 28.43 35.67177589879744 139.73923399745806 28.43 35.671743375839846 139.73925524480865 28.43 35.67185820804797 139.73936723165963 28.43 35.671917600175995 139.73924112181382 28.43 35.67184811803105 139.73925865676827 28.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-950ca773-b25b-4318-9582-cdb211a72ded"/>
							<gml:surfaceMember xlink:href="#poly-0a0074fc-5ef3-4d53-b884-3926920d0b6d"/>
							<gml:surfaceMember xlink:href="#poly-00d98e3e-026d-47a9-af67-215d00d9c7bd"/>
							<gml:surfaceMember xlink:href="#poly-f712e5eb-3f22-4c57-aca0-b0654a67be93"/>
							<gml:surfaceMember xlink:href="#poly-a8c8f79e-9fa5-45c4-b2c6-7e5fa2a008bd"/>
							<gml:surfaceMember xlink:href="#poly-6eeeeff7-d6f2-43db-a3dd-da9310941d0c"/>
							<gml:surfaceMember xlink:href="#poly-b3de250e-8d2f-4221-bf68-b9f2bd4f1543"/>
							<gml:surfaceMember xlink:href="#poly-0120afbe-59d6-4465-a031-43cd291e62b5"/>
							<gml:surfaceMember xlink:href="#poly-155a07b0-1e64-4c02-be9b-af914380b7f0"/>
							<gml:surfaceMember xlink:href="#poly-2a36db25-cf10-4502-adc1-6eafbd4240e2"/>
							<gml:surfaceMember xlink:href="#poly-73c5f56b-ca2f-478b-822d-0c26b2eb28ce"/>
							<gml:surfaceMember xlink:href="#poly-50d03961-cfc2-42c0-a31c-982444b51c16"/>
							<gml:surfaceMember xlink:href="#poly-ce6543b0-a01a-4752-8aaf-e65a3eef5b57"/>
							<gml:surfaceMember xlink:href="#poly-20c851c1-bff6-4aa2-910a-a6028d20b9c2"/>
							<gml:surfaceMember xlink:href="#poly-ee9392ce-d175-4796-aa60-1f5ee4c13caf"/>
							<gml:surfaceMember xlink:href="#poly-2329311e-6d70-48ce-ba64-fbfbe58bbe99"/>
							<gml:surfaceMember xlink:href="#poly-28027ee8-eda3-4a50-a272-f2dcfa2f8481"/>
							<gml:surfaceMember xlink:href="#poly-c0625b5e-6a78-4d7d-a550-4e6176b3e1b1"/>
							<gml:surfaceMember xlink:href="#poly-709011b0-e69d-4c8e-bb99-830fd37ceb83"/>
							<gml:surfaceMember xlink:href="#poly-085285a0-a2a4-4da7-9392-497ca1022184"/>
							<gml:surfaceMember xlink:href="#poly-dd99c87b-01d8-4a03-9e79-a6171202d0d5"/>
							<gml:surfaceMember xlink:href="#poly-555bc3db-d18f-4e4f-b69e-efe3befefd32"/>
							<gml:surfaceMember xlink:href="#poly-fc81f959-7d6d-4268-a2f5-c8505b8c5cd1"/>
							<gml:surfaceMember xlink:href="#poly-f617fdec-7bfb-412f-9cfa-ce70e5213a75"/>
							<gml:surfaceMember xlink:href="#poly-5dda937e-077b-481c-9910-86bdb7bc34e3"/>
							<gml:surfaceMember xlink:href="#poly-bb821c2c-07db-4af4-8dec-cf28c89c306e"/>
							<gml:surfaceMember xlink:href="#poly-98401f95-cece-4896-b9e3-36afe77c1537"/>
							<gml:surfaceMember xlink:href="#poly-1c069c9c-8c39-41d8-a626-753864a2c6d7"/>
							<gml:surfaceMember xlink:href="#poly-a94cf694-5cad-4cbe-bf22-b2e26f844d2a"/>
							<gml:surfaceMember xlink:href="#poly-b0d47eb4-c5d3-4aac-b2f8-e6d5935ed339"/>
							<gml:surfaceMember xlink:href="#poly-399342f9-ba1e-4674-88a8-754463245e11"/>
							<gml:surfaceMember xlink:href="#poly-913c1a0c-4cf2-40be-8904-da9b48fcb3a0"/>
							<gml:surfaceMember xlink:href="#poly-04d6d0fe-43bc-49f5-98e6-02a5c163d201"/>
							<gml:surfaceMember xlink:href="#poly-b793cd0d-6ad6-401b-aa9e-c32324358fdb"/>
							<gml:surfaceMember xlink:href="#poly-184d02ea-cef9-40d0-803d-cbef941578f8"/>
							<gml:surfaceMember xlink:href="#poly-9a5551eb-810d-45c0-aef7-53953d944c5d"/>
							<gml:surfaceMember xlink:href="#poly-0152ede2-b340-41dc-974e-31614fe125e0"/>
							<gml:surfaceMember xlink:href="#poly-a5c5fd23-eb28-47b0-91e2-3b44bcdf7d35"/>
							<gml:surfaceMember xlink:href="#poly-5f102270-8125-4f8f-bc24-4dba6ed6734b"/>
							<gml:surfaceMember xlink:href="#poly-b86571ec-7163-4c7f-ac6b-f7321c27e7ee"/>
							<gml:surfaceMember xlink:href="#poly-2be18a16-7956-4f2c-8613-e830a5097296"/>
							<gml:surfaceMember xlink:href="#poly-a7186e0f-663b-4171-9181-6b869870b114"/>
							<gml:surfaceMember xlink:href="#poly-e4873c6b-2d47-4af1-a7de-cca97c073099"/>
							<gml:surfaceMember xlink:href="#poly-d4c964e0-91ea-4377-80fa-ffff90091bd2"/>
							<gml:surfaceMember xlink:href="#poly-d1a456b1-3902-4392-81bf-5877aead4b40"/>
							<gml:surfaceMember xlink:href="#poly-ce7bf78f-82b6-4ebf-9576-f1d2662b9b9b"/>
							<gml:surfaceMember xlink:href="#poly-dd818f3f-0444-45f3-b463-c2294fbb5d17"/>
							<gml:surfaceMember xlink:href="#poly-de4bddeb-9747-447e-ba0b-898e859b2ea7"/>
							<gml:surfaceMember xlink:href="#poly-d7869288-5849-4fc8-83f8-a08951d0359d"/>
							<gml:surfaceMember xlink:href="#poly-deada1b4-0f07-421e-81a0-50619300d9f3"/>
							<gml:surfaceMember xlink:href="#poly-96ee7454-aaeb-432b-8381-aeecc7c14083"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_60a208aa-8a82-4e86-b6f9-6d6edf4712e6_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-040504e2-9810-4c7d-a5a4-ff2d10afe934">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67186220630229 139.73928149537016 33.749 35.67186844342222 139.7392694695001 33.749 35.671877507733555 139.7392765286033 33.749 35.67187126159923 139.73928855448474 33.749 35.67186220630229 139.73928149537016 33.749</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fbd8d83b-322e-4c43-a2ee-654f8d428762">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67180718207872 139.7392873703553 28.215 35.67181841272726 139.73929832631367 28.215 35.671809517868006 139.73931203435217 28.215 35.67179828722071 139.7393010783931 28.215 35.67180718207872 139.7392873703553 28.215</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa84a6bc-c540-4f29-81a7-4ae8e2fce352">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67184052977496 139.73931802935113 28.215 35.671833313830675 139.73931167505222 28.215 35.671837778684065 139.73930404775865 28.215 35.6718450036511 139.73931041309308 28.215 35.67184052977496 139.73931802935113 28.215</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e8f4939-4a98-4498-b5ef-2ec710cad9d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6e8f4939-4a98-4498-b5ef-2ec710cad9d6_0">
											<gml:posList>35.67180718207872 139.7392873703553 28.215 35.67179828722071 139.7393010783931 28.215 35.67179828722071 139.7393010783931 31.311 35.67180718207872 139.7392873703553 31.311 35.67180718207872 139.7392873703553 28.215</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c2c870ea-7ab2-4c63-8e64-b424107b579b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c2c870ea-7ab2-4c63-8e64-b424107b579b_0">
											<gml:posList>35.67179828722071 139.7393010783931 28.215 35.671809517868006 139.73931203435217 28.215 35.671809517868006 139.73931203435217 31.311 35.67179828722071 139.7393010783931 31.311 35.67179828722071 139.7393010783931 28.215</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6bcbb9f1-c8db-4ded-bee1-2c0c4e67c6cf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6bcbb9f1-c8db-4ded-bee1-2c0c4e67c6cf_0">
											<gml:posList>35.67180718207872 139.7392873703553 31.311 35.67179828722071 139.7393010783931 31.311 35.671809517868006 139.73931203435217 31.311 35.67181841272726 139.73929832631367 31.311 35.67180718207872 139.7392873703553 31.311</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-34830119-6252-4df5-8c93-9d49b261207d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-34830119-6252-4df5-8c93-9d49b261207d_0">
											<gml:posList>35.67180718207872 139.7392873703553 28.215 35.67180718207872 139.7392873703553 31.311 35.67181841272726 139.73929832631367 31.311 35.67181841272726 139.73929832631367 28.215 35.67180718207872 139.7392873703553 28.215</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea63a9a3-96c2-4be8-886a-7ad0e0e7e580">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea63a9a3-96c2-4be8-886a-7ad0e0e7e580_0">
											<gml:posList>35.671809517868006 139.73931203435217 28.215 35.67181841272726 139.73929832631367 28.215 35.67181841272726 139.73929832631367 31.311 35.671809517868006 139.73931203435217 31.311 35.671809517868006 139.73931203435217 28.215</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e91551b-875d-4c50-afaf-65a2f4d1d10a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8e91551b-875d-4c50-afaf-65a2f4d1d10a_0">
											<gml:posList>35.671837778684065 139.73930404775865 28.215 35.671833313830675 139.73931167505222 28.215 35.671833313830675 139.73931167505222 30.628 35.671837778684065 139.73930404775865 30.628 35.671837778684065 139.73930404775865 28.215</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94d03712-f120-47f7-a2fa-3cc4cb69e2dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-94d03712-f120-47f7-a2fa-3cc4cb69e2dc_0">
											<gml:posList>35.671833313830675 139.73931167505222 28.215 35.67184052977496 139.73931802935113 28.215 35.67184052977496 139.73931802935113 30.628 35.671833313830675 139.73931167505222 30.628 35.671833313830675 139.73931167505222 28.215</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4d49e61-9c5d-4d7b-b3ef-17ddd7f69e79">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b4d49e61-9c5d-4d7b-b3ef-17ddd7f69e79_0">
											<gml:posList>35.671837778684065 139.73930404775865 30.628 35.671833313830675 139.73931167505222 30.628 35.67184052977496 139.73931802935113 30.628 35.6718450036511 139.73931041309308 30.628 35.671837778684065 139.73930404775865 30.628</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-795019fa-9825-4188-bac6-bc427d4275dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-795019fa-9825-4188-bac6-bc427d4275dd_0">
											<gml:posList>35.6718450036511 139.73931041309308 28.215 35.671837778684065 139.73930404775865 28.215 35.671837778684065 139.73930404775865 30.628 35.6718450036511 139.73931041309308 30.628 35.6718450036511 139.73931041309308 28.215</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82a5a349-b688-47d5-8d2d-25223bb94ff2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-82a5a349-b688-47d5-8d2d-25223bb94ff2_0">
											<gml:posList>35.67184052977496 139.73931802935113 28.215 35.6718450036511 139.73931041309308 28.215 35.6718450036511 139.73931041309308 30.628 35.67184052977496 139.73931802935113 30.628 35.67184052977496 139.73931802935113 28.215</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a51df69-d17f-433a-aae1-e6faf52bcb01">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0a51df69-d17f-433a-aae1-e6faf52bcb01_0">
											<gml:posList>35.67186844342222 139.7392694695001 33.749 35.67186220630229 139.73928149537016 33.749 35.67186220630229 139.73928149537016 34.258 35.67186844342222 139.7392694695001 34.258 35.67186844342222 139.7392694695001 33.749</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd3a5ad1-d92a-4b59-95e7-cd748664bb7a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bd3a5ad1-d92a-4b59-95e7-cd748664bb7a_0">
											<gml:posList>35.67187126159923 139.73928855448474 33.749 35.67187126159923 139.73928855448474 34.258 35.67186220630229 139.73928149537016 34.258 35.67186220630229 139.73928149537016 33.749 35.67187126159923 139.73928855448474 33.749</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0677fd3f-f9e4-4af5-b64e-d3c752c4804d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0677fd3f-f9e4-4af5-b64e-d3c752c4804d_0">
											<gml:posList>35.671877507733555 139.7392765286033 34.258 35.67186844342222 139.7392694695001 34.258 35.67186220630229 139.73928149537016 34.258 35.67187126159923 139.73928855448474 34.258 35.671877507733555 139.7392765286033 34.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44b5cf70-f3db-4cf1-9586-84ad116a1a8c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-44b5cf70-f3db-4cf1-9586-84ad116a1a8c_0">
											<gml:posList>35.671877507733555 139.7392765286033 33.749 35.67186844342222 139.7392694695001 33.749 35.67186844342222 139.7392694695001 34.258 35.671877507733555 139.7392765286033 34.258 35.671877507733555 139.7392765286033 33.749</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e79b696c-d32e-4e94-b8d2-503819afb523">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e79b696c-d32e-4e94-b8d2-503819afb523_0">
											<gml:posList>35.67187126159923 139.73928855448474 33.749 35.671877507733555 139.7392765286033 33.749 35.671877507733555 139.7392765286033 34.258 35.67187126159923 139.73928855448474 34.258 35.67187126159923 139.73928855448474 33.749</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_60a208aa-8a82-4e86-b6f9-6d6edf4712e6_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0278f469-71ca-43b2-bb6b-64f8f1be1356">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67186731776653 139.73930544915473 28.215 35.67186117890555 139.7393163371209 28.215 35.67185664245987 139.73931308373415 28.215 35.671839676438346 139.73929874323193 28.215 35.67184603131643 139.73928745734133 28.215 35.67186731776653 139.73930544915473 28.215</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-249f7665-7bee-4c88-8873-6264dddfb0a4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67186117890555 139.7393163371209 28.592 35.671860962886775 139.7393167350469 28.592 35.67185664245987 139.73931308373415 28.592 35.67186117890555 139.7393163371209 28.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb21cb64-8476-40dd-a377-778d1187d41d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb21cb64-8476-40dd-a377-778d1187d41d_0">
											<gml:posList>35.671839676438346 139.73929874323193 28.215 35.671839676438346 139.73929874323193 28.73 35.67184603131643 139.73928745734133 28.73 35.67184603131643 139.73928745734133 28.215 35.671839676438346 139.73929874323193 28.215</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f68456d1-c303-4d87-a4e5-d48695e300ac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f68456d1-c303-4d87-a4e5-d48695e300ac_0">
											<gml:posList>35.67186731776653 139.73930544915473 28.73 35.67186731776653 139.73930544915473 28.215 35.67184603131643 139.73928745734133 28.215 35.67184603131643 139.73928745734133 28.73 35.67186731776653 139.73930544915473 28.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-964003ee-33b9-434a-968a-59455f0eb68f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-964003ee-33b9-434a-968a-59455f0eb68f_0">
											<gml:posList>35.671839676438346 139.73929874323193 28.73 35.671860962886775 139.7393167350469 28.73 35.67186731776653 139.73930544915473 28.73 35.67184603131643 139.73928745734133 28.73 35.671839676438346 139.73929874323193 28.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df350cbb-7e42-456c-87fd-95f590b88457">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-df350cbb-7e42-456c-87fd-95f590b88457_0">
											<gml:posList>35.671860962886775 139.7393167350469 28.73 35.671839676438346 139.73929874323193 28.73 35.671839676438346 139.73929874323193 28.215 35.67185664245987 139.73931308373415 28.215 35.67185664245987 139.73931308373415 28.592 35.671860962886775 139.7393167350469 28.592 35.671860962886775 139.7393167350469 28.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a3c7304-efbd-4bdb-a4c5-1a6ec091dfea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4a3c7304-efbd-4bdb-a4c5-1a6ec091dfea_0">
											<gml:posList>35.67186731776653 139.73930544915473 28.215 35.67186731776653 139.73930544915473 28.73 35.671860962886775 139.7393167350469 28.73 35.671860962886775 139.7393167350469 28.592 35.67186117890555 139.7393163371209 28.592 35.67186117890555 139.7393163371209 28.215 35.67186731776653 139.73930544915473 28.215</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e96dc87-492d-40ca-945e-11f9842861fb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6e96dc87-492d-40ca-945e-11f9842861fb_0">
											<gml:posList>35.67185664245987 139.73931308373415 28.592 35.67185664245987 139.73931308373415 28.215 35.67186117890555 139.7393163371209 28.215 35.67186117890555 139.7393163371209 28.592 35.67185664245987 139.73931308373415 28.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-950ca773-b25b-4318-9582-cdb211a72ded">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-950ca773-b25b-4318-9582-cdb211a72ded">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-950ca773-b25b-4318-9582-cdb211a72ded">
											<gml:posList>35.67184811803104 139.73925865676824 9.61 35.671917600176 139.73924112181382 9.61 35.67185820804797 139.73936723165966 9.61 35.67174337583983 139.73925524480865 9.61 35.671775898797435 139.73923399745803 9.61 35.671839514422985 139.73920674849987 9.61 35.67184811803104 139.73925865676824 9.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0a0074fc-5ef3-4d53-b884-3926920d0b6d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a0074fc-5ef3-4d53-b884-3926920d0b6d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a0074fc-5ef3-4d53-b884-3926920d0b6d">
											<gml:posList>35.671775898797435 139.73923399745803 25.397 35.67174337583983 139.73925524480865 25.397 35.67176342864068 139.73927480663372 28.592 35.671775898797435 139.73923399745803 25.397</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-00d98e3e-026d-47a9-af67-215d00d9c7bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-00d98e3e-026d-47a9-af67-215d00d9c7bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-00d98e3e-026d-47a9-af67-215d00d9c7bd">
											<gml:posList>35.671782824618006 139.7392612630206 28.592 35.67176342864068 139.73927480663372 28.592 35.67176707045981 139.7392751558476 28.592 35.671781556634876 139.73926504239515 28.592 35.671782824618006 139.7392612630206 28.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f712e5eb-3f22-4c57-aca0-b0654a67be93">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f712e5eb-3f22-4c57-aca0-b0654a67be93">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f712e5eb-3f22-4c57-aca0-b0654a67be93">
											<gml:posList>35.67176342864068 139.73927480663372 28.592 35.671782824618006 139.7392612630206 28.592 35.671775898797435 139.73923399745803 25.397 35.67176342864068 139.73927480663372 28.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a8c8f79e-9fa5-45c4-b2c6-7e5fa2a008bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a8c8f79e-9fa5-45c4-b2c6-7e5fa2a008bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a8c8f79e-9fa5-45c4-b2c6-7e5fa2a008bd">
											<gml:posList>35.67178503169792 139.7392711580527 28.592 35.671782824618006 139.7392612630206 28.592 35.671781556634876 139.73926504239515 28.592 35.67178361898586 139.73927428585625 28.592 35.67178503169792 139.7392711580527 28.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6eeeeff7-d6f2-43db-a3dd-da9310941d0c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6eeeeff7-d6f2-43db-a3dd-da9310941d0c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6eeeeff7-d6f2-43db-a3dd-da9310941d0c">
											<gml:posList>35.67183507022479 139.7393446687678 28.592 35.67183462570703 139.73934102395722 28.592 35.67176707045981 139.7392751558476 28.592 35.67176342864068 139.73927480663372 28.592 35.67183507022479 139.7393446687678 28.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b3de250e-8d2f-4221-bf68-b9f2bd4f1543">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b3de250e-8d2f-4221-bf68-b9f2bd4f1543">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b3de250e-8d2f-4221-bf68-b9f2bd4f1543">
											<gml:posList>35.67184651503336 139.7392489709026 28.592 35.671839514422985 139.73920674849987 25.397 35.671775898797435 139.73923399745803 25.397 35.67184651503336 139.7392489709026 28.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0120afbe-59d6-4465-a031-43cd291e62b5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0120afbe-59d6-4465-a031-43cd291e62b5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0120afbe-59d6-4465-a031-43cd291e62b5">
											<gml:posList>35.671775898797435 139.73923399745803 25.397 35.67178503169792 139.7392711580527 28.592 35.67184651503336 139.7392489709026 28.592 35.671775898797435 139.73923399745803 25.397</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-155a07b0-1e64-4c02-be9b-af914380b7f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-155a07b0-1e64-4c02-be9b-af914380b7f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-155a07b0-1e64-4c02-be9b-af914380b7f0">
											<gml:posList>35.67178503169792 139.7392711580527 28.592 35.67178361898586 139.73927428585625 28.592 35.671844967159245 139.73925215409983 28.592 35.67184651503336 139.7392489709026 28.592 35.67178503169792 139.7392711580527 28.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2a36db25-cf10-4502-adc1-6eafbd4240e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a36db25-cf10-4502-adc1-6eafbd4240e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a36db25-cf10-4502-adc1-6eafbd4240e2">
											<gml:posList>35.67185202483885 139.7393097641642 28.215 35.67186392963408 139.7393183112122 28.215 35.6718692930824 139.73930712590067 28.215 35.67184945879053 139.7392903474938 28.215 35.671867128217166 139.73925895480926 28.215 35.67188514954755 139.73927418883366 28.215 35.671880031238416 139.7392530187632 28.215 35.6718465339292 139.73926161907866 28.215 35.671844967159245 139.73925215409983 28.215 35.67178361898586 139.73927428585625 28.215 35.671781556634876 139.73926504239515 28.215 35.67176707045981 139.7392751558476 28.215 35.67183462570703 139.73934102395722 28.215 35.67185202483885 139.7393097641642 28.215</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-73c5f56b-ca2f-478b-822d-0c26b2eb28ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73c5f56b-ca2f-478b-822d-0c26b2eb28ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73c5f56b-ca2f-478b-822d-0c26b2eb28ce">
											<gml:posList>35.67185264039397 139.73931312156682 28.592 35.67185202483885 139.7393097641642 28.592 35.67183462570703 139.73934102395722 28.592 35.67183507022479 139.7393446687678 28.592 35.67185264039397 139.73931312156682 28.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-50d03961-cfc2-42c0-a31c-982444b51c16">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50d03961-cfc2-42c0-a31c-982444b51c16">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50d03961-cfc2-42c0-a31c-982444b51c16">
											<gml:posList>35.67184811803104 139.73925865676824 28.592 35.67184651503336 139.7392489709026 28.592 35.671844967159245 139.73925215409983 28.592 35.6718465339292 139.73926161907866 28.592 35.67184811803104 139.73925865676824 28.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ce6543b0-a01a-4752-8aaf-e65a3eef5b57">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce6543b0-a01a-4752-8aaf-e65a3eef5b57">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce6543b0-a01a-4752-8aaf-e65a3eef5b57">
											<gml:posList>35.67183507022479 139.7393446687678 28.592 35.67185820804797 139.73936723165966 25.871 35.67187588171366 139.7393296971489 25.871 35.67183507022479 139.7393446687678 28.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-20c851c1-bff6-4aa2-910a-a6028d20b9c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20c851c1-bff6-4aa2-910a-a6028d20b9c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20c851c1-bff6-4aa2-910a-a6028d20b9c2">
											<gml:posList>35.67187588171366 139.7393296971489 25.871 35.67185264039397 139.73931312156682 28.592 35.67183507022479 139.7393446687678 28.592 35.67187588171366 139.7393296971489 25.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ee9392ce-d175-4796-aa60-1f5ee4c13caf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee9392ce-d175-4796-aa60-1f5ee4c13caf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee9392ce-d175-4796-aa60-1f5ee4c13caf">
											<gml:posList>35.67185264039397 139.73931312156682 28.592 35.67186461734187 139.73932172376308 28.592 35.67186392963408 139.7393183112122 28.592 35.67185202483885 139.7393097641642 28.592 35.67185264039397 139.73931312156682 28.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2329311e-6d70-48ce-ba64-fbfbe58bbe99">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2329311e-6d70-48ce-ba64-fbfbe58bbe99">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2329311e-6d70-48ce-ba64-fbfbe58bbe99">
											<gml:posList>35.67184945879053 139.7392903474938 34.854 35.67185151354775 139.73928987008568 34.854 35.671867508761096 139.7392614729566 34.854 35.671867128217166 139.73925895480926 34.854 35.67184945879053 139.7392903474938 34.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-28027ee8-eda3-4a50-a272-f2dcfa2f8481">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28027ee8-eda3-4a50-a272-f2dcfa2f8481">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28027ee8-eda3-4a50-a272-f2dcfa2f8481">
											<gml:posList>35.6718692930824 139.73930712590067 34.854 35.671868903517066 139.7393045967172 34.854 35.67185151354775 139.73928987008568 34.854 35.67184945879053 139.7392903474938 34.854 35.6718692930824 139.73930712590067 34.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c0625b5e-6a78-4d7d-a550-4e6176b3e1b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0625b5e-6a78-4d7d-a550-4e6176b3e1b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0625b5e-6a78-4d7d-a550-4e6176b3e1b1">
											<gml:posList>35.67188697151843 139.73927572215504 28.592 35.6718692930824 139.73930712590067 28.592 35.671887665928665 139.7392761742455 28.592 35.67188166952594 139.7392501889454 28.592 35.67184811803104 139.73925865676824 28.592 35.6718465339292 139.73926161907866 28.592 35.671880031238416 139.7392530187632 28.592 35.67188514954755 139.73927418883366 28.592 35.67188697151843 139.73927572215504 28.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-709011b0-e69d-4c8e-bb99-830fd37ceb83">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-709011b0-e69d-4c8e-bb99-830fd37ceb83">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-709011b0-e69d-4c8e-bb99-830fd37ceb83">
											<gml:posList>35.67188490773893 139.73927618852784 33.749 35.671867508761096 139.7392614729566 33.749 35.67185151354775 139.73928987008568 33.749 35.671868903517066 139.7393045967172 33.749 35.67188490773893 139.73927618852784 33.749</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-085285a0-a2a4-4da7-9392-497ca1022184">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-085285a0-a2a4-4da7-9392-497ca1022184">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-085285a0-a2a4-4da7-9392-497ca1022184">
											<gml:posList>35.67186461734187 139.73932172376308 28.592 35.671887665928665 139.7392761742455 28.592 35.6718692930824 139.73930712590067 28.592 35.67186392963408 139.7393183112122 28.592 35.67186461734187 139.73932172376308 28.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dd99c87b-01d8-4a03-9e79-a6171202d0d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd99c87b-01d8-4a03-9e79-a6171202d0d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd99c87b-01d8-4a03-9e79-a6171202d0d5">
											<gml:posList>35.671887665928665 139.7392761742455 28.592 35.67186461734187 139.73932172376308 28.592 35.67187588171366 139.7393296971489 25.871 35.671887665928665 139.7392761742455 28.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-555bc3db-d18f-4e4f-b69e-efe3befefd32">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-555bc3db-d18f-4e4f-b69e-efe3befefd32">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-555bc3db-d18f-4e4f-b69e-efe3befefd32">
											<gml:posList>35.671867128217166 139.73925895480926 34.854 35.671867508761096 139.7392614729566 34.854 35.67188490773893 139.73927618852784 34.854 35.67188697151843 139.73927572215504 34.854 35.671867128217166 139.73925895480926 34.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fc81f959-7d6d-4268-a2f5-c8505b8c5cd1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc81f959-7d6d-4268-a2f5-c8505b8c5cd1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc81f959-7d6d-4268-a2f5-c8505b8c5cd1">
											<gml:posList>35.67188697151843 139.73927572215504 34.854 35.67188490773893 139.73927618852784 34.854 35.671868903517066 139.7393045967172 34.854 35.6718692930824 139.73930712590067 34.854 35.67188697151843 139.73927572215504 34.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f617fdec-7bfb-412f-9cfa-ce70e5213a75">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f617fdec-7bfb-412f-9cfa-ce70e5213a75">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f617fdec-7bfb-412f-9cfa-ce70e5213a75">
											<gml:posList>35.67187588171366 139.7393296971489 25.871 35.671917600176 139.73924112181382 25.871 35.671887665928665 139.7392761742455 28.592 35.67187588171366 139.7393296971489 25.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5dda937e-077b-481c-9910-86bdb7bc34e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5dda937e-077b-481c-9910-86bdb7bc34e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5dda937e-077b-481c-9910-86bdb7bc34e3">
											<gml:posList>35.671917600176 139.73924112181382 25.871 35.67188166952594 139.7392501889454 28.592 35.671887665928665 139.7392761742455 28.592 35.671917600176 139.73924112181382 25.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bb821c2c-07db-4af4-8dec-cf28c89c306e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb821c2c-07db-4af4-8dec-cf28c89c306e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb821c2c-07db-4af4-8dec-cf28c89c306e">
											<gml:posList>35.67176707045981 139.7392751558476 28.592 35.67176707045981 139.7392751558476 28.215 35.671781556634876 139.73926504239515 28.215 35.671781556634876 139.73926504239515 28.592 35.67176707045981 139.7392751558476 28.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-98401f95-cece-4896-b9e3-36afe77c1537">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-98401f95-cece-4896-b9e3-36afe77c1537">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-98401f95-cece-4896-b9e3-36afe77c1537">
											<gml:posList>35.67185151354775 139.73928987008568 34.854 35.67185151354775 139.73928987008568 33.749 35.671867508761096 139.7392614729566 33.749 35.671867508761096 139.7392614729566 34.854 35.67185151354775 139.73928987008568 34.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1c069c9c-8c39-41d8-a626-753864a2c6d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c069c9c-8c39-41d8-a626-753864a2c6d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c069c9c-8c39-41d8-a626-753864a2c6d7">
											<gml:posList>35.67188490773893 139.73927618852784 34.854 35.67188490773893 139.73927618852784 33.749 35.671868903517066 139.7393045967172 33.749 35.671868903517066 139.7393045967172 34.854 35.67188490773893 139.73927618852784 34.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a94cf694-5cad-4cbe-bf22-b2e26f844d2a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a94cf694-5cad-4cbe-bf22-b2e26f844d2a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a94cf694-5cad-4cbe-bf22-b2e26f844d2a">
											<gml:posList>35.671839514422985 139.73920674849987 9.61 35.671775898797435 139.73923399745803 9.61 35.671775898797435 139.73923399745803 25.397 35.671839514422985 139.73920674849987 25.397 35.671839514422985 139.73920674849987 9.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b0d47eb4-c5d3-4aac-b2f8-e6d5935ed339">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b0d47eb4-c5d3-4aac-b2f8-e6d5935ed339">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b0d47eb4-c5d3-4aac-b2f8-e6d5935ed339">
											<gml:posList>35.67184811803104 139.73925865676824 28.592 35.67184811803104 139.73925865676824 9.61 35.671839514422985 139.73920674849987 9.61 35.671839514422985 139.73920674849987 25.397 35.67184651503336 139.7392489709026 28.592 35.67184811803104 139.73925865676824 28.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-399342f9-ba1e-4674-88a8-754463245e11">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-399342f9-ba1e-4674-88a8-754463245e11">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-399342f9-ba1e-4674-88a8-754463245e11">
											<gml:posList>35.671775898797435 139.73923399745803 9.61 35.67174337583983 139.73925524480865 9.61 35.67174337583983 139.73925524480865 25.397 35.671775898797435 139.73923399745803 25.397 35.671775898797435 139.73923399745803 9.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-913c1a0c-4cf2-40be-8904-da9b48fcb3a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-913c1a0c-4cf2-40be-8904-da9b48fcb3a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-913c1a0c-4cf2-40be-8904-da9b48fcb3a0">
											<gml:posList>35.67184811803104 139.73925865676824 28.592 35.67188166952594 139.7392501889454 28.592 35.671917600176 139.73924112181382 25.871 35.671917600176 139.73924112181382 9.61 35.67184811803104 139.73925865676824 9.61 35.67184811803104 139.73925865676824 28.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-04d6d0fe-43bc-49f5-98e6-02a5c163d201">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04d6d0fe-43bc-49f5-98e6-02a5c163d201">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04d6d0fe-43bc-49f5-98e6-02a5c163d201">
											<gml:posList>35.671775898797435 139.73923399745803 25.397 35.671782824618006 139.7392612630206 28.592 35.67178503169792 139.7392711580527 28.592 35.671775898797435 139.73923399745803 25.397</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b793cd0d-6ad6-401b-aa9e-c32324358fdb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b793cd0d-6ad6-401b-aa9e-c32324358fdb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b793cd0d-6ad6-401b-aa9e-c32324358fdb">
											<gml:posList>35.671844967159245 139.73925215409983 28.592 35.671844967159245 139.73925215409983 28.215 35.6718465339292 139.73926161907866 28.215 35.6718465339292 139.73926161907866 28.592 35.671844967159245 139.73925215409983 28.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-184d02ea-cef9-40d0-803d-cbef941578f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-184d02ea-cef9-40d0-803d-cbef941578f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-184d02ea-cef9-40d0-803d-cbef941578f8">
											<gml:posList>35.6718465339292 139.73926161907866 28.592 35.6718465339292 139.73926161907866 28.215 35.671880031238416 139.7392530187632 28.215 35.671880031238416 139.7392530187632 28.592 35.6718465339292 139.73926161907866 28.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9a5551eb-810d-45c0-aef7-53953d944c5d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a5551eb-810d-45c0-aef7-53953d944c5d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a5551eb-810d-45c0-aef7-53953d944c5d">
											<gml:posList>35.67178361898586 139.73927428585625 28.592 35.67178361898586 139.73927428585625 28.215 35.671844967159245 139.73925215409983 28.215 35.671844967159245 139.73925215409983 28.592 35.67178361898586 139.73927428585625 28.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0152ede2-b340-41dc-974e-31614fe125e0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0152ede2-b340-41dc-974e-31614fe125e0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0152ede2-b340-41dc-974e-31614fe125e0">
											<gml:posList>35.671880031238416 139.7392530187632 28.592 35.671880031238416 139.7392530187632 28.215 35.67188514954755 139.73927418883366 28.215 35.67188514954755 139.73927418883366 28.592 35.671880031238416 139.7392530187632 28.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a5c5fd23-eb28-47b0-91e2-3b44bcdf7d35">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5c5fd23-eb28-47b0-91e2-3b44bcdf7d35">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5c5fd23-eb28-47b0-91e2-3b44bcdf7d35">
											<gml:posList>35.671867128217166 139.73925895480926 28.215 35.671867128217166 139.73925895480926 34.854 35.67188697151843 139.73927572215504 34.854 35.67188697151843 139.73927572215504 28.592 35.67188514954755 139.73927418883366 28.592 35.67188514954755 139.73927418883366 28.215 35.671867128217166 139.73925895480926 28.215</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5f102270-8125-4f8f-bc24-4dba6ed6734b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f102270-8125-4f8f-bc24-4dba6ed6734b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f102270-8125-4f8f-bc24-4dba6ed6734b">
											<gml:posList>35.671867508761096 139.7392614729566 34.854 35.671867508761096 139.7392614729566 33.749 35.67188490773893 139.73927618852784 33.749 35.67188490773893 139.73927618852784 34.854 35.671867508761096 139.7392614729566 34.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b86571ec-7163-4c7f-ac6b-f7321c27e7ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b86571ec-7163-4c7f-ac6b-f7321c27e7ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b86571ec-7163-4c7f-ac6b-f7321c27e7ee">
											<gml:posList>35.671781556634876 139.73926504239515 28.592 35.671781556634876 139.73926504239515 28.215 35.67178361898586 139.73927428585625 28.215 35.67178361898586 139.73927428585625 28.592 35.671781556634876 139.73926504239515 28.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2be18a16-7956-4f2c-8613-e830a5097296">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2be18a16-7956-4f2c-8613-e830a5097296">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2be18a16-7956-4f2c-8613-e830a5097296">
											<gml:posList>35.67184945879053 139.7392903474938 34.854 35.671867128217166 139.73925895480926 34.854 35.671867128217166 139.73925895480926 28.215 35.67184945879053 139.7392903474938 28.215 35.67184945879053 139.7392903474938 34.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a7186e0f-663b-4171-9181-6b869870b114">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a7186e0f-663b-4171-9181-6b869870b114">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a7186e0f-663b-4171-9181-6b869870b114">
											<gml:posList>35.67188697151843 139.73927572215504 34.854 35.6718692930824 139.73930712590067 34.854 35.6718692930824 139.73930712590067 28.592 35.67188697151843 139.73927572215504 28.592 35.67188697151843 139.73927572215504 34.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e4873c6b-2d47-4af1-a7de-cca97c073099">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e4873c6b-2d47-4af1-a7de-cca97c073099">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e4873c6b-2d47-4af1-a7de-cca97c073099">
											<gml:posList>35.671868903517066 139.7393045967172 34.854 35.671868903517066 139.7393045967172 33.749 35.67185151354775 139.73928987008568 33.749 35.67185151354775 139.73928987008568 34.854 35.671868903517066 139.7393045967172 34.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d4c964e0-91ea-4377-80fa-ffff90091bd2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4c964e0-91ea-4377-80fa-ffff90091bd2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4c964e0-91ea-4377-80fa-ffff90091bd2">
											<gml:posList>35.67184945879053 139.7392903474938 34.854 35.67184945879053 139.7392903474938 28.215 35.6718692930824 139.73930712590067 28.215 35.6718692930824 139.73930712590067 28.592 35.6718692930824 139.73930712590067 34.854 35.67184945879053 139.7392903474938 34.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d1a456b1-3902-4392-81bf-5877aead4b40">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1a456b1-3902-4392-81bf-5877aead4b40">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1a456b1-3902-4392-81bf-5877aead4b40">
											<gml:posList>35.67185820804797 139.73936723165966 9.61 35.671917600176 139.73924112181382 9.61 35.671917600176 139.73924112181382 25.871 35.67187588171366 139.7393296971489 25.871 35.67185820804797 139.73936723165966 25.871 35.67185820804797 139.73936723165966 9.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ce7bf78f-82b6-4ebf-9576-f1d2662b9b9b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce7bf78f-82b6-4ebf-9576-f1d2662b9b9b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce7bf78f-82b6-4ebf-9576-f1d2662b9b9b">
											<gml:posList>35.67183462570703 139.73934102395722 28.592 35.67183462570703 139.73934102395722 28.215 35.67176707045981 139.7392751558476 28.215 35.67176707045981 139.7392751558476 28.592 35.67183462570703 139.73934102395722 28.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dd818f3f-0444-45f3-b463-c2294fbb5d17">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd818f3f-0444-45f3-b463-c2294fbb5d17">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd818f3f-0444-45f3-b463-c2294fbb5d17">
											<gml:posList>35.67174337583983 139.73925524480865 9.61 35.67185820804797 139.73936723165966 9.61 35.67185820804797 139.73936723165966 25.871 35.67183507022479 139.7393446687678 28.592 35.67176342864068 139.73927480663372 28.592 35.67174337583983 139.73925524480865 25.397 35.67174337583983 139.73925524480865 9.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-de4bddeb-9747-447e-ba0b-898e859b2ea7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de4bddeb-9747-447e-ba0b-898e859b2ea7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de4bddeb-9747-447e-ba0b-898e859b2ea7">
											<gml:posList>35.6718692930824 139.73930712590067 28.592 35.6718692930824 139.73930712590067 28.215 35.67186392963408 139.7393183112122 28.215 35.67186392963408 139.7393183112122 28.592 35.6718692930824 139.73930712590067 28.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d7869288-5849-4fc8-83f8-a08951d0359d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7869288-5849-4fc8-83f8-a08951d0359d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7869288-5849-4fc8-83f8-a08951d0359d">
											<gml:posList>35.67186392963408 139.7393183112122 28.592 35.67186392963408 139.7393183112122 28.215 35.67185202483885 139.7393097641642 28.215 35.67185202483885 139.7393097641642 28.592 35.67186392963408 139.7393183112122 28.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-deada1b4-0f07-421e-81a0-50619300d9f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-deada1b4-0f07-421e-81a0-50619300d9f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-deada1b4-0f07-421e-81a0-50619300d9f3">
											<gml:posList>35.67187588171366 139.7393296971489 25.871 35.67186461734187 139.73932172376308 28.592 35.67185264039397 139.73931312156682 28.592 35.67187588171366 139.7393296971489 25.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-96ee7454-aaeb-432b-8381-aeecc7c14083">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96ee7454-aaeb-432b-8381-aeecc7c14083">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96ee7454-aaeb-432b-8381-aeecc7c14083">
											<gml:posList>35.67185202483885 139.7393097641642 28.592 35.67185202483885 139.7393097641642 28.215 35.67183462570703 139.73934102395722 28.215 35.67183462570703 139.73934102395722 28.592 35.67185202483885 139.7393097641642 28.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5187</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">125.19855</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>