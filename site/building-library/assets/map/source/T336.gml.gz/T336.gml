<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_60aee89d-0a9a-405a-9948-6c541daefc30">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">20.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67088797536159 139.7376794623721 0 35.67087063988047 139.73759745303192 0 35.670712732145574 139.7376475929752 0 35.67071139552626 139.73765568046548 0 35.6707065023043 139.7376572327873 0 35.67072658823733 139.73775224019656 0 35.67089567023137 139.73769856334297 0 35.670893534973956 139.73768846954442 0 35.67088797536159 139.7376794623721 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67088797536159 139.7376794623721 13.1 35.670893534973956 139.73768846954442 13.1 35.67089567023137 139.73769856334297 13.1 35.67072658823733 139.73775224019656 13.1 35.6707065023043 139.7376572327873 13.1 35.67071139552626 139.73765568046548 13.1 35.670712732145574 139.7376475929752 13.1 35.67087063988047 139.73759745303192 13.1 35.67088797536159 139.7376794623721 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67088797536159 139.7376794623721 13.1 35.67087063988047 139.73759745303192 13.1 35.67087063988047 139.73759745303192 33.78 35.67088797536159 139.7376794623721 33.78 35.67088797536159 139.7376794623721 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67087063988047 139.73759745303192 13.1 35.670712732145574 139.7376475929752 13.1 35.670712732145574 139.7376475929752 33.78 35.67087063988047 139.73759745303192 33.78 35.67087063988047 139.73759745303192 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670712732145574 139.7376475929752 13.1 35.67071139552626 139.73765568046548 13.1 35.67071139552626 139.73765568046548 33.78 35.670712732145574 139.7376475929752 33.78 35.670712732145574 139.7376475929752 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67071139552626 139.73765568046548 13.1 35.6707065023043 139.7376572327873 13.1 35.6707065023043 139.7376572327873 33.78 35.67071139552626 139.73765568046548 33.78 35.67071139552626 139.73765568046548 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6707065023043 139.7376572327873 13.1 35.67072658823733 139.73775224019656 13.1 35.67072658823733 139.73775224019656 33.78 35.6707065023043 139.7376572327873 33.78 35.6707065023043 139.7376572327873 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67072658823733 139.73775224019656 13.1 35.67089567023137 139.73769856334297 13.1 35.67089567023137 139.73769856334297 33.78 35.67072658823733 139.73775224019656 33.78 35.67072658823733 139.73775224019656 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67089567023137 139.73769856334297 13.1 35.670893534973956 139.73768846954442 13.1 35.670893534973956 139.73768846954442 33.78 35.67089567023137 139.73769856334297 33.78 35.67089567023137 139.73769856334297 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670893534973956 139.73768846954442 13.1 35.67088797536159 139.7376794623721 13.1 35.67088797536159 139.7376794623721 33.78 35.670893534973956 139.73768846954442 33.78 35.670893534973956 139.73768846954442 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67088797536159 139.7376794623721 33.78 35.67087063988047 139.73759745303192 33.78 35.670712732145574 139.7376475929752 33.78 35.67071139552626 139.73765568046548 33.78 35.6707065023043 139.7376572327873 33.78 35.67072658823733 139.73775224019656 33.78 35.67089567023137 139.73769856334297 33.78 35.670893534973956 139.73768846954442 33.78 35.67088797536159 139.7376794623721 33.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-89133dcc-7d9a-4203-bbc9-c351079ca6e7"/>
							<gml:surfaceMember xlink:href="#poly-0ae31468-84ed-4885-9b1f-62c6d0ba1440"/>
							<gml:surfaceMember xlink:href="#poly-05ab15ab-b864-47cc-a98f-77968f55f993"/>
							<gml:surfaceMember xlink:href="#poly-eb467c01-6ddd-47ce-afe7-1d34b290d874"/>
							<gml:surfaceMember xlink:href="#poly-2d1bdb42-d9d9-41af-b33c-020f1c4febaa"/>
							<gml:surfaceMember xlink:href="#poly-683eaf31-cc6c-41c3-b0c1-8cd8807916ec"/>
							<gml:surfaceMember xlink:href="#poly-e32454ae-8375-4158-94c2-2a12d9b9dffe"/>
							<gml:surfaceMember xlink:href="#poly-1305c6cc-3d59-49f5-bf51-0a8a7c7fa45f"/>
							<gml:surfaceMember xlink:href="#poly-88041cdd-cdcd-4bd5-b8b5-0796f40fdf67"/>
							<gml:surfaceMember xlink:href="#poly-8dff676a-a5ec-4623-a8d5-9e2b27d5b5fa"/>
							<gml:surfaceMember xlink:href="#poly-81f1f642-0d59-4cb2-af16-a1e165b3fe54"/>
							<gml:surfaceMember xlink:href="#poly-e156a761-5fb9-4311-8253-08351cfeb68a"/>
							<gml:surfaceMember xlink:href="#poly-023dd3d6-9ca6-4300-9f8b-cd0807ea6348"/>
							<gml:surfaceMember xlink:href="#poly-44e0e587-0ab0-496c-b0d8-f7c60a04d9a7"/>
							<gml:surfaceMember xlink:href="#poly-b1579e8c-6a9d-46d3-be79-040de9e45357"/>
							<gml:surfaceMember xlink:href="#poly-a4811349-6eac-42a4-b775-64808aa6dc40"/>
							<gml:surfaceMember xlink:href="#poly-b3f4e0db-6b3e-411b-92bb-a0ad7173b479"/>
							<gml:surfaceMember xlink:href="#poly-70405163-de5d-44c3-8c84-a9073bec4d23"/>
							<gml:surfaceMember xlink:href="#poly-1d4031f8-8a02-4a73-b4b4-65980df5a9d1"/>
							<gml:surfaceMember xlink:href="#poly-23e022f5-211b-4a69-bfc8-f9a8c7c3c83d"/>
							<gml:surfaceMember xlink:href="#poly-bfd4efa8-f6d8-4086-95a9-f57d174f7822"/>
							<gml:surfaceMember xlink:href="#poly-df35afe7-9153-469d-8248-5b23be11f2b5"/>
							<gml:surfaceMember xlink:href="#poly-e22ebfc9-2bf2-402e-a22a-8cfbcf82146b"/>
							<gml:surfaceMember xlink:href="#poly-841f74d3-5dc6-4e93-a987-65db9361fd23"/>
							<gml:surfaceMember xlink:href="#poly-80f111bf-eb12-4c34-b145-36dc5676e9d0"/>
							<gml:surfaceMember xlink:href="#poly-dbc38242-df3d-46c1-9b80-284b465e4c39"/>
							<gml:surfaceMember xlink:href="#poly-d919c8f8-19bc-44d8-a11f-3ff1990567ba"/>
							<gml:surfaceMember xlink:href="#poly-ad43a7b7-f690-4efb-8398-e72dff6104a0"/>
							<gml:surfaceMember xlink:href="#poly-d618a0fc-3e4f-4742-8d32-48967440fec5"/>
							<gml:surfaceMember xlink:href="#poly-59330c0f-756c-49d6-8e77-89bf6c781f87"/>
							<gml:surfaceMember xlink:href="#poly-1b9019d6-385d-4190-859e-c26e82a5ab47"/>
							<gml:surfaceMember xlink:href="#poly-ee2ea2b1-9725-4b56-b3fc-26bac59ba735"/>
							<gml:surfaceMember xlink:href="#poly-4a8aa0fb-08e0-49c5-982c-a8dda11654f6"/>
							<gml:surfaceMember xlink:href="#poly-9ccae40a-ab2a-4991-ac94-4a7cc9c358c1"/>
							<gml:surfaceMember xlink:href="#poly-2d85e4c5-ab79-4ee2-874d-f89a1d48d419"/>
							<gml:surfaceMember xlink:href="#poly-39bf788c-2b93-4bed-a2b2-a87d0bcef84b"/>
							<gml:surfaceMember xlink:href="#poly-7641356c-c8b1-493a-9ff8-d95c780e3deb"/>
							<gml:surfaceMember xlink:href="#poly-5a1e53c0-5f76-4ebe-bc56-ebb24952539f"/>
							<gml:surfaceMember xlink:href="#poly-1cf3f92a-0ab1-4762-a851-75a87eb6da2d"/>
							<gml:surfaceMember xlink:href="#poly-96d1ba9b-409b-476a-bd7b-9d895a7ffb0f"/>
							<gml:surfaceMember xlink:href="#poly-3728d828-d365-4380-8146-09d44dbe6804"/>
							<gml:surfaceMember xlink:href="#poly-4ef70e94-1ba0-4b48-9d79-6c5fc02033fe"/>
							<gml:surfaceMember xlink:href="#poly-bbaa3a85-8180-42ca-b6aa-3d6a52cac33b"/>
							<gml:surfaceMember xlink:href="#poly-ac1a57db-ba16-4f70-a307-cec5001431f4"/>
							<gml:surfaceMember xlink:href="#poly-3e50e28f-9801-40e1-bafc-d03e9607c0bd"/>
							<gml:surfaceMember xlink:href="#poly-0dbbe20b-c41f-4884-a258-dc18ad3c219c"/>
							<gml:surfaceMember xlink:href="#poly-8eb7fc44-8ae2-4d1d-8472-f08f8ae962c6"/>
							<gml:surfaceMember xlink:href="#poly-486ac220-0b58-4bea-b937-04e82cab61ab"/>
							<gml:surfaceMember xlink:href="#poly-c5af56ea-0956-4208-addb-acc0c0bb4e0b"/>
							<gml:surfaceMember xlink:href="#poly-28bbcf88-f451-4746-b8ff-753d61791d63"/>
							<gml:surfaceMember xlink:href="#poly-9df21517-7bbe-4984-9121-f5ab2e6d9ab9"/>
							<gml:surfaceMember xlink:href="#poly-7eb29cde-cd7b-404e-a47b-f4a923f7e162"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-89133dcc-7d9a-4203-bbc9-c351079ca6e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-89133dcc-7d9a-4203-bbc9-c351079ca6e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-89133dcc-7d9a-4203-bbc9-c351079ca6e7">
											<gml:posList>35.67071139552625 139.73765568046548 13.1 35.670712732145574 139.73764759297518 13.1 35.670870639880434 139.7375974530319 13.1 35.670887975361595 139.7376794623721 13.1 35.67089353497394 139.7376884695444 13.1 35.67089567023135 139.73769856334297 13.1 35.67072658823731 139.73775224019653 13.1 35.670706502304284 139.73765723278729 13.1 35.67071139552625 139.73765568046548 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0ae31468-84ed-4885-9b1f-62c6d0ba1440">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ae31468-84ed-4885-9b1f-62c6d0ba1440">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ae31468-84ed-4885-9b1f-62c6d0ba1440">
											<gml:posList>35.67088204004229 139.73765137864035 38.566 35.670870639880434 139.7375974530319 31.009 35.67075218429832 139.73763506356067 31.009 35.67075913294964 139.73766791804312 35.6 35.67076358444345 139.7376889890949 38.566 35.67088204004229 139.73765137864035 38.566</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-05ab15ab-b864-47cc-a98f-77968f55f993">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-05ab15ab-b864-47cc-a98f-77968f55f993">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-05ab15ab-b864-47cc-a98f-77968f55f993">
											<gml:posList>35.67071139552625 139.73765568046548 31.009 35.670726486813116 139.73765857868148 33.023 35.670712732145574 139.73764759297518 31.009 35.67071139552625 139.73765568046548 31.009</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-eb467c01-6ddd-47ce-afe7-1d34b290d874">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eb467c01-6ddd-47ce-afe7-1d34b290d874">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eb467c01-6ddd-47ce-afe7-1d34b290d874">
											<gml:posList>35.670740860091406 139.7376540214969 33.023 35.67074475966208 139.73767246417995 35.593 35.67075913294964 139.73766791804312 35.6 35.67075218429832 139.73763506356067 31.009 35.670712732145574 139.73764759297518 31.009 35.670726486813116 139.73765857868148 33.023 35.670740860091406 139.7376540214969 33.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2d1bdb42-d9d9-41af-b33c-020f1c4febaa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d1bdb42-d9d9-41af-b33c-020f1c4febaa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d1bdb42-d9d9-41af-b33c-020f1c4febaa">
											<gml:posList>35.670706502304284 139.73765723278729 31.009 35.670726486813116 139.73765857868148 33.023 35.67071139552625 139.73765568046548 31.009 35.670706502304284 139.73765723278729 31.009</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-683eaf31-cc6c-41c3-b0c1-8cd8807916ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-683eaf31-cc6c-41c3-b0c1-8cd8807916ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-683eaf31-cc6c-41c3-b0c1-8cd8807916ec">
											<gml:posList>35.670740860091406 139.7376540214969 33.023 35.670726486813116 139.73765857868148 33.023 35.67073031984771 139.73766134673065 33.023 35.67074164724308 139.73765774316362 33.023 35.670740860091406 139.7376540214969 33.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e32454ae-8375-4158-94c2-2a12d9b9dffe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e32454ae-8375-4158-94c2-2a12d9b9dffe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e32454ae-8375-4158-94c2-2a12d9b9dffe">
											<gml:posList>35.67088204004229 139.73765137864035 38.566 35.67087947536243 139.73765670603112 38.566 35.67088316680972 139.7376741327323 38.566 35.67088750487551 139.73767723157496 38.566 35.67088204004229 139.73765137864035 38.566</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1305c6cc-3d59-49f5-bf51-0a8a7c7fa45f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1305c6cc-3d59-49f5-bf51-0a8a7c7fa45f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1305c6cc-3d59-49f5-bf51-0a8a7c7fa45f">
											<gml:posList>35.67075913294964 139.73766791804312 35.6 35.67074475966208 139.73767246417995 35.593 35.67074835820795 139.73767506681557 35.595 35.670759874865524 139.7376714298849 35.6 35.67075913294964 139.73766791804312 35.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-88041cdd-cdcd-4bd5-b8b5-0796f40fdf67">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-88041cdd-cdcd-4bd5-b8b5-0796f40fdf67">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-88041cdd-cdcd-4bd5-b8b5-0796f40fdf67">
											<gml:posList>35.67076358444345 139.7376889890949 38.566 35.67076792254403 139.73769213211895 38.566 35.67087947536243 139.73765670603112 38.566 35.67088204004229 139.73765137864035 38.566 35.67076358444345 139.7376889890949 38.566</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8dff676a-a5ec-4623-a8d5-9e2b27d5b5fa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8dff676a-a5ec-4623-a8d5-9e2b27d5b5fa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8dff676a-a5ec-4623-a8d5-9e2b27d5b5fa">
											<gml:posList>35.67087785365466 139.73768035815402 38.566 35.67088750487551 139.73767723157496 38.566 35.67088316680972 139.7376741327323 38.566 35.67087350657523 139.7376772593223 38.566 35.67087785365466 139.73768035815402 38.566</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-81f1f642-0d59-4cb2-af16-a1e165b3fe54">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-81f1f642-0d59-4cb2-af16-a1e165b3fe54">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-81f1f642-0d59-4cb2-af16-a1e165b3fe54">
											<gml:posList>35.67087785365466 139.73768035815402 38.566 35.67087350657523 139.7376772593223 38.566 35.670875442742016 139.73768635918609 38.566 35.67087978983876 139.737689480111 38.566 35.67087785365466 139.73768035815402 38.566</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e156a761-5fb9-4311-8253-08351cfeb68a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e156a761-5fb9-4311-8253-08351cfeb68a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e156a761-5fb9-4311-8253-08351cfeb68a">
											<gml:posList>35.67087346379455 139.73769148704267 38.566 35.67087978983876 139.737689480111 38.566 35.670875442742016 139.73768635918609 38.566 35.670869152735186 139.73768834398228 38.566 35.67087346379455 139.73769148704267 38.566</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-023dd3d6-9ca6-4300-9f8b-cd0807ea6348">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-023dd3d6-9ca6-4300-9f8b-cd0807ea6348">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-023dd3d6-9ca6-4300-9f8b-cd0807ea6348">
											<gml:posList>35.67087613338785 139.73770476154377 31.009 35.67089567023135 139.73769856334297 31.009 35.67089353497394 139.7376884695444 31.009 35.670887975361595 139.7376794623721 31.009 35.67088750487551 139.73767723157496 31.009 35.67087785365466 139.73768035815402 31.009 35.67087978983876 139.737689480111 31.009 35.67087346379455 139.73769148704267 31.009 35.67087613338785 139.73770476154377 31.009</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-44e0e587-0ab0-496c-b0d8-f7c60a04d9a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44e0e587-0ab0-496c-b0d8-f7c60a04d9a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44e0e587-0ab0-496c-b0d8-f7c60a04d9a7">
											<gml:posList>35.67087350657523 139.7376772593223 38.207 35.67088316680972 139.7376741327323 38.207 35.67087947536243 139.73765670603112 38.207 35.67076792254403 139.73769213211895 38.207 35.67077633691928 139.7377319329963 38.207 35.67087183134255 139.7377016184718 38.207 35.670869152735186 139.73768834398228 38.207 35.670875442742016 139.73768635918609 38.207 35.67087350657523 139.7376772593223 38.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b1579e8c-6a9d-46d3-be79-040de9e45357">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b1579e8c-6a9d-46d3-be79-040de9e45357">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b1579e8c-6a9d-46d3-be79-040de9e45357">
											<gml:posList>35.67087346379455 139.73769148704267 38.566 35.670869152735186 139.73768834398228 38.566 35.67087183134255 139.7377016184718 38.566 35.67087613338785 139.73770476154377 38.566 35.67087346379455 139.73769148704267 38.566</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a4811349-6eac-42a4-b775-64808aa6dc40">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4811349-6eac-42a4-b775-64808aa6dc40">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4811349-6eac-42a4-b775-64808aa6dc40">
											<gml:posList>35.670758620801536 139.73773807377725 32.386 35.67074164724308 139.73765774316362 32.386 35.67073031984771 139.73766134673065 32.386 35.67074729340377 139.7377416773337 32.386 35.670758620801536 139.73773807377725 32.386</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b3f4e0db-6b3e-411b-92bb-a0ad7173b479">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b3f4e0db-6b3e-411b-92bb-a0ad7173b479">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b3f4e0db-6b3e-411b-92bb-a0ad7173b479">
											<gml:posList>35.6707450436915 139.73774636365115 33.023 35.67074729340377 139.7377416773337 33.023 35.67073031984771 139.73766134673065 33.023 35.670726486813116 139.73765857868148 33.023 35.6707450436915 139.73774636365115 33.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-70405163-de5d-44c3-8c84-a9073bec4d23">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70405163-de5d-44c3-8c84-a9073bec4d23">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70405163-de5d-44c3-8c84-a9073bec4d23">
											<gml:posList>35.67077303932678 139.73773373747738 35.343 35.6707598658518 139.73767142989567 35.349 35.67074835820795 139.73767506681557 35.344 35.6707615226761 139.737737385446 35.344 35.67077303932678 139.73773373747738 35.343</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1d4031f8-8a02-4a73-b4b4-65980df5a9d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d4031f8-8a02-4a73-b4b4-65980df5a9d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d4031f8-8a02-4a73-b4b4-65980df5a9d1">
											<gml:posList>35.670726486813116 139.73765857868148 33.023 35.670706502304284 139.73765723278729 31.009 35.67072658823731 139.73775224019653 31.009 35.6707450436915 139.73774636365115 33.023 35.670726486813116 139.73765857868148 33.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-23e022f5-211b-4a69-bfc8-f9a8c7c3c83d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-23e022f5-211b-4a69-bfc8-f9a8c7c3c83d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-23e022f5-211b-4a69-bfc8-f9a8c7c3c83d">
											<gml:posList>35.67075940795937 139.73774180649198 35.593 35.6707615226761 139.737737385446 35.595 35.67074835820795 139.73767506681557 35.595 35.67074475966208 139.73767246417995 35.593 35.67075940795937 139.73774180649198 35.593</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bfd4efa8-f6d8-4086-95a9-f57d174f7822">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bfd4efa8-f6d8-4086-95a9-f57d174f7822">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bfd4efa8-f6d8-4086-95a9-f57d174f7822">
											<gml:posList>35.670773781240754 139.73773724932042 38.566 35.67077633691928 139.7377319329963 38.566 35.67076792254403 139.73769213211895 38.566 35.67076358444345 139.7376889890949 38.566 35.670773781240754 139.73773724932042 38.566</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-df35afe7-9153-469d-8248-5b23be11f2b5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df35afe7-9153-469d-8248-5b23be11f2b5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df35afe7-9153-469d-8248-5b23be11f2b5">
											<gml:posList>35.67087613338785 139.73770476154377 38.566 35.67087183134255 139.7377016184718 38.566 35.67077633691928 139.7377319329963 38.566 35.670773781240754 139.73773724932042 38.566 35.67087613338785 139.73770476154377 38.566</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e22ebfc9-2bf2-402e-a22a-8cfbcf82146b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e22ebfc9-2bf2-402e-a22a-8cfbcf82146b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e22ebfc9-2bf2-402e-a22a-8cfbcf82146b">
											<gml:posList>35.670773781240754 139.73773724932042 35.593 35.67077303932678 139.73773373747738 35.593 35.6707615226761 139.737737385446 35.595 35.67075940795937 139.73774180649198 35.593 35.670773781240754 139.73773724932042 35.593</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-841f74d3-5dc6-4e93-a987-65db9361fd23">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-841f74d3-5dc6-4e93-a987-65db9361fd23">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-841f74d3-5dc6-4e93-a987-65db9361fd23">
											<gml:posList>35.67075940795937 139.73774180649198 33.023 35.670758620801536 139.73773807377725 33.023 35.67074729340377 139.7377416773337 33.023 35.6707450436915 139.73774636365115 33.023 35.67075940795937 139.73774180649198 33.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-80f111bf-eb12-4c34-b145-36dc5676e9d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-80f111bf-eb12-4c34-b145-36dc5676e9d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-80f111bf-eb12-4c34-b145-36dc5676e9d0">
											<gml:posList>35.67071139552625 139.73765568046548 13.1 35.670706502304284 139.73765723278729 13.1 35.670706502304284 139.73765723278729 31.009 35.67071139552625 139.73765568046548 31.009 35.67071139552625 139.73765568046548 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dbc38242-df3d-46c1-9b80-284b465e4c39">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dbc38242-df3d-46c1-9b80-284b465e4c39">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dbc38242-df3d-46c1-9b80-284b465e4c39">
											<gml:posList>35.670712732145574 139.73764759297518 13.1 35.67071139552625 139.73765568046548 13.1 35.67071139552625 139.73765568046548 31.009 35.670712732145574 139.73764759297518 31.009 35.670712732145574 139.73764759297518 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d919c8f8-19bc-44d8-a11f-3ff1990567ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d919c8f8-19bc-44d8-a11f-3ff1990567ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d919c8f8-19bc-44d8-a11f-3ff1990567ba">
											<gml:posList>35.670706502304284 139.73765723278729 13.1 35.67072658823731 139.73775224019653 13.1 35.67072658823731 139.73775224019653 31.009 35.670706502304284 139.73765723278729 31.009 35.670706502304284 139.73765723278729 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ad43a7b7-f690-4efb-8398-e72dff6104a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad43a7b7-f690-4efb-8398-e72dff6104a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad43a7b7-f690-4efb-8398-e72dff6104a0">
											<gml:posList>35.67073031984771 139.73766134673065 33.023 35.67073031984771 139.73766134673065 32.386 35.67074164724308 139.73765774316362 32.386 35.67074164724308 139.73765774316362 33.023 35.67073031984771 139.73766134673065 33.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d618a0fc-3e4f-4742-8d32-48967440fec5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d618a0fc-3e4f-4742-8d32-48967440fec5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d618a0fc-3e4f-4742-8d32-48967440fec5">
											<gml:posList>35.67074729340377 139.7377416773337 33.023 35.67074729340377 139.7377416773337 32.386 35.67073031984771 139.73766134673065 32.386 35.67073031984771 139.73766134673065 33.023 35.67074729340377 139.7377416773337 33.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-59330c0f-756c-49d6-8e77-89bf6c781f87">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-59330c0f-756c-49d6-8e77-89bf6c781f87">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-59330c0f-756c-49d6-8e77-89bf6c781f87">
											<gml:posList>35.67074164724308 139.73765774316362 33.023 35.67074164724308 139.73765774316362 32.386 35.670758620801536 139.73773807377725 32.386 35.670758620801536 139.73773807377725 33.023 35.67075940795937 139.73774180649198 33.023 35.67075940795937 139.73774180649198 35.593 35.67074475966208 139.73767246417995 35.593 35.670740860091406 139.7376540214969 33.023 35.67074164724308 139.73765774316362 33.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b9019d6-385d-4190-859e-c26e82a5ab47">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b9019d6-385d-4190-859e-c26e82a5ab47">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b9019d6-385d-4190-859e-c26e82a5ab47">
											<gml:posList>35.670758620801536 139.73773807377725 33.023 35.670758620801536 139.73773807377725 32.386 35.67074729340377 139.7377416773337 32.386 35.67074729340377 139.7377416773337 33.023 35.670758620801536 139.73773807377725 33.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ee2ea2b1-9725-4b56-b3fc-26bac59ba735">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee2ea2b1-9725-4b56-b3fc-26bac59ba735">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee2ea2b1-9725-4b56-b3fc-26bac59ba735">
											<gml:posList>35.67074835820795 139.73767506681557 35.595 35.67074835820795 139.73767506681557 35.344 35.6707598658518 139.73767142989567 35.349 35.670759874865524 139.7376714298849 35.6 35.67074835820795 139.73767506681557 35.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4a8aa0fb-08e0-49c5-982c-a8dda11654f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a8aa0fb-08e0-49c5-982c-a8dda11654f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a8aa0fb-08e0-49c5-982c-a8dda11654f6">
											<gml:posList>35.6707615226761 139.737737385446 35.595 35.6707615226761 139.737737385446 35.344 35.67074835820795 139.73767506681557 35.344 35.67074835820795 139.73767506681557 35.595 35.6707615226761 139.737737385446 35.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9ccae40a-ab2a-4991-ac94-4a7cc9c358c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ccae40a-ab2a-4991-ac94-4a7cc9c358c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ccae40a-ab2a-4991-ac94-4a7cc9c358c1">
											<gml:posList>35.670759874865524 139.7376714298849 35.6 35.6707598658518 139.73767142989567 35.349 35.67077303932678 139.73773373747738 35.343 35.67077303932678 139.73773373747738 35.593 35.670773781240754 139.73773724932042 35.593 35.670773781240754 139.73773724932042 38.566 35.67076358444345 139.7376889890949 38.566 35.67075913294964 139.73766791804312 35.6 35.670759874865524 139.7376714298849 35.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2d85e4c5-ab79-4ee2-874d-f89a1d48d419">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d85e4c5-ab79-4ee2-874d-f89a1d48d419">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d85e4c5-ab79-4ee2-874d-f89a1d48d419">
											<gml:posList>35.67077303932678 139.73773373747738 35.593 35.67077303932678 139.73773373747738 35.343 35.6707615226761 139.737737385446 35.344 35.6707615226761 139.737737385446 35.595 35.67077303932678 139.73773373747738 35.593</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-39bf788c-2b93-4bed-a2b2-a87d0bcef84b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-39bf788c-2b93-4bed-a2b2-a87d0bcef84b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-39bf788c-2b93-4bed-a2b2-a87d0bcef84b">
											<gml:posList>35.67077633691928 139.7377319329963 38.566 35.67077633691928 139.7377319329963 38.207 35.67076792254403 139.73769213211895 38.207 35.67076792254403 139.73769213211895 38.566 35.67077633691928 139.7377319329963 38.566</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7641356c-c8b1-493a-9ff8-d95c780e3deb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7641356c-c8b1-493a-9ff8-d95c780e3deb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7641356c-c8b1-493a-9ff8-d95c780e3deb">
											<gml:posList>35.670870639880434 139.7375974530319 13.1 35.670712732145574 139.73764759297518 13.1 35.670712732145574 139.73764759297518 31.009 35.67075218429832 139.73763506356067 31.009 35.670870639880434 139.7375974530319 31.009 35.670870639880434 139.7375974530319 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5a1e53c0-5f76-4ebe-bc56-ebb24952539f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a1e53c0-5f76-4ebe-bc56-ebb24952539f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a1e53c0-5f76-4ebe-bc56-ebb24952539f">
											<gml:posList>35.67072658823731 139.73775224019653 31.009 35.67072658823731 139.73775224019653 13.1 35.67089567023135 139.73769856334297 13.1 35.67089567023135 139.73769856334297 31.009 35.67087613338785 139.73770476154377 31.009 35.67087613338785 139.73770476154377 38.566 35.670773781240754 139.73773724932042 38.566 35.670773781240754 139.73773724932042 35.593 35.67075940795937 139.73774180649198 35.593 35.67075940795937 139.73774180649198 33.023 35.6707450436915 139.73774636365115 33.023 35.67072658823731 139.73775224019653 31.009</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1cf3f92a-0ab1-4762-a851-75a87eb6da2d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1cf3f92a-0ab1-4762-a851-75a87eb6da2d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1cf3f92a-0ab1-4762-a851-75a87eb6da2d">
											<gml:posList>35.67076792254403 139.73769213211895 38.566 35.67076792254403 139.73769213211895 38.207 35.67087947536243 139.73765670603112 38.207 35.67087947536243 139.73765670603112 38.566 35.67076792254403 139.73769213211895 38.566</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-96d1ba9b-409b-476a-bd7b-9d895a7ffb0f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96d1ba9b-409b-476a-bd7b-9d895a7ffb0f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96d1ba9b-409b-476a-bd7b-9d895a7ffb0f">
											<gml:posList>35.67087183134255 139.7377016184718 38.566 35.67087183134255 139.7377016184718 38.207 35.67077633691928 139.7377319329963 38.207 35.67077633691928 139.7377319329963 38.566 35.67087183134255 139.7377016184718 38.566</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3728d828-d365-4380-8146-09d44dbe6804">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3728d828-d365-4380-8146-09d44dbe6804">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3728d828-d365-4380-8146-09d44dbe6804">
											<gml:posList>35.670869152735186 139.73768834398228 38.566 35.670869152735186 139.73768834398228 38.207 35.67087183134255 139.7377016184718 38.207 35.67087183134255 139.7377016184718 38.566 35.670869152735186 139.73768834398228 38.566</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4ef70e94-1ba0-4b48-9d79-6c5fc02033fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ef70e94-1ba0-4b48-9d79-6c5fc02033fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ef70e94-1ba0-4b48-9d79-6c5fc02033fe">
											<gml:posList>35.670875442742016 139.73768635918609 38.566 35.670875442742016 139.73768635918609 38.207 35.670869152735186 139.73768834398228 38.207 35.670869152735186 139.73768834398228 38.566 35.670875442742016 139.73768635918609 38.566</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bbaa3a85-8180-42ca-b6aa-3d6a52cac33b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bbaa3a85-8180-42ca-b6aa-3d6a52cac33b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bbaa3a85-8180-42ca-b6aa-3d6a52cac33b">
											<gml:posList>35.67087350657523 139.7376772593223 38.566 35.67087350657523 139.7376772593223 38.207 35.670875442742016 139.73768635918609 38.207 35.670875442742016 139.73768635918609 38.566 35.67087350657523 139.7376772593223 38.566</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ac1a57db-ba16-4f70-a307-cec5001431f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ac1a57db-ba16-4f70-a307-cec5001431f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ac1a57db-ba16-4f70-a307-cec5001431f4">
											<gml:posList>35.67087346379455 139.73769148704267 38.566 35.67087613338785 139.73770476154377 38.566 35.67087613338785 139.73770476154377 31.009 35.67087346379455 139.73769148704267 31.009 35.67087346379455 139.73769148704267 38.566</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3e50e28f-9801-40e1-bafc-d03e9607c0bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e50e28f-9801-40e1-bafc-d03e9607c0bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e50e28f-9801-40e1-bafc-d03e9607c0bd">
											<gml:posList>35.67087978983876 139.737689480111 38.566 35.67087346379455 139.73769148704267 38.566 35.67087346379455 139.73769148704267 31.009 35.67087978983876 139.737689480111 31.009 35.67087978983876 139.737689480111 38.566</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0dbbe20b-c41f-4884-a258-dc18ad3c219c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0dbbe20b-c41f-4884-a258-dc18ad3c219c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0dbbe20b-c41f-4884-a258-dc18ad3c219c">
											<gml:posList>35.67088316680972 139.7376741327323 38.566 35.67088316680972 139.7376741327323 38.207 35.67087350657523 139.7376772593223 38.207 35.67087350657523 139.7376772593223 38.566 35.67088316680972 139.7376741327323 38.566</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8eb7fc44-8ae2-4d1d-8472-f08f8ae962c6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8eb7fc44-8ae2-4d1d-8472-f08f8ae962c6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8eb7fc44-8ae2-4d1d-8472-f08f8ae962c6">
											<gml:posList>35.67087785365466 139.73768035815402 38.566 35.67087978983876 139.737689480111 38.566 35.67087978983876 139.737689480111 31.009 35.67087785365466 139.73768035815402 31.009 35.67087785365466 139.73768035815402 38.566</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-486ac220-0b58-4bea-b937-04e82cab61ab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-486ac220-0b58-4bea-b937-04e82cab61ab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-486ac220-0b58-4bea-b937-04e82cab61ab">
											<gml:posList>35.67088204004229 139.73765137864035 38.566 35.67088750487551 139.73767723157496 38.566 35.67088750487551 139.73767723157496 31.009 35.670887975361595 139.7376794623721 31.009 35.670887975361595 139.7376794623721 13.1 35.670870639880434 139.7375974530319 13.1 35.670870639880434 139.7375974530319 31.009 35.67088204004229 139.73765137864035 38.566</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c5af56ea-0956-4208-addb-acc0c0bb4e0b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c5af56ea-0956-4208-addb-acc0c0bb4e0b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c5af56ea-0956-4208-addb-acc0c0bb4e0b">
											<gml:posList>35.67087947536243 139.73765670603112 38.566 35.67087947536243 139.73765670603112 38.207 35.67088316680972 139.7376741327323 38.207 35.67088316680972 139.7376741327323 38.566 35.67087947536243 139.73765670603112 38.566</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-28bbcf88-f451-4746-b8ff-753d61791d63">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28bbcf88-f451-4746-b8ff-753d61791d63">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28bbcf88-f451-4746-b8ff-753d61791d63">
											<gml:posList>35.67088750487551 139.73767723157496 38.566 35.67087785365466 139.73768035815402 38.566 35.67087785365466 139.73768035815402 31.009 35.67088750487551 139.73767723157496 31.009 35.67088750487551 139.73767723157496 38.566</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9df21517-7bbe-4984-9121-f5ab2e6d9ab9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9df21517-7bbe-4984-9121-f5ab2e6d9ab9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9df21517-7bbe-4984-9121-f5ab2e6d9ab9">
											<gml:posList>35.67089353497394 139.7376884695444 13.1 35.670887975361595 139.7376794623721 13.1 35.670887975361595 139.7376794623721 31.009 35.67089353497394 139.7376884695444 31.009 35.67089353497394 139.7376884695444 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7eb29cde-cd7b-404e-a47b-f4a923f7e162">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7eb29cde-cd7b-404e-a47b-f4a923f7e162">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7eb29cde-cd7b-404e-a47b-f4a923f7e162">
											<gml:posList>35.67089567023135 139.73769856334297 13.1 35.67089353497394 139.7376884695444 13.1 35.67089353497394 139.7376884695444 31.009 35.67089567023135 139.73769856334297 31.009 35.67089567023135 139.73769856334297 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5143</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">212.06855</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>