<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_61d2334c-99d6-422b-bee3-3742a2548d52">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門二丁目10地区</gen:value>
			</gen:stringAttribute>
			<bldg:measuredHeight uom="m">72.3</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66759893810432 139.74418926359874 0 35.66760430096343 139.74417666533654 0 35.6676234101054 139.74418887187872 0 35.66781734480977 139.7437330236692 0 35.66758702443551 139.74358587383043 0 35.66757938515722 139.74360383192575 0 35.66750478801807 139.74355617517864 0 35.66732687947565 139.7439743378733 0 35.66740147645194 139.74402199490441 0 35.66738772743417 139.7440543193221 0 35.66759893810432 139.74418926359874 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66759893810432 139.74418926359874 15.28 35.66738772743417 139.7440543193221 15.28 35.66740147645194 139.74402199490441 15.28 35.66732687947565 139.7439743378733 15.28 35.66750478801807 139.74355617517864 15.28 35.66757938515722 139.74360383192575 15.28 35.66758702443551 139.74358587383043 15.28 35.66781734480977 139.7437330236692 15.28 35.6676234101054 139.74418887187872 15.28 35.66760430096343 139.74417666533654 15.28 35.66759893810432 139.74418926359874 15.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66759893810432 139.74418926359874 15.28 35.66760430096343 139.74417666533654 15.28 35.66760430096343 139.74417666533654 87.56 35.66759893810432 139.74418926359874 87.56 35.66759893810432 139.74418926359874 15.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66760430096343 139.74417666533654 15.28 35.6676234101054 139.74418887187872 15.28 35.6676234101054 139.74418887187872 87.56 35.66760430096343 139.74417666533654 87.56 35.66760430096343 139.74417666533654 15.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6676234101054 139.74418887187872 15.28 35.66781734480977 139.7437330236692 15.28 35.66781734480977 139.7437330236692 87.56 35.6676234101054 139.74418887187872 87.56 35.6676234101054 139.74418887187872 15.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66781734480977 139.7437330236692 15.28 35.66758702443551 139.74358587383043 15.28 35.66758702443551 139.74358587383043 87.56 35.66781734480977 139.7437330236692 87.56 35.66781734480977 139.7437330236692 15.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66758702443551 139.74358587383043 15.28 35.66757938515722 139.74360383192575 15.28 35.66757938515722 139.74360383192575 87.56 35.66758702443551 139.74358587383043 87.56 35.66758702443551 139.74358587383043 15.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66757938515722 139.74360383192575 15.28 35.66750478801807 139.74355617517864 15.28 35.66750478801807 139.74355617517864 87.56 35.66757938515722 139.74360383192575 87.56 35.66757938515722 139.74360383192575 15.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66750478801807 139.74355617517864 15.28 35.66732687947565 139.7439743378733 15.28 35.66732687947565 139.7439743378733 87.56 35.66750478801807 139.74355617517864 87.56 35.66750478801807 139.74355617517864 15.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66732687947565 139.7439743378733 15.28 35.66740147645194 139.74402199490441 15.28 35.66740147645194 139.74402199490441 87.56 35.66732687947565 139.7439743378733 87.56 35.66732687947565 139.7439743378733 15.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66740147645194 139.74402199490441 15.28 35.66738772743417 139.7440543193221 15.28 35.66738772743417 139.7440543193221 87.56 35.66740147645194 139.74402199490441 87.56 35.66740147645194 139.74402199490441 15.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66738772743417 139.7440543193221 15.28 35.66759893810432 139.74418926359874 15.28 35.66759893810432 139.74418926359874 87.56 35.66738772743417 139.7440543193221 87.56 35.66738772743417 139.7440543193221 15.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66759893810432 139.74418926359874 87.56 35.66760430096343 139.74417666533654 87.56 35.6676234101054 139.74418887187872 87.56 35.66781734480977 139.7437330236692 87.56 35.66758702443551 139.74358587383043 87.56 35.66757938515722 139.74360383192575 87.56 35.66750478801807 139.74355617517864 87.56 35.66732687947565 139.7439743378733 87.56 35.66740147645194 139.74402199490441 87.56 35.66738772743417 139.7440543193221 87.56 35.66759893810432 139.74418926359874 87.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-6d59931b-ac8a-431f-997d-7af9f77c7af3"/>
							<gml:surfaceMember xlink:href="#poly-3503c4a0-7857-4c90-a84e-a7bc01502a00"/>
							<gml:surfaceMember xlink:href="#poly-5c58e264-4d72-43f2-992e-7d6e53f2f912"/>
							<gml:surfaceMember xlink:href="#poly-01746090-65fe-4ec7-be89-abff96dec177"/>
							<gml:surfaceMember xlink:href="#poly-57d3d435-0279-49c9-9d6e-7f542b3c4eed"/>
							<gml:surfaceMember xlink:href="#poly-76be2485-a91e-42b6-afc0-c3b1bc0bcfb0"/>
							<gml:surfaceMember xlink:href="#poly-e324c422-6221-4f05-886c-a3c5d3aecb8a"/>
							<gml:surfaceMember xlink:href="#poly-31771bd1-76c4-4c7d-a189-06cb39c6cee1"/>
							<gml:surfaceMember xlink:href="#poly-870b0918-379d-4370-b918-ecd8cea55338"/>
							<gml:surfaceMember xlink:href="#poly-73acf830-619a-4cb0-bf5b-d27a7e562f48"/>
							<gml:surfaceMember xlink:href="#poly-40a18e83-4c34-4f11-a4d3-f0e5f5eaa1a0"/>
							<gml:surfaceMember xlink:href="#poly-862a8393-a532-45e0-8395-07c89bdc0628"/>
							<gml:surfaceMember xlink:href="#poly-07420a9a-1f0d-4adf-9dd2-ef2a6d4c321f"/>
							<gml:surfaceMember xlink:href="#poly-6f706008-02e2-4e3b-9b5c-e8562beb99c3"/>
							<gml:surfaceMember xlink:href="#poly-28520f83-c297-4c0f-bab0-42943da8187a"/>
							<gml:surfaceMember xlink:href="#poly-278d4050-c074-4f45-b133-1d3b00dcbca8"/>
							<gml:surfaceMember xlink:href="#poly-f91aec2c-ba4d-4137-9971-1bc786427bde"/>
							<gml:surfaceMember xlink:href="#poly-bddb4997-85ab-4112-bbd6-9b7368cf4aea"/>
							<gml:surfaceMember xlink:href="#poly-1cdebf1f-6d60-4b3b-890b-e65a2ca1338f"/>
							<gml:surfaceMember xlink:href="#poly-33f9d014-330e-41d0-825a-7f454b13062e"/>
							<gml:surfaceMember xlink:href="#poly-b8fe7e65-7294-4732-9e8b-adcf188f2972"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_61d2334c-99d6-422b-bee3-3742a2548d52_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01a0f104-0f1d-4828-9a95-a5e4c8232620">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667529522825376 139.7440669083781 90.264 35.66751902943084 139.74408933212118 90.264 35.667505465702504 139.7440797925449 90.264 35.66751595910348 139.74405737985026 90.264 35.667529522825376 139.7440669083781 90.264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b41da15b-de7f-48f5-8715-ada71fe38716">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66757901014906 139.74408165475768 90.264 35.667469711423074 139.74401118232956 90.264 35.66760826512108 139.74368848835428 90.264 35.66771757304666 139.74375896045342 90.264 35.66757901014906 139.74408165475768 90.264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-420b0cb9-ec19-4ce4-bb3a-3e13c0674f7b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-420b0cb9-ec19-4ce4-bb3a-3e13c0674f7b_0">
											<gml:posList>35.66771757304666 139.74375896045342 90.264 35.66760826512108 139.74368848835428 90.264 35.66760826512108 139.74368848835428 93.5 35.66771757304666 139.74375896045342 93.5 35.66771757304666 139.74375896045342 90.264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a75f3914-4082-442a-b9d7-5524abbd9e85">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a75f3914-4082-442a-b9d7-5524abbd9e85_0">
											<gml:posList>35.667469711423074 139.74401118232956 90.264 35.667469711423074 139.74401118232956 93.5 35.66760826512108 139.74368848835428 93.5 35.66760826512108 139.74368848835428 90.264 35.667469711423074 139.74401118232956 90.264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a9a2205-8719-4c12-b3dc-77782591b8de">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9a9a2205-8719-4c12-b3dc-77782591b8de_0">
											<gml:posList>35.66757901014906 139.74408165475768 93.5 35.66771757304666 139.74375896045342 93.5 35.66760826512108 139.74368848835428 93.5 35.667469711423074 139.74401118232956 93.5 35.66757901014906 139.74408165475768 93.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11760a67-8ffc-4b70-a373-42a1438d2e5c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-11760a67-8ffc-4b70-a373-42a1438d2e5c_0">
											<gml:posList>35.66757901014906 139.74408165475768 90.264 35.66771757304666 139.74375896045342 90.264 35.66771757304666 139.74375896045342 93.5 35.66757901014906 139.74408165475768 93.5 35.66757901014906 139.74408165475768 90.264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c92d1233-5a61-48c9-af36-89a96a52f087">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c92d1233-5a61-48c9-af36-89a96a52f087_0">
											<gml:posList>35.667469711423074 139.74401118232956 90.264 35.66757901014906 139.74408165475768 90.264 35.66757901014906 139.74408165475768 93.5 35.667469711423074 139.74401118232956 93.5 35.667469711423074 139.74401118232956 90.264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f10aa46-1b4a-4887-a2a3-0ded7905c85b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f10aa46-1b4a-4887-a2a3-0ded7905c85b_0">
											<gml:posList>35.667529522825376 139.7440669083781 90.264 35.66751595910348 139.74405737985026 90.264 35.66751595910348 139.74405737985026 93.5 35.667529522825376 139.7440669083781 93.5 35.667529522825376 139.7440669083781 90.264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-881c97d5-adbf-430a-861d-a75b7ce611ab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-881c97d5-adbf-430a-861d-a75b7ce611ab_0">
											<gml:posList>35.66751595910348 139.74405737985026 90.264 35.667505465702504 139.7440797925449 90.264 35.667505465702504 139.7440797925449 93.5 35.66751595910348 139.74405737985026 93.5 35.66751595910348 139.74405737985026 90.264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e5e834df-c871-45fd-85a6-2c383a129e39">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e5e834df-c871-45fd-85a6-2c383a129e39_0">
											<gml:posList>35.667529522825376 139.7440669083781 93.5 35.66751595910348 139.74405737985026 93.5 35.667505465702504 139.7440797925449 93.5 35.66751902943084 139.74408933212118 93.5 35.667529522825376 139.7440669083781 93.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-838db3e1-b112-4de8-ba05-1a8d6c520415">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-838db3e1-b112-4de8-ba05-1a8d6c520415_0">
											<gml:posList>35.66751902943084 139.74408933212118 90.264 35.667529522825376 139.7440669083781 90.264 35.667529522825376 139.7440669083781 93.5 35.66751902943084 139.74408933212118 93.5 35.66751902943084 139.74408933212118 90.264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4081e84c-e511-4def-a878-84168f17110a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4081e84c-e511-4def-a878-84168f17110a_0">
											<gml:posList>35.667505465702504 139.7440797925449 90.264 35.66751902943084 139.74408933212118 90.264 35.66751902943084 139.74408933212118 93.5 35.667505465702504 139.7440797925449 93.5 35.667505465702504 139.7440797925449 90.264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-6d59931b-ac8a-431f-997d-7af9f77c7af3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d59931b-ac8a-431f-997d-7af9f77c7af3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d59931b-ac8a-431f-997d-7af9f77c7af3">
											<gml:posList>35.66760430096342 139.74417666533654 15.28 35.66759893810432 139.74418926359877 15.28 35.66738772743417 139.7440543193221 15.28 35.66740147645195 139.74402199490441 15.28 35.66732687947565 139.74397433787328 15.28 35.66750478801806 139.74355617517864 15.28 35.667579385157225 139.74360383192575 15.28 35.667587024435484 139.74358587383045 15.28 35.667817344809734 139.7437330236692 15.28 35.66762341010539 139.7441888718787 15.28 35.66760430096342 139.74417666533654 15.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3503c4a0-7857-4c90-a84e-a7bc01502a00">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3503c4a0-7857-4c90-a84e-a7bc01502a00">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3503c4a0-7857-4c90-a84e-a7bc01502a00">
											<gml:posList>35.667579385157225 139.74360383192575 38.4 35.66750478801806 139.74355617517864 38.4 35.66732687947565 139.74397433787328 38.4 35.66740147645195 139.74402199490441 38.4 35.667579385157225 139.74360383192575 38.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5c58e264-4d72-43f2-992e-7d6e53f2f912">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5c58e264-4d72-43f2-992e-7d6e53f2f912">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5c58e264-4d72-43f2-992e-7d6e53f2f912">
											<gml:posList>35.66759893810432 139.74418926359877 93.5 35.667587168278466 139.74414342525623 93.5 35.667425132755696 139.744039895975 93.5 35.66738772743417 139.7440543193221 93.5 35.66759893810432 139.74418926359877 93.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-01746090-65fe-4ec7-be89-abff96dec177">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-01746090-65fe-4ec7-be89-abff96dec177">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-01746090-65fe-4ec7-be89-abff96dec177">
											<gml:posList>35.66738772743417 139.7440543193221 93.5 35.667425132755696 139.744039895975 93.5 35.66759879446522 139.74363170104473 93.5 35.667587024435484 139.74358587383045 93.5 35.66738772743417 139.7440543193221 93.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-57d3d435-0279-49c9-9d6e-7f542b3c4eed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-57d3d435-0279-49c9-9d6e-7f542b3c4eed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-57d3d435-0279-49c9-9d6e-7f542b3c4eed">
											<gml:posList>35.667760830333386 139.74373522972377 90.264 35.66759879446522 139.74363170104473 90.264 35.667425132755696 139.744039895975 90.264 35.667587168278466 139.74414342525623 90.264 35.667760830333386 139.74373522972377 90.264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-76be2485-a91e-42b6-afc0-c3b1bc0bcfb0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-76be2485-a91e-42b6-afc0-c3b1bc0bcfb0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-76be2485-a91e-42b6-afc0-c3b1bc0bcfb0">
											<gml:posList>35.66779823562228 139.74372081720634 93.5 35.667760830333386 139.74373522972377 93.5 35.667587168278466 139.74414342525623 93.5 35.66759893810432 139.74418926359877 93.5 35.66779823562228 139.74372081720634 93.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e324c422-6221-4f05-886c-a3c5d3aecb8a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e324c422-6221-4f05-886c-a3c5d3aecb8a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e324c422-6221-4f05-886c-a3c5d3aecb8a">
											<gml:posList>35.667587024435484 139.74358587383045 93.5 35.66759879446522 139.74363170104473 93.5 35.667760830333386 139.74373522972377 93.5 35.66779823562228 139.74372081720634 93.5 35.667587024435484 139.74358587383045 93.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-31771bd1-76c4-4c7d-a189-06cb39c6cee1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31771bd1-76c4-4c7d-a189-06cb39c6cee1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31771bd1-76c4-4c7d-a189-06cb39c6cee1">
											<gml:posList>35.66779823562228 139.74372081720634 50.4 35.66760430096342 139.74417666533654 50.4 35.66762341010539 139.7441888718787 50.4 35.667817344809734 139.7437330236692 50.4 35.66779823562228 139.74372081720634 50.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-870b0918-379d-4370-b918-ecd8cea55338">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-870b0918-379d-4370-b918-ecd8cea55338">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-870b0918-379d-4370-b918-ecd8cea55338">
											<gml:posList>35.667425132755696 139.744039895975 93.5 35.667425132755696 139.744039895975 90.264 35.66759879446522 139.74363170104473 90.264 35.66759879446522 139.74363170104473 93.5 35.667425132755696 139.744039895975 93.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-73acf830-619a-4cb0-bf5b-d27a7e562f48">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73acf830-619a-4cb0-bf5b-d27a7e562f48">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73acf830-619a-4cb0-bf5b-d27a7e562f48">
											<gml:posList>35.667760830333386 139.74373522972377 93.5 35.667760830333386 139.74373522972377 90.264 35.667587168278466 139.74414342525623 90.264 35.667587168278466 139.74414342525623 93.5 35.667760830333386 139.74373522972377 93.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-40a18e83-4c34-4f11-a4d3-f0e5f5eaa1a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-40a18e83-4c34-4f11-a4d3-f0e5f5eaa1a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-40a18e83-4c34-4f11-a4d3-f0e5f5eaa1a0">
											<gml:posList>35.66732687947565 139.74397433787328 15.28 35.66740147645195 139.74402199490441 15.28 35.66740147645195 139.74402199490441 38.4 35.66732687947565 139.74397433787328 38.4 35.66732687947565 139.74397433787328 15.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-862a8393-a532-45e0-8395-07c89bdc0628">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-862a8393-a532-45e0-8395-07c89bdc0628">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-862a8393-a532-45e0-8395-07c89bdc0628">
											<gml:posList>35.66750478801806 139.74355617517864 15.28 35.66732687947565 139.74397433787328 15.28 35.66732687947565 139.74397433787328 38.4 35.66750478801806 139.74355617517864 38.4 35.66750478801806 139.74355617517864 15.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-07420a9a-1f0d-4adf-9dd2-ef2a6d4c321f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-07420a9a-1f0d-4adf-9dd2-ef2a6d4c321f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-07420a9a-1f0d-4adf-9dd2-ef2a6d4c321f">
											<gml:posList>35.667587024435484 139.74358587383045 93.5 35.667587024435484 139.74358587383045 15.28 35.667579385157225 139.74360383192575 15.28 35.667579385157225 139.74360383192575 38.4 35.66740147645195 139.74402199490441 38.4 35.66740147645195 139.74402199490441 15.28 35.66738772743417 139.7440543193221 15.28 35.66738772743417 139.7440543193221 93.5 35.667587024435484 139.74358587383045 93.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6f706008-02e2-4e3b-9b5c-e8562beb99c3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f706008-02e2-4e3b-9b5c-e8562beb99c3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f706008-02e2-4e3b-9b5c-e8562beb99c3">
											<gml:posList>35.66738772743417 139.7440543193221 15.28 35.66759893810432 139.74418926359877 15.28 35.66759893810432 139.74418926359877 93.5 35.66738772743417 139.7440543193221 93.5 35.66738772743417 139.7440543193221 15.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-28520f83-c297-4c0f-bab0-42943da8187a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28520f83-c297-4c0f-bab0-42943da8187a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28520f83-c297-4c0f-bab0-42943da8187a">
											<gml:posList>35.667587168278466 139.74414342525623 93.5 35.667587168278466 139.74414342525623 90.264 35.667425132755696 139.744039895975 90.264 35.667425132755696 139.744039895975 93.5 35.667587168278466 139.74414342525623 93.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-278d4050-c074-4f45-b133-1d3b00dcbca8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-278d4050-c074-4f45-b133-1d3b00dcbca8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-278d4050-c074-4f45-b133-1d3b00dcbca8">
											<gml:posList>35.667579385157225 139.74360383192575 15.28 35.66750478801806 139.74355617517864 15.28 35.66750478801806 139.74355617517864 38.4 35.667579385157225 139.74360383192575 38.4 35.667579385157225 139.74360383192575 15.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f91aec2c-ba4d-4137-9971-1bc786427bde">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f91aec2c-ba4d-4137-9971-1bc786427bde">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f91aec2c-ba4d-4137-9971-1bc786427bde">
											<gml:posList>35.66760430096342 139.74417666533654 15.28 35.66762341010539 139.7441888718787 15.28 35.66762341010539 139.7441888718787 50.4 35.66760430096342 139.74417666533654 50.4 35.66760430096342 139.74417666533654 15.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bddb4997-85ab-4112-bbd6-9b7368cf4aea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bddb4997-85ab-4112-bbd6-9b7368cf4aea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bddb4997-85ab-4112-bbd6-9b7368cf4aea">
											<gml:posList>35.66759879446522 139.74363170104473 93.5 35.66759879446522 139.74363170104473 90.264 35.667760830333386 139.74373522972377 90.264 35.667760830333386 139.74373522972377 93.5 35.66759879446522 139.74363170104473 93.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1cdebf1f-6d60-4b3b-890b-e65a2ca1338f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1cdebf1f-6d60-4b3b-890b-e65a2ca1338f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1cdebf1f-6d60-4b3b-890b-e65a2ca1338f">
											<gml:posList>35.66759893810432 139.74418926359877 93.5 35.66759893810432 139.74418926359877 15.28 35.66760430096342 139.74417666533654 15.28 35.66760430096342 139.74417666533654 50.4 35.66779823562228 139.74372081720634 50.4 35.66779823562228 139.74372081720634 93.5 35.66759893810432 139.74418926359877 93.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-33f9d014-330e-41d0-825a-7f454b13062e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-33f9d014-330e-41d0-825a-7f454b13062e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-33f9d014-330e-41d0-825a-7f454b13062e">
											<gml:posList>35.667587024435484 139.74358587383045 15.28 35.667587024435484 139.74358587383045 93.5 35.66779823562228 139.74372081720634 93.5 35.66779823562228 139.74372081720634 50.4 35.667817344809734 139.7437330236692 50.4 35.667817344809734 139.7437330236692 15.28 35.667587024435484 139.74358587383045 15.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b8fe7e65-7294-4732-9e8b-adcf188f2972">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8fe7e65-7294-4732-9e8b-adcf188f2972">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8fe7e65-7294-4732-9e8b-adcf188f2972">
											<gml:posList>35.66762341010539 139.7441888718787 15.28 35.667817344809734 139.7437330236692 15.28 35.667817344809734 139.7437330236692 50.4 35.66762341010539 139.7441888718787 50.4 35.66762341010539 139.7441888718787 15.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8445</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.04</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>