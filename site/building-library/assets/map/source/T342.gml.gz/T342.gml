<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_6250f97a-f726-45d0-93ea-1e441d1680f2">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">422</bldg:usage>
			<bldg:measuredHeight uom="m">15.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66702572893887 139.74213268730972 0 35.66696463706574 139.74227988670268 0 35.667059280721496 139.74233875277173 0 35.667210300659214 139.74197474303625 0 35.667101092688895 139.7419067148243 0 35.667011119839 139.742123646373 0 35.66702572893887 139.74213268730972 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66702572893887 139.74213268730972 25.5 35.667011119839 139.742123646373 25.5 35.667101092688895 139.7419067148243 25.5 35.667210300659214 139.74197474303625 25.5 35.667059280721496 139.74233875277173 25.5 35.66696463706574 139.74227988670268 25.5 35.66702572893887 139.74213268730972 25.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66702572893887 139.74213268730972 25.5 35.66696463706574 139.74227988670268 25.5 35.66696463706574 139.74227988670268 41.2 35.66702572893887 139.74213268730972 41.2 35.66702572893887 139.74213268730972 25.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66696463706574 139.74227988670268 25.5 35.667059280721496 139.74233875277173 25.5 35.667059280721496 139.74233875277173 41.2 35.66696463706574 139.74227988670268 41.2 35.66696463706574 139.74227988670268 25.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667059280721496 139.74233875277173 25.5 35.667210300659214 139.74197474303625 25.5 35.667210300659214 139.74197474303625 41.2 35.667059280721496 139.74233875277173 41.2 35.667059280721496 139.74233875277173 25.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667210300659214 139.74197474303625 25.5 35.667101092688895 139.7419067148243 25.5 35.667101092688895 139.7419067148243 41.2 35.667210300659214 139.74197474303625 41.2 35.667210300659214 139.74197474303625 25.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667101092688895 139.7419067148243 25.5 35.667011119839 139.742123646373 25.5 35.667011119839 139.742123646373 41.2 35.667101092688895 139.7419067148243 41.2 35.667101092688895 139.7419067148243 25.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667011119839 139.742123646373 25.5 35.66702572893887 139.74213268730972 25.5 35.66702572893887 139.74213268730972 41.2 35.667011119839 139.742123646373 41.2 35.667011119839 139.742123646373 25.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66702572893887 139.74213268730972 41.2 35.66696463706574 139.74227988670268 41.2 35.667059280721496 139.74233875277173 41.2 35.667210300659214 139.74197474303625 41.2 35.667101092688895 139.7419067148243 41.2 35.667011119839 139.742123646373 41.2 35.66702572893887 139.74213268730972 41.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-2b9a0a8f-7372-4df1-b11e-975363caad8f"/>
							<gml:surfaceMember xlink:href="#poly-efe024c3-71ff-406c-8b9c-1d6b098d3753"/>
							<gml:surfaceMember xlink:href="#poly-824a9b1e-35ef-4bb1-a087-e59610fa50ee"/>
							<gml:surfaceMember xlink:href="#poly-64759089-2c25-4611-b1f2-d2a754395dc5"/>
							<gml:surfaceMember xlink:href="#poly-079eaee3-8bee-490c-a5d1-b5b93fe55e66"/>
							<gml:surfaceMember xlink:href="#poly-7237c7c7-d33c-4424-ac18-d4b861075234"/>
							<gml:surfaceMember xlink:href="#poly-e621e5df-5f01-4bf1-9202-4ff3842d37c9"/>
							<gml:surfaceMember xlink:href="#poly-69e9af00-59fe-4ca1-8e92-1c2f98963a4f"/>
							<gml:surfaceMember xlink:href="#poly-1cadf626-11e3-4db2-9a8e-f37a936c6da3"/>
							<gml:surfaceMember xlink:href="#poly-6c72442c-d3ec-442d-99d9-6948552586d2"/>
							<gml:surfaceMember xlink:href="#poly-ff8f7f5c-c245-4c37-ad18-628310f03ded"/>
							<gml:surfaceMember xlink:href="#poly-79d213d9-f6d0-4c09-b51d-1ffbb9170b21"/>
							<gml:surfaceMember xlink:href="#poly-b292eede-fcdf-49f1-8da9-345a7f0d8d4d"/>
							<gml:surfaceMember xlink:href="#poly-ef8b4f3a-f144-40ef-b839-70fa78d3665d"/>
							<gml:surfaceMember xlink:href="#poly-8e8e09a9-46d4-4ae4-8bc6-2dbaf8378daa"/>
							<gml:surfaceMember xlink:href="#poly-088bb0c9-e3c3-4b3d-91d2-2cdc992ae394"/>
							<gml:surfaceMember xlink:href="#poly-746a411e-a322-45a2-b1b8-d4cda5ad33b3"/>
							<gml:surfaceMember xlink:href="#poly-78a6ca25-f495-4c8d-b70c-b08e141505cb"/>
							<gml:surfaceMember xlink:href="#poly-96e4edaa-59a5-4492-b7c5-413fcf607d62"/>
							<gml:surfaceMember xlink:href="#poly-6ffecca6-ecdf-4fe7-b19e-fb517a943502"/>
							<gml:surfaceMember xlink:href="#poly-1c0a87cf-f76e-48e0-a153-e7f1c3a17425"/>
							<gml:surfaceMember xlink:href="#poly-d50a6f17-5af2-40fc-aa12-5434aae4c8a5"/>
							<gml:surfaceMember xlink:href="#poly-18416b9f-f053-440f-931a-15dbc1177fc0"/>
							<gml:surfaceMember xlink:href="#poly-88aa914d-faf6-45f0-82c5-85365a44ced0"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_6250f97a-f726-45d0-93ea-1e441d1680f2_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80e6e285-ca86-4683-822d-e7505a7ffbca">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667042860551035 139.74237832641424 25.5 35.66701914326507 139.7423635519488 25.5 35.66703551837042 139.74232398941191 25.5 35.66705928072145 139.74233875277173 25.5 35.667042860551035 139.74237832641424 25.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ae148970-d396-464e-b36d-024bf4a335b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ae148970-d396-464e-b36d-024bf4a335b2_0">
											<gml:posList>35.66705928072145 139.74233875277173 38.7 35.66705928072145 139.74233875277173 25.5 35.66703551837042 139.74232398941191 25.5 35.66703551837042 139.74232398941191 38.7 35.66705928072145 139.74233875277173 38.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eee9d356-d90f-4d21-8a9f-6a3346670547">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eee9d356-d90f-4d21-8a9f-6a3346670547_0">
											<gml:posList>35.66703551837042 139.74232398941191 38.7 35.66703551837042 139.74232398941191 25.5 35.66701914326507 139.7423635519488 25.5 35.66701914326507 139.7423635519488 37.342 35.667024703601385 139.74235011395123 37.342 35.66703551837042 139.74232398941191 38.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73c95446-da0f-4246-ab40-3c453a6d8c89">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73c95446-da0f-4246-ab40-3c453a6d8c89_0">
											<gml:posList>35.66705928072145 139.74233875277173 38.7 35.66703551837042 139.74232398941191 38.7 35.667024703601385 139.74235011395123 37.342 35.66704868184483 139.7423643026902 37.342 35.66705928072145 139.74233875277173 38.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf6947f7-0cb2-4f97-974a-da8beb6201ad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cf6947f7-0cb2-4f97-974a-da8beb6201ad_0">
											<gml:posList>35.667042860551035 139.74237832641424 37.342 35.667042860551035 139.74237832641424 25.5 35.66705928072145 139.74233875277173 25.5 35.66705928072145 139.74233875277173 38.7 35.66704868184483 139.7423643026902 37.342 35.667042860551035 139.74237832641424 37.342</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e08d140b-2649-4a83-93a3-43f1ff00bcb9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e08d140b-2649-4a83-93a3-43f1ff00bcb9_0">
											<gml:posList>35.667024703601385 139.74235011395123 37.342 35.66701914326507 139.7423635519488 37.342 35.667042860551035 139.74237832641424 37.342 35.66704868184483 139.7423643026902 37.342 35.667024703601385 139.74235011395123 37.342</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dfbdb995-92b9-451a-94a8-f7e61ecb7f5e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dfbdb995-92b9-451a-94a8-f7e61ecb7f5e_0">
											<gml:posList>35.66701914326507 139.7423635519488 37.342 35.66701914326507 139.7423635519488 25.5 35.667042860551035 139.74237832641424 25.5 35.667042860551035 139.74237832641424 37.342 35.66701914326507 139.7423635519488 37.342</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_6250f97a-f726-45d0-93ea-1e441d1680f2_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b69e44d-9ff9-48d0-83d8-564fe464331a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66708593537199 139.7421256599766 42.756 35.667096107324745 139.74213154686774 42.334 35.667087255190005 139.74215449907481 42.346 35.6670770922521 139.74214861217115 42.748 35.66708593537199 139.7421256599766 42.756</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-31bd8244-820b-4f18-a2c0-215178e563d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-31bd8244-820b-4f18-a2c0-215178e563d4_0">
											<gml:posList>35.6670770922521 139.74214861217115 43.146 35.66708593537199 139.7421256599766 43.146 35.66708593537199 139.7421256599766 42.756 35.6670770922521 139.74214861217115 42.748 35.6670770922521 139.74214861217115 43.146</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d25c00dc-b8bf-49b7-acbb-fb286f069c44">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d25c00dc-b8bf-49b7-acbb-fb286f069c44_0">
											<gml:posList>35.667087255190005 139.74215449907481 43.146 35.6670770922521 139.74214861217115 43.146 35.6670770922521 139.74214861217115 42.748 35.667087255190005 139.74215449907481 42.346 35.667087255190005 139.74215449907481 43.146</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35fc3ccb-9ad7-4b32-bfc6-ce862303131a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-35fc3ccb-9ad7-4b32-bfc6-ce862303131a_0">
											<gml:posList>35.667096107324745 139.74213154686774 43.146 35.66708593537199 139.7421256599766 43.146 35.6670770922521 139.74214861217115 43.146 35.667087255190005 139.74215449907481 43.146 35.667096107324745 139.74213154686774 43.146</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b224bc2-0273-4a8a-9449-9a84e5586606">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b224bc2-0273-4a8a-9449-9a84e5586606_0">
											<gml:posList>35.66708593537199 139.7421256599766 42.756 35.66708593537199 139.7421256599766 43.146 35.667096107324745 139.74213154686774 43.146 35.667096107324745 139.74213154686774 42.334 35.66708593537199 139.7421256599766 42.756</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-31983f45-ce42-4563-b51e-0b43987bd946">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-31983f45-ce42-4563-b51e-0b43987bd946_0">
											<gml:posList>35.667096107324745 139.74213154686774 43.146 35.667087255190005 139.74215449907481 43.146 35.667087255190005 139.74215449907481 42.346 35.667096107324745 139.74213154686774 42.334 35.667096107324745 139.74213154686774 43.146</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-2b9a0a8f-7372-4df1-b11e-975363caad8f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b9a0a8f-7372-4df1-b11e-975363caad8f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b9a0a8f-7372-4df1-b11e-975363caad8f">
											<gml:posList>35.66710109268888 139.7419067148243 25.5 35.66721030065918 139.74197474303625 25.5 35.66705928072145 139.74233875277173 25.5 35.666964637065725 139.74227988670265 25.5 35.66702572893886 139.74213268730972 25.5 35.667011119839 139.74212364637296 25.5 35.66710109268888 139.7419067148243 25.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-efe024c3-71ff-406c-8b9c-1d6b098d3753">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-efe024c3-71ff-406c-8b9c-1d6b098d3753">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-efe024c3-71ff-406c-8b9c-1d6b098d3753">
											<gml:posList>35.66702572893886 139.74213268730972 38.7 35.666964637065725 139.74227988670265 38.7 35.66700471295586 139.7423048157379 40.796 35.66706568766378 139.7421575943319 40.796 35.66702572893886 139.74213268730972 38.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-824a9b1e-35ef-4bb1-a087-e59610fa50ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-824a9b1e-35ef-4bb1-a087-e59610fa50ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-824a9b1e-35ef-4bb1-a087-e59610fa50ee">
											<gml:posList>35.66710910027158 139.7421846513855 38.979 35.66706568766378 139.7421575943319 40.796 35.66700471295586 139.7423048157379 40.796 35.66710910027158 139.7421846513855 38.979</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-64759089-2c25-4611-b1f2-d2a754395dc5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-64759089-2c25-4611-b1f2-d2a754395dc5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-64759089-2c25-4611-b1f2-d2a754395dc5">
											<gml:posList>35.66713386859834 139.74215896380915 38.7 35.66700471295586 139.7423048157379 40.796 35.66705928072145 139.74233875277173 38.7 35.66713386859834 139.74215896380915 38.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-079eaee3-8bee-490c-a5d1-b5b93fe55e66">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-079eaee3-8bee-490c-a5d1-b5b93fe55e66">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-079eaee3-8bee-490c-a5d1-b5b93fe55e66">
											<gml:posList>35.66713386859834 139.74215896380915 38.7 35.66710910027158 139.7421846513855 38.979 35.66700471295586 139.7423048157379 40.796 35.66713386859834 139.74215896380915 38.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7237c7c7-d33c-4424-ac18-d4b861075234">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7237c7c7-d33c-4424-ac18-d4b861075234">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7237c7c7-d33c-4424-ac18-d4b861075234">
											<gml:posList>35.66710109268888 139.7419067148243 40.5 35.667011119839 139.74212364637296 40.5 35.66706575081006 139.7421576605349 43.008 35.667155696679046 139.74194072890714 43.008 35.66710109268888 139.7419067148243 40.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e621e5df-5f01-4bf1-9202-4ff3842d37c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e621e5df-5f01-4bf1-9202-4ff3842d37c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e621e5df-5f01-4bf1-9202-4ff3842d37c9">
											<gml:posList>35.66712265923187 139.74215197351032 41.225 35.66706575081006 139.7421576605349 43.008 35.66710910027158 139.7421846513855 41.225 35.66712265923187 139.74215197351032 41.225</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-69e9af00-59fe-4ca1-8e92-1c2f98963a4f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69e9af00-59fe-4ca1-8e92-1c2f98963a4f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69e9af00-59fe-4ca1-8e92-1c2f98963a4f">
											<gml:posList>35.66713386859834 139.74215896380915 38.7 35.66712265923187 139.74215197351032 38.979 35.66710910027158 139.7421846513855 38.979 35.66713386859834 139.74215896380915 38.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1cadf626-11e3-4db2-9a8e-f37a936c6da3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1cadf626-11e3-4db2-9a8e-f37a936c6da3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1cadf626-11e3-4db2-9a8e-f37a936c6da3">
											<gml:posList>35.66712265923187 139.74215197351032 41.225 35.66721030065918 139.74197474303625 40.5 35.66706575081006 139.7421576605349 43.008 35.66712265923187 139.74215197351032 41.225</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6c72442c-d3ec-442d-99d9-6948552586d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c72442c-d3ec-442d-99d9-6948552586d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c72442c-d3ec-442d-99d9-6948552586d2">
											<gml:posList>35.66721030065918 139.74197474303625 40.5 35.667155696679046 139.74194072890714 43.008 35.66706575081006 139.7421576605349 43.008 35.66721030065918 139.74197474303625 40.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ff8f7f5c-c245-4c37-ad18-628310f03ded">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff8f7f5c-c245-4c37-ad18-628310f03ded">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff8f7f5c-c245-4c37-ad18-628310f03ded">
											<gml:posList>35.66712265923187 139.74215197351032 41.225 35.66713386859834 139.74215896380915 40.5 35.66721030065918 139.74197474303625 40.5 35.66712265923187 139.74215197351032 41.225</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-79d213d9-f6d0-4c09-b51d-1ffbb9170b21">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79d213d9-f6d0-4c09-b51d-1ffbb9170b21">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79d213d9-f6d0-4c09-b51d-1ffbb9170b21">
											<gml:posList>35.667155696679046 139.74194072890714 43.008 35.66721030065918 139.74197474303625 40.5 35.66721030065918 139.74197474303625 25.5 35.66710109268888 139.7419067148243 25.5 35.66710109268888 139.7419067148243 40.5 35.667155696679046 139.74194072890714 43.008</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b292eede-fcdf-49f1-8da9-345a7f0d8d4d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b292eede-fcdf-49f1-8da9-345a7f0d8d4d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b292eede-fcdf-49f1-8da9-345a7f0d8d4d">
											<gml:posList>35.66710109268888 139.7419067148243 25.5 35.667011119839 139.74212364637296 25.5 35.667011119839 139.74212364637296 40.5 35.66710109268888 139.7419067148243 40.5 35.66710109268888 139.7419067148243 25.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ef8b4f3a-f144-40ef-b839-70fa78d3665d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef8b4f3a-f144-40ef-b839-70fa78d3665d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef8b4f3a-f144-40ef-b839-70fa78d3665d">
											<gml:posList>35.667011119839 139.74212364637296 40.5 35.66702572893886 139.74213268730972 25.5 35.66702572893886 139.74213268730972 38.7 35.667011119839 139.74212364637296 40.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8e8e09a9-46d4-4ae4-8bc6-2dbaf8378daa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8e8e09a9-46d4-4ae4-8bc6-2dbaf8378daa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8e8e09a9-46d4-4ae4-8bc6-2dbaf8378daa">
											<gml:posList>35.667011119839 139.74212364637296 40.5 35.667011119839 139.74212364637296 25.5 35.66702572893886 139.74213268730972 25.5 35.667011119839 139.74212364637296 40.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-088bb0c9-e3c3-4b3d-91d2-2cdc992ae394">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-088bb0c9-e3c3-4b3d-91d2-2cdc992ae394">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-088bb0c9-e3c3-4b3d-91d2-2cdc992ae394">
											<gml:posList>35.66706568766378 139.7421575943319 40.796 35.667011119839 139.74212364637296 40.5 35.66702572893886 139.74213268730972 38.7 35.66706568766378 139.7421575943319 40.796</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-746a411e-a322-45a2-b1b8-d4cda5ad33b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-746a411e-a322-45a2-b1b8-d4cda5ad33b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-746a411e-a322-45a2-b1b8-d4cda5ad33b3">
											<gml:posList>35.66706568766378 139.7421575943319 40.796 35.66710910027158 139.7421846513855 41.225 35.667011119839 139.74212364637296 40.5 35.66706568766378 139.7421575943319 40.796</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-78a6ca25-f495-4c8d-b70c-b08e141505cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78a6ca25-f495-4c8d-b70c-b08e141505cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78a6ca25-f495-4c8d-b70c-b08e141505cb">
											<gml:posList>35.66710910027158 139.7421846513855 41.225 35.66706575081006 139.7421576605349 43.008 35.667011119839 139.74212364637296 40.5 35.66710910027158 139.7421846513855 41.225</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-96e4edaa-59a5-4492-b7c5-413fcf607d62">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96e4edaa-59a5-4492-b7c5-413fcf607d62">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96e4edaa-59a5-4492-b7c5-413fcf607d62">
											<gml:posList>35.66712265923187 139.74215197351032 38.979 35.66713386859834 139.74215896380915 38.7 35.66713386859834 139.74215896380915 40.5 35.66712265923187 139.74215197351032 41.225 35.66712265923187 139.74215197351032 38.979</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6ffecca6-ecdf-4fe7-b19e-fb517a943502">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ffecca6-ecdf-4fe7-b19e-fb517a943502">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ffecca6-ecdf-4fe7-b19e-fb517a943502">
											<gml:posList>35.66713386859834 139.74215896380915 38.7 35.66705928072145 139.74233875277173 38.7 35.66705928072145 139.74233875277173 25.5 35.66721030065918 139.74197474303625 25.5 35.66721030065918 139.74197474303625 40.5 35.66713386859834 139.74215896380915 40.5 35.66713386859834 139.74215896380915 38.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1c0a87cf-f76e-48e0-a153-e7f1c3a17425">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c0a87cf-f76e-48e0-a153-e7f1c3a17425">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c0a87cf-f76e-48e0-a153-e7f1c3a17425">
											<gml:posList>35.66712265923187 139.74215197351032 38.979 35.66712265923187 139.74215197351032 41.225 35.66710910027158 139.7421846513855 41.225 35.66710910027158 139.7421846513855 38.979 35.66712265923187 139.74215197351032 38.979</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d50a6f17-5af2-40fc-aa12-5434aae4c8a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d50a6f17-5af2-40fc-aa12-5434aae4c8a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d50a6f17-5af2-40fc-aa12-5434aae4c8a5">
											<gml:posList>35.66706568766378 139.7421575943319 40.796 35.66710910027158 139.7421846513855 38.979 35.66710910027158 139.7421846513855 41.225 35.66706568766378 139.7421575943319 40.796</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-18416b9f-f053-440f-931a-15dbc1177fc0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18416b9f-f053-440f-931a-15dbc1177fc0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18416b9f-f053-440f-931a-15dbc1177fc0">
											<gml:posList>35.66702572893886 139.74213268730972 25.5 35.666964637065725 139.74227988670265 25.5 35.666964637065725 139.74227988670265 38.7 35.66702572893886 139.74213268730972 38.7 35.66702572893886 139.74213268730972 25.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-88aa914d-faf6-45f0-82c5-85365a44ced0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-88aa914d-faf6-45f0-82c5-85365a44ced0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-88aa914d-faf6-45f0-82c5-85365a44ced0">
											<gml:posList>35.66700471295586 139.7423048157379 40.796 35.666964637065725 139.74227988670265 38.7 35.666964637065725 139.74227988670265 25.5 35.66705928072145 139.74233875277173 25.5 35.66705928072145 139.74233875277173 38.7 35.66700471295586 139.7423048157379 40.796</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5765</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">487.18645</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">6</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1123</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>