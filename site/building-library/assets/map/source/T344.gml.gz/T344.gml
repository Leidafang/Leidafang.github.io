<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_639ba85b-2686-4e48-b61a-08812ca5ff50">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門二丁目10地区</gen:value>
			</gen:stringAttribute>
			<bldg:measuredHeight uom="m">3.3</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66718258151914 139.74489402999822 0 35.66713963643191 139.74495044414897 0 35.66715653333192 139.74496975570267 0 35.6671994784281 139.7449133415504 0 35.66718258151914 139.74489402999822 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66718258151914 139.74489402999822 8.96 35.6671994784281 139.7449133415504 8.96 35.66715653333192 139.74496975570267 8.96 35.66713963643191 139.74495044414897 8.96 35.66718258151914 139.74489402999822 8.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66718258151914 139.74489402999822 8.96 35.66713963643191 139.74495044414897 8.96 35.66713963643191 139.74495044414897 12.25 35.66718258151914 139.74489402999822 12.25 35.66718258151914 139.74489402999822 8.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66713963643191 139.74495044414897 8.96 35.66715653333192 139.74496975570267 8.96 35.66715653333192 139.74496975570267 12.25 35.66713963643191 139.74495044414897 12.25 35.66713963643191 139.74495044414897 8.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66715653333192 139.74496975570267 8.96 35.6671994784281 139.7449133415504 8.96 35.6671994784281 139.7449133415504 12.25 35.66715653333192 139.74496975570267 12.25 35.66715653333192 139.74496975570267 8.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6671994784281 139.7449133415504 8.96 35.66718258151914 139.74489402999822 8.96 35.66718258151914 139.74489402999822 12.25 35.6671994784281 139.7449133415504 12.25 35.6671994784281 139.7449133415504 8.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66718258151914 139.74489402999822 12.25 35.66713963643191 139.74495044414897 12.25 35.66715653333192 139.74496975570267 12.25 35.6671994784281 139.7449133415504 12.25 35.66718258151914 139.74489402999822 12.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-d2f48ce8-571e-4c48-a640-f6cf8f35564c"/>
							<gml:surfaceMember xlink:href="#poly-a1404f7a-1144-43e2-9483-2a6c9ad20449"/>
							<gml:surfaceMember xlink:href="#poly-596dfa3c-cde6-4781-bacc-b32de6540d6f"/>
							<gml:surfaceMember xlink:href="#poly-b6c4471b-8cf6-423b-9d15-593aa0b1ff9d"/>
							<gml:surfaceMember xlink:href="#poly-447fb5ff-331c-441d-9b4f-a362d50005df"/>
							<gml:surfaceMember xlink:href="#poly-d54fbfb3-36fa-46a7-b41e-bc76a21c806b"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-d2f48ce8-571e-4c48-a640-f6cf8f35564c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d2f48ce8-571e-4c48-a640-f6cf8f35564c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d2f48ce8-571e-4c48-a640-f6cf8f35564c">
											<gml:posList>35.66718258151915 139.74489402999822 8.96 35.66719947842805 139.7449133415504 8.96 35.66715653333193 139.74496975570267 8.96 35.667139636431926 139.74495044414897 8.96 35.66718258151915 139.74489402999822 8.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a1404f7a-1144-43e2-9483-2a6c9ad20449">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a1404f7a-1144-43e2-9483-2a6c9ad20449">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a1404f7a-1144-43e2-9483-2a6c9ad20449">
											<gml:posList>35.66715653333193 139.74496975570267 12.332 35.66719947842805 139.7449133415504 12.332 35.66718258151915 139.74489402999822 12.332 35.667139636431926 139.74495044414897 12.332 35.66715653333193 139.74496975570267 12.332</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-596dfa3c-cde6-4781-bacc-b32de6540d6f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-596dfa3c-cde6-4781-bacc-b32de6540d6f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-596dfa3c-cde6-4781-bacc-b32de6540d6f">
											<gml:posList>35.66715653333193 139.74496975570267 12.332 35.667139636431926 139.74495044414897 12.332 35.667139636431926 139.74495044414897 8.96 35.66715653333193 139.74496975570267 8.96 35.66715653333193 139.74496975570267 12.332</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b6c4471b-8cf6-423b-9d15-593aa0b1ff9d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6c4471b-8cf6-423b-9d15-593aa0b1ff9d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6c4471b-8cf6-423b-9d15-593aa0b1ff9d">
											<gml:posList>35.66718258151915 139.74489402999822 8.96 35.667139636431926 139.74495044414897 8.96 35.667139636431926 139.74495044414897 12.332 35.66718258151915 139.74489402999822 12.332 35.66718258151915 139.74489402999822 8.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-447fb5ff-331c-441d-9b4f-a362d50005df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-447fb5ff-331c-441d-9b4f-a362d50005df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-447fb5ff-331c-441d-9b4f-a362d50005df">
											<gml:posList>35.66715653333193 139.74496975570267 8.96 35.66719947842805 139.7449133415504 8.96 35.66719947842805 139.7449133415504 12.332 35.66715653333193 139.74496975570267 12.332 35.66715653333193 139.74496975570267 8.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d54fbfb3-36fa-46a7-b41e-bc76a21c806b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d54fbfb3-36fa-46a7-b41e-bc76a21c806b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d54fbfb3-36fa-46a7-b41e-bc76a21c806b">
											<gml:posList>35.66719947842805 139.7449133415504 8.96 35.66718258151915 139.74489402999822 8.96 35.66718258151915 139.74489402999822 12.332 35.66719947842805 139.7449133415504 12.332 35.66719947842805 139.7449133415504 8.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-11637</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.12</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>