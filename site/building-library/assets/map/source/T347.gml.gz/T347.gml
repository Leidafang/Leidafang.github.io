<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_6508df8e-9cb0-43aa-afb4-6334bfac7097">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">40.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>10</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67299896590598 139.7394693462064 0 35.67281269763779 139.7392850309302 0 35.672758769368855 139.73936694940377 0 35.67283950453886 139.73944683214617 0 35.6727523547691 139.73957916184278 0 35.67285789654973 139.73968347298162 0 35.67299896590598 139.7394693462064 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67299896590598 139.7394693462064 7.38 35.67285789654973 139.73968347298162 7.38 35.6727523547691 139.73957916184278 7.38 35.67283950453886 139.73944683214617 7.38 35.672758769368855 139.73936694940377 7.38 35.67281269763779 139.7392850309302 7.38 35.67299896590598 139.7394693462064 7.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67299896590598 139.7394693462064 7.38 35.67281269763779 139.7392850309302 7.38 35.67281269763779 139.7392850309302 47.03 35.67299896590598 139.7394693462064 47.03 35.67299896590598 139.7394693462064 7.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67281269763779 139.7392850309302 7.38 35.672758769368855 139.73936694940377 7.38 35.672758769368855 139.73936694940377 47.03 35.67281269763779 139.7392850309302 47.03 35.67281269763779 139.7392850309302 7.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672758769368855 139.73936694940377 7.38 35.67283950453886 139.73944683214617 7.38 35.67283950453886 139.73944683214617 47.03 35.672758769368855 139.73936694940377 47.03 35.672758769368855 139.73936694940377 7.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67283950453886 139.73944683214617 7.38 35.6727523547691 139.73957916184278 7.38 35.6727523547691 139.73957916184278 47.03 35.67283950453886 139.73944683214617 47.03 35.67283950453886 139.73944683214617 7.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6727523547691 139.73957916184278 7.38 35.67285789654973 139.73968347298162 7.38 35.67285789654973 139.73968347298162 47.03 35.6727523547691 139.73957916184278 47.03 35.6727523547691 139.73957916184278 7.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67285789654973 139.73968347298162 7.38 35.67299896590598 139.7394693462064 7.38 35.67299896590598 139.7394693462064 47.03 35.67285789654973 139.73968347298162 47.03 35.67285789654973 139.73968347298162 7.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67299896590598 139.7394693462064 47.03 35.67281269763779 139.7392850309302 47.03 35.672758769368855 139.73936694940377 47.03 35.67283950453886 139.73944683214617 47.03 35.6727523547691 139.73957916184278 47.03 35.67285789654973 139.73968347298162 47.03 35.67299896590598 139.7394693462064 47.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-76d97709-b248-455a-9c70-a475e5a1587b"/>
							<gml:surfaceMember xlink:href="#poly-72a0a91e-97a8-41dd-af67-41bd7395a7ac"/>
							<gml:surfaceMember xlink:href="#poly-c9ff0833-1cc2-4296-b100-1b73563dfbf3"/>
							<gml:surfaceMember xlink:href="#poly-8e8804ca-c914-4f55-9413-cffa51ecff9a"/>
							<gml:surfaceMember xlink:href="#poly-d1364cc7-b22d-4f5a-8fbe-9c272867cc5f"/>
							<gml:surfaceMember xlink:href="#poly-fd1d375e-7405-4ad5-96b2-e03b0ced3c3e"/>
							<gml:surfaceMember xlink:href="#poly-ed065d18-875c-4414-8418-a89edbcfda4e"/>
							<gml:surfaceMember xlink:href="#poly-177b5c2e-e5f5-418a-a37d-b375d87ab3f1"/>
							<gml:surfaceMember xlink:href="#poly-ec43549e-8d55-48b1-8c87-995ff3cfe9b3"/>
							<gml:surfaceMember xlink:href="#poly-94b55600-ca04-4e5b-b1d6-18079b101783"/>
							<gml:surfaceMember xlink:href="#poly-2538c637-1dbd-4103-8cee-4c109f868605"/>
							<gml:surfaceMember xlink:href="#poly-b9154582-4bfe-4288-b4f9-36741033d479"/>
							<gml:surfaceMember xlink:href="#poly-fe8a0d21-c05a-41f8-a395-ca2cbe14e995"/>
							<gml:surfaceMember xlink:href="#poly-69709e2d-8668-49e3-bb86-0ab2bef1d8d7"/>
							<gml:surfaceMember xlink:href="#poly-a92df7f5-e468-4c40-b2d2-385cff995ba0"/>
							<gml:surfaceMember xlink:href="#poly-f7de7072-3065-4eb4-92bf-01386883f86f"/>
							<gml:surfaceMember xlink:href="#poly-f63a006d-3a02-4af9-a99a-c162b15bc5ae"/>
							<gml:surfaceMember xlink:href="#poly-fc0f24ed-bdc1-4721-a2e9-d1ac5b5d3ec8"/>
							<gml:surfaceMember xlink:href="#poly-5a333492-b355-4497-86e8-ff4b3730849d"/>
							<gml:surfaceMember xlink:href="#poly-29ecf696-96c8-4849-8ba6-a5ffcf0b6256"/>
							<gml:surfaceMember xlink:href="#poly-36883e63-3dbd-497c-8ef5-478742da243a"/>
							<gml:surfaceMember xlink:href="#poly-a955e3d8-44fc-4f42-b05c-f886d5ea7eb0"/>
							<gml:surfaceMember xlink:href="#poly-62753c22-fe7b-4726-bcbe-89faae88acc9"/>
							<gml:surfaceMember xlink:href="#poly-52b860db-1c9f-4cab-b20a-8a1f5e72b4d0"/>
							<gml:surfaceMember xlink:href="#poly-6facb3c9-ebc8-48c4-952f-a6b8559e7324"/>
							<gml:surfaceMember xlink:href="#poly-5b7ff7a3-28d2-4a5c-b9b9-c601e4d48dfc"/>
							<gml:surfaceMember xlink:href="#poly-444a0816-ee73-4484-af72-ff0827250f13"/>
							<gml:surfaceMember xlink:href="#poly-6356b888-4ab5-45e1-89e6-56bb95f5a38c"/>
							<gml:surfaceMember xlink:href="#poly-e7e24a49-7123-4f70-b446-a8b0d37c11f1"/>
							<gml:surfaceMember xlink:href="#poly-d9370f89-a0c0-4c48-991e-58a09db0605e"/>
							<gml:surfaceMember xlink:href="#poly-113b0d02-f74c-43d4-90f5-9d49890d71d8"/>
							<gml:surfaceMember xlink:href="#poly-fc1b7a30-7bee-44c3-bf27-e1aef50d7016"/>
							<gml:surfaceMember xlink:href="#poly-bc7863af-5244-4cf1-8532-0e613ff2de3a"/>
							<gml:surfaceMember xlink:href="#poly-460eec02-afc1-4c00-b280-9d5c4ad8a0b6"/>
							<gml:surfaceMember xlink:href="#poly-35ffbf8c-f0da-46f6-bc50-78887ba55253"/>
							<gml:surfaceMember xlink:href="#poly-414e107f-e36a-4b9c-8501-cf8c1c59b17b"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_6508df8e-9cb0-43aa-afb4-6334bfac7097_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11dac2bf-ed3c-4717-885e-965cfe3964d3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67279468506119 139.73938491325256 52.783 35.67280797491501 139.739366449867 52.783 35.672825458267695 139.7393853521943 52.783 35.67281217742474 139.7394038155702 52.783 35.67279468506119 139.73938491325256 52.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1328d5b8-2971-444b-bac6-2bcb48ccaadd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67280704820034 139.739576767051 48.083 35.67282330267879 139.7395918487386 48.083 35.672817721207586 139.73960089137978 48.083 35.67280146673025 139.7395858096914 48.083 35.67280704820034 139.739576767051 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25eb8674-e2cb-4369-bb7c-b6b79f7285e9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67281807009473 139.7395743349569 48.083 35.67283387356931 139.73958900844934 48.083 35.67283035364286 139.73959471260926 48.083 35.672814541163845 139.73958005017346 48.083 35.67281807009473 139.7395743349569 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8dfa788-5abb-4493-88eb-4e3339a16119">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6728500347629 139.73957689352517 48.083 35.67284584865612 139.73958366998593 48.083 35.67282656338222 139.739565786005 48.083 35.67283074948801 139.73955900954493 48.083 35.6728500347629 139.73957689352517 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f07a15b0-7323-4262-88ef-36d475bee3f9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6728500347629 139.73957689352517 48.787 35.6728500347629 139.73957689352517 48.083 35.67283074948801 139.73955900954493 48.083 35.67283074948801 139.73955900954493 48.787 35.6728500347629 139.73957689352517 48.787</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-431cb8c4-3da7-4d31-acba-4243c658b254">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672859568463686 139.739631165373 48.083 35.67285497725226 139.73963860510116 48.083 35.67283309415266 139.7396183049368 48.083 35.67283769437656 139.73961086519896 48.083 35.672859568463686 139.739631165373 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-288bddd7-40d6-42f0-9d15-60504ce18c28">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67283319482719 139.7395507990628 48.083 35.672837786033206 139.73954335933163 48.083 35.67285983150416 139.73956380289263 48.083 35.672855231283194 139.73957124263524 48.083 35.67283319482719 139.7395507990628 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe379131-1b6e-434e-b4f2-0f24aecdfdef">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67285983150416 139.73956380289263 48.083 35.672837786033206 139.73954335933163 48.083 35.672837786033206 139.73954335933163 48.787 35.67285983150416 139.73956380289263 48.787 35.67285983150416 139.73956380289263 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c65dd52-3066-4008-a8a0-ee6f57a9e4e3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67286351078146 139.73962384791503 48.687 35.67284199751704 139.73960390081132 48.687 35.67284199751704 139.73960390081132 48.083 35.67286351078146 139.73962384791503 48.083 35.67286351078146 139.73962384791503 48.687</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-192e872e-fac5-4470-88fe-dde19bb7287b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67286351078146 139.73962384791503 48.083 35.67284199751704 139.73960390081132 48.083 35.67284648970442 139.7395966268971 48.083 35.672868002978625 139.73961658504658 48.083 35.67286351078146 139.73962384791503 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb0c540d-3bf7-4c70-b4e5-334eb579b5b4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672868356741795 139.7395499846685 48.083 35.67286404461655 139.73955698221167 48.083 35.67284199914445 139.7395365386515 48.083 35.67284631126852 139.73952954110916 48.083 35.672868356741795 139.7395499846685 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff32b07b-a6aa-4974-898a-06b07c973b4b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672868002978625 139.73961658504658 48.083 35.67284648970442 139.7395966268971 48.083 35.67284648970442 139.7395966268971 48.687 35.672868002978625 139.73961658504658 48.687 35.672868002978625 139.73961658504658 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9fbfb7e-2a59-45ae-8cb5-5f3386b8f3df">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67285057840105 139.73952264303816 48.787 35.67285057840105 139.73952264303816 48.083 35.67287262387547 139.73954308659668 48.083 35.67287262387547 139.73954308659668 48.787 35.67285057840105 139.73952264303816 48.787</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ee0d1716-102d-4f2f-9276-87c392fe5615">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67285470148581 139.73951596606696 48.083 35.67287674696134 139.73953640962472 48.083 35.67287262387547 139.73954308659668 48.083 35.67285057840105 139.73952264303816 48.083 35.67285470148581 139.73951596606696 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4dd557b2-ae97-4d55-bec3-ef294e6ed54c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67285128916621 139.7395903910032 48.083 35.67285565532412 139.73958332712016 48.083 35.67287748429562 139.7396035610643 48.083 35.67287311814514 139.73961063599478 48.083 35.67285128916621 139.7395903910032 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b155acd-f0d4-479d-9e1f-214efa3bbfbc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67286641788278 139.7395141075736 48.083 35.67286044648008 139.73950856916792 48.083 35.672864416520206 139.73950213539953 48.083 35.672870396936936 139.7395076737945 48.083 35.67286641788278 139.7395141075736 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9404cd47-6d57-4f70-9bab-bddb41a7622f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67287748429562 139.7396035610643 48.083 35.67285565532412 139.73958332712016 48.083 35.67285565532412 139.73958332712016 48.687 35.67287748429562 139.7396035610643 48.687 35.67287748429562 139.7396035610643 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db08de40-85c8-406b-9f7d-7f9fa02be81e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67286802348667 139.73951559698594 48.668 35.67286802348667 139.73951559698594 48.083 35.67287413019811 139.7395212677936 48.083 35.67287413019811 139.7395212677936 48.668 35.67286802348667 139.73951559698594 48.668</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c384f19-aa5a-4933-96d9-61ee8fa095f8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67286019251862 139.73957597582472 48.687 35.67286019251862 139.73957597582472 48.083 35.67288228308697 139.73959646353404 48.083 35.67288228308697 139.73959646353404 48.687 35.67286019251862 139.73957597582472 48.687</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab0de288-4639-42e8-a958-fa76e489a006">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67286802348667 139.73951559698594 48.083 35.67287221858609 139.73950879841604 48.083 35.672878334302965 139.73951445816633 48.083 35.67287413019811 139.7395212677936 48.083 35.67286802348667 139.73951559698594 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b47e8c2-4d6e-4c6a-a484-fd6735e6ac9c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67288651420283 139.73958960969205 48.083 35.67288228308697 139.73959646353404 48.083 35.67286019251862 139.73957597582472 48.083 35.67286442363333 139.73956912198352 48.083 35.67288651420283 139.73958960969205 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dbebe734-1960-407b-98ed-7aa1c24d6097">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672868573727406 139.73956240079556 48.083 35.672873137935966 139.73955501632636 48.083 35.672901398346866 139.73958121895996 48.083 35.67289683414533 139.73958861447687 48.083 35.672868573727406 139.73956240079556 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8412dff4-15ec-47ec-851f-aa87e3d9bc4e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67286480184647 139.73934898486297 48.083 35.672882176563 139.73936727976394 48.083 35.67287366806368 139.73937941890657 48.083 35.672983123957735 139.7394862771265 48.083 35.672865772727405 139.73966954506284 48.083 35.67279523206507 139.73960102813925 48.083 35.672797401447546 139.73959726976148 48.083 35.67286533367552 139.7396613269041 48.083 35.6729780754316 139.73948520046784 48.083 35.67287279573266 139.73938198274072 48.083 35.67285675178054 139.7394057075474 48.083 35.67283815841641 139.73938510533296 48.083 35.6728401033197 139.73938246291684 48.083 35.67285654026838 139.73940032810077 48.083 35.67287767938117 139.73936813562347 48.083 35.67286282092355 139.73935167150938 48.083 35.67286480184647 139.73934898486297 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a53a3c1f-0cc2-41d6-8984-30221dc1b580">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672899143393934 139.73956768950404 48.083 35.67287996635128 139.7395498937613 48.083 35.672884089446136 139.7395432278357 48.083 35.67290326648118 139.73956101253114 48.083 35.672899143393934 139.73956768950404 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-082c573e-e633-4148-8592-1fd49afa26f6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672934846248694 139.73949760118404 48.083 35.672885549887035 139.7394509759326 48.083 35.672897991453304 139.7394312210777 48.083 35.67294728782249 139.73947784632418 48.083 35.672934846248694 139.73949760118404 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5bf429bd-42d6-41ff-8572-d55bf36baa39">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67292945991098 139.73953727586718 48.083 35.67289696844139 139.73950643861693 48.083 35.672903522345365 139.7394960581826 48.083 35.67293601382618 139.73952690647775 48.083 35.67292945991098 139.73953727586718 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c5611db-4031-4310-851d-2e43160cdd04">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672882176563 139.73936727976394 48.083 35.67286480184647 139.73934898486297 48.083 35.67286480184647 139.73934898486297 51.167 35.672882176563 139.73936727976394 51.167 35.672882176563 139.73936727976394 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-477307d6-489f-4413-aa2f-3f154cdee6f6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-477307d6-489f-4413-aa2f-3f154cdee6f6_0">
											<gml:posList>35.67283309415266 139.7396183049368 48.083 35.67285497725226 139.73963860510116 48.083 35.67285497725226 139.73963860510116 48.687 35.67283309415266 139.7396183049368 48.687 35.67283309415266 139.7396183049368 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-653044df-3631-4491-bb0e-c2787ae15120">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-653044df-3631-4491-bb0e-c2787ae15120_0">
											<gml:posList>35.67284199914445 139.7395365386515 48.083 35.67286404461655 139.73955698221167 48.083 35.67286404461655 139.73955698221167 48.787 35.67284199914445 139.7395365386515 48.787 35.67284199914445 139.7395365386515 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8cb94d77-f279-4152-ba6b-26a57cffa453">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8cb94d77-f279-4152-ba6b-26a57cffa453_0">
											<gml:posList>35.672868356741795 139.7395499846685 48.083 35.67284631126852 139.73952954110916 48.083 35.67284631126852 139.73952954110916 48.787 35.672868356741795 139.7395499846685 48.787 35.672868356741795 139.7395499846685 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ca0bf70-7666-47ab-b761-515f1008d9b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9ca0bf70-7666-47ab-b761-515f1008d9b4_0">
											<gml:posList>35.67285128916621 139.7395903910032 48.083 35.67287311814514 139.73961063599478 48.083 35.67287311814514 139.73961063599478 48.687 35.67285128916621 139.7395903910032 48.687 35.67285128916621 139.7395903910032 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d2409bd-07ec-4e1f-8e5e-6415dd2ebccf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d2409bd-07ec-4e1f-8e5e-6415dd2ebccf_0">
											<gml:posList>35.67286351078146 139.73962384791503 48.083 35.672868002978625 139.73961658504658 48.083 35.672868002978625 139.73961658504658 48.687 35.67286351078146 139.73962384791503 48.687 35.67286351078146 139.73962384791503 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-434d6bc6-edcd-4566-ac05-04de61330a10">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-434d6bc6-edcd-4566-ac05-04de61330a10_0">
											<gml:posList>35.67286404461655 139.73955698221167 48.083 35.672868356741795 139.7395499846685 48.083 35.672868356741795 139.7395499846685 48.787 35.67286404461655 139.73955698221167 48.787 35.67286404461655 139.73955698221167 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4fb388a2-4fb9-4939-a5f0-4e7328409c55">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4fb388a2-4fb9-4939-a5f0-4e7328409c55_0">
											<gml:posList>35.67286641788278 139.7395141075736 48.083 35.672870396936936 139.7395076737945 48.083 35.672870396936936 139.7395076737945 48.668 35.67286641788278 139.7395141075736 48.668 35.67286641788278 139.7395141075736 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0199d95f-a298-4c5d-b201-1d44f178f0b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0199d95f-a298-4c5d-b201-1d44f178f0b3_0">
											<gml:posList>35.67287262387547 139.73954308659668 48.083 35.67287674696134 139.73953640962472 48.083 35.67287674696134 139.73953640962472 48.787 35.67287262387547 139.73954308659668 48.787 35.67287262387547 139.73954308659668 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4651ab21-84b2-4b0f-96ec-372577b9ce14">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4651ab21-84b2-4b0f-96ec-372577b9ce14_0">
											<gml:posList>35.67287311814514 139.73961063599478 48.083 35.67287748429562 139.7396035610643 48.083 35.67287748429562 139.7396035610643 48.687 35.67287311814514 139.73961063599478 48.687 35.67287311814514 139.73961063599478 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-601118d4-7e74-445a-964e-342da1f37c5b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-601118d4-7e74-445a-964e-342da1f37c5b_0">
											<gml:posList>35.67288651420283 139.73958960969205 48.083 35.67286442363333 139.73956912198352 48.083 35.67286442363333 139.73956912198352 48.687 35.67288651420283 139.73958960969205 48.687 35.67288651420283 139.73958960969205 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74b71a99-ae5b-43da-8193-5e2b7b08f45a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-74b71a99-ae5b-43da-8193-5e2b7b08f45a_0">
											<gml:posList>35.672878334302965 139.73951445816633 48.668 35.67287413019811 139.7395212677936 48.668 35.67287413019811 139.7395212677936 48.083 35.672878334302965 139.73951445816633 48.083 35.672878334302965 139.73951445816633 48.668</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-204ebe44-2b91-41fc-8eaf-8a664e7f141c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-204ebe44-2b91-41fc-8eaf-8a664e7f141c_0">
											<gml:posList>35.67288228308697 139.73959646353404 48.083 35.67288651420283 139.73958960969205 48.083 35.67288651420283 139.73958960969205 48.687 35.67288228308697 139.73959646353404 48.687 35.67288228308697 139.73959646353404 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d290535-0cfc-43f4-b2b3-2b4a33029b5f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4d290535-0cfc-43f4-b2b3-2b4a33029b5f_0">
											<gml:posList>35.672901398346866 139.73958121895996 48.687 35.67289683414533 139.73958861447687 48.687 35.67289683414533 139.73958861447687 48.083 35.672901398346866 139.73958121895996 48.083 35.672901398346866 139.73958121895996 48.687</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f72d519-8220-4c2e-9821-a0d3cc9c1559">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f72d519-8220-4c2e-9821-a0d3cc9c1559_0">
											<gml:posList>35.672899143393934 139.73956768950404 48.083 35.67290326648118 139.73956101253114 48.083 35.67290326648118 139.73956101253114 48.787 35.672899143393934 139.73956768950404 48.787 35.672899143393934 139.73956768950404 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-389e9c0e-4f7d-44ee-b6f4-14f3c260c7ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-389e9c0e-4f7d-44ee-b6f4-14f3c260c7ce_0">
											<gml:posList>35.67294728782249 139.73947784632418 48.083 35.672897991453304 139.7394312210777 48.083 35.672897991453304 139.7394312210777 49.445 35.67294728782249 139.73947784632418 49.445 35.67294728782249 139.73947784632418 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f1cda22a-dc1e-417c-9f63-96ebfb9941f5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f1cda22a-dc1e-417c-9f63-96ebfb9941f5_0">
											<gml:posList>35.67292945991098 139.73953727586718 48.083 35.67293601382618 139.73952690647775 48.083 35.67293601382618 139.73952690647775 49.385 35.67292945991098 139.73953727586718 49.385 35.67292945991098 139.73953727586718 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b6d5aaa-b4e1-4f6e-b324-f09eea3e5bd7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b6d5aaa-b4e1-4f6e-b324-f09eea3e5bd7_0">
											<gml:posList>35.672934846248694 139.73949760118404 48.083 35.67294728782249 139.73947784632418 48.083 35.67294728782249 139.73947784632418 49.445 35.672934846248694 139.73949760118404 49.445 35.672934846248694 139.73949760118404 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad04b1d6-8711-4180-a890-e7c077610f57">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ad04b1d6-8711-4180-a890-e7c077610f57_0">
											<gml:posList>35.672797401447546 139.73959726976148 48.083 35.67279523206507 139.73960102813925 48.083 35.67279523206507 139.73960102813925 51.167 35.672797401447546 139.73959726976148 51.167 35.672797401447546 139.73959726976148 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ef909f0-615d-4c7e-8707-3624d713428f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7ef909f0-615d-4c7e-8707-3624d713428f_0">
											<gml:posList>35.67280704820034 139.739576767051 48.083 35.67280146673025 139.7395858096914 48.083 35.67280146673025 139.7395858096914 48.462 35.67280704820034 139.739576767051 48.462 35.67280704820034 139.739576767051 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13dcc785-b67a-4bd9-8c13-916fd23c7db6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-13dcc785-b67a-4bd9-8c13-916fd23c7db6_0">
											<gml:posList>35.67280146673025 139.7395858096914 48.083 35.672817721207586 139.73960089137978 48.083 35.672817721207586 139.73960089137978 48.462 35.67280146673025 139.7395858096914 48.462 35.67280146673025 139.7395858096914 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70a2b258-b9c4-4458-a19c-f92e87d31fe4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-70a2b258-b9c4-4458-a19c-f92e87d31fe4_0">
											<gml:posList>35.67280704820034 139.739576767051 48.462 35.67280146673025 139.7395858096914 48.462 35.672817721207586 139.73960089137978 48.462 35.67282330267879 139.7395918487386 48.462 35.67280704820034 139.739576767051 48.462</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d381b640-006e-4a86-b38a-a5fcef7703fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d381b640-006e-4a86-b38a-a5fcef7703fd_0">
											<gml:posList>35.67280704820034 139.739576767051 48.462 35.67282330267879 139.7395918487386 48.462 35.67282330267879 139.7395918487386 48.083 35.67280704820034 139.739576767051 48.083 35.67280704820034 139.739576767051 48.462</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9957b785-f309-4fef-8364-32bcc0103a0b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9957b785-f309-4fef-8364-32bcc0103a0b_0">
											<gml:posList>35.67281807009473 139.7395743349569 48.083 35.672814541163845 139.73958005017346 48.083 35.672814541163845 139.73958005017346 48.787 35.67281807009473 139.7395743349569 48.787 35.67281807009473 139.7395743349569 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-96e65b0d-e2f0-4dd9-9413-e79d09810b90">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-96e65b0d-e2f0-4dd9-9413-e79d09810b90_0">
											<gml:posList>35.672817721207586 139.73960089137978 48.083 35.67282330267879 139.7395918487386 48.083 35.67282330267879 139.7395918487386 48.462 35.672817721207586 139.73960089137978 48.462 35.672817721207586 139.73960089137978 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a385050f-4c52-440e-aa0d-ef0ff1574339">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a385050f-4c52-440e-aa0d-ef0ff1574339_0">
											<gml:posList>35.672814541163845 139.73958005017346 48.083 35.67283035364286 139.73959471260926 48.083 35.67283035364286 139.73959471260926 48.787 35.672814541163845 139.73958005017346 48.787 35.672814541163845 139.73958005017346 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-66688070-0e17-4d7a-868b-497b612eb12f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-66688070-0e17-4d7a-868b-497b612eb12f_0">
											<gml:posList>35.67281807009473 139.7395743349569 48.787 35.672814541163845 139.73958005017346 48.787 35.67283035364286 139.73959471260926 48.787 35.67283387356931 139.73958900844934 48.787 35.67281807009473 139.7395743349569 48.787</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e1bf4159-3b57-44d6-a740-e525301d0f3b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e1bf4159-3b57-44d6-a740-e525301d0f3b_0">
											<gml:posList>35.67281807009473 139.7395743349569 48.083 35.67281807009473 139.7395743349569 48.787 35.67283387356931 139.73958900844934 48.787 35.67283387356931 139.73958900844934 48.083 35.67281807009473 139.7395743349569 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b575ee42-8009-4d8f-9701-1c5ed8d526fa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b575ee42-8009-4d8f-9701-1c5ed8d526fa_0">
											<gml:posList>35.67282656338222 139.739565786005 48.787 35.67283074948801 139.73955900954493 48.787 35.67283074948801 139.73955900954493 48.083 35.67282656338222 139.739565786005 48.083 35.67282656338222 139.739565786005 48.787</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e0aca7ea-df11-40c1-851c-fdd5f3352275">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e0aca7ea-df11-40c1-851c-fdd5f3352275_0">
											<gml:posList>35.67279523206507 139.73960102813925 48.083 35.672865772727405 139.73966954506284 48.083 35.672865772727405 139.73966954506284 51.167 35.67279523206507 139.73960102813925 51.167 35.67279523206507 139.73960102813925 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bae00126-a2bb-4a55-96b0-284a909f3022">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bae00126-a2bb-4a55-96b0-284a909f3022_0">
											<gml:posList>35.67286533367552 139.7396613269041 48.083 35.672797401447546 139.73959726976148 48.083 35.672797401447546 139.73959726976148 51.167 35.67286533367552 139.7396613269041 51.167 35.67286533367552 139.7396613269041 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7acfba9a-04a9-48b0-b217-a1dca552b5f3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7acfba9a-04a9-48b0-b217-a1dca552b5f3_0">
											<gml:posList>35.67283035364286 139.73959471260926 48.083 35.67283387356931 139.73958900844934 48.083 35.67283387356931 139.73958900844934 48.787 35.67283035364286 139.73959471260926 48.787 35.67283035364286 139.73959471260926 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-64ef1100-5b8c-4014-bed5-75b509cb47e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-64ef1100-5b8c-4014-bed5-75b509cb47e4_0">
											<gml:posList>35.67283769437656 139.73961086519896 48.083 35.67283309415266 139.7396183049368 48.083 35.67283309415266 139.7396183049368 48.687 35.67283769437656 139.73961086519896 48.687 35.67283769437656 139.73961086519896 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ecfc609c-0c38-4358-9369-fe52f0ddf06c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ecfc609c-0c38-4358-9369-fe52f0ddf06c_0">
											<gml:posList>35.67283319482719 139.7395507990628 48.787 35.672837786033206 139.73954335933163 48.787 35.672837786033206 139.73954335933163 48.083 35.67283319482719 139.7395507990628 48.083 35.67283319482719 139.7395507990628 48.787</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6692152-1daa-4cac-aa0c-67ccf417f5de">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d6692152-1daa-4cac-aa0c-67ccf417f5de_0">
											<gml:posList>35.67282656338222 139.739565786005 48.787 35.67282656338222 139.739565786005 48.083 35.67284584865612 139.73958366998593 48.083 35.67284584865612 139.73958366998593 48.787 35.67282656338222 139.739565786005 48.787</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b0ca5fe9-d4fa-4b8b-bf80-c62b6b8157e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b0ca5fe9-d4fa-4b8b-bf80-c62b6b8157e4_0">
											<gml:posList>35.67282656338222 139.739565786005 48.787 35.67284584865612 139.73958366998593 48.787 35.6728500347629 139.73957689352517 48.787 35.67283074948801 139.73955900954493 48.787 35.67282656338222 139.739565786005 48.787</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce6b341c-a1e3-4d6a-ab15-3f2bd235e6cf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce6b341c-a1e3-4d6a-ab15-3f2bd235e6cf_0">
											<gml:posList>35.67284199914445 139.7395365386515 48.787 35.67284631126852 139.73952954110916 48.787 35.67284631126852 139.73952954110916 48.083 35.67284199914445 139.7395365386515 48.083 35.67284199914445 139.7395365386515 48.787</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-616e538a-f2b9-4fc4-8a92-9bbbb1c1282e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-616e538a-f2b9-4fc4-8a92-9bbbb1c1282e_0">
											<gml:posList>35.67284648970442 139.7395966268971 48.083 35.67284199751704 139.73960390081132 48.083 35.67284199751704 139.73960390081132 48.687 35.67284648970442 139.7395966268971 48.687 35.67284648970442 139.7395966268971 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da39a3de-38c7-442d-9bce-f510df8a27be">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da39a3de-38c7-442d-9bce-f510df8a27be_0">
											<gml:posList>35.67283319482719 139.7395507990628 48.083 35.672855231283194 139.73957124263524 48.083 35.672855231283194 139.73957124263524 48.787 35.67283319482719 139.7395507990628 48.787 35.67283319482719 139.7395507990628 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8ee09c7d-c7ac-4c5f-bee2-39dc016a43e9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8ee09c7d-c7ac-4c5f-bee2-39dc016a43e9_0">
											<gml:posList>35.67283309415266 139.7396183049368 48.687 35.67285497725226 139.73963860510116 48.687 35.672859568463686 139.739631165373 48.687 35.67283769437656 139.73961086519896 48.687 35.67283309415266 139.7396183049368 48.687</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e27ef22-f37f-47b1-9fc5-14d658b1c3b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1e27ef22-f37f-47b1-9fc5-14d658b1c3b8_0">
											<gml:posList>35.67283319482719 139.7395507990628 48.787 35.672855231283194 139.73957124263524 48.787 35.67285983150416 139.73956380289263 48.787 35.672837786033206 139.73954335933163 48.787 35.67283319482719 139.7395507990628 48.787</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e6bf25a0-b39e-423d-8dfa-d1870ab85d0d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e6bf25a0-b39e-423d-8dfa-d1870ab85d0d_0">
											<gml:posList>35.67284584865612 139.73958366998593 48.083 35.6728500347629 139.73957689352517 48.083 35.6728500347629 139.73957689352517 48.787 35.67284584865612 139.73958366998593 48.787 35.67284584865612 139.73958366998593 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25aed583-a3ba-4731-8cbc-b18e85f467e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-25aed583-a3ba-4731-8cbc-b18e85f467e4_0">
											<gml:posList>35.672859568463686 139.739631165373 48.083 35.67283769437656 139.73961086519896 48.083 35.67283769437656 139.73961086519896 48.687 35.672859568463686 139.739631165373 48.687 35.672859568463686 139.739631165373 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27f5def6-8aae-4a80-9a95-b39280ad1c1d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-27f5def6-8aae-4a80-9a95-b39280ad1c1d_0">
											<gml:posList>35.67285470148581 139.73951596606696 48.083 35.67285057840105 139.73952264303816 48.083 35.67285057840105 139.73952264303816 48.787 35.67285470148581 139.73951596606696 48.787 35.67285470148581 139.73951596606696 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b6b9f86-3c67-4f83-b121-7e8991e704b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b6b9f86-3c67-4f83-b121-7e8991e704b0_0">
											<gml:posList>35.67285128916621 139.7395903910032 48.083 35.67285128916621 139.7395903910032 48.687 35.67285565532412 139.73958332712016 48.687 35.67285565532412 139.73958332712016 48.083 35.67285128916621 139.7395903910032 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43d436bc-1399-4f3f-8173-63833be6a1f7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-43d436bc-1399-4f3f-8173-63833be6a1f7_0">
											<gml:posList>35.67286351078146 139.73962384791503 48.687 35.672868002978625 139.73961658504658 48.687 35.67284648970442 139.7395966268971 48.687 35.67284199751704 139.73960390081132 48.687 35.67286351078146 139.73962384791503 48.687</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf348d2d-fcb1-4b27-b70b-e4c4b97ef1e8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cf348d2d-fcb1-4b27-b70b-e4c4b97ef1e8_0">
											<gml:posList>35.67284199914445 139.7395365386515 48.787 35.67286404461655 139.73955698221167 48.787 35.672868356741795 139.7395499846685 48.787 35.67284631126852 139.73952954110916 48.787 35.67284199914445 139.7395365386515 48.787</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27fdbe76-4eca-4ba1-85f3-b64c2ac8c853">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-27fdbe76-4eca-4ba1-85f3-b64c2ac8c853_0">
											<gml:posList>35.67285497725226 139.73963860510116 48.083 35.672859568463686 139.739631165373 48.083 35.672859568463686 139.739631165373 48.687 35.67285497725226 139.73963860510116 48.687 35.67285497725226 139.73963860510116 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b531bea7-1849-4f55-9e47-038a07b63d5d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b531bea7-1849-4f55-9e47-038a07b63d5d_0">
											<gml:posList>35.672855231283194 139.73957124263524 48.083 35.67285983150416 139.73956380289263 48.083 35.67285983150416 139.73956380289263 48.787 35.672855231283194 139.73957124263524 48.787 35.672855231283194 139.73957124263524 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b63d35b1-883c-4c9a-9d42-2d96844b161c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b63d35b1-883c-4c9a-9d42-2d96844b161c_0">
											<gml:posList>35.67286019251862 139.73957597582472 48.687 35.67286442363333 139.73956912198352 48.687 35.67286442363333 139.73956912198352 48.083 35.67286019251862 139.73957597582472 48.083 35.67286019251862 139.73957597582472 48.687</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7cae5f9d-a877-4c3d-9358-3926e156ca6d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7cae5f9d-a877-4c3d-9358-3926e156ca6d_0">
											<gml:posList>35.672864416520206 139.73950213539953 48.083 35.67286044648008 139.73950856916792 48.083 35.67286044648008 139.73950856916792 48.668 35.672864416520206 139.73950213539953 48.668 35.672864416520206 139.73950213539953 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e0ebda14-1c04-40fb-a002-e2e35bf101c2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e0ebda14-1c04-40fb-a002-e2e35bf101c2_0">
											<gml:posList>35.67286641788278 139.7395141075736 48.668 35.67286044648008 139.73950856916792 48.668 35.67286044648008 139.73950856916792 48.083 35.67286641788278 139.7395141075736 48.083 35.67286641788278 139.7395141075736 48.668</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ed0eabab-73d5-44b0-a5e6-ec086c5e6332">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ed0eabab-73d5-44b0-a5e6-ec086c5e6332_0">
											<gml:posList>35.67285470148581 139.73951596606696 48.787 35.67285057840105 139.73952264303816 48.787 35.67287262387547 139.73954308659668 48.787 35.67287674696134 139.73953640962472 48.787 35.67285470148581 139.73951596606696 48.787</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd1ae5c3-e12c-4f81-a903-0194296ae3b7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dd1ae5c3-e12c-4f81-a903-0194296ae3b7_0">
											<gml:posList>35.67285128916621 139.7395903910032 48.687 35.67287311814514 139.73961063599478 48.687 35.67287748429562 139.7396035610643 48.687 35.67285565532412 139.73958332712016 48.687 35.67285128916621 139.7395903910032 48.687</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-acc5513d-d835-491e-a5c7-835a9e5d4a7a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-acc5513d-d835-491e-a5c7-835a9e5d4a7a_0">
											<gml:posList>35.67286641788278 139.7395141075736 48.668 35.672870396936936 139.7395076737945 48.668 35.672864416520206 139.73950213539953 48.668 35.67286044648008 139.73950856916792 48.668 35.67286641788278 139.7395141075736 48.668</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97ac4f2b-40ca-49b3-861c-4507b068453f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-97ac4f2b-40ca-49b3-861c-4507b068453f_0">
											<gml:posList>35.67285470148581 139.73951596606696 48.083 35.67285470148581 139.73951596606696 48.787 35.67287674696134 139.73953640962472 48.787 35.67287674696134 139.73953640962472 48.083 35.67285470148581 139.73951596606696 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2af409f5-a523-4be5-b4e4-7e2f2dc9cf14">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2af409f5-a523-4be5-b4e4-7e2f2dc9cf14_0">
											<gml:posList>35.672870396936936 139.7395076737945 48.668 35.672870396936936 139.7395076737945 48.083 35.672864416520206 139.73950213539953 48.083 35.672864416520206 139.73950213539953 48.668 35.672870396936936 139.7395076737945 48.668</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-47bf66a7-197f-4b32-8cf8-c45a992112c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-47bf66a7-197f-4b32-8cf8-c45a992112c3_0">
											<gml:posList>35.67287221858609 139.73950879841604 48.668 35.67287221858609 139.73950879841604 48.083 35.67286802348667 139.73951559698594 48.083 35.67286802348667 139.73951559698594 48.668 35.67287221858609 139.73950879841604 48.668</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-08dd0b16-aa79-42ac-8945-24ea174ba11f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-08dd0b16-aa79-42ac-8945-24ea174ba11f_0">
											<gml:posList>35.672873137935966 139.73955501632636 48.083 35.672868573727406 139.73956240079556 48.083 35.672868573727406 139.73956240079556 48.687 35.672873137935966 139.73955501632636 48.687 35.672873137935966 139.73955501632636 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d17c233-8cae-4675-8228-4573fb6f1365">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4d17c233-8cae-4675-8228-4573fb6f1365_0">
											<gml:posList>35.672878334302965 139.73951445816633 48.668 35.67287221858609 139.73950879841604 48.668 35.67286802348667 139.73951559698594 48.668 35.67287413019811 139.7395212677936 48.668 35.672878334302965 139.73951445816633 48.668</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce9212a4-4405-417d-9442-2264c34b84b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce9212a4-4405-417d-9442-2264c34b84b3_0">
											<gml:posList>35.67286019251862 139.73957597582472 48.687 35.67288228308697 139.73959646353404 48.687 35.67288651420283 139.73958960969205 48.687 35.67286442363333 139.73956912198352 48.687 35.67286019251862 139.73957597582472 48.687</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7794e7eb-f610-4b78-a1fe-4024833b4ef6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7794e7eb-f610-4b78-a1fe-4024833b4ef6_0">
											<gml:posList>35.672878334302965 139.73951445816633 48.668 35.672878334302965 139.73951445816633 48.083 35.67287221858609 139.73950879841604 48.083 35.67287221858609 139.73950879841604 48.668 35.672878334302965 139.73951445816633 48.668</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2eba5ca0-4fc6-47dd-aaf6-a1b8e7e453ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2eba5ca0-4fc6-47dd-aaf6-a1b8e7e453ca_0">
											<gml:posList>35.672884089446136 139.7395432278357 48.083 35.67287996635128 139.7395498937613 48.083 35.67287996635128 139.7395498937613 48.787 35.672884089446136 139.7395432278357 48.787 35.672884089446136 139.7395432278357 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f74efca5-71a1-4d07-8c49-5935e72ae62e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f74efca5-71a1-4d07-8c49-5935e72ae62e_0">
											<gml:posList>35.672868573727406 139.73956240079556 48.083 35.67289683414533 139.73958861447687 48.083 35.67289683414533 139.73958861447687 48.687 35.672868573727406 139.73956240079556 48.687 35.672868573727406 139.73956240079556 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8ad33b0b-f87e-48f8-b106-aeefbea9dc7c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8ad33b0b-f87e-48f8-b106-aeefbea9dc7c_0">
											<gml:posList>35.672901398346866 139.73958121895996 48.687 35.672873137935966 139.73955501632636 48.687 35.672868573727406 139.73956240079556 48.687 35.67289683414533 139.73958861447687 48.687 35.672901398346866 139.73958121895996 48.687</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-643ea805-94d6-483d-a0b6-4dd5c0d0f732">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-643ea805-94d6-483d-a0b6-4dd5c0d0f732_0">
											<gml:posList>35.672901398346866 139.73958121895996 48.687 35.672901398346866 139.73958121895996 48.083 35.672873137935966 139.73955501632636 48.083 35.672873137935966 139.73955501632636 48.687 35.672901398346866 139.73958121895996 48.687</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76a1818a-e457-4a8c-9177-0749554e805f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-76a1818a-e457-4a8c-9177-0749554e805f_0">
											<gml:posList>35.67287767938117 139.73936813562347 51.167 35.67285654026838 139.73940032810077 51.167 35.6728401033197 139.73938246291684 51.167 35.67283815841641 139.73938510533296 51.167 35.67285675178054 139.7394057075474 51.167 35.67287279573266 139.73938198274072 51.167 35.6729780754316 139.73948520046784 51.167 35.67286533367552 139.7396613269041 51.167 35.672797401447546 139.73959726976148 51.167 35.67279523206507 139.73960102813925 51.167 35.672865772727405 139.73966954506284 51.167 35.672983123957735 139.7394862771265 51.167 35.67287366806368 139.73937941890657 51.167 35.672882176563 139.73936727976394 51.167 35.67286480184647 139.73934898486297 51.167 35.67286282092355 139.73935167150938 51.167 35.67287767938117 139.73936813562347 51.167</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-056a7913-c9bb-4bef-b2a6-3bbb51b5db7e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-056a7913-c9bb-4bef-b2a6-3bbb51b5db7e_0">
											<gml:posList>35.672899143393934 139.73956768950404 48.787 35.67287996635128 139.7395498937613 48.787 35.67287996635128 139.7395498937613 48.083 35.672899143393934 139.73956768950404 48.083 35.672899143393934 139.73956768950404 48.787</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac48b617-45f6-4df3-8d7d-3604d5bc2bed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ac48b617-45f6-4df3-8d7d-3604d5bc2bed_0">
											<gml:posList>35.672899143393934 139.73956768950404 48.787 35.67290326648118 139.73956101253114 48.787 35.672884089446136 139.7395432278357 48.787 35.67287996635128 139.7395498937613 48.787 35.672899143393934 139.73956768950404 48.787</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e680d806-6e17-4b26-b764-deea516f5f22">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e680d806-6e17-4b26-b764-deea516f5f22_0">
											<gml:posList>35.67290326648118 139.73956101253114 48.083 35.672884089446136 139.7395432278357 48.083 35.672884089446136 139.7395432278357 48.787 35.67290326648118 139.73956101253114 48.787 35.67290326648118 139.73956101253114 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2405997e-5dbe-4169-8ee0-f93eb79e127f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2405997e-5dbe-4169-8ee0-f93eb79e127f_0">
											<gml:posList>35.672903522345365 139.7394960581826 48.083 35.67289696844139 139.73950643861693 48.083 35.67289696844139 139.73950643861693 49.385 35.672903522345365 139.7394960581826 49.385 35.672903522345365 139.7394960581826 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14b0d850-4779-4c2b-90e3-f7de037c8e60">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-14b0d850-4779-4c2b-90e3-f7de037c8e60_0">
											<gml:posList>35.67292945991098 139.73953727586718 48.083 35.67292945991098 139.73953727586718 49.385 35.67289696844139 139.73950643861693 49.385 35.67289696844139 139.73950643861693 48.083 35.67292945991098 139.73953727586718 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-121c84e4-7f9f-46eb-9a43-78d9c43e4158">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-121c84e4-7f9f-46eb-9a43-78d9c43e4158_0">
											<gml:posList>35.67292945991098 139.73953727586718 49.385 35.67293601382618 139.73952690647775 49.385 35.672903522345365 139.7394960581826 49.385 35.67289696844139 139.73950643861693 49.385 35.67292945991098 139.73953727586718 49.385</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-42f790eb-0601-419c-a97d-910a46095fd7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-42f790eb-0601-419c-a97d-910a46095fd7_0">
											<gml:posList>35.67293601382618 139.73952690647775 48.083 35.672903522345365 139.7394960581826 48.083 35.672903522345365 139.7394960581826 49.385 35.67293601382618 139.73952690647775 49.385 35.67293601382618 139.73952690647775 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca7f4555-feb2-4025-9e16-21d6559d7e3b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ca7f4555-feb2-4025-9e16-21d6559d7e3b_0">
											<gml:posList>35.67286533367552 139.7396613269041 48.083 35.67286533367552 139.7396613269041 51.167 35.6729780754316 139.73948520046784 51.167 35.6729780754316 139.73948520046784 48.083 35.67286533367552 139.7396613269041 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a824620-4bb9-4f5b-bee7-a17404d5d047">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5a824620-4bb9-4f5b-bee7-a17404d5d047_0">
											<gml:posList>35.672865772727405 139.73966954506284 48.083 35.672983123957735 139.7394862771265 48.083 35.672983123957735 139.7394862771265 51.167 35.672865772727405 139.73966954506284 51.167 35.672865772727405 139.73966954506284 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9db0958b-0fa9-4a60-b4f1-a4ad1196af5b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9db0958b-0fa9-4a60-b4f1-a4ad1196af5b_0">
											<gml:posList>35.67279468506119 139.73938491325256 54.212 35.67280797491501 139.739366449867 54.212 35.67280797491501 139.739366449867 52.783 35.67279468506119 139.73938491325256 52.783 35.67279468506119 139.73938491325256 54.212</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e7ca4f1-80e8-4c57-a8c2-cbd83546d03e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3e7ca4f1-80e8-4c57-a8c2-cbd83546d03e_0">
											<gml:posList>35.67281217742474 139.7394038155702 54.212 35.67279468506119 139.73938491325256 54.212 35.67279468506119 139.73938491325256 52.783 35.67281217742474 139.7394038155702 52.783 35.67281217742474 139.7394038155702 54.212</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-289e5ca0-02e0-488d-ba28-ccee9b6da242">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-289e5ca0-02e0-488d-ba28-ccee9b6da242_0">
											<gml:posList>35.672825458267695 139.7393853521943 54.212 35.67280797491501 139.739366449867 54.212 35.67279468506119 139.73938491325256 54.212 35.67281217742474 139.7394038155702 54.212 35.672825458267695 139.7393853521943 54.212</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f6f58aa2-6f7b-452f-9adf-60aa4c3bf57e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f6f58aa2-6f7b-452f-9adf-60aa4c3bf57e_0">
											<gml:posList>35.67280797491501 139.739366449867 54.212 35.672825458267695 139.7393853521943 54.212 35.672825458267695 139.7393853521943 52.783 35.67280797491501 139.739366449867 52.783 35.67280797491501 139.739366449867 54.212</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3243452-baab-459d-bf08-542d31ec2d42">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3243452-baab-459d-bf08-542d31ec2d42_0">
											<gml:posList>35.672825458267695 139.7393853521943 54.212 35.67281217742474 139.7394038155702 54.212 35.67281217742474 139.7394038155702 52.783 35.672825458267695 139.7393853521943 52.783 35.672825458267695 139.7393853521943 54.212</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-08a874f2-74e2-4d9d-86b2-06062f8844ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-08a874f2-74e2-4d9d-86b2-06062f8844ca_0">
											<gml:posList>35.67283815841641 139.73938510533296 51.167 35.6728401033197 139.73938246291684 51.167 35.6728401033197 139.73938246291684 48.083 35.67283815841641 139.73938510533296 48.083 35.67283815841641 139.73938510533296 51.167</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dfdb9bfe-1e18-4af1-80e9-7dd1de74a90f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dfdb9bfe-1e18-4af1-80e9-7dd1de74a90f_0">
											<gml:posList>35.67285675178054 139.7394057075474 48.083 35.67285675178054 139.7394057075474 51.167 35.67283815841641 139.73938510533296 51.167 35.67283815841641 139.73938510533296 48.083 35.67285675178054 139.7394057075474 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f0e40ac8-ece7-4de4-9bde-978f03a15d8b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f0e40ac8-ece7-4de4-9bde-978f03a15d8b_0">
											<gml:posList>35.67285654026838 139.73940032810077 48.083 35.6728401033197 139.73938246291684 48.083 35.6728401033197 139.73938246291684 51.167 35.67285654026838 139.73940032810077 51.167 35.67285654026838 139.73940032810077 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16a61ee8-04a8-4ba8-aa69-9edbfdcb87f4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16a61ee8-04a8-4ba8-aa69-9edbfdcb87f4_0">
											<gml:posList>35.67286480184647 139.73934898486297 48.083 35.67286282092355 139.73935167150938 48.083 35.67286282092355 139.73935167150938 51.167 35.67286480184647 139.73934898486297 51.167 35.67286480184647 139.73934898486297 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-406e63f8-141b-479d-ba52-9e900883cf9d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-406e63f8-141b-479d-ba52-9e900883cf9d_0">
											<gml:posList>35.67285675178054 139.7394057075474 48.083 35.67287279573266 139.73938198274072 48.083 35.67287279573266 139.73938198274072 51.167 35.67285675178054 139.7394057075474 51.167 35.67285675178054 139.7394057075474 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef40ae01-46f2-46c7-82bc-2ae5ad2690b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef40ae01-46f2-46c7-82bc-2ae5ad2690b8_0">
											<gml:posList>35.67285654026838 139.73940032810077 48.083 35.67285654026838 139.73940032810077 51.167 35.67287767938117 139.73936813562347 51.167 35.67287767938117 139.73936813562347 48.083 35.67285654026838 139.73940032810077 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b5f988d-9d69-4829-ac03-23a3e3ffe63a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b5f988d-9d69-4829-ac03-23a3e3ffe63a_0">
											<gml:posList>35.67287767938117 139.73936813562347 48.083 35.67287767938117 139.73936813562347 51.167 35.67286282092355 139.73935167150938 51.167 35.67286282092355 139.73935167150938 48.083 35.67287767938117 139.73936813562347 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-42eec3d7-b0c1-4941-a4da-ada21732cceb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-42eec3d7-b0c1-4941-a4da-ada21732cceb_0">
											<gml:posList>35.67287366806368 139.73937941890657 48.083 35.672882176563 139.73936727976394 48.083 35.672882176563 139.73936727976394 51.167 35.67287366806368 139.73937941890657 51.167 35.67287366806368 139.73937941890657 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d93aca6-9436-4058-a905-9d10ff8cfcf6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4d93aca6-9436-4058-a905-9d10ff8cfcf6_0">
											<gml:posList>35.672897991453304 139.7394312210777 48.083 35.672885549887035 139.7394509759326 48.083 35.672885549887035 139.7394509759326 49.445 35.672897991453304 139.7394312210777 49.445 35.672897991453304 139.7394312210777 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bbcb41b3-d9fa-4587-a8d9-df489968b071">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bbcb41b3-d9fa-4587-a8d9-df489968b071_0">
											<gml:posList>35.672934846248694 139.73949760118404 48.083 35.672934846248694 139.73949760118404 49.445 35.672885549887035 139.7394509759326 49.445 35.672885549887035 139.7394509759326 48.083 35.672934846248694 139.73949760118404 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5381d796-cfbc-4d2c-819e-f80e3500d113">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5381d796-cfbc-4d2c-819e-f80e3500d113_0">
											<gml:posList>35.672934846248694 139.73949760118404 49.445 35.67294728782249 139.73947784632418 49.445 35.672897991453304 139.7394312210777 49.445 35.672885549887035 139.7394509759326 49.445 35.672934846248694 139.73949760118404 49.445</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-86442aa1-b147-46f3-9aff-6b0322bee45e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-86442aa1-b147-46f3-9aff-6b0322bee45e_0">
											<gml:posList>35.67287279573266 139.73938198274072 48.083 35.6729780754316 139.73948520046784 48.083 35.6729780754316 139.73948520046784 51.167 35.67287279573266 139.73938198274072 51.167 35.67287279573266 139.73938198274072 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e75c8298-9055-49cf-b003-615e7079955f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e75c8298-9055-49cf-b003-615e7079955f_0">
											<gml:posList>35.672983123957735 139.7394862771265 48.083 35.67287366806368 139.73937941890657 48.083 35.67287366806368 139.73937941890657 51.167 35.672983123957735 139.7394862771265 51.167 35.672983123957735 139.7394862771265 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_6508df8e-9cb0-43aa-afb4-6334bfac7097_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-91dd1ddd-fcd1-466c-bd3a-a3cb072e4198">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67278644777608 139.7395831318857 48.083 35.67276550215391 139.73956290798338 48.083 35.6728405247859 139.73944900713124 48.083 35.67286146140459 139.73946921998657 48.083 35.67278644777608 139.7395831318857 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a54cdd4-8c73-47bc-b520-7d9201f88fdf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2a54cdd4-8c73-47bc-b520-7d9201f88fdf_0">
											<gml:posList>35.6728405247859 139.73944900713124 48.083 35.6728405247859 139.73944900713124 48.44 35.67286146140459 139.73946921998657 48.44 35.67286146140459 139.73946921998657 48.083 35.6728405247859 139.73944900713124 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ada7a9f0-4714-4b7c-bf31-a6d2dfaaf08a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ada7a9f0-4714-4b7c-bf31-a6d2dfaaf08a_0">
											<gml:posList>35.67276550215391 139.73956290798338 48.083 35.67276550215391 139.73956290798338 48.44 35.6728405247859 139.73944900713124 48.44 35.6728405247859 139.73944900713124 48.083 35.67276550215391 139.73956290798338 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35682530-a7ae-4cd3-8bbe-e17b46bc3b3a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-35682530-a7ae-4cd3-8bbe-e17b46bc3b3a_0">
											<gml:posList>35.6728405247859 139.73944900713124 48.44 35.67276550215391 139.73956290798338 48.44 35.67278644777608 139.7395831318857 48.44 35.67286146140459 139.73946921998657 48.44 35.6728405247859 139.73944900713124 48.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74e36509-a30f-46b3-9f51-908f9709913e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-74e36509-a30f-46b3-9f51-908f9709913e_0">
											<gml:posList>35.67278644777608 139.7395831318857 48.44 35.67278644777608 139.7395831318857 48.083 35.67286146140459 139.73946921998657 48.083 35.67286146140459 139.73946921998657 48.44 35.67278644777608 139.7395831318857 48.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2825f08e-ea51-475e-b582-f0bc18195835">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2825f08e-ea51-475e-b582-f0bc18195835_0">
											<gml:posList>35.67278644777608 139.7395831318857 48.083 35.67278644777608 139.7395831318857 48.44 35.67276550215391 139.73956290798338 48.44 35.67276550215391 139.73956290798338 48.083 35.67278644777608 139.7395831318857 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_6508df8e-9cb0-43aa-afb4-6334bfac7097_BuildingInstallation_1031">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33b80ccd-6fed-4a18-bb5c-a6d643f11ca9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67285572603012 139.73948895592997 48.083 35.67285619700775 139.7394918606346 48.083 35.672855506498294 139.7394964126422 48.083 35.67279908663544 139.73958520491198 48.083 35.67279060719437 139.7395768083714 48.083 35.67279455054114 139.73957081650693 48.083 35.672796805708415 139.73957304528105 48.083 35.67285417331147 139.73948593097907 48.083 35.67285572603012 139.73948895592997 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c6fc240e-1e91-498a-b6ce-d81995198ea8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c6fc240e-1e91-498a-b6ce-d81995198ea8_0">
											<gml:posList>35.67285417331147 139.73948593097907 48.083 35.67285417331147 139.73948593097907 48.251 35.67285572603012 139.73948895592997 48.251 35.67285572603012 139.73948895592997 48.083 35.67285417331147 139.73948593097907 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-90b04d91-e091-47b6-8c71-54ec0bd4d76e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-90b04d91-e091-47b6-8c71-54ec0bd4d76e_0">
											<gml:posList>35.67285572603012 139.73948895592997 48.251 35.67285619700775 139.7394918606346 48.251 35.67285619700775 139.7394918606346 48.083 35.67285572603012 139.73948895592997 48.083 35.67285572603012 139.73948895592997 48.251</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e5400454-6434-494d-a1ea-ab9dfb6c5699">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e5400454-6434-494d-a1ea-ab9dfb6c5699_0">
											<gml:posList>35.67285619700775 139.7394918606346 48.083 35.67285619700775 139.7394918606346 48.251 35.672855506498294 139.7394964126422 48.251 35.672855506498294 139.7394964126422 48.083 35.67285619700775 139.7394918606346 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f4e9440a-59b7-4788-8bed-1d20e3b50e0b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f4e9440a-59b7-4788-8bed-1d20e3b50e0b_0">
											<gml:posList>35.672796805708415 139.73957304528105 48.083 35.672796805708415 139.73957304528105 48.251 35.67285417331147 139.73948593097907 48.251 35.67285417331147 139.73948593097907 48.083 35.672796805708415 139.73957304528105 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-17970425-6fff-4efd-a56a-7fb0d33d60b7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-17970425-6fff-4efd-a56a-7fb0d33d60b7_0">
											<gml:posList>35.672796805708415 139.73957304528105 48.251 35.67279455054114 139.73957081650693 48.251 35.67279060719437 139.7395768083714 48.251 35.67279908663544 139.73958520491198 48.251 35.672855506498294 139.7394964126422 48.251 35.67285619700775 139.7394918606346 48.251 35.67285572603012 139.73948895592997 48.251 35.67285417331147 139.73948593097907 48.251 35.672796805708415 139.73957304528105 48.251</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b1d5de4d-18cc-44fd-b23b-aad76f28d107">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b1d5de4d-18cc-44fd-b23b-aad76f28d107_0">
											<gml:posList>35.672855506498294 139.7394964126422 48.083 35.672855506498294 139.7394964126422 48.251 35.67279908663544 139.73958520491198 48.251 35.67279908663544 139.73958520491198 48.083 35.672855506498294 139.7394964126422 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-547db537-7500-4ca2-8638-92a52c4a89dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-547db537-7500-4ca2-8638-92a52c4a89dc_0">
											<gml:posList>35.67279455054114 139.73957081650693 48.083 35.67279455054114 139.73957081650693 48.251 35.672796805708415 139.73957304528105 48.251 35.672796805708415 139.73957304528105 48.083 35.67279455054114 139.73957081650693 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7bd360ac-780d-4b0a-be4c-e3ff12f996ab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7bd360ac-780d-4b0a-be4c-e3ff12f996ab_0">
											<gml:posList>35.67279060719437 139.7395768083714 48.083 35.67279060719437 139.7395768083714 48.251 35.67279455054114 139.73957081650693 48.251 35.67279455054114 139.73957081650693 48.083 35.67279060719437 139.7395768083714 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-65d40e3a-5c87-417c-8a22-2fdb7308ee79">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-65d40e3a-5c87-417c-8a22-2fdb7308ee79_0">
											<gml:posList>35.67279908663544 139.73958520491198 48.083 35.67279908663544 139.73958520491198 48.251 35.67279060719437 139.7395768083714 48.251 35.67279060719437 139.7395768083714 48.083 35.67279908663544 139.73958520491198 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-76d97709-b248-455a-9c70-a475e5a1587b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-76d97709-b248-455a-9c70-a475e5a1587b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-76d97709-b248-455a-9c70-a475e5a1587b">
											<gml:posList>35.67283950453888 139.7394468321462 7.38 35.672758769368855 139.73936694940377 7.38 35.67281269763779 139.73928503093018 7.38 35.67299896590596 139.7394693462064 7.38 35.6728578965497 139.73968347298162 7.38 35.6727523547691 139.73957916184276 7.38 35.67283950453888 139.7394468321462 7.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-72a0a91e-97a8-41dd-af67-41bd7395a7ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-72a0a91e-97a8-41dd-af67-41bd7395a7ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-72a0a91e-97a8-41dd-af67-41bd7395a7ac">
											<gml:posList>35.67276202847294 139.7393619967126 54.525 35.67278575287956 139.73938545395617 54.525 35.672788462802615 139.73938134144862 54.525 35.672766632733165 139.73935974885836 54.525 35.67279465023527 139.73931719768441 54.525 35.672792755888025 139.73931532198534 54.525 35.67276202847294 139.7393619967126 54.525</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c9ff0833-1cc2-4296-b100-1b73563dfbf3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c9ff0833-1cc2-4296-b100-1b73563dfbf3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c9ff0833-1cc2-4296-b100-1b73563dfbf3">
											<gml:posList>35.67281648030362 139.739338779224 48.083 35.67279465023527 139.73931719768441 48.083 35.672766632733165 139.73935974885836 48.083 35.672788462802615 139.73938134144862 48.083 35.67281648030362 139.739338779224 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8e8804ca-c914-4f55-9413-cffa51ecff9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8e8804ca-c914-4f55-9413-cffa51ecff9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8e8804ca-c914-4f55-9413-cffa51ecff9a">
											<gml:posList>35.67281576495311 139.739415454478 55.258 35.67281545452312 139.739410373408 55.258 35.6727899889137 139.73938491875577 55.258 35.67278575287956 139.73938545395617 55.258 35.67281576495311 139.739415454478 55.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d1364cc7-b22d-4f5a-8fbe-9c272867cc5f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1364cc7-b22d-4f5a-8fbe-9c272867cc5f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1364cc7-b22d-4f5a-8fbe-9c272867cc5f">
											<gml:posList>35.672792755888025 139.73931532198534 55.258 35.67279700092693 139.739314775724 55.258 35.67280864186333 139.73929708752203 55.258 35.672808205115494 139.7392918519488 55.258 35.672792755888025 139.73931532198534 55.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fd1d375e-7405-4ad5-96b2-e03b0ced3c3e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fd1d375e-7405-4ad5-96b2-e03b0ced3c3e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fd1d375e-7405-4ad5-96b2-e03b0ced3c3e">
											<gml:posList>35.67281648030362 139.739338779224 55.258 35.67278575287956 139.73938545395617 55.258 35.6727899889137 139.73938491875577 55.258 35.672820716328886 139.73933823297435 55.258 35.67281648030362 139.739338779224 55.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ed065d18-875c-4414-8418-a89edbcfda4e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed065d18-875c-4414-8418-a89edbcfda4e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed065d18-875c-4414-8418-a89edbcfda4e">
											<gml:posList>35.67281648030362 139.739338779224 55.258 35.672820716328886 139.73933823297435 55.258 35.67279700092693 139.739314775724 55.258 35.672792755888025 139.73931532198534 55.258 35.67281648030362 139.739338779224 55.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-177b5c2e-e5f5-418a-a37d-b375d87ab3f1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-177b5c2e-e5f5-418a-a37d-b375d87ab3f1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-177b5c2e-e5f5-418a-a37d-b375d87ab3f1">
											<gml:posList>35.67276012442192 139.73956735500147 43.419 35.6727523547691 139.73957916184276 43.419 35.6728578965497 139.73968347298162 43.419 35.672865621204146 139.73967174351364 43.419 35.67276012442192 139.73956735500147 43.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ec43549e-8d55-48b1-8c87-995ff3cfe9b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec43549e-8d55-48b1-8c87-995ff3cfe9b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec43549e-8d55-48b1-8c87-995ff3cfe9b3">
											<gml:posList>35.67286044853075 139.73934938764404 52.783 35.67280864186333 139.73929708752203 52.783 35.67279700092693 139.739314775724 52.783 35.672820716328886 139.73933823297435 52.783 35.6727899889137 139.73938491875577 52.783 35.67281545452312 139.739410373408 52.783 35.67286044853075 139.73934938764404 52.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-94b55600-ca04-4e5b-b1d6-18079b101783">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-94b55600-ca04-4e5b-b1d6-18079b101783">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-94b55600-ca04-4e5b-b1d6-18079b101783">
											<gml:posList>35.672808205115494 139.7392918519488 55.258 35.67280864186333 139.73929708752203 55.258 35.67286044853075 139.73934938764404 55.258 35.67286480184647 139.73934898486297 55.258 35.672808205115494 139.7392918519488 55.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2538c637-1dbd-4103-8cee-4c109f868605">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2538c637-1dbd-4103-8cee-4c109f868605">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2538c637-1dbd-4103-8cee-4c109f868605">
											<gml:posList>35.67286480184647 139.73934898486297 55.258 35.67286044853075 139.73934938764404 55.258 35.67281545452312 139.739410373408 55.258 35.67281576495311 139.739415454478 55.258 35.67286480184647 139.73934898486297 55.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b9154582-4bfe-4288-b4f9-36741033d479">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b9154582-4bfe-4288-b4f9-36741033d479">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b9154582-4bfe-4288-b4f9-36741033d479">
											<gml:posList>35.67276202847294 139.7393619967126 48.083 35.672758769368855 139.73936694940377 48.083 35.67283950453888 139.7394468321462 48.083 35.67276012442192 139.73956735500147 48.083 35.672865621204146 139.73967174351364 48.083 35.67298761302203 139.73948657013028 48.083 35.67287573286896 139.7393802670752 48.083 35.67288884133535 139.73936037887074 48.083 35.67281269763779 139.73928503093018 48.083 35.672808205115494 139.7392918519488 48.083 35.67286480184647 139.73934898486297 48.083 35.67281576495311 139.739415454478 48.083 35.67278575287956 139.73938545395617 48.083 35.67276202847294 139.7393619967126 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fe8a0d21-c05a-41f8-a395-ca2cbe14e995">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe8a0d21-c05a-41f8-a395-ca2cbe14e995">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe8a0d21-c05a-41f8-a395-ca2cbe14e995">
											<gml:posList>35.67287573286896 139.7393802670752 43.325 35.67298761302203 139.73948657013028 43.325 35.67299896590596 139.7394693462064 43.325 35.67288884133535 139.73936037887074 43.325 35.67287573286896 139.7393802670752 43.325</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-69709e2d-8668-49e3-bb86-0ab2bef1d8d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69709e2d-8668-49e3-bb86-0ab2bef1d8d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69709e2d-8668-49e3-bb86-0ab2bef1d8d7">
											<gml:posList>35.672820716328886 139.73933823297435 55.258 35.672820716328886 139.73933823297435 52.783 35.67279700092693 139.739314775724 52.783 35.67279700092693 139.739314775724 55.258 35.672820716328886 139.73933823297435 55.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a92df7f5-e468-4c40-b2d2-385cff995ba0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a92df7f5-e468-4c40-b2d2-385cff995ba0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a92df7f5-e468-4c40-b2d2-385cff995ba0">
											<gml:posList>35.6727899889137 139.73938491875577 55.258 35.6727899889137 139.73938491875577 52.783 35.672820716328886 139.73933823297435 52.783 35.672820716328886 139.73933823297435 55.258 35.6727899889137 139.73938491875577 55.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f7de7072-3065-4eb4-92bf-01386883f86f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f7de7072-3065-4eb4-92bf-01386883f86f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f7de7072-3065-4eb4-92bf-01386883f86f">
											<gml:posList>35.67286044853075 139.73934938764404 55.258 35.67286044853075 139.73934938764404 52.783 35.67281545452312 139.739410373408 52.783 35.67281545452312 139.739410373408 55.258 35.67286044853075 139.73934938764404 55.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f63a006d-3a02-4af9-a99a-c162b15bc5ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f63a006d-3a02-4af9-a99a-c162b15bc5ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f63a006d-3a02-4af9-a99a-c162b15bc5ae">
											<gml:posList>35.67279700092693 139.739314775724 55.258 35.67279700092693 139.739314775724 52.783 35.67280864186333 139.73929708752203 52.783 35.67280864186333 139.73929708752203 55.258 35.67279700092693 139.739314775724 55.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fc0f24ed-bdc1-4721-a2e9-d1ac5b5d3ec8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc0f24ed-bdc1-4721-a2e9-d1ac5b5d3ec8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc0f24ed-bdc1-4721-a2e9-d1ac5b5d3ec8">
											<gml:posList>35.672808205115494 139.7392918519488 48.083 35.672808205115494 139.7392918519488 55.258 35.67286480184647 139.73934898486297 55.258 35.67286480184647 139.73934898486297 48.083 35.672808205115494 139.7392918519488 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5a333492-b355-4497-86e8-ff4b3730849d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a333492-b355-4497-86e8-ff4b3730849d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a333492-b355-4497-86e8-ff4b3730849d">
											<gml:posList>35.67280864186333 139.73929708752203 55.258 35.67280864186333 139.73929708752203 52.783 35.67286044853075 139.73934938764404 52.783 35.67286044853075 139.73934938764404 55.258 35.67280864186333 139.73929708752203 55.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-29ecf696-96c8-4849-8ba6-a5ffcf0b6256">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-29ecf696-96c8-4849-8ba6-a5ffcf0b6256">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-29ecf696-96c8-4849-8ba6-a5ffcf0b6256">
											<gml:posList>35.672792755888025 139.73931532198534 54.525 35.672792755888025 139.73931532198534 55.258 35.672808205115494 139.7392918519488 55.258 35.672808205115494 139.7392918519488 48.083 35.67281269763779 139.73928503093018 48.083 35.67281269763779 139.73928503093018 7.38 35.672758769368855 139.73936694940377 7.38 35.672758769368855 139.73936694940377 48.083 35.67276202847294 139.7393619967126 48.083 35.67276202847294 139.7393619967126 54.525 35.672792755888025 139.73931532198534 54.525</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-36883e63-3dbd-497c-8ef5-478742da243a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36883e63-3dbd-497c-8ef5-478742da243a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36883e63-3dbd-497c-8ef5-478742da243a">
											<gml:posList>35.67281648030362 139.739338779224 48.083 35.67281648030362 139.739338779224 55.258 35.672792755888025 139.73931532198534 55.258 35.672792755888025 139.73931532198534 54.525 35.67279465023527 139.73931719768441 54.525 35.67279465023527 139.73931719768441 48.083 35.67281648030362 139.739338779224 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a955e3d8-44fc-4f42-b05c-f886d5ea7eb0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a955e3d8-44fc-4f42-b05c-f886d5ea7eb0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a955e3d8-44fc-4f42-b05c-f886d5ea7eb0">
											<gml:posList>35.672788462802615 139.73938134144862 54.525 35.67278575287956 139.73938545395617 54.525 35.67278575287956 139.73938545395617 55.258 35.67281648030362 139.739338779224 55.258 35.67281648030362 139.739338779224 48.083 35.672788462802615 139.73938134144862 48.083 35.672788462802615 139.73938134144862 54.525</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-62753c22-fe7b-4726-bcbe-89faae88acc9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-62753c22-fe7b-4726-bcbe-89faae88acc9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-62753c22-fe7b-4726-bcbe-89faae88acc9">
											<gml:posList>35.67288884133535 139.73936037887074 43.325 35.67288884133535 139.73936037887074 48.083 35.67287573286896 139.7393802670752 48.083 35.67287573286896 139.7393802670752 43.325 35.67288884133535 139.73936037887074 43.325</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-52b860db-1c9f-4cab-b20a-8a1f5e72b4d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-52b860db-1c9f-4cab-b20a-8a1f5e72b4d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-52b860db-1c9f-4cab-b20a-8a1f5e72b4d0">
											<gml:posList>35.672766632733165 139.73935974885836 48.083 35.672766632733165 139.73935974885836 54.525 35.672788462802615 139.73938134144862 54.525 35.672788462802615 139.73938134144862 48.083 35.672766632733165 139.73935974885836 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6facb3c9-ebc8-48c4-952f-a6b8559e7324">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6facb3c9-ebc8-48c4-952f-a6b8559e7324">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6facb3c9-ebc8-48c4-952f-a6b8559e7324">
											<gml:posList>35.67278575287956 139.73938545395617 48.083 35.67278575287956 139.73938545395617 54.525 35.67276202847294 139.7393619967126 54.525 35.67276202847294 139.7393619967126 48.083 35.67278575287956 139.73938545395617 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5b7ff7a3-28d2-4a5c-b9b9-c601e4d48dfc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b7ff7a3-28d2-4a5c-b9b9-c601e4d48dfc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b7ff7a3-28d2-4a5c-b9b9-c601e4d48dfc">
											<gml:posList>35.67281269763779 139.73928503093018 7.38 35.67281269763779 139.73928503093018 48.083 35.67288884133535 139.73936037887074 48.083 35.67288884133535 139.73936037887074 43.325 35.67299896590596 139.7394693462064 43.325 35.67299896590596 139.7394693462064 7.38 35.67281269763779 139.73928503093018 7.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-444a0816-ee73-4484-af72-ff0827250f13">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-444a0816-ee73-4484-af72-ff0827250f13">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-444a0816-ee73-4484-af72-ff0827250f13">
											<gml:posList>35.67286480184647 139.73934898486297 55.258 35.67281576495311 139.739415454478 55.258 35.67281576495311 139.739415454478 48.083 35.67286480184647 139.73934898486297 48.083 35.67286480184647 139.73934898486297 55.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6356b888-4ab5-45e1-89e6-56bb95f5a38c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6356b888-4ab5-45e1-89e6-56bb95f5a38c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6356b888-4ab5-45e1-89e6-56bb95f5a38c">
											<gml:posList>35.67281545452312 139.739410373408 55.258 35.67281545452312 139.739410373408 52.783 35.6727899889137 139.73938491875577 52.783 35.6727899889137 139.73938491875577 55.258 35.67281545452312 139.739410373408 55.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e7e24a49-7123-4f70-b446-a8b0d37c11f1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e7e24a49-7123-4f70-b446-a8b0d37c11f1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e7e24a49-7123-4f70-b446-a8b0d37c11f1">
											<gml:posList>35.67281576495311 139.739415454478 48.083 35.67281576495311 139.739415454478 55.258 35.67278575287956 139.73938545395617 55.258 35.67278575287956 139.73938545395617 54.525 35.67278575287956 139.73938545395617 48.083 35.67281576495311 139.739415454478 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d9370f89-a0c0-4c48-991e-58a09db0605e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d9370f89-a0c0-4c48-991e-58a09db0605e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d9370f89-a0c0-4c48-991e-58a09db0605e">
											<gml:posList>35.672758769368855 139.73936694940377 7.38 35.67283950453888 139.7394468321462 7.38 35.67283950453888 139.7394468321462 48.083 35.672758769368855 139.73936694940377 48.083 35.672758769368855 139.73936694940377 7.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-113b0d02-f74c-43d4-90f5-9d49890d71d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-113b0d02-f74c-43d4-90f5-9d49890d71d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-113b0d02-f74c-43d4-90f5-9d49890d71d8">
											<gml:posList>35.67287573286896 139.7393802670752 43.325 35.67287573286896 139.7393802670752 48.083 35.67298761302203 139.73948657013028 48.083 35.67298761302203 139.73948657013028 43.325 35.67287573286896 139.7393802670752 43.325</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fc1b7a30-7bee-44c3-bf27-e1aef50d7016">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc1b7a30-7bee-44c3-bf27-e1aef50d7016">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc1b7a30-7bee-44c3-bf27-e1aef50d7016">
											<gml:posList>35.67283950453888 139.7394468321462 48.083 35.67283950453888 139.7394468321462 7.38 35.6727523547691 139.73957916184276 7.38 35.6727523547691 139.73957916184276 43.419 35.67276012442192 139.73956735500147 43.419 35.67276012442192 139.73956735500147 48.083 35.67283950453888 139.7394468321462 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bc7863af-5244-4cf1-8532-0e613ff2de3a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc7863af-5244-4cf1-8532-0e613ff2de3a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc7863af-5244-4cf1-8532-0e613ff2de3a">
											<gml:posList>35.67298761302203 139.73948657013028 43.325 35.67298761302203 139.73948657013028 48.083 35.672865621204146 139.73967174351364 48.083 35.672865621204146 139.73967174351364 43.419 35.6728578965497 139.73968347298162 43.419 35.6728578965497 139.73968347298162 7.38 35.67299896590596 139.7394693462064 7.38 35.67299896590596 139.7394693462064 43.325 35.67298761302203 139.73948657013028 43.325</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-460eec02-afc1-4c00-b280-9d5c4ad8a0b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-460eec02-afc1-4c00-b280-9d5c4ad8a0b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-460eec02-afc1-4c00-b280-9d5c4ad8a0b6">
											<gml:posList>35.672865621204146 139.73967174351364 43.419 35.672865621204146 139.73967174351364 48.083 35.67276012442192 139.73956735500147 48.083 35.67276012442192 139.73956735500147 43.419 35.672865621204146 139.73967174351364 43.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-35ffbf8c-f0da-46f6-bc50-78887ba55253">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-35ffbf8c-f0da-46f6-bc50-78887ba55253">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-35ffbf8c-f0da-46f6-bc50-78887ba55253">
											<gml:posList>35.6727523547691 139.73957916184276 7.38 35.6728578965497 139.73968347298162 7.38 35.6728578965497 139.73968347298162 43.419 35.6727523547691 139.73957916184276 43.419 35.6727523547691 139.73957916184276 7.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-414e107f-e36a-4b9c-8501-cf8c1c59b17b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-414e107f-e36a-4b9c-8501-cf8c1c59b17b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-414e107f-e36a-4b9c-8501-cf8c1c59b17b">
											<gml:posList>35.67279465023527 139.73931719768441 48.083 35.67279465023527 139.73931719768441 54.525 35.672766632733165 139.73935974885836 54.525 35.672766632733165 139.73935974885836 48.083 35.67279465023527 139.73931719768441 48.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5801</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">430.11205</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.32</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>