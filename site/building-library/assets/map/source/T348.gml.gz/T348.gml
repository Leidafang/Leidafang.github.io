<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_65611cd7-eea4-4715-a338-878c9a97a705">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">39.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>12</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67145139752371 139.73876479556483 0 35.67141688208717 139.73877389432673 0 35.671437253121304 139.73888875291183 0 35.6715617968295 139.73885557739823 0 35.67153943363309 139.73872912225372 0 35.67150645027196 139.73873788784095 0 35.67150138019564 139.73870939407556 0 35.67146055654791 139.7387202677367 0 35.67146518330937 139.73874667424005 0 35.67144896197891 139.7387509793831 0 35.67145139752371 139.73876479556483 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67145139752371 139.73876479556483 15.03 35.67144896197891 139.7387509793831 15.03 35.67146518330937 139.73874667424005 15.03 35.67146055654791 139.7387202677367 15.03 35.67150138019564 139.73870939407556 15.03 35.67150645027196 139.73873788784095 15.03 35.67153943363309 139.73872912225372 15.03 35.6715617968295 139.73885557739823 15.03 35.671437253121304 139.73888875291183 15.03 35.67141688208717 139.73877389432673 15.03 35.67145139752371 139.73876479556483 15.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67145139752371 139.73876479556483 15.03 35.67141688208717 139.73877389432673 15.03 35.67141688208717 139.73877389432673 54.45 35.67145139752371 139.73876479556483 54.45 35.67145139752371 139.73876479556483 15.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67141688208717 139.73877389432673 15.03 35.671437253121304 139.73888875291183 15.03 35.671437253121304 139.73888875291183 54.45 35.67141688208717 139.73877389432673 54.45 35.67141688208717 139.73877389432673 15.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671437253121304 139.73888875291183 15.03 35.6715617968295 139.73885557739823 15.03 35.6715617968295 139.73885557739823 54.45 35.671437253121304 139.73888875291183 54.45 35.671437253121304 139.73888875291183 15.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6715617968295 139.73885557739823 15.03 35.67153943363309 139.73872912225372 15.03 35.67153943363309 139.73872912225372 54.45 35.6715617968295 139.73885557739823 54.45 35.6715617968295 139.73885557739823 15.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67153943363309 139.73872912225372 15.03 35.67150645027196 139.73873788784095 15.03 35.67150645027196 139.73873788784095 54.45 35.67153943363309 139.73872912225372 54.45 35.67153943363309 139.73872912225372 15.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67150645027196 139.73873788784095 15.03 35.67150138019564 139.73870939407556 15.03 35.67150138019564 139.73870939407556 54.45 35.67150645027196 139.73873788784095 54.45 35.67150645027196 139.73873788784095 15.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67150138019564 139.73870939407556 15.03 35.67146055654791 139.7387202677367 15.03 35.67146055654791 139.7387202677367 54.45 35.67150138019564 139.73870939407556 54.45 35.67150138019564 139.73870939407556 15.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67146055654791 139.7387202677367 15.03 35.67146518330937 139.73874667424005 15.03 35.67146518330937 139.73874667424005 54.45 35.67146055654791 139.7387202677367 54.45 35.67146055654791 139.7387202677367 15.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67146518330937 139.73874667424005 15.03 35.67144896197891 139.7387509793831 15.03 35.67144896197891 139.7387509793831 54.45 35.67146518330937 139.73874667424005 54.45 35.67146518330937 139.73874667424005 15.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67144896197891 139.7387509793831 15.03 35.67145139752371 139.73876479556483 15.03 35.67145139752371 139.73876479556483 54.45 35.67144896197891 139.7387509793831 54.45 35.67144896197891 139.7387509793831 15.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67145139752371 139.73876479556483 54.45 35.67141688208717 139.73877389432673 54.45 35.671437253121304 139.73888875291183 54.45 35.6715617968295 139.73885557739823 54.45 35.67153943363309 139.73872912225372 54.45 35.67150645027196 139.73873788784095 54.45 35.67150138019564 139.73870939407556 54.45 35.67146055654791 139.7387202677367 54.45 35.67146518330937 139.73874667424005 54.45 35.67144896197891 139.7387509793831 54.45 35.67145139752371 139.73876479556483 54.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-92c1ebf2-f809-4bfb-8e98-1e2e8684229b"/>
							<gml:surfaceMember xlink:href="#poly-5b890616-0dfe-4f28-89b8-9b3cbc94ddbf"/>
							<gml:surfaceMember xlink:href="#poly-d19d8c13-3d2e-4337-a5df-3d8fa5174f0e"/>
							<gml:surfaceMember xlink:href="#poly-887203a7-0b40-4883-a2c4-1881e07046be"/>
							<gml:surfaceMember xlink:href="#poly-4b43d405-a799-4c56-adf2-315f9a9f6b6d"/>
							<gml:surfaceMember xlink:href="#poly-1c2428ce-e15a-4828-8cfa-fa0d3fb64361"/>
							<gml:surfaceMember xlink:href="#poly-83371db6-e0a9-40d6-8621-ce0abe6d4c3f"/>
							<gml:surfaceMember xlink:href="#poly-af5f97aa-3eb8-4dfd-806c-beb1aca1d24d"/>
							<gml:surfaceMember xlink:href="#poly-247c8bce-1d1c-4cd2-9196-383ae49874c4"/>
							<gml:surfaceMember xlink:href="#poly-4d1a207b-166e-46f7-b9af-aa38a38fe2f8"/>
							<gml:surfaceMember xlink:href="#poly-4b0bf06b-14d8-4f7c-9aac-059fc955c915"/>
							<gml:surfaceMember xlink:href="#poly-8933b8b0-0ddc-433b-bb56-442f470b7e5c"/>
							<gml:surfaceMember xlink:href="#poly-ac82291a-83a6-4a04-bfcd-fa96b9bf34fd"/>
							<gml:surfaceMember xlink:href="#poly-4d3417db-d57d-45e2-a465-4993c493d59d"/>
							<gml:surfaceMember xlink:href="#poly-b5dc1cbb-8c78-4127-8b80-d4786db98309"/>
							<gml:surfaceMember xlink:href="#poly-50d0f6b6-ed7b-4808-8932-4a9cbf42993d"/>
							<gml:surfaceMember xlink:href="#poly-da4fa4a9-8b38-4968-b324-6f88c6b390eb"/>
							<gml:surfaceMember xlink:href="#poly-c7204564-9839-4873-a1f5-250aae7f2008"/>
							<gml:surfaceMember xlink:href="#poly-5ddda0c5-e382-4e5a-bd7d-40c7f36b8d72"/>
							<gml:surfaceMember xlink:href="#poly-84570358-2e87-4ea1-9360-b1a600a85140"/>
							<gml:surfaceMember xlink:href="#poly-e0264616-fdd7-41ab-bbbd-36f978a7993b"/>
							<gml:surfaceMember xlink:href="#poly-6cd3a3c3-527d-49fb-8aa5-ab6f47053d63"/>
							<gml:surfaceMember xlink:href="#poly-594f848c-bbf1-40ac-b22d-5cc885ff3aa1"/>
							<gml:surfaceMember xlink:href="#poly-bdc0b3cc-31ce-466e-856b-7e4bf706aec1"/>
							<gml:surfaceMember xlink:href="#poly-fb5802ff-b637-43ff-a4b7-eb17b89302a1"/>
							<gml:surfaceMember xlink:href="#poly-6f10757f-7746-4b32-b881-ecd54282093f"/>
							<gml:surfaceMember xlink:href="#poly-845b40cd-81df-4b48-a1ac-2e0938b26d76"/>
							<gml:surfaceMember xlink:href="#poly-1c58229d-3d73-4906-a489-d8ba41f6cca9"/>
							<gml:surfaceMember xlink:href="#poly-7a470298-5b76-4c3f-9878-b4c06779764e"/>
							<gml:surfaceMember xlink:href="#poly-70f93d52-2984-4b12-9fa8-0b6b8bb9e983"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_65611cd7-eea4-4715-a338-878c9a97a705_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18c54494-28e5-42fb-8f75-a9f111e4e97f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-18c54494-28e5-42fb-8f75-a9f111e4e97f_0">
											<gml:posList>35.67148903213026 139.73874475716764 54.824 35.671499071748904 139.73874262441163 54.392 35.67148903213026 139.73874475716764 54.392 35.67148903213026 139.73874475716764 54.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b69f036-6c02-4e1e-8a8c-ca7c08b80acd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b69f036-6c02-4e1e-8a8c-ca7c08b80acd_0">
											<gml:posList>35.67148903213026 139.73874475716764 54.824 35.671499071748904 139.73874262441163 54.824 35.671499071748904 139.73874262441163 54.392 35.67148903213026 139.73874475716764 54.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7eb47995-0df5-4fdb-82c1-b9f07a1d63ba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7eb47995-0df5-4fdb-82c1-b9f07a1d63ba_0">
											<gml:posList>35.671477347001684 139.73876346148003 54.392 35.67146869565176 139.73876579143072 55.13 35.671477347001684 139.73876346148003 55.13 35.671477347001684 139.73876346148003 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e23a98b-e4ff-4d8e-b50d-083622888cf6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1e23a98b-e4ff-4d8e-b50d-083622888cf6_0">
											<gml:posList>35.671477347001684 139.73876346148003 54.392 35.67146869565176 139.73876579143072 54.392 35.67146869565176 139.73876579143072 55.13 35.671477347001684 139.73876346148003 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3f92aaa-dc27-447e-aac1-3e0281649458">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3f92aaa-dc27-447e-aac1-3e0281649458_0">
											<gml:posList>35.671477347001684 139.73876346148003 55.13 35.67146869565176 139.73876579143072 55.13 35.6714705606414 139.73877618390225 55.13 35.671477347001684 139.73876346148003 55.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd38ca78-13e6-4a1d-98e4-eccd72d28772">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bd38ca78-13e6-4a1d-98e4-eccd72d28772_0">
											<gml:posList>35.671479211991524 139.73877385395264 55.13 35.671477347001684 139.73876346148003 55.13 35.6714705606414 139.73877618390225 55.13 35.671479211991524 139.73877385395264 55.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-423d744f-0cf8-4333-8c6e-4293ec230630">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-423d744f-0cf8-4333-8c6e-4293ec230630_0">
											<gml:posList>35.6714705606414 139.73877618390225 54.392 35.671479211991524 139.73877385395264 55.13 35.6714705606414 139.73877618390225 55.13 35.6714705606414 139.73877618390225 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-92dcdb32-4439-4231-92f7-ec97b8878b78">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-92dcdb32-4439-4231-92f7-ec97b8878b78_0">
											<gml:posList>35.6714705606414 139.73877618390225 54.392 35.671479211991524 139.73877385395264 54.392 35.671479211991524 139.73877385395264 55.13 35.6714705606414 139.73877618390225 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73754ba4-3c8e-4038-81f7-b1dd460626e6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73754ba4-3c8e-4038-81f7-b1dd460626e6_0">
											<gml:posList>35.671479211991524 139.73877385395264 54.392 35.671477347001684 139.73876346148003 55.13 35.671479211991524 139.73877385395264 55.13 35.671479211991524 139.73877385395264 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-825d1214-1001-4bbe-86c8-c9f3bb3f1287">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-825d1214-1001-4bbe-86c8-c9f3bb3f1287_0">
											<gml:posList>35.671479211991524 139.73877385395264 54.392 35.671477347001684 139.73876346148003 54.392 35.671477347001684 139.73876346148003 55.13 35.671479211991524 139.73877385395264 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-05d293bb-17f5-4403-8fa0-26aa77726c12">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-05d293bb-17f5-4403-8fa0-26aa77726c12_0">
											<gml:posList>35.671479131745684 139.73880941244326 54.392 35.67148024529787 139.7388156081669 56.982 35.671479131745684 139.73880941244326 56.982 35.671479131745684 139.73880941244326 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19735f64-b56e-4dc5-b24d-f0b024fbc2fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19735f64-b56e-4dc5-b24d-f0b024fbc2fd_0">
											<gml:posList>35.671479131745684 139.73880941244326 54.392 35.67148024529787 139.7388156081669 54.392 35.67148024529787 139.7388156081669 56.982 35.671479131745684 139.73880941244326 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4ebda02a-c3d5-4efe-8739-7c3c117f3724">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4ebda02a-c3d5-4efe-8739-7c3c117f3724_0">
											<gml:posList>35.671485021694664 139.73876856691587 54.392 35.671489629836984 139.7387942333424 55.536 35.671485021694664 139.73876856691587 55.536 35.671485021694664 139.73876856691587 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-71106a7f-e801-4e3b-89cc-2e69a9a712fb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-71106a7f-e801-4e3b-89cc-2e69a9a712fb_0">
											<gml:posList>35.671485021694664 139.73876856691587 54.392 35.671489629836984 139.7387942333424 54.392 35.671489629836984 139.7387942333424 55.536 35.671485021694664 139.73876856691587 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e6eea037-57de-442f-977f-aaab7e168789">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e6eea037-57de-442f-977f-aaab7e168789_0">
											<gml:posList>35.67148964510598 139.73883665154696 54.392 35.67149174546907 139.73884834722216 56.392 35.67148964510598 139.73883665154696 56.392 35.67148964510598 139.73883665154696 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6aa1ea21-004f-4f93-b8d8-6078f3ffa734">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6aa1ea21-004f-4f93-b8d8-6078f3ffa734_0">
											<gml:posList>35.67148964510598 139.73883665154696 54.392 35.67149174546907 139.73884834722216 54.392 35.67149174546907 139.73884834722216 56.392 35.67148964510598 139.73883665154696 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe851339-7222-4bac-8012-dcc0cb462628">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe851339-7222-4bac-8012-dcc0cb462628_0">
											<gml:posList>35.67149843795083 139.73873901298222 53.679 35.67148847983755 139.7387416316846 54.976 35.67149843795083 139.73873901298222 54.976 35.67149843795083 139.73873901298222 53.679</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4f39b923-5b06-402b-a987-9b17ac748bdf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4f39b923-5b06-402b-a987-9b17ac748bdf_0">
											<gml:posList>35.67149843795083 139.73873901298222 53.679 35.67148847983755 139.7387416316846 53.679 35.67148847983755 139.7387416316846 54.976 35.67149843795083 139.73873901298222 53.679</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb7ecd9d-01aa-4e9a-8c3d-cda8d4cda087">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fb7ecd9d-01aa-4e9a-8c3d-cda8d4cda087_0">
											<gml:posList>35.67148849792574 139.7387417089882 54.824 35.67149853754433 139.7387395762318 53.679 35.67149853754433 139.7387395762318 54.824 35.67148849792574 139.7387417089882 54.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13cfbf23-7651-47cb-93a4-30bcb7b4d1e3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-13cfbf23-7651-47cb-93a4-30bcb7b4d1e3_0">
											<gml:posList>35.67148849792574 139.7387417089882 54.824 35.67148849792574 139.7387417089882 53.679 35.67149853754433 139.7387395762318 53.679 35.67148849792574 139.7387417089882 54.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-205307d3-bac7-4758-9a9f-5d4972567f93">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-205307d3-bac7-4758-9a9f-5d4972567f93_0">
											<gml:posList>35.67150279300386 139.7387637739039 54.392 35.671485021694664 139.73876856691587 55.536 35.67150279300386 139.7387637739039 55.536 35.67150279300386 139.7387637739039 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-141d1aee-40c2-4963-bf0f-799d7e17f6d5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-141d1aee-40c2-4963-bf0f-799d7e17f6d5_0">
											<gml:posList>35.67150279300386 139.7387637739039 54.392 35.671485021694664 139.73876856691587 54.392 35.671485021694664 139.73876856691587 55.536 35.67150279300386 139.7387637739039 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab83d207-4610-41ba-8a29-3d8c01d43092">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ab83d207-4610-41ba-8a29-3d8c01d43092_0">
											<gml:posList>35.671479131745684 139.73880941244326 54.392 35.671509591712784 139.73880121323094 56.982 35.671509591712784 139.73880121323094 54.392 35.671479131745684 139.73880941244326 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f5871561-337d-48d6-ba3b-56f9fdd13155">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f5871561-337d-48d6-ba3b-56f9fdd13155_0">
											<gml:posList>35.671479131745684 139.73880941244326 54.392 35.671479131745684 139.73880941244326 56.982 35.671509591712784 139.73880121323094 56.982 35.671479131745684 139.73880941244326 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ebc635d4-8524-41ef-8fae-cc10646cae5d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ebc635d4-8524-41ef-8fae-cc10646cae5d_0">
											<gml:posList>35.67149843795083 139.73873901298222 54.976 35.67149072528837 139.7387544207808 54.976 35.67150068340192 139.73875180207992 54.976 35.67149843795083 139.73873901298222 54.976</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4b0a0ec-41cb-4d84-b994-770a6e000bfd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a4b0a0ec-41cb-4d84-b994-770a6e000bfd_0">
											<gml:posList>35.67149843795083 139.73873901298222 54.976 35.67148847983755 139.7387416316846 54.976 35.67149072528837 139.7387544207808 54.976 35.67149843795083 139.73873901298222 54.976</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f626725-e7c5-4957-9733-c8abd822cb11">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2f626725-e7c5-4957-9733-c8abd822cb11_0">
											<gml:posList>35.6715000267275 139.73883385561453 54.392 35.67148964510598 139.73883665154696 56.392 35.6715000267275 139.73883385561453 56.392 35.6715000267275 139.73883385561453 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6106e92c-3aa6-423e-a0ac-b2183049ebcd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6106e92c-3aa6-423e-a0ac-b2183049ebcd_0">
											<gml:posList>35.6715000267275 139.73883385561453 54.392 35.67148964510598 139.73883665154696 54.392 35.67148964510598 139.73883665154696 56.392 35.6715000267275 139.73883385561453 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a03e404-e3a9-430a-b561-cc9570a42663">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1a03e404-e3a9-430a-b561-cc9570a42663_0">
											<gml:posList>35.67148024529787 139.7388156081669 56.982 35.67151070526538 139.7388074089568 56.982 35.671509591712784 139.73880121323094 56.982 35.67148024529787 139.7388156081669 56.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-257487eb-c33e-48ca-881c-4527656d24ba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-257487eb-c33e-48ca-881c-4527656d24ba_0">
											<gml:posList>35.671479131745684 139.73880941244326 56.982 35.67148024529787 139.7388156081669 56.982 35.671509591712784 139.73880121323094 56.982 35.671479131745684 139.73880941244326 56.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a44d012b-ae21-4bbb-98fc-a997c3767cfb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a44d012b-ae21-4bbb-98fc-a997c3767cfb_0">
											<gml:posList>35.67148024529787 139.7388156081669 54.392 35.67151070526538 139.7388074089568 56.982 35.67148024529787 139.7388156081669 56.982 35.67148024529787 139.7388156081669 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b33075fb-23a0-44a0-bc29-8c9edc6fd96e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b33075fb-23a0-44a0-bc29-8c9edc6fd96e_0">
											<gml:posList>35.67148024529787 139.7388156081669 54.392 35.67151070526538 139.7388074089568 54.392 35.67151070526538 139.7388074089568 56.982 35.67148024529787 139.7388156081669 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-023500cd-79da-445b-b16b-073e2ceeac85">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-023500cd-79da-445b-b16b-073e2ceeac85_0">
											<gml:posList>35.67149072528837 139.7387544207808 54.392 35.67150068340192 139.73875180207992 54.976 35.67149072528837 139.7387544207808 54.976 35.67149072528837 139.7387544207808 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b392c219-9096-4d5d-aa57-562bf06cd3f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b392c219-9096-4d5d-aa57-562bf06cd3f8_0">
											<gml:posList>35.67149072528837 139.7387544207808 54.392 35.67150068340192 139.73875180207992 54.392 35.67150068340192 139.73875180207992 54.976 35.67149072528837 139.7387544207808 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-34033804-ddc5-45f1-99fc-8a965e591aad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-34033804-ddc5-45f1-99fc-8a965e591aad_0">
											<gml:posList>35.67149174546907 139.73884834722216 56.392 35.6715000267275 139.73883385561453 56.392 35.67148964510598 139.73883665154696 56.392 35.67149174546907 139.73884834722216 56.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-96d07c9a-de53-404c-91aa-9750dc496318">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-96d07c9a-de53-404c-91aa-9750dc496318_0">
											<gml:posList>35.67149174546907 139.73884834722216 56.392 35.67150212709086 139.73884555129118 56.392 35.6715000267275 139.73883385561453 56.392 35.67149174546907 139.73884834722216 56.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bef3dcc6-dc18-4435-8096-480f3e69111a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bef3dcc6-dc18-4435-8096-480f3e69111a_0">
											<gml:posList>35.67150279300386 139.7387637739039 55.536 35.671489629836984 139.7387942333424 55.536 35.67150740115588 139.73878945138227 55.536 35.67150279300386 139.7387637739039 55.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e34a8c62-3290-45eb-b81a-bd6f16e74f1b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e34a8c62-3290-45eb-b81a-bd6f16e74f1b_0">
											<gml:posList>35.67150279300386 139.7387637739039 55.536 35.671485021694664 139.73876856691587 55.536 35.671489629836984 139.7387942333424 55.536 35.67150279300386 139.7387637739039 55.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80cb72d5-3970-46cb-ab88-5310b0b6639b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-80cb72d5-3970-46cb-ab88-5310b0b6639b_0">
											<gml:posList>35.67149174546907 139.73884834722216 54.392 35.67150212709086 139.73884555129118 56.392 35.67149174546907 139.73884834722216 56.392 35.67149174546907 139.73884834722216 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7805d64d-0b10-40bb-961b-1ff06adf424e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7805d64d-0b10-40bb-961b-1ff06adf424e_0">
											<gml:posList>35.67149174546907 139.73884834722216 54.392 35.67150212709086 139.73884555129118 54.392 35.67150212709086 139.73884555129118 56.392 35.67149174546907 139.73884834722216 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c604665-23a0-47e8-a533-dcd396aea841">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2c604665-23a0-47e8-a533-dcd396aea841_0">
											<gml:posList>35.671489629836984 139.7387942333424 54.392 35.67150740115588 139.73878945138227 55.536 35.671489629836984 139.7387942333424 55.536 35.671489629836984 139.7387942333424 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a6c0155-ab78-4881-b70f-ecc41a907946">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2a6c0155-ab78-4881-b70f-ecc41a907946_0">
											<gml:posList>35.671489629836984 139.7387942333424 54.392 35.67150740115588 139.73878945138227 54.392 35.67150740115588 139.73878945138227 55.536 35.671489629836984 139.7387942333424 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e9b72ba-71f0-42ad-a534-08a09e4c1f8b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9e9b72ba-71f0-42ad-a534-08a09e4c1f8b_0">
											<gml:posList>35.67150068340192 139.73875180207992 54.392 35.671499071748904 139.73874262441163 54.392 35.671499071748904 139.73874262441163 54.824 35.67150068340192 139.73875180207992 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a15420f6-a940-4954-97de-ba6dafd3238f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a15420f6-a940-4954-97de-ba6dafd3238f_0">
											<gml:posList>35.67150068340192 139.73875180207992 54.976 35.67150068340192 139.73875180207992 54.392 35.671499071748904 139.73874262441163 54.824 35.67150068340192 139.73875180207992 54.976</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19080256-ab22-4cf2-9791-3dec7cfe80c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19080256-ab22-4cf2-9791-3dec7cfe80c7_0">
											<gml:posList>35.67149853754433 139.7387395762318 54.824 35.67149853754433 139.7387395762318 53.679 35.67149843795083 139.73873901298222 53.679 35.67149853754433 139.7387395762318 54.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3755b326-4a54-4460-915a-034495615cfd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3755b326-4a54-4460-915a-034495615cfd_0">
											<gml:posList>35.67150068340192 139.73875180207992 54.976 35.671499071748904 139.73874262441163 54.824 35.67149843795083 139.73873901298222 54.976 35.67150068340192 139.73875180207992 54.976</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a0847334-db61-45fb-a1f7-3eca367350dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a0847334-db61-45fb-a1f7-3eca367350dc_0">
											<gml:posList>35.67149853754433 139.7387395762318 54.824 35.67149843795083 139.73873901298222 53.679 35.67149843795083 139.73873901298222 54.976 35.67149853754433 139.7387395762318 54.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af3a47ca-4505-4e20-af72-0346f4854077">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-af3a47ca-4505-4e20-af72-0346f4854077_0">
											<gml:posList>35.671499071748904 139.73874262441163 54.824 35.67149853754433 139.7387395762318 54.824 35.67149843795083 139.73873901298222 54.976 35.671499071748904 139.73874262441163 54.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d1ba827-f1cc-48e8-9c5e-8a925442592e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5d1ba827-f1cc-48e8-9c5e-8a925442592e_0">
											<gml:posList>35.67150212709086 139.73884555129118 54.392 35.6715000267275 139.73883385561453 56.392 35.67150212709086 139.73884555129118 56.392 35.67150212709086 139.73884555129118 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eb78c986-3bcc-480f-8e7f-367b22e7bd7b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eb78c986-3bcc-480f-8e7f-367b22e7bd7b_0">
											<gml:posList>35.67150212709086 139.73884555129118 54.392 35.6715000267275 139.73883385561453 54.392 35.6715000267275 139.73883385561453 56.392 35.67150212709086 139.73884555129118 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63543f6b-2d29-4eb9-b2b9-33772fd9fd47">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-63543f6b-2d29-4eb9-b2b9-33772fd9fd47_0">
											<gml:posList>35.67150279300386 139.7387637739039 55.536 35.67150740115588 139.73878945138227 54.392 35.67150279300386 139.7387637739039 54.392 35.67150279300386 139.7387637739039 55.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-153a41d0-d4b6-4d38-b0fa-27d0a84078eb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-153a41d0-d4b6-4d38-b0fa-27d0a84078eb_0">
											<gml:posList>35.67150279300386 139.7387637739039 55.536 35.67150740115588 139.73878945138227 55.536 35.67150740115588 139.73878945138227 54.392 35.67150279300386 139.7387637739039 55.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58d6ed72-2651-4435-9bce-7c2df2677046">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-58d6ed72-2651-4435-9bce-7c2df2677046_0">
											<gml:posList>35.67151070526538 139.7388074089568 54.392 35.671509591712784 139.73880121323094 56.982 35.67151070526538 139.7388074089568 56.982 35.67151070526538 139.7388074089568 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-72cea661-9b3c-4a5d-adbd-744ecfe8cfaf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-72cea661-9b3c-4a5d-adbd-744ecfe8cfaf_0">
											<gml:posList>35.67151070526538 139.7388074089568 54.392 35.671509591712784 139.73880121323094 54.392 35.671509591712784 139.73880121323094 56.982 35.67151070526538 139.7388074089568 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-31423e10-077e-48d3-8d33-3bfabf39bbb9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-31423e10-077e-48d3-8d33-3bfabf39bbb9_0">
											<gml:posList>35.67144932415029 139.73875304463385 54.824 35.671451388509986 139.73876479557546 55.297 35.67144932415029 139.73875304463385 55.297 35.67144932415029 139.73875304463385 54.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b01fa55-e288-43f6-b843-90d5adca804e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7b01fa55-e288-43f6-b843-90d5adca804e_0">
											<gml:posList>35.67144932415029 139.73875304463385 54.824 35.671451388509986 139.73876479557546 54.824 35.671451388509986 139.73876479557546 55.297 35.67144932415029 139.73875304463385 54.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d914f91c-981b-4a4b-b7ea-eed1da569a05">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d914f91c-981b-4a4b-b7ea-eed1da569a05_0">
											<gml:posList>35.6714519924719 139.7387533728783 54.392 35.67145389381247 139.73876414088235 54.824 35.6714519924719 139.7387533728783 54.824 35.6714519924719 139.7387533728783 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d6b2938-5de7-4139-991d-7900b50d3d00">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4d6b2938-5de7-4139-991d-7900b50d3d00_0">
											<gml:posList>35.6714519924719 139.7387533728783 54.392 35.67145389381247 139.73876414088235 54.392 35.67145389381247 139.73876414088235 54.824 35.6714519924719 139.7387533728783 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-730976b4-774c-446e-8881-052d399baf84">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-730976b4-774c-446e-8881-052d399baf84_0">
											<gml:posList>35.67144932415029 139.73875304463385 54.824 35.67145937237505 139.73875039268864 55.297 35.67145937237505 139.73875039268864 54.824 35.67144932415029 139.73875304463385 54.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b946b97e-6a57-4e13-8af7-0e9b4c02dbf0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b946b97e-6a57-4e13-8af7-0e9b4c02dbf0_0">
											<gml:posList>35.67144932415029 139.73875304463385 54.824 35.67144932415029 139.73875304463385 55.297 35.67145937237505 139.73875039268864 55.297 35.67144932415029 139.73875304463385 54.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b6155d1-d4ff-475f-8136-ad7dc96c3648">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b6155d1-d4ff-475f-8136-ad7dc96c3648_0">
											<gml:posList>35.67144932415029 139.73875304463385 55.297 35.671451388509986 139.73876479557546 55.297 35.671461436735015 139.73876214363167 55.297 35.67144932415029 139.73875304463385 55.297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a144f8d9-ed5e-4981-8dd7-79f41a91a5d3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a144f8d9-ed5e-4981-8dd7-79f41a91a5d3_0">
											<gml:posList>35.67145937237505 139.73875039268864 55.297 35.67144932415029 139.73875304463385 55.297 35.671461436735015 139.73876214363167 55.297 35.67145937237505 139.73875039268864 55.297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0812fcd4-2f5f-4bb4-8556-f9b9b310defa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0812fcd4-2f5f-4bb4-8556-f9b9b310defa_0">
											<gml:posList>35.6714519924719 139.7387533728783 54.824 35.671459544399305 139.73875136456962 54.392 35.6714519924719 139.7387533728783 54.392 35.6714519924719 139.7387533728783 54.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1ded08a-f30f-4e06-859d-ebc725fa3caa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a1ded08a-f30f-4e06-859d-ebc725fa3caa_0">
											<gml:posList>35.6714519924719 139.7387533728783 54.824 35.671459544399305 139.73875136456962 54.824 35.671459544399305 139.73875136456962 54.392 35.6714519924719 139.7387533728783 54.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-86956779-6e0d-4971-a66e-e6fe7c7c9a15">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-86956779-6e0d-4971-a66e-e6fe7c7c9a15_0">
											<gml:posList>35.671451388509986 139.73876479557546 54.824 35.67145389381247 139.73876414088235 54.824 35.671451388509986 139.73876479557546 55.297 35.671451388509986 139.73876479557546 54.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f22b583b-9fdf-4282-9752-fc33a3221b8f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f22b583b-9fdf-4282-9752-fc33a3221b8f_0">
											<gml:posList>35.671451388509986 139.73876479557546 55.297 35.67145389381247 139.73876414088235 54.824 35.671461436735015 139.73876214363167 55.297 35.671451388509986 139.73876479557546 55.297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4f1ae756-16a1-4eb7-9264-d82be84c37ef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4f1ae756-16a1-4eb7-9264-d82be84c37ef_0">
											<gml:posList>35.671461436735015 139.73876214363167 55.297 35.67145389381247 139.73876414088235 54.824 35.671461436735015 139.73876214363167 54.392 35.671461436735015 139.73876214363167 55.297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-160a363e-38f9-40a5-8913-20caa9a5b8fe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-160a363e-38f9-40a5-8913-20caa9a5b8fe_0">
											<gml:posList>35.67145389381247 139.73876414088235 54.824 35.67145389381247 139.73876414088235 54.392 35.671461436735015 139.73876214363167 54.392 35.67145389381247 139.73876414088235 54.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a714c3b4-f9c8-47af-bcf4-041be0bfa802">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a714c3b4-f9c8-47af-bcf4-041be0bfa802_0">
											<gml:posList>35.67145937237505 139.73875039268864 54.824 35.67145937237505 139.73875039268864 55.297 35.671459544399305 139.73875136456962 54.824 35.67145937237505 139.73875039268864 54.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a64af8c2-b30b-44a4-a19a-d85ec2c77faa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a64af8c2-b30b-44a4-a19a-d85ec2c77faa_0">
											<gml:posList>35.671459544399305 139.73875136456962 54.392 35.671459544399305 139.73875136456962 54.824 35.671461436735015 139.73876214363167 54.392 35.671459544399305 139.73875136456962 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6bb5dbe1-341f-46b8-a784-1dd67b4162d9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6bb5dbe1-341f-46b8-a784-1dd67b4162d9_0">
											<gml:posList>35.671461436735015 139.73876214363167 54.392 35.671459544399305 139.73875136456962 54.824 35.671461436735015 139.73876214363167 55.297 35.671461436735015 139.73876214363167 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6487898a-7ad7-4b07-8b94-597ffaf55d0b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6487898a-7ad7-4b07-8b94-597ffaf55d0b_0">
											<gml:posList>35.671459544399305 139.73875136456962 54.824 35.67145937237505 139.73875039268864 55.297 35.671461436735015 139.73876214363167 55.297 35.671459544399305 139.73875136456962 54.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-794549a6-3ddf-466d-94c2-6dc986e07bdf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-794549a6-3ddf-466d-94c2-6dc986e07bdf_0">
											<gml:posList>35.67146869565176 139.73876579143072 54.392 35.6714705606414 139.73877618390225 55.13 35.67146869565176 139.73876579143072 55.13 35.67146869565176 139.73876579143072 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-008e8430-b931-4172-ae2e-47812dae5178">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-008e8430-b931-4172-ae2e-47812dae5178_0">
											<gml:posList>35.67146869565176 139.73876579143072 54.392 35.6714705606414 139.73877618390225 54.392 35.6714705606414 139.73877618390225 55.13 35.67146869565176 139.73876579143072 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d42b58c7-36ce-45cb-8b6e-c4b64aea7e71">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d42b58c7-36ce-45cb-8b6e-c4b64aea7e71_0">
											<gml:posList>35.67148849792574 139.7387417089882 53.679 35.67148849792574 139.7387417089882 54.824 35.67148847983755 139.7387416316846 54.976 35.67148849792574 139.7387417089882 53.679</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd36922c-bdb0-4861-8e0a-16cd9d1b7f09">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bd36922c-bdb0-4861-8e0a-16cd9d1b7f09_0">
											<gml:posList>35.67148847983755 139.7387416316846 54.976 35.67148903213026 139.73874475716764 54.824 35.67149072528837 139.7387544207808 54.976 35.67148847983755 139.7387416316846 54.976</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8edafc65-5556-4a5b-b693-e70898577e7e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8edafc65-5556-4a5b-b693-e70898577e7e_0">
											<gml:posList>35.67148903213026 139.73874475716764 54.824 35.67149072528837 139.7387544207808 54.392 35.67149072528837 139.7387544207808 54.976 35.67148903213026 139.73874475716764 54.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fbe9eb75-550e-4758-be8e-2c629d24e033">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fbe9eb75-550e-4758-be8e-2c629d24e033_0">
											<gml:posList>35.67148903213026 139.73874475716764 54.392 35.67149072528837 139.7387544207808 54.392 35.67148903213026 139.73874475716764 54.824 35.67148903213026 139.73874475716764 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db9a7ba1-bbd6-4526-af39-cf621fe8344b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-db9a7ba1-bbd6-4526-af39-cf621fe8344b_0">
											<gml:posList>35.67148849792574 139.7387417089882 54.824 35.67148903213026 139.73874475716764 54.824 35.67148847983755 139.7387416316846 54.976 35.67148849792574 139.7387417089882 54.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3593240-26f6-4f33-ab53-0964df861846">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67148849792574 139.7387417089882 53.679 35.67149843795083 139.73873901298222 53.679 35.67149853754433 139.7387395762318 53.679 35.67148849792574 139.7387417089882 53.679</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f78c2ee0-e795-4231-b468-ce641210cd53">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67148903213026 139.73874475716764 54.824 35.67149853754433 139.7387395762318 54.824 35.671499071748904 139.73874262441163 54.824 35.67148903213026 139.73874475716764 54.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2873a559-29b3-41ab-90d7-efe78ac8eeec">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67148903213026 139.73874475716764 54.824 35.67148849792574 139.7387417089882 54.824 35.67149853754433 139.7387395762318 54.824 35.67148903213026 139.73874475716764 54.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-87847b18-bc84-4bae-a65a-69542804d9e3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67149072528837 139.7387544207808 54.392 35.671499071748904 139.73874262441163 54.392 35.67150068340192 139.73875180207992 54.392 35.67149072528837 139.7387544207808 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c53e787-79e1-43d1-b3a2-e2f83cba9ef8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67149072528837 139.7387544207808 54.392 35.67148903213026 139.73874475716764 54.392 35.671499071748904 139.73874262441163 54.392 35.67149072528837 139.7387544207808 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53761907-3dd5-43fa-a0c7-2982c407259a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67145389381247 139.73876414088235 54.824 35.671451388509986 139.73876479557546 54.824 35.6714519924719 139.7387533728783 54.824 35.67145389381247 139.73876414088235 54.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-67ef3d9c-a067-484b-b5f5-c6fb2a4f008f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671459544399305 139.73875136456962 54.824 35.6714519924719 139.7387533728783 54.824 35.67145937237505 139.73875039268864 54.824 35.671459544399305 139.73875136456962 54.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-916ba862-80ce-46a1-86f3-a7716e2356f3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67145937237505 139.73875039268864 54.824 35.6714519924719 139.7387533728783 54.824 35.67144932415029 139.73875304463385 54.824 35.67145937237505 139.73875039268864 54.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24537462-436d-4fdb-8c5d-f184a500e66c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6714519924719 139.7387533728783 54.824 35.671451388509986 139.73876479557546 54.824 35.67144932415029 139.73875304463385 54.824 35.6714519924719 139.7387533728783 54.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9dff6715-6c18-476e-a96b-ffa7c3a534a1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671461436735015 139.73876214363167 54.392 35.67145389381247 139.73876414088235 54.392 35.6714519924719 139.7387533728783 54.392 35.671461436735015 139.73876214363167 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57ad2b13-d837-4c1a-bfac-635f07ea3247">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671459544399305 139.73875136456962 54.392 35.671461436735015 139.73876214363167 54.392 35.6714519924719 139.7387533728783 54.392 35.671459544399305 139.73875136456962 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61c1eeef-f808-48cd-86a4-3457979163df">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671477347001684 139.73876346148003 54.392 35.671479211991524 139.73877385395264 54.392 35.6714705606414 139.73877618390225 54.392 35.671477347001684 139.73876346148003 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cef296f4-4fb2-4c03-bd65-2e9502c2d95d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67146869565176 139.73876579143072 54.392 35.671477347001684 139.73876346148003 54.392 35.6714705606414 139.73877618390225 54.392 35.67146869565176 139.73876579143072 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a1cd288-0fee-4422-995d-033e9008cd85">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671489629836984 139.7387942333424 54.392 35.67150279300386 139.7387637739039 54.392 35.67150740115588 139.73878945138227 54.392 35.671489629836984 139.7387942333424 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f02ecbf5-0848-4572-9a65-0bea120329a0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671489629836984 139.7387942333424 54.392 35.671485021694664 139.73876856691587 54.392 35.67150279300386 139.7387637739039 54.392 35.671489629836984 139.7387942333424 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eb70a036-2dd8-4548-b922-f2dc0c142e58">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671509591712784 139.73880121323094 54.392 35.67151070526538 139.7388074089568 54.392 35.67148024529787 139.7388156081669 54.392 35.671509591712784 139.73880121323094 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-543ebbb6-77db-4833-a71c-6b38bf2c61b4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671479131745684 139.73880941244326 54.392 35.671509591712784 139.73880121323094 54.392 35.67148024529787 139.7388156081669 54.392 35.671479131745684 139.73880941244326 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57b92bab-d870-4243-9fe8-ed5e5c2989dc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6715000267275 139.73883385561453 54.392 35.67149174546907 139.73884834722216 54.392 35.67148964510598 139.73883665154696 54.392 35.6715000267275 139.73883385561453 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c646cb22-95fe-42f7-b461-858fe84e7b91">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6715000267275 139.73883385561453 54.392 35.67150212709086 139.73884555129118 54.392 35.67149174546907 139.73884834722216 54.392 35.6715000267275 139.73883385561453 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-92c1ebf2-f809-4bfb-8e98-1e2e8684229b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-92c1ebf2-f809-4bfb-8e98-1e2e8684229b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-92c1ebf2-f809-4bfb-8e98-1e2e8684229b">
											<gml:posList>35.67146055654792 139.7387202677367 15.03 35.671501380195636 139.73870939407556 15.03 35.671506450271934 139.73873788784095 15.03 35.6715394336331 139.73872912225372 15.03 35.6715617968295 139.7388555773982 15.03 35.67143725312128 139.73888875291183 15.03 35.671416882087144 139.73877389432673 15.03 35.67145139752371 139.73876479556483 15.03 35.6714489619789 139.7387509793831 15.03 35.67146518330936 139.73874667424005 15.03 35.67146055654792 139.7387202677367 15.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5b890616-0dfe-4f28-89b8-9b3cbc94ddbf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b890616-0dfe-4f28-89b8-9b3cbc94ddbf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b890616-0dfe-4f28-89b8-9b3cbc94ddbf">
											<gml:posList>35.67143725312128 139.73888875291183 54.824 35.67143920617878 139.7388850279726 54.824 35.67141992159342 139.73877628781122 54.824 35.671416882087144 139.73877389432673 54.824 35.67143725312128 139.73888875291183 54.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d19d8c13-3d2e-4337-a5df-3d8fa5174f0e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d19d8c13-3d2e-4337-a5df-3d8fa5174f0e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d19d8c13-3d2e-4337-a5df-3d8fa5174f0e">
											<gml:posList>35.67145139752371 139.73876479556483 54.824 35.671416882087144 139.73877389432673 54.824 35.67141992159342 139.73877628781122 54.824 35.671454428016425 139.73876718906064 54.824 35.67145139752371 139.73876479556483 54.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-887203a7-0b40-4883-a2c4-1881e07046be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-887203a7-0b40-4883-a2c4-1881e07046be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-887203a7-0b40-4883-a2c4-1881e07046be">
											<gml:posList>35.67145139752371 139.73876479556483 54.824 35.671454428016425 139.73876718906064 54.824 35.6714519924719 139.7387533728783 54.824 35.6714489619789 139.7387509793831 54.824 35.67145139752371 139.73876479556483 54.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4b43d405-a799-4c56-adf2-315f9a9f6b6d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b43d405-a799-4c56-adf2-315f9a9f6b6d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b43d405-a799-4c56-adf2-315f9a9f6b6d">
											<gml:posList>35.67146518330936 139.73874667424005 54.824 35.6714489619789 139.7387509793831 54.824 35.6714519924719 139.7387533728783 54.824 35.6714657355412 139.7387497223974 54.824 35.67146518330936 139.73874667424005 54.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1c2428ce-e15a-4828-8cfa-fa0d3fb64361">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c2428ce-e15a-4828-8cfa-fa0d3fb64361">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c2428ce-e15a-4828-8cfa-fa0d3fb64361">
											<gml:posList>35.671501380195636 139.73870939407556 53.679 35.67146055654792 139.7387202677367 53.679 35.67146518330936 139.73874667424005 53.679 35.671506450271934 139.73873788784095 53.679 35.671501380195636 139.73870939407556 53.679</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-83371db6-e0a9-40d6-8621-ce0abe6d4c3f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83371db6-e0a9-40d6-8621-ce0abe6d4c3f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83371db6-e0a9-40d6-8621-ce0abe6d4c3f">
											<gml:posList>35.67146518330936 139.73874667424005 54.824 35.6714657355412 139.7387497223974 54.824 35.67150693941662 139.73874094712065 54.824 35.671506450271934 139.73873788784095 54.824 35.67146518330936 139.73874667424005 54.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-af5f97aa-3eb8-4dfd-806c-beb1aca1d24d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af5f97aa-3eb8-4dfd-806c-beb1aca1d24d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af5f97aa-3eb8-4dfd-806c-beb1aca1d24d">
											<gml:posList>35.67150693941662 139.73874094712065 54.392 35.6714657355412 139.7387497223974 54.392 35.6714519924719 139.7387533728783 54.392 35.671454428016425 139.73876718906064 54.392 35.67141992159342 139.73877628781122 54.392 35.67143920617878 139.7388850279726 54.392 35.671558766338585 139.73885318389586 54.392 35.67153748057179 139.73873283615498 54.392 35.67150693941662 139.73874094712065 54.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-247c8bce-1d1c-4cd2-9196-383ae49874c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-247c8bce-1d1c-4cd2-9196-383ae49874c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-247c8bce-1d1c-4cd2-9196-383ae49874c4">
											<gml:posList>35.6715617968295 139.7388555773982 54.824 35.671558766338585 139.73885318389586 54.824 35.67143920617878 139.7388850279726 54.824 35.67143725312128 139.73888875291183 54.824 35.6715617968295 139.7388555773982 54.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4d1a207b-166e-46f7-b9af-aa38a38fe2f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d1a207b-166e-46f7-b9af-aa38a38fe2f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d1a207b-166e-46f7-b9af-aa38a38fe2f8">
											<gml:posList>35.671506450271934 139.73873788784095 54.824 35.67150693941662 139.73874094712065 54.824 35.67153748057179 139.73873283615498 54.824 35.6715394336331 139.73872912225372 54.824 35.671506450271934 139.73873788784095 54.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4b0bf06b-14d8-4f7c-9aac-059fc955c915">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b0bf06b-14d8-4f7c-9aac-059fc955c915">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b0bf06b-14d8-4f7c-9aac-059fc955c915">
											<gml:posList>35.6715394336331 139.73872912225372 54.824 35.67153748057179 139.73873283615498 54.824 35.671558766338585 139.73885318389586 54.824 35.6715617968295 139.7388555773982 54.824 35.6715394336331 139.73872912225372 54.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8933b8b0-0ddc-433b-bb56-442f470b7e5c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8933b8b0-0ddc-433b-bb56-442f470b7e5c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8933b8b0-0ddc-433b-bb56-442f470b7e5c">
											<gml:posList>35.67146518330936 139.73874667424005 53.679 35.67146055654792 139.7387202677367 53.679 35.67146055654792 139.7387202677367 15.03 35.67146518330936 139.73874667424005 15.03 35.67146518330936 139.73874667424005 53.679</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ac82291a-83a6-4a04-bfcd-fa96b9bf34fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ac82291a-83a6-4a04-bfcd-fa96b9bf34fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ac82291a-83a6-4a04-bfcd-fa96b9bf34fd">
											<gml:posList>35.67146055654792 139.7387202677367 53.679 35.671501380195636 139.73870939407556 53.679 35.671501380195636 139.73870939407556 15.03 35.67146055654792 139.7387202677367 15.03 35.67146055654792 139.7387202677367 53.679</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4d3417db-d57d-45e2-a465-4993c493d59d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d3417db-d57d-45e2-a465-4993c493d59d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d3417db-d57d-45e2-a465-4993c493d59d">
											<gml:posList>35.671506450271934 139.73873788784095 15.03 35.671501380195636 139.73870939407556 15.03 35.671501380195636 139.73870939407556 53.679 35.671506450271934 139.73873788784095 53.679 35.671506450271934 139.73873788784095 15.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b5dc1cbb-8c78-4127-8b80-d4786db98309">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b5dc1cbb-8c78-4127-8b80-d4786db98309">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b5dc1cbb-8c78-4127-8b80-d4786db98309">
											<gml:posList>35.67150693941662 139.73874094712065 54.824 35.67150693941662 139.73874094712065 54.392 35.67153748057179 139.73873283615498 54.392 35.67153748057179 139.73873283615498 54.824 35.67150693941662 139.73874094712065 54.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-50d0f6b6-ed7b-4808-8932-4a9cbf42993d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50d0f6b6-ed7b-4808-8932-4a9cbf42993d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50d0f6b6-ed7b-4808-8932-4a9cbf42993d">
											<gml:posList>35.6715394336331 139.73872912225372 54.824 35.6715394336331 139.73872912225372 15.03 35.671506450271934 139.73873788784095 15.03 35.671506450271934 139.73873788784095 53.679 35.671506450271934 139.73873788784095 54.824 35.6715394336331 139.73872912225372 54.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-da4fa4a9-8b38-4968-b324-6f88c6b390eb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da4fa4a9-8b38-4968-b324-6f88c6b390eb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da4fa4a9-8b38-4968-b324-6f88c6b390eb">
											<gml:posList>35.671416882087144 139.73877389432673 15.03 35.67143725312128 139.73888875291183 15.03 35.67143725312128 139.73888875291183 54.824 35.671416882087144 139.73877389432673 54.824 35.671416882087144 139.73877389432673 15.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c7204564-9839-4873-a1f5-250aae7f2008">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c7204564-9839-4873-a1f5-250aae7f2008">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c7204564-9839-4873-a1f5-250aae7f2008">
											<gml:posList>35.67143920617878 139.7388850279726 54.824 35.67143920617878 139.7388850279726 54.392 35.67141992159342 139.73877628781122 54.392 35.67141992159342 139.73877628781122 54.824 35.67143920617878 139.7388850279726 54.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5ddda0c5-e382-4e5a-bd7d-40c7f36b8d72">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5ddda0c5-e382-4e5a-bd7d-40c7f36b8d72">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5ddda0c5-e382-4e5a-bd7d-40c7f36b8d72">
											<gml:posList>35.67145139752371 139.73876479556483 15.03 35.671416882087144 139.73877389432673 15.03 35.671416882087144 139.73877389432673 54.824 35.67145139752371 139.73876479556483 54.824 35.67145139752371 139.73876479556483 15.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-84570358-2e87-4ea1-9360-b1a600a85140">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84570358-2e87-4ea1-9360-b1a600a85140">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84570358-2e87-4ea1-9360-b1a600a85140">
											<gml:posList>35.67141992159342 139.73877628781122 54.824 35.67141992159342 139.73877628781122 54.392 35.671454428016425 139.73876718906064 54.392 35.671454428016425 139.73876718906064 54.824 35.67141992159342 139.73877628781122 54.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e0264616-fdd7-41ab-bbbd-36f978a7993b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e0264616-fdd7-41ab-bbbd-36f978a7993b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e0264616-fdd7-41ab-bbbd-36f978a7993b">
											<gml:posList>35.6714489619789 139.7387509793831 15.03 35.67145139752371 139.73876479556483 15.03 35.67145139752371 139.73876479556483 54.824 35.6714489619789 139.7387509793831 54.824 35.6714489619789 139.7387509793831 15.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6cd3a3c3-527d-49fb-8aa5-ab6f47053d63">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6cd3a3c3-527d-49fb-8aa5-ab6f47053d63">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6cd3a3c3-527d-49fb-8aa5-ab6f47053d63">
											<gml:posList>35.671454428016425 139.73876718906064 54.824 35.671454428016425 139.73876718906064 54.392 35.6714519924719 139.7387533728783 54.392 35.6714519924719 139.7387533728783 54.824 35.671454428016425 139.73876718906064 54.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-594f848c-bbf1-40ac-b22d-5cc885ff3aa1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-594f848c-bbf1-40ac-b22d-5cc885ff3aa1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-594f848c-bbf1-40ac-b22d-5cc885ff3aa1">
											<gml:posList>35.6714489619789 139.7387509793831 15.03 35.6714489619789 139.7387509793831 54.824 35.67146518330936 139.73874667424005 54.824 35.67146518330936 139.73874667424005 53.679 35.67146518330936 139.73874667424005 15.03 35.6714489619789 139.7387509793831 15.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bdc0b3cc-31ce-466e-856b-7e4bf706aec1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bdc0b3cc-31ce-466e-856b-7e4bf706aec1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bdc0b3cc-31ce-466e-856b-7e4bf706aec1">
											<gml:posList>35.6714519924719 139.7387533728783 54.824 35.6714519924719 139.7387533728783 54.392 35.6714657355412 139.7387497223974 54.392 35.6714657355412 139.7387497223974 54.824 35.6714519924719 139.7387533728783 54.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fb5802ff-b637-43ff-a4b7-eb17b89302a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb5802ff-b637-43ff-a4b7-eb17b89302a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb5802ff-b637-43ff-a4b7-eb17b89302a1">
											<gml:posList>35.671506450271934 139.73873788784095 54.824 35.671506450271934 139.73873788784095 53.679 35.67146518330936 139.73874667424005 53.679 35.67146518330936 139.73874667424005 54.824 35.671506450271934 139.73873788784095 54.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6f10757f-7746-4b32-b881-ecd54282093f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f10757f-7746-4b32-b881-ecd54282093f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f10757f-7746-4b32-b881-ecd54282093f">
											<gml:posList>35.6714657355412 139.7387497223974 54.824 35.6714657355412 139.7387497223974 54.392 35.67150693941662 139.73874094712065 54.392 35.67150693941662 139.73874094712065 54.824 35.6714657355412 139.7387497223974 54.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-845b40cd-81df-4b48-a1ac-2e0938b26d76">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-845b40cd-81df-4b48-a1ac-2e0938b26d76">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-845b40cd-81df-4b48-a1ac-2e0938b26d76">
											<gml:posList>35.671558766338585 139.73885318389586 54.824 35.671558766338585 139.73885318389586 54.392 35.67143920617878 139.7388850279726 54.392 35.67143920617878 139.7388850279726 54.824 35.671558766338585 139.73885318389586 54.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1c58229d-3d73-4906-a489-d8ba41f6cca9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c58229d-3d73-4906-a489-d8ba41f6cca9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c58229d-3d73-4906-a489-d8ba41f6cca9">
											<gml:posList>35.67143725312128 139.73888875291183 15.03 35.6715617968295 139.7388555773982 15.03 35.6715617968295 139.7388555773982 54.824 35.67143725312128 139.73888875291183 54.824 35.67143725312128 139.73888875291183 15.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7a470298-5b76-4c3f-9878-b4c06779764e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a470298-5b76-4c3f-9878-b4c06779764e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a470298-5b76-4c3f-9878-b4c06779764e">
											<gml:posList>35.67153748057179 139.73873283615498 54.824 35.67153748057179 139.73873283615498 54.392 35.671558766338585 139.73885318389586 54.392 35.671558766338585 139.73885318389586 54.824 35.67153748057179 139.73873283615498 54.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-70f93d52-2984-4b12-9fa8-0b6b8bb9e983">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70f93d52-2984-4b12-9fa8-0b6b8bb9e983">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70f93d52-2984-4b12-9fa8-0b6b8bb9e983">
											<gml:posList>35.6715617968295 139.7388555773982 15.03 35.6715394336331 139.73872912225372 15.03 35.6715394336331 139.73872912225372 54.824 35.6715617968295 139.7388555773982 54.824 35.6715617968295 139.7388555773982 15.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1624</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">173.23253</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.3</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>