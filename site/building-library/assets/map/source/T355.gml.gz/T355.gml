<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_6667a4b9-3010-446f-a1ff-34b1549059c3">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門駅南地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">35.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>10</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66863207886215 139.74867958105577 0 35.66864628265847 139.74863849695254 0 35.66871237603885 139.748670792009 0 35.668744217494265 139.74857532064735 0 35.66873978131916 139.74856050155873 0 35.66873816406697 139.74855511280398 0 35.66858768723108 139.74848890745736 0 35.66855349985245 139.74859374816154 0 35.66855602424027 139.7485945187143 0 35.66857033388376 139.74860140734842 0 35.668562545085436 139.7486257057547 0 35.66855752741407 139.74864275504757 0 35.66863207886215 139.74867958105577 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66863207886215 139.74867958105577 5.67 35.66855752741407 139.74864275504757 5.67 35.668562545085436 139.7486257057547 5.67 35.66857033388376 139.74860140734842 5.67 35.66855602424027 139.7485945187143 5.67 35.66855349985245 139.74859374816154 5.67 35.66858768723108 139.74848890745736 5.67 35.66873816406697 139.74855511280398 5.67 35.66873978131916 139.74856050155873 5.67 35.668744217494265 139.74857532064735 5.67 35.66871237603885 139.748670792009 5.67 35.66864628265847 139.74863849695254 5.67 35.66863207886215 139.74867958105577 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66863207886215 139.74867958105577 5.67 35.66864628265847 139.74863849695254 5.67 35.66864628265847 139.74863849695254 39.71 35.66863207886215 139.74867958105577 39.71 35.66863207886215 139.74867958105577 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66864628265847 139.74863849695254 5.67 35.66871237603885 139.748670792009 5.67 35.66871237603885 139.748670792009 39.71 35.66864628265847 139.74863849695254 39.71 35.66864628265847 139.74863849695254 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66871237603885 139.748670792009 5.67 35.668744217494265 139.74857532064735 5.67 35.668744217494265 139.74857532064735 39.71 35.66871237603885 139.748670792009 39.71 35.66871237603885 139.748670792009 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668744217494265 139.74857532064735 5.67 35.66873978131916 139.74856050155873 5.67 35.66873978131916 139.74856050155873 39.71 35.668744217494265 139.74857532064735 39.71 35.668744217494265 139.74857532064735 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66873978131916 139.74856050155873 5.67 35.66873816406697 139.74855511280398 5.67 35.66873816406697 139.74855511280398 39.71 35.66873978131916 139.74856050155873 39.71 35.66873978131916 139.74856050155873 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66873816406697 139.74855511280398 5.67 35.66858768723108 139.74848890745736 5.67 35.66858768723108 139.74848890745736 39.71 35.66873816406697 139.74855511280398 39.71 35.66873816406697 139.74855511280398 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66858768723108 139.74848890745736 5.67 35.66855349985245 139.74859374816154 5.67 35.66855349985245 139.74859374816154 39.71 35.66858768723108 139.74848890745736 39.71 35.66858768723108 139.74848890745736 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66855349985245 139.74859374816154 5.67 35.66855602424027 139.7485945187143 5.67 35.66855602424027 139.7485945187143 39.71 35.66855349985245 139.74859374816154 39.71 35.66855349985245 139.74859374816154 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66855602424027 139.7485945187143 5.67 35.66857033388376 139.74860140734842 5.67 35.66857033388376 139.74860140734842 39.71 35.66855602424027 139.7485945187143 39.71 35.66855602424027 139.7485945187143 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66857033388376 139.74860140734842 5.67 35.668562545085436 139.7486257057547 5.67 35.668562545085436 139.7486257057547 39.71 35.66857033388376 139.74860140734842 39.71 35.66857033388376 139.74860140734842 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668562545085436 139.7486257057547 5.67 35.66855752741407 139.74864275504757 5.67 35.66855752741407 139.74864275504757 39.71 35.668562545085436 139.7486257057547 39.71 35.668562545085436 139.7486257057547 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66855752741407 139.74864275504757 5.67 35.66863207886215 139.74867958105577 5.67 35.66863207886215 139.74867958105577 39.71 35.66855752741407 139.74864275504757 39.71 35.66855752741407 139.74864275504757 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66863207886215 139.74867958105577 39.71 35.66864628265847 139.74863849695254 39.71 35.66871237603885 139.748670792009 39.71 35.668744217494265 139.74857532064735 39.71 35.66873978131916 139.74856050155873 39.71 35.66873816406697 139.74855511280398 39.71 35.66858768723108 139.74848890745736 39.71 35.66855349985245 139.74859374816154 39.71 35.66855602424027 139.7485945187143 39.71 35.66857033388376 139.74860140734842 39.71 35.668562545085436 139.7486257057547 39.71 35.66855752741407 139.74864275504757 39.71 35.66863207886215 139.74867958105577 39.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-998a4f92-81e1-4879-bb72-ab14ff13333d"/>
							<gml:surfaceMember xlink:href="#poly-b408e767-80c9-4175-a23d-b951fdb10b7c"/>
							<gml:surfaceMember xlink:href="#poly-36b448fb-4b62-4f8a-bdd4-3edf51e0baf4"/>
							<gml:surfaceMember xlink:href="#poly-dbb5c213-967d-461c-93e0-3968eb47dd0e"/>
							<gml:surfaceMember xlink:href="#poly-139d7a8e-49bb-4896-b631-bf69ef469957"/>
							<gml:surfaceMember xlink:href="#poly-7f2418fc-540f-44a2-b58b-0a2c766ca42a"/>
							<gml:surfaceMember xlink:href="#poly-f74a38fb-6ed3-4912-a947-89cb41a77d25"/>
							<gml:surfaceMember xlink:href="#poly-74423f3b-6c28-4938-b0b8-bb49a2e36fa6"/>
							<gml:surfaceMember xlink:href="#poly-6c618980-92bc-4d6f-bfa1-a9e77bbfd7e9"/>
							<gml:surfaceMember xlink:href="#poly-a336033d-cd22-4209-a851-aa3dc9568f43"/>
							<gml:surfaceMember xlink:href="#poly-aaf211ee-4472-4c7b-be93-ea16bd28d314"/>
							<gml:surfaceMember xlink:href="#poly-6d4f0b72-809d-485b-b03e-9fe79f19eebe"/>
							<gml:surfaceMember xlink:href="#poly-7625db90-158f-4725-adb6-1836dd81898c"/>
							<gml:surfaceMember xlink:href="#poly-d1876708-ec9c-458b-8bb4-f8d69c434aef"/>
							<gml:surfaceMember xlink:href="#poly-6123ed98-2060-4799-b348-b85210d4124e"/>
							<gml:surfaceMember xlink:href="#poly-29c47dc6-ff67-4424-9a11-ea99f60389e7"/>
							<gml:surfaceMember xlink:href="#poly-5452d381-befd-4f66-8fe3-6f2d037cc77a"/>
							<gml:surfaceMember xlink:href="#poly-9aefc1d7-d08f-4639-b7d0-4b9923439cc3"/>
							<gml:surfaceMember xlink:href="#poly-49bcb2c5-a944-4c62-818a-30810ce8c63f"/>
							<gml:surfaceMember xlink:href="#poly-414ef87b-6314-4b42-b1ab-46eef4e23fa4"/>
							<gml:surfaceMember xlink:href="#poly-0fb3e391-271c-45c5-910a-748f49f351d4"/>
							<gml:surfaceMember xlink:href="#poly-e04d5841-acfe-40eb-99b7-74073d06744a"/>
							<gml:surfaceMember xlink:href="#poly-8ff4cdea-28f4-40a9-ba8e-94416e216e85"/>
							<gml:surfaceMember xlink:href="#poly-fe917174-a733-46cc-879b-c4de17a9b7e6"/>
							<gml:surfaceMember xlink:href="#poly-e8194e78-a4d4-4aec-9fcb-feea73697928"/>
							<gml:surfaceMember xlink:href="#poly-b6c0bd66-b451-4ace-bee3-348b4ac51d02"/>
							<gml:surfaceMember xlink:href="#poly-d7cf0f4d-c3b7-4f11-8ce7-c7f01dcc1295"/>
							<gml:surfaceMember xlink:href="#poly-80efcb16-bc21-4f14-9ba4-6e2385a7763c"/>
							<gml:surfaceMember xlink:href="#poly-08de1676-dabd-41ac-983f-74bf8513b2c1"/>
							<gml:surfaceMember xlink:href="#poly-a39faffe-4490-451d-8d97-91599dd5b943"/>
							<gml:surfaceMember xlink:href="#poly-cfcec912-0ebe-41b6-baa6-b112ab40b13f"/>
							<gml:surfaceMember xlink:href="#poly-1b37cb56-cc43-4eb7-9606-7cd825f8289e"/>
							<gml:surfaceMember xlink:href="#poly-fddef19c-52cc-4b10-8e25-9e74249eebe9"/>
							<gml:surfaceMember xlink:href="#poly-afc644d9-5dbf-443e-a842-4a9c204bd2fe"/>
							<gml:surfaceMember xlink:href="#poly-3b2ed8be-47a6-4ceb-97de-779fff57db4b"/>
							<gml:surfaceMember xlink:href="#poly-6b6877ce-98bc-468f-b49f-3bf4586c3546"/>
							<gml:surfaceMember xlink:href="#poly-e2566685-0850-432a-8e30-e1dada9c80a4"/>
							<gml:surfaceMember xlink:href="#poly-8cc730b5-4dda-4ca5-a0f8-41e117f279a9"/>
							<gml:surfaceMember xlink:href="#poly-9649c6ee-9fd8-42d5-ba54-14f95a4080d7"/>
							<gml:surfaceMember xlink:href="#poly-e412e6c3-000e-4f1e-b602-05fa894fd370"/>
							<gml:surfaceMember xlink:href="#poly-ce75e40f-89b2-4f72-bec9-4c15c3ed75fc"/>
							<gml:surfaceMember xlink:href="#poly-e28713b5-7712-4dd9-a045-ea43f0d590ea"/>
							<gml:surfaceMember xlink:href="#poly-58244e1b-2b44-4ac3-967e-cc5001b992bc"/>
							<gml:surfaceMember xlink:href="#poly-704fcc5f-a588-4347-bd4b-42e651dfd826"/>
							<gml:surfaceMember xlink:href="#poly-1d9e3fd8-1062-4778-93b0-b1fd9eef2887"/>
							<gml:surfaceMember xlink:href="#poly-7462fb36-4485-4057-a32a-96da5a88347b"/>
							<gml:surfaceMember xlink:href="#poly-34a5f711-d303-410d-9309-7f153b0622b4"/>
							<gml:surfaceMember xlink:href="#poly-c45b6722-e66c-408e-b1c9-ed1c3e62280f"/>
							<gml:surfaceMember xlink:href="#poly-55bedeb3-60da-4a88-84d2-03e47a632bad"/>
							<gml:surfaceMember xlink:href="#poly-5935b47a-cfd5-4ba9-a4e0-7ab72b56a3b3"/>
							<gml:surfaceMember xlink:href="#poly-682c358b-3ee1-4ed2-ba5d-40be6cf646d1"/>
							<gml:surfaceMember xlink:href="#poly-de83ea10-c3ee-4f0b-b6bb-f01bf1594ac8"/>
							<gml:surfaceMember xlink:href="#poly-3cd40c8f-e900-42a1-aada-34399e2b0a7a"/>
							<gml:surfaceMember xlink:href="#poly-71448de6-8b0a-4228-bc25-af7589fd3038"/>
							<gml:surfaceMember xlink:href="#poly-0c77af26-e566-4c8f-a767-3852183cc344"/>
							<gml:surfaceMember xlink:href="#poly-31c6846c-9644-4358-bff9-e0932adfc8c5"/>
							<gml:surfaceMember xlink:href="#poly-461158a0-0b42-4937-990c-fbce63e7463d"/>
							<gml:surfaceMember xlink:href="#poly-e19212ed-dfbb-473b-bbff-e4f388787cb5"/>
							<gml:surfaceMember xlink:href="#poly-4683faab-3e98-4c3a-ac38-3bb041e15d12"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_6667a4b9-3010-446f-a1ff-34b1549059c3_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f19aafc-3cb9-49d4-a122-2b0a3048b2a9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66854001158962 139.74863971380424 5.67 35.66855602424025 139.7485945187143 5.67 35.66857033388376 139.7486014073484 5.67 35.66856254508541 139.74862570575468 5.67 35.66855629546219 139.74864692069417 5.67 35.66854001158962 139.74863971380424 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-577a6ef3-d817-4842-921e-db2a4db66455">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-577a6ef3-d817-4842-921e-db2a4db66455_0">
											<gml:posList>35.66857033388376 139.7486014073484 39.503 35.66857033388376 139.7486014073484 5.67 35.66855602424025 139.7485945187143 5.67 35.66855602424025 139.7485945187143 39.503 35.66857033388376 139.7486014073484 39.503</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a907417-b66e-4dd1-85ba-2697a9221d34">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7a907417-b66e-4dd1-85ba-2697a9221d34_0">
											<gml:posList>35.66856254508541 139.74862570575468 39.503 35.66856254508541 139.74862570575468 5.67 35.66857033388376 139.7486014073484 5.67 35.66857033388376 139.7486014073484 39.503 35.66856254508541 139.74862570575468 39.503</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-200e6834-eda2-4f62-be6e-01c23976195c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-200e6834-eda2-4f62-be6e-01c23976195c_0">
											<gml:posList>35.66855602424025 139.7485945187143 39.503 35.66855602424025 139.7485945187143 5.67 35.66854001158962 139.74863971380424 5.67 35.66854001158962 139.74863971380424 39.503 35.66855602424025 139.7485945187143 39.503</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d17b8214-1d11-4589-bf5b-17854077fbcb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d17b8214-1d11-4589-bf5b-17854077fbcb_0">
											<gml:posList>35.66854001158962 139.74863971380424 39.503 35.66855629546219 139.74864692069417 39.503 35.66856254508541 139.74862570575468 39.503 35.66857033388376 139.7486014073484 39.503 35.66855602424025 139.7485945187143 39.503 35.66854001158962 139.74863971380424 39.503</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35edeec4-fd5f-4dde-ac79-5580e07a923a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-35edeec4-fd5f-4dde-ac79-5580e07a923a_0">
											<gml:posList>35.66855629546219 139.74864692069417 39.503 35.66855629546219 139.74864692069417 5.67 35.66856254508541 139.74862570575468 5.67 35.66856254508541 139.74862570575468 39.503 35.66855629546219 139.74864692069417 39.503</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-decc7c2e-b6fd-4e76-b70c-d0eb5aea3393">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-decc7c2e-b6fd-4e76-b70c-d0eb5aea3393_0">
											<gml:posList>35.66854001158962 139.74863971380424 39.503 35.66854001158962 139.74863971380424 5.67 35.66855629546219 139.74864692069417 5.67 35.66855629546219 139.74864692069417 39.503 35.66854001158962 139.74863971380424 39.503</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_6667a4b9-3010-446f-a1ff-34b1549059c3_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53db3381-b00b-4f35-b409-4bcd2281edae">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668658789441544 139.74854275890596 39.108 35.668669239859234 139.74854772961203 39.108 35.668666181989195 139.74855738707052 39.108 35.66865573157969 139.74855242740938 39.108 35.668658789441544 139.74854275890596 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-47bfa785-060a-499b-b8b5-9c97d2b4c10d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66868199751799 139.74856511361338 39.108 35.6686716372772 139.74856019803903 39.108 35.66867473111682 139.74855041903572 39.108 35.668685091365774 139.748555345655 39.108 35.66868199751799 139.74856511361338 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9b808cb9-81c4-4ecf-99e2-c3127d9c2173">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66869473819119 139.7485711754595 39.108 35.66868327790271 139.74856573083724 39.108 35.66868637174277 139.7485559518327 39.108 35.66869783203169 139.74856139645374 39.108 35.66869473819119 139.7485711754595 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3cf02d1a-0662-4896-9dcc-612272df151a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668650380302054 139.74856932243503 39.108 35.66865322232574 139.7485603500605 39.108 35.6686636727427 139.74856532076853 39.108 35.66866083071864 139.74857429314406 39.108 35.668650380302054 139.74856932243503 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c354fca2-45eb-4e3a-a5b4-0f30eb4510c5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668669370856854 139.74856735825912 39.108 35.668679731097356 139.74857227383424 39.108 35.66867670019657 139.74858183185032 39.108 35.66866633995645 139.74857691627412 39.108 35.668669370856854 139.74856735825912 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0722b611-aa7e-4d10-956f-e6030b95ca01">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6686777197662 139.748583277802 39.108 35.66868075064377 139.74857368664783 39.108 35.66869221995341 139.7485791423075 39.108 35.6686891800539 139.74858872242635 39.108 35.6686777197662 139.748583277802 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33f030a0-6255-4d3c-a275-1902582be640">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66866228919806 139.74858461963439 39.108 35.66867134201986 139.74858892906173 39.108 35.668668050310394 139.74859932684961 39.108 35.668658997496735 139.7485950284673 39.108 35.66866228919806 139.74858461963439 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-473a9adc-c853-4977-883a-e4bfbd1ab4e3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668672107669124 139.74860100155774 39.108 35.6686752285066 139.74859115625125 39.108 35.66868698635577 139.74859675520648 39.108 35.668683874531574 139.74860660050467 39.108 35.668672107669124 139.74860100155774 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f546f607-9b6b-4775-b856-0aedfed2302f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66866221338843 139.7486177909232 39.108 35.66865315155392 139.74861348150262 39.108 35.66865679403827 139.7486020008363 39.108 35.66866584685946 139.74860631026533 39.108 35.66866221338843 139.7486177909232 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d567a39-dfac-4197-af8d-09cd3bf35ad5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66866584685946 139.74860631026533 39.108 35.66866584685946 139.74860631026533 41.752 35.66866221338843 139.7486177909232 41.752 35.66866221338843 139.7486177909232 39.108 35.66866584685946 139.74860631026533 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e1d15f0-bbee-4a4f-ad69-794d5e995c6c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66866971533396 139.74860855956663 39.108 35.66866619879251 139.74861968662864 39.108 35.66866619879251 139.74861968662864 41.752 35.66866971533396 139.74860855956663 41.752 35.66866971533396 139.74860855956663 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb3759fb-1e1e-4b05-aaf5-984ba4947b58">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66866619879251 139.74861968662864 39.108 35.66866971533396 139.74860855956663 39.108 35.6686814821883 139.74861414746852 39.108 35.66867795663261 139.74862527454144 39.108 35.66866619879251 139.74861968662864 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-79a0f59b-4fba-4899-af67-b39578943f15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66858425829919 139.7486116543799 45.883 35.66860307635954 139.74862074745934 45.883 35.66859891210277 139.7486336867422 45.883 35.66858009403562 139.7486245826142 45.883 35.66858425829919 139.7486116543799 45.883</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f77a7f3-4551-43dd-909b-7b885545a008">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f77a7f3-4551-43dd-909b-7b885545a008_0">
											<gml:posList>35.668685091365774 139.748555345655 39.108 35.668685091365774 139.748555345655 41.604 35.66868199751799 139.74856511361338 41.604 35.66868199751799 139.74856511361338 39.108 35.668685091365774 139.748555345655 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58813c40-503b-48be-bcb5-ccd064dbfbe6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-58813c40-503b-48be-bcb5-ccd064dbfbe6_0">
											<gml:posList>35.6686752285066 139.74859115625125 39.108 35.668672107669124 139.74860100155774 39.108 35.668672107669124 139.74860100155774 41.752 35.6686752285066 139.74859115625125 41.752 35.6686752285066 139.74859115625125 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-79adfc6c-6484-4f07-8694-5440416611af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-79adfc6c-6484-4f07-8694-5440416611af_0">
											<gml:posList>35.668669239859234 139.74854772961203 39.108 35.668658789441544 139.74854275890596 39.108 35.668658789441544 139.74854275890596 41.678 35.668669239859234 139.74854772961203 41.678 35.668669239859234 139.74854772961203 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0fbaf0fa-f95a-4e7e-8f4c-d67c05e95539">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0fbaf0fa-f95a-4e7e-8f4c-d67c05e95539_0">
											<gml:posList>35.668658789441544 139.74854275890596 39.108 35.66865573157969 139.74855242740938 39.108 35.66865573157969 139.74855242740938 41.678 35.668658789441544 139.74854275890596 41.678 35.668658789441544 139.74854275890596 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-17eea3ed-18ad-4599-a241-e920af06f889">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-17eea3ed-18ad-4599-a241-e920af06f889_0">
											<gml:posList>35.668666181989195 139.74855738707052 41.678 35.668669239859234 139.74854772961203 41.678 35.668658789441544 139.74854275890596 41.678 35.66865573157969 139.74855242740938 41.678 35.668666181989195 139.74855738707052 41.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70fb5e4c-7557-4621-8844-fc3f70173c7b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-70fb5e4c-7557-4621-8844-fc3f70173c7b_0">
											<gml:posList>35.668666181989195 139.74855738707052 39.108 35.668669239859234 139.74854772961203 39.108 35.668669239859234 139.74854772961203 41.678 35.668666181989195 139.74855738707052 41.678 35.668666181989195 139.74855738707052 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73b20973-2e27-4b27-923e-802b9f1ad0c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73b20973-2e27-4b27-923e-802b9f1ad0c3_0">
											<gml:posList>35.668685091365774 139.748555345655 39.108 35.66867473111682 139.74855041903572 39.108 35.66867473111682 139.74855041903572 41.604 35.668685091365774 139.748555345655 41.604 35.668685091365774 139.748555345655 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48078391-63af-4cab-a2ad-955c3e37e516">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-48078391-63af-4cab-a2ad-955c3e37e516_0">
											<gml:posList>35.66865573157969 139.74855242740938 39.108 35.668666181989195 139.74855738707052 39.108 35.668666181989195 139.74855738707052 41.678 35.66865573157969 139.74855242740938 41.678 35.66865573157969 139.74855242740938 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4bea1cbf-31b7-48b8-8387-8fff95a6db17">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4bea1cbf-31b7-48b8-8387-8fff95a6db17_0">
											<gml:posList>35.6686716372772 139.74856019803903 39.108 35.6686716372772 139.74856019803903 41.604 35.66867473111682 139.74855041903572 41.604 35.66867473111682 139.74855041903572 39.108 35.6686716372772 139.74856019803903 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61d54aa3-b5d4-47b4-9a11-42f1d2ffffbd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-61d54aa3-b5d4-47b4-9a11-42f1d2ffffbd_0">
											<gml:posList>35.66867473111682 139.74855041903572 41.604 35.6686716372772 139.74856019803903 41.604 35.66868199751799 139.74856511361338 41.604 35.668685091365774 139.748555345655 41.604 35.66867473111682 139.74855041903572 41.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14b666cd-3eba-460b-8575-0cf7d939f413">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-14b666cd-3eba-460b-8575-0cf7d939f413_0">
											<gml:posList>35.66868637174277 139.7485559518327 39.108 35.66868637174277 139.7485559518327 41.678 35.66869783203169 139.74856139645374 41.678 35.66869783203169 139.74856139645374 39.108 35.66868637174277 139.7485559518327 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c585f09e-3237-4e57-bf11-5960dfa604b5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c585f09e-3237-4e57-bf11-5960dfa604b5_0">
											<gml:posList>35.66868637174277 139.7485559518327 39.108 35.66868327790271 139.74856573083724 39.108 35.66868327790271 139.74856573083724 41.678 35.66868637174277 139.7485559518327 41.678 35.66868637174277 139.7485559518327 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-607c8f0e-733e-4d45-905a-e498e454b2f9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-607c8f0e-733e-4d45-905a-e498e454b2f9_0">
											<gml:posList>35.6686716372772 139.74856019803903 39.108 35.66868199751799 139.74856511361338 39.108 35.66868199751799 139.74856511361338 41.604 35.6686716372772 139.74856019803903 41.604 35.6686716372772 139.74856019803903 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a3bc7fb-5faa-40b3-8817-fe131c3700e6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7a3bc7fb-5faa-40b3-8817-fe131c3700e6_0">
											<gml:posList>35.6686636727427 139.74856532076853 39.108 35.66865322232574 139.7485603500605 39.108 35.66865322232574 139.7485603500605 41.678 35.6686636727427 139.74856532076853 41.678 35.6686636727427 139.74856532076853 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b166f24c-9467-4832-a423-3bc600a907f3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b166f24c-9467-4832-a423-3bc600a907f3_0">
											<gml:posList>35.66869473819119 139.7485711754595 41.678 35.66869783203169 139.74856139645374 41.678 35.66868637174277 139.7485559518327 41.678 35.66868327790271 139.74856573083724 41.678 35.66869473819119 139.7485711754595 41.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8681221-36a7-444d-b072-387722a86288">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8681221-36a7-444d-b072-387722a86288_0">
											<gml:posList>35.66865322232574 139.7485603500605 39.108 35.668650380302054 139.74856932243503 39.108 35.668650380302054 139.74856932243503 41.678 35.66865322232574 139.7485603500605 41.678 35.66865322232574 139.7485603500605 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3141188a-96b4-4a19-811f-576012038558">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3141188a-96b4-4a19-811f-576012038558_0">
											<gml:posList>35.66869783203169 139.74856139645374 39.108 35.66869783203169 139.74856139645374 41.678 35.66869473819119 139.7485711754595 41.678 35.66869473819119 139.7485711754595 39.108 35.66869783203169 139.74856139645374 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e993f60b-e7b6-4e98-9ed7-bdd7d61c0f3e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e993f60b-e7b6-4e98-9ed7-bdd7d61c0f3e_0">
											<gml:posList>35.6686636727427 139.74856532076853 41.678 35.66865322232574 139.7485603500605 41.678 35.668650380302054 139.74856932243503 41.678 35.66866083071864 139.74857429314406 41.678 35.6686636727427 139.74856532076853 41.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-268d0c62-2a80-4fef-9d88-3314a2bbf571">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-268d0c62-2a80-4fef-9d88-3314a2bbf571_0">
											<gml:posList>35.66868327790271 139.74856573083724 39.108 35.66869473819119 139.7485711754595 39.108 35.66869473819119 139.7485711754595 41.678 35.66868327790271 139.74856573083724 41.678 35.66868327790271 139.74856573083724 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e985ff28-0515-4d2b-9883-5cf19c598c6c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e985ff28-0515-4d2b-9883-5cf19c598c6c_0">
											<gml:posList>35.6686636727427 139.74856532076853 41.678 35.66866083071864 139.74857429314406 41.678 35.66866083071864 139.74857429314406 39.108 35.6686636727427 139.74856532076853 39.108 35.6686636727427 139.74856532076853 41.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e8e057a-ab33-41a9-9c54-aa4bf3d749dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4e8e057a-ab33-41a9-9c54-aa4bf3d749dd_0">
											<gml:posList>35.668669370856854 139.74856735825912 39.108 35.668669370856854 139.74856735825912 41.678 35.668679731097356 139.74857227383424 41.678 35.668679731097356 139.74857227383424 39.108 35.668669370856854 139.74856735825912 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db3e5198-8ead-4725-8e32-8703d9aa8f5b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-db3e5198-8ead-4725-8e32-8703d9aa8f5b_0">
											<gml:posList>35.668650380302054 139.74856932243503 39.108 35.66866083071864 139.74857429314406 39.108 35.66866083071864 139.74857429314406 41.678 35.668650380302054 139.74856932243503 41.678 35.668650380302054 139.74856932243503 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-338128c4-55e6-4807-9c4d-5ea717818b8f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-338128c4-55e6-4807-9c4d-5ea717818b8f_0">
											<gml:posList>35.66866633995645 139.74857691627412 39.108 35.66866633995645 139.74857691627412 41.678 35.668669370856854 139.74856735825912 41.678 35.668669370856854 139.74856735825912 39.108 35.66866633995645 139.74857691627412 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3319ce23-a6e4-42c9-8a62-e613af2bf351">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3319ce23-a6e4-42c9-8a62-e613af2bf351_0">
											<gml:posList>35.66867670019657 139.74858183185032 41.678 35.668679731097356 139.74857227383424 41.678 35.668669370856854 139.74856735825912 41.678 35.66866633995645 139.74857691627412 41.678 35.66867670019657 139.74858183185032 41.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46a331f5-d68a-4d99-9b27-010102d3b661">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46a331f5-d68a-4d99-9b27-010102d3b661_0">
											<gml:posList>35.66868075064377 139.74857368664783 41.752 35.66869221995341 139.7485791423075 41.752 35.66869221995341 139.7485791423075 39.108 35.66868075064377 139.74857368664783 39.108 35.66868075064377 139.74857368664783 41.752</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0ded439-bfca-4766-96db-2a76b667e035">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d0ded439-bfca-4766-96db-2a76b667e035_0">
											<gml:posList>35.668679731097356 139.74857227383424 39.108 35.668679731097356 139.74857227383424 41.678 35.66867670019657 139.74858183185032 41.678 35.66867670019657 139.74858183185032 39.108 35.668679731097356 139.74857227383424 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01be4a28-23d4-4390-a118-7b207d2c351d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01be4a28-23d4-4390-a118-7b207d2c351d_0">
											<gml:posList>35.66868075064377 139.74857368664783 39.108 35.6686777197662 139.748583277802 39.108 35.6686777197662 139.748583277802 41.752 35.66868075064377 139.74857368664783 41.752 35.66868075064377 139.74857368664783 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4626eb45-e508-4f6e-86f8-8c3af39f93cd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4626eb45-e508-4f6e-86f8-8c3af39f93cd_0">
											<gml:posList>35.66867670019657 139.74858183185032 39.108 35.66867670019657 139.74858183185032 41.678 35.66866633995645 139.74857691627412 41.678 35.66866633995645 139.74857691627412 39.108 35.66867670019657 139.74858183185032 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c5e521f-c7a1-4007-b1cb-b34d2a89a002">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6c5e521f-c7a1-4007-b1cb-b34d2a89a002_0">
											<gml:posList>35.6686777197662 139.748583277802 41.752 35.6686891800539 139.74858872242635 41.752 35.66869221995341 139.7485791423075 41.752 35.66868075064377 139.74857368664783 41.752 35.6686777197662 139.748583277802 41.752</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7eb0f1c4-4c0e-4003-8ad7-901fe9b25826">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7eb0f1c4-4c0e-4003-8ad7-901fe9b25826_0">
											<gml:posList>35.66869221995341 139.7485791423075 39.108 35.66869221995341 139.7485791423075 41.752 35.6686891800539 139.74858872242635 41.752 35.6686891800539 139.74858872242635 39.108 35.66869221995341 139.7485791423075 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a343a535-ffae-4391-8d7a-f29b40304ceb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a343a535-ffae-4391-8d7a-f29b40304ceb_0">
											<gml:posList>35.6686777197662 139.748583277802 39.108 35.6686891800539 139.74858872242635 39.108 35.6686891800539 139.74858872242635 41.752 35.6686777197662 139.748583277802 41.752 35.6686777197662 139.748583277802 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-05148b24-183d-41b9-b8d4-95ed79150915">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-05148b24-183d-41b9-b8d4-95ed79150915_0">
											<gml:posList>35.66866228919806 139.74858461963439 39.108 35.66866228919806 139.74858461963439 41.752 35.66867134201986 139.74858892906173 41.752 35.66867134201986 139.74858892906173 39.108 35.66866228919806 139.74858461963439 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1f8c435-0733-49c9-9702-48f06ba66027">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d1f8c435-0733-49c9-9702-48f06ba66027_0">
											<gml:posList>35.66866228919806 139.74858461963439 39.108 35.668658997496735 139.7485950284673 39.108 35.668658997496735 139.7485950284673 41.752 35.66866228919806 139.74858461963439 41.752 35.66866228919806 139.74858461963439 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c1016a2-2fdb-4ac6-a197-f20ec1446e06">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2c1016a2-2fdb-4ac6-a197-f20ec1446e06_0">
											<gml:posList>35.66866228919806 139.74858461963439 41.752 35.668658997496735 139.7485950284673 41.752 35.668668050310394 139.74859932684961 41.752 35.66867134201986 139.74858892906173 41.752 35.66866228919806 139.74858461963439 41.752</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-49873bf3-9f33-4309-bc18-5fb2ff11bba8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-49873bf3-9f33-4309-bc18-5fb2ff11bba8_0">
											<gml:posList>35.6686752285066 139.74859115625125 39.108 35.6686752285066 139.74859115625125 41.752 35.66868698635577 139.74859675520648 41.752 35.66868698635577 139.74859675520648 39.108 35.6686752285066 139.74859115625125 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-32232eaa-51ed-4dd0-b648-d1c123a6d90c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-32232eaa-51ed-4dd0-b648-d1c123a6d90c_0">
											<gml:posList>35.668668050310394 139.74859932684961 39.108 35.66867134201986 139.74858892906173 39.108 35.66867134201986 139.74858892906173 41.752 35.668668050310394 139.74859932684961 41.752 35.668668050310394 139.74859932684961 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c813182-bb7b-4f3a-9111-44b5bf67f9ba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6c813182-bb7b-4f3a-9111-44b5bf67f9ba_0">
											<gml:posList>35.668668050310394 139.74859932684961 39.108 35.668668050310394 139.74859932684961 41.752 35.668658997496735 139.7485950284673 41.752 35.668658997496735 139.7485950284673 39.108 35.668668050310394 139.74859932684961 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec30472d-8d77-4615-b54b-7330478d3bfc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ec30472d-8d77-4615-b54b-7330478d3bfc_0">
											<gml:posList>35.668672107669124 139.74860100155774 41.752 35.668683874531574 139.74860660050467 41.752 35.66868698635577 139.74859675520648 41.752 35.6686752285066 139.74859115625125 41.752 35.668672107669124 139.74860100155774 41.752</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f92fb84-b096-421a-bf41-ad826896d099">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f92fb84-b096-421a-bf41-ad826896d099_0">
											<gml:posList>35.668683874531574 139.74860660050467 39.108 35.66868698635577 139.74859675520648 39.108 35.66868698635577 139.74859675520648 41.752 35.668683874531574 139.74860660050467 41.752 35.668683874531574 139.74860660050467 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b5d9d526-906f-445a-810c-c04d7d5d8bde">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b5d9d526-906f-445a-810c-c04d7d5d8bde_0">
											<gml:posList>35.668683874531574 139.74860660050467 39.108 35.668683874531574 139.74860660050467 41.752 35.668672107669124 139.74860100155774 41.752 35.668672107669124 139.74860100155774 39.108 35.668683874531574 139.74860660050467 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d066a64c-6758-4f14-8378-0c449f09826e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d066a64c-6758-4f14-8378-0c449f09826e_0">
											<gml:posList>35.66866584685946 139.74860631026533 39.108 35.66865679403827 139.7486020008363 39.108 35.66865679403827 139.7486020008363 41.752 35.66866584685946 139.74860631026533 41.752 35.66866584685946 139.74860631026533 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c6789059-4ab1-4d0f-930b-0ff81c5dff80">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c6789059-4ab1-4d0f-930b-0ff81c5dff80_0">
											<gml:posList>35.66865679403827 139.7486020008363 39.108 35.66865315155392 139.74861348150262 39.108 35.66865315155392 139.74861348150262 41.752 35.66865679403827 139.7486020008363 41.752 35.66865679403827 139.7486020008363 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-436a1def-d982-460a-b199-b8dd9a350086">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-436a1def-d982-460a-b199-b8dd9a350086_0">
											<gml:posList>35.66865679403827 139.7486020008363 41.752 35.66865315155392 139.74861348150262 41.752 35.66866221338843 139.7486177909232 41.752 35.66866584685946 139.74860631026533 41.752 35.66865679403827 139.7486020008363 41.752</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44262aa9-157b-478b-8e1a-e7d181eeadb8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-44262aa9-157b-478b-8e1a-e7d181eeadb8_0">
											<gml:posList>35.66866971533396 139.74860855956663 39.108 35.66866971533396 139.74860855956663 41.752 35.6686814821883 139.74861414746852 41.752 35.6686814821883 139.74861414746852 39.108 35.66866971533396 139.74860855956663 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b3d52d9-d956-4cc6-8678-306c7721ad80">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b3d52d9-d956-4cc6-8678-306c7721ad80_0">
											<gml:posList>35.66865315155392 139.74861348150262 39.108 35.66866221338843 139.7486177909232 39.108 35.66866221338843 139.7486177909232 41.752 35.66865315155392 139.74861348150262 41.752 35.66865315155392 139.74861348150262 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f644b040-3ce1-416f-9baf-b97d8ab4743c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f644b040-3ce1-416f-9baf-b97d8ab4743c_0">
											<gml:posList>35.66860307635954 139.74862074745934 45.883 35.66858425829919 139.7486116543799 45.883 35.66858425829919 139.7486116543799 46.277 35.66860307635954 139.74862074745934 46.277 35.66860307635954 139.74862074745934 45.883</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd144215-3646-4bfd-9e2d-57700e834598">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cd144215-3646-4bfd-9e2d-57700e834598_0">
											<gml:posList>35.6686814821883 139.74861414746852 41.752 35.66866971533396 139.74860855956663 41.752 35.66866619879251 139.74861968662864 41.752 35.66867795663261 139.74862527454144 41.752 35.6686814821883 139.74861414746852 41.752</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75087c6f-14ac-4bd6-acf6-113efa2ed6ef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-75087c6f-14ac-4bd6-acf6-113efa2ed6ef_0">
											<gml:posList>35.66858009403562 139.7486245826142 45.883 35.66858009403562 139.7486245826142 46.277 35.66858425829919 139.7486116543799 46.277 35.66858425829919 139.7486116543799 45.883 35.66858009403562 139.7486245826142 45.883</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19f24e3b-cb57-4b04-8d0b-118dd9e5a7a7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19f24e3b-cb57-4b04-8d0b-118dd9e5a7a7_0">
											<gml:posList>35.66867795663261 139.74862527454144 39.108 35.6686814821883 139.74861414746852 39.108 35.6686814821883 139.74861414746852 41.752 35.66867795663261 139.74862527454144 41.752 35.66867795663261 139.74862527454144 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-889bab6a-97b6-43fa-adb1-8bab3e56b72a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-889bab6a-97b6-43fa-adb1-8bab3e56b72a_0">
											<gml:posList>35.66866619879251 139.74861968662864 39.108 35.66867795663261 139.74862527454144 39.108 35.66867795663261 139.74862527454144 41.752 35.66866619879251 139.74861968662864 41.752 35.66866619879251 139.74861968662864 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9371e745-d738-4b1c-ac87-5b024d1de035">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9371e745-d738-4b1c-ac87-5b024d1de035_0">
											<gml:posList>35.66859891210277 139.7486336867422 46.277 35.66860307635954 139.74862074745934 46.277 35.66858425829919 139.7486116543799 46.277 35.66858009403562 139.7486245826142 46.277 35.66859891210277 139.7486336867422 46.277</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac2b9558-27d1-4594-96af-285c8152e71a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ac2b9558-27d1-4594-96af-285c8152e71a_0">
											<gml:posList>35.66859891210277 139.7486336867422 45.883 35.66860307635954 139.74862074745934 45.883 35.66860307635954 139.74862074745934 46.277 35.66859891210277 139.7486336867422 46.277 35.66859891210277 139.7486336867422 45.883</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-85e43597-e89c-4b47-8b14-8f805bef6199">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-85e43597-e89c-4b47-8b14-8f805bef6199_0">
											<gml:posList>35.66858009403562 139.7486245826142 45.883 35.66859891210277 139.7486336867422 45.883 35.66859891210277 139.7486336867422 46.277 35.66858009403562 139.7486245826142 46.277 35.66858009403562 139.7486245826142 45.883</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_6667a4b9-3010-446f-a1ff-34b1549059c3_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-92f4e7d1-f84b-472a-a026-0e8a773cbd03">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66860393507715 139.74853453240098 39.108 35.66862203178059 139.74854325066272 39.108 35.668613055786906 139.74857125076096 39.108 35.66859495908545 139.74856253249388 39.108 35.66860393507715 139.74853453240098 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d84ea78-872e-4178-94dc-79b97d85c38f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d84ea78-872e-4178-94dc-79b97d85c38f_0">
											<gml:posList>35.66859495908545 139.74856253249388 39.108 35.66859495908545 139.74856253249388 42.707 35.66860393507715 139.74853453240098 42.707 35.66860393507715 139.74853453240098 39.108 35.66859495908545 139.74856253249388 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4af61e5-e6fe-4c51-9200-5ef2713f1fb9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b4af61e5-e6fe-4c51-9200-5ef2713f1fb9_0">
											<gml:posList>35.668613055786906 139.74857125076096 42.707 35.66859495908545 139.74856253249388 42.707 35.66859495908545 139.74856253249388 39.108 35.668613055786906 139.74857125076096 39.108 35.668613055786906 139.74857125076096 42.707</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-addfc6e1-245b-4045-8bee-9c2a62db1dfd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-addfc6e1-245b-4045-8bee-9c2a62db1dfd_0">
											<gml:posList>35.668613055786906 139.74857125076096 42.707 35.66862203178059 139.74854325066272 42.707 35.66860393507715 139.74853453240098 42.707 35.66859495908545 139.74856253249388 42.707 35.668613055786906 139.74857125076096 42.707</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6dcb5ab3-89e8-4b5b-a501-041e5d10760f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6dcb5ab3-89e8-4b5b-a501-041e5d10760f_0">
											<gml:posList>35.66860393507715 139.74853453240098 42.707 35.66862203178059 139.74854325066272 42.707 35.66862203178059 139.74854325066272 39.108 35.66860393507715 139.74853453240098 39.108 35.66860393507715 139.74853453240098 42.707</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f4576ed-2ef4-489f-9826-b9cfd14bbf73">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9f4576ed-2ef4-489f-9826-b9cfd14bbf73_0">
											<gml:posList>35.66862203178059 139.74854325066272 39.108 35.66862203178059 139.74854325066272 42.707 35.668613055786906 139.74857125076096 42.707 35.668613055786906 139.74857125076096 39.108 35.66862203178059 139.74854325066272 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-998a4f92-81e1-4879-bb72-ab14ff13333d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-998a4f92-81e1-4879-bb72-ab14ff13333d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-998a4f92-81e1-4879-bb72-ab14ff13333d">
											<gml:posList>35.66858768723106 139.74848890745736 5.67 35.66873816406698 139.74855511280396 5.67 35.66873978131915 139.74856050155873 5.67 35.668744217494236 139.74857532064735 5.67 35.668712376038826 139.748670792009 5.67 35.66864628265847 139.74863849695254 5.67 35.668632078862146 139.74867958105577 5.67 35.668557527414066 139.74864275504757 5.67 35.66856254508541 139.74862570575468 5.67 35.66857033388376 139.7486014073484 5.67 35.66855602424025 139.7485945187143 5.67 35.668553499852436 139.7485937481615 5.67 35.66858768723106 139.74848890745736 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b408e767-80c9-4175-a23d-b951fdb10b7c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b408e767-80c9-4175-a23d-b951fdb10b7c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b408e767-80c9-4175-a23d-b951fdb10b7c">
											<gml:posList>35.66858974627561 139.7484944614234 39.6 35.66873537223791 139.74855856211832 39.6 35.66873816406698 139.74855511280396 39.6 35.66858768723106 139.74848890745736 39.6 35.66858974627561 139.7484944614234 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-36b448fb-4b62-4f8a-bdd4-3edf51e0baf4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36b448fb-4b62-4f8a-bdd4-3edf51e0baf4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36b448fb-4b62-4f8a-bdd4-3edf51e0baf4">
											<gml:posList>35.66858768723106 139.74848890745736 39.6 35.668553499852436 139.7485937481615 39.6 35.668558311169555 139.74859088216039 39.6 35.66858974627561 139.7484944614234 39.6 35.66858768723106 139.74848890745736 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dbb5c213-967d-461c-93e0-3968eb47dd0e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dbb5c213-967d-461c-93e0-3968eb47dd0e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dbb5c213-967d-461c-93e0-3968eb47dd0e">
											<gml:posList>35.668744217494236 139.74857532064735 39.6 35.66873816406698 139.74855511280396 39.6 35.66873537223791 139.74855856211832 39.6 35.66874036856278 139.7485752253016 39.6 35.668744217494236 139.74857532064735 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-139d7a8e-49bb-4896-b631-bf69ef469957">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-139d7a8e-49bb-4896-b631-bf69ef469957">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-139d7a8e-49bb-4896-b631-bf69ef469957">
											<gml:posList>35.66858974627561 139.7484944614234 39.108 35.668558311169555 139.74859088216039 39.108 35.668571647012 139.7485973189367 39.108 35.6685718538769 139.74859667804944 39.108 35.66862108554587 139.7486203860062 39.108 35.668611776748776 139.74864941372653 39.108 35.668565367337855 139.74862706143242 39.108 35.668563470002354 139.74863354744463 39.108 35.66863225061734 139.74866746339112 39.108 35.668644349711755 139.7486327992474 39.108 35.66871039800949 139.7486650722539 39.108 35.66874036856278 139.7485752253016 39.108 35.66873537223791 139.74855856211832 39.108 35.66858974627561 139.7484944614234 39.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7f2418fc-540f-44a2-b58b-0a2c766ca42a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f2418fc-540f-44a2-b58b-0a2c766ca42a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f2418fc-540f-44a2-b58b-0a2c766ca42a">
											<gml:posList>35.668553499852436 139.7485937481615 39.6 35.66855602424025 139.7485945187143 39.6 35.668558311169555 139.74859088216039 39.6 35.668553499852436 139.7485937481615 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f74a38fb-6ed3-4912-a947-89cb41a77d25">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f74a38fb-6ed3-4912-a947-89cb41a77d25">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f74a38fb-6ed3-4912-a947-89cb41a77d25">
											<gml:posList>35.668558311169555 139.74859088216039 39.6 35.66855602424025 139.7485945187143 39.6 35.66857033388376 139.7486014073484 39.6 35.668571647012 139.7485973189367 39.6 35.668558311169555 139.74859088216039 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-74423f3b-6c28-4938-b0b8-bb49a2e36fa6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74423f3b-6c28-4938-b0b8-bb49a2e36fa6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74423f3b-6c28-4938-b0b8-bb49a2e36fa6">
											<gml:posList>35.66862108554587 139.7486203860062 46.567 35.6685718538769 139.74859667804944 46.567 35.66857340730052 139.74860102853623 46.567 35.66861754448761 139.7486222896623 46.567 35.66862108554587 139.7486203860062 46.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6c618980-92bc-4d6f-bfa1-a9e77bbfd7e9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c618980-92bc-4d6f-bfa1-a9e77bbfd7e9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c618980-92bc-4d6f-bfa1-a9e77bbfd7e9">
											<gml:posList>35.6685718538769 139.74859667804944 46.567 35.66856254508541 139.74862570575468 46.567 35.66856609515749 139.74862380209052 46.567 35.66857340730052 139.74860102853623 46.567 35.6685718538769 139.74859667804944 46.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a336033d-cd22-4209-a851-aa3dc9568f43">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a336033d-cd22-4209-a851-aa3dc9568f43">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a336033d-cd22-4209-a851-aa3dc9568f43">
											<gml:posList>35.668610232340626 139.74864506322717 45.883 35.66861754448761 139.7486222896623 45.883 35.66857340730052 139.74860102853623 45.883 35.66856609515749 139.74862380209052 45.883 35.668610232340626 139.74864506322717 45.883</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-aaf211ee-4472-4c7b-be93-ea16bd28d314">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aaf211ee-4472-4c7b-be93-ea16bd28d314">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aaf211ee-4472-4c7b-be93-ea16bd28d314">
											<gml:posList>35.66871039800949 139.7486650722539 39.6 35.668712376038826 139.748670792009 39.6 35.668744217494236 139.74857532064735 39.6 35.66874036856278 139.7485752253016 39.6 35.66871039800949 139.7486650722539 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6d4f0b72-809d-485b-b03e-9fe79f19eebe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d4f0b72-809d-485b-b03e-9fe79f19eebe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d4f0b72-809d-485b-b03e-9fe79f19eebe">
											<gml:posList>35.66856254508541 139.74862570575468 39.6 35.668559838410324 139.74863488784794 39.6 35.66856266970747 139.74863628770044 39.6 35.668563470002354 139.74863354744463 39.6 35.668565367337855 139.74862706143242 39.6 35.66856254508541 139.74862570575468 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7625db90-158f-4725-adb6-1836dd81898c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7625db90-158f-4725-adb6-1836dd81898c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7625db90-158f-4725-adb6-1836dd81898c">
											<gml:posList>35.668611776748776 139.74864941372653 46.567 35.66862108554587 139.7486203860062 46.567 35.66861754448761 139.7486222896623 46.567 35.668610232340626 139.74864506322717 46.567 35.668611776748776 139.74864941372653 46.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d1876708-ec9c-458b-8bb4-f8d69c434aef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1876708-ec9c-458b-8bb4-f8d69c434aef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1876708-ec9c-458b-8bb4-f8d69c434aef">
											<gml:posList>35.66856254508541 139.74862570575468 46.567 35.668611776748776 139.74864941372653 46.567 35.668610232340626 139.74864506322717 46.567 35.66856609515749 139.74862380209052 46.567 35.66856254508541 139.74862570575468 46.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6123ed98-2060-4799-b348-b85210d4124e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6123ed98-2060-4799-b348-b85210d4124e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6123ed98-2060-4799-b348-b85210d4124e">
											<gml:posList>35.66863225061734 139.74866746339112 39.6 35.668563470002354 139.74863354744463 39.6 35.66856266970747 139.74863628770044 39.6 35.66863129708056 139.74867019276473 39.6 35.66863225061734 139.74866746339112 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-29c47dc6-ff67-4424-9a11-ea99f60389e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-29c47dc6-ff67-4424-9a11-ea99f60389e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-29c47dc6-ff67-4424-9a11-ea99f60389e7">
											<gml:posList>35.66871039800949 139.7486650722539 39.6 35.668644349711755 139.7486327992474 39.6 35.66864628265847 139.74863849695254 39.6 35.668712376038826 139.748670792009 39.6 35.66871039800949 139.7486650722539 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5452d381-befd-4f66-8fe3-6f2d037cc77a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5452d381-befd-4f66-8fe3-6f2d037cc77a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5452d381-befd-4f66-8fe3-6f2d037cc77a">
											<gml:posList>35.668634633324615 139.74867184614504 39.6 35.66864628265847 139.74863849695254 39.6 35.668644349711755 139.7486327992474 39.6 35.66863225061734 139.74866746339112 39.6 35.66863129708056 139.74867019276473 39.6 35.668634633324615 139.74867184614504 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9aefc1d7-d08f-4639-b7d0-4b9923439cc3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9aefc1d7-d08f-4639-b7d0-4b9923439cc3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9aefc1d7-d08f-4639-b7d0-4b9923439cc3">
											<gml:posList>35.668634633324615 139.74867184614504 39.6 35.66863129708056 139.74867019276473 39.6 35.66856266970747 139.74863628770044 39.6 35.668559838410324 139.74863488784794 39.6 35.668557527414066 139.74864275504757 36.366 35.668632078862146 139.74867958105577 36.366 35.668634633324615 139.74867184614504 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-49bcb2c5-a944-4c62-818a-30810ce8c63f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-49bcb2c5-a944-4c62-818a-30810ce8c63f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-49bcb2c5-a944-4c62-818a-30810ce8c63f">
											<gml:posList>35.66861754448761 139.7486222896623 46.567 35.66857340730052 139.74860102853623 46.567 35.66857340730052 139.74860102853623 45.883 35.66861754448761 139.7486222896623 45.883 35.66861754448761 139.7486222896623 46.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-414ef87b-6314-4b42-b1ab-46eef4e23fa4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-414ef87b-6314-4b42-b1ab-46eef4e23fa4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-414ef87b-6314-4b42-b1ab-46eef4e23fa4">
											<gml:posList>35.66856609515749 139.74862380209052 46.567 35.668610232340626 139.74864506322717 46.567 35.668610232340626 139.74864506322717 45.883 35.66856609515749 139.74862380209052 45.883 35.66856609515749 139.74862380209052 46.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0fb3e391-271c-45c5-910a-748f49f351d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0fb3e391-271c-45c5-910a-748f49f351d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0fb3e391-271c-45c5-910a-748f49f351d4">
											<gml:posList>35.66873816406698 139.74855511280396 5.67 35.66858768723106 139.74848890745736 5.67 35.66858768723106 139.74848890745736 36.366 35.66873816406698 139.74855511280396 36.366 35.66873816406698 139.74855511280396 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e04d5841-acfe-40eb-99b7-74073d06744a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e04d5841-acfe-40eb-99b7-74073d06744a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e04d5841-acfe-40eb-99b7-74073d06744a">
											<gml:posList>35.66873816406698 139.74855511280396 36.366 35.66858768723106 139.74848890745736 36.366 35.66858768723106 139.74848890745736 39.6 35.66873816406698 139.74855511280396 39.6 35.66873816406698 139.74855511280396 36.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8ff4cdea-28f4-40a9-ba8e-94416e216e85">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ff4cdea-28f4-40a9-ba8e-94416e216e85">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ff4cdea-28f4-40a9-ba8e-94416e216e85">
											<gml:posList>35.66873537223791 139.74855856211832 39.6 35.66858974627561 139.7484944614234 39.6 35.66858974627561 139.7484944614234 39.108 35.66873537223791 139.74855856211832 39.108 35.66873537223791 139.74855856211832 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fe917174-a733-46cc-879b-c4de17a9b7e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe917174-a733-46cc-879b-c4de17a9b7e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe917174-a733-46cc-879b-c4de17a9b7e6">
											<gml:posList>35.66858768723106 139.74848890745736 5.67 35.668553499852436 139.7485937481615 5.67 35.668553499852436 139.7485937481615 36.366 35.66858768723106 139.74848890745736 36.366 35.66858768723106 139.74848890745736 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e8194e78-a4d4-4aec-9fcb-feea73697928">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8194e78-a4d4-4aec-9fcb-feea73697928">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8194e78-a4d4-4aec-9fcb-feea73697928">
											<gml:posList>35.66858768723106 139.74848890745736 39.6 35.66858768723106 139.74848890745736 36.366 35.668553499852436 139.7485937481615 36.366 35.668553499852436 139.7485937481615 39.6 35.66858768723106 139.74848890745736 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b6c0bd66-b451-4ace-bee3-348b4ac51d02">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6c0bd66-b451-4ace-bee3-348b4ac51d02">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6c0bd66-b451-4ace-bee3-348b4ac51d02">
											<gml:posList>35.66858974627561 139.7484944614234 39.6 35.668558311169555 139.74859088216039 39.6 35.668558311169555 139.74859088216039 39.108 35.66858974627561 139.7484944614234 39.108 35.66858974627561 139.7484944614234 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d7cf0f4d-c3b7-4f11-8ce7-c7f01dcc1295">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7cf0f4d-c3b7-4f11-8ce7-c7f01dcc1295">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7cf0f4d-c3b7-4f11-8ce7-c7f01dcc1295">
											<gml:posList>35.668744217494236 139.74857532064735 36.366 35.668744217494236 139.74857532064735 5.67 35.66873978131915 139.74856050155873 5.67 35.66873816406698 139.74855511280396 5.67 35.66873816406698 139.74855511280396 36.366 35.668744217494236 139.74857532064735 36.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-80efcb16-bc21-4f14-9ba4-6e2385a7763c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-80efcb16-bc21-4f14-9ba4-6e2385a7763c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-80efcb16-bc21-4f14-9ba4-6e2385a7763c">
											<gml:posList>35.668744217494236 139.74857532064735 36.366 35.66873816406698 139.74855511280396 36.366 35.66873816406698 139.74855511280396 39.6 35.668744217494236 139.74857532064735 39.6 35.668744217494236 139.74857532064735 36.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-08de1676-dabd-41ac-983f-74bf8513b2c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-08de1676-dabd-41ac-983f-74bf8513b2c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-08de1676-dabd-41ac-983f-74bf8513b2c1">
											<gml:posList>35.66874036856278 139.7485752253016 39.6 35.66873537223791 139.74855856211832 39.6 35.66873537223791 139.74855856211832 39.108 35.66874036856278 139.7485752253016 39.108 35.66874036856278 139.7485752253016 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a39faffe-4490-451d-8d97-91599dd5b943">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a39faffe-4490-451d-8d97-91599dd5b943">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a39faffe-4490-451d-8d97-91599dd5b943">
											<gml:posList>35.668558311169555 139.74859088216039 39.6 35.668571647012 139.7485973189367 39.6 35.668571647012 139.7485973189367 39.108 35.668558311169555 139.74859088216039 39.108 35.668558311169555 139.74859088216039 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cfcec912-0ebe-41b6-baa6-b112ab40b13f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cfcec912-0ebe-41b6-baa6-b112ab40b13f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cfcec912-0ebe-41b6-baa6-b112ab40b13f">
											<gml:posList>35.668553499852436 139.7485937481615 5.67 35.66855602424025 139.7485945187143 5.67 35.66855602424025 139.7485945187143 36.366 35.668553499852436 139.7485937481615 36.366 35.668553499852436 139.7485937481615 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b37cb56-cc43-4eb7-9606-7cd825f8289e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b37cb56-cc43-4eb7-9606-7cd825f8289e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b37cb56-cc43-4eb7-9606-7cd825f8289e">
											<gml:posList>35.668553499852436 139.7485937481615 39.6 35.668553499852436 139.7485937481615 36.366 35.66855602424025 139.7485945187143 36.366 35.66855602424025 139.7485945187143 39.6 35.668553499852436 139.7485937481615 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fddef19c-52cc-4b10-8e25-9e74249eebe9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fddef19c-52cc-4b10-8e25-9e74249eebe9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fddef19c-52cc-4b10-8e25-9e74249eebe9">
											<gml:posList>35.668571647012 139.7485973189367 39.6 35.6685718538769 139.74859667804944 39.6 35.6685718538769 139.74859667804944 39.108 35.668571647012 139.7485973189367 39.108 35.668571647012 139.7485973189367 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-afc644d9-5dbf-443e-a842-4a9c204bd2fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-afc644d9-5dbf-443e-a842-4a9c204bd2fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-afc644d9-5dbf-443e-a842-4a9c204bd2fe">
											<gml:posList>35.66855602424025 139.7485945187143 5.67 35.66857033388376 139.7486014073484 5.67 35.66857033388376 139.7486014073484 36.366 35.66855602424025 139.7485945187143 36.366 35.66855602424025 139.7485945187143 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3b2ed8be-47a6-4ceb-97de-779fff57db4b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3b2ed8be-47a6-4ceb-97de-779fff57db4b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3b2ed8be-47a6-4ceb-97de-779fff57db4b">
											<gml:posList>35.66855602424025 139.7485945187143 39.6 35.66855602424025 139.7485945187143 36.366 35.66857033388376 139.7486014073484 36.366 35.66857033388376 139.7486014073484 39.6 35.66855602424025 139.7485945187143 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6b6877ce-98bc-468f-b49f-3bf4586c3546">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b6877ce-98bc-468f-b49f-3bf4586c3546">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b6877ce-98bc-468f-b49f-3bf4586c3546">
											<gml:posList>35.6685718538769 139.74859667804944 39.6 35.66862108554587 139.7486203860062 39.6 35.66862108554587 139.7486203860062 39.108 35.6685718538769 139.74859667804944 39.108 35.6685718538769 139.74859667804944 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e2566685-0850-432a-8e30-e1dada9c80a4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e2566685-0850-432a-8e30-e1dada9c80a4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e2566685-0850-432a-8e30-e1dada9c80a4">
											<gml:posList>35.6685718538769 139.74859667804944 39.6 35.6685718538769 139.74859667804944 46.567 35.66862108554587 139.7486203860062 46.567 35.66862108554587 139.7486203860062 39.6 35.6685718538769 139.74859667804944 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8cc730b5-4dda-4ca5-a0f8-41e117f279a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8cc730b5-4dda-4ca5-a0f8-41e117f279a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8cc730b5-4dda-4ca5-a0f8-41e117f279a9">
											<gml:posList>35.6685718538769 139.74859667804944 46.567 35.6685718538769 139.74859667804944 39.6 35.668571647012 139.7485973189367 39.6 35.66857033388376 139.7486014073484 39.6 35.66857033388376 139.7486014073484 36.366 35.66856254508541 139.74862570575468 36.366 35.66856254508541 139.74862570575468 39.6 35.66856254508541 139.74862570575468 46.567 35.6685718538769 139.74859667804944 46.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9649c6ee-9fd8-42d5-ba54-14f95a4080d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9649c6ee-9fd8-42d5-ba54-14f95a4080d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9649c6ee-9fd8-42d5-ba54-14f95a4080d7">
											<gml:posList>35.66857340730052 139.74860102853623 46.567 35.66856609515749 139.74862380209052 46.567 35.66856609515749 139.74862380209052 45.883 35.66857340730052 139.74860102853623 45.883 35.66857340730052 139.74860102853623 46.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e412e6c3-000e-4f1e-b602-05fa894fd370">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e412e6c3-000e-4f1e-b602-05fa894fd370">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e412e6c3-000e-4f1e-b602-05fa894fd370">
											<gml:posList>35.66857033388376 139.7486014073484 5.67 35.66856254508541 139.74862570575468 5.67 35.66856254508541 139.74862570575468 36.366 35.66857033388376 139.7486014073484 36.366 35.66857033388376 139.7486014073484 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ce75e40f-89b2-4f72-bec9-4c15c3ed75fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce75e40f-89b2-4f72-bec9-4c15c3ed75fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce75e40f-89b2-4f72-bec9-4c15c3ed75fc">
											<gml:posList>35.66871039800949 139.7486650722539 39.6 35.66874036856278 139.7485752253016 39.6 35.66874036856278 139.7485752253016 39.108 35.66871039800949 139.7486650722539 39.108 35.66871039800949 139.7486650722539 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e28713b5-7712-4dd9-a045-ea43f0d590ea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e28713b5-7712-4dd9-a045-ea43f0d590ea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e28713b5-7712-4dd9-a045-ea43f0d590ea">
											<gml:posList>35.668712376038826 139.748670792009 39.6 35.668712376038826 139.748670792009 36.366 35.668744217494236 139.74857532064735 36.366 35.668744217494236 139.74857532064735 39.6 35.668712376038826 139.748670792009 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-58244e1b-2b44-4ac3-967e-cc5001b992bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-58244e1b-2b44-4ac3-967e-cc5001b992bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-58244e1b-2b44-4ac3-967e-cc5001b992bc">
											<gml:posList>35.668712376038826 139.748670792009 5.67 35.668744217494236 139.74857532064735 5.67 35.668744217494236 139.74857532064735 36.366 35.668712376038826 139.748670792009 36.366 35.668712376038826 139.748670792009 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-704fcc5f-a588-4347-bd4b-42e651dfd826">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-704fcc5f-a588-4347-bd4b-42e651dfd826">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-704fcc5f-a588-4347-bd4b-42e651dfd826">
											<gml:posList>35.668565367337855 139.74862706143242 39.6 35.668563470002354 139.74863354744463 39.6 35.668563470002354 139.74863354744463 39.108 35.668565367337855 139.74862706143242 39.108 35.668565367337855 139.74862706143242 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1d9e3fd8-1062-4778-93b0-b1fd9eef2887">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d9e3fd8-1062-4778-93b0-b1fd9eef2887">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d9e3fd8-1062-4778-93b0-b1fd9eef2887">
											<gml:posList>35.668610232340626 139.74864506322717 46.567 35.66861754448761 139.7486222896623 46.567 35.66861754448761 139.7486222896623 45.883 35.668610232340626 139.74864506322717 45.883 35.668610232340626 139.74864506322717 46.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7462fb36-4485-4057-a32a-96da5a88347b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7462fb36-4485-4057-a32a-96da5a88347b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7462fb36-4485-4057-a32a-96da5a88347b">
											<gml:posList>35.66856254508541 139.74862570575468 5.67 35.668557527414066 139.74864275504757 5.67 35.668557527414066 139.74864275504757 36.366 35.66856254508541 139.74862570575468 36.366 35.66856254508541 139.74862570575468 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-34a5f711-d303-410d-9309-7f153b0622b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-34a5f711-d303-410d-9309-7f153b0622b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-34a5f711-d303-410d-9309-7f153b0622b4">
											<gml:posList>35.668559838410324 139.74863488784794 39.6 35.66856254508541 139.74862570575468 39.6 35.66856254508541 139.74862570575468 36.366 35.668557527414066 139.74864275504757 36.366 35.668559838410324 139.74863488784794 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c45b6722-e66c-408e-b1c9-ed1c3e62280f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c45b6722-e66c-408e-b1c9-ed1c3e62280f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c45b6722-e66c-408e-b1c9-ed1c3e62280f">
											<gml:posList>35.66862108554587 139.7486203860062 39.6 35.668611776748776 139.74864941372653 39.6 35.668611776748776 139.74864941372653 39.108 35.66862108554587 139.7486203860062 39.108 35.66862108554587 139.7486203860062 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-55bedeb3-60da-4a88-84d2-03e47a632bad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-55bedeb3-60da-4a88-84d2-03e47a632bad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-55bedeb3-60da-4a88-84d2-03e47a632bad">
											<gml:posList>35.668611776748776 139.74864941372653 46.567 35.668611776748776 139.74864941372653 39.6 35.66862108554587 139.7486203860062 39.6 35.66862108554587 139.7486203860062 46.567 35.668611776748776 139.74864941372653 46.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5935b47a-cfd5-4ba9-a4e0-7ab72b56a3b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5935b47a-cfd5-4ba9-a4e0-7ab72b56a3b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5935b47a-cfd5-4ba9-a4e0-7ab72b56a3b3">
											<gml:posList>35.668611776748776 139.74864941372653 46.567 35.66856254508541 139.74862570575468 46.567 35.66856254508541 139.74862570575468 39.6 35.668565367337855 139.74862706143242 39.6 35.668611776748776 139.74864941372653 39.6 35.668611776748776 139.74864941372653 46.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-682c358b-3ee1-4ed2-ba5d-40be6cf646d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-682c358b-3ee1-4ed2-ba5d-40be6cf646d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-682c358b-3ee1-4ed2-ba5d-40be6cf646d1">
											<gml:posList>35.668611776748776 139.74864941372653 39.6 35.668565367337855 139.74862706143242 39.6 35.668565367337855 139.74862706143242 39.108 35.668611776748776 139.74864941372653 39.108 35.668611776748776 139.74864941372653 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-de83ea10-c3ee-4f0b-b6bb-f01bf1594ac8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de83ea10-c3ee-4f0b-b6bb-f01bf1594ac8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de83ea10-c3ee-4f0b-b6bb-f01bf1594ac8">
											<gml:posList>35.668644349711755 139.7486327992474 39.6 35.66871039800949 139.7486650722539 39.6 35.66871039800949 139.7486650722539 39.108 35.668644349711755 139.7486327992474 39.108 35.668644349711755 139.7486327992474 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3cd40c8f-e900-42a1-aada-34399e2b0a7a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3cd40c8f-e900-42a1-aada-34399e2b0a7a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3cd40c8f-e900-42a1-aada-34399e2b0a7a">
											<gml:posList>35.66863225061734 139.74866746339112 39.6 35.668644349711755 139.7486327992474 39.6 35.668644349711755 139.7486327992474 39.108 35.66863225061734 139.74866746339112 39.108 35.66863225061734 139.74866746339112 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-71448de6-8b0a-4228-bc25-af7589fd3038">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-71448de6-8b0a-4228-bc25-af7589fd3038">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-71448de6-8b0a-4228-bc25-af7589fd3038">
											<gml:posList>35.668563470002354 139.74863354744463 39.6 35.66863225061734 139.74866746339112 39.6 35.66863225061734 139.74866746339112 39.108 35.668563470002354 139.74863354744463 39.108 35.668563470002354 139.74863354744463 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0c77af26-e566-4c8f-a767-3852183cc344">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c77af26-e566-4c8f-a767-3852183cc344">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c77af26-e566-4c8f-a767-3852183cc344">
											<gml:posList>35.66864628265847 139.74863849695254 39.6 35.66864628265847 139.74863849695254 36.366 35.668712376038826 139.748670792009 36.366 35.668712376038826 139.748670792009 39.6 35.66864628265847 139.74863849695254 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-31c6846c-9644-4358-bff9-e0932adfc8c5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31c6846c-9644-4358-bff9-e0932adfc8c5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31c6846c-9644-4358-bff9-e0932adfc8c5">
											<gml:posList>35.66864628265847 139.74863849695254 5.67 35.668712376038826 139.748670792009 5.67 35.668712376038826 139.748670792009 36.366 35.66864628265847 139.74863849695254 36.366 35.66864628265847 139.74863849695254 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-461158a0-0b42-4937-990c-fbce63e7463d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-461158a0-0b42-4937-990c-fbce63e7463d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-461158a0-0b42-4937-990c-fbce63e7463d">
											<gml:posList>35.668632078862146 139.74867958105577 5.67 35.66864628265847 139.74863849695254 5.67 35.66864628265847 139.74863849695254 36.366 35.668632078862146 139.74867958105577 36.366 35.668632078862146 139.74867958105577 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e19212ed-dfbb-473b-bbff-e4f388787cb5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e19212ed-dfbb-473b-bbff-e4f388787cb5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e19212ed-dfbb-473b-bbff-e4f388787cb5">
											<gml:posList>35.668634633324615 139.74867184614504 39.6 35.668632078862146 139.74867958105577 36.366 35.66864628265847 139.74863849695254 36.366 35.66864628265847 139.74863849695254 39.6 35.668634633324615 139.74867184614504 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4683faab-3e98-4c3a-ac38-3bb041e15d12">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4683faab-3e98-4c3a-ac38-3bb041e15d12">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4683faab-3e98-4c3a-ac38-3bb041e15d12">
											<gml:posList>35.668557527414066 139.74864275504757 5.67 35.668632078862146 139.74867958105577 5.67 35.668632078862146 139.74867958105577 36.366 35.668557527414066 139.74864275504757 36.366 35.668557527414066 139.74864275504757 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5211</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">270.4306</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.08</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>