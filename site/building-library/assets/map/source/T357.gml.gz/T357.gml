<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_676c55a6-a6df-45f4-9e7c-c30e5b397fe9">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">23.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67442804772474 139.73745676562746 0 35.67449814707241 139.7374223261592 0 35.67446498230297 139.73731642681543 0 35.67426603781612 139.7374149815684 0 35.6743771790127 139.73775752063048 0 35.67450485372024 139.73769484336898 0 35.67442804772474 139.73745676562746 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67442804772474 139.73745676562746 9.07 35.67450485372024 139.73769484336898 9.07 35.6743771790127 139.73775752063048 9.07 35.67426603781612 139.7374149815684 9.07 35.67446498230297 139.73731642681543 9.07 35.67449814707241 139.7374223261592 9.07 35.67442804772474 139.73745676562746 9.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67442804772474 139.73745676562746 9.07 35.67449814707241 139.7374223261592 9.07 35.67449814707241 139.7374223261592 29.78 35.67442804772474 139.73745676562746 29.78 35.67442804772474 139.73745676562746 9.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67449814707241 139.7374223261592 9.07 35.67446498230297 139.73731642681543 9.07 35.67446498230297 139.73731642681543 29.78 35.67449814707241 139.7374223261592 29.78 35.67449814707241 139.7374223261592 9.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67446498230297 139.73731642681543 9.07 35.67426603781612 139.7374149815684 9.07 35.67426603781612 139.7374149815684 29.78 35.67446498230297 139.73731642681543 29.78 35.67446498230297 139.73731642681543 9.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67426603781612 139.7374149815684 9.07 35.6743771790127 139.73775752063048 9.07 35.6743771790127 139.73775752063048 29.78 35.67426603781612 139.7374149815684 29.78 35.67426603781612 139.7374149815684 9.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6743771790127 139.73775752063048 9.07 35.67450485372024 139.73769484336898 9.07 35.67450485372024 139.73769484336898 29.78 35.6743771790127 139.73775752063048 29.78 35.6743771790127 139.73775752063048 9.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67450485372024 139.73769484336898 9.07 35.67442804772474 139.73745676562746 9.07 35.67442804772474 139.73745676562746 29.78 35.67450485372024 139.73769484336898 29.78 35.67450485372024 139.73769484336898 9.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67442804772474 139.73745676562746 29.78 35.67449814707241 139.7374223261592 29.78 35.67446498230297 139.73731642681543 29.78 35.67426603781612 139.7374149815684 29.78 35.6743771790127 139.73775752063048 29.78 35.67450485372024 139.73769484336898 29.78 35.67442804772474 139.73745676562746 29.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-0d08d01f-6359-4651-a1f3-b3e906d61673"/>
							<gml:surfaceMember xlink:href="#poly-d3402578-3614-4119-897e-e82b9b2f382c"/>
							<gml:surfaceMember xlink:href="#poly-c9a774e8-5189-420e-a4c8-1acd0972bb62"/>
							<gml:surfaceMember xlink:href="#poly-6f8ba3c6-8f41-4f2b-9d8c-8c3a891f6543"/>
							<gml:surfaceMember xlink:href="#poly-ce3e5b3d-bee0-4002-afe8-96174d337b9a"/>
							<gml:surfaceMember xlink:href="#poly-989e54f9-c5bc-45f9-b4af-09d2274d31e4"/>
							<gml:surfaceMember xlink:href="#poly-0222f52e-6769-42ed-986b-941c6c9c89f2"/>
							<gml:surfaceMember xlink:href="#poly-aa5f2c6a-b6e5-4c21-8a42-0acc50a75117"/>
							<gml:surfaceMember xlink:href="#poly-cf5e6c0b-a72a-4e8f-abf6-bc42f85d3f0e"/>
							<gml:surfaceMember xlink:href="#poly-c8f1b42e-f544-4b29-a1c7-f581df208b96"/>
							<gml:surfaceMember xlink:href="#poly-4110bc72-4774-4334-9510-92cd95ca943a"/>
							<gml:surfaceMember xlink:href="#poly-d2cb6260-b48f-45c8-af6a-3214dd3f6816"/>
							<gml:surfaceMember xlink:href="#poly-927c94ce-2d8f-4ed1-bf5a-8124a42be5e8"/>
							<gml:surfaceMember xlink:href="#poly-e69ef730-3371-4e14-b115-b195170967fc"/>
							<gml:surfaceMember xlink:href="#poly-05c6b391-82d9-4e1b-96e3-d2bf0b010e8f"/>
							<gml:surfaceMember xlink:href="#poly-cbeb5dda-1bff-4a8b-82d9-b68d05b8e23a"/>
							<gml:surfaceMember xlink:href="#poly-ca956121-855a-4726-961e-bc9b40f0d97d"/>
							<gml:surfaceMember xlink:href="#poly-fdfcc983-373e-4fcd-a0ba-1bb9f087141e"/>
							<gml:surfaceMember xlink:href="#poly-85f1c364-ada6-49d2-ac65-b565460a8509"/>
							<gml:surfaceMember xlink:href="#poly-64901480-e058-4f21-8a82-a30ba2c69473"/>
							<gml:surfaceMember xlink:href="#poly-60cedcde-b05c-4f07-b4e8-3fecf3f61fc6"/>
							<gml:surfaceMember xlink:href="#poly-115bf1c6-f3b9-42f1-9db9-97420f752512"/>
							<gml:surfaceMember xlink:href="#poly-19d7ac31-c1ac-4ec5-8476-5e22b6002376"/>
							<gml:surfaceMember xlink:href="#poly-d233720f-a6b3-4b6d-a6f0-7a8de94500b4"/>
							<gml:surfaceMember xlink:href="#poly-4979eaba-e2f1-4ac8-80ec-99ee7c948503"/>
							<gml:surfaceMember xlink:href="#poly-a4ec906d-fddf-41de-8b23-15bea68f7186"/>
							<gml:surfaceMember xlink:href="#poly-4912d444-9a49-40df-a0e3-83c9a899e1c3"/>
							<gml:surfaceMember xlink:href="#poly-66fb8536-19cd-49b6-bc9e-f08b978072ae"/>
							<gml:surfaceMember xlink:href="#poly-d6f7ba16-cca4-434c-ad02-8e5104631fc1"/>
							<gml:surfaceMember xlink:href="#poly-11794bcf-efb2-46c7-8a5c-04063d928745"/>
							<gml:surfaceMember xlink:href="#poly-9683c141-be5e-4a8d-b20b-ce73ce1ff909"/>
							<gml:surfaceMember xlink:href="#poly-6e10f163-0787-46a6-a98d-f23d05c22a85"/>
							<gml:surfaceMember xlink:href="#poly-c2b4ab71-bc22-4e4c-9da5-c5b6f3c73aac"/>
							<gml:surfaceMember xlink:href="#poly-f61b426a-2dcb-48c7-a3fb-4b930ee274b8"/>
							<gml:surfaceMember xlink:href="#poly-57621c1a-cf6c-4c2f-98c1-6898fbfb76f1"/>
							<gml:surfaceMember xlink:href="#poly-6712f354-323c-42ee-80b1-1281b28d93df"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_676c55a6-a6df-45f4-9e7c-c30e5b397fe9_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1f597d1-781f-4cf9-93c2-8769e27ba236">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67438130928007 139.73747654008235 39.453 35.67440052813965 139.73746722673192 39.453 35.67441968449473 139.73752660255192 39.453 35.67440045661689 139.7375359159012 39.453 35.67438130928007 139.73747654008235 39.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57fc5697-3242-4fca-8d09-970add4a793e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674424493326676 139.7375436089021 39.453 35.67443417033999 139.73753892453513 39.453 35.674444516571484 139.73757100318147 39.453 35.67443483955692 139.7375756875452 39.453 35.674424493326676 139.7375436089021 39.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0506cff1-b01d-4abb-8dae-8aa8f1801571">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0506cff1-b01d-4abb-8dae-8aa8f1801571_0">
											<gml:posList>35.67440045661689 139.7375359159012 41.469 35.67438130928007 139.73747654008235 41.469 35.67438130928007 139.73747654008235 39.453 35.67440045661689 139.7375359159012 39.453 35.67440045661689 139.7375359159012 41.469</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a66e18ab-0384-43d3-b314-2ab39a7cb96f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a66e18ab-0384-43d3-b314-2ab39a7cb96f_0">
											<gml:posList>35.67438130928007 139.73747654008235 41.469 35.67440052813965 139.73746722673192 41.469 35.67440052813965 139.73746722673192 39.453 35.67438130928007 139.73747654008235 39.453 35.67438130928007 139.73747654008235 41.469</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19ffe647-8735-4a98-bd39-28f82dc5ee7a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19ffe647-8735-4a98-bd39-28f82dc5ee7a_0">
											<gml:posList>35.67441968449473 139.73752660255192 41.469 35.67440052813965 139.73746722673192 41.469 35.67438130928007 139.73747654008235 41.469 35.67440045661689 139.7375359159012 41.469 35.67441968449473 139.73752660255192 41.469</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-157919bc-694d-43ec-a1e7-eeffcfeefa01">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-157919bc-694d-43ec-a1e7-eeffcfeefa01_0">
											<gml:posList>35.67441968449473 139.73752660255192 41.469 35.67440045661689 139.7375359159012 41.469 35.67440045661689 139.7375359159012 39.453 35.67441968449473 139.73752660255192 39.453 35.67441968449473 139.73752660255192 41.469</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3a0ca0a-441f-41f5-a575-54dc8db77568">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3a0ca0a-441f-41f5-a575-54dc8db77568_0">
											<gml:posList>35.67441968449473 139.73752660255192 41.469 35.67441968449473 139.73752660255192 39.453 35.67440052813965 139.73746722673192 39.453 35.67440052813965 139.73746722673192 41.469 35.67441968449473 139.73752660255192 41.469</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76c71974-bfcd-4cab-8ad9-f8a9a0b88555">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-76c71974-bfcd-4cab-8ad9-f8a9a0b88555_0">
											<gml:posList>35.674424493326676 139.7375436089021 39.92 35.67443417033999 139.73753892453513 39.92 35.67443417033999 139.73753892453513 39.453 35.674424493326676 139.7375436089021 39.453 35.674424493326676 139.7375436089021 39.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f4a97353-d313-481e-a011-a21726d3b060">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f4a97353-d313-481e-a011-a21726d3b060_0">
											<gml:posList>35.674424493326676 139.7375436089021 39.92 35.674424493326676 139.7375436089021 39.453 35.67443483955692 139.7375756875452 39.453 35.67443483955692 139.7375756875452 39.92 35.674424493326676 139.7375436089021 39.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19c6fe4d-308f-4a8a-ac33-541b77ebb367">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19c6fe4d-308f-4a8a-ac33-541b77ebb367_0">
											<gml:posList>35.674444516571484 139.73757100318147 39.92 35.67443417033999 139.73753892453513 39.92 35.674424493326676 139.7375436089021 39.92 35.67443483955692 139.7375756875452 39.92 35.674444516571484 139.73757100318147 39.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78c6f7f7-2850-405c-93d0-35cb02a345a9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78c6f7f7-2850-405c-93d0-35cb02a345a9_0">
											<gml:posList>35.674444516571484 139.73757100318147 39.92 35.674444516571484 139.73757100318147 39.453 35.67443417033999 139.73753892453513 39.453 35.67443417033999 139.73753892453513 39.92 35.674444516571484 139.73757100318147 39.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-95593c8c-15c7-4905-84a1-a46ce45068e5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-95593c8c-15c7-4905-84a1-a46ce45068e5_0">
											<gml:posList>35.67443483955692 139.7375756875452 39.92 35.67443483955692 139.7375756875452 39.453 35.674444516571484 139.73757100318147 39.453 35.674444516571484 139.73757100318147 39.92 35.67443483955692 139.7375756875452 39.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_676c55a6-a6df-45f4-9e7c-c30e5b397fe9_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f2b21d65-8c42-4cb5-8f08-26b5b983431a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67443033009121 139.73761775921164 39.453 35.6744280622214 139.73761093498658 39.453 35.67444599242852 139.73760199879362 39.453 35.67444825128512 139.7376088230307 39.453 35.67443033009121 139.73761775921164 39.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c49bf28a-15a3-48e0-ae1d-5df5aa177fff">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67446177115105 139.73756257593868 39.453 35.67446791561547 139.73758160227308 39.453 35.674460806481775 139.73758499109178 39.453 35.67445467102283 139.73756595370122 39.453 35.67446177115105 139.73756257593868 39.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6fe1e5d8-bba3-4af6-8864-68932d16df3c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6fe1e5d8-bba3-4af6-8864-68932d16df3c_0">
											<gml:posList>35.67443033009121 139.73761775921164 39.832 35.6744280622214 139.73761093498658 39.832 35.6744280622214 139.73761093498658 39.453 35.67443033009121 139.73761775921164 39.453 35.67443033009121 139.73761775921164 39.832</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c04d0bf-9538-4b0c-a461-1f2d3af8cf5d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4c04d0bf-9538-4b0c-a461-1f2d3af8cf5d_0">
											<gml:posList>35.6744280622214 139.73761093498658 39.832 35.67444599242852 139.73760199879362 39.832 35.67444599242852 139.73760199879362 39.453 35.6744280622214 139.73761093498658 39.453 35.6744280622214 139.73761093498658 39.832</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7d80b5a3-32d7-4f31-a801-4f137a3b426e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7d80b5a3-32d7-4f31-a801-4f137a3b426e_0">
											<gml:posList>35.67443033009121 139.73761775921164 39.832 35.67444825128512 139.7376088230307 39.832 35.67444599242852 139.73760199879362 39.832 35.6744280622214 139.73761093498658 39.832 35.67443033009121 139.73761775921164 39.832</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61fef6ae-0108-4dc3-b425-1a26582b0276">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-61fef6ae-0108-4dc3-b425-1a26582b0276_0">
											<gml:posList>35.67444825128512 139.7376088230307 39.832 35.67443033009121 139.73761775921164 39.832 35.67443033009121 139.73761775921164 39.453 35.67444825128512 139.7376088230307 39.453 35.67444825128512 139.7376088230307 39.832</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a10b7808-9a97-431c-9a54-0dd420dce4e8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a10b7808-9a97-431c-9a54-0dd420dce4e8_0">
											<gml:posList>35.67444825128512 139.7376088230307 39.832 35.67444825128512 139.7376088230307 39.453 35.67444599242852 139.73760199879362 39.453 35.67444599242852 139.73760199879362 39.832 35.67444825128512 139.7376088230307 39.832</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4ad13d38-7a81-4f5b-8609-392f606d76b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4ad13d38-7a81-4f5b-8609-392f606d76b2_0">
											<gml:posList>35.674460806481775 139.73758499109178 39.863 35.67445467102283 139.73756595370122 39.863 35.67445467102283 139.73756595370122 39.453 35.674460806481775 139.73758499109178 39.453 35.674460806481775 139.73758499109178 39.863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d97be5c9-9b2b-4b7d-ac16-4be8760f1917">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d97be5c9-9b2b-4b7d-ac16-4be8760f1917_0">
											<gml:posList>35.67445467102283 139.73756595370122 39.863 35.67446177115105 139.73756257593868 39.863 35.67446177115105 139.73756257593868 39.453 35.67445467102283 139.73756595370122 39.453 35.67445467102283 139.73756595370122 39.863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6b33995-fea7-4859-882d-a616a317fd1b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d6b33995-fea7-4859-882d-a616a317fd1b_0">
											<gml:posList>35.67446177115105 139.73756257593868 39.863 35.67445467102283 139.73756595370122 39.863 35.674460806481775 139.73758499109178 39.863 35.67446791561547 139.73758160227308 39.863 35.67446177115105 139.73756257593868 39.863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f1a19f2-44fa-43b0-9fe0-b558ef8da60c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0f1a19f2-44fa-43b0-9fe0-b558ef8da60c_0">
											<gml:posList>35.674460806481775 139.73758499109178 39.863 35.674460806481775 139.73758499109178 39.453 35.67446791561547 139.73758160227308 39.453 35.67446791561547 139.73758160227308 39.863 35.674460806481775 139.73758499109178 39.863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7ed20c3-bb28-4661-a36c-16f70904a097">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c7ed20c3-bb28-4661-a36c-16f70904a097_0">
											<gml:posList>35.67446177115105 139.73756257593868 39.863 35.67446791561547 139.73758160227308 39.863 35.67446791561547 139.73758160227308 39.453 35.67446177115105 139.73756257593868 39.453 35.67446177115105 139.73756257593868 39.863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-0d08d01f-6359-4651-a1f3-b3e906d61673">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d08d01f-6359-4651-a1f3-b3e906d61673">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d08d01f-6359-4651-a1f3-b3e906d61673">
											<gml:posList>35.67442804772473 139.73745676562746 9.07 35.67450485372026 139.73769484336898 9.07 35.67437717901271 139.73775752063045 9.07 35.67426603781611 139.73741498156838 9.07 35.674464982302936 139.7373164268154 9.07 35.674498147072384 139.7374223261592 9.07 35.67442804772473 139.73745676562746 9.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d3402578-3614-4119-897e-e82b9b2f382c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3402578-3614-4119-897e-e82b9b2f382c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3402578-3614-4119-897e-e82b9b2f382c">
											<gml:posList>35.674422061795866 139.73742178752008 36.664 35.674464982302936 139.7373164268154 27.625 35.67426603781611 139.73741498156838 27.625 35.674422061795866 139.73742178752008 36.664</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c9a774e8-5189-420e-a4c8-1acd0972bb62">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c9a774e8-5189-420e-a4c8-1acd0972bb62">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c9a774e8-5189-420e-a4c8-1acd0972bb62">
											<gml:posList>35.67447858277171 139.7373940255099 36.664 35.674464982302936 139.7373164268154 27.625 35.674422061795866 139.73742178752008 36.664 35.67447858277171 139.7373940255099 36.664</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6f8ba3c6-8f41-4f2b-9d8c-8c3a891f6543">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f8ba3c6-8f41-4f2b-9d8c-8c3a891f6543">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f8ba3c6-8f41-4f2b-9d8c-8c3a891f6543">
											<gml:posList>35.674464982302936 139.7373164268154 27.625 35.67448926301555 139.73742668923737 27.625 35.674498147072384 139.7374223261592 27.625 35.674464982302936 139.7373164268154 27.625</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ce3e5b3d-bee0-4002-afe8-96174d337b9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce3e5b3d-bee0-4002-afe8-96174d337b9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce3e5b3d-bee0-4002-afe8-96174d337b9a">
											<gml:posList>35.67448926301555 139.73742668923737 38.113 35.67447858277171 139.7373940255099 38.113 35.674422061795866 139.73742178752008 38.113 35.67443275104597 139.7374544512175 38.113 35.67448926301555 139.73742668923737 38.113</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-989e54f9-c5bc-45f9-b4af-09d2274d31e4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-989e54f9-c5bc-45f9-b4af-09d2274d31e4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-989e54f9-c5bc-45f9-b4af-09d2274d31e4">
											<gml:posList>35.67426603781611 139.73741498156838 27.625 35.67436435911439 139.73747105903982 37.837 35.674422061795866 139.73742178752008 36.664 35.67426603781611 139.73741498156838 27.625</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0222f52e-6769-42ed-986b-941c6c9c89f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0222f52e-6769-42ed-986b-941c6c9c89f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0222f52e-6769-42ed-986b-941c6c9c89f2">
											<gml:posList>35.674422061795866 139.73742178752008 36.664 35.67436435911439 139.73747105903982 37.837 35.67442343030638 139.73744244342913 37.837 35.67442805248632 139.73744010702188 37.837 35.674422061795866 139.73742178752008 36.664</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-aa5f2c6a-b6e5-4c21-8a42-0acc50a75117">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa5f2c6a-b6e5-4c21-8a42-0acc50a75117">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa5f2c6a-b6e5-4c21-8a42-0acc50a75117">
											<gml:posList>35.67442343030638 139.73744244342913 27.316 35.67442804772473 139.73745676562746 27.316 35.67443275104597 139.7374544512175 27.316 35.67442805248632 139.73744010702188 27.316 35.67442343030638 139.73744244342913 27.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cf5e6c0b-a72a-4e8f-abf6-bc42f85d3f0e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cf5e6c0b-a72a-4e8f-abf6-bc42f85d3f0e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cf5e6c0b-a72a-4e8f-abf6-bc42f85d3f0e">
											<gml:posList>35.674412645659274 139.737459766688 39.453 35.67442680076201 139.73745291177974 39.453 35.67442343030638 139.73744244342913 39.453 35.67440639730701 139.73745745432979 39.453 35.674412645659274 139.737459766688 39.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c8f1b42e-f544-4b29-a1c7-f581df208b96">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8f1b42e-f544-4b29-a1c7-f581df208b96">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8f1b42e-f544-4b29-a1c7-f581df208b96">
											<gml:posList>35.67436435911439 139.73747105903982 39.453 35.67437101405107 139.7374745860607 39.453 35.67440639730701 139.73745745432979 39.453 35.67442343030638 139.73744244342913 39.453 35.67436435911439 139.73747105903982 39.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4110bc72-4774-4334-9510-92cd95ca943a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4110bc72-4774-4334-9510-92cd95ca943a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4110bc72-4774-4334-9510-92cd95ca943a">
											<gml:posList>35.67443861517412 139.73754026693558 40.655 35.6744527792951 139.7375334120285 40.655 35.67442680076201 139.73745291177974 40.655 35.674412645659274 139.737459766688 40.655 35.67443861517412 139.73754026693558 40.655</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d2cb6260-b48f-45c8-af6a-3214dd3f6816">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d2cb6260-b48f-45c8-af6a-3214dd3f6816">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d2cb6260-b48f-45c8-af6a-3214dd3f6816">
											<gml:posList>35.67443861517412 139.73754026693558 39.453 35.674412645659274 139.737459766688 39.453 35.67440639730701 139.73745745432979 39.453 35.67443573725314 139.73754840083254 39.453 35.67443861517412 139.73754026693558 39.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-927c94ce-2d8f-4ed1-bf5a-8124a42be5e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-927c94ce-2d8f-4ed1-bf5a-8124a42be5e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-927c94ce-2d8f-4ed1-bf5a-8124a42be5e8">
											<gml:posList>35.67443861517412 139.73754026693558 39.453 35.67443573725314 139.73754840083254 39.453 35.67444990137461 139.73754154592714 39.453 35.6744527792951 139.7375334120285 39.453 35.67443861517412 139.73754026693558 39.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e69ef730-3371-4e14-b115-b195170967fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e69ef730-3371-4e14-b115-b195170967fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e69ef730-3371-4e14-b115-b195170967fc">
											<gml:posList>35.67442078435087 139.73762883951855 39.453 35.674470313708575 139.7376048308769 39.453 35.67444990137461 139.73754154592714 39.453 35.67443573725314 139.73754840083254 39.453 35.67440639730701 139.73745745432979 39.453 35.67437101405107 139.7374745860607 39.453 35.67442078435087 139.73762883951855 39.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-05c6b391-82d9-4e1b-96e3-d2bf0b010e8f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-05c6b391-82d9-4e1b-96e3-d2bf0b010e8f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-05c6b391-82d9-4e1b-96e3-d2bf0b010e8f">
											<gml:posList>35.67441789743651 139.7376370065617 39.453 35.67442078435087 139.73762883951855 39.453 35.67437101405107 139.7374745860607 39.453 35.67436435911439 139.73747105903982 39.453 35.67441789743651 139.7376370065617 39.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cbeb5dda-1bff-4a8b-82d9-b68d05b8e23a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cbeb5dda-1bff-4a8b-82d9-b68d05b8e23a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cbeb5dda-1bff-4a8b-82d9-b68d05b8e23a">
											<gml:posList>35.6744527792951 139.7375334120285 39.453 35.67444990137461 139.73754154592714 39.453 35.674470313708575 139.7376048308769 39.453 35.67447695964509 139.73760838001795 39.453 35.6744527792951 139.7375334120285 39.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ca956121-855a-4726-961e-bc9b40f0d97d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca956121-855a-4726-961e-bc9b40f0d97d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca956121-855a-4726-961e-bc9b40f0d97d">
											<gml:posList>35.67437717901271 139.73775752063045 27.625 35.67441789743651 139.7376370065617 37.837 35.67436435911439 139.73747105903982 37.837 35.67426603781611 139.73741498156838 27.625 35.67437717901271 139.73775752063045 27.625</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fdfcc983-373e-4fcd-a0ba-1bb9f087141e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fdfcc983-373e-4fcd-a0ba-1bb9f087141e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fdfcc983-373e-4fcd-a0ba-1bb9f087141e">
											<gml:posList>35.67447695964509 139.73760838001795 39.453 35.674470313708575 139.7376048308769 39.453 35.67442078435087 139.73762883951855 39.453 35.67441789743651 139.7376370065617 39.453 35.67447695964509 139.73760838001795 39.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-85f1c364-ada6-49d2-ac65-b565460a8509">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85f1c364-ada6-49d2-ac65-b565460a8509">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85f1c364-ada6-49d2-ac65-b565460a8509">
											<gml:posList>35.67441789743651 139.7376370065617 37.837 35.67437717901271 139.73775752063045 27.625 35.67450485372026 139.73769484336898 27.625 35.67447695964509 139.73760838001795 37.837 35.67441789743651 139.7376370065617 37.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-64901480-e058-4f21-8a82-a30ba2c69473">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-64901480-e058-4f21-8a82-a30ba2c69473">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-64901480-e058-4f21-8a82-a30ba2c69473">
											<gml:posList>35.67426603781611 139.73741498156838 27.625 35.674464982302936 139.7373164268154 27.625 35.674464982302936 139.7373164268154 9.07 35.67426603781611 139.73741498156838 9.07 35.67426603781611 139.73741498156838 27.625</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-60cedcde-b05c-4f07-b4e8-3fecf3f61fc6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-60cedcde-b05c-4f07-b4e8-3fecf3f61fc6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-60cedcde-b05c-4f07-b4e8-3fecf3f61fc6">
											<gml:posList>35.674464982302936 139.7373164268154 27.625 35.674498147072384 139.7374223261592 27.625 35.674498147072384 139.7374223261592 9.07 35.674464982302936 139.7373164268154 9.07 35.674464982302936 139.7373164268154 27.625</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-115bf1c6-f3b9-42f1-9db9-97420f752512">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-115bf1c6-f3b9-42f1-9db9-97420f752512">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-115bf1c6-f3b9-42f1-9db9-97420f752512">
											<gml:posList>35.67447858277171 139.7373940255099 36.664 35.67448926301555 139.73742668923737 27.625 35.674464982302936 139.7373164268154 27.625 35.67447858277171 139.7373940255099 36.664</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-19d7ac31-c1ac-4ec5-8476-5e22b6002376">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-19d7ac31-c1ac-4ec5-8476-5e22b6002376">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-19d7ac31-c1ac-4ec5-8476-5e22b6002376">
											<gml:posList>35.67447858277171 139.7373940255099 38.113 35.67447858277171 139.7373940255099 36.664 35.674422061795866 139.73742178752008 36.664 35.674422061795866 139.73742178752008 38.113 35.67447858277171 139.7373940255099 38.113</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d233720f-a6b3-4b6d-a6f0-7a8de94500b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d233720f-a6b3-4b6d-a6f0-7a8de94500b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d233720f-a6b3-4b6d-a6f0-7a8de94500b4">
											<gml:posList>35.67448926301555 139.73742668923737 38.113 35.67448926301555 139.73742668923737 27.625 35.67447858277171 139.7373940255099 36.664 35.67447858277171 139.7373940255099 38.113 35.67448926301555 139.73742668923737 38.113</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4979eaba-e2f1-4ac8-80ec-99ee7c948503">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4979eaba-e2f1-4ac8-80ec-99ee7c948503">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4979eaba-e2f1-4ac8-80ec-99ee7c948503">
											<gml:posList>35.67442805248632 139.73744010702188 37.837 35.67442805248632 139.73744010702188 27.316 35.67443275104597 139.7374544512175 27.316 35.67443275104597 139.7374544512175 38.113 35.674422061795866 139.73742178752008 38.113 35.674422061795866 139.73742178752008 36.664 35.67442805248632 139.73744010702188 37.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a4ec906d-fddf-41de-8b23-15bea68f7186">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4ec906d-fddf-41de-8b23-15bea68f7186">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4ec906d-fddf-41de-8b23-15bea68f7186">
											<gml:posList>35.67443275104597 139.7374544512175 27.316 35.67442804772473 139.73745676562746 27.316 35.67442804772473 139.73745676562746 9.07 35.674498147072384 139.7374223261592 9.07 35.674498147072384 139.7374223261592 27.625 35.67448926301555 139.73742668923737 27.625 35.67448926301555 139.73742668923737 38.113 35.67443275104597 139.7374544512175 38.113 35.67443275104597 139.7374544512175 27.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4912d444-9a49-40df-a0e3-83c9a899e1c3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4912d444-9a49-40df-a0e3-83c9a899e1c3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4912d444-9a49-40df-a0e3-83c9a899e1c3">
											<gml:posList>35.67442805248632 139.73744010702188 27.316 35.67442805248632 139.73744010702188 37.837 35.67442343030638 139.73744244342913 37.837 35.67442343030638 139.73744244342913 27.316 35.67442805248632 139.73744010702188 27.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-66fb8536-19cd-49b6-bc9e-f08b978072ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66fb8536-19cd-49b6-bc9e-f08b978072ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66fb8536-19cd-49b6-bc9e-f08b978072ae">
											<gml:posList>35.674412645659274 139.737459766688 40.655 35.67442680076201 139.73745291177974 40.655 35.67442680076201 139.73745291177974 39.453 35.674412645659274 139.737459766688 39.453 35.674412645659274 139.737459766688 40.655</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d6f7ba16-cca4-434c-ad02-8e5104631fc1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d6f7ba16-cca4-434c-ad02-8e5104631fc1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d6f7ba16-cca4-434c-ad02-8e5104631fc1">
											<gml:posList>35.67442343030638 139.73744244342913 39.453 35.67442343030638 139.73744244342913 37.837 35.67436435911439 139.73747105903982 37.837 35.67436435911439 139.73747105903982 39.453 35.67442343030638 139.73744244342913 39.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-11794bcf-efb2-46c7-8a5c-04063d928745">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11794bcf-efb2-46c7-8a5c-04063d928745">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11794bcf-efb2-46c7-8a5c-04063d928745">
											<gml:posList>35.67443861517412 139.73754026693558 40.655 35.674412645659274 139.737459766688 40.655 35.674412645659274 139.737459766688 39.453 35.67443861517412 139.73754026693558 39.453 35.67443861517412 139.73754026693558 40.655</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9683c141-be5e-4a8d-b20b-ce73ce1ff909">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9683c141-be5e-4a8d-b20b-ce73ce1ff909">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9683c141-be5e-4a8d-b20b-ce73ce1ff909">
											<gml:posList>35.6744527792951 139.7375334120285 40.655 35.67443861517412 139.73754026693558 40.655 35.67443861517412 139.73754026693558 39.453 35.6744527792951 139.7375334120285 39.453 35.6744527792951 139.7375334120285 40.655</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6e10f163-0787-46a6-a98d-f23d05c22a85">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e10f163-0787-46a6-a98d-f23d05c22a85">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e10f163-0787-46a6-a98d-f23d05c22a85">
											<gml:posList>35.67441789743651 139.7376370065617 39.453 35.67436435911439 139.73747105903982 39.453 35.67436435911439 139.73747105903982 37.837 35.67441789743651 139.7376370065617 37.837 35.67441789743651 139.7376370065617 39.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c2b4ab71-bc22-4e4c-9da5-c5b6f3c73aac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c2b4ab71-bc22-4e4c-9da5-c5b6f3c73aac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c2b4ab71-bc22-4e4c-9da5-c5b6f3c73aac">
											<gml:posList>35.6744527792951 139.7375334120285 39.453 35.67447695964509 139.73760838001795 39.453 35.67447695964509 139.73760838001795 37.837 35.67450485372026 139.73769484336898 27.625 35.67450485372026 139.73769484336898 9.07 35.67442804772473 139.73745676562746 9.07 35.67442804772473 139.73745676562746 27.316 35.67442343030638 139.73744244342913 27.316 35.67442343030638 139.73744244342913 37.837 35.67442343030638 139.73744244342913 39.453 35.67442680076201 139.73745291177974 39.453 35.67442680076201 139.73745291177974 40.655 35.6744527792951 139.7375334120285 40.655 35.6744527792951 139.7375334120285 39.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f61b426a-2dcb-48c7-a3fb-4b930ee274b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f61b426a-2dcb-48c7-a3fb-4b930ee274b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f61b426a-2dcb-48c7-a3fb-4b930ee274b8">
											<gml:posList>35.67426603781611 139.73741498156838 9.07 35.67437717901271 139.73775752063045 9.07 35.67437717901271 139.73775752063045 27.625 35.67426603781611 139.73741498156838 27.625 35.67426603781611 139.73741498156838 9.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-57621c1a-cf6c-4c2f-98c1-6898fbfb76f1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-57621c1a-cf6c-4c2f-98c1-6898fbfb76f1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-57621c1a-cf6c-4c2f-98c1-6898fbfb76f1">
											<gml:posList>35.67447695964509 139.73760838001795 37.837 35.67447695964509 139.73760838001795 39.453 35.67441789743651 139.7376370065617 39.453 35.67441789743651 139.7376370065617 37.837 35.67447695964509 139.73760838001795 37.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6712f354-323c-42ee-80b1-1281b28d93df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6712f354-323c-42ee-80b1-1281b28d93df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6712f354-323c-42ee-80b1-1281b28d93df">
											<gml:posList>35.67437717901271 139.73775752063045 9.07 35.67450485372026 139.73769484336898 9.07 35.67450485372026 139.73769484336898 27.625 35.67437717901271 139.73775752063045 27.625 35.67437717901271 139.73775752063045 9.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-11613</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">597.08475</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>