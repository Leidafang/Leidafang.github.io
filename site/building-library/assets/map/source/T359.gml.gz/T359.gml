<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_682b0c96-4b88-4d7d-819a-f0ce912690ec">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">15</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.674278254428636 139.7377020731857 0 35.674243731259025 139.7375878905448 0 35.67421606912849 139.7376004727335 0 35.67422391362747 139.73762636808542 0 35.67421382172481 139.73763073256796 0 35.67419454833061 139.7376394935833 0 35.6741985338614 139.73765267868737 0 35.67416123059321 139.73766973525125 0 35.67418400490357 139.73774493666843 0 35.674278254428636 139.7377020731857 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674278254428636 139.7377020731857 9.22 35.67418400490357 139.73774493666843 9.22 35.67416123059321 139.73766973525125 9.22 35.6741985338614 139.73765267868737 9.22 35.67419454833061 139.7376394935833 9.22 35.67421382172481 139.73763073256796 9.22 35.67422391362747 139.73762636808542 9.22 35.67421606912849 139.7376004727335 9.22 35.674243731259025 139.7375878905448 9.22 35.674278254428636 139.7377020731857 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674278254428636 139.7377020731857 9.22 35.674243731259025 139.7375878905448 9.22 35.674243731259025 139.7375878905448 24.21 35.674278254428636 139.7377020731857 24.21 35.674278254428636 139.7377020731857 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674243731259025 139.7375878905448 9.22 35.67421606912849 139.7376004727335 9.22 35.67421606912849 139.7376004727335 24.21 35.674243731259025 139.7375878905448 24.21 35.674243731259025 139.7375878905448 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67421606912849 139.7376004727335 9.22 35.67422391362747 139.73762636808542 9.22 35.67422391362747 139.73762636808542 24.21 35.67421606912849 139.7376004727335 24.21 35.67421606912849 139.7376004727335 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67422391362747 139.73762636808542 9.22 35.67421382172481 139.73763073256796 9.22 35.67421382172481 139.73763073256796 24.21 35.67422391362747 139.73762636808542 24.21 35.67422391362747 139.73762636808542 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67421382172481 139.73763073256796 9.22 35.67419454833061 139.7376394935833 9.22 35.67419454833061 139.7376394935833 24.21 35.67421382172481 139.73763073256796 24.21 35.67421382172481 139.73763073256796 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67419454833061 139.7376394935833 9.22 35.6741985338614 139.73765267868737 9.22 35.6741985338614 139.73765267868737 24.21 35.67419454833061 139.7376394935833 24.21 35.67419454833061 139.7376394935833 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6741985338614 139.73765267868737 9.22 35.67416123059321 139.73766973525125 9.22 35.67416123059321 139.73766973525125 24.21 35.6741985338614 139.73765267868737 24.21 35.6741985338614 139.73765267868737 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67416123059321 139.73766973525125 9.22 35.67418400490357 139.73774493666843 9.22 35.67418400490357 139.73774493666843 24.21 35.67416123059321 139.73766973525125 24.21 35.67416123059321 139.73766973525125 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67418400490357 139.73774493666843 9.22 35.674278254428636 139.7377020731857 9.22 35.674278254428636 139.7377020731857 24.21 35.67418400490357 139.73774493666843 24.21 35.67418400490357 139.73774493666843 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674278254428636 139.7377020731857 24.21 35.674243731259025 139.7375878905448 24.21 35.67421606912849 139.7376004727335 24.21 35.67422391362747 139.73762636808542 24.21 35.67421382172481 139.73763073256796 24.21 35.67419454833061 139.7376394935833 24.21 35.6741985338614 139.73765267868737 24.21 35.67416123059321 139.73766973525125 24.21 35.67418400490357 139.73774493666843 24.21 35.674278254428636 139.7377020731857 24.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-17f0c6aa-6251-44fa-99d3-54e83ae0bf42"/>
							<gml:surfaceMember xlink:href="#poly-00249201-28c9-434a-a524-2829ad5f04a9"/>
							<gml:surfaceMember xlink:href="#poly-7995ac7f-7623-47a4-9824-2e50e09103a4"/>
							<gml:surfaceMember xlink:href="#poly-ca1bbb93-a17e-4f67-857f-f2d92548886f"/>
							<gml:surfaceMember xlink:href="#poly-b5ae0088-4e17-4a45-b2c5-a83d8d15a216"/>
							<gml:surfaceMember xlink:href="#poly-e72d8d43-69a8-4dd2-a6c8-217e8f485883"/>
							<gml:surfaceMember xlink:href="#poly-f86d9508-83b9-4f79-ba4a-41e1d644547a"/>
							<gml:surfaceMember xlink:href="#poly-fa4df14c-0ce0-46c1-9f1e-854dd0352839"/>
							<gml:surfaceMember xlink:href="#poly-1ad76535-446d-429a-8a94-7dc216d9f894"/>
							<gml:surfaceMember xlink:href="#poly-3f9ee86c-7404-4b5a-b72c-5e4fc9bfcbb3"/>
							<gml:surfaceMember xlink:href="#poly-df47e19a-6359-47a4-8bd5-146a99cd29e4"/>
							<gml:surfaceMember xlink:href="#poly-6ee64ba2-ec03-4349-a725-1c8ca29029bb"/>
							<gml:surfaceMember xlink:href="#poly-7cfb20ad-f8a6-40ea-9132-15b1720efc9e"/>
							<gml:surfaceMember xlink:href="#poly-ca3da78e-83c7-4185-a05f-8d3809209789"/>
							<gml:surfaceMember xlink:href="#poly-68315c34-6345-42fb-b51a-8853d4bcc649"/>
							<gml:surfaceMember xlink:href="#poly-463b4370-9b75-491f-8402-b8135d7aca3e"/>
							<gml:surfaceMember xlink:href="#poly-b398dd76-ca34-4812-bbdb-89d17593e625"/>
							<gml:surfaceMember xlink:href="#poly-6e2d48e8-63ae-4e4c-ad4b-c83fd25a8ae9"/>
							<gml:surfaceMember xlink:href="#poly-adf25251-15c1-4503-9ce5-e40d1ebecf98"/>
							<gml:surfaceMember xlink:href="#poly-3f2bc8be-57f7-40eb-82ae-116bbc84e491"/>
							<gml:surfaceMember xlink:href="#poly-ce4302fb-201b-4196-9269-987267856394"/>
							<gml:surfaceMember xlink:href="#poly-3bbcbba5-17d8-413a-a89e-6c12b56df4a1"/>
							<gml:surfaceMember xlink:href="#poly-5f22c1c8-c01f-4052-932b-7efb82574adf"/>
							<gml:surfaceMember xlink:href="#poly-7fefd91b-170b-44c4-a2f4-b4679ceac9ef"/>
							<gml:surfaceMember xlink:href="#poly-175a6429-31fc-4fcc-9ea6-032ba71b495b"/>
							<gml:surfaceMember xlink:href="#poly-f24f4834-86f7-49f3-b9c0-ea4408dd077f"/>
							<gml:surfaceMember xlink:href="#poly-aa6f3f1d-eaae-4f04-94ac-a583a4863435"/>
							<gml:surfaceMember xlink:href="#poly-92571c09-876d-4e74-b0fa-a81903d3aacd"/>
							<gml:surfaceMember xlink:href="#poly-83789ddf-a98e-45b3-b622-372b521f9459"/>
							<gml:surfaceMember xlink:href="#poly-86f8c128-40c1-4ccc-89a7-1330c9d9afa5"/>
							<gml:surfaceMember xlink:href="#poly-c1a6bff2-2e3e-48d6-81ac-8a4f0d4e779b"/>
							<gml:surfaceMember xlink:href="#poly-a3323a19-c1fe-49b9-86a8-a6ba32ee7f5a"/>
							<gml:surfaceMember xlink:href="#poly-e4548ac2-a810-4726-a30f-f6259de5045a"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_682b0c96-4b88-4d7d-819a-f0ce912690ec_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2452e506-69e2-4f04-b893-fe23c6b5bb5e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2452e506-69e2-4f04-b893-fe23c6b5bb5e_0">
											<gml:posList>35.674194548321836 139.73763948253648 25.242 35.67418678512474 139.73761380803137 9.35 35.674194548321836 139.73763948253648 9.35 35.674194548321836 139.73763948253648 25.242</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4397fbb3-a2c2-4117-aec1-f6ff73530493">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4397fbb3-a2c2-4117-aec1-f6ff73530493_0">
											<gml:posList>35.674194548321836 139.73763948253648 25.242 35.67418678512474 139.73761380803137 25.242 35.67418678512474 139.73761380803137 9.35 35.674194548321836 139.73763948253648 25.242</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-452b41f3-51f0-4029-ad03-7a36d675dfe2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-452b41f3-51f0-4029-ad03-7a36d675dfe2_0">
											<gml:posList>35.6741992492615 139.73769088866413 27.377 35.67419235366534 139.73766807423434 24.955 35.6741992492615 139.73769088866413 24.955 35.6741992492615 139.73769088866413 27.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1329f4e3-3c88-46f1-ac81-ecf13a1b1470">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1329f4e3-3c88-46f1-ac81-ecf13a1b1470_0">
											<gml:posList>35.6741992492615 139.73769088866413 27.377 35.67419235366534 139.73766807423434 27.377 35.67419235366534 139.73766807423434 24.955 35.6741992492615 139.73769088866413 27.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4030f02-146e-41f3-af27-a466a6d57c42">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b4030f02-146e-41f3-af27-a466a6d57c42_0">
											<gml:posList>35.67420187774038 139.73766375462245 27.377 35.67419235366534 139.73766807423434 24.955 35.67419235366534 139.73766807423434 27.377 35.67420187774038 139.73766375462245 27.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-50743c9d-9198-4c3e-9ef9-e7aeab795b65">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-50743c9d-9198-4c3e-9ef9-e7aeab795b65_0">
											<gml:posList>35.67420187774038 139.73766375462245 27.377 35.67420187774038 139.73766375462245 24.955 35.67419235366534 139.73766807423434 24.955 35.67420187774038 139.73766375462245 27.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da04174e-6229-4f18-a4f8-266cf40d81d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da04174e-6229-4f18-a4f8-266cf40d81d4_0">
											<gml:posList>35.674194548321836 139.73763948253648 9.35 35.67420800997628 139.73763337968802 25.242 35.674194548321836 139.73763948253648 25.242 35.674194548321836 139.73763948253648 9.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c842a99e-dd35-4201-af9e-6154beaa4f4a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c842a99e-dd35-4201-af9e-6154beaa4f4a_0">
											<gml:posList>35.674194548321836 139.73763948253648 9.35 35.67420800997628 139.73763337968802 9.35 35.67420800997628 139.73763337968802 25.242 35.674194548321836 139.73763948253648 9.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4ae9c1bd-0bf1-4408-9b10-57d1c5b9ec24">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4ae9c1bd-0bf1-4408-9b10-57d1c5b9ec24_0">
											<gml:posList>35.67420187774038 139.73766375462245 27.377 35.67420592653123 139.73767714954244 24.955 35.67420187774038 139.73766375462245 24.955 35.67420187774038 139.73766375462245 27.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-547106a9-3eab-4ba7-a9f6-df1c2c6d12c4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-547106a9-3eab-4ba7-a9f6-df1c2c6d12c4_0">
											<gml:posList>35.67420187774038 139.73766375462245 27.377 35.67420592653123 139.73767714954244 27.377 35.67420592653123 139.73767714954244 24.955 35.67420187774038 139.73766375462245 27.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c62f92b2-5ff0-43b0-89fb-440f7a2b4dde">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c62f92b2-5ff0-43b0-89fb-440f7a2b4dde_0">
											<gml:posList>35.67422195615759 139.7376698616287 27.377 35.67420592653123 139.73767714954244 27.377 35.67422480297307 139.73767929218926 27.377 35.67422195615759 139.7376698616287 27.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e0a342c-696f-4c50-af41-8b55a729d07f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3e0a342c-696f-4c50-af41-8b55a729d07f_0">
											<gml:posList>35.67422480297307 139.73767929218926 27.377 35.67420592653123 139.73767714954244 27.377 35.6741992492615 139.73769088866413 27.377 35.67422480297307 139.73767929218926 27.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eaa6c8fa-6d53-4c15-b990-5b84cd61a623">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eaa6c8fa-6d53-4c15-b990-5b84cd61a623_0">
											<gml:posList>35.6741992492615 139.73769088866413 27.377 35.67420592653123 139.73767714954244 27.377 35.67419235366534 139.73766807423434 27.377 35.6741992492615 139.73769088866413 27.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eeb795f2-8e21-4904-9cdb-39f1e2018f5b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eeb795f2-8e21-4904-9cdb-39f1e2018f5b_0">
											<gml:posList>35.67420592653123 139.73767714954244 27.377 35.67420187774038 139.73766375462245 27.377 35.67419235366534 139.73766807423434 27.377 35.67420592653123 139.73767714954244 27.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b1da6422-062a-455f-8cca-34a64d642756">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b1da6422-062a-455f-8cca-34a64d642756_0">
											<gml:posList>35.67421382172479 139.73763073256796 25.242 35.67420800997628 139.73763337968802 9.35 35.67421382172479 139.73763073256796 9.35 35.67421382172479 139.73763073256796 25.242</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa090ad3-c12a-4d85-8b8c-8036c7e6d776">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aa090ad3-c12a-4d85-8b8c-8036c7e6d776_0">
											<gml:posList>35.67421382172479 139.73763073256796 25.242 35.67420800997628 139.73763337968802 25.242 35.67420800997628 139.73763337968802 9.35 35.67421382172479 139.73763073256796 25.242</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4acaaf97-bf54-438f-b7d9-bb51f8cdc417">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4acaaf97-bf54-438f-b7d9-bb51f8cdc417_0">
											<gml:posList>35.67422480297307 139.73767929218926 27.377 35.6741992492615 139.73769088866413 24.955 35.67422480297307 139.73767929218926 24.955 35.67422480297307 139.73767929218926 27.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-934ac75d-3681-4612-b8a4-4ba5daa33e82">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-934ac75d-3681-4612-b8a4-4ba5daa33e82_0">
											<gml:posList>35.67422480297307 139.73767929218926 27.377 35.6741992492615 139.73769088866413 27.377 35.6741992492615 139.73769088866413 24.955 35.67422480297307 139.73767929218926 27.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ba4c743-b6ec-4be7-9d64-a999440b5fbe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9ba4c743-b6ec-4be7-9d64-a999440b5fbe_0">
											<gml:posList>35.67420592653123 139.73767714954244 27.377 35.67422195615759 139.7376698616287 24.955 35.67420592653123 139.73767714954244 24.955 35.67420592653123 139.73767714954244 27.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-49f129c5-ad26-4b63-90a2-af0ab55f4995">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-49f129c5-ad26-4b63-90a2-af0ab55f4995_0">
											<gml:posList>35.67420592653123 139.73767714954244 27.377 35.67422195615759 139.7376698616287 27.377 35.67422195615759 139.7376698616287 24.955 35.67420592653123 139.73767714954244 27.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c2e6cd25-1eb1-4c06-88ed-cc54db5775e7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c2e6cd25-1eb1-4c06-88ed-cc54db5775e7_0">
											<gml:posList>35.67421692138076 139.73762939220623 25.242 35.67421382172479 139.73763073256796 25.242 35.67421820088944 139.73762883833936 24.999 35.67421692138076 139.73762939220623 25.242</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d2d36f7d-6701-43f2-b3b6-f8da74650b04">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d2d36f7d-6701-43f2-b3b6-f8da74650b04_0">
											<gml:posList>35.67421382172479 139.73763073256796 25.242 35.67421382172479 139.73763073256796 9.35 35.67421820088944 139.73762883833936 24.999 35.67421382172479 139.73763073256796 25.242</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e8141a9-5a52-459a-89fc-2eea2c8cd1a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4e8141a9-5a52-459a-89fc-2eea2c8cd1a6_0">
											<gml:posList>35.67421382172479 139.73763073256796 9.35 35.67421848923178 139.73762871648043 9.35 35.67421820088944 139.73762883833936 24.999 35.67421382172479 139.73763073256796 9.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7975a7f5-5afc-4dc0-9acd-177b1266848b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7975a7f5-5afc-4dc0-9acd-177b1266848b_0">
											<gml:posList>35.674216069137266 139.73760048378028 23.917 35.674223913627465 139.73762636808542 25.242 35.674223913627465 139.73762636808542 23.916 35.674216069137266 139.73760048378028 23.917</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a6cf62fb-f529-46e6-b511-d0fed014eca8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a6cf62fb-f529-46e6-b511-d0fed014eca8_0">
											<gml:posList>35.674216069137266 139.73760048378028 23.917 35.674216069137266 139.73760048378028 25.242 35.674223913627465 139.73762636808542 25.242 35.674216069137266 139.73760048378028 23.917</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7d2611df-e956-4048-b7a4-b06a5cc01e0d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7d2611df-e956-4048-b7a4-b06a5cc01e0d_0">
											<gml:posList>35.674223913627465 139.73762636808542 23.917 35.674216069137266 139.73760048378028 9.35 35.674216069137266 139.73760048378028 23.917 35.674223913627465 139.73762636808542 23.917</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35ee8434-0bb0-447e-a013-913527a323de">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-35ee8434-0bb0-447e-a013-913527a323de_0">
											<gml:posList>35.674223913627465 139.73762636808542 23.917 35.674223913627465 139.73762636808542 9.35 35.674216069137266 139.73760048378028 9.35 35.674223913627465 139.73762636808542 23.917</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ddabb62e-2f21-4735-a326-e32d2680ed9b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ddabb62e-2f21-4735-a326-e32d2680ed9b_0">
											<gml:posList>35.67422195615759 139.7376698616287 27.377 35.67422480297307 139.73767929218926 24.955 35.67422195615759 139.7376698616287 24.955 35.67422195615759 139.7376698616287 27.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-318dea3b-12e5-4112-8758-1fc791df9593">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-318dea3b-12e5-4112-8758-1fc791df9593_0">
											<gml:posList>35.67422195615759 139.7376698616287 27.377 35.67422480297307 139.73767929218926 27.377 35.67422480297307 139.73767929218926 24.955 35.67422195615759 139.7376698616287 27.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-725837c3-4cf3-4768-99dc-00bfb55d8158">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-725837c3-4cf3-4768-99dc-00bfb55d8158_0">
											<gml:posList>35.67418678512474 139.73761380803137 25.242 35.674216069137266 139.73760048378028 23.917 35.67418678512474 139.73761380803137 9.35 35.67418678512474 139.73761380803137 25.242</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37dc9def-0576-46b4-bb0f-3d1e4c330470">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-37dc9def-0576-46b4-bb0f-3d1e4c330470_0">
											<gml:posList>35.674216069137266 139.73760048378028 23.917 35.674216069137266 139.73760048378028 9.35 35.67418678512474 139.73761380803137 9.35 35.674216069137266 139.73760048378028 23.917</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f9e9d117-069b-4c76-94b0-fd7ef496a246">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f9e9d117-069b-4c76-94b0-fd7ef496a246_0">
											<gml:posList>35.67418678512474 139.73761380803137 25.242 35.674216069137266 139.73760048378028 25.242 35.674216069137266 139.73760048378028 23.917 35.67418678512474 139.73761380803137 25.242</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b66d478-85a3-4e81-8dbb-44584a30a3ba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5b66d478-85a3-4e81-8dbb-44584a30a3ba_0">
											<gml:posList>35.674194548321836 139.73763948253648 25.242 35.67420800997628 139.73763337968802 25.242 35.67418678512474 139.73761380803137 25.242 35.674194548321836 139.73763948253648 25.242</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff74412c-52dd-4246-b9b8-bdc1f1c8079b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ff74412c-52dd-4246-b9b8-bdc1f1c8079b_0">
											<gml:posList>35.67418678512474 139.73761380803137 25.242 35.67420800997628 139.73763337968802 25.242 35.674216069137266 139.73760048378028 25.242 35.67418678512474 139.73761380803137 25.242</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0707ec80-99e2-4294-b4d2-4c12d3db7b1c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0707ec80-99e2-4294-b4d2-4c12d3db7b1c_0">
											<gml:posList>35.67421692138076 139.73762939220623 25.242 35.674223913627465 139.73762636808542 25.242 35.674216069137266 139.73760048378028 25.242 35.67421692138076 139.73762939220623 25.242</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a8d9273-7377-4dac-bda7-91af1613febe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3a8d9273-7377-4dac-bda7-91af1613febe_0">
											<gml:posList>35.67421382172479 139.73763073256796 25.242 35.67421692138076 139.73762939220623 25.242 35.674216069137266 139.73760048378028 25.242 35.67421382172479 139.73763073256796 25.242</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e165e48c-7006-419e-b68c-770de42edcf4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e165e48c-7006-419e-b68c-770de42edcf4_0">
											<gml:posList>35.67420800997628 139.73763337968802 25.242 35.67421382172479 139.73763073256796 25.242 35.674216069137266 139.73760048378028 25.242 35.67420800997628 139.73763337968802 25.242</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-732dc7e3-f14c-4945-b3cf-d75b5a64c103">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-732dc7e3-f14c-4945-b3cf-d75b5a64c103_0">
											<gml:posList>35.67421820088944 139.73762883833936 24.999 35.674223913627465 139.73762636808542 23.916 35.674223913627465 139.73762636808542 25.242 35.67421820088944 139.73762883833936 24.999</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc80f2d1-18ba-4ae3-9221-5f6a9ce96117">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cc80f2d1-18ba-4ae3-9221-5f6a9ce96117_0">
											<gml:posList>35.674223913627465 139.73762636808542 25.242 35.67421692138076 139.73762939220623 25.242 35.67421820088944 139.73762883833936 24.999 35.674223913627465 139.73762636808542 25.242</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f3446d0f-10cd-4e06-867a-72ab39704e55">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f3446d0f-10cd-4e06-867a-72ab39704e55_0">
											<gml:posList>35.67421848923178 139.73762871648043 9.35 35.674223913627465 139.73762636808542 9.35 35.674223913627465 139.73762636808542 23.916 35.67421848923178 139.73762871648043 9.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c8286ed-56f4-484f-bfde-41f59d688c7b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c8286ed-56f4-484f-bfde-41f59d688c7b_0">
											<gml:posList>35.67421820088944 139.73762883833936 24.999 35.67421848923178 139.73762871648043 9.35 35.674223913627465 139.73762636808542 23.916 35.67421820088944 139.73762883833936 24.999</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c9e43c92-f1b1-4c27-b1d8-55f8f652c6ba">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67420800997628 139.73763337968802 9.35 35.67418678512474 139.73761380803137 9.35 35.674216069137266 139.73760048378028 9.35 35.67420800997628 139.73763337968802 9.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b38e8ea-25b2-4ffc-9a2b-9e2cf6add954">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674216069137266 139.73760048378028 9.35 35.674223913627465 139.73762636808542 9.35 35.67421848923178 139.73762871648043 9.35 35.674216069137266 139.73760048378028 9.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60658cb5-21c3-48c1-b059-7d3f13cdeed0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674194548321836 139.73763948253648 9.35 35.67418678512474 139.73761380803137 9.35 35.67420800997628 139.73763337968802 9.35 35.674194548321836 139.73763948253648 9.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bbbd5652-bb32-49df-837c-c2116a6c2375">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67420800997628 139.73763337968802 9.35 35.674216069137266 139.73760048378028 9.35 35.67421382172479 139.73763073256796 9.35 35.67420800997628 139.73763337968802 9.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8de3acef-a824-4a16-99de-ecd13c3eedd2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67421382172479 139.73763073256796 9.35 35.674216069137266 139.73760048378028 9.35 35.67421848923178 139.73762871648043 9.35 35.67421382172479 139.73763073256796 9.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f05b438-b67d-4910-8e36-e30f9dd8d5b2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67420187774038 139.73766375462245 24.955 35.67420592653123 139.73767714954244 24.955 35.67419235366534 139.73766807423434 24.955 35.67420187774038 139.73766375462245 24.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff4b786f-3a1c-437a-b066-19656e880225">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67419235366534 139.73766807423434 24.955 35.67420592653123 139.73767714954244 24.955 35.6741992492615 139.73769088866413 24.955 35.67419235366534 139.73766807423434 24.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e9676fc-d44b-4118-ba26-17e6e615b20b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6741992492615 139.73769088866413 24.955 35.67420592653123 139.73767714954244 24.955 35.67422480297307 139.73767929218926 24.955 35.6741992492615 139.73769088866413 24.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d0d4295-515f-4af3-bbd2-7264ec8631cd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67420592653123 139.73767714954244 24.955 35.67422195615759 139.7376698616287 24.955 35.67422480297307 139.73767929218926 24.955 35.67420592653123 139.73767714954244 24.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_682b0c96-4b88-4d7d-819a-f0ce912690ec_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d780fac7-2f4f-4297-93bb-7bb9db365353">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674185791341785 139.73770169742764 24.955 35.67417965488313 139.7376813786678 24.955 35.67418891764867 139.73767716983784 24.955 35.674195063121736 139.73769748858894 24.955 35.674185791341785 139.73770169742764 24.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-86fe7fef-3b26-4259-a95e-e01f3ae18aae">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67420745147327 139.73766784632863 31.912 35.67420026667885 139.7376440822201 31.912 35.6742108720039 139.73763926420887 31.912 35.67421805679927 139.7376630283201 31.912 35.67420745147327 139.73766784632863 31.912</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e58bc6f-30e4-4d9f-868c-ef5d929374fb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3e58bc6f-30e4-4d9f-868c-ef5d929374fb_0">
											<gml:posList>35.6742108720039 139.73763926420887 32.121 35.6742108720039 139.73763926420887 31.912 35.67420026667885 139.7376440822201 31.912 35.67420026667885 139.7376440822201 32.121 35.6742108720039 139.73763926420887 32.121</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-754d1bc9-4bac-4167-8270-4f3f1f731714">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-754d1bc9-4bac-4167-8270-4f3f1f731714_0">
											<gml:posList>35.6742108720039 139.73763926420887 32.121 35.67421805679927 139.7376630283201 32.121 35.67421805679927 139.7376630283201 31.912 35.6742108720039 139.73763926420887 31.912 35.6742108720039 139.73763926420887 32.121</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4aed07bb-541e-45e8-9007-1d109f1b807e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4aed07bb-541e-45e8-9007-1d109f1b807e_0">
											<gml:posList>35.67420745147327 139.73766784632863 32.121 35.67421805679927 139.7376630283201 32.121 35.6742108720039 139.73763926420887 32.121 35.67420026667885 139.7376440822201 32.121 35.67420745147327 139.73766784632863 32.121</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59fac157-3bdc-4977-abca-6592209a6f72">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-59fac157-3bdc-4977-abca-6592209a6f72_0">
											<gml:posList>35.67420745147327 139.73766784632863 32.121 35.67420026667885 139.7376440822201 32.121 35.67420026667885 139.7376440822201 31.912 35.67420745147327 139.73766784632863 31.912 35.67420745147327 139.73766784632863 32.121</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc29756f-1f7e-49ea-9ae1-c8d000714eed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bc29756f-1f7e-49ea-9ae1-c8d000714eed_0">
											<gml:posList>35.67421805679927 139.7376630283201 32.121 35.67420745147327 139.73766784632863 32.121 35.67420745147327 139.73766784632863 31.912 35.67421805679927 139.7376630283201 31.912 35.67421805679927 139.7376630283201 32.121</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-79cdac87-80f8-412d-8001-87fe9e77aee9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-79cdac87-80f8-412d-8001-87fe9e77aee9_0">
											<gml:posList>35.67418891764867 139.73767716983784 27.871 35.67418891764867 139.73767716983784 24.955 35.67417965488313 139.7376813786678 24.955 35.67417965488313 139.7376813786678 27.871 35.67418891764867 139.73767716983784 27.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-710380b6-3674-46cf-8890-cbe803a91d22">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-710380b6-3674-46cf-8890-cbe803a91d22_0">
											<gml:posList>35.674195063121736 139.73769748858894 24.955 35.67418891764867 139.73767716983784 24.955 35.67418891764867 139.73767716983784 27.871 35.674195063121736 139.73769748858894 27.871 35.674195063121736 139.73769748858894 24.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-50f53f3b-30f5-43d5-9d9b-7f94786bafe9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-50f53f3b-30f5-43d5-9d9b-7f94786bafe9_0">
											<gml:posList>35.674185791341785 139.73770169742764 27.871 35.674195063121736 139.73769748858894 27.871 35.67418891764867 139.73767716983784 27.871 35.67417965488313 139.7376813786678 27.871 35.674185791341785 139.73770169742764 27.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9c6ad85a-062a-4c9f-b153-e425a2b45368">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9c6ad85a-062a-4c9f-b153-e425a2b45368_0">
											<gml:posList>35.674185791341785 139.73770169742764 27.871 35.67417965488313 139.7376813786678 27.871 35.67417965488313 139.7376813786678 24.955 35.674185791341785 139.73770169742764 24.955 35.674185791341785 139.73770169742764 27.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-acee6950-f072-4b5d-8822-fe0fd1004ee5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-acee6950-f072-4b5d-8822-fe0fd1004ee5_0">
											<gml:posList>35.674185791341785 139.73770169742764 27.871 35.674185791341785 139.73770169742764 24.955 35.674195063121736 139.73769748858894 24.955 35.674195063121736 139.73769748858894 27.871 35.674185791341785 139.73770169742764 27.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-17f0c6aa-6251-44fa-99d3-54e83ae0bf42">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17f0c6aa-6251-44fa-99d3-54e83ae0bf42">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17f0c6aa-6251-44fa-99d3-54e83ae0bf42">
											<gml:posList>35.67419853386136 139.73765267868737 9.22 35.67419454833062 139.73763949358326 9.22 35.67421382172479 139.73763073256796 9.22 35.674223913627465 139.73762636808542 9.22 35.67421606912849 139.7376004727335 9.22 35.674243731259025 139.73758789054477 9.22 35.67427825442863 139.73770207318566 9.22 35.67418400490356 139.73774493666843 9.22 35.6741612305932 139.73766973525127 9.22 35.67419853386136 139.73765267868737 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-00249201-28c9-434a-a524-2829ad5f04a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-00249201-28c9-434a-a524-2829ad5f04a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-00249201-28c9-434a-a524-2829ad5f04a9">
											<gml:posList>35.67419454833062 139.73763949358326 32.572 35.67419839891698 139.73764166520354 32.572 35.67421204075804 139.73763545167216 32.572 35.67421382172479 139.73763073256796 32.572 35.67419454833062 139.73763949358326 32.572</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7995ac7f-7623-47a4-9824-2e50e09103a4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7995ac7f-7623-47a4-9824-2e50e09103a4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7995ac7f-7623-47a4-9824-2e50e09103a4">
											<gml:posList>35.67421382172479 139.73763073256796 32.572 35.67421204075804 139.73763545167216 32.572 35.674221349333486 139.73766620586585 32.572 35.67422520894184 139.73766838852416 32.572 35.67421382172479 139.73763073256796 32.572</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ca1bbb93-a17e-4f67-857f-f2d92548886f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca1bbb93-a17e-4f67-857f-f2d92548886f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca1bbb93-a17e-4f67-857f-f2d92548886f">
											<gml:posList>35.67421692138076 139.73762939220623 25.242 35.67421382172479 139.73763073256796 25.242 35.67422520894184 139.73766838852416 25.242 35.674226527586164 139.73767171203409 25.242 35.67421692138076 139.73762939220623 25.242</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b5ae0088-4e17-4a45-b2c5-a83d8d15a216">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b5ae0088-4e17-4a45-b2c5-a83d8d15a216">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b5ae0088-4e17-4a45-b2c5-a83d8d15a216">
											<gml:posList>35.67427825442863 139.73770207318566 18.526 35.674243731259025 139.73758789054477 18.526 35.67421606912849 139.7376004727335 23.917 35.674223913627465 139.73762636808542 23.917 35.67421692138076 139.73762939220623 25.242 35.67424369026225 139.73771778981492 25.242 35.67427825442863 139.73770207318566 18.526</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e72d8d43-69a8-4dd2-a6c8-217e8f485883">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e72d8d43-69a8-4dd2-a6c8-217e8f485883">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e72d8d43-69a8-4dd2-a6c8-217e8f485883">
											<gml:posList>35.674221349333486 139.73766620586585 31.912 35.67421204075804 139.73763545167216 31.912 35.67419839891698 139.73764166520354 31.912 35.67420769846835 139.7376724083567 31.912 35.674221349333486 139.73766620586585 31.912</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f86d9508-83b9-4f79-ba4a-41e1d644547a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f86d9508-83b9-4f79-ba4a-41e1d644547a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f86d9508-83b9-4f79-ba4a-41e1d644547a">
											<gml:posList>35.674205926522454 139.73767713849566 32.572 35.67420769846835 139.7376724083567 32.572 35.67419839891698 139.73764166520354 32.572 35.67419454833062 139.73763949358326 32.572 35.674205926522454 139.73767713849566 32.572</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fa4df14c-0ce0-46c1-9f1e-854dd0352839">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa4df14c-0ce0-46c1-9f1e-854dd0352839">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa4df14c-0ce0-46c1-9f1e-854dd0352839">
											<gml:posList>35.674165099197694 139.73767189580383 25.242 35.67419958219997 139.73765613508 25.242 35.67419853386136 139.73765267868737 25.242 35.6741612305932 139.73766973525127 25.242 35.674165099197694 139.73767189580383 25.242</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1ad76535-446d-429a-8a94-7dc216d9f894">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ad76535-446d-429a-8a94-7dc216d9f894">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ad76535-446d-429a-8a94-7dc216d9f894">
											<gml:posList>35.67422520894184 139.73766838852416 32.572 35.674221349333486 139.73766620586585 32.572 35.67420769846835 139.7376724083567 32.572 35.674205926522454 139.73767713849566 32.572 35.67422520894184 139.73766838852416 32.572</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3f9ee86c-7404-4b5a-b72c-5e4fc9bfcbb3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f9ee86c-7404-4b5a-b72c-5e4fc9bfcbb3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f9ee86c-7404-4b5a-b72c-5e4fc9bfcbb3">
											<gml:posList>35.67424369026225 139.73771778981492 25.242 35.67421692138076 139.73762939220623 25.242 35.674226527586164 139.73767171203409 25.242 35.6742398306548 139.73771560715372 25.242 35.67424369026225 139.73771778981492 25.242</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-df47e19a-6359-47a4-8bd5-146a99cd29e4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df47e19a-6359-47a4-8bd5-146a99cd29e4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df47e19a-6359-47a4-8bd5-146a99cd29e4">
											<gml:posList>35.6742398306548 139.73771560715372 24.955 35.674226527586164 139.73767171203409 24.955 35.67422520894184 139.73766838852416 24.955 35.674205926522454 139.73767713849566 24.955 35.67419958219997 139.73765613508 24.955 35.674165099197694 139.73767189580383 24.955 35.674185785857084 139.73774019547474 24.955 35.6742398306548 139.73771560715372 24.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6ee64ba2-ec03-4349-a725-1c8ca29029bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ee64ba2-ec03-4349-a725-1c8ca29029bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ee64ba2-ec03-4349-a725-1c8ca29029bb">
											<gml:posList>35.67418400490356 139.73774493666843 25.242 35.674185785857084 139.73774019547474 25.242 35.674165099197694 139.73767189580383 25.242 35.6741612305932 139.73766973525127 25.242 35.67418400490356 139.73774493666843 25.242</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7cfb20ad-f8a6-40ea-9132-15b1720efc9e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7cfb20ad-f8a6-40ea-9132-15b1720efc9e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7cfb20ad-f8a6-40ea-9132-15b1720efc9e">
											<gml:posList>35.67424369026225 139.73771778981492 25.242 35.6742398306548 139.73771560715372 25.242 35.674185785857084 139.73774019547474 25.242 35.67418400490356 139.73774493666843 25.242 35.67424369026225 139.73771778981492 25.242</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ca3da78e-83c7-4185-a05f-8d3809209789">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca3da78e-83c7-4185-a05f-8d3809209789">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca3da78e-83c7-4185-a05f-8d3809209789">
											<gml:posList>35.67418400490356 139.73774493666843 25.242 35.67418400490356 139.73774493666843 9.22 35.67427825442863 139.73770207318566 9.22 35.67427825442863 139.73770207318566 18.526 35.67424369026225 139.73771778981492 25.242 35.67418400490356 139.73774493666843 25.242</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-68315c34-6345-42fb-b51a-8853d4bcc649">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-68315c34-6345-42fb-b51a-8853d4bcc649">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-68315c34-6345-42fb-b51a-8853d4bcc649">
											<gml:posList>35.674243731259025 139.73758789054477 18.526 35.674243731259025 139.73758789054477 9.22 35.67421606912849 139.7376004727335 9.22 35.67421606912849 139.7376004727335 23.917 35.674243731259025 139.73758789054477 18.526</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-463b4370-9b75-491f-8402-b8135d7aca3e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-463b4370-9b75-491f-8402-b8135d7aca3e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-463b4370-9b75-491f-8402-b8135d7aca3e">
											<gml:posList>35.67421606912849 139.7376004727335 9.22 35.674223913627465 139.73762636808542 9.22 35.674223913627465 139.73762636808542 23.917 35.67421606912849 139.7376004727335 23.917 35.67421606912849 139.7376004727335 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b398dd76-ca34-4812-bbdb-89d17593e625">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b398dd76-ca34-4812-bbdb-89d17593e625">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b398dd76-ca34-4812-bbdb-89d17593e625">
											<gml:posList>35.674223913627465 139.73762636808542 23.917 35.674223913627465 139.73762636808542 9.22 35.67421382172479 139.73763073256796 9.22 35.67421382172479 139.73763073256796 25.242 35.67421692138076 139.73762939220623 25.242 35.674223913627465 139.73762636808542 23.917</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6e2d48e8-63ae-4e4c-ad4b-c83fd25a8ae9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e2d48e8-63ae-4e4c-ad4b-c83fd25a8ae9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e2d48e8-63ae-4e4c-ad4b-c83fd25a8ae9">
											<gml:posList>35.67419454833062 139.73763949358326 32.572 35.67421382172479 139.73763073256796 32.572 35.67421382172479 139.73763073256796 25.242 35.67421382172479 139.73763073256796 9.22 35.67419454833062 139.73763949358326 9.22 35.67419454833062 139.73763949358326 32.572</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-adf25251-15c1-4503-9ce5-e40d1ebecf98">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-adf25251-15c1-4503-9ce5-e40d1ebecf98">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-adf25251-15c1-4503-9ce5-e40d1ebecf98">
											<gml:posList>35.67419839891698 139.73764166520354 32.572 35.67419839891698 139.73764166520354 31.912 35.67421204075804 139.73763545167216 31.912 35.67421204075804 139.73763545167216 32.572 35.67419839891698 139.73764166520354 32.572</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3f2bc8be-57f7-40eb-82ae-116bbc84e491">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f2bc8be-57f7-40eb-82ae-116bbc84e491">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f2bc8be-57f7-40eb-82ae-116bbc84e491">
											<gml:posList>35.67427825442863 139.73770207318566 9.22 35.674243731259025 139.73758789054477 9.22 35.674243731259025 139.73758789054477 18.526 35.67427825442863 139.73770207318566 18.526 35.67427825442863 139.73770207318566 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ce4302fb-201b-4196-9269-987267856394">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce4302fb-201b-4196-9269-987267856394">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce4302fb-201b-4196-9269-987267856394">
											<gml:posList>35.67421382172479 139.73763073256796 32.572 35.67422520894184 139.73766838852416 32.572 35.67422520894184 139.73766838852416 25.242 35.67421382172479 139.73763073256796 25.242 35.67421382172479 139.73763073256796 32.572</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3bbcbba5-17d8-413a-a89e-6c12b56df4a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3bbcbba5-17d8-413a-a89e-6c12b56df4a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3bbcbba5-17d8-413a-a89e-6c12b56df4a1">
											<gml:posList>35.67421204075804 139.73763545167216 32.572 35.67421204075804 139.73763545167216 31.912 35.674221349333486 139.73766620586585 31.912 35.674221349333486 139.73766620586585 32.572 35.67421204075804 139.73763545167216 32.572</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5f22c1c8-c01f-4052-932b-7efb82574adf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f22c1c8-c01f-4052-932b-7efb82574adf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f22c1c8-c01f-4052-932b-7efb82574adf">
											<gml:posList>35.67420769846835 139.7376724083567 32.572 35.67420769846835 139.7376724083567 31.912 35.67419839891698 139.73764166520354 31.912 35.67419839891698 139.73764166520354 32.572 35.67420769846835 139.7376724083567 32.572</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7fefd91b-170b-44c4-a2f4-b4679ceac9ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7fefd91b-170b-44c4-a2f4-b4679ceac9ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7fefd91b-170b-44c4-a2f4-b4679ceac9ef">
											<gml:posList>35.67419958219997 139.73765613508 25.242 35.67419958219997 139.73765613508 24.955 35.674205926522454 139.73767713849566 24.955 35.674205926522454 139.73767713849566 32.572 35.67419454833062 139.73763949358326 32.572 35.67419454833062 139.73763949358326 9.22 35.67419853386136 139.73765267868737 9.22 35.67419853386136 139.73765267868737 25.242 35.67419958219997 139.73765613508 25.242</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-175a6429-31fc-4fcc-9ea6-032ba71b495b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-175a6429-31fc-4fcc-9ea6-032ba71b495b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-175a6429-31fc-4fcc-9ea6-032ba71b495b">
											<gml:posList>35.67419853386136 139.73765267868737 9.22 35.6741612305932 139.73766973525127 9.22 35.6741612305932 139.73766973525127 25.242 35.67419853386136 139.73765267868737 25.242 35.67419853386136 139.73765267868737 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f24f4834-86f7-49f3-b9c0-ea4408dd077f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f24f4834-86f7-49f3-b9c0-ea4408dd077f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f24f4834-86f7-49f3-b9c0-ea4408dd077f">
											<gml:posList>35.674165099197694 139.73767189580383 25.242 35.674165099197694 139.73767189580383 24.955 35.67419958219997 139.73765613508 24.955 35.67419958219997 139.73765613508 25.242 35.674165099197694 139.73767189580383 25.242</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aa6f3f1d-eaae-4f04-94ac-a583a4863435">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa6f3f1d-eaae-4f04-94ac-a583a4863435">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa6f3f1d-eaae-4f04-94ac-a583a4863435">
											<gml:posList>35.674221349333486 139.73766620586585 32.572 35.674221349333486 139.73766620586585 31.912 35.67420769846835 139.7376724083567 31.912 35.67420769846835 139.7376724083567 32.572 35.674221349333486 139.73766620586585 32.572</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-92571c09-876d-4e74-b0fa-a81903d3aacd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-92571c09-876d-4e74-b0fa-a81903d3aacd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-92571c09-876d-4e74-b0fa-a81903d3aacd">
											<gml:posList>35.67422520894184 139.73766838852416 25.242 35.67422520894184 139.73766838852416 24.955 35.674226527586164 139.73767171203409 24.955 35.674226527586164 139.73767171203409 25.242 35.67422520894184 139.73766838852416 25.242</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-83789ddf-a98e-45b3-b622-372b521f9459">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83789ddf-a98e-45b3-b622-372b521f9459">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83789ddf-a98e-45b3-b622-372b521f9459">
											<gml:posList>35.674205926522454 139.73767713849566 32.572 35.674205926522454 139.73767713849566 24.955 35.67422520894184 139.73766838852416 24.955 35.67422520894184 139.73766838852416 25.242 35.67422520894184 139.73766838852416 32.572 35.674205926522454 139.73767713849566 32.572</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-86f8c128-40c1-4ccc-89a7-1330c9d9afa5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-86f8c128-40c1-4ccc-89a7-1330c9d9afa5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-86f8c128-40c1-4ccc-89a7-1330c9d9afa5">
											<gml:posList>35.674226527586164 139.73767171203409 25.242 35.674226527586164 139.73767171203409 24.955 35.6742398306548 139.73771560715372 24.955 35.6742398306548 139.73771560715372 25.242 35.674226527586164 139.73767171203409 25.242</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c1a6bff2-2e3e-48d6-81ac-8a4f0d4e779b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c1a6bff2-2e3e-48d6-81ac-8a4f0d4e779b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c1a6bff2-2e3e-48d6-81ac-8a4f0d4e779b">
											<gml:posList>35.674185785857084 139.73774019547474 25.242 35.674185785857084 139.73774019547474 24.955 35.674165099197694 139.73767189580383 24.955 35.674165099197694 139.73767189580383 25.242 35.674185785857084 139.73774019547474 25.242</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a3323a19-c1fe-49b9-86a8-a6ba32ee7f5a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a3323a19-c1fe-49b9-86a8-a6ba32ee7f5a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a3323a19-c1fe-49b9-86a8-a6ba32ee7f5a">
											<gml:posList>35.6741612305932 139.73766973525127 9.22 35.67418400490356 139.73774493666843 9.22 35.67418400490356 139.73774493666843 25.242 35.6741612305932 139.73766973525127 25.242 35.6741612305932 139.73766973525127 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e4548ac2-a810-4726-a30f-f6259de5045a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e4548ac2-a810-4726-a30f-f6259de5045a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e4548ac2-a810-4726-a30f-f6259de5045a">
											<gml:posList>35.6742398306548 139.73771560715372 25.242 35.6742398306548 139.73771560715372 24.955 35.674185785857084 139.73774019547474 24.955 35.674185785857084 139.73774019547474 25.242 35.6742398306548 139.73771560715372 25.242</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-3127</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">106.3631</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1221</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>