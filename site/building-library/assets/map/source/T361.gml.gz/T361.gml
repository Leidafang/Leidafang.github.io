<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_68750951-dae8-44a7-97aa-2fd5cff08d8e">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門駅南地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">21.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>7</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.6686215554065 139.7497571533144 0 35.668640923432626 139.74976655538237 0 35.66864901760904 139.74974035682877 0 35.66869218991943 139.74976132136507 0 35.668720468375945 139.74967387359652 0 35.66865825262507 139.7496436724068 0 35.6686215554065 139.7497571533144 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6686215554065 139.7497571533144 5.61 35.66865825262507 139.7496436724068 5.61 35.668720468375945 139.74967387359652 5.61 35.66869218991943 139.74976132136507 5.61 35.66864901760904 139.74974035682877 5.61 35.668640923432626 139.74976655538237 5.61 35.6686215554065 139.7497571533144 5.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6686215554065 139.7497571533144 5.61 35.668640923432626 139.74976655538237 5.61 35.668640923432626 139.74976655538237 27.04 35.6686215554065 139.7497571533144 27.04 35.6686215554065 139.7497571533144 5.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668640923432626 139.74976655538237 5.61 35.66864901760904 139.74974035682877 5.61 35.66864901760904 139.74974035682877 27.04 35.668640923432626 139.74976655538237 27.04 35.668640923432626 139.74976655538237 5.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66864901760904 139.74974035682877 5.61 35.66869218991943 139.74976132136507 5.61 35.66869218991943 139.74976132136507 27.04 35.66864901760904 139.74974035682877 27.04 35.66864901760904 139.74974035682877 5.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66869218991943 139.74976132136507 5.61 35.668720468375945 139.74967387359652 5.61 35.668720468375945 139.74967387359652 27.04 35.66869218991943 139.74976132136507 27.04 35.66869218991943 139.74976132136507 5.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668720468375945 139.74967387359652 5.61 35.66865825262507 139.7496436724068 5.61 35.66865825262507 139.7496436724068 27.04 35.668720468375945 139.74967387359652 27.04 35.668720468375945 139.74967387359652 5.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66865825262507 139.7496436724068 5.61 35.6686215554065 139.7497571533144 5.61 35.6686215554065 139.7497571533144 27.04 35.66865825262507 139.7496436724068 27.04 35.66865825262507 139.7496436724068 5.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6686215554065 139.7497571533144 27.04 35.668640923432626 139.74976655538237 27.04 35.66864901760904 139.74974035682877 27.04 35.66869218991943 139.74976132136507 27.04 35.668720468375945 139.74967387359652 27.04 35.66865825262507 139.7496436724068 27.04 35.6686215554065 139.7497571533144 27.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-476fc146-cdbc-4d05-870a-4929e5dd39cb"/>
							<gml:surfaceMember xlink:href="#poly-5b5e6475-b065-4408-bc8a-4cc445dfbb5a"/>
							<gml:surfaceMember xlink:href="#poly-0191b9dc-2b35-49cf-9839-68598dbc1d6e"/>
							<gml:surfaceMember xlink:href="#poly-520243f5-6f07-499b-a6b6-b9cffad2a21f"/>
							<gml:surfaceMember xlink:href="#poly-ed3c2778-5fec-46dd-9a33-609d3dce5d56"/>
							<gml:surfaceMember xlink:href="#poly-0373c732-64a9-4a18-8b4a-6ff981623010"/>
							<gml:surfaceMember xlink:href="#poly-73a3e655-c191-4703-b033-91df7b3204f1"/>
							<gml:surfaceMember xlink:href="#poly-7f53bd16-90d2-4097-8600-b5dd9c90bf65"/>
							<gml:surfaceMember xlink:href="#poly-1e26ab70-8cc5-43f7-8d64-6cd8ee1c1ab3"/>
							<gml:surfaceMember xlink:href="#poly-0bb6fc89-f800-4bac-9838-bb6e126dd3cc"/>
							<gml:surfaceMember xlink:href="#poly-809bf131-2c60-47d8-b455-b9dde6067452"/>
							<gml:surfaceMember xlink:href="#poly-65fcf3f7-88f0-475f-9c76-11e1dca15815"/>
							<gml:surfaceMember xlink:href="#poly-e7c17919-d7c1-4cbb-837f-99f2afa4d676"/>
							<gml:surfaceMember xlink:href="#poly-1a88a724-c093-4788-9049-c80796bcdade"/>
							<gml:surfaceMember xlink:href="#poly-e8631f19-4406-4975-a4f2-dd2fb5843578"/>
							<gml:surfaceMember xlink:href="#poly-fba71ae6-b209-4bef-8cd2-e9e067929646"/>
							<gml:surfaceMember xlink:href="#poly-8ccca192-1b07-49ee-ad52-0e2436f3a712"/>
							<gml:surfaceMember xlink:href="#poly-8fcee22a-b342-47ec-8bba-6bf98912995d"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_68750951-dae8-44a7-97aa-2fd5cff08d8e_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-534a34b2-02ab-453d-8d63-cb821453a755">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668683771129395 139.74978735457847 5.61 35.66864091441888 139.74976655539174 5.61 35.66864901760133 139.74974034578275 5.61 35.66869218991942 139.74976132136507 5.61 35.668683771129395 139.74978735457847 5.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f5a90b13-301b-4d0f-a06c-49a27193fc5a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f5a90b13-301b-4d0f-a06c-49a27193fc5a_0">
											<gml:posList>35.66869218991942 139.74976132136507 32.3 35.66869218991942 139.74976132136507 5.61 35.66864901760133 139.74974034578275 5.61 35.66864901760133 139.74974034578275 32.3 35.66869218991942 139.74976132136507 32.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4ea64e25-abe9-4ad8-a2b8-c007166ef15f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4ea64e25-abe9-4ad8-a2b8-c007166ef15f_0">
											<gml:posList>35.66864901760133 139.74974034578275 32.3 35.66864901760133 139.74974034578275 5.61 35.66864091441888 139.74976655539174 5.61 35.66864091441888 139.74976655539174 32.3 35.66864901760133 139.74974034578275 32.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-490d3732-4d99-4529-8a2c-ceaf2473aef8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-490d3732-4d99-4529-8a2c-ceaf2473aef8_0">
											<gml:posList>35.66869218991942 139.74976132136507 32.3 35.66864901760133 139.74974034578275 32.3 35.66864091441888 139.74976655539174 32.3 35.668683771129395 139.74978735457847 32.3 35.66869218991942 139.74976132136507 32.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-476f51bb-37f6-4b82-912a-1ae24d68d1a7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-476f51bb-37f6-4b82-912a-1ae24d68d1a7_0">
											<gml:posList>35.668683771129395 139.74978735457847 32.3 35.668683771129395 139.74978735457847 5.61 35.66869218991942 139.74976132136507 5.61 35.66869218991942 139.74976132136507 32.3 35.668683771129395 139.74978735457847 32.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61b9f8aa-e1b3-4504-821c-10ad7a235c45">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-61b9f8aa-e1b3-4504-821c-10ad7a235c45_0">
											<gml:posList>35.66864091441888 139.74976655539174 32.3 35.66864091441888 139.74976655539174 5.61 35.668683771129395 139.74978735457847 5.61 35.668683771129395 139.74978735457847 32.3 35.66864091441888 139.74976655539174 32.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-476fc146-cdbc-4d05-870a-4929e5dd39cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-476fc146-cdbc-4d05-870a-4929e5dd39cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-476fc146-cdbc-4d05-870a-4929e5dd39cb">
											<gml:posList>35.66865825262504 139.7496436724068 5.61 35.66872046837593 139.74967387359652 5.61 35.66869218991942 139.74976132136507 5.61 35.668649017609006 139.74974035682877 5.61 35.66864092343261 139.74976655538237 5.61 35.668621555406496 139.7497571533144 5.61 35.66865825262504 139.7496436724068 5.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5b5e6475-b065-4408-bc8a-4cc445dfbb5a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b5e6475-b065-4408-bc8a-4cc445dfbb5a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b5e6475-b065-4408-bc8a-4cc445dfbb5a">
											<gml:posList>35.66865825262504 139.7496436724068 22.4 35.66863719671216 139.74970878858068 32.7 35.66869941245465 139.7497390008591 32.7 35.66872046837593 139.74967387359652 22.4 35.66865825262504 139.7496436724068 22.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0191b9dc-2b35-49cf-9839-68598dbc1d6e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0191b9dc-2b35-49cf-9839-68598dbc1d6e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0191b9dc-2b35-49cf-9839-68598dbc1d6e">
											<gml:posList>35.66862998319617 139.74973110906262 32.7 35.668631668149686 139.74973022362425 32.7 35.668637928250895 139.7497108423775 32.7 35.66863719671216 139.74970878858068 32.7 35.66862998319617 139.74973110906262 32.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-520243f5-6f07-499b-a6b6-b9cffad2a21f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-520243f5-6f07-499b-a6b6-b9cffad2a21f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-520243f5-6f07-499b-a6b6-b9cffad2a21f">
											<gml:posList>35.66863719671216 139.74970878858068 32.7 35.668637928250895 139.7497108423775 32.7 35.668697736507134 139.74973987524262 32.7 35.66869941245465 139.7497390008591 32.7 35.66863719671216 139.74970878858068 32.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ed3c2778-5fec-46dd-9a33-609d3dce5d56">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed3c2778-5fec-46dd-9a33-609d3dce5d56">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed3c2778-5fec-46dd-9a33-609d3dce5d56">
											<gml:posList>35.668697736507134 139.74973987524262 32.419 35.668637928250895 139.7497108423775 32.419 35.668631668149686 139.74973022362425 32.419 35.66869146738762 139.74975925651097 32.419 35.668697736507134 139.74973987524262 32.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0373c732-64a9-4a18-8b4a-6ff981623010">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0373c732-64a9-4a18-8b4a-6ff981623010">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0373c732-64a9-4a18-8b4a-6ff981623010">
											<gml:posList>35.66869218991942 139.74976132136507 32.7 35.66869146738762 139.74975925651097 32.7 35.668631668149686 139.74973022362425 32.7 35.66862998319617 139.74973110906262 32.7 35.66869218991942 139.74976132136507 32.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-73a3e655-c191-4703-b033-91df7b3204f1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73a3e655-c191-4703-b033-91df7b3204f1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73a3e655-c191-4703-b033-91df7b3204f1">
											<gml:posList>35.668649017609006 139.74974035682877 31.1 35.66862998319617 139.74973110906262 31.1 35.668621555406496 139.7497571533144 31.1 35.66864092343261 139.74976655538237 31.1 35.668649017609006 139.74974035682877 31.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7f53bd16-90d2-4097-8600-b5dd9c90bf65">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f53bd16-90d2-4097-8600-b5dd9c90bf65">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f53bd16-90d2-4097-8600-b5dd9c90bf65">
											<gml:posList>35.66869941245465 139.7497390008591 32.7 35.668697736507134 139.74973987524262 32.7 35.66869146738762 139.74975925651097 32.7 35.66869218991942 139.74976132136507 32.7 35.66869941245465 139.7497390008591 32.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1e26ab70-8cc5-43f7-8d64-6cd8ee1c1ab3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e26ab70-8cc5-43f7-8d64-6cd8ee1c1ab3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e26ab70-8cc5-43f7-8d64-6cd8ee1c1ab3">
											<gml:posList>35.668637928250895 139.7497108423775 32.7 35.668637928250895 139.7497108423775 32.419 35.668697736507134 139.74973987524262 32.419 35.668697736507134 139.74973987524262 32.7 35.668637928250895 139.7497108423775 32.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0bb6fc89-f800-4bac-9838-bb6e126dd3cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0bb6fc89-f800-4bac-9838-bb6e126dd3cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0bb6fc89-f800-4bac-9838-bb6e126dd3cc">
											<gml:posList>35.668621555406496 139.7497571533144 5.61 35.66864092343261 139.74976655538237 5.61 35.66864092343261 139.74976655538237 31.1 35.668621555406496 139.7497571533144 31.1 35.668621555406496 139.7497571533144 5.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-809bf131-2c60-47d8-b455-b9dde6067452">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-809bf131-2c60-47d8-b455-b9dde6067452">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-809bf131-2c60-47d8-b455-b9dde6067452">
											<gml:posList>35.668631668149686 139.74973022362425 32.7 35.668631668149686 139.74973022362425 32.419 35.668637928250895 139.7497108423775 32.419 35.668637928250895 139.7497108423775 32.7 35.668631668149686 139.74973022362425 32.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-65fcf3f7-88f0-475f-9c76-11e1dca15815">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65fcf3f7-88f0-475f-9c76-11e1dca15815">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65fcf3f7-88f0-475f-9c76-11e1dca15815">
											<gml:posList>35.66862998319617 139.74973110906262 32.7 35.66863719671216 139.74970878858068 32.7 35.66865825262504 139.7496436724068 22.4 35.66865825262504 139.7496436724068 5.61 35.668621555406496 139.7497571533144 5.61 35.668621555406496 139.7497571533144 31.1 35.66862998319617 139.74973110906262 31.1 35.66862998319617 139.74973110906262 32.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e7c17919-d7c1-4cbb-837f-99f2afa4d676">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e7c17919-d7c1-4cbb-837f-99f2afa4d676">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e7c17919-d7c1-4cbb-837f-99f2afa4d676">
											<gml:posList>35.66864092343261 139.74976655538237 5.61 35.668649017609006 139.74974035682877 5.61 35.668649017609006 139.74974035682877 31.1 35.66864092343261 139.74976655538237 31.1 35.66864092343261 139.74976655538237 5.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1a88a724-c093-4788-9049-c80796bcdade">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a88a724-c093-4788-9049-c80796bcdade">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a88a724-c093-4788-9049-c80796bcdade">
											<gml:posList>35.668649017609006 139.74974035682877 31.1 35.668649017609006 139.74974035682877 5.61 35.66869218991942 139.74976132136507 5.61 35.66869218991942 139.74976132136507 32.7 35.66862998319617 139.74973110906262 32.7 35.66862998319617 139.74973110906262 31.1 35.668649017609006 139.74974035682877 31.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e8631f19-4406-4975-a4f2-dd2fb5843578">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8631f19-4406-4975-a4f2-dd2fb5843578">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8631f19-4406-4975-a4f2-dd2fb5843578">
											<gml:posList>35.66869146738762 139.74975925651097 32.7 35.66869146738762 139.74975925651097 32.419 35.668631668149686 139.74973022362425 32.419 35.668631668149686 139.74973022362425 32.7 35.66869146738762 139.74975925651097 32.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fba71ae6-b209-4bef-8cd2-e9e067929646">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fba71ae6-b209-4bef-8cd2-e9e067929646">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fba71ae6-b209-4bef-8cd2-e9e067929646">
											<gml:posList>35.66872046837593 139.74967387359652 5.61 35.66865825262504 139.7496436724068 5.61 35.66865825262504 139.7496436724068 22.4 35.66872046837593 139.74967387359652 22.4 35.66872046837593 139.74967387359652 5.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8ccca192-1b07-49ee-ad52-0e2436f3a712">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ccca192-1b07-49ee-ad52-0e2436f3a712">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ccca192-1b07-49ee-ad52-0e2436f3a712">
											<gml:posList>35.668697736507134 139.74973987524262 32.7 35.668697736507134 139.74973987524262 32.419 35.66869146738762 139.74975925651097 32.419 35.66869146738762 139.74975925651097 32.7 35.668697736507134 139.74973987524262 32.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8fcee22a-b342-47ec-8bba-6bf98912995d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8fcee22a-b342-47ec-8bba-6bf98912995d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8fcee22a-b342-47ec-8bba-6bf98912995d">
											<gml:posList>35.66869218991942 139.74976132136507 32.7 35.66869218991942 139.74976132136507 5.61 35.66872046837593 139.74967387359652 5.61 35.66872046837593 139.74967387359652 22.4 35.66869941245465 139.7497390008591 32.7 35.66869218991942 139.74976132136507 32.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7432</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">82.0422</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>