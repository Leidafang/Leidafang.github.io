<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_690bdd16-db28-41ae-96b4-f6c3240d33ef">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門駅南地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">33.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66844516025247 139.74916706136122 0 35.668526799164326 139.74920793425318 0 35.66862484308554 139.74891389683773 0 35.66853503475625 139.74886892368642 0 35.668493251186796 139.74884907385447 0 35.668504621757094 139.74881659767448 0 35.66850552126909 139.74881394568587 0 35.66835385684932 139.74873788828222 0 35.6683017768366 139.7488939123794 0 35.66828518576769 139.74888564537227 0 35.66826467752302 139.7489470825577 0 35.66826242331695 139.7489459803332 0 35.66825369842149 139.74897227891768 0 35.668265240094556 139.74897812113824 0 35.66826721901343 139.74897226469272 0 35.66832490918578 139.74900124387088 0 35.6682814217897 139.74913558652517 0 35.6684308046468 139.74921044299342 0 35.66844516025247 139.74916706136122 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66844516025247 139.74916706136122 5.32 35.6684308046468 139.74921044299342 5.32 35.6682814217897 139.74913558652517 5.32 35.66832490918578 139.74900124387088 5.32 35.66826721901343 139.74897226469272 5.32 35.668265240094556 139.74897812113824 5.32 35.66825369842149 139.74897227891768 5.32 35.66826242331695 139.7489459803332 5.32 35.66826467752302 139.7489470825577 5.32 35.66828518576769 139.74888564537227 5.32 35.6683017768366 139.7488939123794 5.32 35.66835385684932 139.74873788828222 5.32 35.66850552126909 139.74881394568587 5.32 35.668504621757094 139.74881659767448 5.32 35.668493251186796 139.74884907385447 5.32 35.66853503475625 139.74886892368642 5.32 35.66862484308554 139.74891389683773 5.32 35.668526799164326 139.74920793425318 5.32 35.66844516025247 139.74916706136122 5.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66844516025247 139.74916706136122 5.32 35.668526799164326 139.74920793425318 5.32 35.668526799164326 139.74920793425318 34.42 35.66844516025247 139.74916706136122 34.42 35.66844516025247 139.74916706136122 5.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668526799164326 139.74920793425318 5.32 35.66862484308554 139.74891389683773 5.32 35.66862484308554 139.74891389683773 34.42 35.668526799164326 139.74920793425318 34.42 35.668526799164326 139.74920793425318 5.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66862484308554 139.74891389683773 5.32 35.66853503475625 139.74886892368642 5.32 35.66853503475625 139.74886892368642 34.42 35.66862484308554 139.74891389683773 34.42 35.66862484308554 139.74891389683773 5.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66853503475625 139.74886892368642 5.32 35.668493251186796 139.74884907385447 5.32 35.668493251186796 139.74884907385447 34.42 35.66853503475625 139.74886892368642 34.42 35.66853503475625 139.74886892368642 5.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668493251186796 139.74884907385447 5.32 35.668504621757094 139.74881659767448 5.32 35.668504621757094 139.74881659767448 34.42 35.668493251186796 139.74884907385447 34.42 35.668493251186796 139.74884907385447 5.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668504621757094 139.74881659767448 5.32 35.66850552126909 139.74881394568587 5.32 35.66850552126909 139.74881394568587 34.42 35.668504621757094 139.74881659767448 34.42 35.668504621757094 139.74881659767448 5.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66850552126909 139.74881394568587 5.32 35.66835385684932 139.74873788828222 5.32 35.66835385684932 139.74873788828222 34.42 35.66850552126909 139.74881394568587 34.42 35.66850552126909 139.74881394568587 5.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66835385684932 139.74873788828222 5.32 35.6683017768366 139.7488939123794 5.32 35.6683017768366 139.7488939123794 34.42 35.66835385684932 139.74873788828222 34.42 35.66835385684932 139.74873788828222 5.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6683017768366 139.7488939123794 5.32 35.66828518576769 139.74888564537227 5.32 35.66828518576769 139.74888564537227 34.42 35.6683017768366 139.7488939123794 34.42 35.6683017768366 139.7488939123794 5.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66828518576769 139.74888564537227 5.32 35.66826467752302 139.7489470825577 5.32 35.66826467752302 139.7489470825577 34.42 35.66828518576769 139.74888564537227 34.42 35.66828518576769 139.74888564537227 5.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66826467752302 139.7489470825577 5.32 35.66826242331695 139.7489459803332 5.32 35.66826242331695 139.7489459803332 34.42 35.66826467752302 139.7489470825577 34.42 35.66826467752302 139.7489470825577 5.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66826242331695 139.7489459803332 5.32 35.66825369842149 139.74897227891768 5.32 35.66825369842149 139.74897227891768 34.42 35.66826242331695 139.7489459803332 34.42 35.66826242331695 139.7489459803332 5.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66825369842149 139.74897227891768 5.32 35.668265240094556 139.74897812113824 5.32 35.668265240094556 139.74897812113824 34.42 35.66825369842149 139.74897227891768 34.42 35.66825369842149 139.74897227891768 5.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668265240094556 139.74897812113824 5.32 35.66826721901343 139.74897226469272 5.32 35.66826721901343 139.74897226469272 34.42 35.668265240094556 139.74897812113824 34.42 35.668265240094556 139.74897812113824 5.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66826721901343 139.74897226469272 5.32 35.66832490918578 139.74900124387088 5.32 35.66832490918578 139.74900124387088 34.42 35.66826721901343 139.74897226469272 34.42 35.66826721901343 139.74897226469272 5.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66832490918578 139.74900124387088 5.32 35.6682814217897 139.74913558652517 5.32 35.6682814217897 139.74913558652517 34.42 35.66832490918578 139.74900124387088 34.42 35.66832490918578 139.74900124387088 5.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6682814217897 139.74913558652517 5.32 35.6684308046468 139.74921044299342 5.32 35.6684308046468 139.74921044299342 34.42 35.6682814217897 139.74913558652517 34.42 35.6682814217897 139.74913558652517 5.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6684308046468 139.74921044299342 5.32 35.66844516025247 139.74916706136122 5.32 35.66844516025247 139.74916706136122 34.42 35.6684308046468 139.74921044299342 34.42 35.6684308046468 139.74921044299342 5.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66844516025247 139.74916706136122 34.42 35.668526799164326 139.74920793425318 34.42 35.66862484308554 139.74891389683773 34.42 35.66853503475625 139.74886892368642 34.42 35.668493251186796 139.74884907385447 34.42 35.668504621757094 139.74881659767448 34.42 35.66850552126909 139.74881394568587 34.42 35.66835385684932 139.74873788828222 34.42 35.6683017768366 139.7488939123794 34.42 35.66828518576769 139.74888564537227 34.42 35.66826467752302 139.7489470825577 34.42 35.66826242331695 139.7489459803332 34.42 35.66825369842149 139.74897227891768 34.42 35.668265240094556 139.74897812113824 34.42 35.66826721901343 139.74897226469272 34.42 35.66832490918578 139.74900124387088 34.42 35.6682814217897 139.74913558652517 34.42 35.6684308046468 139.74921044299342 34.42 35.66844516025247 139.74916706136122 34.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-7333b957-9ed7-4239-8c92-557787fb2084"/>
							<gml:surfaceMember xlink:href="#poly-0ecde677-371a-41a2-8b51-da9a068f4cc9"/>
							<gml:surfaceMember xlink:href="#poly-9b92d5af-61b4-4f95-bb2c-bcb15ef8e5be"/>
							<gml:surfaceMember xlink:href="#poly-1ad76773-253c-4c76-ad89-efcf691a2918"/>
							<gml:surfaceMember xlink:href="#poly-ed5a1a15-0f83-4028-8b83-b872ac4d71d0"/>
							<gml:surfaceMember xlink:href="#poly-e78fa11f-590f-40a4-80ce-5c9a322b67c4"/>
							<gml:surfaceMember xlink:href="#poly-838151a6-9ded-4af6-adba-e67cd1aba263"/>
							<gml:surfaceMember xlink:href="#poly-7f2f0f9b-0c2c-4875-a52b-81347146f86c"/>
							<gml:surfaceMember xlink:href="#poly-902f6126-d1ae-4a98-aac9-797c3bb2aabc"/>
							<gml:surfaceMember xlink:href="#poly-74988eca-142d-4581-b25e-454ddfa456bc"/>
							<gml:surfaceMember xlink:href="#poly-ff030566-29eb-4fc2-be26-8f6fd8165503"/>
							<gml:surfaceMember xlink:href="#poly-b5d75e18-26e2-4c98-a188-40233f5bf1f2"/>
							<gml:surfaceMember xlink:href="#poly-243f7385-af5e-4fac-a0d8-55312aaacd89"/>
							<gml:surfaceMember xlink:href="#poly-79f5ae62-669c-4dcb-a943-ec7919bf18b8"/>
							<gml:surfaceMember xlink:href="#poly-0d7c7725-63d9-469b-b9e7-22db1deb3f31"/>
							<gml:surfaceMember xlink:href="#poly-1a4fb30b-17df-475d-bcb3-23f5d11fdc77"/>
							<gml:surfaceMember xlink:href="#poly-102608b4-1f2f-4907-851c-d427813d4304"/>
							<gml:surfaceMember xlink:href="#poly-19317fb1-9f5b-438a-b8b4-ebdd6b49f519"/>
							<gml:surfaceMember xlink:href="#poly-11f677ee-e2cd-4774-b420-0c3eeef8448b"/>
							<gml:surfaceMember xlink:href="#poly-af42e2bc-d3e1-4a46-a695-cc6504dc61ae"/>
							<gml:surfaceMember xlink:href="#poly-c70f0f5e-02ed-446d-a15d-055c32ac05fe"/>
							<gml:surfaceMember xlink:href="#poly-3951e3c9-eb8d-4e5c-ac19-c59fdbdce768"/>
							<gml:surfaceMember xlink:href="#poly-bd6287ec-3efe-4c50-95ac-f63608b41d89"/>
							<gml:surfaceMember xlink:href="#poly-1c3a3fee-8fcf-40ac-8b0d-6e51f1b06c1c"/>
							<gml:surfaceMember xlink:href="#poly-4c77cf76-dba2-447e-a219-e972673313ec"/>
							<gml:surfaceMember xlink:href="#poly-92a75d64-9514-4791-bbc1-75f036f2bf77"/>
							<gml:surfaceMember xlink:href="#poly-a955d81a-9c8a-4c28-85df-b9f025413d4e"/>
							<gml:surfaceMember xlink:href="#poly-37f1ca52-0274-4c98-a4b0-c4dad697d9bd"/>
							<gml:surfaceMember xlink:href="#poly-ee0a2aee-62dc-4348-8450-9214eb45be86"/>
							<gml:surfaceMember xlink:href="#poly-fa0dbe8d-9d5e-4c83-9e1e-ae1ea2523a26"/>
							<gml:surfaceMember xlink:href="#poly-d5d0d6a1-5ce8-453e-a10d-908ba8f515b3"/>
							<gml:surfaceMember xlink:href="#poly-38e6be30-827f-41bb-8d74-02dd0006e1d1"/>
							<gml:surfaceMember xlink:href="#poly-977b210a-b941-4649-8360-e597376a6eac"/>
							<gml:surfaceMember xlink:href="#poly-addae228-2217-4698-8538-67e62e69957d"/>
							<gml:surfaceMember xlink:href="#poly-f8b878bd-9ef1-4eb8-8643-533c0d5210f0"/>
							<gml:surfaceMember xlink:href="#poly-10931778-f662-4baa-83fb-f4e744a3246b"/>
							<gml:surfaceMember xlink:href="#poly-4c602eb0-da80-47ad-b576-9983938227fc"/>
							<gml:surfaceMember xlink:href="#poly-c23ccf41-b9ff-4c28-92a0-0a56a3a7f479"/>
							<gml:surfaceMember xlink:href="#poly-6f0fd1e2-832a-4d59-b760-2f5abd71ae34"/>
							<gml:surfaceMember xlink:href="#poly-a286b046-b9e2-4d3f-b94a-183cf9d76208"/>
							<gml:surfaceMember xlink:href="#poly-66b08531-8761-4eef-8c88-079ed1564d55"/>
							<gml:surfaceMember xlink:href="#poly-e70fe346-3a94-4ac2-b818-01da4d92d18a"/>
							<gml:surfaceMember xlink:href="#poly-ba15f6eb-ff75-4286-898d-d97a6d4489a5"/>
							<gml:surfaceMember xlink:href="#poly-cb3a46a7-cf30-4341-87c8-49d522f17712"/>
							<gml:surfaceMember xlink:href="#poly-4fe41fa8-ebf8-4494-8434-160b98c82c5e"/>
							<gml:surfaceMember xlink:href="#poly-6153c8df-abf3-4717-a4ef-3e0b498fc73b"/>
							<gml:surfaceMember xlink:href="#poly-e5219087-dd14-4a1b-b416-e8ca5adb3ebe"/>
							<gml:surfaceMember xlink:href="#poly-203cd46c-456f-4f7b-8158-8e241a3f92c6"/>
							<gml:surfaceMember xlink:href="#poly-748edc9f-bd2e-434d-980d-ed6fbb012c3e"/>
							<gml:surfaceMember xlink:href="#poly-205252b3-cfe2-4a22-8ee9-d4a34d180212"/>
							<gml:surfaceMember xlink:href="#poly-db7da300-ba58-41c3-b6df-8320450011e2"/>
							<gml:surfaceMember xlink:href="#poly-ce21249b-1181-404f-bbd3-88f4964e4883"/>
							<gml:surfaceMember xlink:href="#poly-167557dc-219f-49b2-88ee-9a406c6c9a9f"/>
							<gml:surfaceMember xlink:href="#poly-9c7f044a-b93d-4109-8ad8-a49403f2452b"/>
							<gml:surfaceMember xlink:href="#poly-c2e906ad-8c71-44f4-b73e-c86f60e229ff"/>
							<gml:surfaceMember xlink:href="#poly-85fa7d13-5dad-4780-8d36-b10f248da058"/>
							<gml:surfaceMember xlink:href="#poly-77f18606-5620-49ee-93b3-bd498c4282bb"/>
							<gml:surfaceMember xlink:href="#poly-8f4e97b0-ffaf-49d5-9cfb-cfce13452d93"/>
							<gml:surfaceMember xlink:href="#poly-468f836e-6a7b-48b6-b1c4-d584459e6f10"/>
							<gml:surfaceMember xlink:href="#poly-ada4a2be-ceae-498d-8b8a-869d89f76939"/>
							<gml:surfaceMember xlink:href="#poly-a48dc918-73f3-4750-aecd-d1a179eba261"/>
							<gml:surfaceMember xlink:href="#poly-78a133ca-6043-45d9-9744-7d0efbd350b6"/>
							<gml:surfaceMember xlink:href="#poly-8edd643a-bbdf-4617-8e9f-b3ca1ed7d864"/>
							<gml:surfaceMember xlink:href="#poly-f1e896d6-fcdc-44b5-981a-7a3146eda9ca"/>
							<gml:surfaceMember xlink:href="#poly-3e35653d-526d-4d2a-b51c-f7c79b6ca250"/>
							<gml:surfaceMember xlink:href="#poly-8c4de846-85f5-4e30-9b48-6fd37df99369"/>
							<gml:surfaceMember xlink:href="#poly-cbee93ec-007e-411c-8cf8-6e2f410a120f"/>
							<gml:surfaceMember xlink:href="#poly-2285f033-b6b2-434f-8578-e03bb1065cc3"/>
							<gml:surfaceMember xlink:href="#poly-674252fe-b73e-4902-9a2d-87c7a8c63512"/>
							<gml:surfaceMember xlink:href="#poly-b4867e65-f1fe-4281-be7b-95eb26bcd91c"/>
							<gml:surfaceMember xlink:href="#poly-b1ff66eb-99a5-4978-a2aa-39880017c3ce"/>
							<gml:surfaceMember xlink:href="#poly-131e5607-c581-41e5-927b-40ecd16e8227"/>
							<gml:surfaceMember xlink:href="#poly-86dea59c-5032-47a6-8194-97bb17030f17"/>
							<gml:surfaceMember xlink:href="#poly-7387c8e8-0894-476e-8f8c-b0f60978f888"/>
							<gml:surfaceMember xlink:href="#poly-c732d3ef-81dd-411b-b52b-0b3edee6b553"/>
							<gml:surfaceMember xlink:href="#poly-30be9168-a966-47f4-9347-7823ae6d8d88"/>
							<gml:surfaceMember xlink:href="#poly-4cc8eb22-31d0-4de1-a6e1-4a518f1d9bfe"/>
							<gml:surfaceMember xlink:href="#poly-36287620-69f8-48d4-9da4-e3b495ef4d60"/>
							<gml:surfaceMember xlink:href="#poly-1b8f7083-76aa-4bf4-a9a0-3aeafc2bba4b"/>
							<gml:surfaceMember xlink:href="#poly-64e0519b-d181-446b-aed7-3f44303e7219"/>
							<gml:surfaceMember xlink:href="#poly-ba8b6fef-fad5-45b2-8504-decc4b1d2acf"/>
							<gml:surfaceMember xlink:href="#poly-317b2fb5-9967-4261-91c1-18f34a182d9c"/>
							<gml:surfaceMember xlink:href="#poly-fd9cd844-4ee0-47bc-8bc8-075c4b429a65"/>
							<gml:surfaceMember xlink:href="#poly-f8d97950-af09-4951-8b73-4c0022e4222c"/>
							<gml:surfaceMember xlink:href="#poly-3887efc9-4af1-481a-80cb-8a60e80357cc"/>
							<gml:surfaceMember xlink:href="#poly-49945417-adfb-4b45-9a7d-edc536830a8f"/>
							<gml:surfaceMember xlink:href="#poly-b5ab06aa-8776-4863-a173-92eb0d6cc6da"/>
							<gml:surfaceMember xlink:href="#poly-0a6247e2-fa5b-46f7-8deb-614d80d33bcc"/>
							<gml:surfaceMember xlink:href="#poly-ac4695f6-0e23-4748-8eac-dc6b3d2ba8d1"/>
							<gml:surfaceMember xlink:href="#poly-ec8bc39d-9273-4297-a692-c4017767e801"/>
							<gml:surfaceMember xlink:href="#poly-e0028799-b0de-498a-aaba-f3cc000b6044"/>
							<gml:surfaceMember xlink:href="#poly-4d81023f-5b08-40b5-a287-814925fa931d"/>
							<gml:surfaceMember xlink:href="#poly-766b2dce-44e5-4954-aa4a-bd581a27ce08"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_690bdd16-db28-41ae-96b4-f6c3240d33ef_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4f69c713-33ab-4ba8-8f9c-593d75518534">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66844140926187 139.74890771642487 34.955 35.66845412888562 139.74887093091522 34.955 35.66846555323758 139.74887656338538 34.955 35.668482911000254 139.74888558072956 34.955 35.66847010141292 139.74892262040277 34.955 35.66844140926187 139.74890771642487 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24d1a42f-1909-4952-b6b3-c270dcdd541c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66843066551427 139.74894718401933 34.955 35.668419709106736 139.7489790411397 34.955 35.668417348330294 139.7489802144982 34.955 35.66842969901725 139.74894429098669 34.955 35.66843066551427 139.74894718401933 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97795e10-208c-4a66-939f-47170fd46573">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668417348330294 139.7489802144982 34.955 35.668419709106736 139.7489790411397 34.955 35.668434722402914 139.74898679067798 34.955 35.668445326391975 139.74899226938228 34.955 35.66845628280295 139.74896041225355 34.955 35.66844567882021 139.7489549445987 34.955 35.66843066551427 139.74894718401933 34.955 35.66842969901725 139.74894429098669 34.955 35.668458643579186 139.7489592388939 34.955 35.668446283874104 139.74899516242553 34.955 35.668417348330294 139.7489802144982 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd28a124-88d7-4bf4-98f3-2163a0ac3016">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66841567017563 139.74899079832167 34.955 35.668399874215496 139.74903672206082 34.955 35.66839751344622 139.7490379064633 34.955 35.668414703679645 139.74898790528906 34.955 35.66841567017563 139.74899079832167 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c13ce224-ef04-431e-908b-9c5de99dddcf">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66839751344622 139.7490379064633 34.955 35.668399874215496 139.74903672206082 34.955 35.66841487850203 139.74904448266344 34.955 35.66842548248851 139.74904996137403 34.955 35.66844127844586 139.74900402657687 34.955 35.668430674457326 139.74899854787128 34.955 35.66841567017563 139.74899079832167 34.955 35.668414703679645 139.74898790528906 34.955 35.668443639222524 139.74900285321868 34.955 35.668426448982984 139.7490528544078 34.955 35.66839751344622 139.7490379064633 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a398556-af05-4f12-b619-012b76eab498">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66843312680998 139.74905092538614 34.955 35.66842784667525 139.7490665389219 34.955 35.66842549492715 139.74906773436047 34.955 35.66843215130946 139.74904804340764 34.955 35.66843312680998 139.74905092538614 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04b1b526-e3cf-4e17-a004-76887e503a58">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66847187993315 139.74906820477574 34.955 35.66846539487797 139.7490879949706 34.955 35.66842549492715 139.74906773436047 34.955 35.66842784667525 139.7490665389219 34.955 35.66845492453802 139.74908028482088 34.955 35.6684590001959 139.74908235718553 34.955 35.66846440134316 139.74908510196346 34.955 35.6684695372065 139.7490694112514 34.955 35.66846427131893 139.74906674365417 34.955 35.6684602046745 139.7490646712807 34.955 35.66843312680998 139.74905092538614 34.955 35.66843215130946 139.74904804340764 34.955 35.66847187993315 139.74906820477574 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-03767f2d-0ea6-405c-8b28-cb72dc7ca927">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-03767f2d-0ea6-405c-8b28-cb72dc7ca927_0">
											<gml:posList>35.6684602046745 139.7490646712807 38.045 35.66843312680998 139.74905092538614 38.045 35.66843312680998 139.74905092538614 34.955 35.6684602046745 139.7490646712807 34.955 35.6684602046745 139.7490646712807 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25b62f79-e0d9-43f2-8ff6-83ce9cb528c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-25b62f79-e0d9-43f2-8ff6-83ce9cb528c1_0">
											<gml:posList>35.66846427131893 139.74906674365417 38.045 35.6684602046745 139.7490646712807 38.045 35.6684602046745 139.7490646712807 34.955 35.66846427131893 139.74906674365417 34.955 35.66846427131893 139.74906674365417 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ecd9337e-1f46-40be-ba60-c8f8a3675dfc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ecd9337e-1f46-40be-ba60-c8f8a3675dfc_0">
											<gml:posList>35.6684695372065 139.7490694112514 38.045 35.66846427131893 139.74906674365417 38.045 35.66846427131893 139.74906674365417 34.955 35.6684695372065 139.7490694112514 34.955 35.6684695372065 139.7490694112514 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df545344-37cc-47e7-98e8-810badf3f469">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-df545344-37cc-47e7-98e8-810badf3f469_0">
											<gml:posList>35.66842784667525 139.7490665389219 38.045 35.66845492453802 139.74908028482088 38.045 35.66845492453802 139.74908028482088 34.955 35.66842784667525 139.7490665389219 34.955 35.66842784667525 139.7490665389219 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61cdc259-be4f-49ec-9a47-b686a4a0c428">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-61cdc259-be4f-49ec-9a47-b686a4a0c428_0">
											<gml:posList>35.66839751344622 139.7490379064633 34.955 35.66839751344622 139.7490379064633 38.045 35.668414703679645 139.74898790528906 38.045 35.668414703679645 139.74898790528906 34.955 35.66839751344622 139.7490379064633 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f2ff4c9b-67aa-4bce-bba8-c5f5041cdd59">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f2ff4c9b-67aa-4bce-bba8-c5f5041cdd59_0">
											<gml:posList>35.66839751344622 139.7490379064633 38.045 35.66841418586767 139.74904651585362 38.045 35.66841487850203 139.74904448266344 38.045 35.668399874215496 139.74903672206082 38.045 35.66839751344622 139.7490379064633 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-93acc0f2-4f58-4a48-89a7-316238803b08">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-93acc0f2-4f58-4a48-89a7-316238803b08_0">
											<gml:posList>35.668414703679645 139.74898790528906 38.045 35.66839751344622 139.7490379064633 38.045 35.668399874215496 139.74903672206082 38.045 35.66841567017563 139.74899079832167 38.045 35.668414703679645 139.74898790528906 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76d149f5-460a-45d1-8279-53b806b82b26">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-76d149f5-460a-45d1-8279-53b806b82b26_0">
											<gml:posList>35.668399874215496 139.74903672206082 38.045 35.66841487850203 139.74904448266344 38.045 35.66841487850203 139.74904448266344 34.955 35.668399874215496 139.74903672206082 34.955 35.668399874215496 139.74903672206082 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-157ea0db-dff3-45a5-aa7b-108adc92b90b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-157ea0db-dff3-45a5-aa7b-108adc92b90b_0">
											<gml:posList>35.66841567017563 139.74899079832167 38.045 35.668399874215496 139.74903672206082 38.045 35.668399874215496 139.74903672206082 34.955 35.66841567017563 139.74899079832167 34.955 35.66841567017563 139.74899079832167 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a5bdb9ae-5999-4206-8954-a53c6c4bc50a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a5bdb9ae-5999-4206-8954-a53c6c4bc50a_0">
											<gml:posList>35.668426448982984 139.7490528544078 34.955 35.668426448982984 139.7490528544078 38.045 35.66841418586767 139.74904651585362 38.045 35.66839751344622 139.7490379064633 38.045 35.66839751344622 139.7490379064633 34.955 35.668426448982984 139.7490528544078 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e46995c6-0af2-46ef-9ac9-966706e18517">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e46995c6-0af2-46ef-9ac9-966706e18517_0">
											<gml:posList>35.66841487850203 139.74904448266344 38.045 35.66842548248851 139.74904996137403 38.045 35.66842548248851 139.74904996137403 34.955 35.66841487850203 139.74904448266344 34.955 35.66841487850203 139.74904448266344 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d140016-1512-4596-a0a9-d6768320e9af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8d140016-1512-4596-a0a9-d6768320e9af_0">
											<gml:posList>35.66841418586767 139.74904651585362 38.045 35.668426448982984 139.7490528544078 38.045 35.66842548248851 139.74904996137403 38.045 35.66841487850203 139.74904448266344 38.045 35.66841418586767 139.74904651585362 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3f9d8bc-723e-41e6-963a-d520334c0895">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b3f9d8bc-723e-41e6-963a-d520334c0895_0">
											<gml:posList>35.668431376104614 139.7489965146708 38.045 35.668414703679645 139.74898790528906 38.045 35.66841567017563 139.74899079832167 38.045 35.668430674457326 139.74899854787128 38.045 35.668431376104614 139.7489965146708 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-56edd9dc-455d-4975-9517-d12bebbe8371">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-56edd9dc-455d-4975-9517-d12bebbe8371_0">
											<gml:posList>35.668430674457326 139.74899854787128 38.045 35.66841567017563 139.74899079832167 38.045 35.66841567017563 139.74899079832167 34.955 35.668430674457326 139.74899854787128 34.955 35.668430674457326 139.74899854787128 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc24a493-ecf2-4bdc-b352-cbc9d59afe7f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dc24a493-ecf2-4bdc-b352-cbc9d59afe7f_0">
											<gml:posList>35.66842969901725 139.74894429098669 34.955 35.668417348330294 139.7489802144982 34.955 35.668417348330294 139.7489802144982 38.045 35.66842969901725 139.74894429098669 38.045 35.66842969901725 139.74894429098669 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-466c72c1-1a17-442f-a48c-6f3c69b4db74">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-466c72c1-1a17-442f-a48c-6f3c69b4db74_0">
											<gml:posList>35.66842969901725 139.74894429098669 38.045 35.668417348330294 139.7489802144982 38.045 35.668419709106736 139.7489790411397 38.045 35.66843066551427 139.74894718401933 38.045 35.66842969901725 139.74894429098669 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d6363c1-e305-4cb8-9115-6c4f048f2044">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d6363c1-e305-4cb8-9115-6c4f048f2044_0">
											<gml:posList>35.66843066551427 139.74894718401933 38.045 35.668419709106736 139.7489790411397 38.045 35.668419709106736 139.7489790411397 34.955 35.66843066551427 139.74894718401933 34.955 35.66843066551427 139.74894718401933 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0773063b-82db-4f6b-b03d-ab3e4ee012b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0773063b-82db-4f6b-b03d-ab3e4ee012b1_0">
											<gml:posList>35.668417348330294 139.7489802144982 38.045 35.6684340207558 139.74898882387862 38.045 35.668434722402914 139.74898679067798 38.045 35.668419709106736 139.7489790411397 38.045 35.668417348330294 139.7489802144982 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3475d35e-4d9b-49b2-858f-a777e118d963">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3475d35e-4d9b-49b2-858f-a777e118d963_0">
											<gml:posList>35.668419709106736 139.7489790411397 38.045 35.668434722402914 139.74898679067798 38.045 35.668434722402914 139.74898679067798 34.955 35.668419709106736 139.7489790411397 34.955 35.668419709106736 139.7489790411397 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e583071-8a4e-427a-a6af-3ca7f911b544">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1e583071-8a4e-427a-a6af-3ca7f911b544_0">
											<gml:posList>35.66843215130946 139.74904804340764 34.955 35.66842549492715 139.74906773436047 34.955 35.66842549492715 139.74906773436047 38.045 35.66843215130946 139.74904804340764 38.045 35.66843215130946 139.74904804340764 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e90a0b2-1b8f-4696-8a83-8fa8cc9bbb3c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6e90a0b2-1b8f-4696-8a83-8fa8cc9bbb3c_0">
											<gml:posList>35.668443639222524 139.74900285321868 34.955 35.668414703679645 139.74898790528906 34.955 35.668414703679645 139.74898790528906 38.045 35.668431376104614 139.7489965146708 38.045 35.668443639222524 139.74900285321868 38.045 35.668443639222524 139.74900285321868 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d15134a-7fdd-4ced-8109-c856e4334322">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4d15134a-7fdd-4ced-8109-c856e4334322_0">
											<gml:posList>35.66843215130946 139.74904804340764 38.045 35.66842549492715 139.74906773436047 38.045 35.66842784667525 139.7490665389219 38.045 35.66843312680998 139.74905092538614 38.045 35.66843215130946 139.74904804340764 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9eb0aabf-ab8e-49d4-9f5d-aa6cf22118e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9eb0aabf-ab8e-49d4-9f5d-aa6cf22118e2_0">
											<gml:posList>35.66843312680998 139.74905092538614 38.045 35.66842784667525 139.7490665389219 38.045 35.66842784667525 139.7490665389219 34.955 35.66843312680998 139.74905092538614 34.955 35.66843312680998 139.74905092538614 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d681b42-1398-478f-b785-de237b7acc8b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6d681b42-1398-478f-b785-de237b7acc8b_0">
											<gml:posList>35.668446283874104 139.74899516242553 34.955 35.668446283874104 139.74899516242553 38.045 35.6684340207558 139.74898882387862 38.045 35.668417348330294 139.7489802144982 38.045 35.668417348330294 139.7489802144982 34.955 35.668446283874104 139.74899516242553 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-819e9894-b3f0-45ab-9307-3a8160bf4d52">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-819e9894-b3f0-45ab-9307-3a8160bf4d52_0">
											<gml:posList>35.66842548248851 139.74904996137403 38.045 35.66844127844586 139.74900402657687 38.045 35.66844127844586 139.74900402657687 34.955 35.66842548248851 139.74904996137403 34.955 35.66842548248851 139.74904996137403 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5bfafbd-b41c-4f72-83df-72de913b9715">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c5bfafbd-b41c-4f72-83df-72de913b9715_0">
											<gml:posList>35.668426448982984 139.7490528544078 38.045 35.668443639222524 139.74900285321868 38.045 35.66844127844586 139.74900402657687 38.045 35.66842548248851 139.74904996137403 38.045 35.668426448982984 139.7490528544078 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff0796be-f518-428d-b295-05087936b21f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ff0796be-f518-428d-b295-05087936b21f_0">
											<gml:posList>35.668443639222524 139.74900285321868 34.955 35.668443639222524 139.74900285321868 38.045 35.668426448982984 139.7490528544078 38.045 35.668426448982984 139.7490528544078 34.955 35.668443639222524 139.74900285321868 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b5c557ce-253e-4ce5-bf53-c7cf1045c85e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b5c557ce-253e-4ce5-bf53-c7cf1045c85e_0">
											<gml:posList>35.66844127844586 139.74900402657687 38.045 35.668430674457326 139.74899854787128 38.045 35.668430674457326 139.74899854787128 34.955 35.66844127844586 139.74900402657687 34.955 35.66844127844586 139.74900402657687 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9aae2bf7-09c6-4691-be71-305c2a4e1b9b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9aae2bf7-09c6-4691-be71-305c2a4e1b9b_0">
											<gml:posList>35.668443639222524 139.74900285321868 38.045 35.668431376104614 139.7489965146708 38.045 35.668430674457326 139.74899854787128 38.045 35.66844127844586 139.74900402657687 38.045 35.668443639222524 139.74900285321868 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de56ece4-10e2-4c1c-98b2-61be2e2000bc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de56ece4-10e2-4c1c-98b2-61be2e2000bc_0">
											<gml:posList>35.66844638045901 139.74895290035147 38.045 35.66842969901725 139.74894429098669 38.045 35.66843066551427 139.74894718401933 38.045 35.66844567882021 139.7489549445987 38.045 35.66844638045901 139.74895290035147 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e94acda-7c99-427e-9aed-cc363153164f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6e94acda-7c99-427e-9aed-cc363153164f_0">
											<gml:posList>35.66844567882021 139.7489549445987 38.045 35.66843066551427 139.74894718401933 38.045 35.66843066551427 139.74894718401933 34.955 35.66844567882021 139.7489549445987 34.955 35.66844567882021 139.7489549445987 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-808688a9-8a04-4453-941b-22622d1aae2e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-808688a9-8a04-4453-941b-22622d1aae2e_0">
											<gml:posList>35.668434722402914 139.74898679067798 38.045 35.668445326391975 139.74899226938228 38.045 35.668445326391975 139.74899226938228 34.955 35.668434722402914 139.74898679067798 34.955 35.668434722402914 139.74898679067798 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e89e2a4e-078f-4a84-94ea-640caebe820f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e89e2a4e-078f-4a84-94ea-640caebe820f_0">
											<gml:posList>35.6684340207558 139.74898882387862 38.045 35.668446283874104 139.74899516242553 38.045 35.668445326391975 139.74899226938228 38.045 35.668434722402914 139.74898679067798 38.045 35.6684340207558 139.74898882387862 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8bdae39-6084-48c8-b8cb-71f946f97aec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d8bdae39-6084-48c8-b8cb-71f946f97aec_0">
											<gml:posList>35.66842549492715 139.74906773436047 38.045 35.66845423191078 139.7490823290577 38.045 35.66845492453802 139.74908028482088 38.045 35.66842784667525 139.7490665389219 38.045 35.66842549492715 139.74906773436047 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-463aa5fc-09c8-4a8e-bab0-dfa46cde5c3a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-463aa5fc-09c8-4a8e-bab0-dfa46cde5c3a_0">
											<gml:posList>35.668458643579186 139.7489592388939 34.955 35.66842969901725 139.74894429098669 34.955 35.66842969901725 139.74894429098669 38.045 35.66844638045901 139.74895290035147 38.045 35.668458643579186 139.7489592388939 38.045 35.668458643579186 139.7489592388939 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4476f406-f2b3-43b5-b441-d335c9509544">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4476f406-f2b3-43b5-b441-d335c9509544_0">
											<gml:posList>35.66842549492715 139.74906773436047 34.955 35.66846539487797 139.7490879949706 34.955 35.66846539487797 139.7490879949706 38.045 35.668458307568635 139.74908440142244 38.045 35.66845423191078 139.7490823290577 38.045 35.66842549492715 139.74906773436047 38.045 35.66842549492715 139.74906773436047 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9f6e95c-4da1-4595-802a-5fa5858e1d5c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b9f6e95c-4da1-4595-802a-5fa5858e1d5c_0">
											<gml:posList>35.66846089730917 139.74906263808953 38.045 35.66843215130946 139.74904804340764 38.045 35.66843312680998 139.74905092538614 38.045 35.6684602046745 139.7490646712807 38.045 35.66846089730917 139.74906263808953 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0646ac7-1061-4e68-b97b-ce5e05cdd780">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0646ac7-1061-4e68-b97b-ce5e05cdd780_0">
											<gml:posList>35.66845412888562 139.74887093091522 34.955 35.66844140926187 139.74890771642487 34.955 35.66844140926187 139.74890771642487 38.045 35.66845412888562 139.74887093091522 38.045 35.66845412888562 139.74887093091522 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3ca7a61-331d-4de5-9d85-d0987013ed95">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3ca7a61-331d-4de5-9d85-d0987013ed95_0">
											<gml:posList>35.668445326391975 139.74899226938228 38.045 35.66845628280295 139.74896041225355 38.045 35.66845628280295 139.74896041225355 34.955 35.668445326391975 139.74899226938228 34.955 35.668445326391975 139.74899226938228 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-675a711b-4e33-41c6-8dda-cb68cafdb4be">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-675a711b-4e33-41c6-8dda-cb68cafdb4be_0">
											<gml:posList>35.66845628280295 139.74896041225355 38.045 35.66844567882021 139.7489549445987 38.045 35.66844567882021 139.7489549445987 34.955 35.66845628280295 139.74896041225355 34.955 35.66845628280295 139.74896041225355 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26b433b8-8e2b-4c42-9f8c-2ab2e78c1111">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-26b433b8-8e2b-4c42-9f8c-2ab2e78c1111_0">
											<gml:posList>35.66847187993315 139.74906820477574 34.955 35.66843215130946 139.74904804340764 34.955 35.66843215130946 139.74904804340764 38.045 35.66846089730917 139.74906263808953 38.045 35.6684649639459 139.74906469941692 38.045 35.66847187993315 139.74906820477574 38.045 35.66847187993315 139.74906820477574 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f415282-197c-406a-8fdd-ba99d2ddd2f5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9f415282-197c-406a-8fdd-ba99d2ddd2f5_0">
											<gml:posList>35.668446283874104 139.74899516242553 38.045 35.668458643579186 139.7489592388939 38.045 35.66845628280295 139.74896041225355 38.045 35.668445326391975 139.74899226938228 38.045 35.668446283874104 139.74899516242553 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a5ab89cd-dbf1-4093-8855-453f272328b6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a5ab89cd-dbf1-4093-8855-453f272328b6_0">
											<gml:posList>35.668458643579186 139.7489592388939 38.045 35.66844638045901 139.74895290035147 38.045 35.66844567882021 139.7489549445987 38.045 35.66845628280295 139.74896041225355 38.045 35.668458643579186 139.7489592388939 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-39793557-8ed9-4ba5-bde6-7560f7e74ff8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-39793557-8ed9-4ba5-bde6-7560f7e74ff8_0">
											<gml:posList>35.668446283874104 139.74899516242553 34.955 35.668458643579186 139.7489592388939 34.955 35.668458643579186 139.7489592388939 38.045 35.668446283874104 139.74899516242553 38.045 35.668446283874104 139.74899516242553 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ea32c5b-1d0a-4f02-b57a-3a8b7d040c41">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3ea32c5b-1d0a-4f02-b57a-3a8b7d040c41_0">
											<gml:posList>35.66844140926187 139.74890771642487 34.955 35.66847010141292 139.74892262040277 34.955 35.66847010141292 139.74892262040277 38.045 35.66844140926187 139.74890771642487 38.045 35.66844140926187 139.74890771642487 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a0a15031-feab-41fd-8fd8-2fd3d0889177">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a0a15031-feab-41fd-8fd8-2fd3d0889177_0">
											<gml:posList>35.66845423191078 139.7490823290577 38.045 35.668458307568635 139.74908440142244 38.045 35.6684590001959 139.74908235718553 38.045 35.66845492453802 139.74908028482088 38.045 35.66845423191078 139.7490823290577 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6195cb2-fb95-4be2-a3df-236ebe9d3465">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d6195cb2-fb95-4be2-a3df-236ebe9d3465_0">
											<gml:posList>35.66845492453802 139.74908028482088 38.045 35.6684590001959 139.74908235718553 38.045 35.6684590001959 139.74908235718553 34.955 35.66845492453802 139.74908028482088 34.955 35.66845492453802 139.74908028482088 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb54e465-113c-4a54-bfaf-5bc18e54f56c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb54e465-113c-4a54-bfaf-5bc18e54f56c_0">
											<gml:posList>35.66845412888562 139.74887093091522 38.045 35.66846555323758 139.74887656338538 38.045 35.66846555323758 139.74887656338538 34.955 35.66845412888562 139.74887093091522 34.955 35.66845412888562 139.74887093091522 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d25935e7-6de1-44c9-a84d-1284396e58b7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d25935e7-6de1-44c9-a84d-1284396e58b7_0">
											<gml:posList>35.6684590001959 139.74908235718553 38.045 35.66846440134316 139.74908510196346 38.045 35.66846440134316 139.74908510196346 34.955 35.6684590001959 139.74908235718553 34.955 35.6684590001959 139.74908235718553 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6fdbea38-8762-4946-a785-dc014768a4cd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6fdbea38-8762-4946-a785-dc014768a4cd_0">
											<gml:posList>35.668458307568635 139.74908440142244 38.045 35.66846539487797 139.7490879949706 38.045 35.66846440134316 139.74908510196346 38.045 35.6684590001959 139.74908235718553 38.045 35.668458307568635 139.74908440142244 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c369c078-915a-4415-89b0-f1642b96687d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c369c078-915a-4415-89b0-f1642b96687d_0">
											<gml:posList>35.668482911000254 139.74888558072956 38.045 35.66846555323758 139.74887656338538 38.045 35.66845412888562 139.74887093091522 38.045 35.66844140926187 139.74890771642487 38.045 35.66847010141292 139.74892262040277 38.045 35.668482911000254 139.74888558072956 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c17c059a-0460-4c3e-8e11-03126109f9dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c17c059a-0460-4c3e-8e11-03126109f9dc_0">
											<gml:posList>35.6684649639459 139.74906469941692 38.045 35.66846089730917 139.74906263808953 38.045 35.6684602046745 139.7490646712807 38.045 35.66846427131893 139.74906674365417 38.045 35.6684649639459 139.74906469941692 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46b05a55-7aad-48ae-b2a0-1b27579c8853">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46b05a55-7aad-48ae-b2a0-1b27579c8853_0">
											<gml:posList>35.66846440134316 139.74908510196346 38.045 35.6684695372065 139.7490694112514 38.045 35.6684695372065 139.7490694112514 34.955 35.66846440134316 139.74908510196346 34.955 35.66846440134316 139.74908510196346 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a9b8b8e1-49b3-46ef-a22b-df524e673faf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a9b8b8e1-49b3-46ef-a22b-df524e673faf_0">
											<gml:posList>35.66847187993315 139.74906820477574 38.045 35.6684649639459 139.74906469941692 38.045 35.66846427131893 139.74906674365417 38.045 35.6684695372065 139.7490694112514 38.045 35.66847187993315 139.74906820477574 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef8d05bd-2076-4c75-abf6-f1bf01f59811">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef8d05bd-2076-4c75-abf6-f1bf01f59811_0">
											<gml:posList>35.66846539487797 139.7490879949706 38.045 35.66847187993315 139.74906820477574 38.045 35.6684695372065 139.7490694112514 38.045 35.66846440134316 139.74908510196346 38.045 35.66846539487797 139.7490879949706 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-10f8cd7b-6ba8-434e-afd2-1e2315608111">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-10f8cd7b-6ba8-434e-afd2-1e2315608111_0">
											<gml:posList>35.66846539487797 139.7490879949706 34.955 35.66847187993315 139.74906820477574 34.955 35.66847187993315 139.74906820477574 38.045 35.66846539487797 139.7490879949706 38.045 35.66846539487797 139.7490879949706 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a36fe698-955f-4a84-8e07-780c5a5a4c0d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a36fe698-955f-4a84-8e07-780c5a5a4c0d_0">
											<gml:posList>35.66846555323758 139.74887656338538 38.045 35.668482911000254 139.74888558072956 38.045 35.668482911000254 139.74888558072956 34.955 35.66846555323758 139.74887656338538 34.955 35.66846555323758 139.74887656338538 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-716bc984-9da5-4e81-9799-b95266b13329">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-716bc984-9da5-4e81-9799-b95266b13329_0">
											<gml:posList>35.66847010141292 139.74892262040277 34.955 35.668482911000254 139.74888558072956 34.955 35.668482911000254 139.74888558072956 38.045 35.66847010141292 139.74892262040277 38.045 35.66847010141292 139.74892262040277 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_690bdd16-db28-41ae-96b4-f6c3240d33ef_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84b0af2e-d382-46aa-81d4-30c576b6066a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-84b0af2e-d382-46aa-81d4-30c576b6066a_0">
											<gml:posList>35.6683687658792 139.74907258793428 34.955 35.66838049635556 139.74903910627341 40.658 35.66838049635556 139.74903910627341 34.955 35.6683687658792 139.74907258793428 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84e8a65f-bb71-4440-b7ec-1e3cf1ea340e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-84e8a65f-bb71-4440-b7ec-1e3cf1ea340e_0">
											<gml:posList>35.6683687658792 139.74907258793428 34.955 35.6683687658792 139.74907258793428 40.658 35.66838049635556 139.74903910627341 40.658 35.6683687658792 139.74907258793428 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8258bd1-0b82-457b-bc41-8c9d2295ec1d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b8258bd1-0b82-457b-bc41-8c9d2295ec1d_0">
											<gml:posList>35.6683687658792 139.74907258793428 40.658 35.66839744912791 139.74908767974887 40.658 35.66840917960839 139.74905419807823 40.658 35.6683687658792 139.74907258793428 40.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c041c275-c091-4aaf-9e2a-4461c55967b9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c041c275-c091-4aaf-9e2a-4461c55967b9_0">
											<gml:posList>35.66838049635556 139.74903910627341 40.658 35.6683687658792 139.74907258793428 40.658 35.66840917960839 139.74905419807823 40.658 35.66838049635556 139.74903910627341 40.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a358587-328f-4452-ab36-9e8ab5b634a4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6a358587-328f-4452-ab36-9e8ab5b634a4_0">
											<gml:posList>35.66846427131893 139.74906674365417 34.955 35.6684602046745 139.7490646712807 36.999 35.66846427131893 139.74906674365417 36.999 35.66846427131893 139.74906674365417 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c58734a7-628e-4bbb-b80e-800769d45ff8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c58734a7-628e-4bbb-b80e-800769d45ff8_0">
											<gml:posList>35.66846427131893 139.74906674365417 34.955 35.6684602046745 139.7490646712807 34.955 35.6684602046745 139.7490646712807 36.999 35.66846427131893 139.74906674365417 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4f38ad45-2211-4e5b-9007-65d7093b89c8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4f38ad45-2211-4e5b-9007-65d7093b89c8_0">
											<gml:posList>35.66840917960839 139.74905419807823 34.955 35.66839744912791 139.74908767974887 40.658 35.66839744912791 139.74908767974887 34.955 35.66840917960839 139.74905419807823 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-15ce5892-31a5-44e3-a625-eee37ddc29a2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-15ce5892-31a5-44e3-a625-eee37ddc29a2_0">
											<gml:posList>35.66840917960839 139.74905419807823 34.955 35.66840917960839 139.74905419807823 40.658 35.66839744912791 139.74908767974887 40.658 35.66840917960839 139.74905419807823 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3775914-d7a4-48c5-a1e4-408c78515eaa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b3775914-d7a4-48c5-a1e4-408c78515eaa_0">
											<gml:posList>35.6684602046745 139.7490646712807 36.999 35.66845492453802 139.74908028482088 34.955 35.66845492453802 139.74908028482088 36.999 35.6684602046745 139.7490646712807 36.999</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8597249-803e-4ae0-8248-ca4cd82017a7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8597249-803e-4ae0-8248-ca4cd82017a7_0">
											<gml:posList>35.6684602046745 139.7490646712807 36.999 35.6684602046745 139.7490646712807 34.955 35.66845492453802 139.74908028482088 34.955 35.6684602046745 139.7490646712807 36.999</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8614553-127a-4d9d-9d2f-e09926c84e18">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b8614553-127a-4d9d-9d2f-e09926c84e18_0">
											<gml:posList>35.66846427131893 139.74906674365417 34.955 35.66845899118218 139.749082357195 36.999 35.66845899118218 139.749082357195 34.955 35.66846427131893 139.74906674365417 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a33f336c-00b4-49a9-8585-f744d2c3b773">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a33f336c-00b4-49a9-8585-f744d2c3b773_0">
											<gml:posList>35.66846427131893 139.74906674365417 34.955 35.66846427131893 139.74906674365417 36.999 35.66845899118218 139.749082357195 36.999 35.66846427131893 139.74906674365417 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f3e86933-cd41-4ba8-9ed2-a35a534dc70a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f3e86933-cd41-4ba8-9ed2-a35a534dc70a_0">
											<gml:posList>35.6683447146933 139.74908183660162 34.955 35.66831934989459 139.74906874063328 40.658 35.6683447146933 139.74908183660162 40.658 35.6683447146933 139.74908183660162 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-88912a7f-6307-439c-89c3-bc2a7716b139">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-88912a7f-6307-439c-89c3-bc2a7716b139_0">
											<gml:posList>35.6683447146933 139.74908183660162 34.955 35.66831934989459 139.74906874063328 34.955 35.66831934989459 139.74906874063328 40.658 35.6683447146933 139.74908183660162 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-072aea4a-dcd1-4126-a951-78254734a240">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-072aea4a-dcd1-4126-a951-78254734a240_0">
											<gml:posList>35.66831934989459 139.74906874063328 34.955 35.66831334095152 139.74908622168135 40.658 35.66831934989459 139.74906874063328 40.658 35.66831934989459 139.74906874063328 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-07eaedfe-260c-4996-b000-195fabf698c5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-07eaedfe-260c-4996-b000-195fabf698c5_0">
											<gml:posList>35.66831934989459 139.74906874063328 34.955 35.66831334095152 139.74908622168135 34.955 35.66831334095152 139.74908622168135 40.658 35.66831934989459 139.74906874063328 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-15fec08f-238a-4707-96ae-b254666aed96">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-15fec08f-238a-4707-96ae-b254666aed96_0">
											<gml:posList>35.66839744912791 139.74908767974887 40.658 35.6683687658792 139.74907258793428 34.955 35.66839744912791 139.74908767974887 34.955 35.66839744912791 139.74908767974887 40.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-faed034a-d163-4878-b1e4-dfe0ed42c23e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-faed034a-d163-4878-b1e4-dfe0ed42c23e_0">
											<gml:posList>35.66839744912791 139.74908767974887 40.658 35.6683687658792 139.74907258793428 40.658 35.6683687658792 139.74907258793428 34.955 35.66839744912791 139.74908767974887 40.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-658d94f1-36c8-4bef-8dad-c9cdf9d536b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-658d94f1-36c8-4bef-8dad-c9cdf9d536b8_0">
											<gml:posList>35.66845492453802 139.74908028482088 36.999 35.66845899118218 139.749082357195 34.955 35.66845899118218 139.749082357195 36.999 35.66845492453802 139.74908028482088 36.999</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-915bcca9-6eb2-4940-b3ba-be5d6705a0e8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-915bcca9-6eb2-4940-b3ba-be5d6705a0e8_0">
											<gml:posList>35.66845492453802 139.74908028482088 36.999 35.66845492453802 139.74908028482088 34.955 35.66845899118218 139.749082357195 34.955 35.66845492453802 139.74908028482088 36.999</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef84ab20-5832-4ae9-b250-4fcef3d46bf0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef84ab20-5832-4ae9-b250-4fcef3d46bf0_0">
											<gml:posList>35.66831334095152 139.74908622168135 40.658 35.6683447146933 139.74908183660162 40.658 35.66831934989459 139.74906874063328 40.658 35.66831334095152 139.74908622168135 40.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01e28a17-703d-4897-aba1-60ef9c9b050c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01e28a17-703d-4897-aba1-60ef9c9b050c_0">
											<gml:posList>35.66831334095152 139.74908622168135 40.658 35.66833870574836 139.7490993176542 40.658 35.6683447146933 139.74908183660162 40.658 35.66831334095152 139.74908622168135 40.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-91be2b28-fa4f-4ada-97a9-4433047164c8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-91be2b28-fa4f-4ada-97a9-4433047164c8_0">
											<gml:posList>35.66836615709979 139.74908002462215 40.658 35.66839484034757 139.7490951164389 34.955 35.66836615709979 139.74908002462215 34.955 35.66836615709979 139.74908002462215 40.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d918ff08-18ba-4033-8101-e6937513420e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d918ff08-18ba-4033-8101-e6937513420e_0">
											<gml:posList>35.66836615709979 139.74908002462215 40.658 35.66839484034757 139.7490951164389 40.658 35.66839484034757 139.7490951164389 34.955 35.66836615709979 139.74908002462215 40.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b7a8d43-4922-4597-89da-668547ec9762">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b7a8d43-4922-4597-89da-668547ec9762_0">
											<gml:posList>35.66833870574836 139.7490993176542 34.955 35.6683447146933 139.74908183660162 40.658 35.66833870574836 139.7490993176542 40.658 35.66833870574836 139.7490993176542 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab16d632-0976-4efa-80e2-892ab78a521b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ab16d632-0976-4efa-80e2-892ab78a521b_0">
											<gml:posList>35.66833870574836 139.7490993176542 34.955 35.6683447146933 139.74908183660162 34.955 35.6683447146933 139.74908183660162 40.658 35.66833870574836 139.7490993176542 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b8e9015-d83b-4a82-a380-49536c46b18e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0b8e9015-d83b-4a82-a380-49536c46b18e_0">
											<gml:posList>35.66833870574836 139.7490993176542 40.658 35.66831334095152 139.74908622168135 34.955 35.66833870574836 139.7490993176542 34.955 35.66833870574836 139.7490993176542 40.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a8de2fd-3217-4485-9139-3f90bd894e5e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4a8de2fd-3217-4485-9139-3f90bd894e5e_0">
											<gml:posList>35.66833870574836 139.7490993176542 40.658 35.66831334095152 139.74908622168135 40.658 35.66831334095152 139.74908622168135 34.955 35.66833870574836 139.7490993176542 40.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a1b66a3-7ce5-4501-9245-cbb572da4161">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1a1b66a3-7ce5-4501-9245-cbb572da4161_0">
											<gml:posList>35.66836615709979 139.74908002462215 34.955 35.66835407579511 139.74911453391576 40.658 35.66836615709979 139.74908002462215 40.658 35.66836615709979 139.74908002462215 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f704055-555b-41b7-abda-8fed3c919c43">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2f704055-555b-41b7-abda-8fed3c919c43_0">
											<gml:posList>35.66836615709979 139.74908002462215 34.955 35.66835407579511 139.74911453391576 34.955 35.66835407579511 139.74911453391576 40.658 35.66836615709979 139.74908002462215 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37880e47-96d6-4be5-b152-86c8eae6565c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-37880e47-96d6-4be5-b152-86c8eae6565c_0">
											<gml:posList>35.66839484034757 139.7490951164389 40.658 35.66835407579511 139.74911453391576 40.658 35.66838275002491 139.74912962575206 40.658 35.66839484034757 139.7490951164389 40.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a247e245-04eb-4011-a2bb-85539513778e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a247e245-04eb-4011-a2bb-85539513778e_0">
											<gml:posList>35.66839484034757 139.7490951164389 40.658 35.66836615709979 139.74908002462215 40.658 35.66835407579511 139.74911453391576 40.658 35.66839484034757 139.7490951164389 40.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1ba6d020-6612-4c3f-a7da-4e1ca8ef6d55">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1ba6d020-6612-4c3f-a7da-4e1ca8ef6d55_0">
											<gml:posList>35.66838275002491 139.74912962575206 34.955 35.66839484034757 139.7490951164389 40.658 35.66838275002491 139.74912962575206 40.658 35.66838275002491 139.74912962575206 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-846533b3-baca-41da-a770-0f0082cd26ef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-846533b3-baca-41da-a770-0f0082cd26ef_0">
											<gml:posList>35.66838275002491 139.74912962575206 34.955 35.66839484034757 139.7490951164389 34.955 35.66839484034757 139.7490951164389 40.658 35.66838275002491 139.74912962575206 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c8cc841-62ff-40aa-a117-334d63763350">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c8cc841-62ff-40aa-a117-334d63763350_0">
											<gml:posList>35.66835407579511 139.74911453391576 34.955 35.66838275002491 139.74912962575206 40.658 35.66835407579511 139.74911453391576 40.658 35.66835407579511 139.74911453391576 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2e700b7f-6338-4be7-b99a-90bc9f6ee34e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2e700b7f-6338-4be7-b99a-90bc9f6ee34e_0">
											<gml:posList>35.66835407579511 139.74911453391576 34.955 35.66838275002491 139.74912962575206 34.955 35.66838275002491 139.74912962575206 40.658 35.66835407579511 139.74911453391576 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fcd32833-7c75-400b-a76d-1463c037e283">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fcd32833-7c75-400b-a76d-1463c037e283_0">
											<gml:posList>35.66841156643659 139.74916759369324 42.017 35.668400250239664 139.74916192793387 43.69 35.66841156643659 139.74916759369324 43.69 35.66841156643659 139.74916759369324 42.017</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cbcc5d1d-0738-4eb0-8ae3-f03142bd11e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cbcc5d1d-0738-4eb0-8ae3-f03142bd11e4_0">
											<gml:posList>35.66841156643659 139.74916759369324 42.017 35.668400250239664 139.74916192793387 42.017 35.668400250239664 139.74916192793387 43.69 35.66841156643659 139.74916759369324 42.017</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c92a535c-a1fc-46a6-9c68-80f2b2dd1d59">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c92a535c-a1fc-46a6-9c68-80f2b2dd1d59_0">
											<gml:posList>35.668400250239664 139.74916192793387 42.017 35.66839595966285 139.74917476787465 43.69 35.668400250239664 139.74916192793387 43.69 35.668400250239664 139.74916192793387 42.017</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f6b8ab8-b8a4-41be-8f94-79c317d34e4f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1f6b8ab8-b8a4-41be-8f94-79c317d34e4f_0">
											<gml:posList>35.668400250239664 139.74916192793387 42.017 35.66839595966285 139.74917476787465 42.017 35.66839595966285 139.74917476787465 43.69 35.668400250239664 139.74916192793387 42.017</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f76a4ee2-11ee-4d33-afb9-712ab8a16a20">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f76a4ee2-11ee-4d33-afb9-712ab8a16a20_0">
											<gml:posList>35.668407275859195 139.74918043363553 43.69 35.668400250239664 139.74916192793387 43.69 35.66839595966285 139.74917476787465 43.69 35.668407275859195 139.74918043363553 43.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-addf8bde-1abc-4af0-a5f0-3662fdf2538b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-addf8bde-1abc-4af0-a5f0-3662fdf2538b_0">
											<gml:posList>35.668407275859195 139.74918043363553 43.69 35.66841156643659 139.74916759369324 43.69 35.668400250239664 139.74916192793387 43.69 35.668407275859195 139.74918043363553 43.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf68113d-d450-43f8-b9e3-2a22bd506ba1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cf68113d-d450-43f8-b9e3-2a22bd506ba1_0">
											<gml:posList>35.668407275859195 139.74918043363553 42.017 35.66841156643659 139.74916759369324 43.69 35.668407275859195 139.74918043363553 43.69 35.668407275859195 139.74918043363553 42.017</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-09db455b-2d27-4e65-b427-64e5a855d2d0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-09db455b-2d27-4e65-b427-64e5a855d2d0_0">
											<gml:posList>35.668407275859195 139.74918043363553 42.017 35.66841156643659 139.74916759369324 42.017 35.66841156643659 139.74916759369324 43.69 35.668407275859195 139.74918043363553 42.017</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c583539a-7514-4355-9453-aae59399844e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c583539a-7514-4355-9453-aae59399844e_0">
											<gml:posList>35.66839595966285 139.74917476787465 42.017 35.668407275859195 139.74918043363553 43.69 35.66839595966285 139.74917476787465 43.69 35.66839595966285 139.74917476787465 42.017</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53ad2658-506c-42b0-b87c-f9c472a8915d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-53ad2658-506c-42b0-b87c-f9c472a8915d_0">
											<gml:posList>35.66839595966285 139.74917476787465 42.017 35.668407275859195 139.74918043363553 42.017 35.668407275859195 139.74918043363553 43.69 35.66839595966285 139.74917476787465 42.017</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-250bfd1a-4c76-472f-bdb5-1ce2b5dd7e1a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-250bfd1a-4c76-472f-bdb5-1ce2b5dd7e1a_0">
											<gml:posList>35.66847242066309 139.74879800806426 34.2 35.66848187036847 139.7488027257891 35.216 35.66848187036847 139.7488027257891 34.2 35.66847242066309 139.74879800806426 34.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-580d0b6d-18bd-43fc-bdf7-c4da0c722d54">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-580d0b6d-18bd-43fc-bdf7-c4da0c722d54_0">
											<gml:posList>35.66847242066309 139.74879800806426 34.2 35.66847242066309 139.74879800806426 35.216 35.66848187036847 139.7488027257891 35.216 35.66847242066309 139.74879800806426 34.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-65d4b6ba-d23a-4347-8ae4-10842823c215">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-65d4b6ba-d23a-4347-8ae4-10842823c215_0">
											<gml:posList>35.66847109849099 139.74880206333918 34.2 35.668480539198015 139.7488068031659 33.586 35.66847109849099 139.74880206333918 33.586 35.66847109849099 139.74880206333918 34.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce9d7706-f7a3-4c30-a45e-c54c13ce0ec5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce9d7706-f7a3-4c30-a45e-c54c13ce0ec5_0">
											<gml:posList>35.66847109849099 139.74880206333918 34.2 35.668480539198015 139.7488068031659 34.2 35.668480539198015 139.7488068031659 33.586 35.66847109849099 139.74880206333918 34.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27737d6f-b912-493b-a63b-9e45b45284ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-27737d6f-b912-493b-a63b-9e45b45284ce_0">
											<gml:posList>35.66847109849099 139.74880206333918 33.586 35.66846508124761 139.7488205054507 33.586 35.66847109849099 139.74880206333918 34.2 35.66847109849099 139.74880206333918 33.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-93b93b21-1bf6-4b78-b2a5-28135c9a49ac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-93b93b21-1bf6-4b78-b2a5-28135c9a49ac_0">
											<gml:posList>35.66847242066309 139.74879800806426 34.2 35.66847109849099 139.74880206333918 34.2 35.66847242066309 139.74879800806426 35.216 35.66847242066309 139.74879800806426 34.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9be937f6-1917-4df3-9d7b-608697a698dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9be937f6-1917-4df3-9d7b-608697a698dc_0">
											<gml:posList>35.66847242066309 139.74879800806426 35.216 35.66847109849099 139.74880206333918 34.2 35.66846508124761 139.7488205054507 35.216 35.66847242066309 139.74879800806426 35.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a72ba698-f8fb-465a-afde-4064eacbfe43">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a72ba698-f8fb-465a-afde-4064eacbfe43_0">
											<gml:posList>35.66847109849099 139.74880206333918 34.2 35.66846508124761 139.7488205054507 33.586 35.66846508124761 139.7488205054507 35.216 35.66847109849099 139.74880206333918 34.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1a1fed3-ba58-4a60-a1c8-8d30cc2fe57e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c1a1fed3-ba58-4a60-a1c8-8d30cc2fe57e_0">
											<gml:posList>35.66846508124761 139.7488205054507 35.216 35.66848187036847 139.7488027257891 35.216 35.66847242066309 139.74879800806426 35.216 35.66846508124761 139.7488205054507 35.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0fcbac48-adea-4677-bbb4-2b7ab140353d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0fcbac48-adea-4677-bbb4-2b7ab140353d_0">
											<gml:posList>35.66846508124761 139.7488205054507 35.216 35.66847454895634 139.74882519002082 35.216 35.66848187036847 139.7488027257891 35.216 35.66846508124761 139.7488205054507 35.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f929d179-9497-4711-a06f-1db8d70c4b3f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f929d179-9497-4711-a06f-1db8d70c4b3f_0">
											<gml:posList>35.66848187036847 139.7488027257891 34.2 35.66848187036847 139.7488027257891 35.216 35.668480539198015 139.7488068031659 34.2 35.66848187036847 139.7488027257891 34.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-133a3665-f47d-4bcc-af0d-b12afbd03054">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-133a3665-f47d-4bcc-af0d-b12afbd03054_0">
											<gml:posList>35.668480539198015 139.7488068031659 33.586 35.668480539198015 139.7488068031659 34.2 35.66847454895634 139.74882519002082 33.586 35.668480539198015 139.7488068031659 33.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-afa826ee-8448-4978-85a1-a74c3eeb727c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-afa826ee-8448-4978-85a1-a74c3eeb727c_0">
											<gml:posList>35.66847454895634 139.74882519002082 33.586 35.668480539198015 139.7488068031659 34.2 35.66847454895634 139.74882519002082 35.216 35.66847454895634 139.74882519002082 33.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1df3cfc4-1ccb-4f7e-abb0-1da58c62ceb1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1df3cfc4-1ccb-4f7e-abb0-1da58c62ceb1_0">
											<gml:posList>35.668480539198015 139.7488068031659 34.2 35.66848187036847 139.7488027257891 35.216 35.66847454895634 139.74882519002082 35.216 35.668480539198015 139.7488068031659 34.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e50eee9e-3b10-4ae1-bb9b-3669be43359b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e50eee9e-3b10-4ae1-bb9b-3669be43359b_0">
											<gml:posList>35.66846508124761 139.7488205054507 33.586 35.66847454895634 139.74882519002082 35.216 35.66846508124761 139.7488205054507 35.216 35.66846508124761 139.7488205054507 33.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76a8c1c8-7541-4829-a9c2-00c635bb1ba0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-76a8c1c8-7541-4829-a9c2-00c635bb1ba0_0">
											<gml:posList>35.66846508124761 139.7488205054507 33.586 35.66847454895634 139.74882519002082 33.586 35.66847454895634 139.74882519002082 35.216 35.66846508124761 139.7488205054507 33.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e7bb182-86ff-4b7d-9b2e-763f6c0807ac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4e7bb182-86ff-4b7d-9b2e-763f6c0807ac_0">
											<gml:posList>35.66841430045831 139.74893986670517 34.955 35.66838861934329 139.74892560022894 39.266 35.66841430045831 139.74893986670517 39.266 35.66841430045831 139.74893986670517 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b54dfe28-02cf-4e66-8d67-fc30b2300f74">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b54dfe28-02cf-4e66-8d67-fc30b2300f74_0">
											<gml:posList>35.66841430045831 139.74893986670517 34.955 35.66838861934329 139.74892560022894 34.955 35.66838861934329 139.74892560022894 39.266 35.66841430045831 139.74893986670517 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c8693d42-87a4-483d-a94d-6a22de823c2f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c8693d42-87a4-483d-a94d-6a22de823c2f_0">
											<gml:posList>35.66838861934329 139.74892560022894 34.955 35.66837421565246 139.74896455248472 39.266 35.66838861934329 139.74892560022894 39.266 35.66838861934329 139.74892560022894 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2e4c30c5-a2f7-416d-9b83-906e93ddf274">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2e4c30c5-a2f7-416d-9b83-906e93ddf274_0">
											<gml:posList>35.66838861934329 139.74892560022894 34.955 35.66837421565246 139.74896455248472 34.955 35.66837421565246 139.74896455248472 39.266 35.66838861934329 139.74892560022894 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0c1354c6-d58d-4f2e-980e-068a40a1f6ae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0c1354c6-d58d-4f2e-980e-068a40a1f6ae_0">
											<gml:posList>35.66841430045831 139.74893986670517 39.266 35.66837421565246 139.74896455248472 39.266 35.66839988774922 139.7489788189804 39.266 35.66841430045831 139.74893986670517 39.266</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb6800af-ab88-45bf-8f28-7bb3cbb89ea9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb6800af-ab88-45bf-8f28-7bb3cbb89ea9_0">
											<gml:posList>35.66841430045831 139.74893986670517 39.266 35.66838861934329 139.74892560022894 39.266 35.66837421565246 139.74896455248472 39.266 35.66841430045831 139.74893986670517 39.266</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d6b1b0b-9731-47a4-8c88-759b87e7886e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4d6b1b0b-9731-47a4-8c88-759b87e7886e_0">
											<gml:posList>35.66844567882021 139.7489549445987 36.452 35.66845628280295 139.74896041225355 34.955 35.66844567882021 139.7489549445987 34.955 35.66844567882021 139.7489549445987 36.452</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ecaabc37-5b53-4782-879c-ce519bfe75da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ecaabc37-5b53-4782-879c-ce519bfe75da_0">
											<gml:posList>35.66844567882021 139.7489549445987 36.452 35.66845628280295 139.74896041225355 36.452 35.66845628280295 139.74896041225355 34.955 35.66844567882021 139.7489549445987 36.452</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-555c6a69-2b37-4970-a11c-e0c21559d9c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-555c6a69-2b37-4970-a11c-e0c21559d9c7_0">
											<gml:posList>35.66839988774922 139.7489788189804 34.955 35.66841430045831 139.74893986670517 39.266 35.66839988774922 139.7489788189804 39.266 35.66839988774922 139.7489788189804 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e7d8efba-1361-486d-b43c-f43046d15004">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e7d8efba-1361-486d-b43c-f43046d15004_0">
											<gml:posList>35.66839988774922 139.7489788189804 34.955 35.66841430045831 139.74893986670517 34.955 35.66841430045831 139.74893986670517 39.266 35.66839988774922 139.7489788189804 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2013b91d-362b-49de-8f81-e1d27c8f8eae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2013b91d-362b-49de-8f81-e1d27c8f8eae_0">
											<gml:posList>35.668434722402914 139.74898679067798 34.955 35.66844567882021 139.7489549445987 36.452 35.66844567882021 139.7489549445987 34.955 35.668434722402914 139.74898679067798 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd343bd3-a6be-4c90-8d3e-a2112ebd6626">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dd343bd3-a6be-4c90-8d3e-a2112ebd6626_0">
											<gml:posList>35.668434722402914 139.74898679067798 34.955 35.668434722402914 139.74898679067798 36.452 35.66844567882021 139.7489549445987 36.452 35.668434722402914 139.74898679067798 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01d96981-718e-415b-af19-39f484e9dcda">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01d96981-718e-415b-af19-39f484e9dcda_0">
											<gml:posList>35.66839988774922 139.7489788189804 34.955 35.66837421565246 139.74896455248472 39.266 35.66837421565246 139.74896455248472 34.955 35.66839988774922 139.7489788189804 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-456eb8cc-9142-44e3-a056-1838ac2a20c8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-456eb8cc-9142-44e3-a056-1838ac2a20c8_0">
											<gml:posList>35.66839988774922 139.7489788189804 34.955 35.66839988774922 139.7489788189804 39.266 35.66837421565246 139.74896455248472 39.266 35.66839988774922 139.7489788189804 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-842e0720-77de-4e7b-a1a5-3df9896ce9bc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-842e0720-77de-4e7b-a1a5-3df9896ce9bc_0">
											<gml:posList>35.66845628280295 139.74896041225355 34.955 35.668445326391975 139.74899226938228 36.452 35.668445326391975 139.74899226938228 34.955 35.66845628280295 139.74896041225355 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b292129d-1692-4983-b243-9f1f458a8692">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b292129d-1692-4983-b243-9f1f458a8692_0">
											<gml:posList>35.66845628280295 139.74896041225355 34.955 35.66845628280295 139.74896041225355 36.452 35.668445326391975 139.74899226938228 36.452 35.66845628280295 139.74896041225355 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c7466c3-7318-468b-b3fc-723eaacaaeab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c7466c3-7318-468b-b3fc-723eaacaaeab_0">
											<gml:posList>35.66837895556034 139.74898840682405 34.955 35.6683517963698 139.74897438490518 40.658 35.66837895556034 139.74898840682405 40.658 35.66837895556034 139.74898840682405 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e870192d-becc-4d9c-a965-1de122d7b211">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e870192d-becc-4d9c-a965-1de122d7b211_0">
											<gml:posList>35.66837895556034 139.74898840682405 34.955 35.6683517963698 139.74897438490518 34.955 35.6683517963698 139.74897438490518 40.658 35.66837895556034 139.74898840682405 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8110fa6-15b0-415b-aed6-5ce32fc0220b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b8110fa6-15b0-415b-aed6-5ce32fc0220b_0">
											<gml:posList>35.668445326391975 139.74899226938228 34.955 35.668434722402914 139.74898679067798 36.452 35.668434722402914 139.74898679067798 34.955 35.668445326391975 139.74899226938228 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-91367840-83b9-48b7-ac96-fde1a3d37565">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-91367840-83b9-48b7-ac96-fde1a3d37565_0">
											<gml:posList>35.668445326391975 139.74899226938228 34.955 35.668445326391975 139.74899226938228 36.452 35.668434722402914 139.74898679067798 36.452 35.668445326391975 139.74899226938228 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74d05eef-a44a-46d2-bcd8-548eff1cef99">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-74d05eef-a44a-46d2-bcd8-548eff1cef99_0">
											<gml:posList>35.6683517963698 139.74897438490518 34.955 35.668339913428326 139.74900893818378 40.658 35.6683517963698 139.74897438490518 40.658 35.6683517963698 139.74897438490518 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-95eb2be4-2d05-47c2-9051-2f8281c33d15">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-95eb2be4-2d05-47c2-9051-2f8281c33d15_0">
											<gml:posList>35.6683517963698 139.74897438490518 34.955 35.668339913428326 139.74900893818378 34.955 35.668339913428326 139.74900893818378 40.658 35.6683517963698 139.74897438490518 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-21845a89-8e0a-4db4-8998-b391d64fa1fc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-21845a89-8e0a-4db4-8998-b391d64fa1fc_0">
											<gml:posList>35.66839601765669 139.74899998716273 34.955 35.66838844351054 139.74899626158563 39.887 35.66839601765669 139.74899998716273 39.887 35.66839601765669 139.74899998716273 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-368dcacf-b056-4b82-813c-a1b579e40053">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-368dcacf-b056-4b82-813c-a1b579e40053_0">
											<gml:posList>35.66839601765669 139.74899998716273 34.955 35.66838844351054 139.74899626158563 34.955 35.66838844351054 139.74899626158563 39.887 35.66839601765669 139.74899998716273 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18759a16-ab20-40a1-b81f-157284d5c4c8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-18759a16-ab20-40a1-b81f-157284d5c4c8_0">
											<gml:posList>35.66836707261493 139.74902296011234 40.658 35.6683517963698 139.74897438490518 40.658 35.668339913428326 139.74900893818378 40.658 35.66836707261493 139.74902296011234 40.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-88836da2-5bc8-442b-b610-453c8f7c8c10">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-88836da2-5bc8-442b-b610-453c8f7c8c10_0">
											<gml:posList>35.66836707261493 139.74902296011234 40.658 35.66837895556034 139.74898840682405 40.658 35.6683517963698 139.74897438490518 40.658 35.66836707261493 139.74902296011234 40.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-62cc1046-eab9-44a9-aab0-2ad2e0cf60a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-62cc1046-eab9-44a9-aab0-2ad2e0cf60a5_0">
											<gml:posList>35.66844127844586 139.74900402657687 34.955 35.668430674457326 139.74899854787128 36.452 35.66844127844586 139.74900402657687 36.452 35.66844127844586 139.74900402657687 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1c707aa-150e-46cc-a6df-15620fddefcf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d1c707aa-150e-46cc-a6df-15620fddefcf_0">
											<gml:posList>35.66844127844586 139.74900402657687 34.955 35.668430674457326 139.74899854787128 34.955 35.668430674457326 139.74899854787128 36.452 35.66844127844586 139.74900402657687 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-202653da-835b-46dc-a554-8d9036886f04">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-202653da-835b-46dc-a554-8d9036886f04_0">
											<gml:posList>35.66836707261493 139.74902296011234 34.955 35.66837895556034 139.74898840682405 40.658 35.66836707261493 139.74902296011234 40.658 35.66836707261493 139.74902296011234 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e1ffa264-c7fd-4d35-86e6-9efda9bb050c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e1ffa264-c7fd-4d35-86e6-9efda9bb050c_0">
											<gml:posList>35.66836707261493 139.74902296011234 34.955 35.66837895556034 139.74898840682405 34.955 35.66837895556034 139.74898840682405 40.658 35.66836707261493 139.74902296011234 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e2d7d9a0-1e59-454a-a5c4-dfca466dea2d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e2d7d9a0-1e59-454a-a5c4-dfca466dea2d_0">
											<gml:posList>35.66837960191311 139.74902325622574 34.955 35.66838844351054 139.74899626158563 39.887 35.66838844351054 139.74899626158563 34.955 35.66837960191311 139.74902325622574 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18402b6d-a48b-4662-a8be-8b6c8a581b0b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-18402b6d-a48b-4662-a8be-8b6c8a581b0b_0">
											<gml:posList>35.66837960191311 139.74902325622574 34.955 35.66837960191311 139.74902325622574 39.887 35.66838844351054 139.74899626158563 39.887 35.66837960191311 139.74902325622574 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-65ba9d9c-6148-4b9f-aa49-b26c3149414f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-65ba9d9c-6148-4b9f-aa49-b26c3149414f_0">
											<gml:posList>35.66838844351054 139.74899626158563 39.887 35.66838718507218 139.7490269817955 39.887 35.66839601765669 139.74899998716273 39.887 35.66838844351054 139.74899626158563 39.887</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-137824ce-2672-4f6f-80d4-60eb7f1fd1c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-137824ce-2672-4f6f-80d4-60eb7f1fd1c7_0">
											<gml:posList>35.66838844351054 139.74899626158563 39.887 35.66837960191311 139.74902325622574 39.887 35.66838718507218 139.7490269817955 39.887 35.66838844351054 139.74899626158563 39.887</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-916b9fe7-c159-45c2-9462-cb91839c636a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-916b9fe7-c159-45c2-9462-cb91839c636a_0">
											<gml:posList>35.66839601765669 139.74899998716273 34.955 35.66838718507218 139.7490269817955 39.887 35.66838718507218 139.7490269817955 34.955 35.66839601765669 139.74899998716273 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec1de430-6bdd-4cb4-875a-7121996c0059">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ec1de430-6bdd-4cb4-875a-7121996c0059_0">
											<gml:posList>35.66839601765669 139.74899998716273 34.955 35.66839601765669 139.74899998716273 39.887 35.66838718507218 139.7490269817955 39.887 35.66839601765669 139.74899998716273 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-500146a9-17db-4c84-b4dc-b0bbd95931e8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-500146a9-17db-4c84-b4dc-b0bbd95931e8_0">
											<gml:posList>35.668339913428326 139.74900893818378 34.955 35.66836707261493 139.74902296011234 40.658 35.668339913428326 139.74900893818378 40.658 35.668339913428326 139.74900893818378 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74610044-bd0b-4236-818b-243b3c7e5d40">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-74610044-bd0b-4236-818b-243b3c7e5d40_0">
											<gml:posList>35.668339913428326 139.74900893818378 34.955 35.66836707261493 139.74902296011234 34.955 35.66836707261493 139.74902296011234 40.658 35.668339913428326 139.74900893818378 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-136eea51-bcdf-4d2e-9e45-27ee5a02457d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-136eea51-bcdf-4d2e-9e45-27ee5a02457d_0">
											<gml:posList>35.668430674457326 139.74899854787128 34.955 35.66841487850203 139.74904448266344 36.452 35.668430674457326 139.74899854787128 36.452 35.668430674457326 139.74899854787128 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e0b0dc8-06af-4ae8-b504-d7eb35bcc9a0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6e0b0dc8-06af-4ae8-b504-d7eb35bcc9a0_0">
											<gml:posList>35.668430674457326 139.74899854787128 34.955 35.66841487850203 139.74904448266344 34.955 35.66841487850203 139.74904448266344 36.452 35.668430674457326 139.74899854787128 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-93782073-bf3b-43be-aa5f-1b006ea3b402">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-93782073-bf3b-43be-aa5f-1b006ea3b402_0">
											<gml:posList>35.66844127844586 139.74900402657687 36.452 35.668430674457326 139.74899854787128 36.452 35.66841487850203 139.74904448266344 36.452 35.66844127844586 139.74900402657687 36.452</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a289157-ea9c-4004-a77e-f97529520b17">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3a289157-ea9c-4004-a77e-f97529520b17_0">
											<gml:posList>35.66842548248851 139.74904996137403 36.452 35.66844127844586 139.74900402657687 36.452 35.66841487850203 139.74904448266344 36.452 35.66842548248851 139.74904996137403 36.452</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e4713378-8e64-4780-9826-018f002b99d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e4713378-8e64-4780-9826-018f002b99d1_0">
											<gml:posList>35.66837960191311 139.74902325622574 34.955 35.66838718507218 139.7490269817955 39.887 35.66837960191311 139.74902325622574 39.887 35.66837960191311 139.74902325622574 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f8c312cd-9ba2-4d70-adc7-f360db2a90d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f8c312cd-9ba2-4d70-adc7-f360db2a90d7_0">
											<gml:posList>35.66837960191311 139.74902325622574 34.955 35.66838718507218 139.7490269817955 34.955 35.66838718507218 139.7490269817955 39.887 35.66837960191311 139.74902325622574 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f165a3f-46e0-48af-ae3c-764489de5e8d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9f165a3f-46e0-48af-ae3c-764489de5e8d_0">
											<gml:posList>35.66842548248851 139.74904996137403 34.955 35.66844127844586 139.74900402657687 36.452 35.66842548248851 139.74904996137403 36.452 35.66842548248851 139.74904996137403 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7336b12e-a48e-4076-84de-b525d1fdf252">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7336b12e-a48e-4076-84de-b525d1fdf252_0">
											<gml:posList>35.66842548248851 139.74904996137403 34.955 35.66844127844586 139.74900402657687 34.955 35.66844127844586 139.74900402657687 36.452 35.66842548248851 139.74904996137403 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b500e4cd-3b90-48ff-a694-d0fcc0a15e3f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b500e4cd-3b90-48ff-a694-d0fcc0a15e3f_0">
											<gml:posList>35.66836099888134 139.7490380111263 34.955 35.66833459712802 139.74902438605253 40.658 35.66836099888134 139.7490380111263 40.658 35.66836099888134 139.7490380111263 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7923f5ed-1aec-4265-a82f-c81dc27efbef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7923f5ed-1aec-4265-a82f-c81dc27efbef_0">
											<gml:posList>35.66836099888134 139.7490380111263 34.955 35.66833459712802 139.74902438605253 34.955 35.66833459712802 139.74902438605253 40.658 35.66836099888134 139.7490380111263 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4bc29d6-8628-4915-90bf-b3e9674ec7c0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4bc29d6-8628-4915-90bf-b3e9674ec7c0_0">
											<gml:posList>35.66833459712802 139.74902438605253 34.955 35.66832807545277 139.74904335885319 40.658 35.66833459712802 139.74902438605253 40.658 35.66833459712802 139.74902438605253 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43bf1201-501c-4384-92da-59a7025b8806">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-43bf1201-501c-4384-92da-59a7025b8806_0">
											<gml:posList>35.66833459712802 139.74902438605253 34.955 35.66832807545277 139.74904335885319 34.955 35.66832807545277 139.74904335885319 40.658 35.66833459712802 139.74902438605253 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-abcc19a8-7eee-461d-a0a1-7588f9717ebe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-abcc19a8-7eee-461d-a0a1-7588f9717ebe_0">
											<gml:posList>35.66836099888134 139.7490380111263 40.658 35.66832807545277 139.74904335885319 40.658 35.6683544772117 139.74905699497808 40.658 35.66836099888134 139.7490380111263 40.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-07d8a643-3e5b-4649-8826-aea69c5305f5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-07d8a643-3e5b-4649-8826-aea69c5305f5_0">
											<gml:posList>35.66836099888134 139.7490380111263 40.658 35.66833459712802 139.74902438605253 40.658 35.66832807545277 139.74904335885319 40.658 35.66836099888134 139.7490380111263 40.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f371c30-fc15-4852-a3e0-d79ae63a2079">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f371c30-fc15-4852-a3e0-d79ae63a2079_0">
											<gml:posList>35.66840917960839 139.74905419807823 34.955 35.66838049635556 139.74903910627341 40.658 35.66840917960839 139.74905419807823 40.658 35.66840917960839 139.74905419807823 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74174e89-e4d3-4b7e-bfdd-0fd58a26f488">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-74174e89-e4d3-4b7e-bfdd-0fd58a26f488_0">
											<gml:posList>35.66840917960839 139.74905419807823 34.955 35.66838049635556 139.74903910627341 34.955 35.66838049635556 139.74903910627341 40.658 35.66840917960839 139.74905419807823 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78d17c7f-0a36-45c4-9bd5-2ef5eb721e7d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78d17c7f-0a36-45c4-9bd5-2ef5eb721e7d_0">
											<gml:posList>35.66841487850203 139.74904448266344 34.955 35.66842548248851 139.74904996137403 36.452 35.66841487850203 139.74904448266344 36.452 35.66841487850203 139.74904448266344 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e1bba807-5595-4361-a04a-27796c57a80a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e1bba807-5595-4361-a04a-27796c57a80a_0">
											<gml:posList>35.66841487850203 139.74904448266344 34.955 35.66842548248851 139.74904996137403 34.955 35.66842548248851 139.74904996137403 36.452 35.66841487850203 139.74904448266344 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-50cc11ae-b1c6-4c0b-9d29-f43136bf392f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-50cc11ae-b1c6-4c0b-9d29-f43136bf392f_0">
											<gml:posList>35.66836099888134 139.7490380111263 34.955 35.6683544772117 139.74905699497808 40.658 35.6683544772117 139.74905699497808 34.955 35.66836099888134 139.7490380111263 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1ad0edab-952d-40eb-93a3-4a48f1dad8c5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1ad0edab-952d-40eb-93a3-4a48f1dad8c5_0">
											<gml:posList>35.66836099888134 139.7490380111263 34.955 35.66836099888134 139.7490380111263 40.658 35.6683544772117 139.74905699497808 40.658 35.66836099888134 139.7490380111263 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c5b0073-bec7-4018-aa72-ecc684356fee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8c5b0073-bec7-4018-aa72-ecc684356fee_0">
											<gml:posList>35.66832807545277 139.74904335885319 34.955 35.6683544772117 139.74905699497808 40.658 35.66832807545277 139.74904335885319 40.658 35.66832807545277 139.74904335885319 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75ea44e9-f7cd-404e-93ae-f7bc909ca612">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-75ea44e9-f7cd-404e-93ae-f7bc909ca612_0">
											<gml:posList>35.66832807545277 139.74904335885319 34.955 35.6683544772117 139.74905699497808 34.955 35.6683544772117 139.74905699497808 40.658 35.66832807545277 139.74904335885319 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a32e562-5d82-4a3d-8f8f-b681b4a0f22b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3a32e562-5d82-4a3d-8f8f-b681b4a0f22b_0">
											<gml:posList>35.66845492453802 139.74908028482088 36.999 35.66846427131893 139.74906674365417 36.999 35.6684602046745 139.7490646712807 36.999 35.66845492453802 139.74908028482088 36.999</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84cd5dc3-2fa8-4e50-b838-b2f23937ed32">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-84cd5dc3-2fa8-4e50-b838-b2f23937ed32_0">
											<gml:posList>35.66845492453802 139.74908028482088 36.999 35.66845899118218 139.749082357195 36.999 35.66846427131893 139.74906674365417 36.999 35.66845492453802 139.74908028482088 36.999</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b82c739-2575-47b3-8368-9128be119f4b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b82c739-2575-47b3-8368-9128be119f4b_0">
											<gml:posList>35.66844567882021 139.7489549445987 36.452 35.668434722402914 139.74898679067798 36.452 35.668445326391975 139.74899226938228 36.452 35.66844567882021 139.7489549445987 36.452</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29983383-6cbf-4f70-b8af-f3482919dd8a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29983383-6cbf-4f70-b8af-f3482919dd8a_0">
											<gml:posList>35.66845628280295 139.74896041225355 36.452 35.66844567882021 139.7489549445987 36.452 35.668445326391975 139.74899226938228 36.452 35.66845628280295 139.74896041225355 36.452</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec5e1b35-9474-44d8-9861-1928e6474676">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6683447146933 139.74908183660162 34.955 35.66831334095152 139.74908622168135 34.955 35.66831934989459 139.74906874063328 34.955 35.6683447146933 139.74908183660162 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6fc875f1-4ae9-4adc-abd3-747375bb4b9f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6683447146933 139.74908183660162 34.955 35.66833870574836 139.7490993176542 34.955 35.66831334095152 139.74908622168135 34.955 35.6683447146933 139.74908183660162 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f51ce508-c607-4ff7-93b4-cb40d1755bc7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66832807545277 139.74904335885319 34.955 35.66836099888134 139.7490380111263 34.955 35.6683544772117 139.74905699497808 34.955 35.66832807545277 139.74904335885319 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0db3d21d-c950-48f7-8ed1-575870497c04">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66832807545277 139.74904335885319 34.955 35.66833459712802 139.74902438605253 34.955 35.66836099888134 139.7490380111263 34.955 35.66832807545277 139.74904335885319 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-acab9935-f4d7-4361-a223-edc0bf262287">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6683517963698 139.74897438490518 34.955 35.66836707261493 139.74902296011234 34.955 35.668339913428326 139.74900893818378 34.955 35.6683517963698 139.74897438490518 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-41c34d66-52c5-4adf-8a6a-8bf8dc9001ba">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6683517963698 139.74897438490518 34.955 35.66837895556034 139.74898840682405 34.955 35.66836707261493 139.74902296011234 34.955 35.6683517963698 139.74897438490518 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61933978-bf96-4272-9080-28613eba2b61">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66835407579511 139.74911453391576 34.955 35.66839484034757 139.7490951164389 34.955 35.66838275002491 139.74912962575206 34.955 35.66835407579511 139.74911453391576 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a2075e3-0ec4-4d8f-9015-0fdcc39b8c7c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66835407579511 139.74911453391576 34.955 35.66836615709979 139.74908002462215 34.955 35.66839484034757 139.7490951164389 34.955 35.66835407579511 139.74911453391576 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9210e09c-5fdd-427a-a46d-34348e82c8aa">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66838718507218 139.7490269817955 34.955 35.66838844351054 139.74899626158563 34.955 35.66839601765669 139.74899998716273 34.955 35.66838718507218 139.7490269817955 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a7e93598-2af2-4ccc-ab4d-ecdf75738b89">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66838718507218 139.7490269817955 34.955 35.66837960191311 139.74902325622574 34.955 35.66838844351054 139.74899626158563 34.955 35.66838718507218 139.7490269817955 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea3137e5-5d91-4891-aed2-156d3811f2a1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66840917960839 139.74905419807823 34.955 35.66839744912791 139.74908767974887 34.955 35.6683687658792 139.74907258793428 34.955 35.66840917960839 139.74905419807823 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e5e3453c-5a75-4153-8473-7d064963ec35">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66838049635556 139.74903910627341 34.955 35.66840917960839 139.74905419807823 34.955 35.6683687658792 139.74907258793428 34.955 35.66838049635556 139.74903910627341 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e132199b-b0b3-48f7-a7ed-0f516d231c65">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66837421565246 139.74896455248472 34.955 35.66841430045831 139.74893986670517 34.955 35.66839988774922 139.7489788189804 34.955 35.66837421565246 139.74896455248472 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a80527fc-8af0-4b1f-b3a6-673df454e47e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66837421565246 139.74896455248472 34.955 35.66838861934329 139.74892560022894 34.955 35.66841430045831 139.74893986670517 34.955 35.66837421565246 139.74896455248472 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1ace8eb-56ca-4324-998c-51b5006e7792">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668400250239664 139.74916192793387 42.017 35.668407275859195 139.74918043363553 42.017 35.66839595966285 139.74917476787465 42.017 35.668400250239664 139.74916192793387 42.017</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27ace5ee-e2ae-4e94-a91d-f49a52fd62d0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668400250239664 139.74916192793387 42.017 35.66841156643659 139.74916759369324 42.017 35.668407275859195 139.74918043363553 42.017 35.668400250239664 139.74916192793387 42.017</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1fcca189-a34f-48e8-ab1e-d025ba3e30b2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66841487850203 139.74904448266344 34.955 35.668430674457326 139.74899854787128 34.955 35.66844127844586 139.74900402657687 34.955 35.66841487850203 139.74904448266344 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e02d835-2b25-4dd6-82a1-75fc83fa3e91">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66842548248851 139.74904996137403 34.955 35.66841487850203 139.74904448266344 34.955 35.66844127844586 139.74900402657687 34.955 35.66842548248851 139.74904996137403 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-674926b0-f02b-43a6-ae84-829ea7309aa8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66844567882021 139.7489549445987 34.955 35.66845628280295 139.74896041225355 34.955 35.668445326391975 139.74899226938228 34.955 35.66844567882021 139.7489549445987 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-69dcdbd9-a0b7-44a4-a680-4999db5ccdf7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668434722402914 139.74898679067798 34.955 35.66844567882021 139.7489549445987 34.955 35.668445326391975 139.74899226938228 34.955 35.668434722402914 139.74898679067798 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94a2de44-f137-491d-85d6-4f77ecf84348">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66846427131893 139.74906674365417 34.955 35.66845899118218 139.749082357195 34.955 35.66845492453802 139.74908028482088 34.955 35.66846427131893 139.74906674365417 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0011a69d-3e8f-4a64-a9e9-b251dd71402e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6684602046745 139.7490646712807 34.955 35.66846427131893 139.74906674365417 34.955 35.66845492453802 139.74908028482088 34.955 35.6684602046745 139.7490646712807 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-685bcfc6-f898-40bb-96da-7e538b5c3deb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66846508124761 139.7488205054507 33.586 35.668480539198015 139.7488068031659 33.586 35.66847454895634 139.74882519002082 33.586 35.66846508124761 139.7488205054507 33.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e76ef9d-e6f7-4972-919c-993c9a940577">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66846508124761 139.7488205054507 33.586 35.66847109849099 139.74880206333918 33.586 35.668480539198015 139.7488068031659 33.586 35.66846508124761 139.7488205054507 33.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3db5a5b-fa4f-4b36-a035-3bbd4dd967b0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66848187036847 139.7488027257891 34.2 35.66847109849099 139.74880206333918 34.2 35.66847242066309 139.74879800806426 34.2 35.66848187036847 139.7488027257891 34.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a0ed44b-6f08-4062-947b-7987c9f77a5a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66848187036847 139.7488027257891 34.2 35.668480539198015 139.7488068031659 34.2 35.66847109849099 139.74880206333918 34.2 35.66848187036847 139.7488027257891 34.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_690bdd16-db28-41ae-96b4-f6c3240d33ef_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-86dc5829-d586-4f3e-b9ff-6b1decd925a0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668493251186796 139.74884907385444 5.32 35.668504621757066 139.74881659767448 5.32 35.66854023853916 139.74883445466367 5.32 35.66853556124414 139.74884848802049 5.32 35.6685409714181 139.74885124382178 5.32 35.66853503475622 139.74886892368642 5.32 35.668493251186796 139.74884907385444 5.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4938dd5-4d03-47b4-8ef3-072885cdd7e7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4938dd5-4d03-47b4-8ef3-072885cdd7e7_0">
											<gml:posList>35.66854023853916 139.74883445466367 34.2 35.66854023853916 139.74883445466367 5.32 35.668504621757066 139.74881659767448 5.32 35.668504621757066 139.74881659767448 34.2 35.66854023853916 139.74883445466367 34.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c22ed80-2b5e-4de8-90ed-6f8afa9b0674">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c22ed80-2b5e-4de8-90ed-6f8afa9b0674_0">
											<gml:posList>35.668504621757066 139.74881659767448 34.2 35.668504621757066 139.74881659767448 5.32 35.668493251186796 139.74884907385444 5.32 35.668493251186796 139.74884907385444 34.2 35.668504621757066 139.74881659767448 34.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-55dd00e1-459c-448e-b4d1-887319fd7442">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-55dd00e1-459c-448e-b4d1-887319fd7442_0">
											<gml:posList>35.66853556124414 139.74884848802049 34.2 35.66853556124414 139.74884848802049 5.32 35.66854023853916 139.74883445466367 5.32 35.66854023853916 139.74883445466367 34.2 35.66853556124414 139.74884848802049 34.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6aa7da8a-c4d6-4923-90db-c40ff93ec84a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6aa7da8a-c4d6-4923-90db-c40ff93ec84a_0">
											<gml:posList>35.668493251186796 139.74884907385444 34.2 35.66853503475622 139.74886892368642 34.2 35.6685409714181 139.74885124382178 34.2 35.66853556124414 139.74884848802049 34.2 35.66854023853916 139.74883445466367 34.2 35.668504621757066 139.74881659767448 34.2 35.668493251186796 139.74884907385444 34.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e4131d3d-62b3-4a2d-b160-0b528951f022">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e4131d3d-62b3-4a2d-b160-0b528951f022_0">
											<gml:posList>35.6685409714181 139.74885124382178 34.2 35.6685409714181 139.74885124382178 5.32 35.66853556124414 139.74884848802049 5.32 35.66853556124414 139.74884848802049 34.2 35.6685409714181 139.74885124382178 34.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-93f1b7b2-af96-4f16-a4fe-2d9493892eff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-93f1b7b2-af96-4f16-a4fe-2d9493892eff_0">
											<gml:posList>35.668493251186796 139.74884907385444 34.2 35.668493251186796 139.74884907385444 5.32 35.66853503475622 139.74886892368642 5.32 35.66853503475622 139.74886892368642 34.2 35.668493251186796 139.74884907385444 34.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-87e2d7b7-8078-4243-b7c7-1a785f1be3da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-87e2d7b7-8078-4243-b7c7-1a785f1be3da_0">
											<gml:posList>35.66853503475622 139.74886892368642 34.2 35.66853503475622 139.74886892368642 5.32 35.6685409714181 139.74885124382178 5.32 35.6685409714181 139.74885124382178 34.2 35.66853503475622 139.74886892368642 34.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_690bdd16-db28-41ae-96b4-f6c3240d33ef_BuildingInstallation_1061">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-572d84d4-5d7c-4194-83f0-c75cd60d101c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-572d84d4-5d7c-4194-83f0-c75cd60d101c_0">
											<gml:posList>35.668381440916015 139.74877929266967 34.982 35.66845637124227 139.74881660434872 34.982 35.66845637124227 139.74881660434872 33.586 35.668381440916015 139.74877929266967 34.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-89d88e4b-b05b-498b-832b-e6b2ce70c88f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-89d88e4b-b05b-498b-832b-e6b2ce70c88f_0">
											<gml:posList>35.668381440916015 139.74877929266967 34.982 35.66845637124227 139.74881660434872 33.586 35.668381440916015 139.74877929266967 33.586 35.668381440916015 139.74877929266967 34.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d5887cc-12ee-4220-975e-b435f8f820f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d5887cc-12ee-4220-975e-b435f8f820f0_0">
											<gml:posList>35.66846452250504 139.7488206606836 33.586 35.66848409816048 139.74883040471408 33.586 35.668381440916015 139.74877929266967 33.586 35.66846452250504 139.7488206606836 33.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3fc4beb-4325-40d5-8108-759e2b95cc30">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b3fc4beb-4325-40d5-8108-759e2b95cc30_0">
											<gml:posList>35.66846452250504 139.7488206606836 34.982 35.66848409816048 139.74883040471408 34.982 35.66846452250504 139.7488206606836 33.586 35.66846452250504 139.7488206606836 34.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e00bb46-d7db-4816-ab69-25e39b71f3ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8e00bb46-d7db-4816-ab69-25e39b71f3ce_0">
											<gml:posList>35.66846452250504 139.7488206606836 33.586 35.66848409816048 139.74883040471408 34.982 35.66848409816048 139.74883040471408 33.586 35.66846452250504 139.7488206606836 33.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46e7ffb9-b7c2-4864-847e-738d239835da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46e7ffb9-b7c2-4864-847e-738d239835da_0">
											<gml:posList>35.66845637124227 139.74881660434872 33.586 35.66846452250504 139.7488206606836 33.586 35.668381440916015 139.74877929266967 33.586 35.66845637124227 139.74881660434872 33.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24c6a030-3e6f-4d32-a7d4-b8c75d983bd6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-24c6a030-3e6f-4d32-a7d4-b8c75d983bd6_0">
											<gml:posList>35.66848109764341 139.74883191013208 34.982 35.66846367702095 139.74882323529184 34.982 35.66846367702095 139.74882323529184 33.586 35.66848109764341 139.74883191013208 34.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-20e1555c-a6f3-49c5-af8b-851e9726daaf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-20e1555c-a6f3-49c5-af8b-851e9726daaf_0">
											<gml:posList>35.66848109764341 139.74883191013208 33.586 35.66848109764341 139.74883191013208 34.982 35.66846367702095 139.74882323529184 33.586 35.66848109764341 139.74883191013208 33.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-822c6372-63d5-4e27-895b-b33fde6bcc8e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-822c6372-63d5-4e27-895b-b33fde6bcc8e_0">
											<gml:posList>35.66845552575828 139.74881917895678 34.982 35.66838332754628 139.7487832230509 34.982 35.66845552575828 139.74881917895678 33.586 35.66845552575828 139.74881917895678 34.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0cdb3d2-b37d-451d-b271-a2f0e7d85320">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0cdb3d2-b37d-451d-b271-a2f0e7d85320_0">
											<gml:posList>35.66848109764341 139.74883191013208 33.586 35.66846367702095 139.74882323529184 33.586 35.66838332754628 139.7487832230509 33.586 35.66848109764341 139.74883191013208 33.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-47035c68-35e8-4ca1-8b46-63e8cfdcd9c5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-47035c68-35e8-4ca1-8b46-63e8cfdcd9c5_0">
											<gml:posList>35.66845552575828 139.74881917895678 33.586 35.66838332754628 139.7487832230509 34.982 35.66838332754628 139.7487832230509 33.586 35.66845552575828 139.74881917895678 33.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cdccc22e-d967-47d9-96b0-ada02e59cbc3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cdccc22e-d967-47d9-96b0-ada02e59cbc3_0">
											<gml:posList>35.66846367702095 139.74882323529184 33.586 35.66845552575828 139.74881917895678 33.586 35.66838332754628 139.7487832230509 33.586 35.66846367702095 139.74882323529184 33.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fcd0d58a-7659-4a20-a789-3a4397803357">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fcd0d58a-7659-4a20-a789-3a4397803357_0">
											<gml:posList>35.66845552575828 139.74881917895678 33.586 35.66845637124227 139.74881660434872 34.982 35.66845552575828 139.74881917895678 34.982 35.66845552575828 139.74881917895678 33.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33c77fd3-9153-4c9d-b9d6-e5f1959b3046">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-33c77fd3-9153-4c9d-b9d6-e5f1959b3046_0">
											<gml:posList>35.66845552575828 139.74881917895678 33.586 35.66845637124227 139.74881660434872 33.586 35.66845637124227 139.74881660434872 34.982 35.66845552575828 139.74881917895678 33.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5df0b5cf-c764-4a62-bcca-1f0dfdffe9ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5df0b5cf-c764-4a62-bcca-1f0dfdffe9ea_0">
											<gml:posList>35.66846452250504 139.7488206606836 33.586 35.66846367702095 139.74882323529184 34.982 35.66846452250504 139.7488206606836 34.982 35.66846452250504 139.7488206606836 33.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a55ac18-3fe1-48c5-9ad2-1ea63538ce8e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a55ac18-3fe1-48c5-9ad2-1ea63538ce8e_0">
											<gml:posList>35.66846452250504 139.7488206606836 33.586 35.66846367702095 139.74882323529184 33.586 35.66846367702095 139.74882323529184 34.982 35.66846452250504 139.7488206606836 33.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11d3c2ac-9973-4a37-b1ac-3654876e60da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-11d3c2ac-9973-4a37-b1ac-3654876e60da_0">
											<gml:posList>35.66847404209517 139.74886074762145 34.982 35.66848409816048 139.74883040471408 33.586 35.66848409816048 139.74883040471408 34.982 35.66847404209517 139.74886074762145 34.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e6022254-0907-4a59-a76c-a315bb14f74e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e6022254-0907-4a59-a76c-a315bb14f74e_0">
											<gml:posList>35.66847404209517 139.74886074762145 34.982 35.66847404209517 139.74886074762145 33.586 35.66848409816048 139.74883040471408 33.586 35.66847404209517 139.74886074762145 34.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea69f326-baa1-4e4e-ac05-c848a36fc6a9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea69f326-baa1-4e4e-ac05-c848a36fc6a9_0">
											<gml:posList>35.66848409816048 139.74883040471408 34.982 35.66846452250504 139.7488206606836 34.982 35.66848109764341 139.74883191013208 34.982 35.66848409816048 139.74883040471408 34.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8ed247e6-7b40-4db4-bba5-55d964856edf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8ed247e6-7b40-4db4-bba5-55d964856edf_0">
											<gml:posList>35.668485764047794 139.74886658965204 34.982 35.66849200409082 139.74885735966853 34.982 35.6684892719782 139.74885600388893 34.982 35.668485764047794 139.74886658965204 34.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c02459df-fca7-4564-90b2-fec2cd7b7ba9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c02459df-fca7-4564-90b2-fec2cd7b7ba9_0">
											<gml:posList>35.66849200409082 139.74885735966853 34.982 35.668485764047794 139.74886658965204 34.982 35.66848756971436 139.74887075209173 34.982 35.66849200409082 139.74885735966853 34.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c59e5631-dab3-4898-b478-0544e6803a1f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c59e5631-dab3-4898-b478-0544e6803a1f_0">
											<gml:posList>35.66848109764341 139.74883191013208 34.982 35.66846452250504 139.7488206606836 34.982 35.66846367702095 139.74882323529184 34.982 35.66848109764341 139.74883191013208 34.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26b25b5f-c37e-43b8-ad1b-c9abc6a149d5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-26b25b5f-c37e-43b8-ad1b-c9abc6a149d5_0">
											<gml:posList>35.66848409816048 139.74883040471408 34.982 35.66848109764341 139.74883191013208 34.982 35.66847404209517 139.74886074762145 34.982 35.66848409816048 139.74883040471408 34.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-463eb61a-9bf6-4be3-9d9d-ca6a745dd346">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-463eb61a-9bf6-4be3-9d9d-ca6a745dd346_0">
											<gml:posList>35.66847096061688 139.74886248508935 34.982 35.66848756971436 139.74887075209173 34.982 35.668485764047794 139.74886658965204 34.982 35.66847096061688 139.74886248508935 34.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3fa54ba6-dc24-4554-a213-11a3afeadd97">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3fa54ba6-dc24-4554-a213-11a3afeadd97_0">
											<gml:posList>35.66847096061688 139.74886248508935 34.982 35.668485764047794 139.74886658965204 34.982 35.66847404209517 139.74886074762145 34.982 35.66847096061688 139.74886248508935 34.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29a59b11-a2bc-4baa-9e6a-e8832a3e3d04">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29a59b11-a2bc-4baa-9e6a-e8832a3e3d04_0">
											<gml:posList>35.66848109764341 139.74883191013208 34.982 35.66847096061688 139.74886248508935 34.982 35.66847404209517 139.74886074762145 34.982 35.66848109764341 139.74883191013208 34.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-031d33c0-ae6f-4367-bc41-ac72280332d3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-031d33c0-ae6f-4367-bc41-ac72280332d3_0">
											<gml:posList>35.66847096061688 139.74886248508935 34.982 35.66848109764341 139.74883191013208 33.586 35.66847096061688 139.74886248508935 33.586 35.66847096061688 139.74886248508935 34.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d6f5a89-363a-417a-bb08-6eb8f34d0869">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d6f5a89-363a-417a-bb08-6eb8f34d0869_0">
											<gml:posList>35.66847096061688 139.74886248508935 34.982 35.66848109764341 139.74883191013208 34.982 35.66848109764341 139.74883191013208 33.586 35.66847096061688 139.74886248508935 34.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8bb53db4-501d-44d6-b3be-643d5ac87846">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8bb53db4-501d-44d6-b3be-643d5ac87846_0">
											<gml:posList>35.6684892719782 139.74885600388893 34.982 35.66849200409082 139.74885735966853 33.586 35.6684892719782 139.74885600388893 33.586 35.6684892719782 139.74885600388893 34.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c96b2da3-36d4-4532-97f7-1d01f0f6ad8a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c96b2da3-36d4-4532-97f7-1d01f0f6ad8a_0">
											<gml:posList>35.6684892719782 139.74885600388893 34.982 35.66849200409082 139.74885735966853 34.982 35.66849200409082 139.74885735966853 33.586 35.6684892719782 139.74885600388893 34.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bdc65eb9-19a5-41c0-adc2-c9f24a234066">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bdc65eb9-19a5-41c0-adc2-c9f24a234066_0">
											<gml:posList>35.668485764047794 139.74886658965204 34.982 35.6684892719782 139.74885600388893 33.586 35.668485764047794 139.74886658965204 33.586 35.668485764047794 139.74886658965204 34.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-02143b18-621b-4548-8764-e59d1813875f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-02143b18-621b-4548-8764-e59d1813875f_0">
											<gml:posList>35.668485764047794 139.74886658965204 34.982 35.6684892719782 139.74885600388893 34.982 35.6684892719782 139.74885600388893 33.586 35.668485764047794 139.74886658965204 34.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da752123-bcd9-48b7-9b9a-563dee751c03">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da752123-bcd9-48b7-9b9a-563dee751c03_0">
											<gml:posList>35.66847404209517 139.74886074762145 34.982 35.668485764047794 139.74886658965204 33.586 35.66847404209517 139.74886074762145 33.586 35.66847404209517 139.74886074762145 34.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29fb4378-c6cb-4603-9d89-16a3eeb7997e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29fb4378-c6cb-4603-9d89-16a3eeb7997e_0">
											<gml:posList>35.66847404209517 139.74886074762145 34.982 35.668485764047794 139.74886658965204 34.982 35.668485764047794 139.74886658965204 33.586 35.66847404209517 139.74886074762145 34.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2bcd5ad7-4f0a-4924-93ac-6c420cecd144">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2bcd5ad7-4f0a-4924-93ac-6c420cecd144_0">
											<gml:posList>35.66849200409082 139.74885735966853 34.982 35.66848756971436 139.74887075209173 33.586 35.66849200409082 139.74885735966853 33.586 35.66849200409082 139.74885735966853 34.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61ccc489-c324-467a-a935-40d6e06efbcf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-61ccc489-c324-467a-a935-40d6e06efbcf_0">
											<gml:posList>35.66849200409082 139.74885735966853 34.982 35.66848756971436 139.74887075209173 34.982 35.66848756971436 139.74887075209173 33.586 35.66849200409082 139.74885735966853 34.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a20ab7fe-e53e-45be-892a-05ed725d60d5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a20ab7fe-e53e-45be-892a-05ed725d60d5_0">
											<gml:posList>35.66848756971436 139.74887075209173 34.982 35.66847096061688 139.74886248508935 33.586 35.66848756971436 139.74887075209173 33.586 35.66848756971436 139.74887075209173 34.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c7e6726-a419-434c-b333-1d3e71ce63e9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3c7e6726-a419-434c-b333-1d3e71ce63e9_0">
											<gml:posList>35.66848756971436 139.74887075209173 34.982 35.66847096061688 139.74886248508935 34.982 35.66847096061688 139.74886248508935 33.586 35.66848756971436 139.74887075209173 34.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac236eda-bf2c-4cbd-8eeb-262eee19cebf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ac236eda-bf2c-4cbd-8eeb-262eee19cebf_0">
											<gml:posList>35.66831288325639 139.74898607934867 34.982 35.668381440916015 139.74877929266967 33.586 35.66831288325639 139.74898607934867 33.586 35.66831288325639 139.74898607934867 34.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c306a78e-8e9e-4d78-820f-e2f10882f089">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c306a78e-8e9e-4d78-820f-e2f10882f089_0">
											<gml:posList>35.66831288325639 139.74898607934867 34.982 35.668381440916015 139.74877929266967 34.982 35.668381440916015 139.74877929266967 33.586 35.66831288325639 139.74898607934867 34.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c53a206-fd09-4a1f-8abf-35a315d758fb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8c53a206-fd09-4a1f-8abf-35a315d758fb_0">
											<gml:posList>35.66838332754628 139.7487832230509 34.982 35.668316640773874 139.7489843522238 33.586 35.66838332754628 139.7487832230509 33.586 35.66838332754628 139.7487832230509 34.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b750ad3-650d-4c54-a216-5539ab61a3c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0b750ad3-650d-4c54-a216-5539ab61a3c6_0">
											<gml:posList>35.66838332754628 139.7487832230509 34.982 35.668316640773874 139.7489843522238 34.982 35.668316640773874 139.7489843522238 33.586 35.66838332754628 139.7487832230509 34.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d13ca58e-e201-480c-bbb8-968b23b75ed0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d13ca58e-e201-480c-bbb8-968b23b75ed0_0">
											<gml:posList>35.66845552575828 139.74881917895678 34.982 35.66845637124227 139.74881660434872 34.982 35.66838332754628 139.7487832230509 34.982 35.66845552575828 139.74881917895678 34.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb267c31-6d41-4c1d-bc5b-42b44247496f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb267c31-6d41-4c1d-bc5b-42b44247496f_0">
											<gml:posList>35.668316640773874 139.7489843522238 34.982 35.66832749962341 139.74899336536447 34.982 35.66832850698689 139.74899026038514 34.982 35.668316640773874 139.7489843522238 34.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b23b742e-c8df-4cbd-bd1a-fb4a39062ebf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b23b742e-c8df-4cbd-bd1a-fb4a39062ebf_0">
											<gml:posList>35.66832749962341 139.74899336536447 34.982 35.668316640773874 139.7489843522238 34.982 35.66831288325639 139.74898607934867 34.982 35.66832749962341 139.74899336536447 34.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3020256b-bdd1-44b8-a739-c90905c98339">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3020256b-bdd1-44b8-a739-c90905c98339_0">
											<gml:posList>35.66845637124227 139.74881660434872 34.982 35.668381440916015 139.74877929266967 34.982 35.66838332754628 139.7487832230509 34.982 35.66845637124227 139.74881660434872 34.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-987a2ae3-d814-4b51-9612-ce2fe398d46c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-987a2ae3-d814-4b51-9612-ce2fe398d46c_0">
											<gml:posList>35.668381440916015 139.74877929266967 34.982 35.66831288325639 139.74898607934867 34.982 35.668316640773874 139.7489843522238 34.982 35.668381440916015 139.74877929266967 34.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f86c5419-65e6-4c62-b30e-e658edfb0b07">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f86c5419-65e6-4c62-b30e-e658edfb0b07_0">
											<gml:posList>35.668381440916015 139.74877929266967 34.982 35.668316640773874 139.7489843522238 34.982 35.66838332754628 139.7487832230509 34.982 35.668381440916015 139.74877929266967 34.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e6c67df-83e4-4188-b2ed-0ba35e1763f9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3e6c67df-83e4-4188-b2ed-0ba35e1763f9_0">
											<gml:posList>35.668316640773874 139.7489843522238 34.982 35.66832850698689 139.74899026038514 33.586 35.668316640773874 139.7489843522238 33.586 35.668316640773874 139.7489843522238 34.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c83e0c6-554e-4339-856b-bc584c8922e6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c83e0c6-554e-4339-856b-bc584c8922e6_0">
											<gml:posList>35.668316640773874 139.7489843522238 34.982 35.66832850698689 139.74899026038514 34.982 35.66832850698689 139.74899026038514 33.586 35.668316640773874 139.7489843522238 34.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3aee8bca-5d06-4ef8-b678-30d01814fee0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3aee8bca-5d06-4ef8-b678-30d01814fee0_0">
											<gml:posList>35.66832749962341 139.74899336536447 34.982 35.66831288325639 139.74898607934867 33.586 35.66832749962341 139.74899336536447 33.586 35.66832749962341 139.74899336536447 34.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70b9cfc6-1fdf-4f37-aba6-594859ca0723">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-70b9cfc6-1fdf-4f37-aba6-594859ca0723_0">
											<gml:posList>35.66832749962341 139.74899336536447 34.982 35.66831288325639 139.74898607934867 34.982 35.66831288325639 139.74898607934867 33.586 35.66832749962341 139.74899336536447 34.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4ef837f1-f1e4-4b88-837b-b8147784e03f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4ef837f1-f1e4-4b88-837b-b8147784e03f_0">
											<gml:posList>35.66832850698689 139.74899026038514 34.982 35.66832749962341 139.74899336536447 33.586 35.66832850698689 139.74899026038514 33.586 35.66832850698689 139.74899026038514 34.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ed6f773e-0345-496a-ae1a-5c4d60800655">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ed6f773e-0345-496a-ae1a-5c4d60800655_0">
											<gml:posList>35.66832850698689 139.74899026038514 34.982 35.66832749962341 139.74899336536447 34.982 35.66832749962341 139.74899336536447 33.586 35.66832850698689 139.74899026038514 34.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-47680e56-61b6-44eb-a9f0-1db6ef5677e1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668485764047794 139.74886658965204 33.586 35.66849200409082 139.74885735966853 33.586 35.66848756971436 139.74887075209173 33.586 35.668485764047794 139.74886658965204 33.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33e32478-b21d-4107-bc65-ec98b3000841">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668316640773874 139.7489843522238 33.586 35.66832749962341 139.74899336536447 33.586 35.66831288325639 139.74898607934867 33.586 35.668316640773874 139.7489843522238 33.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b017fd12-552a-4f72-b28e-a639c165eb78">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668316640773874 139.7489843522238 33.586 35.66832850698689 139.74899026038514 33.586 35.66832749962341 139.74899336536447 33.586 35.668316640773874 139.7489843522238 33.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e7917be-0945-4fc4-834a-fb32e7e8e336">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668485764047794 139.74886658965204 33.586 35.6684892719782 139.74885600388893 33.586 35.66849200409082 139.74885735966853 33.586 35.668485764047794 139.74886658965204 33.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e91fc1ba-c9fe-4e7a-9a60-0f57398c88d4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66838332754628 139.7487832230509 33.586 35.668381440916015 139.74877929266967 33.586 35.66848409816048 139.74883040471408 33.586 35.66838332754628 139.7487832230509 33.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4629b9f3-6783-49b2-ba11-ac62e1b61226">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668316640773874 139.7489843522238 33.586 35.66831288325639 139.74898607934867 33.586 35.668381440916015 139.74877929266967 33.586 35.668316640773874 139.7489843522238 33.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a0859f2-2a4f-45bf-99d0-cde7954f7c32">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66847096061688 139.74886248508935 33.586 35.668485764047794 139.74886658965204 33.586 35.66848756971436 139.74887075209173 33.586 35.66847096061688 139.74886248508935 33.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ee77937d-0186-40dd-b910-1afdb2d7ed7b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66848409816048 139.74883040471408 33.586 35.66847404209517 139.74886074762145 33.586 35.66848109764341 139.74883191013208 33.586 35.66848409816048 139.74883040471408 33.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9847bfea-6527-4156-8c54-f2f8e5e329af">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668485764047794 139.74886658965204 33.586 35.66847096061688 139.74886248508935 33.586 35.66847404209517 139.74886074762145 33.586 35.668485764047794 139.74886658965204 33.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-695339d4-a5a5-49af-a60e-1cfd3fe1e919">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668316640773874 139.7489843522238 33.586 35.668381440916015 139.74877929266967 33.586 35.66838332754628 139.7487832230509 33.586 35.668316640773874 139.7489843522238 33.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3be8f21-4f52-471c-9206-9ef197a7a1aa">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66838332754628 139.7487832230509 33.586 35.66848409816048 139.74883040471408 33.586 35.66848109764341 139.74883191013208 33.586 35.66838332754628 139.7487832230509 33.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f54111fd-2a23-4c9f-9572-889fa73892b9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66847404209517 139.74886074762145 33.586 35.66847096061688 139.74886248508935 33.586 35.66848109764341 139.74883191013208 33.586 35.66847404209517 139.74886074762145 33.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef1551a7-0608-4567-9e71-4f249ac2e027">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66845552575828 139.74881917895678 33.586 35.66846452250504 139.7488206606836 33.586 35.66845637124227 139.74881660434872 33.586 35.66845552575828 139.74881917895678 33.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e7dc851d-2fb6-4a6d-96a7-8b494c7757dc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66845552575828 139.74881917895678 33.586 35.66846367702095 139.74882323529184 33.586 35.66846452250504 139.7488206606836 33.586 35.66845552575828 139.74881917895678 33.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_690bdd16-db28-41ae-96b4-f6c3240d33ef_BuildingInstallation_1031">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf569c7d-b9cb-4bd6-833b-9ddc172f8efb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66847201488249 139.74879777652612 34.2 35.668470674698476 139.74880185391203 34.2 35.6684625324333 139.74879777547727 34.2 35.668463872617195 139.74879369809173 34.2 35.66847201488249 139.74879777652612 34.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4720ec98-8fba-4486-aa94-e501e1615ff7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66844259175042 139.74885871515346 33.586 35.6684625324333 139.74879777547727 33.586 35.668470674698476 139.74880185391203 33.586 35.668450752002265 139.74886273834443 33.586 35.66844259175042 139.74885871515346 33.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-710ff9e4-0a9d-4ba3-890c-ac58eeccd7b7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66838969390351 139.74885122647382 34.955 35.66830905446644 139.74909201427593 34.955 35.668303680460866 139.749089413072 34.955 35.66838626295192 139.7488430560594 34.955 35.66843926378436 139.74886885888097 34.955 35.668440747872616 139.74886432846048 34.955 35.66844890812428 139.74886835165196 34.955 35.66844549921205 139.74887874952302 34.955 35.66838969390351 139.74885122647382 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-734dff4c-5063-4cdd-85f6-dde8a5dea227">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-734dff4c-5063-4cdd-85f6-dde8a5dea227_0">
											<gml:posList>35.668450752002265 139.74886273834443 37.005 35.66844259175042 139.74885871515346 37.005 35.66844259175042 139.74885871515346 33.586 35.668450752002265 139.74886273834443 33.586 35.668450752002265 139.74886273834443 37.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d29ef0f9-2e15-4564-93ac-677c5a2e8a0d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d29ef0f9-2e15-4564-93ac-677c5a2e8a0d_0">
											<gml:posList>35.66830905446644 139.74909201427593 34.955 35.66830905446644 139.74909201427593 38.045 35.668303680460866 139.749089413072 38.045 35.668303680460866 139.749089413072 34.955 35.66830905446644 139.74909201427593 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db7d7c2b-2701-4de3-91a2-3ab3a8825041">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-db7d7c2b-2701-4de3-91a2-3ab3a8825041_0">
											<gml:posList>35.668303680460866 139.749089413072 34.955 35.668303680460866 139.749089413072 38.045 35.66838626295192 139.7488430560594 38.045 35.66838626295192 139.7488430560594 34.955 35.668303680460866 139.749089413072 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8366d528-09b0-409e-b8a3-4c7d8b18de85">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8366d528-09b0-409e-b8a3-4c7d8b18de85_0">
											<gml:posList>35.66838969390351 139.74885122647382 38.045 35.66830905446644 139.74909201427593 38.045 35.66830905446644 139.74909201427593 34.955 35.66838969390351 139.74885122647382 34.955 35.66838969390351 139.74885122647382 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99e3af32-7d07-4293-8b79-7779695cfc14">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-99e3af32-7d07-4293-8b79-7779695cfc14_0">
											<gml:posList>35.668303680460866 139.749089413072 38.045 35.66830905446644 139.74909201427593 38.045 35.66838969390351 139.74885122647382 38.045 35.66844549921205 139.74887874952302 38.045 35.66844890812428 139.74886835165196 38.045 35.668440747872616 139.74886432846048 38.045 35.66843926378436 139.74886885888097 38.045 35.66838626295192 139.7488430560594 38.045 35.668303680460866 139.749089413072 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8316cb48-4108-4914-9ad6-556e141dfeff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8316cb48-4108-4914-9ad6-556e141dfeff_0">
											<gml:posList>35.66838626295192 139.7488430560594 34.955 35.66838626295192 139.7488430560594 38.045 35.66843926378436 139.74886885888097 38.045 35.66843926378436 139.74886885888097 34.955 35.66838626295192 139.7488430560594 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d13cf246-1632-4aae-ac84-d54bfebd1852">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d13cf246-1632-4aae-ac84-d54bfebd1852_0">
											<gml:posList>35.66844549921205 139.74887874952302 34.955 35.66844549921205 139.74887874952302 38.045 35.66838969390351 139.74885122647382 38.045 35.66838969390351 139.74885122647382 34.955 35.66844549921205 139.74887874952302 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd379d04-6327-4139-b345-7e472a104111">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dd379d04-6327-4139-b345-7e472a104111_0">
											<gml:posList>35.66843926378436 139.74886885888097 38.045 35.668440747872616 139.74886432846048 38.045 35.668440747872616 139.74886432846048 34.955 35.66843926378436 139.74886885888097 34.955 35.66843926378436 139.74886885888097 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8af2674-9ff9-49b1-8eea-d97f8a1111fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8af2674-9ff9-49b1-8eea-d97f8a1111fd_0">
											<gml:posList>35.66844890812428 139.74886835165196 34.955 35.668440747872616 139.74886432846048 34.955 35.668440747872616 139.74886432846048 38.045 35.66844890812428 139.74886835165196 38.045 35.66844890812428 139.74886835165196 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cdddf612-4e8c-453a-a60e-fca17203d2a3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cdddf612-4e8c-453a-a60e-fca17203d2a3_0">
											<gml:posList>35.66844549921205 139.74887874952302 38.045 35.66844549921205 139.74887874952302 34.955 35.66844890812428 139.74886835165196 34.955 35.66844890812428 139.74886835165196 38.045 35.66844549921205 139.74887874952302 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c368814-8b88-4894-a813-46ac147eca5c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8c368814-8b88-4894-a813-46ac147eca5c_0">
											<gml:posList>35.668463872617195 139.74879369809173 37.005 35.668463872617195 139.74879369809173 34.2 35.6684625324333 139.74879777547727 34.2 35.6684625324333 139.74879777547727 33.586 35.66844259175042 139.74885871515346 33.586 35.66844259175042 139.74885871515346 37.005 35.668463872617195 139.74879369809173 37.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f0a4cb3c-54ff-4b8d-b6e9-62d8168f9d1f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f0a4cb3c-54ff-4b8d-b6e9-62d8168f9d1f_0">
											<gml:posList>35.668450752002265 139.74886273834443 37.005 35.66847201488249 139.74879777652612 37.005 35.668463872617195 139.74879369809173 37.005 35.66844259175042 139.74885871515346 37.005 35.668450752002265 139.74886273834443 37.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5dca3506-3b66-4ee0-a9a2-150f0dc9502e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5dca3506-3b66-4ee0-a9a2-150f0dc9502e_0">
											<gml:posList>35.668450752002265 139.74886273834443 33.586 35.668470674698476 139.74880185391203 33.586 35.668470674698476 139.74880185391203 34.2 35.66847201488249 139.74879777652612 34.2 35.66847201488249 139.74879777652612 37.005 35.668450752002265 139.74886273834443 37.005 35.668450752002265 139.74886273834443 33.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2efe4b88-5bd9-40c7-b304-bf498dc546ae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2efe4b88-5bd9-40c7-b304-bf498dc546ae_0">
											<gml:posList>35.6684625324333 139.74879777547727 34.2 35.668470674698476 139.74880185391203 34.2 35.668470674698476 139.74880185391203 33.586 35.6684625324333 139.74879777547727 33.586 35.6684625324333 139.74879777547727 34.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1fef3e65-3a24-40fc-84e2-8de2b898668f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1fef3e65-3a24-40fc-84e2-8de2b898668f_0">
											<gml:posList>35.668463872617195 139.74879369809173 34.2 35.668463872617195 139.74879369809173 37.005 35.66847201488249 139.74879777652612 37.005 35.66847201488249 139.74879777652612 34.2 35.668463872617195 139.74879369809173 34.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-7333b957-9ed7-4239-8c92-557787fb2084">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7333b957-9ed7-4239-8c92-557787fb2084">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7333b957-9ed7-4239-8c92-557787fb2084">
											<gml:posList>35.66825369842148 139.74897227891768 5.32 35.66826242331693 139.7489459803332 5.32 35.66826467752301 139.7489470825577 5.32 35.66828518576768 139.74888564537227 5.32 35.6683017768366 139.7488939123794 5.32 35.66835385684933 139.7487378882822 5.32 35.6685055212691 139.74881394568587 5.32 35.668504621757066 139.74881659767448 5.32 35.668493251186796 139.74884907385444 5.32 35.66853503475622 139.74886892368642 5.32 35.66862484308554 139.7489138968377 5.32 35.66852679916431 139.74920793425318 5.32 35.66844516025247 139.74916706136122 5.32 35.668430804646796 139.74921044299342 5.32 35.6682814217897 139.74913558652514 5.32 35.668324909185756 139.74900124387085 5.32 35.66826721901341 139.7489722646927 5.32 35.66826524009456 139.74897812113824 5.32 35.66825369842148 139.74897227891768 5.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0ecde677-371a-41a2-8b51-da9a068f4cc9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ecde677-371a-41a2-8b51-da9a068f4cc9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ecde677-371a-41a2-8b51-da9a068f4cc9">
											<gml:posList>35.66837859925547 139.74875029995692 34.2 35.66838082119458 139.74875679265213 34.2 35.6685001960556 139.7488166575694 34.2 35.6685055212691 139.74881394568587 34.2 35.66837859925547 139.74875029995692 34.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9b92d5af-61b4-4f95-bb2c-bcb15ef8e5be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b92d5af-61b4-4f95-bb2c-bcb15ef8e5be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b92d5af-61b4-4f95-bb2c-bcb15ef8e5be">
											<gml:posList>35.668504621757066 139.74881659767448 34.2 35.6685055212691 139.74881394568587 34.2 35.6685001960556 139.7488166575694 34.2 35.668504621757066 139.74881659767448 34.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1ad76773-253c-4c76-ad89-efcf691a2918">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ad76773-253c-4c76-ad89-efcf691a2918">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ad76773-253c-4c76-ad89-efcf691a2918">
											<gml:posList>35.668493251186796 139.74884907385444 34.2 35.668504621757066 139.74881659767448 34.2 35.6685001960556 139.7488166575694 34.2 35.668487871936634 139.74885185206813 34.2 35.668493251186796 139.74884907385444 34.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ed5a1a15-0f83-4028-8b83-b872ac4d71d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed5a1a15-0f83-4028-8b83-b872ac4d71d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed5a1a15-0f83-4028-8b83-b872ac4d71d0">
											<gml:posList>35.668493251186796 139.74884907385444 34.2 35.668487871936634 139.74885185206813 34.2 35.6685335056534 139.74887353148162 34.2 35.66853503475622 139.74886892368642 34.2 35.668493251186796 139.74884907385444 34.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e78fa11f-590f-40a4-80ce-5c9a322b67c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e78fa11f-590f-40a4-80ce-5c9a322b67c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e78fa11f-590f-40a4-80ce-5c9a322b67c4">
											<gml:posList>35.66827436942238 139.74897585815606 16.6 35.66829912083361 139.74898829197446 16.6 35.66830104573247 139.74898252395133 16.6 35.66827909858834 139.7489715121142 16.6 35.668354987732314 139.748743818781 16.6 35.66837707014163 139.7487548856534 16.6 35.66837859925547 139.74875029995692 16.6 35.66835385684933 139.7487378882822 16.6 35.66827436942238 139.74897585815606 16.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-838151a6-9ded-4af6-adba-e67cd1aba263">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-838151a6-9ded-4af6-adba-e67cd1aba263">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-838151a6-9ded-4af6-adba-e67cd1aba263">
											<gml:posList>35.668354987732314 139.748743818781 16.037 35.66827909858834 139.7489715121142 16.037 35.66830104573247 139.74898252395133 16.037 35.66837707014163 139.7487548856534 16.037 35.668354987732314 139.748743818781 16.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7f2f0f9b-0c2c-4875-a52b-81347146f86c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f2f0f9b-0c2c-4875-a52b-81347146f86c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f2f0f9b-0c2c-4875-a52b-81347146f86c">
											<gml:posList>35.668381060735754 139.7488283703812 38.045 35.668383986780064 139.74883634249878 38.045 35.6685250644596 139.74890590516674 38.045 35.66853202089644 139.7489028160065 38.045 35.668381060735754 139.7488283703812 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-902f6126-d1ae-4a98-aac9-797c3bb2aabc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-902f6126-d1ae-4a98-aac9-797c3bb2aabc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-902f6126-d1ae-4a98-aac9-797c3bb2aabc">
											<gml:posList>35.66829912083361 139.74898829197446 34.2 35.66830441900999 139.74898558013763 34.2 35.66838082119458 139.74875679265213 34.2 35.66837859925547 139.74875029995692 34.2 35.66829912083361 139.74898829197446 34.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-74988eca-142d-4581-b25e-454ddfa456bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74988eca-142d-4581-b25e-454ddfa456bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74988eca-142d-4581-b25e-454ddfa456bc">
											<gml:posList>35.66853503475622 139.74886892368642 34.2 35.6685335056534 139.74887353148162 34.2 35.6685938647855 139.74890375607376 34.2 35.66859914492449 139.74890103319433 34.2 35.66853503475622 139.74886892368642 34.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ff030566-29eb-4fc2-be26-8f6fd8165503">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff030566-29eb-4fc2-be26-8f6fd8165503">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff030566-29eb-4fc2-be26-8f6fd8165503">
											<gml:posList>35.66860099653363 139.74890644379198 27.1 35.66859914492449 139.74890103319433 27.1 35.668597858656724 139.74890487856186 27.1 35.66860099653363 139.74890644379198 27.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b5d75e18-26e2-4c98-a188-40233f5bf1f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b5d75e18-26e2-4c98-a188-40233f5bf1f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b5d75e18-26e2-4c98-a188-40233f5bf1f2">
											<gml:posList>35.66859914492449 139.74890103319433 27.1 35.66860099653363 139.74890644379198 27.1 35.66862041893289 139.74891616592927 27.1 35.66862484308554 139.7489138968377 27.1 35.66859914492449 139.74890103319433 27.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-243f7385-af5e-4fac-a0d8-55312aaacd89">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-243f7385-af5e-4fac-a0d8-55312aaacd89">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-243f7385-af5e-4fac-a0d8-55312aaacd89">
											<gml:posList>35.6683017768366 139.7488939123794 9.7 35.66828518576768 139.74888564537227 9.7 35.66826467752301 139.7489470825577 9.7 35.66827416314621 139.74895161246863 9.7 35.66826721901341 139.7489722646927 9.7 35.66827436942238 139.74897585815606 9.7 35.6683017768366 139.7488939123794 9.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-79f5ae62-669c-4dcb-a943-ec7919bf18b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79f5ae62-669c-4dcb-a943-ec7919bf18b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79f5ae62-669c-4dcb-a943-ec7919bf18b8">
											<gml:posList>35.66826524009456 139.74897812113824 15.228 35.66827416314621 139.74895161246863 15.228 35.66826242331693 139.7489459803332 15.228 35.66825369842148 139.74897227891768 15.228 35.66826524009456 139.74897812113824 15.228</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0d7c7725-63d9-469b-b9e7-22db1deb3f31">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d7c7725-63d9-469b-b9e7-22db1deb3f31">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d7c7725-63d9-469b-b9e7-22db1deb3f31">
											<gml:posList>35.668487871936634 139.74885185206813 33.586 35.6685001960556 139.7488166575694 33.586 35.66838082119458 139.74875679265213 33.586 35.66830441900999 139.74898558013763 33.586 35.66832656449345 139.74899664700334 33.586 35.66838103368681 139.7488283593637 33.586 35.668532084015766 139.74890284907804 33.586 35.668446265605525 139.7491622883316 33.586 35.668450368264594 139.74916430544192 33.586 35.66849887913413 139.749188599906 33.586 35.6685938647855 139.74890375607376 33.586 35.6685335056534 139.74887353148162 33.586 35.668487871936634 139.74885185206813 33.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1a4fb30b-17df-475d-bcb3-23f5d11fdc77">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a4fb30b-17df-475d-bcb3-23f5d11fdc77">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a4fb30b-17df-475d-bcb3-23f5d11fdc77">
											<gml:posList>35.668281584098594 139.74913567472248 38.045 35.66828788232325 139.74913227699557 38.045 35.668383986780064 139.74883634249878 38.045 35.668381060735754 139.7488283703812 38.045 35.668281584098594 139.74913567472248 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-102608b4-1f2f-4907-851c-d427813d4304">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-102608b4-1f2f-4907-851c-d427813d4304">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-102608b4-1f2f-4907-851c-d427813d4304">
											<gml:posList>35.66830441900999 139.74898558013763 34.2 35.66829912083361 139.74898829197446 34.2 35.668325053459554 139.74900132104094 34.2 35.66832656449345 139.74899664700334 34.2 35.66830441900999 139.74898558013763 34.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-19317fb1-9f5b-438a-b8b4-ebdd6b49f519">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-19317fb1-9f5b-438a-b8b4-ebdd6b49f519">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-19317fb1-9f5b-438a-b8b4-ebdd6b49f519">
											<gml:posList>35.668323101568504 139.74912308289694 34.955 35.668355309912414 139.74913922038778 34.955 35.668359780366075 139.74912581691765 34.955 35.66842132066751 139.74915665897004 34.955 35.668409168558746 139.74919306826024 34.955 35.668413731102675 139.74919534999236 34.955 35.66842788761782 139.74920243771007 34.955 35.6685250644596 139.74890590516674 34.955 35.668383986780064 139.74883634249878 34.955 35.66828788232325 139.74913227699557 34.955 35.66831085736523 139.74914378486756 34.955 35.66831542893161 139.74914607763057 34.955 35.668323101568504 139.74912308289694 34.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-11f677ee-e2cd-4774-b420-0c3eeef8448b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11f677ee-e2cd-4774-b420-0c3eeef8448b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11f677ee-e2cd-4774-b420-0c3eeef8448b">
											<gml:posList>35.66859914492449 139.74890103319433 34.2 35.6685938647855 139.74890375607376 34.2 35.66849887913413 139.749188599906 34.2 35.668501101034146 139.74919507053116 34.2 35.66859914492449 139.74890103319433 34.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-af42e2bc-d3e1-4a46-a695-cc6504dc61ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af42e2bc-d3e1-4a46-a695-cc6504dc61ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af42e2bc-d3e1-4a46-a695-cc6504dc61ae">
											<gml:posList>35.66850553419818 139.7491927904029 26.64 35.66852494756098 139.74920251260752 26.64 35.66862041893289 139.74891616592927 26.64 35.66860099653363 139.74890644379198 26.64 35.668597858656724 139.74890487856186 26.64 35.6685023873035 139.74919121412688 26.64 35.66850553419818 139.7491927904029 26.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c70f0f5e-02ed-446d-a15d-055c32ac05fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c70f0f5e-02ed-446d-a15d-055c32ac05fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c70f0f5e-02ed-446d-a15d-055c32ac05fe">
											<gml:posList>35.66853202089644 139.7489028160065 38.045 35.6685250644596 139.74890590516674 38.045 35.66842788761782 139.74920243771007 38.045 35.66843033577091 139.7492102115195 38.045 35.66853202089644 139.7489028160065 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3951e3c9-eb8d-4e5c-ac19-c59fdbdce768">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3951e3c9-eb8d-4e5c-ac19-c59fdbdce768">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3951e3c9-eb8d-4e5c-ac19-c59fdbdce768">
											<gml:posList>35.66862484308554 139.7489138968377 27.1 35.66862041893289 139.74891616592927 27.1 35.66852494756098 139.74920251260752 27.1 35.66852679916431 139.74920793425318 27.1 35.66862484308554 139.7489138968377 27.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bd6287ec-3efe-4c50-95ac-f63608b41d89">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd6287ec-3efe-4c50-95ac-f63608b41d89">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd6287ec-3efe-4c50-95ac-f63608b41d89">
											<gml:posList>35.668355309912414 139.74913922038778 42.322 35.668323101568504 139.74912308289694 42.322 35.668324248652496 139.74912642862327 42.322 35.66835645699595 139.7491425661157 42.322 35.668355309912414 139.74913922038778 42.322</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1c3a3fee-8fcf-40ac-8b0d-6e51f1b06c1c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c3a3fee-8fcf-40ac-8b0d-6e51f1b06c1c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c3a3fee-8fcf-40ac-8b0d-6e51f1b06c1c">
											<gml:posList>35.668355309912414 139.74913922038778 42.322 35.66835645699595 139.7491425661157 42.322 35.66836092744999 139.74912916264557 42.322 35.668359780366075 139.74912581691765 42.322 35.668355309912414 139.74913922038778 42.322</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4c77cf76-dba2-447e-a219-e972673313ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c77cf76-dba2-447e-a219-e972673313ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c77cf76-dba2-447e-a219-e972673313ec">
											<gml:posList>35.66831355799916 139.74915169095047 42.322 35.66831628817029 139.74915027419925 42.322 35.668324248652496 139.74912642862327 42.322 35.668323101568504 139.74912308289694 42.322 35.66831355799916 139.74915169095047 42.322</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-92a75d64-9514-4791-bbc1-75f036f2bf77">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-92a75d64-9514-4791-bbc1-75f036f2bf77">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-92a75d64-9514-4791-bbc1-75f036f2bf77">
											<gml:posList>35.66831355799916 139.74915169095047 38.045 35.66831085736523 139.74914378486756 38.045 35.66828788232325 139.74913227699557 38.045 35.668281584098594 139.74913567472248 38.045 35.66831355799916 139.74915169095047 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a955d81a-9c8a-4c28-85df-b9f025413d4e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a955d81a-9c8a-4c28-85df-b9f025413d4e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a955d81a-9c8a-4c28-85df-b9f025413d4e">
											<gml:posList>35.668359780366075 139.74912581691765 42.322 35.66836092744999 139.74912916264557 42.322 35.66841858146719 139.7491580536404 42.322 35.66842132066751 139.74915665897004 42.322 35.668359780366075 139.74912581691765 42.322</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-37f1ca52-0274-4c98-a4b0-c4dad697d9bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37f1ca52-0274-4c98-a4b0-c4dad697d9bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37f1ca52-0274-4c98-a4b0-c4dad697d9bd">
											<gml:posList>35.66831085736523 139.74914378486756 38.045 35.66831355799916 139.74915169095047 38.045 35.66831542893161 139.74914607763057 38.045 35.66831085736523 139.74914378486756 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ee0a2aee-62dc-4348-8450-9214eb45be86">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee0a2aee-62dc-4348-8450-9214eb45be86">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee0a2aee-62dc-4348-8450-9214eb45be86">
											<gml:posList>35.66840614151301 139.7491953137723 42.017 35.66841858146719 139.7491580536404 42.017 35.66836092744999 139.74912916264557 42.017 35.66835645699595 139.7491425661157 42.017 35.668324248652496 139.74912642862327 42.017 35.66831628817029 139.74915027419925 42.017 35.66840614151301 139.7491953137723 42.017</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fa0dbe8d-9d5e-4c83-9e1e-ae1ea2523a26">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa0dbe8d-9d5e-4c83-9e1e-ae1ea2523a26">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa0dbe8d-9d5e-4c83-9e1e-ae1ea2523a26">
											<gml:posList>35.668446256584076 139.74916227729508 34.2 35.66844473646057 139.7491668519322 34.2 35.668450368264594 139.74916430544192 34.2 35.668446256584076 139.74916227729508 34.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d5d0d6a1-5ce8-453e-a10d-908ba8f515b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5d0d6a1-5ce8-453e-a10d-908ba8f515b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5d0d6a1-5ce8-453e-a10d-908ba8f515b3">
											<gml:posList>35.668407297616426 139.7491986705397 42.322 35.66840614151301 139.7491953137723 42.322 35.66831628817029 139.74915027419925 42.322 35.66831355799916 139.74915169095047 42.322 35.668407297616426 139.7491986705397 42.322</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-38e6be30-827f-41bb-8d74-02dd0006e1d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38e6be30-827f-41bb-8d74-02dd0006e1d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38e6be30-827f-41bb-8d74-02dd0006e1d1">
											<gml:posList>35.66842132066751 139.74915665897004 42.322 35.66841858146719 139.7491580536404 42.322 35.66840614151301 139.7491953137723 42.322 35.668407297616426 139.7491986705397 42.322 35.66842132066751 139.74915665897004 42.322</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-977b210a-b941-4649-8360-e597376a6eac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-977b210a-b941-4649-8360-e597376a6eac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-977b210a-b941-4649-8360-e597376a6eac">
											<gml:posList>35.668501101034146 139.74919507053116 34.2 35.66849887913413 139.749188599906 34.2 35.668450368264594 139.74916430544192 34.2 35.66844473646057 139.7491668519322 34.2 35.668501101034146 139.74919507053116 34.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-addae228-2217-4698-8538-67e62e69957d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-addae228-2217-4698-8538-67e62e69957d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-addae228-2217-4698-8538-67e62e69957d">
											<gml:posList>35.6685023873035 139.74919121412688 27.1 35.668501101034146 139.74919507053116 27.1 35.66850553419818 139.7491927904029 27.1 35.6685023873035 139.74919121412688 27.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f8b878bd-9ef1-4eb8-8643-533c0d5210f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f8b878bd-9ef1-4eb8-8643-533c0d5210f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f8b878bd-9ef1-4eb8-8643-533c0d5210f0">
											<gml:posList>35.668409168558746 139.74919306826024 38.045 35.668407297616426 139.7491986705397 38.045 35.668413731102675 139.74919534999236 38.045 35.668409168558746 139.74919306826024 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-10931778-f662-4baa-83fb-f4e744a3246b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-10931778-f662-4baa-83fb-f4e744a3246b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-10931778-f662-4baa-83fb-f4e744a3246b">
											<gml:posList>35.66852679916431 139.74920793425318 27.1 35.66852494756098 139.74920251260752 27.1 35.66850553419818 139.7491927904029 27.1 35.668501101034146 139.74919507053116 27.1 35.66852679916431 139.74920793425318 27.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4c602eb0-da80-47ad-b576-9983938227fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c602eb0-da80-47ad-b576-9983938227fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c602eb0-da80-47ad-b576-9983938227fc">
											<gml:posList>35.66843033577091 139.7492102115195 38.045 35.66842788761782 139.74920243771007 38.045 35.668413731102675 139.74919534999236 38.045 35.668407297616426 139.7491986705397 38.045 35.66843033577091 139.7492102115195 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c23ccf41-b9ff-4c28-92a0-0a56a3a7f479">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c23ccf41-b9ff-4c28-92a0-0a56a3a7f479">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c23ccf41-b9ff-4c28-92a0-0a56a3a7f479">
											<gml:posList>35.668324248652496 139.74912642862327 42.322 35.668324248652496 139.74912642862327 42.017 35.66835645699595 139.7491425661157 42.017 35.66835645699595 139.7491425661157 42.322 35.668324248652496 139.74912642862327 42.322</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6f0fd1e2-832a-4d59-b760-2f5abd71ae34">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f0fd1e2-832a-4d59-b760-2f5abd71ae34">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f0fd1e2-832a-4d59-b760-2f5abd71ae34">
											<gml:posList>35.66836092744999 139.74912916264557 42.322 35.66836092744999 139.74912916264557 42.017 35.66841858146719 139.7491580536404 42.017 35.66841858146719 139.7491580536404 42.322 35.66836092744999 139.74912916264557 42.322</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a286b046-b9e2-4d3f-b94a-183cf9d76208">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a286b046-b9e2-4d3f-b94a-183cf9d76208">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a286b046-b9e2-4d3f-b94a-183cf9d76208">
											<gml:posList>35.668354987732314 139.748743818781 16.6 35.668354987732314 139.748743818781 16.037 35.66837707014163 139.7487548856534 16.037 35.66837707014163 139.7487548856534 16.6 35.668354987732314 139.748743818781 16.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-66b08531-8761-4eef-8c88-079ed1564d55">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66b08531-8761-4eef-8c88-079ed1564d55">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66b08531-8761-4eef-8c88-079ed1564d55">
											<gml:posList>35.66835385684933 139.7487378882822 5.32 35.66835385684933 139.7487378882822 16.6 35.66837859925547 139.74875029995692 16.6 35.66837859925547 139.74875029995692 34.2 35.6685055212691 139.74881394568587 34.2 35.6685055212691 139.74881394568587 5.32 35.66835385684933 139.7487378882822 5.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e70fe346-3a94-4ac2-b818-01da4d92d18a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e70fe346-3a94-4ac2-b818-01da4d92d18a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e70fe346-3a94-4ac2-b818-01da4d92d18a">
											<gml:posList>35.66838082119458 139.74875679265213 34.2 35.66838082119458 139.74875679265213 33.586 35.6685001960556 139.7488166575694 33.586 35.6685001960556 139.7488166575694 34.2 35.66838082119458 139.74875679265213 34.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ba15f6eb-ff75-4286-898d-d97a6d4489a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba15f6eb-ff75-4286-898d-d97a6d4489a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba15f6eb-ff75-4286-898d-d97a6d4489a5">
											<gml:posList>35.66826242331693 139.7489459803332 5.32 35.66825369842148 139.74897227891768 5.32 35.66825369842148 139.74897227891768 15.228 35.66826242331693 139.7489459803332 15.228 35.66826242331693 139.7489459803332 5.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cb3a46a7-cf30-4341-87c8-49d522f17712">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb3a46a7-cf30-4341-87c8-49d522f17712">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb3a46a7-cf30-4341-87c8-49d522f17712">
											<gml:posList>35.66825369842148 139.74897227891768 5.32 35.66826524009456 139.74897812113824 5.32 35.66826524009456 139.74897812113824 15.228 35.66825369842148 139.74897227891768 15.228 35.66825369842148 139.74897227891768 5.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4fe41fa8-ebf8-4494-8434-160b98c82c5e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4fe41fa8-ebf8-4494-8434-160b98c82c5e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4fe41fa8-ebf8-4494-8434-160b98c82c5e">
											<gml:posList>35.66826242331693 139.7489459803332 15.228 35.66827416314621 139.74895161246863 15.228 35.66827416314621 139.74895161246863 9.7 35.66826467752301 139.7489470825577 9.7 35.66826467752301 139.7489470825577 5.32 35.66826242331693 139.7489459803332 5.32 35.66826242331693 139.7489459803332 15.228</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6153c8df-abf3-4717-a4ef-3e0b498fc73b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6153c8df-abf3-4717-a4ef-3e0b498fc73b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6153c8df-abf3-4717-a4ef-3e0b498fc73b">
											<gml:posList>35.66826721901341 139.7489722646927 9.7 35.66827416314621 139.74895161246863 9.7 35.66827416314621 139.74895161246863 15.228 35.66826524009456 139.74897812113824 15.228 35.66826524009456 139.74897812113824 5.32 35.66826721901341 139.7489722646927 5.32 35.66826721901341 139.7489722646927 9.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e5219087-dd14-4a1b-b416-e8ca5adb3ebe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5219087-dd14-4a1b-b416-e8ca5adb3ebe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5219087-dd14-4a1b-b416-e8ca5adb3ebe">
											<gml:posList>35.66828518576768 139.74888564537227 5.32 35.66826467752301 139.7489470825577 5.32 35.66826467752301 139.7489470825577 9.7 35.66828518576768 139.74888564537227 9.7 35.66828518576768 139.74888564537227 5.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-203cd46c-456f-4f7b-8158-8e241a3f92c6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-203cd46c-456f-4f7b-8158-8e241a3f92c6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-203cd46c-456f-4f7b-8158-8e241a3f92c6">
											<gml:posList>35.66830104573247 139.74898252395133 16.6 35.66830104573247 139.74898252395133 16.037 35.66827909858834 139.7489715121142 16.037 35.66827909858834 139.7489715121142 16.6 35.66830104573247 139.74898252395133 16.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-748edc9f-bd2e-434d-980d-ed6fbb012c3e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-748edc9f-bd2e-434d-980d-ed6fbb012c3e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-748edc9f-bd2e-434d-980d-ed6fbb012c3e">
											<gml:posList>35.6683017768366 139.7488939123794 5.32 35.66828518576768 139.74888564537227 5.32 35.66828518576768 139.74888564537227 9.7 35.6683017768366 139.7488939123794 9.7 35.6683017768366 139.7488939123794 5.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-205252b3-cfe2-4a22-8ee9-d4a34d180212">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-205252b3-cfe2-4a22-8ee9-d4a34d180212">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-205252b3-cfe2-4a22-8ee9-d4a34d180212">
											<gml:posList>35.66827436942238 139.74897585815606 9.7 35.66826721901341 139.7489722646927 9.7 35.66826721901341 139.7489722646927 5.32 35.668324909185756 139.74900124387085 5.32 35.668325053459554 139.74900132104094 34.2 35.66829912083361 139.74898829197446 34.2 35.66829912083361 139.74898829197446 16.6 35.66827436942238 139.74897585815606 16.6 35.66827436942238 139.74897585815606 9.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-db7da300-ba58-41c3-b6df-8320450011e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db7da300-ba58-41c3-b6df-8320450011e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db7da300-ba58-41c3-b6df-8320450011e2">
											<gml:posList>35.66831085736523 139.74914378486756 38.045 35.66831085736523 139.74914378486756 34.955 35.66828788232325 139.74913227699557 34.955 35.66828788232325 139.74913227699557 38.045 35.66831085736523 139.74914378486756 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ce21249b-1181-404f-bbd3-88f4964e4883">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce21249b-1181-404f-bbd3-88f4964e4883">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce21249b-1181-404f-bbd3-88f4964e4883">
											<gml:posList>35.66831542893161 139.74914607763057 38.045 35.66831542893161 139.74914607763057 34.955 35.66831085736523 139.74914378486756 34.955 35.66831085736523 139.74914378486756 38.045 35.66831542893161 139.74914607763057 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-167557dc-219f-49b2-88ee-9a406c6c9a9f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-167557dc-219f-49b2-88ee-9a406c6c9a9f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-167557dc-219f-49b2-88ee-9a406c6c9a9f">
											<gml:posList>35.6683017768366 139.7488939123794 9.7 35.66827436942238 139.74897585815606 9.7 35.66827436942238 139.74897585815606 16.6 35.66835385684933 139.7487378882822 16.6 35.66835385684933 139.7487378882822 5.32 35.6683017768366 139.7488939123794 5.32 35.6683017768366 139.7488939123794 9.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9c7f044a-b93d-4109-8ad8-a49403f2452b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c7f044a-b93d-4109-8ad8-a49403f2452b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c7f044a-b93d-4109-8ad8-a49403f2452b">
											<gml:posList>35.66830441900999 139.74898558013763 33.586 35.66830441900999 139.74898558013763 34.2 35.66832656449345 139.74899664700334 34.2 35.66832656449345 139.74899664700334 33.586 35.66830441900999 139.74898558013763 33.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c2e906ad-8c71-44f4-b73e-c86f60e229ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c2e906ad-8c71-44f4-b73e-c86f60e229ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c2e906ad-8c71-44f4-b73e-c86f60e229ff">
											<gml:posList>35.66827909858834 139.7489715121142 16.6 35.66827909858834 139.7489715121142 16.037 35.668354987732314 139.748743818781 16.037 35.668354987732314 139.748743818781 16.6 35.66827909858834 139.7489715121142 16.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-85fa7d13-5dad-4780-8d36-b10f248da058">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85fa7d13-5dad-4780-8d36-b10f248da058">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85fa7d13-5dad-4780-8d36-b10f248da058">
											<gml:posList>35.66831542893161 139.74914607763057 38.045 35.66831355799916 139.74915169095047 38.045 35.66831355799916 139.74915169095047 42.322 35.668323101568504 139.74912308289694 42.322 35.668323101568504 139.74912308289694 34.955 35.66831542893161 139.74914607763057 34.955 35.66831542893161 139.74914607763057 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-77f18606-5620-49ee-93b3-bd498c4282bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-77f18606-5620-49ee-93b3-bd498c4282bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-77f18606-5620-49ee-93b3-bd498c4282bb">
											<gml:posList>35.66831628817029 139.74915027419925 42.322 35.66831628817029 139.74915027419925 42.017 35.668324248652496 139.74912642862327 42.017 35.668324248652496 139.74912642862327 42.322 35.66831628817029 139.74915027419925 42.322</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8f4e97b0-ffaf-49d5-9cfb-cfce13452d93">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f4e97b0-ffaf-49d5-9cfb-cfce13452d93">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f4e97b0-ffaf-49d5-9cfb-cfce13452d93">
											<gml:posList>35.668325053459554 139.74900132104094 34.2 35.668324909185756 139.74900124387085 5.32 35.6682814217897 139.74913558652514 5.32 35.668281584098594 139.74913567472248 38.045 35.668381060735754 139.7488283703812 38.045 35.66838103368681 139.7488283593637 33.586 35.66832656449345 139.74899664700334 33.586 35.66832656449345 139.74899664700334 34.2 35.668325053459554 139.74900132104094 34.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-468f836e-6a7b-48b6-b1c4-d584459e6f10">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-468f836e-6a7b-48b6-b1c4-d584459e6f10">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-468f836e-6a7b-48b6-b1c4-d584459e6f10">
											<gml:posList>35.66828788232325 139.74913227699557 38.045 35.66828788232325 139.74913227699557 34.955 35.668383986780064 139.74883634249878 34.955 35.668383986780064 139.74883634249878 38.045 35.66828788232325 139.74913227699557 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ada4a2be-ceae-498d-8b8a-869d89f76939">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ada4a2be-ceae-498d-8b8a-869d89f76939">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ada4a2be-ceae-498d-8b8a-869d89f76939">
											<gml:posList>35.66837707014163 139.7487548856534 16.6 35.66837707014163 139.7487548856534 16.037 35.66830104573247 139.74898252395133 16.037 35.66830104573247 139.74898252395133 16.6 35.66829912083361 139.74898829197446 16.6 35.66829912083361 139.74898829197446 34.2 35.66837859925547 139.74875029995692 34.2 35.66837859925547 139.74875029995692 16.6 35.66837707014163 139.7487548856534 16.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a48dc918-73f3-4750-aecd-d1a179eba261">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a48dc918-73f3-4750-aecd-d1a179eba261">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a48dc918-73f3-4750-aecd-d1a179eba261">
											<gml:posList>35.668323101568504 139.74912308289694 42.322 35.668355309912414 139.74913922038778 42.322 35.668355309912414 139.74913922038778 34.955 35.668323101568504 139.74912308289694 34.955 35.668323101568504 139.74912308289694 42.322</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-78a133ca-6043-45d9-9744-7d0efbd350b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78a133ca-6043-45d9-9744-7d0efbd350b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78a133ca-6043-45d9-9744-7d0efbd350b6">
											<gml:posList>35.66830441900999 139.74898558013763 34.2 35.66830441900999 139.74898558013763 33.586 35.66838082119458 139.74875679265213 33.586 35.66838082119458 139.74875679265213 34.2 35.66830441900999 139.74898558013763 34.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8edd643a-bbdf-4617-8e9f-b3ca1ed7d864">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8edd643a-bbdf-4617-8e9f-b3ca1ed7d864">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8edd643a-bbdf-4617-8e9f-b3ca1ed7d864">
											<gml:posList>35.668407297616426 139.7491986705397 38.045 35.668407297616426 139.7491986705397 42.322 35.66831355799916 139.74915169095047 42.322 35.66831355799916 139.74915169095047 38.045 35.668281584098594 139.74913567472248 38.045 35.6682814217897 139.74913558652514 5.32 35.668430804646796 139.74921044299342 5.32 35.66843033577091 139.7492102115195 38.045 35.668407297616426 139.7491986705397 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f1e896d6-fcdc-44b5-981a-7a3146eda9ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f1e896d6-fcdc-44b5-981a-7a3146eda9ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f1e896d6-fcdc-44b5-981a-7a3146eda9ca">
											<gml:posList>35.668355309912414 139.74913922038778 42.322 35.668359780366075 139.74912581691765 42.322 35.668359780366075 139.74912581691765 34.955 35.668355309912414 139.74913922038778 34.955 35.668355309912414 139.74913922038778 42.322</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3e35653d-526d-4d2a-b51c-f7c79b6ca250">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e35653d-526d-4d2a-b51c-f7c79b6ca250">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e35653d-526d-4d2a-b51c-f7c79b6ca250">
											<gml:posList>35.66835645699595 139.7491425661157 42.322 35.66835645699595 139.7491425661157 42.017 35.66836092744999 139.74912916264557 42.017 35.66836092744999 139.74912916264557 42.322 35.66835645699595 139.7491425661157 42.322</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8c4de846-85f5-4e30-9b48-6fd37df99369">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c4de846-85f5-4e30-9b48-6fd37df99369">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c4de846-85f5-4e30-9b48-6fd37df99369">
											<gml:posList>35.66840614151301 139.7491953137723 42.322 35.66840614151301 139.7491953137723 42.017 35.66831628817029 139.74915027419925 42.017 35.66831628817029 139.74915027419925 42.322 35.66840614151301 139.7491953137723 42.322</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cbee93ec-007e-411c-8cf8-6e2f410a120f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cbee93ec-007e-411c-8cf8-6e2f410a120f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cbee93ec-007e-411c-8cf8-6e2f410a120f">
											<gml:posList>35.668359780366075 139.74912581691765 42.322 35.66842132066751 139.74915665897004 42.322 35.66842132066751 139.74915665897004 34.955 35.668359780366075 139.74912581691765 34.955 35.668359780366075 139.74912581691765 42.322</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2285f033-b6b2-434f-8578-e03bb1065cc3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2285f033-b6b2-434f-8578-e03bb1065cc3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2285f033-b6b2-434f-8578-e03bb1065cc3">
											<gml:posList>35.668413731102675 139.74919534999236 38.045 35.668413731102675 139.74919534999236 34.955 35.668409168558746 139.74919306826024 34.955 35.668409168558746 139.74919306826024 38.045 35.668413731102675 139.74919534999236 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-674252fe-b73e-4902-9a2d-87c7a8c63512">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-674252fe-b73e-4902-9a2d-87c7a8c63512">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-674252fe-b73e-4902-9a2d-87c7a8c63512">
											<gml:posList>35.66841858146719 139.7491580536404 42.322 35.66841858146719 139.7491580536404 42.017 35.66840614151301 139.7491953137723 42.017 35.66840614151301 139.7491953137723 42.322 35.66841858146719 139.7491580536404 42.322</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b4867e65-f1fe-4281-be7b-95eb26bcd91c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b4867e65-f1fe-4281-be7b-95eb26bcd91c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b4867e65-f1fe-4281-be7b-95eb26bcd91c">
											<gml:posList>35.668409168558746 139.74919306826024 38.045 35.668409168558746 139.74919306826024 34.955 35.66842132066751 139.74915665897004 34.955 35.66842132066751 139.74915665897004 42.322 35.668407297616426 139.7491986705397 42.322 35.668407297616426 139.7491986705397 38.045 35.668409168558746 139.74919306826024 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b1ff66eb-99a5-4978-a2aa-39880017c3ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b1ff66eb-99a5-4978-a2aa-39880017c3ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b1ff66eb-99a5-4978-a2aa-39880017c3ce">
											<gml:posList>35.66842788761782 139.74920243771007 38.045 35.66842788761782 139.74920243771007 34.955 35.668413731102675 139.74919534999236 34.955 35.668413731102675 139.74919534999236 38.045 35.66842788761782 139.74920243771007 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-131e5607-c581-41e5-927b-40ecd16e8227">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-131e5607-c581-41e5-927b-40ecd16e8227">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-131e5607-c581-41e5-927b-40ecd16e8227">
											<gml:posList>35.668450368264594 139.74916430544192 34.2 35.668450368264594 139.74916430544192 33.586 35.668446265605525 139.7491622883316 33.586 35.668446256584076 139.74916227729508 34.2 35.668450368264594 139.74916430544192 34.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-86dea59c-5032-47a6-8194-97bb17030f17">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-86dea59c-5032-47a6-8194-97bb17030f17">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-86dea59c-5032-47a6-8194-97bb17030f17">
											<gml:posList>35.668383986780064 139.74883634249878 38.045 35.668383986780064 139.74883634249878 34.955 35.6685250644596 139.74890590516674 34.955 35.6685250644596 139.74890590516674 38.045 35.668383986780064 139.74883634249878 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7387c8e8-0894-476e-8f8c-b0f60978f888">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7387c8e8-0894-476e-8f8c-b0f60978f888">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7387c8e8-0894-476e-8f8c-b0f60978f888">
											<gml:posList>35.668381060735754 139.7488283703812 38.045 35.66853202089644 139.7489028160065 38.045 35.668532084015766 139.74890284907804 33.586 35.66838103368681 139.7488283593637 33.586 35.668381060735754 139.7488283703812 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c732d3ef-81dd-411b-b52b-0b3edee6b553">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c732d3ef-81dd-411b-b52b-0b3edee6b553">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c732d3ef-81dd-411b-b52b-0b3edee6b553">
											<gml:posList>35.66849887913413 139.749188599906 34.2 35.66849887913413 139.749188599906 33.586 35.668450368264594 139.74916430544192 33.586 35.668450368264594 139.74916430544192 34.2 35.66849887913413 139.749188599906 34.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-30be9168-a966-47f4-9347-7823ae6d8d88">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-30be9168-a966-47f4-9347-7823ae6d8d88">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-30be9168-a966-47f4-9347-7823ae6d8d88">
											<gml:posList>35.6685250644596 139.74890590516674 38.045 35.6685250644596 139.74890590516674 34.955 35.66842788761782 139.74920243771007 34.955 35.66842788761782 139.74920243771007 38.045 35.6685250644596 139.74890590516674 38.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4cc8eb22-31d0-4de1-a6e1-4a518f1d9bfe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4cc8eb22-31d0-4de1-a6e1-4a518f1d9bfe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4cc8eb22-31d0-4de1-a6e1-4a518f1d9bfe">
											<gml:posList>35.668446256584076 139.74916227729508 34.2 35.668446265605525 139.7491622883316 33.586 35.668532084015766 139.74890284907804 33.586 35.66853202089644 139.7489028160065 38.045 35.66843033577091 139.7492102115195 38.045 35.668430804646796 139.74921044299342 5.32 35.66844516025247 139.74916706136122 5.32 35.66844473646057 139.7491668519322 34.2 35.668446256584076 139.74916227729508 34.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-36287620-69f8-48d4-9da4-e3b495ef4d60">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36287620-69f8-48d4-9da4-e3b495ef4d60">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36287620-69f8-48d4-9da4-e3b495ef4d60">
											<gml:posList>35.66844473646057 139.7491668519322 34.2 35.66844516025247 139.74916706136122 5.32 35.66852679916431 139.74920793425318 5.32 35.66852679916431 139.74920793425318 27.1 35.668501101034146 139.74919507053116 27.1 35.668501101034146 139.74919507053116 34.2 35.66844473646057 139.7491668519322 34.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b8f7083-76aa-4bf4-a9a0-3aeafc2bba4b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b8f7083-76aa-4bf4-a9a0-3aeafc2bba4b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b8f7083-76aa-4bf4-a9a0-3aeafc2bba4b">
											<gml:posList>35.6685001960556 139.7488166575694 34.2 35.6685001960556 139.7488166575694 33.586 35.668487871936634 139.74885185206813 33.586 35.668487871936634 139.74885185206813 34.2 35.6685001960556 139.7488166575694 34.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-64e0519b-d181-446b-aed7-3f44303e7219">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-64e0519b-d181-446b-aed7-3f44303e7219">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-64e0519b-d181-446b-aed7-3f44303e7219">
											<gml:posList>35.668493251186796 139.74884907385444 5.32 35.668504621757066 139.74881659767448 5.32 35.668504621757066 139.74881659767448 34.2 35.668493251186796 139.74884907385444 34.2 35.668493251186796 139.74884907385444 5.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ba8b6fef-fad5-45b2-8504-decc4b1d2acf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba8b6fef-fad5-45b2-8504-decc4b1d2acf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba8b6fef-fad5-45b2-8504-decc4b1d2acf">
											<gml:posList>35.66850553419818 139.7491927904029 27.1 35.66850553419818 139.7491927904029 26.64 35.6685023873035 139.74919121412688 26.64 35.6685023873035 139.74919121412688 27.1 35.66850553419818 139.7491927904029 27.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-317b2fb5-9967-4261-91c1-18f34a182d9c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-317b2fb5-9967-4261-91c1-18f34a182d9c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-317b2fb5-9967-4261-91c1-18f34a182d9c">
											<gml:posList>35.668504621757066 139.74881659767448 5.32 35.6685055212691 139.74881394568587 5.32 35.6685055212691 139.74881394568587 34.2 35.668504621757066 139.74881659767448 34.2 35.668504621757066 139.74881659767448 5.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fd9cd844-4ee0-47bc-8bc8-075c4b429a65">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fd9cd844-4ee0-47bc-8bc8-075c4b429a65">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fd9cd844-4ee0-47bc-8bc8-075c4b429a65">
											<gml:posList>35.668487871936634 139.74885185206813 34.2 35.668487871936634 139.74885185206813 33.586 35.6685335056534 139.74887353148162 33.586 35.6685335056534 139.74887353148162 34.2 35.668487871936634 139.74885185206813 34.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f8d97950-af09-4951-8b73-4c0022e4222c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f8d97950-af09-4951-8b73-4c0022e4222c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f8d97950-af09-4951-8b73-4c0022e4222c">
											<gml:posList>35.66853503475622 139.74886892368642 5.32 35.668493251186796 139.74884907385444 5.32 35.668493251186796 139.74884907385444 34.2 35.66853503475622 139.74886892368642 34.2 35.66853503475622 139.74886892368642 5.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3887efc9-4af1-481a-80cb-8a60e80357cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3887efc9-4af1-481a-80cb-8a60e80357cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3887efc9-4af1-481a-80cb-8a60e80357cc">
											<gml:posList>35.66852494756098 139.74920251260752 27.1 35.66852494756098 139.74920251260752 26.64 35.66850553419818 139.7491927904029 26.64 35.66850553419818 139.7491927904029 27.1 35.66852494756098 139.74920251260752 27.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-49945417-adfb-4b45-9a7d-edc536830a8f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-49945417-adfb-4b45-9a7d-edc536830a8f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-49945417-adfb-4b45-9a7d-edc536830a8f">
											<gml:posList>35.6685938647855 139.74890375607376 34.2 35.6685938647855 139.74890375607376 33.586 35.66849887913413 139.749188599906 33.586 35.66849887913413 139.749188599906 34.2 35.6685938647855 139.74890375607376 34.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b5ab06aa-8776-4863-a173-92eb0d6cc6da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b5ab06aa-8776-4863-a173-92eb0d6cc6da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b5ab06aa-8776-4863-a173-92eb0d6cc6da">
											<gml:posList>35.6685023873035 139.74919121412688 27.1 35.6685023873035 139.74919121412688 26.64 35.668597858656724 139.74890487856186 26.64 35.668597858656724 139.74890487856186 27.1 35.66859914492449 139.74890103319433 27.1 35.66859914492449 139.74890103319433 34.2 35.668501101034146 139.74919507053116 34.2 35.668501101034146 139.74919507053116 27.1 35.6685023873035 139.74919121412688 27.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0a6247e2-fa5b-46f7-8deb-614d80d33bcc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a6247e2-fa5b-46f7-8deb-614d80d33bcc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a6247e2-fa5b-46f7-8deb-614d80d33bcc">
											<gml:posList>35.6685335056534 139.74887353148162 34.2 35.6685335056534 139.74887353148162 33.586 35.6685938647855 139.74890375607376 33.586 35.6685938647855 139.74890375607376 34.2 35.6685335056534 139.74887353148162 34.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ac4695f6-0e23-4748-8eac-dc6b3d2ba8d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ac4695f6-0e23-4748-8eac-dc6b3d2ba8d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ac4695f6-0e23-4748-8eac-dc6b3d2ba8d1">
											<gml:posList>35.66862041893289 139.74891616592927 27.1 35.66862041893289 139.74891616592927 26.64 35.66852494756098 139.74920251260752 26.64 35.66852494756098 139.74920251260752 27.1 35.66862041893289 139.74891616592927 27.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ec8bc39d-9273-4297-a692-c4017767e801">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec8bc39d-9273-4297-a692-c4017767e801">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec8bc39d-9273-4297-a692-c4017767e801">
											<gml:posList>35.66852679916431 139.74920793425318 5.32 35.66862484308554 139.7489138968377 5.32 35.66862484308554 139.7489138968377 27.1 35.66852679916431 139.74920793425318 27.1 35.66852679916431 139.74920793425318 5.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e0028799-b0de-498a-aaba-f3cc000b6044">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e0028799-b0de-498a-aaba-f3cc000b6044">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e0028799-b0de-498a-aaba-f3cc000b6044">
											<gml:posList>35.66853503475622 139.74886892368642 5.32 35.66853503475622 139.74886892368642 34.2 35.66859914492449 139.74890103319433 34.2 35.66859914492449 139.74890103319433 27.1 35.66862484308554 139.7489138968377 27.1 35.66862484308554 139.7489138968377 5.32 35.66853503475622 139.74886892368642 5.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4d81023f-5b08-40b5-a287-814925fa931d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d81023f-5b08-40b5-a287-814925fa931d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d81023f-5b08-40b5-a287-814925fa931d">
											<gml:posList>35.668597858656724 139.74890487856186 27.1 35.668597858656724 139.74890487856186 26.64 35.66860099653363 139.74890644379198 26.64 35.66860099653363 139.74890644379198 27.1 35.668597858656724 139.74890487856186 27.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-766b2dce-44e5-4954-aa4a-bd581a27ce08">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-766b2dce-44e5-4954-aa4a-bd581a27ce08">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-766b2dce-44e5-4954-aa4a-bd581a27ce08">
											<gml:posList>35.66860099653363 139.74890644379198 27.1 35.66860099653363 139.74890644379198 26.64 35.66862041893289 139.74891616592927 26.64 35.66862041893289 139.74891616592927 27.1 35.66860099653363 139.74890644379198 27.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7471</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">1088.559</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.06</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>