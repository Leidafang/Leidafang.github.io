<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_692d7a8d-1981-4d6a-be30-c3808529280f">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門駅南地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">28.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66855616185335 139.7486620096835 0 35.66852144043474 139.7487638905069 0 35.66866102147881 139.7488328913961 0 35.66869466076426 139.74873023834488 0 35.66855616185335 139.7486620096835 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66855616185335 139.7486620096835 5.41 35.66869466076426 139.74873023834488 5.41 35.66866102147881 139.7488328913961 5.41 35.66852144043474 139.7487638905069 5.41 35.66855616185335 139.7486620096835 5.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66855616185335 139.7486620096835 5.41 35.66852144043474 139.7487638905069 5.41 35.66852144043474 139.7487638905069 32.12 35.66855616185335 139.7486620096835 32.12 35.66855616185335 139.7486620096835 5.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66852144043474 139.7487638905069 5.41 35.66866102147881 139.7488328913961 5.41 35.66866102147881 139.7488328913961 32.12 35.66852144043474 139.7487638905069 32.12 35.66852144043474 139.7487638905069 5.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66866102147881 139.7488328913961 5.41 35.66869466076426 139.74873023834488 5.41 35.66869466076426 139.74873023834488 32.12 35.66866102147881 139.7488328913961 32.12 35.66866102147881 139.7488328913961 5.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66869466076426 139.74873023834488 5.41 35.66855616185335 139.7486620096835 5.41 35.66855616185335 139.7486620096835 32.12 35.66869466076426 139.74873023834488 32.12 35.66869466076426 139.74873023834488 5.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66855616185335 139.7486620096835 32.12 35.66852144043474 139.7487638905069 32.12 35.66866102147881 139.7488328913961 32.12 35.66869466076426 139.74873023834488 32.12 35.66855616185335 139.7486620096835 32.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-44afc409-40c5-46ea-9f05-855e9eba53db"/>
							<gml:surfaceMember xlink:href="#poly-febcf4ef-3f22-4841-9e8f-71f82c6e892d"/>
							<gml:surfaceMember xlink:href="#poly-0f05c4d9-910f-4103-b1fd-718d838ced93"/>
							<gml:surfaceMember xlink:href="#poly-16983a8a-55a8-44ac-90d9-766af82e95b3"/>
							<gml:surfaceMember xlink:href="#poly-f4fb4cc2-4dac-4f6a-bf4b-1879e61c34df"/>
							<gml:surfaceMember xlink:href="#poly-711db9d2-01ff-4adb-ae51-660233cadc0c"/>
							<gml:surfaceMember xlink:href="#poly-72747cf7-d858-4804-ab8f-b68ba65a10dd"/>
							<gml:surfaceMember xlink:href="#poly-7d9f513b-9754-4b47-a81e-6e440a9ba974"/>
							<gml:surfaceMember xlink:href="#poly-1cbca950-d776-4aa1-ae07-300991ff80d0"/>
							<gml:surfaceMember xlink:href="#poly-5b9c6e3d-5006-4d5e-9dd7-276dae48aa46"/>
							<gml:surfaceMember xlink:href="#poly-7f604a9f-b69d-479b-9ac8-8ee0b86aaad8"/>
							<gml:surfaceMember xlink:href="#poly-22d14f97-0bb5-4804-9ffd-3678a89d7c73"/>
							<gml:surfaceMember xlink:href="#poly-fcb8d1e7-cbd6-48d3-953f-3f8261d57229"/>
							<gml:surfaceMember xlink:href="#poly-7f323d6d-56e4-4caa-a350-325d234205ff"/>
							<gml:surfaceMember xlink:href="#poly-97a7d36f-16d2-47b0-bebb-ae9ab22adfde"/>
							<gml:surfaceMember xlink:href="#poly-7b3a885f-e2a0-46ef-90b0-22416ff73641"/>
							<gml:surfaceMember xlink:href="#poly-ad94b341-18bc-405f-9d72-2b4665a20dcf"/>
							<gml:surfaceMember xlink:href="#poly-b79f8b41-14a5-45d5-a0ab-57d62c8a584b"/>
							<gml:surfaceMember xlink:href="#poly-ceb6ee7a-01ef-4306-9fd6-819c1c08daee"/>
							<gml:surfaceMember xlink:href="#poly-3cc2bd1c-7a03-4638-8144-ce6d5064971f"/>
							<gml:surfaceMember xlink:href="#poly-222d86d8-e3f2-4bc0-b711-1bd705d1993f"/>
							<gml:surfaceMember xlink:href="#poly-03fed9d9-a46d-449f-aa6e-1d47eaeb3301"/>
							<gml:surfaceMember xlink:href="#poly-e99fb9dd-995e-4909-9811-8a648b4a4d2d"/>
							<gml:surfaceMember xlink:href="#poly-7766a27f-6c00-43d7-a983-50e7aade2ada"/>
							<gml:surfaceMember xlink:href="#poly-bd1baece-d017-4fb2-9edb-59436de2413c"/>
							<gml:surfaceMember xlink:href="#poly-3b994e56-541e-4f4d-b294-26314c6c9b3e"/>
							<gml:surfaceMember xlink:href="#poly-b7089854-6fcc-408c-bde6-246a6604fd27"/>
							<gml:surfaceMember xlink:href="#poly-6511c01a-0e7f-48a4-b8e5-fa93b7c800af"/>
							<gml:surfaceMember xlink:href="#poly-89e892da-be46-4d4f-9022-5cd7088bafba"/>
							<gml:surfaceMember xlink:href="#poly-e1b62038-b0a4-43cf-b476-dc58cd514a34"/>
							<gml:surfaceMember xlink:href="#poly-721357be-72f4-4cf1-b1c0-6565d813b8b5"/>
							<gml:surfaceMember xlink:href="#poly-cba2fe80-08bd-4986-8012-c28a77f4c565"/>
							<gml:surfaceMember xlink:href="#poly-001e70bf-23aa-47d5-87d2-582a2ff3034c"/>
							<gml:surfaceMember xlink:href="#poly-a71344dd-eff6-472a-b471-4ef4474e8cb5"/>
							<gml:surfaceMember xlink:href="#poly-5af855ab-f058-4edf-9223-0b388a4b84cc"/>
							<gml:surfaceMember xlink:href="#poly-d31a0cf7-0581-4bf2-885b-c79704bb2227"/>
							<gml:surfaceMember xlink:href="#poly-2a9f3727-7ed2-4406-80e2-cab88218da7f"/>
							<gml:surfaceMember xlink:href="#poly-ecea5680-4463-4c23-b539-49f7d9f315fa"/>
							<gml:surfaceMember xlink:href="#poly-69a0e112-e836-49f8-9cd7-a3b4072fe5d3"/>
							<gml:surfaceMember xlink:href="#poly-10bc8558-aa49-4131-8b10-f17093716392"/>
							<gml:surfaceMember xlink:href="#poly-d7259479-8334-4fbd-8ac9-9b0c49daed98"/>
							<gml:surfaceMember xlink:href="#poly-a93bfc38-1bdf-41ae-97d0-112da998dff2"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_692d7a8d-1981-4d6a-be30-c3808529280f_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c8c56ebc-7c46-4051-be91-d1c9e426012f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66856768143348 139.74870051495782 36.004 35.66857288023395 139.74868466949036 36.004 35.66858942616957 139.74869282607293 36.004 35.668584227368044 139.7487086715431 36.004 35.66856768143348 139.74870051495782 36.004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f37c4767-e349-490e-8f59-e7be12c9d0d2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668597628267605 139.74878206921332 31.735 35.66859588328076 139.74878730686422 31.735 35.6685639093256 139.74877127967943 31.735 35.668565654311756 139.7487660420303 31.735 35.668597628267605 139.74878206921332 31.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc698e21-8933-4830-81d6-1e6861df60e3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66860436575751 139.74876242229303 31.735 35.66860238677145 139.7487681683083 31.735 35.66856933041388 139.7487510708086 31.735 35.668571309399134 139.7487453247953 31.735 35.66860436575751 139.74876242229303 31.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5645fca1-fa1f-4d47-bbb3-1265e5505da0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66860618732839 139.74878922905222 31.735 35.66861616145273 139.74875774843252 31.735 35.668620940326434 139.7487600188715 31.735 35.66861096620926 139.74879151053884 31.735 35.66860618732839 139.74878922905222 31.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38c5b972-96e5-4e50-8270-e2c2b8aaa564">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66862749592841 139.7487637455113 31.735 35.668631977240366 139.74876586162054 31.735 35.668622147225015 139.74879718744927 31.735 35.66861766591359 139.74879507133855 31.735 35.66862749592841 139.7487637455113 31.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-28cc3eb8-ea93-4921-8740-9ef1db8f13e9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6686348015461 139.74875730902247 31.735 35.668615162595145 139.74874728890794 31.735 35.668620757842746 139.74873121104946 31.735 35.6686325971195 139.7487372517763 31.735 35.668631454735184 139.74874061097145 31.735 35.66863430409732 139.74874206603997 31.735 35.66863923635209 139.74874454619112 31.735 35.6686348015461 139.74875730902247 31.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e7e8a09-e503-492e-9e78-598e2ba36725">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6686325971195 139.7487372517763 32.2 35.668640396795006 139.74874123116075 32.2 35.66863923635209 139.74874454619112 32.2 35.66863430409732 139.74874206603997 32.2 35.668631454735184 139.74874061097145 32.2 35.6686325971195 139.7487372517763 32.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db4d45fd-a46a-4bf5-ace4-3b8fb4d49e6e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-db4d45fd-a46a-4bf5-ace4-3b8fb4d49e6e_0">
											<gml:posList>35.668597628267605 139.74878206921332 31.735 35.668565654311756 139.7487660420303 31.735 35.668565654311756 139.7487660420303 33.92 35.668597628267605 139.74878206921332 33.92 35.668597628267605 139.74878206921332 31.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f6242fec-0906-471b-ba18-0733593b52c8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f6242fec-0906-471b-ba18-0733593b52c8_0">
											<gml:posList>35.66861096620926 139.74879151053884 31.735 35.668620940326434 139.7487600188715 31.735 35.668620940326434 139.7487600188715 33.92 35.66861096620926 139.74879151053884 33.92 35.66861096620926 139.74879151053884 31.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78789955-97f2-4a91-886b-e1a6afd488bb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78789955-97f2-4a91-886b-e1a6afd488bb_0">
											<gml:posList>35.66862749592841 139.7487637455113 31.735 35.66861766591359 139.74879507133855 31.735 35.66861766591359 139.74879507133855 33.92 35.66862749592841 139.7487637455113 33.92 35.66862749592841 139.7487637455113 31.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-65c59107-45fe-49ee-a0c4-1ff8685cf378">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-65c59107-45fe-49ee-a0c4-1ff8685cf378_0">
											<gml:posList>35.66858942616957 139.74869282607293 36.004 35.66857288023395 139.74868466949036 36.004 35.66857288023395 139.74868466949036 38.992 35.66858942616957 139.74869282607293 38.992 35.66858942616957 139.74869282607293 36.004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a96886ac-58c4-458c-acd3-e5bf52ac34a2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a96886ac-58c4-458c-acd3-e5bf52ac34a2_0">
											<gml:posList>35.66857288023395 139.74868466949036 36.004 35.66856768143348 139.74870051495782 36.004 35.66856768143348 139.74870051495782 38.992 35.66857288023395 139.74868466949036 38.992 35.66857288023395 139.74868466949036 36.004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9bb859e1-7e0c-4f20-8ff1-5947b69f5ea7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9bb859e1-7e0c-4f20-8ff1-5947b69f5ea7_0">
											<gml:posList>35.66856768143348 139.74870051495782 38.992 35.668584227368044 139.7487086715431 38.992 35.66858942616957 139.74869282607293 38.992 35.66857288023395 139.74868466949036 38.992 35.66856768143348 139.74870051495782 38.992</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9421938a-2afd-4908-883f-f7839f58b369">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9421938a-2afd-4908-883f-f7839f58b369_0">
											<gml:posList>35.66858942616957 139.74869282607293 36.004 35.66858942616957 139.74869282607293 38.992 35.668584227368044 139.7487086715431 38.992 35.668584227368044 139.7487086715431 36.004 35.66858942616957 139.74869282607293 36.004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-51f077c4-6c1a-4a39-a196-4787505fbdae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-51f077c4-6c1a-4a39-a196-4787505fbdae_0">
											<gml:posList>35.66856768143348 139.74870051495782 36.004 35.668584227368044 139.7487086715431 36.004 35.668584227368044 139.7487086715431 38.992 35.66856768143348 139.74870051495782 38.992 35.66856768143348 139.74870051495782 36.004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ab12545-7bdf-46b2-9e19-cfcd93f84727">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9ab12545-7bdf-46b2-9e19-cfcd93f84727_0">
											<gml:posList>35.668620757842746 139.74873121104946 31.735 35.668620757842746 139.74873121104946 35.263 35.668640396795006 139.74874123116075 35.263 35.668640396795006 139.74874123116075 32.2 35.6686325971195 139.7487372517763 32.2 35.6686325971195 139.7487372517763 31.735 35.668620757842746 139.74873121104946 31.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a95b53d-4739-4967-8d9d-528ba94487d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1a95b53d-4739-4967-8d9d-528ba94487d7_0">
											<gml:posList>35.668631454735184 139.74874061097145 31.735 35.6686325971195 139.7487372517763 31.735 35.6686325971195 139.7487372517763 32.2 35.668631454735184 139.74874061097145 32.2 35.668631454735184 139.74874061097145 31.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4ab90a49-d20e-4ad9-8839-f129263e7f11">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4ab90a49-d20e-4ad9-8839-f129263e7f11_0">
											<gml:posList>35.668615162595145 139.74874728890794 31.735 35.668615162595145 139.74874728890794 35.263 35.668620757842746 139.74873121104946 35.263 35.668620757842746 139.74873121104946 31.735 35.668615162595145 139.74874728890794 31.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e0ea0b2-e077-47ea-ad24-f1013d0b8fff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e0ea0b2-e077-47ea-ad24-f1013d0b8fff_0">
											<gml:posList>35.668631454735184 139.74874061097145 32.2 35.66863430409732 139.74874206603997 32.2 35.66863430409732 139.74874206603997 31.735 35.668631454735184 139.74874061097145 31.735 35.668631454735184 139.74874061097145 32.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e19cccb5-04a3-476a-b156-8a9dede63f6b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e19cccb5-04a3-476a-b156-8a9dede63f6b_0">
											<gml:posList>35.66863430409732 139.74874206603997 32.2 35.66863923635209 139.74874454619112 32.2 35.66863923635209 139.74874454619112 31.735 35.66863430409732 139.74874206603997 31.735 35.66863430409732 139.74874206603997 32.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8cf6f5dd-03e2-4c66-9e3c-c930fd3364e5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8cf6f5dd-03e2-4c66-9e3c-c930fd3364e5_0">
											<gml:posList>35.668620757842746 139.74873121104946 35.263 35.668615162595145 139.74874728890794 35.263 35.6686348015461 139.74875730902247 35.263 35.668640396795006 139.74874123116075 35.263 35.668620757842746 139.74873121104946 35.263</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c4399ffc-e6ff-4325-bf48-debb63419a66">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c4399ffc-e6ff-4325-bf48-debb63419a66_0">
											<gml:posList>35.668571309399134 139.7487453247953 31.735 35.66856933041388 139.7487510708086 31.735 35.66856933041388 139.7487510708086 33.92 35.668571309399134 139.7487453247953 33.92 35.668571309399134 139.7487453247953 31.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f1e3c09f-59fd-4f12-b75d-ed2ac5b9f4b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f1e3c09f-59fd-4f12-b75d-ed2ac5b9f4b8_0">
											<gml:posList>35.66863923635209 139.74874454619112 32.2 35.668640396795006 139.74874123116075 32.2 35.668640396795006 139.74874123116075 35.263 35.6686348015461 139.74875730902247 35.263 35.6686348015461 139.74875730902247 31.735 35.66863923635209 139.74874454619112 31.735 35.66863923635209 139.74874454619112 32.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0fce2c8-cb59-483a-8c5d-7d679406685d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d0fce2c8-cb59-483a-8c5d-7d679406685d_0">
											<gml:posList>35.668615162595145 139.74874728890794 31.735 35.6686348015461 139.74875730902247 31.735 35.6686348015461 139.74875730902247 35.263 35.668615162595145 139.74874728890794 35.263 35.668615162595145 139.74874728890794 31.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f333553-ee42-4ea0-9242-b3abbe3fba2f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5f333553-ee42-4ea0-9242-b3abbe3fba2f_0">
											<gml:posList>35.668571309399134 139.7487453247953 31.735 35.668571309399134 139.7487453247953 33.92 35.66860436575751 139.74876242229303 33.92 35.66860436575751 139.74876242229303 31.735 35.668571309399134 139.7487453247953 31.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d21e78c1-873e-4c58-9908-0e44d9038017">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d21e78c1-873e-4c58-9908-0e44d9038017_0">
											<gml:posList>35.66856933041388 139.7487510708086 33.92 35.66860238677145 139.7487681683083 33.92 35.66860436575751 139.74876242229303 33.92 35.668571309399134 139.7487453247953 33.92 35.66856933041388 139.7487510708086 33.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57c7b31c-4a0a-4659-82cb-a5afec3ccdbd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-57c7b31c-4a0a-4659-82cb-a5afec3ccdbd_0">
											<gml:posList>35.668620940326434 139.7487600188715 31.735 35.66861616145273 139.74875774843252 31.735 35.66861616145273 139.74875774843252 33.92 35.668620940326434 139.7487600188715 33.92 35.668620940326434 139.7487600188715 31.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ed1e6475-37f4-4f30-937f-596f25ce825c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ed1e6475-37f4-4f30-937f-596f25ce825c_0">
											<gml:posList>35.66856933041388 139.7487510708086 31.735 35.66860238677145 139.7487681683083 31.735 35.66860238677145 139.7487681683083 33.92 35.66856933041388 139.7487510708086 33.92 35.66856933041388 139.7487510708086 31.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c0d29ae-a415-42fb-adaa-25bc4ec75054">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3c0d29ae-a415-42fb-adaa-25bc4ec75054_0">
											<gml:posList>35.668631977240366 139.74876586162054 31.735 35.66862749592841 139.7487637455113 31.735 35.66862749592841 139.7487637455113 33.92 35.668631977240366 139.74876586162054 33.92 35.668631977240366 139.74876586162054 31.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0fb54fc3-59e2-409e-8faf-cac741ebb99e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0fb54fc3-59e2-409e-8faf-cac741ebb99e_0">
											<gml:posList>35.66860238677145 139.7487681683083 31.735 35.66860436575751 139.74876242229303 31.735 35.66860436575751 139.74876242229303 33.92 35.66860238677145 139.7487681683083 33.92 35.66860238677145 139.7487681683083 31.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b85cd12-5708-41d8-873b-a1579358b9f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b85cd12-5708-41d8-873b-a1579358b9f0_0">
											<gml:posList>35.668565654311756 139.7487660420303 31.735 35.6685639093256 139.74877127967943 31.735 35.6685639093256 139.74877127967943 33.92 35.668565654311756 139.7487660420303 33.92 35.668565654311756 139.7487660420303 31.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0631f27d-519c-4d8d-a2d1-8c72c89eeb48">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0631f27d-519c-4d8d-a2d1-8c72c89eeb48_0">
											<gml:posList>35.66861616145273 139.74875774843252 31.735 35.66860618732839 139.74878922905222 31.735 35.66860618732839 139.74878922905222 33.92 35.66861616145273 139.74875774843252 33.92 35.66861616145273 139.74875774843252 31.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f4f2efbf-01a2-427e-908f-dfd9c37f97b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f4f2efbf-01a2-427e-908f-dfd9c37f97b4_0">
											<gml:posList>35.668620940326434 139.7487600188715 33.92 35.66861616145273 139.74875774843252 33.92 35.66860618732839 139.74878922905222 33.92 35.66861096620926 139.74879151053884 33.92 35.668620940326434 139.7487600188715 33.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-31f60ab5-2446-43ce-9de8-cdea87f1d46d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-31f60ab5-2446-43ce-9de8-cdea87f1d46d_0">
											<gml:posList>35.6685639093256 139.74877127967943 33.92 35.66859588328076 139.74878730686422 33.92 35.668597628267605 139.74878206921332 33.92 35.668565654311756 139.7487660420303 33.92 35.6685639093256 139.74877127967943 33.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-362bc5cd-dd6a-432f-9c85-77571059c12e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-362bc5cd-dd6a-432f-9c85-77571059c12e_0">
											<gml:posList>35.6685639093256 139.74877127967943 31.735 35.66859588328076 139.74878730686422 31.735 35.66859588328076 139.74878730686422 33.92 35.6685639093256 139.74877127967943 33.92 35.6685639093256 139.74877127967943 31.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c2fb8da0-d730-4465-a54a-7942466aa028">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c2fb8da0-d730-4465-a54a-7942466aa028_0">
											<gml:posList>35.668622147225015 139.74879718744927 33.92 35.668631977240366 139.74876586162054 33.92 35.66862749592841 139.7487637455113 33.92 35.66861766591359 139.74879507133855 33.92 35.668622147225015 139.74879718744927 33.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ccb932c4-a47d-4a96-947b-fbcac74eec9b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ccb932c4-a47d-4a96-947b-fbcac74eec9b_0">
											<gml:posList>35.668622147225015 139.74879718744927 31.735 35.668631977240366 139.74876586162054 31.735 35.668631977240366 139.74876586162054 33.92 35.668622147225015 139.74879718744927 33.92 35.668622147225015 139.74879718744927 31.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e0843a5-7e6c-49fe-a0ea-4f2601b93267">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4e0843a5-7e6c-49fe-a0ea-4f2601b93267_0">
											<gml:posList>35.66859588328076 139.74878730686422 31.735 35.668597628267605 139.74878206921332 31.735 35.668597628267605 139.74878206921332 33.92 35.66859588328076 139.74878730686422 33.92 35.66859588328076 139.74878730686422 31.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3468067c-2254-493d-b8f9-ebff1b5685c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3468067c-2254-493d-b8f9-ebff1b5685c3_0">
											<gml:posList>35.66860618732839 139.74878922905222 31.735 35.66861096620926 139.74879151053884 31.735 35.66861096620926 139.74879151053884 33.92 35.66860618732839 139.74878922905222 33.92 35.66860618732839 139.74878922905222 31.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-beb0bb01-3756-4345-85d9-31382d6bb27e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-beb0bb01-3756-4345-85d9-31382d6bb27e_0">
											<gml:posList>35.66861766591359 139.74879507133855 31.735 35.668622147225015 139.74879718744927 31.735 35.668622147225015 139.74879718744927 33.92 35.66861766591359 139.74879507133855 33.92 35.66861766591359 139.74879507133855 31.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_692d7a8d-1981-4d6a-be30-c3808529280f_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ed938dce-37b2-42ac-9bba-b9ffc119665e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668536251081534 139.74875259691368 31.735 35.668542673645014 139.74873374565075 31.735 35.66856217736811 139.7487437327576 31.735 35.66855574578936 139.7487625840338 31.735 35.668536251081534 139.74875259691368 31.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-617028e4-a5c6-4aa0-817e-0c2d08f1cbae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-617028e4-a5c6-4aa0-817e-0c2d08f1cbae_0">
											<gml:posList>35.668536251081534 139.74875259691368 31.735 35.668536251081534 139.74875259691368 34.783 35.668542673645014 139.74873374565075 34.783 35.668542673645014 139.74873374565075 31.735 35.668536251081534 139.74875259691368 31.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-659be88d-47c6-44b6-bd77-f2fadd433e57">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-659be88d-47c6-44b6-bd77-f2fadd433e57_0">
											<gml:posList>35.66855574578936 139.7487625840338 31.735 35.66855574578936 139.7487625840338 34.783 35.668536251081534 139.74875259691368 34.783 35.668536251081534 139.74875259691368 31.735 35.66855574578936 139.7487625840338 31.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-549b50b5-727b-4530-909e-a272ba106283">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-549b50b5-727b-4530-909e-a272ba106283_0">
											<gml:posList>35.668536251081534 139.74875259691368 34.783 35.66855574578936 139.7487625840338 34.783 35.66856217736811 139.7487437327576 34.783 35.668542673645014 139.74873374565075 34.783 35.668536251081534 139.74875259691368 34.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d130793-c1d3-431c-9a0e-46b1bfde9253">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d130793-c1d3-431c-9a0e-46b1bfde9253_0">
											<gml:posList>35.668542673645014 139.74873374565075 31.735 35.668542673645014 139.74873374565075 34.783 35.66856217736811 139.7487437327576 34.783 35.66856217736811 139.7487437327576 31.735 35.668542673645014 139.74873374565075 31.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6abe7e02-d944-4531-887a-719adc934d33">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6abe7e02-d944-4531-887a-719adc934d33_0">
											<gml:posList>35.66856217736811 139.7487437327576 31.735 35.66856217736811 139.7487437327576 34.783 35.66855574578936 139.7487625840338 34.783 35.66855574578936 139.7487625840338 31.735 35.66856217736811 139.7487437327576 31.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-44afc409-40c5-46ea-9f05-855e9eba53db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44afc409-40c5-46ea-9f05-855e9eba53db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44afc409-40c5-46ea-9f05-855e9eba53db">
											<gml:posList>35.668556161853324 139.7486620096835 5.41 35.66869466076426 139.74873023834488 5.41 35.66866102147878 139.7488328913961 5.41 35.668521440434695 139.7487638905069 5.41 35.668556161853324 139.7486620096835 5.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-febcf4ef-3f22-4841-9e8f-71f82c6e892d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-febcf4ef-3f22-4841-9e8f-71f82c6e892d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-febcf4ef-3f22-4841-9e8f-71f82c6e892d">
											<gml:posList>35.66854370352878 139.7486985630311 36.366 35.66854734380141 139.74869674764346 36.366 35.66855767926629 139.7486664264848 36.366 35.668556161853324 139.7486620096835 36.366 35.66854370352878 139.7486985630311 36.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0f05c4d9-910f-4103-b1fd-718d838ced93">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0f05c4d9-910f-4103-b1fd-718d838ced93">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0f05c4d9-910f-4103-b1fd-718d838ced93">
											<gml:posList>35.668556161853324 139.7486620096835 36.366 35.66855767926629 139.7486664264848 36.366 35.66864281642513 139.74870836669592 36.366 35.668646465672744 139.74870649606686 36.366 35.668556161853324 139.7486620096835 36.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-16983a8a-55a8-44ac-90d9-766af82e95b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16983a8a-55a8-44ac-90d9-766af82e95b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16983a8a-55a8-44ac-90d9-766af82e95b3">
											<gml:posList>35.66861892453261 139.74872619809182 36.004 35.66863406403671 139.74873394746876 36.004 35.66864281642513 139.74870836669592 36.004 35.66855767926629 139.7486664264848 36.004 35.66854734380141 139.74869674764346 36.004 35.66856758691714 139.74870710952587 36.004 35.66861684663786 139.7487322866399 36.004 35.66861892453261 139.74872619809182 36.004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f4fb4cc2-4dac-4f6a-bf4b-1879e61c34df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4fb4cc2-4dac-4f6a-bf4b-1879e61c34df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4fb4cc2-4dac-4f6a-bf4b-1879e61c34df">
											<gml:posList>35.66854668815173 139.74870009527584 32.2 35.66854370352878 139.7486985630311 32.2 35.66854543781329 139.74870375282407 32.2 35.66854668815173 139.74870009527584 32.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-711db9d2-01ff-4adb-ae51-660233cadc0c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-711db9d2-01ff-4adb-ae51-660233cadc0c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-711db9d2-01ff-4adb-ae51-660233cadc0c">
											<gml:posList>35.66856650746672 139.74871023668607 36.366 35.66856758691714 139.74870710952587 36.366 35.66854734380141 139.74869674764346 36.366 35.66854370352878 139.7486985630311 36.366 35.66856650746672 139.74871023668607 36.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-72747cf7-d858-4804-ab8f-b68ba65a10dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-72747cf7-d858-4804-ab8f-b68ba65a10dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-72747cf7-d858-4804-ab8f-b68ba65a10dd">
											<gml:posList>35.66856650746672 139.74871023668607 36.366 35.66861833703033 139.74873673661244 36.366 35.66861684663786 139.7487322866399 36.366 35.66856758691714 139.74870710952587 36.366 35.66856650746672 139.74871023668607 36.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7d9f513b-9754-4b47-a81e-6e440a9ba974">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d9f513b-9754-4b47-a81e-6e440a9ba974">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d9f513b-9754-4b47-a81e-6e440a9ba974">
											<gml:posList>35.668635554429116 139.7487383974423 36.366 35.668646465672744 139.74870649606686 36.366 35.66864281642513 139.74870836669592 36.366 35.66863406403671 139.74873394746876 36.366 35.66861892453261 139.74872619809182 36.366 35.668620414925314 139.74873064806434 36.366 35.668635554429116 139.7487383974423 36.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1cbca950-d776-4aa1-ae07-300991ff80d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1cbca950-d776-4aa1-ae07-300991ff80d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1cbca950-d776-4aa1-ae07-300991ff80d0">
											<gml:posList>35.66869466076426 139.74873023834488 28.1 35.668646465672744 139.74870649606686 36.366 35.668635554429116 139.7487383974423 36.366 35.66869466076426 139.74873023834488 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5b9c6e3d-5006-4d5e-9dd7-276dae48aa46">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b9c6e3d-5006-4d5e-9dd7-276dae48aa46">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b9c6e3d-5006-4d5e-9dd7-276dae48aa46">
											<gml:posList>35.66856299034918 139.74872055737117 35.563 35.668614819926084 139.74874707939512 35.563 35.66861833703033 139.74873673661244 36.366 35.66856650746672 139.74871023668607 36.366 35.66856299034918 139.74872055737117 35.563</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7f604a9f-b69d-479b-9ac8-8ee0b86aaad8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f604a9f-b69d-479b-9ac8-8ee0b86aaad8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f604a9f-b69d-479b-9ac8-8ee0b86aaad8">
											<gml:posList>35.668521440434695 139.7487638905069 32.2 35.66852569337804 139.74876169891235 32.2 35.66854543781329 139.74870375282407 32.2 35.66854370352878 139.7486985630311 32.2 35.668521440434695 139.7487638905069 32.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-22d14f97-0bb5-4804-9ffd-3678a89d7c73">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22d14f97-0bb5-4804-9ffd-3678a89d7c73">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22d14f97-0bb5-4804-9ffd-3678a89d7c73">
											<gml:posList>35.668620414925314 139.74873064806434 36.366 35.66861892453261 139.74872619809182 36.366 35.66861684663786 139.7487322866399 36.366 35.66861833703033 139.74873673661244 36.366 35.668620414925314 139.74873064806434 36.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fcb8d1e7-cbd6-48d3-953f-3f8261d57229">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fcb8d1e7-cbd6-48d3-953f-3f8261d57229">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fcb8d1e7-cbd6-48d3-953f-3f8261d57229">
											<gml:posList>35.668660738677445 139.74875105170702 32.2 35.66869466076426 139.74873023834488 28.1 35.668635554429116 139.7487383974423 36.366 35.668660738677445 139.74875105170702 32.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7f323d6d-56e4-4caa-a350-325d234205ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f323d6d-56e4-4caa-a350-325d234205ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f323d6d-56e4-4caa-a350-325d234205ff">
											<gml:posList>35.6686564947171 139.7487531991123 32.2 35.668660738677445 139.74875105170702 32.2 35.668635554429116 139.7487383974423 32.2 35.66863270506694 139.74873694237388 32.2 35.668631454735184 139.74874061097145 32.2 35.6686564947171 139.7487531991123 32.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-97a7d36f-16d2-47b0-bebb-ae9ab22adfde">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-97a7d36f-16d2-47b0-bebb-ae9ab22adfde">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-97a7d36f-16d2-47b0-bebb-ae9ab22adfde">
											<gml:posList>35.66856299034918 139.74872055737117 31.735 35.66856650746672 139.74871023668607 31.735 35.66854668815173 139.74870009527584 31.735 35.66854543781329 139.74870375282407 31.735 35.66852569337804 139.74876169891235 31.735 35.668635311395995 139.74881589657403 31.735 35.6686564947171 139.7487531991123 31.735 35.668631454735184 139.74874061097145 31.735 35.66863270506694 139.74873694237388 31.735 35.668620414925314 139.74873064806434 31.735 35.668614819926084 139.74874707939512 31.735 35.66856299034918 139.74872055737117 31.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7b3a885f-e2a0-46ef-90b0-22416ff73641">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b3a885f-e2a0-46ef-90b0-22416ff73641">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b3a885f-e2a0-46ef-90b0-22416ff73641">
											<gml:posList>35.668660738677445 139.74875105170702 32.2 35.66866102147878 139.7488328913961 28.1 35.66869466076426 139.74873023834488 28.1 35.668660738677445 139.74875105170702 32.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ad94b341-18bc-405f-9d72-2b4665a20dcf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad94b341-18bc-405f-9d72-2b4665a20dcf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad94b341-18bc-405f-9d72-2b4665a20dcf">
											<gml:posList>35.668660738677445 139.74875105170702 32.2 35.6686564947171 139.7487531991123 32.2 35.668635311395995 139.74881589657403 32.2 35.668637090728566 139.7488210642359 32.2 35.668660738677445 139.74875105170702 32.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b79f8b41-14a5-45d5-a0ab-57d62c8a584b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b79f8b41-14a5-45d5-a0ab-57d62c8a584b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b79f8b41-14a5-45d5-a0ab-57d62c8a584b">
											<gml:posList>35.668637090728566 139.7488210642359 32.2 35.668635311395995 139.74881589657403 32.2 35.66852569337804 139.74876169891235 32.2 35.668521440434695 139.7487638905069 32.2 35.668637090728566 139.7488210642359 32.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ceb6ee7a-01ef-4306-9fd6-819c1c08daee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ceb6ee7a-01ef-4306-9fd6-819c1c08daee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ceb6ee7a-01ef-4306-9fd6-819c1c08daee">
											<gml:posList>35.668660738677445 139.74875105170702 32.2 35.668637090728566 139.7488210642359 32.2 35.66866102147878 139.7488328913961 28.1 35.668660738677445 139.74875105170702 32.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3cc2bd1c-7a03-4638-8144-ce6d5064971f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3cc2bd1c-7a03-4638-8144-ce6d5064971f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3cc2bd1c-7a03-4638-8144-ce6d5064971f">
											<gml:posList>35.66856758691714 139.74870710952587 36.366 35.66856758691714 139.74870710952587 36.004 35.66854734380141 139.74869674764346 36.004 35.66854734380141 139.74869674764346 36.366 35.66856758691714 139.74870710952587 36.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-222d86d8-e3f2-4bc0-b711-1bd705d1993f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-222d86d8-e3f2-4bc0-b711-1bd705d1993f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-222d86d8-e3f2-4bc0-b711-1bd705d1993f">
											<gml:posList>35.66861684663786 139.7487322866399 36.366 35.66861684663786 139.7487322866399 36.004 35.66856758691714 139.74870710952587 36.004 35.66856758691714 139.74870710952587 36.366 35.66861684663786 139.7487322866399 36.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-03fed9d9-a46d-449f-aa6e-1d47eaeb3301">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03fed9d9-a46d-449f-aa6e-1d47eaeb3301">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03fed9d9-a46d-449f-aa6e-1d47eaeb3301">
											<gml:posList>35.66863406403671 139.74873394746876 36.366 35.66863406403671 139.74873394746876 36.004 35.66861892453261 139.74872619809182 36.004 35.66861892453261 139.74872619809182 36.366 35.66863406403671 139.74873394746876 36.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e99fb9dd-995e-4909-9811-8a648b4a4d2d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e99fb9dd-995e-4909-9811-8a648b4a4d2d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e99fb9dd-995e-4909-9811-8a648b4a4d2d">
											<gml:posList>35.66854734380141 139.74869674764346 36.366 35.66854734380141 139.74869674764346 36.004 35.66855767926629 139.7486664264848 36.004 35.66855767926629 139.7486664264848 36.366 35.66854734380141 139.74869674764346 36.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7766a27f-6c00-43d7-a983-50e7aade2ada">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7766a27f-6c00-43d7-a983-50e7aade2ada">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7766a27f-6c00-43d7-a983-50e7aade2ada">
											<gml:posList>35.66855767926629 139.7486664264848 36.366 35.66855767926629 139.7486664264848 36.004 35.66864281642513 139.74870836669592 36.004 35.66864281642513 139.74870836669592 36.366 35.66855767926629 139.7486664264848 36.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bd1baece-d017-4fb2-9edb-59436de2413c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd1baece-d017-4fb2-9edb-59436de2413c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd1baece-d017-4fb2-9edb-59436de2413c">
											<gml:posList>35.668556161853324 139.7486620096835 5.41 35.668556161853324 139.7486620096835 36.366 35.668646465672744 139.74870649606686 36.366 35.66869466076426 139.74873023834488 28.1 35.66869466076426 139.74873023834488 5.41 35.668556161853324 139.7486620096835 5.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3b994e56-541e-4f4d-b294-26314c6c9b3e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3b994e56-541e-4f4d-b294-26314c6c9b3e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3b994e56-541e-4f4d-b294-26314c6c9b3e">
											<gml:posList>35.66854543781329 139.74870375282407 32.2 35.66854543781329 139.74870375282407 31.735 35.66854668815173 139.74870009527584 31.735 35.66854668815173 139.74870009527584 32.2 35.66854543781329 139.74870375282407 32.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b7089854-6fcc-408c-bde6-246a6604fd27">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b7089854-6fcc-408c-bde6-246a6604fd27">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b7089854-6fcc-408c-bde6-246a6604fd27">
											<gml:posList>35.66854370352878 139.7486985630311 36.366 35.66854370352878 139.7486985630311 32.2 35.66854668815173 139.74870009527584 32.2 35.66854668815173 139.74870009527584 31.735 35.66856650746672 139.74871023668607 31.735 35.66856650746672 139.74871023668607 36.366 35.66854370352878 139.7486985630311 36.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6511c01a-0e7f-48a4-b8e5-fa93b7c800af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6511c01a-0e7f-48a4-b8e5-fa93b7c800af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6511c01a-0e7f-48a4-b8e5-fa93b7c800af">
											<gml:posList>35.668556161853324 139.7486620096835 5.41 35.668521440434695 139.7487638905069 5.41 35.668521440434695 139.7487638905069 32.2 35.66854370352878 139.7486985630311 32.2 35.66854370352878 139.7486985630311 36.366 35.668556161853324 139.7486620096835 36.366 35.668556161853324 139.7486620096835 5.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-89e892da-be46-4d4f-9022-5cd7088bafba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-89e892da-be46-4d4f-9022-5cd7088bafba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-89e892da-be46-4d4f-9022-5cd7088bafba">
											<gml:posList>35.66856299034918 139.74872055737117 35.563 35.66856650746672 139.74871023668607 36.366 35.66856650746672 139.74871023668607 31.735 35.66856299034918 139.74872055737117 31.735 35.66856299034918 139.74872055737117 35.563</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e1b62038-b0a4-43cf-b476-dc58cd514a34">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e1b62038-b0a4-43cf-b476-dc58cd514a34">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e1b62038-b0a4-43cf-b476-dc58cd514a34">
											<gml:posList>35.66864281642513 139.74870836669592 36.366 35.66864281642513 139.74870836669592 36.004 35.66863406403671 139.74873394746876 36.004 35.66863406403671 139.74873394746876 36.366 35.66864281642513 139.74870836669592 36.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-721357be-72f4-4cf1-b1c0-6565d813b8b5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-721357be-72f4-4cf1-b1c0-6565d813b8b5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-721357be-72f4-4cf1-b1c0-6565d813b8b5">
											<gml:posList>35.66861892453261 139.74872619809182 36.366 35.66861892453261 139.74872619809182 36.004 35.66861684663786 139.7487322866399 36.004 35.66861684663786 139.7487322866399 36.366 35.66861892453261 139.74872619809182 36.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cba2fe80-08bd-4986-8012-c28a77f4c565">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cba2fe80-08bd-4986-8012-c28a77f4c565">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cba2fe80-08bd-4986-8012-c28a77f4c565">
											<gml:posList>35.66852569337804 139.74876169891235 32.2 35.66852569337804 139.74876169891235 31.735 35.66854543781329 139.74870375282407 31.735 35.66854543781329 139.74870375282407 32.2 35.66852569337804 139.74876169891235 32.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-001e70bf-23aa-47d5-87d2-582a2ff3034c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-001e70bf-23aa-47d5-87d2-582a2ff3034c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-001e70bf-23aa-47d5-87d2-582a2ff3034c">
											<gml:posList>35.66856299034918 139.74872055737117 31.735 35.668614819926084 139.74874707939512 31.735 35.668614819926084 139.74874707939512 35.563 35.66856299034918 139.74872055737117 35.563 35.66856299034918 139.74872055737117 31.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a71344dd-eff6-472a-b471-4ef4474e8cb5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a71344dd-eff6-472a-b471-4ef4474e8cb5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a71344dd-eff6-472a-b471-4ef4474e8cb5">
											<gml:posList>35.668620414925314 139.74873064806434 31.735 35.66863270506694 139.74873694237388 31.735 35.66863270506694 139.74873694237388 32.2 35.668635554429116 139.7487383974423 32.2 35.668635554429116 139.7487383974423 36.366 35.668620414925314 139.74873064806434 36.366 35.668620414925314 139.74873064806434 31.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5af855ab-f058-4edf-9223-0b388a4b84cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5af855ab-f058-4edf-9223-0b388a4b84cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5af855ab-f058-4edf-9223-0b388a4b84cc">
											<gml:posList>35.66863270506694 139.74873694237388 32.2 35.66863270506694 139.74873694237388 31.735 35.668631454735184 139.74874061097145 31.735 35.668631454735184 139.74874061097145 32.2 35.66863270506694 139.74873694237388 32.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d31a0cf7-0581-4bf2-885b-c79704bb2227">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d31a0cf7-0581-4bf2-885b-c79704bb2227">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d31a0cf7-0581-4bf2-885b-c79704bb2227">
											<gml:posList>35.668620414925314 139.74873064806434 31.735 35.668620414925314 139.74873064806434 36.366 35.66861833703033 139.74873673661244 36.366 35.668614819926084 139.74874707939512 35.563 35.668614819926084 139.74874707939512 31.735 35.668620414925314 139.74873064806434 31.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2a9f3727-7ed2-4406-80e2-cab88218da7f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a9f3727-7ed2-4406-80e2-cab88218da7f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a9f3727-7ed2-4406-80e2-cab88218da7f">
											<gml:posList>35.668635554429116 139.7487383974423 36.366 35.668635554429116 139.7487383974423 32.2 35.668660738677445 139.74875105170702 32.2 35.668635554429116 139.7487383974423 36.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ecea5680-4463-4c23-b539-49f7d9f315fa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ecea5680-4463-4c23-b539-49f7d9f315fa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ecea5680-4463-4c23-b539-49f7d9f315fa">
											<gml:posList>35.6686564947171 139.7487531991123 31.735 35.6686564947171 139.7487531991123 32.2 35.668631454735184 139.74874061097145 32.2 35.668631454735184 139.74874061097145 31.735 35.6686564947171 139.7487531991123 31.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-69a0e112-e836-49f8-9cd7-a3b4072fe5d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69a0e112-e836-49f8-9cd7-a3b4072fe5d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69a0e112-e836-49f8-9cd7-a3b4072fe5d3">
											<gml:posList>35.66866102147878 139.7488328913961 5.41 35.66869466076426 139.74873023834488 5.41 35.66869466076426 139.74873023834488 28.1 35.66866102147878 139.7488328913961 28.1 35.66866102147878 139.7488328913961 5.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-10bc8558-aa49-4131-8b10-f17093716392">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-10bc8558-aa49-4131-8b10-f17093716392">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-10bc8558-aa49-4131-8b10-f17093716392">
											<gml:posList>35.6686564947171 139.7487531991123 32.2 35.6686564947171 139.7487531991123 31.735 35.668635311395995 139.74881589657403 31.735 35.668635311395995 139.74881589657403 32.2 35.6686564947171 139.7487531991123 32.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d7259479-8334-4fbd-8ac9-9b0c49daed98">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7259479-8334-4fbd-8ac9-9b0c49daed98">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7259479-8334-4fbd-8ac9-9b0c49daed98">
											<gml:posList>35.668635311395995 139.74881589657403 32.2 35.668635311395995 139.74881589657403 31.735 35.66852569337804 139.74876169891235 31.735 35.66852569337804 139.74876169891235 32.2 35.668635311395995 139.74881589657403 32.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a93bfc38-1bdf-41ae-97d0-112da998dff2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a93bfc38-1bdf-41ae-97d0-112da998dff2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a93bfc38-1bdf-41ae-97d0-112da998dff2">
											<gml:posList>35.668521440434695 139.7487638905069 32.2 35.668521440434695 139.7487638905069 5.41 35.66866102147878 139.7488328913961 5.41 35.66866102147878 139.7488328913961 28.1 35.668637090728566 139.7488210642359 32.2 35.668521440434695 139.7487638905069 32.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7346</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">166.3671</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.12</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>