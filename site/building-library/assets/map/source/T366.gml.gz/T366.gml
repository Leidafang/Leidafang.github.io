<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_698a2922-82be-4df0-aef9-35ff5aeb5ce9">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">21.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67100183465727 139.74067380286291 0 35.67105909780609 139.74059044718186 0 35.67097466510604 139.7405071449718 0 35.67091866461575 139.7405913828705 0 35.67100183465727 139.74067380286291 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67100183465727 139.74067380286291 9.64 35.67091866461575 139.7405913828705 9.64 35.67097466510604 139.7405071449718 9.64 35.67105909780609 139.74059044718186 9.64 35.67100183465727 139.74067380286291 9.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67100183465727 139.74067380286291 9.64 35.67105909780609 139.74059044718186 9.64 35.67105909780609 139.74059044718186 31.28 35.67100183465727 139.74067380286291 31.28 35.67100183465727 139.74067380286291 9.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67105909780609 139.74059044718186 9.64 35.67097466510604 139.7405071449718 9.64 35.67097466510604 139.7405071449718 31.28 35.67105909780609 139.74059044718186 31.28 35.67105909780609 139.74059044718186 9.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67097466510604 139.7405071449718 9.64 35.67091866461575 139.7405913828705 9.64 35.67091866461575 139.7405913828705 31.28 35.67097466510604 139.7405071449718 31.28 35.67097466510604 139.7405071449718 9.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67091866461575 139.7405913828705 9.64 35.67100183465727 139.74067380286291 9.64 35.67100183465727 139.74067380286291 31.28 35.67091866461575 139.7405913828705 31.28 35.67091866461575 139.7405913828705 9.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67100183465727 139.74067380286291 31.28 35.67105909780609 139.74059044718186 31.28 35.67097466510604 139.7405071449718 31.28 35.67091866461575 139.7405913828705 31.28 35.67100183465727 139.74067380286291 31.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-985a2e39-01f1-425b-b8df-366e8ceda025"/>
							<gml:surfaceMember xlink:href="#poly-df905ab1-9636-4e7c-928c-d0870843c42d"/>
							<gml:surfaceMember xlink:href="#poly-3133f061-25d9-40ff-a769-141520faf6d7"/>
							<gml:surfaceMember xlink:href="#poly-a6b4611c-6635-4888-9388-b72f63b4accf"/>
							<gml:surfaceMember xlink:href="#poly-67b545db-e00e-4436-9bd1-1fda160c2d01"/>
							<gml:surfaceMember xlink:href="#poly-d218a741-11f6-4a63-84ef-f8a6dca6e482"/>
							<gml:surfaceMember xlink:href="#poly-8d88738a-021d-44d0-8a05-58c9df3d31aa"/>
							<gml:surfaceMember xlink:href="#poly-569d6b2a-df75-4e42-98c6-0aed8b5e64d1"/>
							<gml:surfaceMember xlink:href="#poly-a41632e2-e5e4-4ac4-be52-90a73e975b21"/>
							<gml:surfaceMember xlink:href="#poly-35fb38fa-75ba-49bb-b779-fe95136d5b3c"/>
							<gml:surfaceMember xlink:href="#poly-8f3b13a8-2cb9-4552-8c20-4e47a8b25337"/>
							<gml:surfaceMember xlink:href="#poly-958bcf30-b307-4fae-b413-ac12e1fb00a3"/>
							<gml:surfaceMember xlink:href="#poly-2cd56568-0daf-4870-b6ff-aabdab8179c2"/>
							<gml:surfaceMember xlink:href="#poly-df12ffeb-3b18-454d-bbb3-64f1e98de478"/>
							<gml:surfaceMember xlink:href="#poly-fd74740a-575f-4943-831c-97812ed45eae"/>
							<gml:surfaceMember xlink:href="#poly-9f8de366-25d2-42cb-a062-1ab0e091cba9"/>
							<gml:surfaceMember xlink:href="#poly-1b1b79e5-35a7-479b-98df-c0c3c4138a60"/>
							<gml:surfaceMember xlink:href="#poly-26ae9ad0-0362-4f8f-aafe-82ed064cbcf9"/>
							<gml:surfaceMember xlink:href="#poly-7d68263b-8a5f-4e41-a9a2-56aa007ddd8a"/>
							<gml:surfaceMember xlink:href="#poly-0fdb4d53-eaa3-4748-8f68-78e61e0b9095"/>
							<gml:surfaceMember xlink:href="#poly-ebb6e473-ebd3-4277-9b15-f31deb87e75a"/>
							<gml:surfaceMember xlink:href="#poly-d950999d-5641-47a3-a7fa-d9270c716ecc"/>
							<gml:surfaceMember xlink:href="#poly-4a4159df-b880-47d9-9ee5-be054d8527bf"/>
							<gml:surfaceMember xlink:href="#poly-4fe539f2-dbfe-4d75-8173-7a2c61252573"/>
							<gml:surfaceMember xlink:href="#poly-d334cb18-acd8-479a-ad35-1ae1b7a3c5b4"/>
							<gml:surfaceMember xlink:href="#poly-e0774357-ea02-4858-ac18-3d9f5effc1d8"/>
							<gml:surfaceMember xlink:href="#poly-cd8c60e8-37d8-44cd-bfd1-5145eb60dd38"/>
							<gml:surfaceMember xlink:href="#poly-47c452fa-7c5b-4ccf-b5b5-c16f45e8e360"/>
							<gml:surfaceMember xlink:href="#poly-ac545743-07cd-4766-b299-dcb2e751eb4d"/>
							<gml:surfaceMember xlink:href="#poly-99997ae3-c9d3-4e4c-81cc-3d336ca7464d"/>
							<gml:surfaceMember xlink:href="#poly-507ea45e-71bd-4415-b293-d879dfc90df1"/>
							<gml:surfaceMember xlink:href="#poly-fcf1d96a-2645-4b45-a4d3-310e1ea3392f"/>
							<gml:surfaceMember xlink:href="#poly-e3e8625c-d3bf-45f7-b9b9-8128f9e52264"/>
							<gml:surfaceMember xlink:href="#poly-d699dc48-c48b-4a68-bf11-e4f634a2a0bf"/>
							<gml:surfaceMember xlink:href="#poly-eaddf295-56ef-4689-b00c-5075bb7cdfb6"/>
							<gml:surfaceMember xlink:href="#poly-2cdf63ea-ed80-4372-92a6-b87a7c30fa70"/>
							<gml:surfaceMember xlink:href="#poly-35f907db-ef0c-4214-adef-beb86536328f"/>
							<gml:surfaceMember xlink:href="#poly-dc2a05c0-136f-4ad8-9d9f-4af58b2f2e8b"/>
							<gml:surfaceMember xlink:href="#poly-9696f67f-3603-48ee-aa0d-875360f255d5"/>
							<gml:surfaceMember xlink:href="#poly-1167f770-0285-4a8d-ae26-e94d016c9912"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_698a2922-82be-4df0-aef9-35ff5aeb5ce9_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c8b0ed4-63c0-4c16-be33-b140041138bd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67095788836449 139.7405627827127 31.759 35.67096494673054 139.74055188285428 31.759 35.67098125577816 139.7405677486212 31.759 35.6709741974107 139.74057864848044 31.759 35.67095788836449 139.7405627827127 31.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d2d19c95-edff-4ba0-a54a-9eb811b0f994">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d2d19c95-edff-4ba0-a54a-9eb811b0f994_0">
											<gml:posList>35.67095788836449 139.7405627827127 31.759 35.67095788836449 139.7405627827127 33.959 35.67096494673054 139.74055188285428 33.959 35.67096494673054 139.74055188285428 31.759 35.67095788836449 139.7405627827127 31.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-898b5d52-1fd1-4181-a7df-b17e83e8faf3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-898b5d52-1fd1-4181-a7df-b17e83e8faf3_0">
											<gml:posList>35.67096494673054 139.74055188285428 31.759 35.67096494673054 139.74055188285428 33.959 35.67098125577816 139.7405677486212 33.959 35.67098125577816 139.7405677486212 31.759 35.67096494673054 139.74055188285428 31.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99b5b009-f3bf-436a-a28e-81a4a80a3fee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-99b5b009-f3bf-436a-a28e-81a4a80a3fee_0">
											<gml:posList>35.67095788836449 139.7405627827127 33.959 35.6709741974107 139.74057864848044 33.959 35.67098125577816 139.7405677486212 33.959 35.67096494673054 139.74055188285428 33.959 35.67095788836449 139.7405627827127 33.959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-172450a0-b043-4611-8fc2-89039ac26327">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-172450a0-b043-4611-8fc2-89039ac26327_0">
											<gml:posList>35.6709741974107 139.74057864848044 31.759 35.6709741974107 139.74057864848044 33.959 35.67095788836449 139.7405627827127 33.959 35.67095788836449 139.7405627827127 31.759 35.6709741974107 139.74057864848044 31.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b73bd16f-c886-4088-91eb-8f4097bd0f62">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b73bd16f-c886-4088-91eb-8f4097bd0f62_0">
											<gml:posList>35.67098125577816 139.7405677486212 31.759 35.67098125577816 139.7405677486212 33.959 35.6709741974107 139.74057864848044 33.959 35.6709741974107 139.74057864848044 31.759 35.67098125577816 139.7405677486212 31.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-985a2e39-01f1-425b-b8df-366e8ceda025">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-985a2e39-01f1-425b-b8df-366e8ceda025">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-985a2e39-01f1-425b-b8df-366e8ceda025">
											<gml:posList>35.67100183465726 139.74067380286291 9.64 35.67091866461573 139.7405913828705 9.64 35.67097466510602 139.7405071449718 9.64 35.671059097806065 139.74059044718186 9.64 35.67100183465726 139.74067380286291 9.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-df905ab1-9636-4e7c-928c-d0870843c42d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df905ab1-9636-4e7c-928c-d0870843c42d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df905ab1-9636-4e7c-928c-d0870843c42d">
											<gml:posList>35.670994653615324 139.74061902129526 32.254 35.67102127357789 139.74064557907133 26.733 35.671059097806065 139.74059044718186 26.733 35.670994653615324 139.74061902129526 32.254</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3133f061-25d9-40ff-a769-141520faf6d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3133f061-25d9-40ff-a769-141520faf6d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3133f061-25d9-40ff-a769-141520faf6d7">
											<gml:posList>35.671059097806065 139.74059044718186 26.733 35.671029582443886 139.7405613189625 32.254 35.670994653615324 139.74061902129526 32.254 35.671059097806065 139.74059044718186 26.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a6b4611c-6635-4888-9388-b72f63b4accf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a6b4611c-6635-4888-9388-b72f63b4accf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a6b4611c-6635-4888-9388-b72f63b4accf">
											<gml:posList>35.67097466510602 139.7405071449718 32.254 35.67097500164524 139.7405110770797 32.254 35.67099484738895 139.7405312357743 32.254 35.671029582443886 139.7405613189625 32.254 35.67097466510602 139.7405071449718 32.254</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-67b545db-e00e-4436-9bd1-1fda160c2d01">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67b545db-e00e-4436-9bd1-1fda160c2d01">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67b545db-e00e-4436-9bd1-1fda160c2d01">
											<gml:posList>35.670980442561046 139.74055347768805 34.751 35.67098214597572 139.74055324374368 34.751 35.670995047299854 139.74053332330197 34.751 35.67099484738895 139.7405312357743 34.751 35.670980442561046 139.74055347768805 34.751</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d218a741-11f6-4a63-84ef-f8a6dca6e482">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d218a741-11f6-4a63-84ef-f8a6dca6e482">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d218a741-11f6-4a63-84ef-f8a6dca6e482">
											<gml:posList>35.67099484738895 139.7405312357743 34.751 35.670995047299854 139.74053332330197 34.751 35.67102605071601 139.7405634660407 34.751 35.67102774511698 139.74056323210684 34.751 35.67099484738895 139.7405312357743 34.751</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8d88738a-021d-44d0-8a05-58c9df3d31aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d88738a-021d-44d0-8a05-58c9df3d31aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d88738a-021d-44d0-8a05-58c9df3d31aa">
											<gml:posList>35.67091866461573 139.7405913828705 32.254 35.67092187319445 139.740590981491 32.254 35.67097500164524 139.7405110770797 32.254 35.67097466510602 139.7405071449718 32.254 35.67091866461573 139.7405913828705 32.254</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-569d6b2a-df75-4e42-98c6-0aed8b5e64d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-569d6b2a-df75-4e42-98c6-0aed8b5e64d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-569d6b2a-df75-4e42-98c6-0aed8b5e64d1">
											<gml:posList>35.671029582443886 139.7405613189625 32.254 35.67099484738895 139.7405312357743 32.254 35.67102774511698 139.74056323210684 32.254 35.67101334929698 139.74058547401356 32.254 35.671029582443886 139.7405613189625 32.254</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a41632e2-e5e4-4ac4-be52-90a73e975b21">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a41632e2-e5e4-4ac4-be52-90a73e975b21">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a41632e2-e5e4-4ac4-be52-90a73e975b21">
											<gml:posList>35.67102605071601 139.7405634660407 34.532 35.670995047299854 139.74053332330197 34.532 35.67098214597572 139.74055324374368 34.532 35.67101314939548 139.74058339753162 34.532 35.67102605071601 139.7405634660407 34.532</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-35fb38fa-75ba-49bb-b779-fe95136d5b3c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-35fb38fa-75ba-49bb-b779-fe95136d5b3c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-35fb38fa-75ba-49bb-b779-fe95136d5b3c">
											<gml:posList>35.67097500164524 139.7405110770797 31.759 35.67092187319445 139.740590981491 31.759 35.67094734740013 139.74061621499814 31.759 35.67096713717895 139.7405871291914 31.759 35.67098741707426 139.7406092426035 31.759 35.670994145869955 139.740615155662 31.759 35.67101334929698 139.74058547401356 31.759 35.670980442561046 139.74055347768805 31.759 35.67099484738895 139.7405312357743 31.759 35.67097500164524 139.7405110770797 31.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8f3b13a8-2cb9-4552-8c20-4e47a8b25337">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f3b13a8-2cb9-4552-8c20-4e47a8b25337">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f3b13a8-2cb9-4552-8c20-4e47a8b25337">
											<gml:posList>35.67101334929698 139.74058547401356 34.751 35.67101314939548 139.74058339753162 34.751 35.67098214597572 139.74055324374368 34.751 35.670980442561046 139.74055347768805 34.751 35.67101334929698 139.74058547401356 34.751</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-958bcf30-b307-4fae-b413-ac12e1fb00a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-958bcf30-b307-4fae-b413-ac12e1fb00a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-958bcf30-b307-4fae-b413-ac12e1fb00a3">
											<gml:posList>35.67102774511698 139.74056323210684 34.751 35.67102605071601 139.7405634660407 34.751 35.67101314939548 139.74058339753162 34.751 35.67101334929698 139.74058547401356 34.751 35.67102774511698 139.74056323210684 34.751</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2cd56568-0daf-4870-b6ff-aabdab8179c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2cd56568-0daf-4870-b6ff-aabdab8179c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2cd56568-0daf-4870-b6ff-aabdab8179c2">
											<gml:posList>35.670994653615324 139.74061902129526 32.254 35.671029582443886 139.7405613189625 32.254 35.67101334929698 139.74058547401356 32.254 35.670994145869955 139.740615155662 32.254 35.670994653615324 139.74061902129526 32.254</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-df12ffeb-3b18-454d-bbb3-64f1e98de478">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df12ffeb-3b18-454d-bbb3-64f1e98de478">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df12ffeb-3b18-454d-bbb3-64f1e98de478">
											<gml:posList>35.67094734740013 139.74061621499814 30.279 35.670968789397 139.74063746545403 30.279 35.67098741707426 139.7406092426035 30.279 35.67096713717895 139.7405871291914 30.279 35.67094734740013 139.74061621499814 30.279</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fd74740a-575f-4943-831c-97812ed45eae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fd74740a-575f-4943-831c-97812ed45eae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fd74740a-575f-4943-831c-97812ed45eae">
											<gml:posList>35.67098783463157 139.74061304206265 32.254 35.670994653615324 139.74061902129526 32.254 35.670994145869955 139.740615155662 32.254 35.67098741707426 139.7406092426035 32.254 35.67098783463157 139.74061304206265 32.254</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9f8de366-25d2-42cb-a062-1ab0e091cba9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f8de366-25d2-42cb-a062-1ab0e091cba9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f8de366-25d2-42cb-a062-1ab0e091cba9">
											<gml:posList>35.670969125923456 139.7406413865159 32.254 35.670968789397 139.74063746545403 32.254 35.67094734740013 139.74061621499814 32.254 35.67092187319445 139.740590981491 32.254 35.67091866461573 139.7405913828705 32.254 35.670969125923456 139.7406413865159 32.254</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1b1b79e5-35a7-479b-98df-c0c3c4138a60">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b1b79e5-35a7-479b-98df-c0c3c4138a60">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b1b79e5-35a7-479b-98df-c0c3c4138a60">
											<gml:posList>35.67098783463157 139.74061304206265 32.254 35.67098741707426 139.7406092426035 32.254 35.670968789397 139.74063746545403 32.254 35.670969125923456 139.7406413865159 32.254 35.67098783463157 139.74061304206265 32.254</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-26ae9ad0-0362-4f8f-aafe-82ed064cbcf9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26ae9ad0-0362-4f8f-aafe-82ed064cbcf9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26ae9ad0-0362-4f8f-aafe-82ed064cbcf9">
											<gml:posList>35.67098783463157 139.74061304206265 32.254 35.670969125923456 139.7406413865159 32.254 35.67100183465726 139.74067380286291 26.733 35.67102127357789 139.74064557907133 26.733 35.67098783463157 139.74061304206265 32.254</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7d68263b-8a5f-4e41-a9a2-56aa007ddd8a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d68263b-8a5f-4e41-a9a2-56aa007ddd8a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d68263b-8a5f-4e41-a9a2-56aa007ddd8a">
											<gml:posList>35.670995047299854 139.74053332330197 34.751 35.670995047299854 139.74053332330197 34.532 35.67102605071601 139.7405634660407 34.532 35.67102605071601 139.7405634660407 34.751 35.670995047299854 139.74053332330197 34.751</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0fdb4d53-eaa3-4748-8f68-78e61e0b9095">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0fdb4d53-eaa3-4748-8f68-78e61e0b9095">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0fdb4d53-eaa3-4748-8f68-78e61e0b9095">
											<gml:posList>35.67101314939548 139.74058339753162 34.751 35.67101314939548 139.74058339753162 34.532 35.67098214597572 139.74055324374368 34.532 35.67098214597572 139.74055324374368 34.751 35.67101314939548 139.74058339753162 34.751</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ebb6e473-ebd3-4277-9b15-f31deb87e75a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ebb6e473-ebd3-4277-9b15-f31deb87e75a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ebb6e473-ebd3-4277-9b15-f31deb87e75a">
											<gml:posList>35.67098741707426 139.7406092426035 31.759 35.67096713717895 139.7405871291914 31.759 35.67096713717895 139.7405871291914 30.279 35.67098741707426 139.7406092426035 30.279 35.67098741707426 139.7406092426035 31.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d950999d-5641-47a3-a7fa-d9270c716ecc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d950999d-5641-47a3-a7fa-d9270c716ecc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d950999d-5641-47a3-a7fa-d9270c716ecc">
											<gml:posList>35.67094734740013 139.74061621499814 32.254 35.67094734740013 139.74061621499814 31.759 35.67092187319445 139.740590981491 31.759 35.67092187319445 139.740590981491 32.254 35.67094734740013 139.74061621499814 32.254</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4a4159df-b880-47d9-9ee5-be054d8527bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a4159df-b880-47d9-9ee5-be054d8527bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a4159df-b880-47d9-9ee5-be054d8527bf">
											<gml:posList>35.67097466510602 139.7405071449718 9.64 35.67091866461573 139.7405913828705 9.64 35.67091866461573 139.7405913828705 32.254 35.67097466510602 139.7405071449718 32.254 35.67097466510602 139.7405071449718 9.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4fe539f2-dbfe-4d75-8173-7a2c61252573">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4fe539f2-dbfe-4d75-8173-7a2c61252573">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4fe539f2-dbfe-4d75-8173-7a2c61252573">
											<gml:posList>35.67092187319445 139.740590981491 32.254 35.67092187319445 139.740590981491 31.759 35.67097500164524 139.7405110770797 31.759 35.67097500164524 139.7405110770797 32.254 35.67092187319445 139.740590981491 32.254</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d334cb18-acd8-479a-ad35-1ae1b7a3c5b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d334cb18-acd8-479a-ad35-1ae1b7a3c5b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d334cb18-acd8-479a-ad35-1ae1b7a3c5b4">
											<gml:posList>35.67096713717895 139.7405871291914 30.279 35.67096713717895 139.7405871291914 31.759 35.67094734740013 139.74061621499814 31.759 35.67094734740013 139.74061621499814 30.279 35.67096713717895 139.7405871291914 30.279</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e0774357-ea02-4858-ac18-3d9f5effc1d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e0774357-ea02-4858-ac18-3d9f5effc1d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e0774357-ea02-4858-ac18-3d9f5effc1d8">
											<gml:posList>35.670968789397 139.74063746545403 32.254 35.670968789397 139.74063746545403 30.279 35.67094734740013 139.74061621499814 30.279 35.67094734740013 139.74061621499814 31.759 35.67094734740013 139.74061621499814 32.254 35.670968789397 139.74063746545403 32.254</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cd8c60e8-37d8-44cd-bfd1-5145eb60dd38">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd8c60e8-37d8-44cd-bfd1-5145eb60dd38">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd8c60e8-37d8-44cd-bfd1-5145eb60dd38">
											<gml:posList>35.67091866461573 139.7405913828705 32.254 35.67091866461573 139.7405913828705 9.64 35.67100183465726 139.74067380286291 9.64 35.67100183465726 139.74067380286291 26.733 35.670969125923456 139.7406413865159 32.254 35.67091866461573 139.7405913828705 32.254</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-47c452fa-7c5b-4ccf-b5b5-c16f45e8e360">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47c452fa-7c5b-4ccf-b5b5-c16f45e8e360">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47c452fa-7c5b-4ccf-b5b5-c16f45e8e360">
											<gml:posList>35.670968789397 139.74063746545403 32.254 35.67098741707426 139.7406092426035 32.254 35.67098741707426 139.7406092426035 31.759 35.67098741707426 139.7406092426035 30.279 35.670968789397 139.74063746545403 30.279 35.670968789397 139.74063746545403 32.254</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ac545743-07cd-4766-b299-dcb2e751eb4d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ac545743-07cd-4766-b299-dcb2e751eb4d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ac545743-07cd-4766-b299-dcb2e751eb4d">
											<gml:posList>35.67097500164524 139.7405110770797 32.254 35.67097500164524 139.7405110770797 31.759 35.67099484738895 139.7405312357743 31.759 35.67099484738895 139.7405312357743 32.254 35.67097500164524 139.7405110770797 32.254</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-99997ae3-c9d3-4e4c-81cc-3d336ca7464d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-99997ae3-c9d3-4e4c-81cc-3d336ca7464d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-99997ae3-c9d3-4e4c-81cc-3d336ca7464d">
											<gml:posList>35.670980442561046 139.74055347768805 31.759 35.670980442561046 139.74055347768805 34.751 35.67099484738895 139.7405312357743 34.751 35.67099484738895 139.7405312357743 32.254 35.67099484738895 139.7405312357743 31.759 35.670980442561046 139.74055347768805 31.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-507ea45e-71bd-4415-b293-d879dfc90df1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-507ea45e-71bd-4415-b293-d879dfc90df1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-507ea45e-71bd-4415-b293-d879dfc90df1">
											<gml:posList>35.67098214597572 139.74055324374368 34.751 35.67098214597572 139.74055324374368 34.532 35.670995047299854 139.74053332330197 34.532 35.670995047299854 139.74053332330197 34.751 35.67098214597572 139.74055324374368 34.751</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fcf1d96a-2645-4b45-a4d3-310e1ea3392f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fcf1d96a-2645-4b45-a4d3-310e1ea3392f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fcf1d96a-2645-4b45-a4d3-310e1ea3392f">
											<gml:posList>35.670994145869955 139.740615155662 32.254 35.670994145869955 139.740615155662 31.759 35.67098741707426 139.7406092426035 31.759 35.67098741707426 139.7406092426035 32.254 35.670994145869955 139.740615155662 32.254</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e3e8625c-d3bf-45f7-b9b9-8128f9e52264">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e3e8625c-d3bf-45f7-b9b9-8128f9e52264">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e3e8625c-d3bf-45f7-b9b9-8128f9e52264">
											<gml:posList>35.670980442561046 139.74055347768805 34.751 35.670980442561046 139.74055347768805 31.759 35.67101334929698 139.74058547401356 31.759 35.67101334929698 139.74058547401356 32.254 35.67101334929698 139.74058547401356 34.751 35.670980442561046 139.74055347768805 34.751</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d699dc48-c48b-4a68-bf11-e4f634a2a0bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d699dc48-c48b-4a68-bf11-e4f634a2a0bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d699dc48-c48b-4a68-bf11-e4f634a2a0bf">
											<gml:posList>35.67101334929698 139.74058547401356 32.254 35.67101334929698 139.74058547401356 31.759 35.670994145869955 139.740615155662 31.759 35.670994145869955 139.740615155662 32.254 35.67101334929698 139.74058547401356 32.254</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eaddf295-56ef-4689-b00c-5075bb7cdfb6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eaddf295-56ef-4689-b00c-5075bb7cdfb6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eaddf295-56ef-4689-b00c-5075bb7cdfb6">
											<gml:posList>35.67102127357789 139.74064557907133 26.733 35.670994653615324 139.74061902129526 32.254 35.67098783463157 139.74061304206265 32.254 35.67102127357789 139.74064557907133 26.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2cdf63ea-ed80-4372-92a6-b87a7c30fa70">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2cdf63ea-ed80-4372-92a6-b87a7c30fa70">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2cdf63ea-ed80-4372-92a6-b87a7c30fa70">
											<gml:posList>35.67099484738895 139.7405312357743 34.751 35.67102774511698 139.74056323210684 34.751 35.67102774511698 139.74056323210684 32.254 35.67099484738895 139.7405312357743 32.254 35.67099484738895 139.7405312357743 34.751</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-35f907db-ef0c-4214-adef-beb86536328f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-35f907db-ef0c-4214-adef-beb86536328f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-35f907db-ef0c-4214-adef-beb86536328f">
											<gml:posList>35.67097466510602 139.7405071449718 32.254 35.671029582443886 139.7405613189625 32.254 35.671059097806065 139.74059044718186 26.733 35.671059097806065 139.74059044718186 9.64 35.67097466510602 139.7405071449718 9.64 35.67097466510602 139.7405071449718 32.254</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dc2a05c0-136f-4ad8-9d9f-4af58b2f2e8b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc2a05c0-136f-4ad8-9d9f-4af58b2f2e8b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc2a05c0-136f-4ad8-9d9f-4af58b2f2e8b">
											<gml:posList>35.67102605071601 139.7405634660407 34.751 35.67102605071601 139.7405634660407 34.532 35.67101314939548 139.74058339753162 34.532 35.67101314939548 139.74058339753162 34.751 35.67102605071601 139.7405634660407 34.751</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9696f67f-3603-48ee-aa0d-875360f255d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9696f67f-3603-48ee-aa0d-875360f255d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9696f67f-3603-48ee-aa0d-875360f255d5">
											<gml:posList>35.67102774511698 139.74056323210684 34.751 35.67101334929698 139.74058547401356 34.751 35.67101334929698 139.74058547401356 32.254 35.67102774511698 139.74056323210684 32.254 35.67102774511698 139.74056323210684 34.751</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1167f770-0285-4a8d-ae26-e94d016c9912">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1167f770-0285-4a8d-ae26-e94d016c9912">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1167f770-0285-4a8d-ae26-e94d016c9912">
											<gml:posList>35.67100183465726 139.74067380286291 9.64 35.671059097806065 139.74059044718186 9.64 35.671059097806065 139.74059044718186 26.733 35.67102127357789 139.74064557907133 26.733 35.67100183465726 139.74067380286291 26.733 35.67100183465726 139.74067380286291 9.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5549</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">117.6561</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.21</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>