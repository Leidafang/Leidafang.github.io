<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_69f4b816-dd42-4112-a100-b8a8ae66d278">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">12.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67026861478018 139.74383442840218 0 35.67032163883087 139.74362349626878 0 35.67023354989283 139.74359023518676 0 35.67018052598145 139.74380127757235 0 35.67026861478018 139.74383442840218 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67026861478018 139.74383442840218 7.72 35.67018052598145 139.74380127757235 7.72 35.67023354989283 139.74359023518676 7.72 35.67032163883087 139.74362349626878 7.72 35.67026861478018 139.74383442840218 7.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67026861478018 139.74383442840218 7.72 35.67032163883087 139.74362349626878 7.72 35.67032163883087 139.74362349626878 20.66 35.67026861478018 139.74383442840218 20.66 35.67026861478018 139.74383442840218 7.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67032163883087 139.74362349626878 7.72 35.67023354989283 139.74359023518676 7.72 35.67023354989283 139.74359023518676 20.66 35.67032163883087 139.74362349626878 20.66 35.67032163883087 139.74362349626878 7.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67023354989283 139.74359023518676 7.72 35.67018052598145 139.74380127757235 7.72 35.67018052598145 139.74380127757235 20.66 35.67023354989283 139.74359023518676 20.66 35.67023354989283 139.74359023518676 7.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67018052598145 139.74380127757235 7.72 35.67026861478018 139.74383442840218 7.72 35.67026861478018 139.74383442840218 20.66 35.67018052598145 139.74380127757235 20.66 35.67018052598145 139.74380127757235 7.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67026861478018 139.74383442840218 20.66 35.67032163883087 139.74362349626878 20.66 35.67023354989283 139.74359023518676 20.66 35.67018052598145 139.74380127757235 20.66 35.67026861478018 139.74383442840218 20.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-e61ceb6d-62f5-4216-8257-01cd5d5dc159"/>
							<gml:surfaceMember xlink:href="#poly-3b7f74b8-a339-41a7-bf5c-e8058855e20e"/>
							<gml:surfaceMember xlink:href="#poly-d37584ce-212b-4b15-9fad-53f33b9939c8"/>
							<gml:surfaceMember xlink:href="#poly-b3d6f831-d08e-4528-8224-f06389311420"/>
							<gml:surfaceMember xlink:href="#poly-9ed30a0b-9513-4b6a-b7d8-5f1f058f5778"/>
							<gml:surfaceMember xlink:href="#poly-6c94184b-431c-4d80-8e11-73f0187bf1d4"/>
							<gml:surfaceMember xlink:href="#poly-e842b7a6-fa09-4e53-af3a-261235dfc453"/>
							<gml:surfaceMember xlink:href="#poly-bbf1b7cc-b699-4e58-ac71-7db74e6a1614"/>
							<gml:surfaceMember xlink:href="#poly-4eb5106c-7d8a-48f1-a9fc-901a151c4904"/>
							<gml:surfaceMember xlink:href="#poly-cebcc944-f155-4a36-bfce-7a7a1cc7c757"/>
							<gml:surfaceMember xlink:href="#poly-cd84acc2-6321-4aa5-8c4e-e0278e504ed2"/>
							<gml:surfaceMember xlink:href="#poly-92c2f0d8-2ef1-4f28-b856-2673c3d34556"/>
							<gml:surfaceMember xlink:href="#poly-6a75893b-e9ff-4cad-8105-165bf43de70c"/>
							<gml:surfaceMember xlink:href="#poly-2eaed7bf-92bd-4efe-a542-2b9f09200610"/>
							<gml:surfaceMember xlink:href="#poly-e21d8b00-de8f-42f1-8974-65f9e0ebaad1"/>
							<gml:surfaceMember xlink:href="#poly-49706d0e-ba11-409f-b0b7-925e63e70b2e"/>
							<gml:surfaceMember xlink:href="#poly-9c448ef3-dac2-441b-a376-f03230ec6a68"/>
							<gml:surfaceMember xlink:href="#poly-a5182367-be89-4fc9-99c9-1349a2c4c9bf"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_69f4b816-dd42-4112-a100-b8a8ae66d278_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1dbb0e9a-2d21-4c28-b536-2eec82487ea7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67026367549986 139.74378626124678 23.207 35.670259541721386 139.74380312243068 23.207 35.67024568381701 139.74379801244908 23.207 35.67024981759479 139.74378115126785 23.207 35.67026367549986 139.74378626124678 23.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-34c9209e-cce4-4ce9-9e8b-7f3e88f02f7d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-34c9209e-cce4-4ce9-9e8b-7f3e88f02f7d_0">
											<gml:posList>35.67024981759479 139.74378115126785 23.207 35.67024981759479 139.74378115126785 26.065 35.67026367549986 139.74378626124678 26.065 35.67026367549986 139.74378626124678 23.207 35.67024981759479 139.74378115126785 23.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5efefe72-4be7-41ed-940d-57c32d6e316e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5efefe72-4be7-41ed-940d-57c32d6e316e_0">
											<gml:posList>35.67024568381701 139.74379801244908 23.207 35.67024568381701 139.74379801244908 26.065 35.67024981759479 139.74378115126785 26.065 35.67024981759479 139.74378115126785 23.207 35.67024568381701 139.74379801244908 23.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-12c2231f-906c-4072-a87d-e7ecbc7703a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-12c2231f-906c-4072-a87d-e7ecbc7703a8_0">
											<gml:posList>35.67024568381701 139.74379801244908 26.065 35.670259541721386 139.74380312243068 26.065 35.67026367549986 139.74378626124678 26.065 35.67024981759479 139.74378115126785 26.065 35.67024568381701 139.74379801244908 26.065</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bba21dcf-baa3-488d-9127-aed889dea873">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bba21dcf-baa3-488d-9127-aed889dea873_0">
											<gml:posList>35.67026367549986 139.74378626124678 23.207 35.67026367549986 139.74378626124678 26.065 35.670259541721386 139.74380312243068 26.065 35.670259541721386 139.74380312243068 23.207 35.67026367549986 139.74378626124678 23.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f3a365fd-9a74-43cd-8b31-720dd3d81945">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f3a365fd-9a74-43cd-8b31-720dd3d81945_0">
											<gml:posList>35.670259541721386 139.74380312243068 23.207 35.670259541721386 139.74380312243068 26.065 35.67024568381701 139.74379801244908 26.065 35.67024568381701 139.74379801244908 23.207 35.670259541721386 139.74380312243068 23.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-e61ceb6d-62f5-4216-8257-01cd5d5dc159">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e61ceb6d-62f5-4216-8257-01cd5d5dc159">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e61ceb6d-62f5-4216-8257-01cd5d5dc159">
											<gml:posList>35.67026861478018 139.74383442840218 7.72 35.67018052598145 139.74380127757235 7.72 35.6702335498928 139.74359023518673 7.72 35.67032163883083 139.74362349626878 7.72 35.67026861478018 139.74383442840218 7.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3b7f74b8-a339-41a7-bf5c-e8058855e20e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3b7f74b8-a339-41a7-bf5c-e8058855e20e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3b7f74b8-a339-41a7-bf5c-e8058855e20e">
											<gml:posList>35.67021161402311 139.74381297396064 15.3 35.6702646650369 139.74360198670175 15.3 35.6702335498928 139.74359023518673 15.3 35.67018052598145 139.74380127757235 15.3 35.67021161402311 139.74381297396064 15.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d37584ce-212b-4b15-9fad-53f33b9939c8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d37584ce-212b-4b15-9fad-53f33b9939c8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d37584ce-212b-4b15-9fad-53f33b9939c8">
											<gml:posList>35.67021161402311 139.74381297396064 21.886 35.6702274646004 139.74381894332456 21.886 35.67028050661896 139.74360796708416 21.886 35.6702646650369 139.74360198670175 21.886 35.67021161402311 139.74381297396064 21.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b3d6f831-d08e-4528-8224-f06389311420">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b3d6f831-d08e-4528-8224-f06389311420">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b3d6f831-d08e-4528-8224-f06389311420">
											<gml:posList>35.67026861478018 139.74383442840218 24.1 35.67026724232136 139.74383123756962 24.1 35.67023005930466 139.74381726139936 24.1 35.6702274646004 139.74381894332456 24.1 35.67026861478018 139.74383442840218 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9ed30a0b-9513-4b6a-b7d8-5f1f058f5778">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ed30a0b-9513-4b6a-b7d8-5f1f058f5778">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ed30a0b-9513-4b6a-b7d8-5f1f058f5778">
											<gml:posList>35.6702274646004 139.74381894332456 24.1 35.67023005930466 139.74381726139936 24.1 35.67028187006172 139.74361114687727 24.1 35.67028050661896 139.74360796708416 24.1 35.6702274646004 139.74381894332456 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6c94184b-431c-4d80-8e11-73f0187bf1d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c94184b-431c-4d80-8e11-73f0187bf1d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c94184b-431c-4d80-8e11-73f0187bf1d4">
											<gml:posList>35.67031903511561 139.74362517821226 23.207 35.67028187006172 139.74361114687727 23.207 35.67023005930466 139.74381726139936 23.207 35.67026724232136 139.74383123756962 23.207 35.67031903511561 139.74362517821226 23.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e842b7a6-fa09-4e53-af3a-261235dfc453">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e842b7a6-fa09-4e53-af3a-261235dfc453">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e842b7a6-fa09-4e53-af3a-261235dfc453">
											<gml:posList>35.67032163883083 139.74362349626878 24.1 35.67031903511561 139.74362517821226 24.1 35.67026724232136 139.74383123756962 24.1 35.67026861478018 139.74383442840218 24.1 35.67032163883083 139.74362349626878 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bbf1b7cc-b699-4e58-ac71-7db74e6a1614">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bbf1b7cc-b699-4e58-ac71-7db74e6a1614">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bbf1b7cc-b699-4e58-ac71-7db74e6a1614">
											<gml:posList>35.67028050661896 139.74360796708416 24.1 35.67028187006172 139.74361114687727 24.1 35.67031903511561 139.74362517821226 24.1 35.67032163883083 139.74362349626878 24.1 35.67028050661896 139.74360796708416 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4eb5106c-7d8a-48f1-a9fc-901a151c4904">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4eb5106c-7d8a-48f1-a9fc-901a151c4904">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4eb5106c-7d8a-48f1-a9fc-901a151c4904">
											<gml:posList>35.67023005930466 139.74381726139936 24.1 35.67023005930466 139.74381726139936 23.207 35.67028187006172 139.74361114687727 23.207 35.67028187006172 139.74361114687727 24.1 35.67023005930466 139.74381726139936 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cebcc944-f155-4a36-bfce-7a7a1cc7c757">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cebcc944-f155-4a36-bfce-7a7a1cc7c757">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cebcc944-f155-4a36-bfce-7a7a1cc7c757">
											<gml:posList>35.67031903511561 139.74362517821226 24.1 35.67031903511561 139.74362517821226 23.207 35.67026724232136 139.74383123756962 23.207 35.67026724232136 139.74383123756962 24.1 35.67031903511561 139.74362517821226 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cd84acc2-6321-4aa5-8c4e-e0278e504ed2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd84acc2-6321-4aa5-8c4e-e0278e504ed2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd84acc2-6321-4aa5-8c4e-e0278e504ed2">
											<gml:posList>35.6702335498928 139.74359023518673 7.72 35.6702335498928 139.74359023518673 15.3 35.6702646650369 139.74360198670175 15.3 35.6702646650369 139.74360198670175 21.886 35.67028050661896 139.74360796708416 21.886 35.67028050661896 139.74360796708416 24.1 35.67032163883083 139.74362349626878 24.1 35.67032163883083 139.74362349626878 7.72 35.6702335498928 139.74359023518673 7.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-92c2f0d8-2ef1-4f28-b856-2673c3d34556">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-92c2f0d8-2ef1-4f28-b856-2673c3d34556">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-92c2f0d8-2ef1-4f28-b856-2673c3d34556">
											<gml:posList>35.67028187006172 139.74361114687727 24.1 35.67028187006172 139.74361114687727 23.207 35.67031903511561 139.74362517821226 23.207 35.67031903511561 139.74362517821226 24.1 35.67028187006172 139.74361114687727 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6a75893b-e9ff-4cad-8105-165bf43de70c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a75893b-e9ff-4cad-8105-165bf43de70c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a75893b-e9ff-4cad-8105-165bf43de70c">
											<gml:posList>35.6702335498928 139.74359023518673 7.72 35.67018052598145 139.74380127757235 7.72 35.67018052598145 139.74380127757235 15.3 35.6702335498928 139.74359023518673 15.3 35.6702335498928 139.74359023518673 7.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2eaed7bf-92bd-4efe-a542-2b9f09200610">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2eaed7bf-92bd-4efe-a542-2b9f09200610">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2eaed7bf-92bd-4efe-a542-2b9f09200610">
											<gml:posList>35.67021161402311 139.74381297396064 15.3 35.67021161402311 139.74381297396064 21.886 35.6702646650369 139.74360198670175 21.886 35.6702646650369 139.74360198670175 15.3 35.67021161402311 139.74381297396064 15.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e21d8b00-de8f-42f1-8974-65f9e0ebaad1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e21d8b00-de8f-42f1-8974-65f9e0ebaad1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e21d8b00-de8f-42f1-8974-65f9e0ebaad1">
											<gml:posList>35.6702274646004 139.74381894332456 21.886 35.6702274646004 139.74381894332456 24.1 35.67028050661896 139.74360796708416 24.1 35.67028050661896 139.74360796708416 21.886 35.6702274646004 139.74381894332456 21.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-49706d0e-ba11-409f-b0b7-925e63e70b2e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-49706d0e-ba11-409f-b0b7-925e63e70b2e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-49706d0e-ba11-409f-b0b7-925e63e70b2e">
											<gml:posList>35.67026861478018 139.74383442840218 7.72 35.67032163883083 139.74362349626878 7.72 35.67032163883083 139.74362349626878 24.1 35.67026861478018 139.74383442840218 24.1 35.67026861478018 139.74383442840218 7.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9c448ef3-dac2-441b-a376-f03230ec6a68">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c448ef3-dac2-441b-a376-f03230ec6a68">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c448ef3-dac2-441b-a376-f03230ec6a68">
											<gml:posList>35.67018052598145 139.74380127757235 7.72 35.67026861478018 139.74383442840218 7.72 35.67026861478018 139.74383442840218 24.1 35.6702274646004 139.74381894332456 24.1 35.6702274646004 139.74381894332456 21.886 35.67021161402311 139.74381297396064 21.886 35.67021161402311 139.74381297396064 15.3 35.67018052598145 139.74380127757235 15.3 35.67018052598145 139.74380127757235 7.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a5182367-be89-4fc9-99c9-1349a2c4c9bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5182367-be89-4fc9-99c9-1349a2c4c9bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5182367-be89-4fc9-99c9-1349a2c4c9bf">
											<gml:posList>35.67026724232136 139.74383123756962 24.1 35.67026724232136 139.74383123756962 23.207 35.67023005930466 139.74381726139936 23.207 35.67023005930466 139.74381726139936 24.1 35.67026724232136 139.74383123756962 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1553</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">204.34665</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>