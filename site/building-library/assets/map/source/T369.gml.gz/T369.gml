<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_69f98dff-33c2-41d8-82d0-80c5936412a4">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">14.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66925962884354 139.73827388491384 0 35.66926010498891 139.73826046333187 0 35.6692553911817 139.73824952223188 0 35.66919414061056 139.73818960352042 0 35.66912789786574 139.73829128403005 0 35.66915021507095 139.7383131177882 0 35.669138016248 139.73833185536398 0 35.669189235736305 139.7383819549954 0 35.66925962884354 139.73827388491384 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66925962884354 139.73827388491384 17.963 35.669189235736305 139.7383819549954 17.963 35.669138016248 139.73833185536398 17.963 35.66915021507095 139.7383131177882 17.963 35.66912789786574 139.73829128403005 17.963 35.66919414061056 139.73818960352042 17.963 35.6692553911817 139.73824952223188 17.963 35.66926010498891 139.73826046333187 17.963 35.66925962884354 139.73827388491384 17.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66925962884354 139.73827388491384 17.963 35.66926010498891 139.73826046333187 17.963 35.66926010498891 139.73826046333187 32.76 35.66925962884354 139.73827388491384 32.76 35.66925962884354 139.73827388491384 17.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66926010498891 139.73826046333187 17.963 35.6692553911817 139.73824952223188 17.963 35.6692553911817 139.73824952223188 32.76 35.66926010498891 139.73826046333187 32.76 35.66926010498891 139.73826046333187 17.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6692553911817 139.73824952223188 17.963 35.66919414061056 139.73818960352042 17.963 35.66919414061056 139.73818960352042 32.76 35.6692553911817 139.73824952223188 32.76 35.6692553911817 139.73824952223188 17.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66919414061056 139.73818960352042 17.963 35.66912789786574 139.73829128403005 17.963 35.66912789786574 139.73829128403005 32.76 35.66919414061056 139.73818960352042 32.76 35.66919414061056 139.73818960352042 17.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66912789786574 139.73829128403005 17.963 35.66915021507095 139.7383131177882 17.963 35.66915021507095 139.7383131177882 32.76 35.66912789786574 139.73829128403005 32.76 35.66912789786574 139.73829128403005 17.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66915021507095 139.7383131177882 17.963 35.669138016248 139.73833185536398 17.963 35.669138016248 139.73833185536398 32.76 35.66915021507095 139.7383131177882 32.76 35.66915021507095 139.7383131177882 17.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669138016248 139.73833185536398 17.963 35.669189235736305 139.7383819549954 17.963 35.669189235736305 139.7383819549954 32.76 35.669138016248 139.73833185536398 32.76 35.669138016248 139.73833185536398 17.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669189235736305 139.7383819549954 17.963 35.66925962884354 139.73827388491384 17.963 35.66925962884354 139.73827388491384 32.76 35.669189235736305 139.7383819549954 32.76 35.669189235736305 139.7383819549954 17.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66925962884354 139.73827388491384 32.76 35.66926010498891 139.73826046333187 32.76 35.6692553911817 139.73824952223188 32.76 35.66919414061056 139.73818960352042 32.76 35.66912789786574 139.73829128403005 32.76 35.66915021507095 139.7383131177882 32.76 35.669138016248 139.73833185536398 32.76 35.669189235736305 139.7383819549954 32.76 35.66925962884354 139.73827388491384 32.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-26e14111-06b6-4fb9-9d21-390d7e120f3c"/>
							<gml:surfaceMember xlink:href="#poly-47759228-ae3e-4f49-a009-3155992ac46b"/>
							<gml:surfaceMember xlink:href="#poly-9b866ccf-88db-4795-978b-cc1ffdc48255"/>
							<gml:surfaceMember xlink:href="#poly-c2aee1c5-ee1d-4e55-81e8-2e5b78cc4f56"/>
							<gml:surfaceMember xlink:href="#poly-8c6755b4-edcd-498a-b6f0-f8c7eae34e30"/>
							<gml:surfaceMember xlink:href="#poly-2d2474a5-465b-4248-aa1e-19ed0f361b43"/>
							<gml:surfaceMember xlink:href="#poly-14200d72-208a-4e10-8510-bddfdec8d382"/>
							<gml:surfaceMember xlink:href="#poly-72ccbc2e-de4d-479e-a7f0-04dfa6fc2abd"/>
							<gml:surfaceMember xlink:href="#poly-cbf50315-c3e2-4dde-914f-f4225b1216ce"/>
							<gml:surfaceMember xlink:href="#poly-299e9b21-43ca-40e6-a90f-e010086dda5f"/>
							<gml:surfaceMember xlink:href="#poly-1070b2d7-104d-4c8a-b4dc-8c78849dbaa5"/>
							<gml:surfaceMember xlink:href="#poly-f8ddcc34-2db6-4ab6-9177-00f8575c286a"/>
							<gml:surfaceMember xlink:href="#poly-fb9af26c-1106-46f5-a7b2-63aa6b676774"/>
							<gml:surfaceMember xlink:href="#poly-d5afcd9b-996d-4eba-930c-249f7cddd7aa"/>
							<gml:surfaceMember xlink:href="#poly-3fc6e353-af36-4628-9b6b-4c4480617e9a"/>
							<gml:surfaceMember xlink:href="#poly-3e6bf5ec-a767-4b08-b903-008077252629"/>
							<gml:surfaceMember xlink:href="#poly-fba59237-6189-4d49-9c91-0faeb4e1a33c"/>
							<gml:surfaceMember xlink:href="#poly-3a3217f4-c10d-4161-9936-9e74187eb1f9"/>
							<gml:surfaceMember xlink:href="#poly-114cd8c2-e419-4f64-95f2-a2751ce7d267"/>
							<gml:surfaceMember xlink:href="#poly-ea023d71-660d-47ba-8422-c01052432ba1"/>
							<gml:surfaceMember xlink:href="#poly-e94edf2f-a3f2-4af8-924a-6bd41284184c"/>
							<gml:surfaceMember xlink:href="#poly-968e499e-e6f6-4721-909f-febd3784928c"/>
							<gml:surfaceMember xlink:href="#poly-74719435-2e7f-494d-9b1a-08821b473d9a"/>
							<gml:surfaceMember xlink:href="#poly-414f9a49-246b-4b39-ad15-494b35a4f191"/>
							<gml:surfaceMember xlink:href="#poly-07ad6053-d1ac-469c-ae54-eabd54ee7c61"/>
							<gml:surfaceMember xlink:href="#poly-1144f0ea-c359-4da1-82e7-ee6df40d7167"/>
							<gml:surfaceMember xlink:href="#poly-478ba380-7070-4c64-af8c-2f9c0c717560"/>
							<gml:surfaceMember xlink:href="#poly-7159d877-5aab-4fe1-9df9-4531692381c4"/>
							<gml:surfaceMember xlink:href="#poly-b600fa60-8f02-4e11-af9f-5f0dec956efd"/>
							<gml:surfaceMember xlink:href="#poly-f4beeefc-bb70-4ec1-bca3-13b6187f4620"/>
							<gml:surfaceMember xlink:href="#poly-8c75bdee-7d02-4047-bbd9-2017423c4564"/>
							<gml:surfaceMember xlink:href="#poly-b27f6571-767b-4eac-8ee3-579710e7ca0f"/>
							<gml:surfaceMember xlink:href="#poly-d7651c79-4a95-41a1-acec-5bd207e8dce0"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_69f98dff-33c2-41d8-82d0-80c5936412a4_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-96cb98de-9fd0-459e-9734-570721753310">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66913801624798 139.73833185536398 17.963 35.66911569904616 139.7383100216039 17.963 35.669127897865756 139.73829128403005 17.963 35.669150215070935 139.7383131177882 17.963 35.6691388715147 139.73833053986613 17.963 35.66913801624798 139.73833185536398 17.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04a4de4c-4950-4bc7-8d17-9253e235d721">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-04a4de4c-4950-4bc7-8d17-9253e235d721_0">
											<gml:posList>35.669127897865756 139.73829128403005 17.963 35.66911569904616 139.7383100216039 17.963 35.66911569904616 139.7383100216039 36.768 35.669127897865756 139.73829128403005 36.768 35.669127897865756 139.73829128403005 17.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e133d97-27a8-435c-8ff6-715de905d640">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6e133d97-27a8-435c-8ff6-715de905d640_0">
											<gml:posList>35.66911569904616 139.7383100216039 17.963 35.66913801624798 139.73833185536398 17.963 35.66913801624798 139.73833185536398 36.768 35.66911569904616 139.7383100216039 36.768 35.66911569904616 139.7383100216039 17.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ecfd1177-6df9-4a47-a352-9a166310818c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ecfd1177-6df9-4a47-a352-9a166310818c_0">
											<gml:posList>35.6691388715147 139.73833053986613 36.768 35.669150215070935 139.7383131177882 36.768 35.669127897865756 139.73829128403005 36.768 35.66911569904616 139.7383100216039 36.768 35.66913801624798 139.73833185536398 36.768 35.6691388715147 139.73833053986613 36.768</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-183d3eaf-abc6-4a7f-8fc1-e1cd05ed118e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-183d3eaf-abc6-4a7f-8fc1-e1cd05ed118e_0">
											<gml:posList>35.66913801624798 139.73833185536398 17.963 35.6691388715147 139.73833053986613 17.963 35.6691388715147 139.73833053986613 36.768 35.66913801624798 139.73833185536398 36.768 35.66913801624798 139.73833185536398 17.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29bf07e1-14eb-43b9-9533-272f13727320">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29bf07e1-14eb-43b9-9533-272f13727320_0">
											<gml:posList>35.669150215070935 139.7383131177882 36.768 35.669150215070935 139.7383131177882 17.963 35.669127897865756 139.73829128403005 17.963 35.669127897865756 139.73829128403005 36.768 35.669150215070935 139.7383131177882 36.768</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9752154f-f425-4f6e-b0bb-c446aa90acb2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9752154f-f425-4f6e-b0bb-c446aa90acb2_0">
											<gml:posList>35.6691388715147 139.73833053986613 17.963 35.669150215070935 139.7383131177882 17.963 35.669150215070935 139.7383131177882 36.768 35.6691388715147 139.73833053986613 36.768 35.6691388715147 139.73833053986613 17.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_69f98dff-33c2-41d8-82d0-80c5936412a4_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-233c6ce9-6835-46a5-a3f5-477816fae872">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66915071491029 139.7382726111844 40.033 35.669159925406376 139.73825924554055 40.033 35.66917461174877 139.7382744275505 40.033 35.66916540125974 139.73828780424117 40.033 35.66915071491029 139.7382726111844 40.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da130961-fe6b-4a36-8d10-e03f98f3328e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da130961-fe6b-4a36-8d10-e03f98f3328e_0">
											<gml:posList>35.66915071491029 139.7382726111844 40.033 35.66915071491029 139.7382726111844 40.41 35.669159925406376 139.73825924554055 40.41 35.669159925406376 139.73825924554055 40.033 35.66915071491029 139.7382726111844 40.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-927f22b6-17a3-4821-9fd5-f83266678666">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-927f22b6-17a3-4821-9fd5-f83266678666_0">
											<gml:posList>35.669159925406376 139.73825924554055 40.033 35.669159925406376 139.73825924554055 40.41 35.66917461174877 139.7382744275505 40.41 35.66917461174877 139.7382744275505 40.033 35.669159925406376 139.73825924554055 40.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a916a66-5bb8-4b38-b917-80a8ed15e487">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3a916a66-5bb8-4b38-b917-80a8ed15e487_0">
											<gml:posList>35.66917461174877 139.7382744275505 40.41 35.669159925406376 139.73825924554055 40.41 35.66915071491029 139.7382726111844 40.41 35.66916540125974 139.73828780424117 40.41 35.66917461174877 139.7382744275505 40.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0893477-e949-4d2d-99ab-d3bbebaf6fae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0893477-e949-4d2d-99ab-d3bbebaf6fae_0">
											<gml:posList>35.66916540125974 139.73828780424117 40.033 35.66916540125974 139.73828780424117 40.41 35.66915071491029 139.7382726111844 40.41 35.66915071491029 139.7382726111844 40.033 35.66916540125974 139.73828780424117 40.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2543ba68-56de-438c-a8ca-5f628c9c2dde">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2543ba68-56de-438c-a8ca-5f628c9c2dde_0">
											<gml:posList>35.66917461174877 139.7382744275505 40.41 35.66916540125974 139.73828780424117 40.41 35.66916540125974 139.73828780424117 40.033 35.66917461174877 139.7382744275505 40.033 35.66917461174877 139.7382744275505 40.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-26e14111-06b6-4fb9-9d21-390d7e120f3c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26e14111-06b6-4fb9-9d21-390d7e120f3c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26e14111-06b6-4fb9-9d21-390d7e120f3c">
											<gml:posList>35.669150215070935 139.7383131177882 17.963 35.669127897865756 139.73829128403005 17.963 35.669194140610536 139.7381896035204 17.963 35.66925539118168 139.73824952223188 17.963 35.66926010498889 139.73826046333187 17.963 35.66925962884355 139.73827388491384 17.963 35.66918923573629 139.73838195499536 17.963 35.66913801624798 139.73833185536398 17.963 35.669150215070935 139.7383131177882 17.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-47759228-ae3e-4f49-a009-3155992ac46b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47759228-ae3e-4f49-a009-3155992ac46b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47759228-ae3e-4f49-a009-3155992ac46b">
											<gml:posList>35.669233862733364 139.73825630797572 31.598 35.66925539118168 139.73824952223188 31.598 35.669194140610536 139.7381896035204 31.598 35.66918310315495 139.73820653923403 31.598 35.669233862733364 139.73825630797572 31.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9b866ccf-88db-4795-978b-cc1ffdc48255">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b866ccf-88db-4795-978b-cc1ffdc48255">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b866ccf-88db-4795-978b-cc1ffdc48255">
											<gml:posList>35.66918310315495 139.73820653923403 31.598 35.6691595427865 139.73824270999594 41.175 35.66918790414004 139.7382707997186 41.175 35.669233862733364 139.73825630797572 31.598 35.66918310315495 139.73820653923403 31.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c2aee1c5-ee1d-4e55-81e8-2e5b78cc4f56">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c2aee1c5-ee1d-4e55-81e8-2e5b78cc4f56">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c2aee1c5-ee1d-4e55-81e8-2e5b78cc4f56">
											<gml:posList>35.66918790414004 139.7382707997186 41.175 35.6691595427865 139.73824270999594 41.175 35.669159688305804 139.73824435569094 41.175 35.66918693108515 139.7382713421309 41.175 35.66918790414004 139.7382707997186 41.175</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8c6755b4-edcd-498a-b6f0-f8c7eae34e30">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c6755b4-edcd-498a-b6f0-f8c7eae34e30">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c6755b4-edcd-498a-b6f0-f8c7eae34e30">
											<gml:posList>35.669237033239725 139.73826477657622 31.598 35.66926010498889 139.73826046333187 31.598 35.66925539118168 139.73824952223188 31.598 35.669233862733364 139.73825630797572 31.598 35.669237033239725 139.73826477657622 31.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2d2474a5-465b-4248-aa1e-19ed0f361b43">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d2474a5-465b-4248-aa1e-19ed0f361b43">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d2474a5-465b-4248-aa1e-19ed0f361b43">
											<gml:posList>35.669233862733364 139.73825630797572 31.598 35.66918790414004 139.7382707997186 41.175 35.669187762431896 139.73827398116197 41.175 35.669233862733364 139.73825630797572 31.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-14200d72-208a-4e10-8510-bddfdec8d382">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-14200d72-208a-4e10-8510-bddfdec8d382">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-14200d72-208a-4e10-8510-bddfdec8d382">
											<gml:posList>35.669187762431896 139.73827398116197 41.175 35.669237033239725 139.73826477657622 31.598 35.669233862733364 139.73825630797572 31.598 35.669187762431896 139.73827398116197 41.175</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-72ccbc2e-de4d-479e-a7f0-04dfa6fc2abd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-72ccbc2e-de4d-479e-a7f0-04dfa6fc2abd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-72ccbc2e-de4d-479e-a7f0-04dfa6fc2abd">
											<gml:posList>35.669127897865756 139.73829128403005 41.175 35.669129240771134 139.73829110570088 41.175 35.669159688305804 139.73824435569094 41.175 35.6691595427865 139.73824270999594 41.175 35.669127897865756 139.73829128403005 41.175</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cbf50315-c3e2-4dde-914f-f4225b1216ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cbf50315-c3e2-4dde-914f-f4225b1216ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cbf50315-c3e2-4dde-914f-f4225b1216ce">
											<gml:posList>35.66925962884355 139.73827388491384 31.598 35.66926010498889 139.73826046333187 31.598 35.669237033239725 139.73826477657622 31.598 35.66923666267749 139.73827492838302 31.598 35.66925962884355 139.73827388491384 31.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-299e9b21-43ca-40e6-a90f-e010086dda5f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-299e9b21-43ca-40e6-a90f-e010086dda5f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-299e9b21-43ca-40e6-a90f-e010086dda5f">
											<gml:posList>35.669187762431896 139.73827398116197 41.175 35.66918762972868 139.73827715154854 41.175 35.66923666267749 139.73827492838302 31.598 35.669237033239725 139.73826477657622 31.598 35.669187762431896 139.73827398116197 41.175</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1070b2d7-104d-4c8a-b4dc-8c78849dbaa5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1070b2d7-104d-4c8a-b4dc-8c78849dbaa5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1070b2d7-104d-4c8a-b4dc-8c78849dbaa5">
											<gml:posList>35.66918693108515 139.7382713421309 41.175 35.66918670097504 139.7382767218519 41.175 35.66918762972868 139.73827715154854 41.175 35.669187762431896 139.73827398116197 41.175 35.66918790414004 139.7382707997186 41.175 35.66918693108515 139.7382713421309 41.175</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f8ddcc34-2db6-4ab6-9177-00f8575c286a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f8ddcc34-2db6-4ab6-9177-00f8575c286a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f8ddcc34-2db6-4ab6-9177-00f8575c286a">
											<gml:posList>35.66914642234588 139.7383385724725 40.033 35.66918670097504 139.7382767218519 40.033 35.66918693108515 139.7382713421309 40.033 35.669159688305804 139.73824435569094 40.033 35.669129240771134 139.73829110570088 40.033 35.66915155796762 139.73831292841325 40.033 35.6691393591447 139.73833166598934 40.033 35.66914642234588 139.7383385724725 40.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fb9af26c-1106-46f5-a7b2-63aa6b676774">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb9af26c-1106-46f5-a7b2-63aa6b676774">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb9af26c-1106-46f5-a7b2-63aa6b676774">
											<gml:posList>35.669150215070935 139.7383131177882 41.175 35.66915155796762 139.73831292841325 41.175 35.669129240771134 139.73829110570088 41.175 35.669127897865756 139.73829128403005 41.175 35.669150215070935 139.7383131177882 41.175</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d5afcd9b-996d-4eba-930c-249f7cddd7aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5afcd9b-996d-4eba-930c-249f7cddd7aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5afcd9b-996d-4eba-930c-249f7cddd7aa">
											<gml:posList>35.66918762972868 139.73827715154854 41.175 35.66918670097504 139.7382767218519 41.175 35.66914642234588 139.7383385724725 41.175 35.66914655884144 139.73834020713198 41.175 35.66918762972868 139.73827715154854 41.175</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3fc6e353-af36-4628-9b6b-4c4480617e9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3fc6e353-af36-4628-9b6b-4c4480617e9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3fc6e353-af36-4628-9b6b-4c4480617e9a">
											<gml:posList>35.66918762972868 139.73827715154854 41.175 35.66914655884144 139.73834020713198 41.175 35.66917562351286 139.73836863848052 31.598 35.66923666267749 139.73827492838302 31.598 35.66918762972868 139.73827715154854 41.175</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3e6bf5ec-a767-4b08-b903-008077252629">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e6bf5ec-a767-4b08-b903-008077252629">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e6bf5ec-a767-4b08-b903-008077252629">
											<gml:posList>35.669150215070935 139.7383131177882 41.175 35.66913801624798 139.73833185536398 41.175 35.6691393591447 139.73833166598934 41.175 35.66915155796762 139.73831292841325 41.175 35.669150215070935 139.7383131177882 41.175</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fba59237-6189-4d49-9c91-0faeb4e1a33c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fba59237-6189-4d49-9c91-0faeb4e1a33c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fba59237-6189-4d49-9c91-0faeb4e1a33c">
											<gml:posList>35.66918923573629 139.73838195499536 31.598 35.66925962884355 139.73827388491384 31.598 35.66923666267749 139.73827492838302 31.598 35.66917562351286 139.73836863848052 31.598 35.66918923573629 139.73838195499536 31.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3a3217f4-c10d-4161-9936-9e74187eb1f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a3217f4-c10d-4161-9936-9e74187eb1f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a3217f4-c10d-4161-9936-9e74187eb1f9">
											<gml:posList>35.66914655884144 139.73834020713198 41.175 35.66914642234588 139.7383385724725 41.175 35.6691393591447 139.73833166598934 41.175 35.66913801624798 139.73833185536398 41.175 35.66914655884144 139.73834020713198 41.175</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-114cd8c2-e419-4f64-95f2-a2751ce7d267">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-114cd8c2-e419-4f64-95f2-a2751ce7d267">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-114cd8c2-e419-4f64-95f2-a2751ce7d267">
											<gml:posList>35.66918693108515 139.7382713421309 41.175 35.66918693108515 139.7382713421309 40.033 35.66918670097504 139.7382767218519 40.033 35.66918670097504 139.7382767218519 41.175 35.66918693108515 139.7382713421309 41.175</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ea023d71-660d-47ba-8422-c01052432ba1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea023d71-660d-47ba-8422-c01052432ba1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea023d71-660d-47ba-8422-c01052432ba1">
											<gml:posList>35.66918670097504 139.7382767218519 41.175 35.66918670097504 139.7382767218519 40.033 35.66914642234588 139.7383385724725 40.033 35.66914642234588 139.7383385724725 41.175 35.66918670097504 139.7382767218519 41.175</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e94edf2f-a3f2-4af8-924a-6bd41284184c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e94edf2f-a3f2-4af8-924a-6bd41284184c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e94edf2f-a3f2-4af8-924a-6bd41284184c">
											<gml:posList>35.66925539118168 139.73824952223188 17.963 35.669194140610536 139.7381896035204 17.963 35.669194140610536 139.7381896035204 31.598 35.66925539118168 139.73824952223188 31.598 35.66925539118168 139.73824952223188 17.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-968e499e-e6f6-4721-909f-febd3784928c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-968e499e-e6f6-4721-909f-febd3784928c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-968e499e-e6f6-4721-909f-febd3784928c">
											<gml:posList>35.669127897865756 139.73829128403005 17.963 35.669127897865756 139.73829128403005 41.175 35.6691595427865 139.73824270999594 41.175 35.66918310315495 139.73820653923403 31.598 35.669194140610536 139.7381896035204 31.598 35.669194140610536 139.7381896035204 17.963 35.669127897865756 139.73829128403005 17.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-74719435-2e7f-494d-9b1a-08821b473d9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74719435-2e7f-494d-9b1a-08821b473d9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74719435-2e7f-494d-9b1a-08821b473d9a">
											<gml:posList>35.66926010498889 139.73826046333187 17.963 35.66925539118168 139.73824952223188 17.963 35.66925539118168 139.73824952223188 31.598 35.66926010498889 139.73826046333187 31.598 35.66926010498889 139.73826046333187 17.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-414f9a49-246b-4b39-ad15-494b35a4f191">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-414f9a49-246b-4b39-ad15-494b35a4f191">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-414f9a49-246b-4b39-ad15-494b35a4f191">
											<gml:posList>35.669159688305804 139.73824435569094 41.175 35.669159688305804 139.73824435569094 40.033 35.66918693108515 139.7382713421309 40.033 35.66918693108515 139.7382713421309 41.175 35.669159688305804 139.73824435569094 41.175</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-07ad6053-d1ac-469c-ae54-eabd54ee7c61">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-07ad6053-d1ac-469c-ae54-eabd54ee7c61">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-07ad6053-d1ac-469c-ae54-eabd54ee7c61">
											<gml:posList>35.66925962884355 139.73827388491384 17.963 35.66926010498889 139.73826046333187 17.963 35.66926010498889 139.73826046333187 31.598 35.66925962884355 139.73827388491384 31.598 35.66925962884355 139.73827388491384 17.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1144f0ea-c359-4da1-82e7-ee6df40d7167">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1144f0ea-c359-4da1-82e7-ee6df40d7167">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1144f0ea-c359-4da1-82e7-ee6df40d7167">
											<gml:posList>35.669129240771134 139.73829110570088 41.175 35.669129240771134 139.73829110570088 40.033 35.669159688305804 139.73824435569094 40.033 35.669159688305804 139.73824435569094 41.175 35.669129240771134 139.73829110570088 41.175</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-478ba380-7070-4c64-af8c-2f9c0c717560">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-478ba380-7070-4c64-af8c-2f9c0c717560">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-478ba380-7070-4c64-af8c-2f9c0c717560">
											<gml:posList>35.66915155796762 139.73831292841325 41.175 35.66915155796762 139.73831292841325 40.033 35.669129240771134 139.73829110570088 40.033 35.669129240771134 139.73829110570088 41.175 35.66915155796762 139.73831292841325 41.175</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7159d877-5aab-4fe1-9df9-4531692381c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7159d877-5aab-4fe1-9df9-4531692381c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7159d877-5aab-4fe1-9df9-4531692381c4">
											<gml:posList>35.669127897865756 139.73829128403005 41.175 35.669127897865756 139.73829128403005 17.963 35.669150215070935 139.7383131177882 17.963 35.669150215070935 139.7383131177882 41.175 35.669127897865756 139.73829128403005 41.175</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b600fa60-8f02-4e11-af9f-5f0dec956efd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b600fa60-8f02-4e11-af9f-5f0dec956efd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b600fa60-8f02-4e11-af9f-5f0dec956efd">
											<gml:posList>35.6691393591447 139.73833166598934 41.175 35.6691393591447 139.73833166598934 40.033 35.66915155796762 139.73831292841325 40.033 35.66915155796762 139.73831292841325 41.175 35.6691393591447 139.73833166598934 41.175</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f4beeefc-bb70-4ec1-bca3-13b6187f4620">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4beeefc-bb70-4ec1-bca3-13b6187f4620">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4beeefc-bb70-4ec1-bca3-13b6187f4620">
											<gml:posList>35.669150215070935 139.7383131177882 41.175 35.669150215070935 139.7383131177882 17.963 35.66913801624798 139.73833185536398 17.963 35.66913801624798 139.73833185536398 41.175 35.669150215070935 139.7383131177882 41.175</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8c75bdee-7d02-4047-bbd9-2017423c4564">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c75bdee-7d02-4047-bbd9-2017423c4564">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c75bdee-7d02-4047-bbd9-2017423c4564">
											<gml:posList>35.66918923573629 139.73838195499536 17.963 35.66925962884355 139.73827388491384 17.963 35.66925962884355 139.73827388491384 31.598 35.66918923573629 139.73838195499536 31.598 35.66918923573629 139.73838195499536 17.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b27f6571-767b-4eac-8ee3-579710e7ca0f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b27f6571-767b-4eac-8ee3-579710e7ca0f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b27f6571-767b-4eac-8ee3-579710e7ca0f">
											<gml:posList>35.66914642234588 139.7383385724725 41.175 35.66914642234588 139.7383385724725 40.033 35.6691393591447 139.73833166598934 40.033 35.6691393591447 139.73833166598934 41.175 35.66914642234588 139.7383385724725 41.175</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d7651c79-4a95-41a1-acec-5bd207e8dce0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7651c79-4a95-41a1-acec-5bd207e8dce0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7651c79-4a95-41a1-acec-5bd207e8dce0">
											<gml:posList>35.66913801624798 139.73833185536398 41.175 35.66913801624798 139.73833185536398 17.963 35.66918923573629 139.73838195499536 17.963 35.66918923573629 139.73838195499536 31.598 35.66917562351286 139.73836863848052 31.598 35.66914655884144 139.73834020713198 41.175 35.66913801624798 139.73833185536398 41.175</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10296</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">174.82195</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>