<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_6afc9fc8-11ac-4e97-b0a6-556e948b3f73">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">7.8</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67358314370242 139.74768969449192 0 35.67358942992641 139.74769483553965 0 35.6735957161423 139.74769996554144 0 35.673637773292135 139.74762269307453 0 35.673631487065165 139.74761755202942 0 35.67362520083794 139.74761241098508 0 35.67361541571867 139.7476303944385 0 35.67360502585909 139.74762189958327 0 35.67357274483328 139.74768119964205 0 35.67358314370242 139.74768969449192 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67358314370242 139.74768969449192 18 35.67357274483328 139.74768119964205 18 35.67360502585909 139.74762189958327 18 35.67361541571867 139.7476303944385 18 35.67362520083794 139.74761241098508 18 35.673631487065165 139.74761755202942 18 35.673637773292135 139.74762269307453 18 35.6735957161423 139.74769996554144 18 35.67358942992641 139.74769483553965 18 35.67358314370242 139.74768969449192 18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67358314370242 139.74768969449192 18 35.67358942992641 139.74769483553965 18 35.67358942992641 139.74769483553965 24.77 35.67358314370242 139.74768969449192 24.77 35.67358314370242 139.74768969449192 18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67358942992641 139.74769483553965 18 35.6735957161423 139.74769996554144 18 35.6735957161423 139.74769996554144 24.77 35.67358942992641 139.74769483553965 24.77 35.67358942992641 139.74769483553965 18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6735957161423 139.74769996554144 18 35.673637773292135 139.74762269307453 18 35.673637773292135 139.74762269307453 24.77 35.6735957161423 139.74769996554144 24.77 35.6735957161423 139.74769996554144 18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673637773292135 139.74762269307453 18 35.673631487065165 139.74761755202942 18 35.673631487065165 139.74761755202942 24.77 35.673637773292135 139.74762269307453 24.77 35.673637773292135 139.74762269307453 18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673631487065165 139.74761755202942 18 35.67362520083794 139.74761241098508 18 35.67362520083794 139.74761241098508 24.77 35.673631487065165 139.74761755202942 24.77 35.673631487065165 139.74761755202942 18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67362520083794 139.74761241098508 18 35.67361541571867 139.7476303944385 18 35.67361541571867 139.7476303944385 24.77 35.67362520083794 139.74761241098508 24.77 35.67362520083794 139.74761241098508 18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67361541571867 139.7476303944385 18 35.67360502585909 139.74762189958327 18 35.67360502585909 139.74762189958327 24.77 35.67361541571867 139.7476303944385 24.77 35.67361541571867 139.7476303944385 18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67360502585909 139.74762189958327 18 35.67357274483328 139.74768119964205 18 35.67357274483328 139.74768119964205 24.77 35.67360502585909 139.74762189958327 24.77 35.67360502585909 139.74762189958327 18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67357274483328 139.74768119964205 18 35.67358314370242 139.74768969449192 18 35.67358314370242 139.74768969449192 24.77 35.67357274483328 139.74768119964205 24.77 35.67357274483328 139.74768119964205 18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67358314370242 139.74768969449192 24.77 35.67358942992641 139.74769483553965 24.77 35.6735957161423 139.74769996554144 24.77 35.673637773292135 139.74762269307453 24.77 35.673631487065165 139.74761755202942 24.77 35.67362520083794 139.74761241098508 24.77 35.67361541571867 139.7476303944385 24.77 35.67360502585909 139.74762189958327 24.77 35.67357274483328 139.74768119964205 24.77 35.67358314370242 139.74768969449192 24.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-81249419-18b6-46f0-bf20-321cebcf2fd3"/>
							<gml:surfaceMember xlink:href="#poly-a67c7bf5-6b32-4bae-bfac-4e3e5509da92"/>
							<gml:surfaceMember xlink:href="#poly-ec8ae95a-4857-45d0-bde7-2217ceb341c8"/>
							<gml:surfaceMember xlink:href="#poly-53c17e61-31d9-4015-891a-7b4beb4d6bf1"/>
							<gml:surfaceMember xlink:href="#poly-780d84f1-d007-4413-a8a3-88c4b59848ec"/>
							<gml:surfaceMember xlink:href="#poly-df1d629d-a091-4f64-932c-4982d74f867c"/>
							<gml:surfaceMember xlink:href="#poly-ead273d5-a7b6-4dc3-bfd2-99c3ddf0ab19"/>
							<gml:surfaceMember xlink:href="#poly-d11c5308-840b-446f-9347-ae44970a269f"/>
							<gml:surfaceMember xlink:href="#poly-a3b7d271-af54-4e63-be0d-0c33f27702de"/>
							<gml:surfaceMember xlink:href="#poly-4b539aa4-a986-496e-a0bb-00bbca7b7794"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-81249419-18b6-46f0-bf20-321cebcf2fd3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-81249419-18b6-46f0-bf20-321cebcf2fd3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-81249419-18b6-46f0-bf20-321cebcf2fd3">
											<gml:posList>35.67357275384698 139.7476811996324 18 35.673605025859096 139.74762189958324 18 35.67361541571864 139.7476303944385 18 35.67362520083793 139.7476124109851 18 35.67363778230586 139.7476226930649 18 35.67359571614226 139.74769996554144 18 35.67357275384698 139.7476811996324 18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a67c7bf5-6b32-4bae-bfac-4e3e5509da92">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a67c7bf5-6b32-4bae-bfac-4e3e5509da92">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a67c7bf5-6b32-4bae-bfac-4e3e5509da92">
											<gml:posList>35.67363148706514 139.74761755202942 25.8 35.67362520083793 139.7476124109851 25 35.67361541571864 139.7476303944385 25 35.673583143702416 139.74768969449192 25 35.67358942992638 139.74769483553962 25.8 35.67363148706514 139.74761755202942 25.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ec8ae95a-4857-45d0-bde7-2217ceb341c8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec8ae95a-4857-45d0-bde7-2217ceb341c8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec8ae95a-4857-45d0-bde7-2217ceb341c8">
											<gml:posList>35.67361541571864 139.7476303944385 25 35.673605025859096 139.74762189958324 25 35.67357275384698 139.7476811996324 25 35.673583143702416 139.74768969449192 25 35.67361541571864 139.7476303944385 25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-53c17e61-31d9-4015-891a-7b4beb4d6bf1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-53c17e61-31d9-4015-891a-7b4beb4d6bf1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-53c17e61-31d9-4015-891a-7b4beb4d6bf1">
											<gml:posList>35.67358942992638 139.74769483553962 25.8 35.67359571614226 139.74769996554144 25 35.67363778230586 139.7476226930649 25 35.67363148706514 139.74761755202942 25.8 35.67358942992638 139.74769483553962 25.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-780d84f1-d007-4413-a8a3-88c4b59848ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-780d84f1-d007-4413-a8a3-88c4b59848ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-780d84f1-d007-4413-a8a3-88c4b59848ec">
											<gml:posList>35.67362520083793 139.7476124109851 25 35.67363148706514 139.74761755202942 25.8 35.67363778230586 139.7476226930649 25 35.67363778230586 139.7476226930649 18 35.67362520083793 139.7476124109851 18 35.67362520083793 139.7476124109851 25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-df1d629d-a091-4f64-932c-4982d74f867c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df1d629d-a091-4f64-932c-4982d74f867c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df1d629d-a091-4f64-932c-4982d74f867c">
											<gml:posList>35.67361541571864 139.7476303944385 25 35.67362520083793 139.7476124109851 25 35.67362520083793 139.7476124109851 18 35.67361541571864 139.7476303944385 18 35.67361541571864 139.7476303944385 25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ead273d5-a7b6-4dc3-bfd2-99c3ddf0ab19">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ead273d5-a7b6-4dc3-bfd2-99c3ddf0ab19">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ead273d5-a7b6-4dc3-bfd2-99c3ddf0ab19">
											<gml:posList>35.67361541571864 139.7476303944385 18 35.673605025859096 139.74762189958324 18 35.673605025859096 139.74762189958324 25 35.67361541571864 139.7476303944385 25 35.67361541571864 139.7476303944385 18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d11c5308-840b-446f-9347-ae44970a269f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d11c5308-840b-446f-9347-ae44970a269f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d11c5308-840b-446f-9347-ae44970a269f">
											<gml:posList>35.673605025859096 139.74762189958324 18 35.67357275384698 139.7476811996324 18 35.67357275384698 139.7476811996324 25 35.673605025859096 139.74762189958324 25 35.673605025859096 139.74762189958324 18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a3b7d271-af54-4e63-be0d-0c33f27702de">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a3b7d271-af54-4e63-be0d-0c33f27702de">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a3b7d271-af54-4e63-be0d-0c33f27702de">
											<gml:posList>35.67359571614226 139.74769996554144 25 35.67359571614226 139.74769996554144 18 35.67363778230586 139.7476226930649 18 35.67363778230586 139.7476226930649 25 35.67359571614226 139.74769996554144 25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4b539aa4-a986-496e-a0bb-00bbca7b7794">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b539aa4-a986-496e-a0bb-00bbca7b7794">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b539aa4-a986-496e-a0bb-00bbca7b7794">
											<gml:posList>35.67359571614226 139.74769996554144 25 35.67358942992638 139.74769483553962 25.8 35.673583143702416 139.74768969449192 25 35.67357275384698 139.7476811996324 25 35.67357275384698 139.7476811996324 18 35.67359571614226 139.74769996554144 18 35.67359571614226 139.74769996554144 25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4553</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">215</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.03</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>