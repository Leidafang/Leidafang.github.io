<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_6c0cc04b-91d3-475b-aafa-ccec305b687e">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>0.80</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>46</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13101046002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">403</bldg:usage>
			<bldg:measuredHeight uom="m">39.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>10</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67212645402601 139.74229722233866 0 35.67219277979404 139.74242017200018 0 35.67226558423864 139.74236124463278 0 35.67219878900409 139.74223737858168 0 35.67219442002392 139.74224091842902 0 35.672190069096196 139.74224449139498 0 35.67218057343263 139.74222701556195 0 35.672116525068276 139.74227889642495 0 35.67212645402601 139.74229722233866 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67212645402601 139.74229722233866 8.565 35.672116525068276 139.74227889642495 8.565 35.67218057343263 139.74222701556195 8.565 35.672190069096196 139.74224449139498 8.565 35.67219442002392 139.74224091842902 8.565 35.67219878900409 139.74223737858168 8.565 35.67226558423864 139.74236124463278 8.565 35.67219277979404 139.74242017200018 8.565 35.67212645402601 139.74229722233866 8.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67212645402601 139.74229722233866 8.565 35.67219277979404 139.74242017200018 8.565 35.67219277979404 139.74242017200018 43.21 35.67212645402601 139.74229722233866 43.21 35.67212645402601 139.74229722233866 8.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67219277979404 139.74242017200018 8.565 35.67226558423864 139.74236124463278 8.565 35.67226558423864 139.74236124463278 43.21 35.67219277979404 139.74242017200018 43.21 35.67219277979404 139.74242017200018 8.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67226558423864 139.74236124463278 8.565 35.67219878900409 139.74223737858168 8.565 35.67219878900409 139.74223737858168 43.21 35.67226558423864 139.74236124463278 43.21 35.67226558423864 139.74236124463278 8.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67219878900409 139.74223737858168 8.565 35.67219442002392 139.74224091842902 8.565 35.67219442002392 139.74224091842902 43.21 35.67219878900409 139.74223737858168 43.21 35.67219878900409 139.74223737858168 8.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67219442002392 139.74224091842902 8.565 35.672190069096196 139.74224449139498 8.565 35.672190069096196 139.74224449139498 43.21 35.67219442002392 139.74224091842902 43.21 35.67219442002392 139.74224091842902 8.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672190069096196 139.74224449139498 8.565 35.67218057343263 139.74222701556195 8.565 35.67218057343263 139.74222701556195 43.21 35.672190069096196 139.74224449139498 43.21 35.672190069096196 139.74224449139498 8.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67218057343263 139.74222701556195 8.565 35.672116525068276 139.74227889642495 8.565 35.672116525068276 139.74227889642495 43.21 35.67218057343263 139.74222701556195 43.21 35.67218057343263 139.74222701556195 8.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672116525068276 139.74227889642495 8.565 35.67212645402601 139.74229722233866 8.565 35.67212645402601 139.74229722233866 43.21 35.672116525068276 139.74227889642495 43.21 35.672116525068276 139.74227889642495 8.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67212645402601 139.74229722233866 43.21 35.67219277979404 139.74242017200018 43.21 35.67226558423864 139.74236124463278 43.21 35.67219878900409 139.74223737858168 43.21 35.67219442002392 139.74224091842902 43.21 35.672190069096196 139.74224449139498 43.21 35.67218057343263 139.74222701556195 43.21 35.672116525068276 139.74227889642495 43.21 35.67212645402601 139.74229722233866 43.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-c99a9706-66c5-4253-9bca-b9ed12469b46"/>
							<gml:surfaceMember xlink:href="#poly-90073011-2e0d-4019-8ddb-3a3cbd1ab5db"/>
							<gml:surfaceMember xlink:href="#poly-dc9aa29a-8aa8-43ad-9103-f015bf2dc04a"/>
							<gml:surfaceMember xlink:href="#poly-54a9c128-434f-43e8-8b41-72fbd366d24a"/>
							<gml:surfaceMember xlink:href="#poly-051626bb-67bc-4b7e-99b6-cf55b6f08cd5"/>
							<gml:surfaceMember xlink:href="#poly-c8999818-8e46-403d-af6b-e3552be2b9a6"/>
							<gml:surfaceMember xlink:href="#poly-de758e92-fa7f-497a-be57-eb21c9564351"/>
							<gml:surfaceMember xlink:href="#poly-e72fecc9-25a7-40b9-b849-72f8dc6c6d47"/>
							<gml:surfaceMember xlink:href="#poly-317a755a-3455-46d5-bf2d-e320c1e04593"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-c99a9706-66c5-4253-9bca-b9ed12469b46">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c99a9706-66c5-4253-9bca-b9ed12469b46">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c99a9706-66c5-4253-9bca-b9ed12469b46">
											<gml:posList>35.672265584238644 139.74236124463278 8.565 35.67219277979402 139.74242017200015 8.565 35.67211652506826 139.74227889642495 8.565 35.672180573432634 139.74222701556195 8.565 35.67219008714867 139.74224452451398 8.565 35.672198789004085 139.74223737858165 8.565 35.672265584238644 139.74236124463278 8.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-90073011-2e0d-4019-8ddb-3a3cbd1ab5db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-90073011-2e0d-4019-8ddb-3a3cbd1ab5db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-90073011-2e0d-4019-8ddb-3a3cbd1ab5db">
											<gml:posList>35.672180573432634 139.74222701556195 40.75 35.67211652506826 139.74227889642495 40.75 35.67212634571103 139.74229702362464 40.75 35.6721901232537 139.74224459075202 40.75 35.672180573432634 139.74222701556195 40.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dc9aa29a-8aa8-43ad-9103-f015bf2dc04a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc9aa29a-8aa8-43ad-9103-f015bf2dc04a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc9aa29a-8aa8-43ad-9103-f015bf2dc04a">
											<gml:posList>35.67219277979402 139.74242017200015 48.507 35.672265584238644 139.74236124463278 48.507 35.672198834131194 139.74223745585596 48.507 35.67212635473311 139.7422970346609 48.507 35.67219277979402 139.74242017200015 48.507</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-54a9c128-434f-43e8-8b41-72fbd366d24a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-54a9c128-434f-43e8-8b41-72fbd366d24a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-54a9c128-434f-43e8-8b41-72fbd366d24a">
											<gml:posList>35.672180573432634 139.74222701556195 40.75 35.6721901232537 139.74224459075202 40.75 35.67219008714867 139.74224452451398 8.565 35.672180573432634 139.74222701556195 8.565 35.672180573432634 139.74222701556195 40.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-051626bb-67bc-4b7e-99b6-cf55b6f08cd5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-051626bb-67bc-4b7e-99b6-cf55b6f08cd5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-051626bb-67bc-4b7e-99b6-cf55b6f08cd5">
											<gml:posList>35.672180573432634 139.74222701556195 40.75 35.672180573432634 139.74222701556195 8.565 35.67211652506826 139.74227889642495 8.565 35.67211652506826 139.74227889642495 40.75 35.672180573432634 139.74222701556195 40.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c8999818-8e46-403d-af6b-e3552be2b9a6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8999818-8e46-403d-af6b-e3552be2b9a6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8999818-8e46-403d-af6b-e3552be2b9a6">
											<gml:posList>35.672198834131194 139.74223745585596 48.507 35.672198789004085 139.74223737858165 8.565 35.67219008714867 139.74224452451398 8.565 35.6721901232537 139.74224459075202 40.75 35.67212634571103 139.74229702362464 40.75 35.67212635473311 139.7422970346609 48.507 35.672198834131194 139.74223745585596 48.507</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-de758e92-fa7f-497a-be57-eb21c9564351">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de758e92-fa7f-497a-be57-eb21c9564351">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de758e92-fa7f-497a-be57-eb21c9564351">
											<gml:posList>35.672198789004085 139.74223737858165 8.565 35.672198834131194 139.74223745585596 48.507 35.672265584238644 139.74236124463278 48.507 35.672265584238644 139.74236124463278 8.565 35.672198789004085 139.74223737858165 8.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e72fecc9-25a7-40b9-b849-72f8dc6c6d47">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e72fecc9-25a7-40b9-b849-72f8dc6c6d47">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e72fecc9-25a7-40b9-b849-72f8dc6c6d47">
											<gml:posList>35.67219277979402 139.74242017200015 8.565 35.67219277979402 139.74242017200015 48.507 35.67212635473311 139.7422970346609 48.507 35.67212634571103 139.74229702362464 40.75 35.67211652506826 139.74227889642495 40.75 35.67211652506826 139.74227889642495 8.565 35.67219277979402 139.74242017200015 8.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-317a755a-3455-46d5-bf2d-e320c1e04593">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-317a755a-3455-46d5-bf2d-e320c1e04593">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-317a755a-3455-46d5-bf2d-e320c1e04593">
											<gml:posList>35.672265584238644 139.74236124463278 8.565 35.672265584238644 139.74236124463278 48.507 35.67219277979402 139.74242017200015 48.507 35.67219277979402 139.74242017200015 8.565 35.672265584238644 139.74236124463278 8.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都千代田区永田町二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4496</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">166.2089</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1241</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.06</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>