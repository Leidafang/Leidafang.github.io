<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_6ebd0231-a496-40ae-bbb8-e24587374549">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">10</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67405450543149 139.73800734129182 0 35.67411007854097 139.73818269796715 0 35.67417549358842 139.7381515788672 0 35.674119920346556 139.73797611160296 0 35.67405450543149 139.73800734129182 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67405450543149 139.73800734129182 8.39 35.674119920346556 139.73797611160296 8.39 35.67417549358842 139.7381515788672 8.39 35.67411007854097 139.73818269796715 8.39 35.67405450543149 139.73800734129182 8.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67405450543149 139.73800734129182 8.39 35.67411007854097 139.73818269796715 8.39 35.67411007854097 139.73818269796715 18.38 35.67405450543149 139.73800734129182 18.38 35.67405450543149 139.73800734129182 8.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67411007854097 139.73818269796715 8.39 35.67417549358842 139.7381515788672 8.39 35.67417549358842 139.7381515788672 18.38 35.67411007854097 139.73818269796715 18.38 35.67411007854097 139.73818269796715 8.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67417549358842 139.7381515788672 8.39 35.674119920346556 139.73797611160296 8.39 35.674119920346556 139.73797611160296 18.38 35.67417549358842 139.7381515788672 18.38 35.67417549358842 139.7381515788672 8.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674119920346556 139.73797611160296 8.39 35.67405450543149 139.73800734129182 8.39 35.67405450543149 139.73800734129182 18.38 35.674119920346556 139.73797611160296 18.38 35.674119920346556 139.73797611160296 8.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67405450543149 139.73800734129182 18.38 35.67411007854097 139.73818269796715 18.38 35.67417549358842 139.7381515788672 18.38 35.674119920346556 139.73797611160296 18.38 35.67405450543149 139.73800734129182 18.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-b782f0b5-c1c2-4059-954d-ea938ab056ad"/>
							<gml:surfaceMember xlink:href="#poly-ba515928-edcf-4602-8883-cbf4f6c72512"/>
							<gml:surfaceMember xlink:href="#poly-78db084a-cb40-4a10-811b-df5b8a08a14f"/>
							<gml:surfaceMember xlink:href="#poly-0054953e-c622-42cc-ae0e-91475f69c327"/>
							<gml:surfaceMember xlink:href="#poly-d6ba53e8-c7bb-4fb8-80e1-24682c79abda"/>
							<gml:surfaceMember xlink:href="#poly-5ead93ca-b386-4c61-a78e-a9a1fa9d1465"/>
							<gml:surfaceMember xlink:href="#poly-899c17a1-32f2-4ba5-ada9-254a4c85797f"/>
							<gml:surfaceMember xlink:href="#poly-d2d3ee37-0916-46e5-8e31-e01bdce04ad1"/>
							<gml:surfaceMember xlink:href="#poly-4a92c474-3e0b-46e0-8e3e-382517318a83"/>
							<gml:surfaceMember xlink:href="#poly-f2d7a6cb-ffdf-4ab8-95dd-a146048f52e8"/>
							<gml:surfaceMember xlink:href="#poly-09eca50e-40d9-40b4-bb2a-baf28db4c1e6"/>
							<gml:surfaceMember xlink:href="#poly-9bd211e7-78fe-4ae7-8b80-9a287756a8f6"/>
							<gml:surfaceMember xlink:href="#poly-24b76592-8eda-4422-b75e-927d112e5a1a"/>
							<gml:surfaceMember xlink:href="#poly-5f51f422-37fc-45f5-bd41-0cf812032c88"/>
							<gml:surfaceMember xlink:href="#poly-dc751baa-d69f-469e-a7e5-807227cdd524"/>
							<gml:surfaceMember xlink:href="#poly-1348d186-b6a2-443b-ade6-a9dff07733d6"/>
							<gml:surfaceMember xlink:href="#poly-a7ea3509-a664-426d-bac9-32c551f44cc8"/>
							<gml:surfaceMember xlink:href="#poly-cf43bd06-ef09-4f21-8b22-ea3969407232"/>
							<gml:surfaceMember xlink:href="#poly-97c796f6-e612-4aef-ba93-651b8b6b2f75"/>
							<gml:surfaceMember xlink:href="#poly-08a22a66-7813-42a5-a1e0-4c872774a08b"/>
							<gml:surfaceMember xlink:href="#poly-19eb5ae2-fb0e-4713-8c52-577ba78821a6"/>
							<gml:surfaceMember xlink:href="#poly-a6f21795-9e6a-4bed-83e3-4f3d641d666f"/>
							<gml:surfaceMember xlink:href="#poly-1c6af1d9-dc8e-4743-8c0d-1996cba54f8c"/>
							<gml:surfaceMember xlink:href="#poly-13468cfe-cdb6-4e3d-9c39-7e63440c9712"/>
							<gml:surfaceMember xlink:href="#poly-3a2a7948-ad0b-4bd0-bbe8-07b3a5e115e6"/>
							<gml:surfaceMember xlink:href="#poly-31ad80d5-327f-4b16-a68a-54d3f79c7777"/>
							<gml:surfaceMember xlink:href="#poly-c0cd1afd-4386-4c08-b33d-eeec7a596ca6"/>
							<gml:surfaceMember xlink:href="#poly-c01358fe-3ad8-4c33-8468-bf57211198b2"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_6ebd0231-a496-40ae-bbb8-e24587374549_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f4d1fffa-28f6-466a-82f7-0fd96d05fe38">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67408992688946 139.7380953308851 18.585 35.674070914535044 139.73803532533597 18.585 35.67408916044739 139.7380266319315 18.585 35.67410817280607 139.73808663749222 18.585 35.67408992688946 139.7380953308851 18.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ad78843-7277-4eda-9b13-85cd52cfd6fb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674132665674755 139.73811268983064 18.585 35.674118915949876 139.7381192900399 18.585 35.674114108771676 139.73810427213718 18.585 35.674127858487 139.738097660879 18.585 35.674132665674755 139.73811268983064 18.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-03725e1e-28dc-4f5f-a1bd-57d3ce8f6840">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67413671739989 139.73806148320762 20.973 35.67413686306156 139.73806330575266 20.973 35.67413670224809 139.73806511761518 20.973 35.67413623490705 139.7380668525145 20.973 35.67413548801842 139.73806843309112 20.973 35.674134479557196 139.73806979304302 20.973 35.674133272566955 139.73807086601462 20.973 35.67413190305888 139.73807159672924 20.973 35.67413044313397 139.73807197405446 20.973 35.674128955862024 139.738071964775 20.973 35.67412749533406 139.73807157987338 20.973 35.674126133668565 139.73807083031073 20.973 35.67412492497406 139.73806974916306 20.973 35.67412393238149 139.73806838054247 20.973 35.67412319199816 139.73806679068673 20.973 35.674122739931384 139.7380650458335 20.973 35.674122585264776 139.73806323434624 20.973 35.67412274606948 139.7380614114373 20.973 35.67412321341043 139.73805967653823 20.973 35.67412396931267 139.73805809595103 20.973 35.67412496876003 139.73805673600987 20.973 35.674126184772604 139.73805567407425 20.973 35.67412754525813 139.73805493232334 20.973 35.67412900519173 139.73805456604458 20.973 35.67413050147741 139.73805457531304 20.973 35.67413196200542 139.73805496021433 20.973 35.674133323671 139.73805570977675 20.973 35.67413452335192 139.73805679093505 20.973 35.67413551593587 139.73805814850888 20.973 35.674136256319315 139.73805973836483 20.973 35.67413671739989 139.73806148320762 20.973</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e738dbf6-dd4d-4f1c-89a4-b051074ff61a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e738dbf6-dd4d-4f1c-89a4-b051074ff61a_0">
											<gml:posList>35.674070914535044 139.73803532533597 20.85 35.67408916044739 139.7380266319315 20.85 35.67408916044739 139.7380266319315 18.585 35.674070914535044 139.73803532533597 18.585 35.674070914535044 139.73803532533597 20.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-50c8159a-475e-4ed3-81c6-a23fce6f239a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-50c8159a-475e-4ed3-81c6-a23fce6f239a_0">
											<gml:posList>35.674070914535044 139.73803532533597 20.85 35.674070914535044 139.73803532533597 18.585 35.67408992688946 139.7380953308851 18.585 35.67408992688946 139.7380953308851 20.85 35.674070914535044 139.73803532533597 20.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3db16ac2-3c77-4fda-91b4-4a2ed0d01f6a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3db16ac2-3c77-4fda-91b4-4a2ed0d01f6a_0">
											<gml:posList>35.67408992688946 139.7380953308851 20.85 35.67410817280607 139.73808663749222 20.85 35.67408916044739 139.7380266319315 20.85 35.674070914535044 139.73803532533597 20.85 35.67408992688946 139.7380953308851 20.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c6e97603-032d-4ada-9e9c-f7c6e429d0a9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c6e97603-032d-4ada-9e9c-f7c6e429d0a9_0">
											<gml:posList>35.67410817280607 139.73808663749222 20.85 35.67410817280607 139.73808663749222 18.585 35.67408916044739 139.7380266319315 18.585 35.67408916044739 139.7380266319315 20.85 35.67410817280607 139.73808663749222 20.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2aacd715-310c-4ee7-bf38-0501c9a4df2d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2aacd715-310c-4ee7-bf38-0501c9a4df2d_0">
											<gml:posList>35.67410817280607 139.73808663749222 20.85 35.67408992688946 139.7380953308851 20.85 35.67408992688946 139.7380953308851 18.585 35.67410817280607 139.73808663749222 18.585 35.67410817280607 139.73808663749222 20.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-554e1f67-6cca-468a-9a30-0720de7bea18">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-554e1f67-6cca-468a-9a30-0720de7bea18_0">
											<gml:posList>35.674118915949876 139.7381192900399 21.498 35.674114108771676 139.73810427213718 21.498 35.674114108771676 139.73810427213718 18.585 35.674118915949876 139.7381192900399 18.585 35.674118915949876 139.7381192900399 21.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f71c41d-f502-4a30-a95d-b6471a921756">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5f71c41d-f502-4a30-a95d-b6471a921756_0">
											<gml:posList>35.674114108771676 139.73810427213718 21.498 35.674127858487 139.738097660879 21.498 35.674127858487 139.738097660879 18.585 35.674114108771676 139.73810427213718 18.585 35.674114108771676 139.73810427213718 21.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-605f96c4-9196-4ce0-961b-90a082d3bebd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-605f96c4-9196-4ce0-961b-90a082d3bebd_0">
											<gml:posList>35.674122739931384 139.7380650458335 23.13 35.674122585264776 139.73806323434624 23.13 35.674122585264776 139.73806323434624 20.973 35.674122739931384 139.7380650458335 20.973 35.674122739931384 139.7380650458335 23.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-49b433d6-be46-4176-a338-eed1869770df">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-49b433d6-be46-4176-a338-eed1869770df_0">
											<gml:posList>35.674122585264776 139.73806323434624 23.13 35.67412274606948 139.7380614114373 23.13 35.67412274606948 139.7380614114373 20.973 35.674122585264776 139.73806323434624 20.973 35.674122585264776 139.73806323434624 23.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d0d974f-14d7-4091-b6ac-250779f661ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4d0d974f-14d7-4091-b6ac-250779f661ca_0">
											<gml:posList>35.674122739931384 139.7380650458335 23.13 35.674122739931384 139.7380650458335 20.973 35.67412319199816 139.73806679068673 20.973 35.67412319199816 139.73806679068673 23.13 35.674122739931384 139.7380650458335 23.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-49b65bc0-b1f4-4790-9e0f-0acac73e824d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-49b65bc0-b1f4-4790-9e0f-0acac73e824d_0">
											<gml:posList>35.67412274606948 139.7380614114373 23.13 35.67412321341043 139.73805967653823 23.13 35.67412321341043 139.73805967653823 20.973 35.67412274606948 139.7380614114373 20.973 35.67412274606948 139.7380614114373 23.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-449d8086-8652-4e13-a406-9e320275a269">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-449d8086-8652-4e13-a406-9e320275a269_0">
											<gml:posList>35.674114108771676 139.73810427213718 21.498 35.674118915949876 139.7381192900399 21.498 35.674132665674755 139.73811268983064 21.498 35.674127858487 139.738097660879 21.498 35.674114108771676 139.73810427213718 21.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd7b5468-69ab-49d2-88ff-065816f477af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cd7b5468-69ab-49d2-88ff-065816f477af_0">
											<gml:posList>35.67412393238149 139.73806838054247 23.13 35.67412319199816 139.73806679068673 23.13 35.67412319199816 139.73806679068673 20.973 35.67412393238149 139.73806838054247 20.973 35.67412393238149 139.73806838054247 23.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19bb65bf-7fd7-44ec-8584-eba3b1ae9d46">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19bb65bf-7fd7-44ec-8584-eba3b1ae9d46_0">
											<gml:posList>35.67412321341043 139.73805967653823 23.13 35.67412396931267 139.73805809595103 23.13 35.67412396931267 139.73805809595103 20.973 35.67412321341043 139.73805967653823 20.973 35.67412321341043 139.73805967653823 23.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7d3882f-2f30-4949-b45a-1dd6d65582cc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f7d3882f-2f30-4949-b45a-1dd6d65582cc_0">
											<gml:posList>35.67412393238149 139.73806838054247 23.13 35.67412393238149 139.73806838054247 20.973 35.67412492497406 139.73806974916306 20.973 35.67412492497406 139.73806974916306 23.13 35.67412393238149 139.73806838054247 23.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c657b2f-16c6-4c79-8266-e6531375533d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c657b2f-16c6-4c79-8266-e6531375533d_0">
											<gml:posList>35.67412396931267 139.73805809595103 23.13 35.67412496876003 139.73805673600987 23.13 35.67412496876003 139.73805673600987 20.973 35.67412396931267 139.73805809595103 20.973 35.67412396931267 139.73805809595103 23.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76fd6273-afed-48da-ae48-c4e1f038fead">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-76fd6273-afed-48da-ae48-c4e1f038fead_0">
											<gml:posList>35.674126133668565 139.73807083031073 23.13 35.67412492497406 139.73806974916306 23.13 35.67412492497406 139.73806974916306 20.973 35.674126133668565 139.73807083031073 20.973 35.674126133668565 139.73807083031073 23.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a8696bb1-e399-42ed-8a7a-2cfc5083b3c0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a8696bb1-e399-42ed-8a7a-2cfc5083b3c0_0">
											<gml:posList>35.67412496876003 139.73805673600987 23.13 35.674126184772604 139.73805567407425 23.13 35.674126184772604 139.73805567407425 20.973 35.67412496876003 139.73805673600987 20.973 35.67412496876003 139.73805673600987 23.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e90ef06-0439-4855-916d-3d62dfd6cd09">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7e90ef06-0439-4855-916d-3d62dfd6cd09_0">
											<gml:posList>35.674132665674755 139.73811268983064 21.498 35.674118915949876 139.7381192900399 21.498 35.674118915949876 139.7381192900399 18.585 35.674132665674755 139.73811268983064 18.585 35.674132665674755 139.73811268983064 21.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-412a7521-270f-43cd-bd5b-5600a15cc78c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-412a7521-270f-43cd-bd5b-5600a15cc78c_0">
											<gml:posList>35.67412749533406 139.73807157987338 23.13 35.674126133668565 139.73807083031073 23.13 35.674126133668565 139.73807083031073 20.973 35.67412749533406 139.73807157987338 20.973 35.67412749533406 139.73807157987338 23.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5398cb22-a3d3-47e9-9e22-2a8d066ab278">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5398cb22-a3d3-47e9-9e22-2a8d066ab278_0">
											<gml:posList>35.674126184772604 139.73805567407425 23.13 35.67412754525813 139.73805493232334 23.13 35.67412754525813 139.73805493232334 20.973 35.674126184772604 139.73805567407425 20.973 35.674126184772604 139.73805567407425 23.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1addba96-eb67-49a6-af72-784586ec1f88">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1addba96-eb67-49a6-af72-784586ec1f88_0">
											<gml:posList>35.674128955862024 139.738071964775 23.13 35.67412749533406 139.73807157987338 23.13 35.67412749533406 139.73807157987338 20.973 35.674128955862024 139.738071964775 20.973 35.674128955862024 139.738071964775 23.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5fec2aca-a4a3-4829-ab7c-8254df98d946">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5fec2aca-a4a3-4829-ab7c-8254df98d946_0">
											<gml:posList>35.67412754525813 139.73805493232334 23.13 35.67412900519173 139.73805456604458 23.13 35.67412900519173 139.73805456604458 20.973 35.67412754525813 139.73805493232334 20.973 35.67412754525813 139.73805493232334 23.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6bd91421-a2eb-48a7-9474-68e4b807533a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6bd91421-a2eb-48a7-9474-68e4b807533a_0">
											<gml:posList>35.674128955862024 139.738071964775 23.13 35.674128955862024 139.738071964775 20.973 35.67413044313397 139.73807197405446 20.973 35.67413044313397 139.73807197405446 23.13 35.674128955862024 139.738071964775 23.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2173731-3a95-4dd0-8ca4-6a1ebced72e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b2173731-3a95-4dd0-8ca4-6a1ebced72e4_0">
											<gml:posList>35.67413670224809 139.73806511761518 23.13 35.67413686306156 139.73806330575266 23.13 35.67413671739989 139.73806148320762 23.13 35.674136256319315 139.73805973836483 23.13 35.67413551593587 139.73805814850888 23.13 35.67413452335192 139.73805679093505 23.13 35.674133323671 139.73805570977675 23.13 35.67413196200542 139.73805496021433 23.13 35.67413050147741 139.73805457531304 23.13 35.67412900519173 139.73805456604458 23.13 35.67412754525813 139.73805493232334 23.13 35.674126184772604 139.73805567407425 23.13 35.67412496876003 139.73805673600987 23.13 35.67412396931267 139.73805809595103 23.13 35.67412321341043 139.73805967653823 23.13 35.67412274606948 139.7380614114373 23.13 35.674122585264776 139.73806323434624 23.13 35.674122739931384 139.7380650458335 23.13 35.67412319199816 139.73806679068673 23.13 35.67412393238149 139.73806838054247 23.13 35.67412492497406 139.73806974916306 23.13 35.674126133668565 139.73807083031073 23.13 35.67412749533406 139.73807157987338 23.13 35.674128955862024 139.738071964775 23.13 35.67413044313397 139.73807197405446 23.13 35.67413190305888 139.73807159672924 23.13 35.674133272566955 139.73807086601462 23.13 35.674134479557196 139.73806979304302 23.13 35.67413548801842 139.73806843309112 23.13 35.67413623490705 139.7380668525145 23.13 35.67413670224809 139.73806511761518 23.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-516f5fcc-355e-444a-a1c1-1c14d14e915a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-516f5fcc-355e-444a-a1c1-1c14d14e915a_0">
											<gml:posList>35.67413050147741 139.73805457531304 23.13 35.67413050147741 139.73805457531304 20.973 35.67412900519173 139.73805456604458 20.973 35.67412900519173 139.73805456604458 23.13 35.67413050147741 139.73805457531304 23.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8379857-4e09-4405-9475-e3b4980392c2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b8379857-4e09-4405-9475-e3b4980392c2_0">
											<gml:posList>35.674127858487 139.738097660879 21.498 35.674132665674755 139.73811268983064 21.498 35.674132665674755 139.73811268983064 18.585 35.674127858487 139.738097660879 18.585 35.674127858487 139.738097660879 21.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bcd8a47e-ff1b-4c01-8241-25ba331893d5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bcd8a47e-ff1b-4c01-8241-25ba331893d5_0">
											<gml:posList>35.67413190305888 139.73807159672924 23.13 35.67413044313397 139.73807197405446 23.13 35.67413044313397 139.73807197405446 20.973 35.67413190305888 139.73807159672924 20.973 35.67413190305888 139.73807159672924 23.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-41bcf3c2-0d10-42ac-98d7-57df14ec156c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-41bcf3c2-0d10-42ac-98d7-57df14ec156c_0">
											<gml:posList>35.67413050147741 139.73805457531304 23.13 35.67413196200542 139.73805496021433 23.13 35.67413196200542 139.73805496021433 20.973 35.67413050147741 139.73805457531304 20.973 35.67413050147741 139.73805457531304 23.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2b233c6-bccf-4c97-8f20-928eeacd3b5f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b2b233c6-bccf-4c97-8f20-928eeacd3b5f_0">
											<gml:posList>35.674133272566955 139.73807086601462 23.13 35.67413190305888 139.73807159672924 23.13 35.67413190305888 139.73807159672924 20.973 35.674133272566955 139.73807086601462 20.973 35.674133272566955 139.73807086601462 23.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-89b8e896-0b23-473c-9f0c-99d6c84cc323">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-89b8e896-0b23-473c-9f0c-99d6c84cc323_0">
											<gml:posList>35.67413196200542 139.73805496021433 23.13 35.674133323671 139.73805570977675 23.13 35.674133323671 139.73805570977675 20.973 35.67413196200542 139.73805496021433 20.973 35.67413196200542 139.73805496021433 23.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e5fce12-6dce-474c-a4cc-941d978c32cc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e5fce12-6dce-474c-a4cc-941d978c32cc_0">
											<gml:posList>35.674134479557196 139.73806979304302 23.13 35.674133272566955 139.73807086601462 23.13 35.674133272566955 139.73807086601462 20.973 35.674134479557196 139.73806979304302 20.973 35.674134479557196 139.73806979304302 23.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-87662387-5809-4ca8-ba7a-05318d750449">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-87662387-5809-4ca8-ba7a-05318d750449_0">
											<gml:posList>35.674133323671 139.73805570977675 23.13 35.67413452335192 139.73805679093505 23.13 35.67413452335192 139.73805679093505 20.973 35.674133323671 139.73805570977675 20.973 35.674133323671 139.73805570977675 23.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc7fa40a-f86c-4319-afd1-46934d55421e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bc7fa40a-f86c-4319-afd1-46934d55421e_0">
											<gml:posList>35.67413548801842 139.73806843309112 23.13 35.674134479557196 139.73806979304302 23.13 35.674134479557196 139.73806979304302 20.973 35.67413548801842 139.73806843309112 20.973 35.67413548801842 139.73806843309112 23.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-47dc3a58-12c9-4aaa-8cf9-75376b8f4f79">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-47dc3a58-12c9-4aaa-8cf9-75376b8f4f79_0">
											<gml:posList>35.67413551593587 139.73805814850888 23.13 35.67413551593587 139.73805814850888 20.973 35.67413452335192 139.73805679093505 20.973 35.67413452335192 139.73805679093505 23.13 35.67413551593587 139.73805814850888 23.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d5019ac-002e-41ff-9f3e-83323d55f3cc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3d5019ac-002e-41ff-9f3e-83323d55f3cc_0">
											<gml:posList>35.67413623490705 139.7380668525145 23.13 35.67413548801842 139.73806843309112 23.13 35.67413548801842 139.73806843309112 20.973 35.67413623490705 139.7380668525145 20.973 35.67413623490705 139.7380668525145 23.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dcb45a3f-df1b-4b04-9233-0fb0c34f5e8b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dcb45a3f-df1b-4b04-9233-0fb0c34f5e8b_0">
											<gml:posList>35.67413551593587 139.73805814850888 23.13 35.674136256319315 139.73805973836483 23.13 35.674136256319315 139.73805973836483 20.973 35.67413551593587 139.73805814850888 20.973 35.67413551593587 139.73805814850888 23.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f20ab2ce-6e6f-4ce1-b686-b9381f72cb15">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f20ab2ce-6e6f-4ce1-b686-b9381f72cb15_0">
											<gml:posList>35.67413670224809 139.73806511761518 23.13 35.67413623490705 139.7380668525145 23.13 35.67413623490705 139.7380668525145 20.973 35.67413670224809 139.73806511761518 20.973 35.67413670224809 139.73806511761518 23.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e89c1d0d-6b38-445f-97aa-60b8935222fc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e89c1d0d-6b38-445f-97aa-60b8935222fc_0">
											<gml:posList>35.67413671739989 139.73806148320762 23.13 35.67413671739989 139.73806148320762 20.973 35.674136256319315 139.73805973836483 20.973 35.674136256319315 139.73805973836483 23.13 35.67413671739989 139.73806148320762 23.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e27249f4-b803-49c5-b1f3-f3eb3c4c1118">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e27249f4-b803-49c5-b1f3-f3eb3c4c1118_0">
											<gml:posList>35.67413686306156 139.73806330575266 23.13 35.67413670224809 139.73806511761518 23.13 35.67413670224809 139.73806511761518 20.973 35.67413686306156 139.73806330575266 20.973 35.67413686306156 139.73806330575266 23.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01e22d6b-63e4-48e3-9d7b-4b04f3fb8c2d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01e22d6b-63e4-48e3-9d7b-4b04f3fb8c2d_0">
											<gml:posList>35.67413671739989 139.73806148320762 23.13 35.67413686306156 139.73806330575266 23.13 35.67413686306156 139.73806330575266 20.973 35.67413671739989 139.73806148320762 20.973 35.67413671739989 139.73806148320762 23.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-b782f0b5-c1c2-4059-954d-ea938ab056ad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b782f0b5-c1c2-4059-954d-ea938ab056ad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b782f0b5-c1c2-4059-954d-ea938ab056ad">
											<gml:posList>35.67405450543148 139.73800734129182 8.39 35.67411992034653 139.73797611160293 8.39 35.67417549358841 139.7381515788672 8.39 35.67411007854097 139.73818269796712 8.39 35.67405450543148 139.73800734129182 8.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ba515928-edcf-4602-8883-cbf4f6c72512">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba515928-edcf-4602-8883-cbf4f6c72512">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba515928-edcf-4602-8883-cbf4f6c72512">
											<gml:posList>35.67405450543148 139.73800734129182 19.51 35.674060727563266 139.73801070315682 19.51 35.67411717721672 139.73798375923354 19.51 35.67411992034653 139.73797611160293 19.51 35.67405450543148 139.73800734129182 19.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-78db084a-cb40-4a10-811b-df5b8a08a14f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78db084a-cb40-4a10-811b-df5b8a08a14f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78db084a-cb40-4a10-811b-df5b8a08a14f">
											<gml:posList>35.67411717721672 139.73798375923354 19.51 35.674125689435506 139.73801064800693 19.51 35.67413018559214 139.738008510633 19.51 35.67411992034653 139.73797611160293 19.51 35.67411717721672 139.73798375923354 19.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0054953e-c622-42cc-ae0e-91475f69c327">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0054953e-c622-42cc-ae0e-91475f69c327">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0054953e-c622-42cc-ae0e-91475f69c327">
											<gml:posList>35.674103001423674 139.73802144558715 21.37 35.67410689701934 139.73802355088918 21.37 35.67412846775028 139.73801328488273 21.37 35.67413018559214 139.738008510633 21.37 35.674103001423674 139.73802144558715 21.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d6ba53e8-c7bb-4fb8-80e1-24682c79abda">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d6ba53e8-c7bb-4fb8-80e1-24682c79abda">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d6ba53e8-c7bb-4fb8-80e1-24682c79abda">
											<gml:posList>35.67413018559214 139.738008510633 21.37 35.67412846775028 139.73801328488273 21.37 35.674146359626725 139.73806976787887 21.37 35.6741502462078 139.73807187319508 21.37 35.67413018559214 139.738008510633 21.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5ead93ca-b386-4c61-a78e-a9a1fa9d1465">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5ead93ca-b386-4c61-a78e-a9a1fa9d1465">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5ead93ca-b386-4c61-a78e-a9a1fa9d1465">
											<gml:posList>35.674146359626725 139.73806976787887 20.973 35.67412846775028 139.73801328488273 20.973 35.67410689701934 139.73802355088918 20.973 35.674124797904724 139.73808003386173 20.973 35.674146359626725 139.73806976787887 20.973</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-899c17a1-32f2-4ba5-ada9-254a4c85797f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-899c17a1-32f2-4ba5-ada9-254a4c85797f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-899c17a1-32f2-4ba5-ada9-254a4c85797f">
											<gml:posList>35.67412307103758 139.73808479707358 21.37 35.674124797904724 139.73808003386173 21.37 35.67410689701934 139.73802355088918 21.37 35.674103001423674 139.73802144558715 21.37 35.67412307103758 139.73808479707358 21.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d2d3ee37-0916-46e5-8e31-e01bdce04ad1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d2d3ee37-0916-46e5-8e31-e01bdce04ad1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d2d3ee37-0916-46e5-8e31-e01bdce04ad1">
											<gml:posList>35.6741502462078 139.73807187319508 21.37 35.674146359626725 139.73806976787887 21.37 35.674124797904724 139.73808003386173 21.37 35.67412307103758 139.73808479707358 21.37 35.6741502462078 139.73807187319508 21.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4a92c474-3e0b-46e0-8e3e-382517318a83">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a92c474-3e0b-46e0-8e3e-382517318a83">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a92c474-3e0b-46e0-8e3e-382517318a83">
											<gml:posList>35.67416925343321 139.73814821700788 18.585 35.67414575906378 139.73807401055532 18.585 35.67412307103758 139.73808479707358 18.585 35.674103001423674 139.73802144558715 18.585 35.674125689435506 139.73801064800693 18.585 35.67411717721672 139.73798375923354 18.585 35.674060727563266 139.73801070315682 18.585 35.67411282169215 139.73817506139076 18.585 35.67416925343321 139.73814821700788 18.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f2d7a6cb-ffdf-4ab8-95dd-a146048f52e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f2d7a6cb-ffdf-4ab8-95dd-a146048f52e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f2d7a6cb-ffdf-4ab8-95dd-a146048f52e8">
											<gml:posList>35.67411007854097 139.73818269796712 19.51 35.67411282169215 139.73817506139076 19.51 35.674060727563266 139.73801070315682 19.51 35.67405450543148 139.73800734129182 19.51 35.67411007854097 139.73818269796712 19.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-09eca50e-40d9-40b4-bb2a-baf28db4c1e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-09eca50e-40d9-40b4-bb2a-baf28db4c1e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-09eca50e-40d9-40b4-bb2a-baf28db4c1e6">
											<gml:posList>35.67416925343321 139.73814821700788 19.51 35.67417549358841 139.7381515788672 19.51 35.6741502462078 139.73807187319508 19.51 35.67414575906378 139.73807401055532 19.51 35.67416925343321 139.73814821700788 19.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9bd211e7-78fe-4ae7-8b80-9a287756a8f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9bd211e7-78fe-4ae7-8b80-9a287756a8f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9bd211e7-78fe-4ae7-8b80-9a287756a8f6">
											<gml:posList>35.67417549358841 139.7381515788672 19.51 35.67416925343321 139.73814821700788 19.51 35.67411282169215 139.73817506139076 19.51 35.67411007854097 139.73818269796712 19.51 35.67417549358841 139.7381515788672 19.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-24b76592-8eda-4422-b75e-927d112e5a1a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-24b76592-8eda-4422-b75e-927d112e5a1a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-24b76592-8eda-4422-b75e-927d112e5a1a">
											<gml:posList>35.674124797904724 139.73808003386173 21.37 35.674124797904724 139.73808003386173 20.973 35.67410689701934 139.73802355088918 20.973 35.67410689701934 139.73802355088918 21.37 35.674124797904724 139.73808003386173 21.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5f51f422-37fc-45f5-bd41-0cf812032c88">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f51f422-37fc-45f5-bd41-0cf812032c88">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f51f422-37fc-45f5-bd41-0cf812032c88">
											<gml:posList>35.67411992034653 139.73797611160293 8.39 35.67405450543148 139.73800734129182 8.39 35.67405450543148 139.73800734129182 19.51 35.67411992034653 139.73797611160293 19.51 35.67411992034653 139.73797611160293 8.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dc751baa-d69f-469e-a7e5-807227cdd524">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc751baa-d69f-469e-a7e5-807227cdd524">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc751baa-d69f-469e-a7e5-807227cdd524">
											<gml:posList>35.674060727563266 139.73801070315682 19.51 35.674060727563266 139.73801070315682 18.585 35.67411717721672 139.73798375923354 18.585 35.67411717721672 139.73798375923354 19.51 35.674060727563266 139.73801070315682 19.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1348d186-b6a2-443b-ade6-a9dff07733d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1348d186-b6a2-443b-ade6-a9dff07733d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1348d186-b6a2-443b-ade6-a9dff07733d6">
											<gml:posList>35.67411717721672 139.73798375923354 19.51 35.67411717721672 139.73798375923354 18.585 35.674125689435506 139.73801064800693 18.585 35.674125689435506 139.73801064800693 19.51 35.67411717721672 139.73798375923354 19.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a7ea3509-a664-426d-bac9-32c551f44cc8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a7ea3509-a664-426d-bac9-32c551f44cc8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a7ea3509-a664-426d-bac9-32c551f44cc8">
											<gml:posList>35.674125689435506 139.73801064800693 19.51 35.674125689435506 139.73801064800693 18.585 35.674103001423674 139.73802144558715 18.585 35.674103001423674 139.73802144558715 21.37 35.67413018559214 139.738008510633 21.37 35.67413018559214 139.738008510633 19.51 35.674125689435506 139.73801064800693 19.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cf43bd06-ef09-4f21-8b22-ea3969407232">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cf43bd06-ef09-4f21-8b22-ea3969407232">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cf43bd06-ef09-4f21-8b22-ea3969407232">
											<gml:posList>35.67410689701934 139.73802355088918 21.37 35.67410689701934 139.73802355088918 20.973 35.67412846775028 139.73801328488273 20.973 35.67412846775028 139.73801328488273 21.37 35.67410689701934 139.73802355088918 21.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-97c796f6-e612-4aef-ba93-651b8b6b2f75">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-97c796f6-e612-4aef-ba93-651b8b6b2f75">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-97c796f6-e612-4aef-ba93-651b8b6b2f75">
											<gml:posList>35.67412846775028 139.73801328488273 21.37 35.67412846775028 139.73801328488273 20.973 35.674146359626725 139.73806976787887 20.973 35.674146359626725 139.73806976787887 21.37 35.67412846775028 139.73801328488273 21.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-08a22a66-7813-42a5-a1e0-4c872774a08b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-08a22a66-7813-42a5-a1e0-4c872774a08b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-08a22a66-7813-42a5-a1e0-4c872774a08b">
											<gml:posList>35.674103001423674 139.73802144558715 18.585 35.67412307103758 139.73808479707358 18.585 35.67412307103758 139.73808479707358 21.37 35.674103001423674 139.73802144558715 21.37 35.674103001423674 139.73802144558715 18.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-19eb5ae2-fb0e-4713-8c52-577ba78821a6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-19eb5ae2-fb0e-4713-8c52-577ba78821a6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-19eb5ae2-fb0e-4713-8c52-577ba78821a6">
											<gml:posList>35.67413018559214 139.738008510633 19.51 35.67413018559214 139.738008510633 21.37 35.6741502462078 139.73807187319508 21.37 35.6741502462078 139.73807187319508 19.51 35.67417549358841 139.7381515788672 19.51 35.67417549358841 139.7381515788672 8.39 35.67411992034653 139.73797611160293 8.39 35.67411992034653 139.73797611160293 19.51 35.67413018559214 139.738008510633 19.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a6f21795-9e6a-4bed-83e3-4f3d641d666f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a6f21795-9e6a-4bed-83e3-4f3d641d666f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a6f21795-9e6a-4bed-83e3-4f3d641d666f">
											<gml:posList>35.674146359626725 139.73806976787887 21.37 35.674146359626725 139.73806976787887 20.973 35.674124797904724 139.73808003386173 20.973 35.674124797904724 139.73808003386173 21.37 35.674146359626725 139.73806976787887 21.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1c6af1d9-dc8e-4743-8c0d-1996cba54f8c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c6af1d9-dc8e-4743-8c0d-1996cba54f8c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c6af1d9-dc8e-4743-8c0d-1996cba54f8c">
											<gml:posList>35.67414575906378 139.73807401055532 19.51 35.6741502462078 139.73807187319508 19.51 35.6741502462078 139.73807187319508 21.37 35.67412307103758 139.73808479707358 21.37 35.67412307103758 139.73808479707358 18.585 35.67414575906378 139.73807401055532 18.585 35.67414575906378 139.73807401055532 19.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-13468cfe-cdb6-4e3d-9c39-7e63440c9712">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13468cfe-cdb6-4e3d-9c39-7e63440c9712">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13468cfe-cdb6-4e3d-9c39-7e63440c9712">
											<gml:posList>35.67411282169215 139.73817506139076 19.51 35.67411282169215 139.73817506139076 18.585 35.674060727563266 139.73801070315682 18.585 35.674060727563266 139.73801070315682 19.51 35.67411282169215 139.73817506139076 19.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3a2a7948-ad0b-4bd0-bbe8-07b3a5e115e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a2a7948-ad0b-4bd0-bbe8-07b3a5e115e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a2a7948-ad0b-4bd0-bbe8-07b3a5e115e6">
											<gml:posList>35.67405450543148 139.73800734129182 8.39 35.67411007854097 139.73818269796712 8.39 35.67411007854097 139.73818269796712 19.51 35.67405450543148 139.73800734129182 19.51 35.67405450543148 139.73800734129182 8.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-31ad80d5-327f-4b16-a68a-54d3f79c7777">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31ad80d5-327f-4b16-a68a-54d3f79c7777">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31ad80d5-327f-4b16-a68a-54d3f79c7777">
											<gml:posList>35.67414575906378 139.73807401055532 19.51 35.67414575906378 139.73807401055532 18.585 35.67416925343321 139.73814821700788 18.585 35.67416925343321 139.73814821700788 19.51 35.67414575906378 139.73807401055532 19.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c0cd1afd-4386-4c08-b33d-eeec7a596ca6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0cd1afd-4386-4c08-b33d-eeec7a596ca6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0cd1afd-4386-4c08-b33d-eeec7a596ca6">
											<gml:posList>35.67416925343321 139.73814821700788 19.51 35.67416925343321 139.73814821700788 18.585 35.67411282169215 139.73817506139076 18.585 35.67411282169215 139.73817506139076 19.51 35.67416925343321 139.73814821700788 19.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c01358fe-3ad8-4c33-8468-bf57211198b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c01358fe-3ad8-4c33-8468-bf57211198b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c01358fe-3ad8-4c33-8468-bf57211198b2">
											<gml:posList>35.67411007854097 139.73818269796712 8.39 35.67417549358841 139.7381515788672 8.39 35.67417549358841 139.7381515788672 19.51 35.67411007854097 139.73818269796712 19.51 35.67411007854097 139.73818269796712 8.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8247</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">132.63735</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1242</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.08</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>