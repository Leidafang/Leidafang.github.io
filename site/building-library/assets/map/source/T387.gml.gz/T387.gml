<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_70470631-6473-45dd-890a-a4dd0baa7a4c">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">7.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.6724340860581 139.73947116745404 0 35.67246602243279 139.73950681040986 0 35.67252256934463 139.73943074393642 0 35.67242479378564 139.73932209421525 0 35.672362826163045 139.7394051926183 0 35.67242859354452 139.73947868553276 0 35.6724340860581 139.73947116745404 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6724340860581 139.73947116745404 7.8 35.67242859354452 139.73947868553276 7.8 35.672362826163045 139.7394051926183 7.8 35.67242479378564 139.73932209421525 7.8 35.67252256934463 139.73943074393642 7.8 35.67246602243279 139.73950681040986 7.8 35.6724340860581 139.73947116745404 7.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6724340860581 139.73947116745404 7.8 35.67246602243279 139.73950681040986 7.8 35.67246602243279 139.73950681040986 14.91 35.6724340860581 139.73947116745404 14.91 35.6724340860581 139.73947116745404 7.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67246602243279 139.73950681040986 7.8 35.67252256934463 139.73943074393642 7.8 35.67252256934463 139.73943074393642 14.91 35.67246602243279 139.73950681040986 14.91 35.67246602243279 139.73950681040986 7.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67252256934463 139.73943074393642 7.8 35.67242479378564 139.73932209421525 7.8 35.67242479378564 139.73932209421525 14.91 35.67252256934463 139.73943074393642 14.91 35.67252256934463 139.73943074393642 7.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67242479378564 139.73932209421525 7.8 35.672362826163045 139.7394051926183 7.8 35.672362826163045 139.7394051926183 14.91 35.67242479378564 139.73932209421525 14.91 35.67242479378564 139.73932209421525 7.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672362826163045 139.7394051926183 7.8 35.67242859354452 139.73947868553276 7.8 35.67242859354452 139.73947868553276 14.91 35.672362826163045 139.7394051926183 14.91 35.672362826163045 139.7394051926183 7.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67242859354452 139.73947868553276 7.8 35.6724340860581 139.73947116745404 7.8 35.6724340860581 139.73947116745404 14.91 35.67242859354452 139.73947868553276 14.91 35.67242859354452 139.73947868553276 7.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6724340860581 139.73947116745404 14.91 35.67246602243279 139.73950681040986 14.91 35.67252256934463 139.73943074393642 14.91 35.67242479378564 139.73932209421525 14.91 35.672362826163045 139.7394051926183 14.91 35.67242859354452 139.73947868553276 14.91 35.6724340860581 139.73947116745404 14.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-9f146ad0-c826-4823-a636-0d1168d9eb8b"/>
							<gml:surfaceMember xlink:href="#poly-0d9167a0-dbff-491a-af5b-2d01d417a89d"/>
							<gml:surfaceMember xlink:href="#poly-9a5f6bce-e68b-4195-b20b-354e590ddd6e"/>
							<gml:surfaceMember xlink:href="#poly-813faf4a-b9f7-4d90-ac38-b31193418eed"/>
							<gml:surfaceMember xlink:href="#poly-b6998149-7a2f-411a-a479-41faed0f0486"/>
							<gml:surfaceMember xlink:href="#poly-56df18f4-00ef-4df9-ab08-71798eeb1644"/>
							<gml:surfaceMember xlink:href="#poly-3c5c19e7-e632-48cc-9cf1-9ae775566a4e"/>
							<gml:surfaceMember xlink:href="#poly-c8a03b3e-9f0c-4ac1-8722-a6b692e05295"/>
							<gml:surfaceMember xlink:href="#poly-d418015b-2b8f-4f9a-b1e5-b7c7e6fd4158"/>
							<gml:surfaceMember xlink:href="#poly-98ad1287-6294-4537-a4b6-aaf5bc232902"/>
							<gml:surfaceMember xlink:href="#poly-68ba3ea1-4c5c-498b-a280-05a8de70392c"/>
							<gml:surfaceMember xlink:href="#poly-d95b4ef9-ba26-470d-b1d6-38cf1f07c7bb"/>
							<gml:surfaceMember xlink:href="#poly-ec9c1a8b-9637-4522-a899-0c9f0d1e3501"/>
							<gml:surfaceMember xlink:href="#poly-595dc550-8e40-4c80-b740-3a028128c558"/>
							<gml:surfaceMember xlink:href="#poly-147f5a1a-e266-49f2-a1ac-12977562aaed"/>
							<gml:surfaceMember xlink:href="#poly-415b3a43-0599-4f9c-a5f7-bf207a4ee226"/>
							<gml:surfaceMember xlink:href="#poly-e4d97fe6-7218-41d5-aed8-5ce253486ece"/>
							<gml:surfaceMember xlink:href="#poly-1794184b-3422-48d9-852d-a6874c139290"/>
							<gml:surfaceMember xlink:href="#poly-cf51c063-16b6-41c9-b73d-424f971ebf61"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-9f146ad0-c826-4823-a636-0d1168d9eb8b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f146ad0-c826-4823-a636-0d1168d9eb8b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f146ad0-c826-4823-a636-0d1168d9eb8b">
											<gml:posList>35.67236282616303 139.7394051926183 7.8 35.67242479378562 139.73932209421523 7.8 35.67252256934461 139.73943074393642 7.8 35.672466022432786 139.73950681040986 7.8 35.6724340860581 139.739471167454 7.8 35.67242859354452 139.73947868553276 7.8 35.67236282616303 139.7394051926183 7.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0d9167a0-dbff-491a-af5b-2d01d417a89d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d9167a0-dbff-491a-af5b-2d01d417a89d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d9167a0-dbff-491a-af5b-2d01d417a89d">
											<gml:posList>35.67239605172522 139.73936021637877 15.513 35.67236282616303 139.7394051926183 13.633 35.67242859354452 139.73947868553276 13.633 35.67239605172522 139.73936021637877 15.513</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9a5f6bce-e68b-4195-b20b-354e590ddd6e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a5f6bce-e68b-4195-b20b-354e590ddd6e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a5f6bce-e68b-4195-b20b-354e590ddd6e">
											<gml:posList>35.67239605172522 139.73936021637877 15.513 35.67242859354452 139.73947868553276 13.633 35.6724340860581 139.739471167454 13.718 35.67239605172522 139.73936021637877 15.513</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-813faf4a-b9f7-4d90-ac38-b31193418eed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-813faf4a-b9f7-4d90-ac38-b31193418eed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-813faf4a-b9f7-4d90-ac38-b31193418eed">
											<gml:posList>35.67242479378562 139.73932209421523 13.718 35.67239605172522 139.73936021637877 15.513 35.67248622233819 139.73946073370448 15.513 35.67242479378562 139.73932209421523 13.718</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b6998149-7a2f-411a-a479-41faed0f0486">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6998149-7a2f-411a-a479-41faed0f0486">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6998149-7a2f-411a-a479-41faed0f0486">
											<gml:posList>35.67248622233819 139.73946073370448 15.513 35.67239605172522 139.73936021637877 15.513 35.6724340860581 139.739471167454 13.718 35.67248622233819 139.73946073370448 15.513</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-56df18f4-00ef-4df9-ab08-71798eeb1644">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56df18f4-00ef-4df9-ab08-71798eeb1644">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56df18f4-00ef-4df9-ab08-71798eeb1644">
											<gml:posList>35.67246279375732 139.73949298391253 13.756 35.6724340860581 139.739471167454 13.718 35.672466022432786 139.73950681040986 13.718 35.67246279375732 139.73949298391253 13.756</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3c5c19e7-e632-48cc-9cf1-9ae775566a4e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c5c19e7-e632-48cc-9cf1-9ae775566a4e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c5c19e7-e632-48cc-9cf1-9ae775566a4e">
											<gml:posList>35.67246279375732 139.73949298391253 13.756 35.67248622233819 139.73946073370448 15.513 35.6724340860581 139.739471167454 13.718 35.67246279375732 139.73949298391253 13.756</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c8a03b3e-9f0c-4ac1-8722-a6b692e05295">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8a03b3e-9f0c-4ac1-8722-a6b692e05295">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8a03b3e-9f0c-4ac1-8722-a6b692e05295">
											<gml:posList>35.67242479378562 139.73932209421523 13.718 35.67248622233819 139.73946073370448 15.513 35.67250680663253 139.73943368973525 13.756 35.67242479378562 139.73932209421523 13.718</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d418015b-2b8f-4f9a-b1e5-b7c7e6fd4158">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d418015b-2b8f-4f9a-b1e5-b7c7e6fd4158">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d418015b-2b8f-4f9a-b1e5-b7c7e6fd4158">
											<gml:posList>35.67250680663253 139.73943368973525 13.756 35.67252256934461 139.73943074393642 13.718 35.67242479378562 139.73932209421523 13.718 35.67250680663253 139.73943368973525 13.756</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-98ad1287-6294-4537-a4b6-aaf5bc232902">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-98ad1287-6294-4537-a4b6-aaf5bc232902">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-98ad1287-6294-4537-a4b6-aaf5bc232902">
											<gml:posList>35.67250680663253 139.73943368973525 13.756 35.67246279375732 139.73949298391253 13.756 35.672466022432786 139.73950681040986 13.718 35.67250680663253 139.73943368973525 13.756</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-68ba3ea1-4c5c-498b-a280-05a8de70392c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-68ba3ea1-4c5c-498b-a280-05a8de70392c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-68ba3ea1-4c5c-498b-a280-05a8de70392c">
											<gml:posList>35.67250680663253 139.73943368973525 13.756 35.672466022432786 139.73950681040986 13.718 35.67252256934461 139.73943074393642 13.718 35.67250680663253 139.73943368973525 13.756</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d95b4ef9-ba26-470d-b1d6-38cf1f07c7bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d95b4ef9-ba26-470d-b1d6-38cf1f07c7bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d95b4ef9-ba26-470d-b1d6-38cf1f07c7bb">
											<gml:posList>35.67239605172522 139.73936021637877 15.513 35.67242479378562 139.73932209421523 13.718 35.67236282616303 139.7394051926183 13.633 35.67239605172522 139.73936021637877 15.513</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ec9c1a8b-9637-4522-a899-0c9f0d1e3501">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec9c1a8b-9637-4522-a899-0c9f0d1e3501">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec9c1a8b-9637-4522-a899-0c9f0d1e3501">
											<gml:posList>35.67242479378562 139.73932209421523 13.718 35.67242479378562 139.73932209421523 7.8 35.67236282616303 139.7394051926183 7.8 35.67236282616303 139.7394051926183 13.633 35.67242479378562 139.73932209421523 13.718</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-595dc550-8e40-4c80-b740-3a028128c558">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-595dc550-8e40-4c80-b740-3a028128c558">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-595dc550-8e40-4c80-b740-3a028128c558">
											<gml:posList>35.67252256934461 139.73943074393642 13.718 35.67252256934461 139.73943074393642 7.8 35.67242479378562 139.73932209421523 7.8 35.67242479378562 139.73932209421523 13.718 35.67252256934461 139.73943074393642 13.718</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-147f5a1a-e266-49f2-a1ac-12977562aaed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-147f5a1a-e266-49f2-a1ac-12977562aaed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-147f5a1a-e266-49f2-a1ac-12977562aaed">
											<gml:posList>35.67236282616303 139.7394051926183 13.633 35.67236282616303 139.7394051926183 7.8 35.67242859354452 139.73947868553276 7.8 35.67242859354452 139.73947868553276 13.633 35.67236282616303 139.7394051926183 13.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-415b3a43-0599-4f9c-a5f7-bf207a4ee226">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-415b3a43-0599-4f9c-a5f7-bf207a4ee226">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-415b3a43-0599-4f9c-a5f7-bf207a4ee226">
											<gml:posList>35.67250680663253 139.73943368973525 13.756 35.67248622233819 139.73946073370448 15.513 35.67246279375732 139.73949298391253 13.756 35.67250680663253 139.73943368973525 13.756</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e4d97fe6-7218-41d5-aed8-5ce253486ece">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e4d97fe6-7218-41d5-aed8-5ce253486ece">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e4d97fe6-7218-41d5-aed8-5ce253486ece">
											<gml:posList>35.672466022432786 139.73950681040986 13.718 35.672466022432786 139.73950681040986 7.8 35.67252256934461 139.73943074393642 7.8 35.67252256934461 139.73943074393642 13.718 35.672466022432786 139.73950681040986 13.718</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1794184b-3422-48d9-852d-a6874c139290">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1794184b-3422-48d9-852d-a6874c139290">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1794184b-3422-48d9-852d-a6874c139290">
											<gml:posList>35.6724340860581 139.739471167454 7.8 35.6724340860581 139.739471167454 13.718 35.67242859354452 139.73947868553276 13.633 35.67242859354452 139.73947868553276 7.8 35.6724340860581 139.739471167454 7.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cf51c063-16b6-41c9-b73d-424f971ebf61">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cf51c063-16b6-41c9-b73d-424f971ebf61">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cf51c063-16b6-41c9-b73d-424f971ebf61">
											<gml:posList>35.6724340860581 139.739471167454 13.718 35.6724340860581 139.739471167454 7.8 35.672466022432786 139.73950681040986 7.8 35.672466022432786 139.73950681040986 13.718 35.6724340860581 139.739471167454 13.718</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-9471</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">145.41837</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1003</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1242</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.24</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">21</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>