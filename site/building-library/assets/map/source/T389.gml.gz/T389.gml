<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_70690ea1-7e84-4af5-a4bd-c4e13320de77">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">9.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.670251641375145 139.7439186197134 0 35.67015751168101 139.74388315582922 0 35.67014340197076 139.74393950732912 0 35.67023744151136 139.74397497137377 0 35.670251641375145 139.7439186197134 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670251641375145 139.7439186197134 8.23 35.67023744151136 139.74397497137377 8.23 35.67014340197076 139.74393950732912 8.23 35.67015751168101 139.74388315582922 8.23 35.670251641375145 139.7439186197134 8.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670251641375145 139.7439186197134 8.23 35.67015751168101 139.74388315582922 8.23 35.67015751168101 139.74388315582922 17.82 35.670251641375145 139.7439186197134 17.82 35.670251641375145 139.7439186197134 8.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67015751168101 139.74388315582922 8.23 35.67014340197076 139.74393950732912 8.23 35.67014340197076 139.74393950732912 17.82 35.67015751168101 139.74388315582922 17.82 35.67015751168101 139.74388315582922 8.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67014340197076 139.74393950732912 8.23 35.67023744151136 139.74397497137377 8.23 35.67023744151136 139.74397497137377 17.82 35.67014340197076 139.74393950732912 17.82 35.67014340197076 139.74393950732912 8.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67023744151136 139.74397497137377 8.23 35.670251641375145 139.7439186197134 8.23 35.670251641375145 139.7439186197134 17.82 35.67023744151136 139.74397497137377 17.82 35.67023744151136 139.74397497137377 8.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670251641375145 139.7439186197134 17.82 35.67015751168101 139.74388315582922 17.82 35.67014340197076 139.74393950732912 17.82 35.67023744151136 139.74397497137377 17.82 35.670251641375145 139.7439186197134 17.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-64148fe3-b3ab-4b20-afb6-555ea990da71"/>
							<gml:surfaceMember xlink:href="#poly-b9b5982b-bf90-4f8a-b4b2-b0c952c4d916"/>
							<gml:surfaceMember xlink:href="#poly-3ab658f9-66e3-46d7-ad1f-af5dddc5de2b"/>
							<gml:surfaceMember xlink:href="#poly-3eeec973-4a55-4ddf-a617-d15b213d3642"/>
							<gml:surfaceMember xlink:href="#poly-7daadf2e-57f0-47ff-be8e-ec286e7894e8"/>
							<gml:surfaceMember xlink:href="#poly-0f706a4a-7848-4404-bbe6-4c47bdfaec12"/>
							<gml:surfaceMember xlink:href="#poly-31bb3377-98fd-4cbc-9552-be470ede2621"/>
							<gml:surfaceMember xlink:href="#poly-41a32858-c804-433d-8726-28a63a66c138"/>
							<gml:surfaceMember xlink:href="#poly-e881bc06-3fd5-4cbf-b423-d8c5684e30be"/>
							<gml:surfaceMember xlink:href="#poly-15d46bc7-4070-4ba0-a733-7684ef1ba406"/>
							<gml:surfaceMember xlink:href="#poly-43d42b8c-5b05-4bac-9025-a388ef50e126"/>
							<gml:surfaceMember xlink:href="#poly-64aad055-42ab-4b2d-8d8c-f5cbf655df35"/>
							<gml:surfaceMember xlink:href="#poly-fb21e0f0-dc99-4d22-bc81-b6e8ce8641b6"/>
							<gml:surfaceMember xlink:href="#poly-980f486c-d5aa-4040-8310-d14344f9105f"/>
							<gml:surfaceMember xlink:href="#poly-17688588-1482-4b45-96d2-ca0f58ec21cd"/>
							<gml:surfaceMember xlink:href="#poly-7119fbe5-ff65-465c-9f3f-5d91e886b081"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-64148fe3-b3ab-4b20-afb6-555ea990da71">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-64148fe3-b3ab-4b20-afb6-555ea990da71">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-64148fe3-b3ab-4b20-afb6-555ea990da71">
											<gml:posList>35.67025164137513 139.7439186197134 8.23 35.670237441511354 139.74397497137377 8.23 35.67014340197077 139.74393950732912 8.23 35.670157511681026 139.74388315582922 8.23 35.67025164137513 139.7439186197134 8.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b9b5982b-bf90-4f8a-b4b2-b0c952c4d916">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b9b5982b-bf90-4f8a-b4b2-b0c952c4d916">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b9b5982b-bf90-4f8a-b4b2-b0c952c4d916">
											<gml:posList>35.67014340197077 139.74393950732912 14.7 35.67015881075472 139.74394532255832 18.3 35.67017294750881 139.74388897101844 18.3 35.670157511681026 139.74388315582922 14.7 35.67014340197077 139.74393950732912 14.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3ab658f9-66e3-46d7-ad1f-af5dddc5de2b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ab658f9-66e3-46d7-ad1f-af5dddc5de2b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ab658f9-66e3-46d7-ad1f-af5dddc5de2b">
											<gml:posList>35.67015881075472 139.74394532255832 18.3 35.67020125928036 139.7439613254135 18.3 35.67021080353099 139.7439231610741 18.3 35.67019101257522 139.74391532927172 18.3 35.67019549715812 139.74389746250938 18.3 35.67017294750881 139.74388897101844 18.3 35.67015881075472 139.74394532255832 18.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3eeec973-4a55-4ddf-a617-d15b213d3642">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3eeec973-4a55-4ddf-a617-d15b213d3642">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3eeec973-4a55-4ddf-a617-d15b213d3642">
											<gml:posList>35.67025164137513 139.7439186197134 20.8 35.67019549715812 139.74389746250938 20.8 35.67019101257522 139.74391532927172 20.8 35.67021080353099 139.7439231610741 20.8 35.67020125928036 139.7439613254135 20.8 35.670237441511354 139.74397497137377 20.8 35.67025164137513 139.7439186197134 20.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7daadf2e-57f0-47ff-be8e-ec286e7894e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7daadf2e-57f0-47ff-be8e-ec286e7894e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7daadf2e-57f0-47ff-be8e-ec286e7894e8">
											<gml:posList>35.670157511681026 139.74388315582922 14.7 35.67025164137513 139.7439186197134 8.23 35.670157511681026 139.74388315582922 8.23 35.670157511681026 139.74388315582922 14.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0f706a4a-7848-4404-bbe6-4c47bdfaec12">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0f706a4a-7848-4404-bbe6-4c47bdfaec12">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0f706a4a-7848-4404-bbe6-4c47bdfaec12">
											<gml:posList>35.670157511681026 139.74388315582922 14.7 35.67017294750881 139.74388897101844 18.3 35.67019549715812 139.74389746250938 18.3 35.67025164137513 139.7439186197134 8.23 35.670157511681026 139.74388315582922 14.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-31bb3377-98fd-4cbc-9552-be470ede2621">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31bb3377-98fd-4cbc-9552-be470ede2621">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31bb3377-98fd-4cbc-9552-be470ede2621">
											<gml:posList>35.67019101257522 139.74391532927172 18.3 35.67019101257522 139.74391532927172 20.8 35.67019549715812 139.74389746250938 20.8 35.67019549715812 139.74389746250938 18.3 35.67019101257522 139.74391532927172 18.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-41a32858-c804-433d-8726-28a63a66c138">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41a32858-c804-433d-8726-28a63a66c138">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41a32858-c804-433d-8726-28a63a66c138">
											<gml:posList>35.67019549715812 139.74389746250938 18.3 35.67019549715812 139.74389746250938 20.8 35.67025164137513 139.7439186197134 20.8 35.67025164137513 139.7439186197134 8.23 35.67019549715812 139.74389746250938 18.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e881bc06-3fd5-4cbf-b423-d8c5684e30be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e881bc06-3fd5-4cbf-b423-d8c5684e30be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e881bc06-3fd5-4cbf-b423-d8c5684e30be">
											<gml:posList>35.670157511681026 139.74388315582922 8.23 35.67014340197077 139.74393950732912 8.23 35.67014340197077 139.74393950732912 14.7 35.670157511681026 139.74388315582922 14.7 35.670157511681026 139.74388315582922 8.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-15d46bc7-4070-4ba0-a733-7684ef1ba406">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15d46bc7-4070-4ba0-a733-7684ef1ba406">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15d46bc7-4070-4ba0-a733-7684ef1ba406">
											<gml:posList>35.67021080353099 139.7439231610741 18.3 35.67021080353099 139.7439231610741 20.8 35.67019101257522 139.74391532927172 20.8 35.67019101257522 139.74391532927172 18.3 35.67021080353099 139.7439231610741 18.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-43d42b8c-5b05-4bac-9025-a388ef50e126">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-43d42b8c-5b05-4bac-9025-a388ef50e126">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-43d42b8c-5b05-4bac-9025-a388ef50e126">
											<gml:posList>35.67020125928036 139.7439613254135 18.3 35.67020125928036 139.7439613254135 20.8 35.67021080353099 139.7439231610741 20.8 35.67021080353099 139.7439231610741 18.3 35.67020125928036 139.7439613254135 18.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-64aad055-42ab-4b2d-8d8c-f5cbf655df35">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-64aad055-42ab-4b2d-8d8c-f5cbf655df35">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-64aad055-42ab-4b2d-8d8c-f5cbf655df35">
											<gml:posList>35.670237441511354 139.74397497137377 8.23 35.67025164137513 139.7439186197134 8.23 35.67025164137513 139.7439186197134 20.8 35.670237441511354 139.74397497137377 20.8 35.670237441511354 139.74397497137377 8.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fb21e0f0-dc99-4d22-bc81-b6e8ce8641b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb21e0f0-dc99-4d22-bc81-b6e8ce8641b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb21e0f0-dc99-4d22-bc81-b6e8ce8641b6">
											<gml:posList>35.670237441511354 139.74397497137377 8.23 35.67015881075472 139.74394532255832 18.3 35.67014340197077 139.74393950732912 14.7 35.670237441511354 139.74397497137377 8.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-980f486c-d5aa-4040-8310-d14344f9105f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-980f486c-d5aa-4040-8310-d14344f9105f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-980f486c-d5aa-4040-8310-d14344f9105f">
											<gml:posList>35.67014340197077 139.74393950732912 8.23 35.670237441511354 139.74397497137377 8.23 35.67014340197077 139.74393950732912 14.7 35.67014340197077 139.74393950732912 8.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-17688588-1482-4b45-96d2-ca0f58ec21cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17688588-1482-4b45-96d2-ca0f58ec21cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17688588-1482-4b45-96d2-ca0f58ec21cd">
											<gml:posList>35.670237441511354 139.74397497137377 8.23 35.67020125928036 139.7439613254135 18.3 35.67015881075472 139.74394532255832 18.3 35.670237441511354 139.74397497137377 8.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7119fbe5-ff65-465c-9f3f-5d91e886b081">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7119fbe5-ff65-465c-9f3f-5d91e886b081">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7119fbe5-ff65-465c-9f3f-5d91e886b081">
											<gml:posList>35.670237441511354 139.74397497137377 20.8 35.67020125928036 139.7439613254135 20.8 35.67020125928036 139.7439613254135 18.3 35.670237441511354 139.74397497137377 8.23 35.670237441511354 139.74397497137377 20.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10092</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">58.29</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>