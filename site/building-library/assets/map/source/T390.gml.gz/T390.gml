<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_707b5da3-d420-43e4-9caa-d58bfef73b3f">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">13.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67020372401677 139.7440882328656 0 35.67015181740105 139.74406858417075 0 35.67014865386384 139.74408112516144 0 35.67012871924711 139.7440740335831 0 35.67012378526157 139.7440936682168 0 35.670195545675206 139.7441208283602 0 35.67020372401677 139.7440882328656 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67020372401677 139.7440882328656 8.725 35.670195545675206 139.7441208283602 8.725 35.67012378526157 139.7440936682168 8.725 35.67012871924711 139.7440740335831 8.725 35.67014865386384 139.74408112516144 8.725 35.67015181740105 139.74406858417075 8.725 35.67020372401677 139.7440882328656 8.725</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67020372401677 139.7440882328656 8.725 35.67015181740105 139.74406858417075 8.725 35.67015181740105 139.74406858417075 22.57 35.67020372401677 139.7440882328656 22.57 35.67020372401677 139.7440882328656 8.725</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67015181740105 139.74406858417075 8.725 35.67014865386384 139.74408112516144 8.725 35.67014865386384 139.74408112516144 22.57 35.67015181740105 139.74406858417075 22.57 35.67015181740105 139.74406858417075 8.725</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67014865386384 139.74408112516144 8.725 35.67012871924711 139.7440740335831 8.725 35.67012871924711 139.7440740335831 22.57 35.67014865386384 139.74408112516144 22.57 35.67014865386384 139.74408112516144 8.725</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67012871924711 139.7440740335831 8.725 35.67012378526157 139.7440936682168 8.725 35.67012378526157 139.7440936682168 22.57 35.67012871924711 139.7440740335831 22.57 35.67012871924711 139.7440740335831 8.725</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67012378526157 139.7440936682168 8.725 35.670195545675206 139.7441208283602 8.725 35.670195545675206 139.7441208283602 22.57 35.67012378526157 139.7440936682168 22.57 35.67012378526157 139.7440936682168 8.725</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670195545675206 139.7441208283602 8.725 35.67020372401677 139.7440882328656 8.725 35.67020372401677 139.7440882328656 22.57 35.670195545675206 139.7441208283602 22.57 35.670195545675206 139.7441208283602 8.725</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67020372401677 139.7440882328656 22.57 35.67015181740105 139.74406858417075 22.57 35.67014865386384 139.74408112516144 22.57 35.67012871924711 139.7440740335831 22.57 35.67012378526157 139.7440936682168 22.57 35.670195545675206 139.7441208283602 22.57 35.67020372401677 139.7440882328656 22.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-122f54aa-dbc1-4fd2-a9b3-a7fef37179af"/>
							<gml:surfaceMember xlink:href="#poly-f65fa99f-3f84-404c-ae82-0ed0a3e94537"/>
							<gml:surfaceMember xlink:href="#poly-444cc5d2-ec79-487e-9f5d-34eda4f31982"/>
							<gml:surfaceMember xlink:href="#poly-695b10ab-3d7d-42f6-8691-11d32b4cda38"/>
							<gml:surfaceMember xlink:href="#poly-eabdb38b-33ee-4bc4-8b65-9b00932f6b19"/>
							<gml:surfaceMember xlink:href="#poly-a68fc0e4-de7f-460d-b5e4-b8dec9de1726"/>
							<gml:surfaceMember xlink:href="#poly-f3bc30ed-15d0-42aa-b7f0-ea65e2aa35c6"/>
							<gml:surfaceMember xlink:href="#poly-90471cf7-d2a6-4431-9376-51c7b8db4242"/>
							<gml:surfaceMember xlink:href="#poly-772f341d-898d-4312-929e-19cad004e87d"/>
							<gml:surfaceMember xlink:href="#poly-69469f3f-4666-405c-a025-494af0cd5c49"/>
							<gml:surfaceMember xlink:href="#poly-4c5a96c9-0087-40c2-895e-38ec629ca247"/>
							<gml:surfaceMember xlink:href="#poly-d775726c-668a-4931-96c9-9f787d37d8bc"/>
							<gml:surfaceMember xlink:href="#poly-65d800e9-6936-41d6-a916-331b5414d855"/>
							<gml:surfaceMember xlink:href="#poly-6684dd76-8362-4f23-b639-1bac7e4e98b5"/>
							<gml:surfaceMember xlink:href="#poly-bb2005d1-986f-46e3-ae64-092e4aef8bd8"/>
							<gml:surfaceMember xlink:href="#poly-6e873487-9fcd-49f4-967a-4a778efac19b"/>
							<gml:surfaceMember xlink:href="#poly-abc68251-4729-4710-9c72-2b4cc7281672"/>
							<gml:surfaceMember xlink:href="#poly-30b6b3e9-f214-4092-81df-6143a1284181"/>
							<gml:surfaceMember xlink:href="#poly-b1a3ef1c-caa2-4d42-bd53-1035fb198715"/>
							<gml:surfaceMember xlink:href="#poly-b121c6ac-c410-4a4f-89a6-3dd544087969"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_707b5da3-d420-43e4-9caa-d58bfef73b3f_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3359869b-f70a-4107-9433-758bfc695a39">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67011788920899 139.74405574204712 8.87 35.67015181740105 139.74406858417072 8.87 35.670148653863826 139.74408112516144 8.87 35.6701287192471 139.7440740335831 8.87 35.67012378526157 139.7440936682168 8.87 35.67010971087605 139.7440883375101 8.87 35.67011788920899 139.74405574204712 8.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-096c546f-b779-4693-a09c-91f140268a40">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-096c546f-b779-4693-a09c-91f140268a40_0">
											<gml:posList>35.67015181740105 139.74406858417072 20.4 35.67015181740105 139.74406858417072 8.87 35.67011788920899 139.74405574204712 8.87 35.67011788920899 139.74405574204712 20.4 35.67015181740105 139.74406858417072 20.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd27a3d9-42d8-41be-bcda-3d2c72390c39">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cd27a3d9-42d8-41be-bcda-3d2c72390c39_0">
											<gml:posList>35.67011788920899 139.74405574204712 20.4 35.67011788920899 139.74405574204712 8.87 35.67010971087605 139.7440883375101 8.87 35.67010971087605 139.7440883375101 20.4 35.67011788920899 139.74405574204712 20.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-798cadb8-d590-4724-9619-3e9dc26a4e40">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-798cadb8-d590-4724-9619-3e9dc26a4e40_0">
											<gml:posList>35.67011788920899 139.74405574204712 20.4 35.67010971087605 139.7440883375101 20.4 35.67012378526157 139.7440936682168 20.4 35.6701287192471 139.7440740335831 20.4 35.670148653863826 139.74408112516144 20.4 35.67015181740105 139.74406858417072 20.4 35.67011788920899 139.74405574204712 20.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-64697a8e-42b8-42bc-b17a-bd7bcd384096">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-64697a8e-42b8-42bc-b17a-bd7bcd384096_0">
											<gml:posList>35.670148653863826 139.74408112516144 20.4 35.670148653863826 139.74408112516144 8.87 35.67015181740105 139.74406858417072 8.87 35.67015181740105 139.74406858417072 20.4 35.670148653863826 139.74408112516144 20.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-abcb8cdd-7e58-4dc8-8d3a-ed978209749a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-abcb8cdd-7e58-4dc8-8d3a-ed978209749a_0">
											<gml:posList>35.6701287192471 139.7440740335831 20.4 35.6701287192471 139.7440740335831 8.87 35.670148653863826 139.74408112516144 8.87 35.670148653863826 139.74408112516144 20.4 35.6701287192471 139.7440740335831 20.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d66e68d-720b-403e-acd4-f0255accbf64">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d66e68d-720b-403e-acd4-f0255accbf64_0">
											<gml:posList>35.67012378526157 139.7440936682168 20.4 35.67012378526157 139.7440936682168 8.87 35.6701287192471 139.7440740335831 8.87 35.6701287192471 139.7440740335831 20.4 35.67012378526157 139.7440936682168 20.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca8aa799-c4ed-4cc6-accd-b6954f1cbfe3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ca8aa799-c4ed-4cc6-accd-b6954f1cbfe3_0">
											<gml:posList>35.67010971087605 139.7440883375101 20.4 35.67010971087605 139.7440883375101 8.87 35.67012378526157 139.7440936682168 8.87 35.67012378526157 139.7440936682168 20.4 35.67010971087605 139.7440883375101 20.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-122f54aa-dbc1-4fd2-a9b3-a7fef37179af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-122f54aa-dbc1-4fd2-a9b3-a7fef37179af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-122f54aa-dbc1-4fd2-a9b3-a7fef37179af">
											<gml:posList>35.670195545675185 139.7441208283602 8.725 35.67012378526157 139.7440936682168 8.725 35.6701287192471 139.7440740335831 8.725 35.670148653863826 139.74408112516144 8.725 35.67015181740105 139.74406858417072 8.725 35.67020372401676 139.7440882328656 8.725 35.670195545675185 139.7441208283602 8.725</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f65fa99f-3f84-404c-ae82-0ed0a3e94537">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f65fa99f-3f84-404c-ae82-0ed0a3e94537">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f65fa99f-3f84-404c-ae82-0ed0a3e94537">
											<gml:posList>35.6701287192471 139.7440740335831 23.1 35.67012378526157 139.7440936682168 23.1 35.67012716378714 139.7440914773039 23.1 35.670130525029684 139.74407812972242 23.1 35.6701287192471 139.7440740335831 23.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-444cc5d2-ec79-487e-9f5d-34eda4f31982">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-444cc5d2-ec79-487e-9f5d-34eda4f31982">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-444cc5d2-ec79-487e-9f5d-34eda4f31982">
											<gml:posList>35.670148653863826 139.74408112516144 23.1 35.6701287192471 139.7440740335831 23.1 35.670130525029684 139.74407812972242 23.1 35.67015045062424 139.74408521026575 23.1 35.670148653863826 139.74408112516144 23.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-695b10ab-3d7d-42f6-8691-11d32b4cda38">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-695b10ab-3d7d-42f6-8691-11d32b4cda38">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-695b10ab-3d7d-42f6-8691-11d32b4cda38">
											<gml:posList>35.67015181740105 139.74406858417072 23.1 35.670148653863826 139.74408112516144 23.1 35.67015045062424 139.74408521026575 23.1 35.67015360518912 139.74407272451603 23.1 35.67015181740105 139.74406858417072 23.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-eabdb38b-33ee-4bc4-8b65-9b00932f6b19">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eabdb38b-33ee-4bc4-8b65-9b00932f6b19">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eabdb38b-33ee-4bc4-8b65-9b00932f6b19">
											<gml:posList>35.67012378526157 139.7440936682168 23.1 35.670195545675185 139.7441208283602 23.1 35.67019375788878 139.74411668801162 23.1 35.67012716378714 139.7440914773039 23.1 35.67012378526157 139.7440936682168 23.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a68fc0e4-de7f-460d-b5e4-b8dec9de1726">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a68fc0e4-de7f-460d-b5e4-b8dec9de1726">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a68fc0e4-de7f-460d-b5e4-b8dec9de1726">
											<gml:posList>35.67019375788878 139.74411668801162 22.6 35.670200345491295 139.7440904237807 22.6 35.67015360518912 139.74407272451603 22.6 35.67015045062424 139.74408521026575 22.6 35.670130525029684 139.74407812972242 22.6 35.67012716378714 139.7440914773039 22.6 35.67019375788878 139.74411668801162 22.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f3bc30ed-15d0-42aa-b7f0-ea65e2aa35c6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f3bc30ed-15d0-42aa-b7f0-ea65e2aa35c6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f3bc30ed-15d0-42aa-b7f0-ea65e2aa35c6">
											<gml:posList>35.67020372401676 139.7440882328656 23.1 35.67015181740105 139.74406858417072 23.1 35.67015360518912 139.74407272451603 23.1 35.670200345491295 139.7440904237807 23.1 35.67020372401676 139.7440882328656 23.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-90471cf7-d2a6-4431-9376-51c7b8db4242">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-90471cf7-d2a6-4431-9376-51c7b8db4242">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-90471cf7-d2a6-4431-9376-51c7b8db4242">
											<gml:posList>35.670195545675185 139.7441208283602 23.1 35.67020372401676 139.7440882328656 23.1 35.670200345491295 139.7440904237807 23.1 35.67019375788878 139.74411668801162 23.1 35.670195545675185 139.7441208283602 23.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-772f341d-898d-4312-929e-19cad004e87d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-772f341d-898d-4312-929e-19cad004e87d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-772f341d-898d-4312-929e-19cad004e87d">
											<gml:posList>35.670200345491295 139.7440904237807 23.1 35.67015360518912 139.74407272451603 23.1 35.67015360518912 139.74407272451603 22.6 35.670200345491295 139.7440904237807 22.6 35.670200345491295 139.7440904237807 23.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-69469f3f-4666-405c-a025-494af0cd5c49">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69469f3f-4666-405c-a025-494af0cd5c49">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69469f3f-4666-405c-a025-494af0cd5c49">
											<gml:posList>35.67015181740105 139.74406858417072 8.725 35.670148653863826 139.74408112516144 8.725 35.670148653863826 139.74408112516144 23.1 35.67015181740105 139.74406858417072 23.1 35.67015181740105 139.74406858417072 8.725</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4c5a96c9-0087-40c2-895e-38ec629ca247">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c5a96c9-0087-40c2-895e-38ec629ca247">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c5a96c9-0087-40c2-895e-38ec629ca247">
											<gml:posList>35.670148653863826 139.74408112516144 8.725 35.6701287192471 139.7440740335831 8.725 35.6701287192471 139.7440740335831 23.1 35.670148653863826 139.74408112516144 23.1 35.670148653863826 139.74408112516144 8.725</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d775726c-668a-4931-96c9-9f787d37d8bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d775726c-668a-4931-96c9-9f787d37d8bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d775726c-668a-4931-96c9-9f787d37d8bc">
											<gml:posList>35.67020372401676 139.7440882328656 8.725 35.67015181740105 139.74406858417072 8.725 35.67015181740105 139.74406858417072 23.1 35.67020372401676 139.7440882328656 23.1 35.67020372401676 139.7440882328656 8.725</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-65d800e9-6936-41d6-a916-331b5414d855">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65d800e9-6936-41d6-a916-331b5414d855">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65d800e9-6936-41d6-a916-331b5414d855">
											<gml:posList>35.67015360518912 139.74407272451603 23.1 35.67015045062424 139.74408521026575 23.1 35.67015045062424 139.74408521026575 22.6 35.67015360518912 139.74407272451603 22.6 35.67015360518912 139.74407272451603 23.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6684dd76-8362-4f23-b639-1bac7e4e98b5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6684dd76-8362-4f23-b639-1bac7e4e98b5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6684dd76-8362-4f23-b639-1bac7e4e98b5">
											<gml:posList>35.67015045062424 139.74408521026575 23.1 35.670130525029684 139.74407812972242 23.1 35.670130525029684 139.74407812972242 22.6 35.67015045062424 139.74408521026575 22.6 35.67015045062424 139.74408521026575 23.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bb2005d1-986f-46e3-ae64-092e4aef8bd8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb2005d1-986f-46e3-ae64-092e4aef8bd8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb2005d1-986f-46e3-ae64-092e4aef8bd8">
											<gml:posList>35.6701287192471 139.7440740335831 8.725 35.67012378526157 139.7440936682168 8.725 35.67012378526157 139.7440936682168 23.1 35.6701287192471 139.7440740335831 23.1 35.6701287192471 139.7440740335831 8.725</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6e873487-9fcd-49f4-967a-4a778efac19b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e873487-9fcd-49f4-967a-4a778efac19b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e873487-9fcd-49f4-967a-4a778efac19b">
											<gml:posList>35.670130525029684 139.74407812972242 23.1 35.67012716378714 139.7440914773039 23.1 35.67012716378714 139.7440914773039 22.6 35.670130525029684 139.74407812972242 22.6 35.670130525029684 139.74407812972242 23.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-abc68251-4729-4710-9c72-2b4cc7281672">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-abc68251-4729-4710-9c72-2b4cc7281672">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-abc68251-4729-4710-9c72-2b4cc7281672">
											<gml:posList>35.67019375788878 139.74411668801162 23.1 35.670200345491295 139.7440904237807 23.1 35.670200345491295 139.7440904237807 22.6 35.67019375788878 139.74411668801162 22.6 35.67019375788878 139.74411668801162 23.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-30b6b3e9-f214-4092-81df-6143a1284181">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-30b6b3e9-f214-4092-81df-6143a1284181">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-30b6b3e9-f214-4092-81df-6143a1284181">
											<gml:posList>35.67012716378714 139.7440914773039 23.1 35.67019375788878 139.74411668801162 23.1 35.67019375788878 139.74411668801162 22.6 35.67012716378714 139.7440914773039 22.6 35.67012716378714 139.7440914773039 23.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b1a3ef1c-caa2-4d42-bd53-1035fb198715">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b1a3ef1c-caa2-4d42-bd53-1035fb198715">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b1a3ef1c-caa2-4d42-bd53-1035fb198715">
											<gml:posList>35.670195545675185 139.7441208283602 8.725 35.67020372401676 139.7440882328656 8.725 35.67020372401676 139.7440882328656 23.1 35.670195545675185 139.7441208283602 23.1 35.670195545675185 139.7441208283602 8.725</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b121c6ac-c410-4a4f-89a6-3dd544087969">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b121c6ac-c410-4a4f-89a6-3dd544087969">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b121c6ac-c410-4a4f-89a6-3dd544087969">
											<gml:posList>35.67012378526157 139.7440936682168 8.725 35.670195545675185 139.7441208283602 8.725 35.670195545675185 139.7441208283602 23.1 35.67012378526157 139.7440936682168 23.1 35.67012378526157 139.7440936682168 8.725</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8288</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">30.7685</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1221</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>