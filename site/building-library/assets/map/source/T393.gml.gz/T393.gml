<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_71ce04d6-7324-444e-99cd-de7e697c4add">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">18.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>7</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.667432481527364 139.7423216610761 0 35.667399567728715 139.74230358324093 0 35.667350151121475 139.7422753619839 0 35.667320644788965 139.74235304773273 0 35.66754987273574 139.74248390212125 0 35.66757847978034 139.74240886822764 0 35.66754213877693 139.7423881432024 0 35.66754672660066 139.74237598754277 0 35.66748856293994 139.74234280547702 0 35.667490991721714 139.74233628566265 0 35.667471243143844 139.74232504129773 0 35.66747322207315 139.74231962658075 0 35.66744044302109 139.7423009410623 0 35.667432481527364 139.7423216610761 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667432481527364 139.7423216610761 29.315 35.66744044302109 139.7423009410623 29.315 35.66747322207315 139.74231962658075 29.315 35.667471243143844 139.74232504129773 29.315 35.667490991721714 139.74233628566265 29.315 35.66748856293994 139.74234280547702 29.315 35.66754672660066 139.74237598754277 29.315 35.66754213877693 139.7423881432024 29.315 35.66757847978034 139.74240886822764 29.315 35.66754987273574 139.74248390212125 29.315 35.667320644788965 139.74235304773273 29.315 35.667350151121475 139.7422753619839 29.315 35.667399567728715 139.74230358324093 29.315 35.667432481527364 139.7423216610761 29.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667432481527364 139.7423216610761 29.315 35.667399567728715 139.74230358324093 29.315 35.667399567728715 139.74230358324093 48.05 35.667432481527364 139.7423216610761 48.05 35.667432481527364 139.7423216610761 29.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667399567728715 139.74230358324093 29.315 35.667350151121475 139.7422753619839 29.315 35.667350151121475 139.7422753619839 48.05 35.667399567728715 139.74230358324093 48.05 35.667399567728715 139.74230358324093 29.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667350151121475 139.7422753619839 29.315 35.667320644788965 139.74235304773273 29.315 35.667320644788965 139.74235304773273 48.05 35.667350151121475 139.7422753619839 48.05 35.667350151121475 139.7422753619839 29.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667320644788965 139.74235304773273 29.315 35.66754987273574 139.74248390212125 29.315 35.66754987273574 139.74248390212125 48.05 35.667320644788965 139.74235304773273 48.05 35.667320644788965 139.74235304773273 29.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66754987273574 139.74248390212125 29.315 35.66757847978034 139.74240886822764 29.315 35.66757847978034 139.74240886822764 48.05 35.66754987273574 139.74248390212125 48.05 35.66754987273574 139.74248390212125 29.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66757847978034 139.74240886822764 29.315 35.66754213877693 139.7423881432024 29.315 35.66754213877693 139.7423881432024 48.05 35.66757847978034 139.74240886822764 48.05 35.66757847978034 139.74240886822764 29.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66754213877693 139.7423881432024 29.315 35.66754672660066 139.74237598754277 29.315 35.66754672660066 139.74237598754277 48.05 35.66754213877693 139.7423881432024 48.05 35.66754213877693 139.7423881432024 29.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66754672660066 139.74237598754277 29.315 35.66748856293994 139.74234280547702 29.315 35.66748856293994 139.74234280547702 48.05 35.66754672660066 139.74237598754277 48.05 35.66754672660066 139.74237598754277 29.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66748856293994 139.74234280547702 29.315 35.667490991721714 139.74233628566265 29.315 35.667490991721714 139.74233628566265 48.05 35.66748856293994 139.74234280547702 48.05 35.66748856293994 139.74234280547702 29.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667490991721714 139.74233628566265 29.315 35.667471243143844 139.74232504129773 29.315 35.667471243143844 139.74232504129773 48.05 35.667490991721714 139.74233628566265 48.05 35.667490991721714 139.74233628566265 29.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667471243143844 139.74232504129773 29.315 35.66747322207315 139.74231962658075 29.315 35.66747322207315 139.74231962658075 48.05 35.667471243143844 139.74232504129773 48.05 35.667471243143844 139.74232504129773 29.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66747322207315 139.74231962658075 29.315 35.66744044302109 139.7423009410623 29.315 35.66744044302109 139.7423009410623 48.05 35.66747322207315 139.74231962658075 48.05 35.66747322207315 139.74231962658075 29.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66744044302109 139.7423009410623 29.315 35.667432481527364 139.7423216610761 29.315 35.667432481527364 139.7423216610761 48.05 35.66744044302109 139.7423009410623 48.05 35.66744044302109 139.7423009410623 29.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667432481527364 139.7423216610761 48.05 35.667399567728715 139.74230358324093 48.05 35.667350151121475 139.7422753619839 48.05 35.667320644788965 139.74235304773273 48.05 35.66754987273574 139.74248390212125 48.05 35.66757847978034 139.74240886822764 48.05 35.66754213877693 139.7423881432024 48.05 35.66754672660066 139.74237598754277 48.05 35.66748856293994 139.74234280547702 48.05 35.667490991721714 139.74233628566265 48.05 35.667471243143844 139.74232504129773 48.05 35.66747322207315 139.74231962658075 48.05 35.66744044302109 139.7423009410623 48.05 35.667432481527364 139.7423216610761 48.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-7af13862-c460-45b2-b0bd-8fbcf9059f1d"/>
							<gml:surfaceMember xlink:href="#poly-1c4ad2ed-bf9e-4774-a28a-f66910ab59d5"/>
							<gml:surfaceMember xlink:href="#poly-a105b5df-e2cb-4fd6-b46e-d84605229611"/>
							<gml:surfaceMember xlink:href="#poly-d1f6c444-ed8b-4956-8478-85807d147657"/>
							<gml:surfaceMember xlink:href="#poly-bb855bab-f9db-40da-8a51-7cf0bc10e5b5"/>
							<gml:surfaceMember xlink:href="#poly-661c0b33-2714-42e0-9dad-2963ea6a03c0"/>
							<gml:surfaceMember xlink:href="#poly-167c094c-f566-4594-8cfa-b5fec0feed88"/>
							<gml:surfaceMember xlink:href="#poly-57c89ff2-03d3-4386-8668-356fd3bebecf"/>
							<gml:surfaceMember xlink:href="#poly-d8a78d9c-b336-4a70-94a5-2557bbd03c8c"/>
							<gml:surfaceMember xlink:href="#poly-8beb13e8-dbaa-4e6a-8dd3-b5098211fddb"/>
							<gml:surfaceMember xlink:href="#poly-d628b8fa-98cc-4d3a-9fbb-ce7d31b96aca"/>
							<gml:surfaceMember xlink:href="#poly-8f4f7321-c4b7-429d-bca2-b5b5929eacb3"/>
							<gml:surfaceMember xlink:href="#poly-077f9c92-e80a-43f4-8d66-525febf9ac0c"/>
							<gml:surfaceMember xlink:href="#poly-d500309c-0c9e-4715-b093-998e4e5d66f7"/>
							<gml:surfaceMember xlink:href="#poly-9ce2be27-fd28-4a2d-b037-e0f2671a54f7"/>
							<gml:surfaceMember xlink:href="#poly-dbc2ec76-0497-4510-a955-2a4c075e68c7"/>
							<gml:surfaceMember xlink:href="#poly-a414e85f-4baf-4e90-ad7f-51986ab4447c"/>
							<gml:surfaceMember xlink:href="#poly-18a8a923-2196-437d-b95c-4fcf259bd3d5"/>
							<gml:surfaceMember xlink:href="#poly-011b3392-fecf-466c-9223-b613bcb1945d"/>
							<gml:surfaceMember xlink:href="#poly-958ac6c2-d243-4580-8ca5-651384a73ffd"/>
							<gml:surfaceMember xlink:href="#poly-fbda9ef3-2a56-4952-aa35-fbece45c4cb0"/>
							<gml:surfaceMember xlink:href="#poly-efb08d97-df9b-4c8e-9d9b-67d55e881334"/>
							<gml:surfaceMember xlink:href="#poly-80b11773-f33d-4246-b505-cbea11cc568d"/>
							<gml:surfaceMember xlink:href="#poly-c185250d-806d-4acc-b94c-b39bda0251d8"/>
							<gml:surfaceMember xlink:href="#poly-aecea577-4f17-49e0-8b14-5e1c178426b3"/>
							<gml:surfaceMember xlink:href="#poly-fe596431-4194-48e8-b094-10c0dac0082e"/>
							<gml:surfaceMember xlink:href="#poly-83652928-f080-4afe-bcf7-35c104b88033"/>
							<gml:surfaceMember xlink:href="#poly-cdd4739e-f060-4ba7-8a4a-6a613c2026f0"/>
							<gml:surfaceMember xlink:href="#poly-2cfbd17b-661e-4eaa-8300-6d425a6109ad"/>
							<gml:surfaceMember xlink:href="#poly-cd34c132-d24c-45eb-9129-a2fa3fa5d6e2"/>
							<gml:surfaceMember xlink:href="#poly-9a8a8075-a2fa-4ea2-bc33-0c25f9547af2"/>
							<gml:surfaceMember xlink:href="#poly-3191b144-fe84-4aa6-b98e-1f30dfaf95d9"/>
							<gml:surfaceMember xlink:href="#poly-ce6e4059-6ee0-4c49-871e-7d1ef45bfc4e"/>
							<gml:surfaceMember xlink:href="#poly-58c130fd-94b1-4b1c-bdfc-1f3e7258f8cf"/>
							<gml:surfaceMember xlink:href="#poly-95868113-42f6-46e1-88de-38cf849c6efc"/>
							<gml:surfaceMember xlink:href="#poly-71c9d580-993f-4830-990c-08e1628ef3d6"/>
							<gml:surfaceMember xlink:href="#poly-8f1fefa1-43d7-4b30-b2c6-b409d454504e"/>
							<gml:surfaceMember xlink:href="#poly-45ec767b-5ed5-4494-ab4d-f7dd9e50cf6a"/>
							<gml:surfaceMember xlink:href="#poly-8616acdf-7147-4fe6-9f9a-fc43ec9a14ae"/>
							<gml:surfaceMember xlink:href="#poly-30fd9981-5ec3-48c4-bd9d-0e285f6a0eb8"/>
							<gml:surfaceMember xlink:href="#poly-51037cae-b41a-42ee-91a2-69fa253aa3e6"/>
							<gml:surfaceMember xlink:href="#poly-17ee56fa-351b-454d-9152-e289c63193c4"/>
							<gml:surfaceMember xlink:href="#poly-87e4215e-1478-454d-956a-27f35d596dd6"/>
							<gml:surfaceMember xlink:href="#poly-998df9e0-3b9f-429c-95b4-6a3285d60c3b"/>
							<gml:surfaceMember xlink:href="#poly-f52a5a09-cf28-4b48-a5be-2a048964a55e"/>
							<gml:surfaceMember xlink:href="#poly-1c13e667-f8bc-4143-a15c-49dd75176264"/>
							<gml:surfaceMember xlink:href="#poly-9ce921c7-e591-44ad-bd9b-f6c01ab335f5"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_71ce04d6-7324-444e-99cd-de7e697c4add_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04719251-b7a2-4849-9bef-6f71652c5b87">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66743473100196 139.74231642278818 51.9 35.667435371252125 139.74231678657463 51.9 35.66743293332407 139.7423231296618 51.9 35.66743228406853 139.7423227769314 51.9 35.66743473100196 139.74231642278818 51.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e2a9dec-9911-401c-bebd-5062cb386c89">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66743228406853 139.7423227769314 50.993 35.66743293332407 139.7423231296618 50.993 35.667435371252125 139.74231678657463 50.993 35.66744616537597 139.74232298209336 50.993 35.66744036294128 139.7423380994082 50.993 35.66742892855974 139.7423315290555 50.993 35.66743228406853 139.7423227769314 50.993</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4abb3a63-d059-4986-beab-1c01836ce068">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66750268395967 139.74237396087935 50.993 35.667509331460984 139.74235589335086 50.993 35.66752674447913 139.74236581487426 50.993 35.66752009698469 139.74238389345172 50.993 35.66750268395967 139.74237396087935 50.993</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-009e08c5-c328-45c6-afda-55f0a0657f35">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66752700534319 139.74236510764285 51.9 35.66752674447913 139.74236581487426 51.9 35.667509331460984 139.74235589335086 51.9 35.667509592316634 139.74235517507373 51.9 35.66752700534319 139.74236510764285 51.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd02f5ea-0a54-4925-99a7-fc20dd0979f6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bd02f5ea-0a54-4925-99a7-fc20dd0979f6_0">
											<gml:posList>35.66743473100196 139.74231642278818 52.931 35.66744616537597 139.74232298209336 52.931 35.66744616537597 139.74232298209336 50.993 35.667435371252125 139.74231678657463 50.993 35.667435371252125 139.74231678657463 51.9 35.66743473100196 139.74231642278818 51.9 35.66743473100196 139.74231642278818 52.931</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9842a9d2-9d8d-4e8e-a4ae-0eaae92eeec6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9842a9d2-9d8d-4e8e-a4ae-0eaae92eeec6_0">
											<gml:posList>35.66743293332407 139.7423231296618 51.9 35.667435371252125 139.74231678657463 51.9 35.667435371252125 139.74231678657463 50.993 35.66743293332407 139.7423231296618 50.993 35.66743293332407 139.7423231296618 51.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4489106-eafa-47b5-8545-0980567108b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4489106-eafa-47b5-8545-0980567108b2_0">
											<gml:posList>35.66743293332407 139.7423231296618 50.993 35.66743228406853 139.7423227769314 50.993 35.66743228406853 139.7423227769314 51.9 35.66743293332407 139.7423231296618 51.9 35.66743293332407 139.7423231296618 50.993</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b6d9ff61-c7d8-4139-9101-748d77cfb387">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b6d9ff61-c7d8-4139-9101-748d77cfb387_0">
											<gml:posList>35.66743228406853 139.7423227769314 51.9 35.66743228406853 139.7423227769314 50.993 35.66742892855974 139.7423315290555 50.993 35.66742892855974 139.7423315290555 52.931 35.66743473100196 139.74231642278818 52.931 35.66743473100196 139.74231642278818 51.9 35.66743228406853 139.7423227769314 51.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57e14d55-2f8a-4f94-9d3e-c28fa230305f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-57e14d55-2f8a-4f94-9d3e-c28fa230305f_0">
											<gml:posList>35.66744036294128 139.7423380994082 52.931 35.66744616537597 139.74232298209336 52.931 35.66743473100196 139.74231642278818 52.931 35.66742892855974 139.7423315290555 52.931 35.66744036294128 139.7423380994082 52.931</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8e4de45-2da9-42fc-9a1d-20b4e65ad92a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d8e4de45-2da9-42fc-9a1d-20b4e65ad92a_0">
											<gml:posList>35.66744036294128 139.7423380994082 50.993 35.66744616537597 139.74232298209336 50.993 35.66744616537597 139.74232298209336 52.931 35.66744036294128 139.7423380994082 52.931 35.66744036294128 139.7423380994082 50.993</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd801762-1503-40c3-bb76-c0e08aa5509a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bd801762-1503-40c3-bb76-c0e08aa5509a_0">
											<gml:posList>35.66742892855974 139.7423315290555 50.993 35.66744036294128 139.7423380994082 50.993 35.66744036294128 139.7423380994082 52.931 35.66742892855974 139.7423315290555 52.931 35.66742892855974 139.7423315290555 50.993</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3058d27-d76b-4ed5-8f89-1d8cc0058626">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b3058d27-d76b-4ed5-8f89-1d8cc0058626_0">
											<gml:posList>35.667509331460984 139.74235589335086 51.9 35.667509331460984 139.74235589335086 50.993 35.66750268395967 139.74237396087935 50.993 35.66750268395967 139.74237396087935 52.817 35.667509592316634 139.74235517507373 52.817 35.667509592316634 139.74235517507373 51.9 35.667509331460984 139.74235589335086 51.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59872067-f290-495e-b9e2-0dd0504e54fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-59872067-f290-495e-b9e2-0dd0504e54fd_0">
											<gml:posList>35.66750268395967 139.74237396087935 50.993 35.66752009698469 139.74238389345172 50.993 35.66752009698469 139.74238389345172 52.817 35.66750268395967 139.74237396087935 52.817 35.66750268395967 139.74237396087935 50.993</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-476361ba-00cf-4aa1-93f7-184d9e91683f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-476361ba-00cf-4aa1-93f7-184d9e91683f_0">
											<gml:posList>35.66750268395967 139.74237396087935 52.817 35.66752009698469 139.74238389345172 52.817 35.66752700534319 139.74236510764285 52.817 35.667509592316634 139.74235517507373 52.817 35.66750268395967 139.74237396087935 52.817</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e47d99b3-e871-40dd-bd53-eca79ad7d5a2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e47d99b3-e871-40dd-bd53-eca79ad7d5a2_0">
											<gml:posList>35.66752674447913 139.74236581487426 51.9 35.66752674447913 139.74236581487426 50.993 35.667509331460984 139.74235589335086 50.993 35.667509331460984 139.74235589335086 51.9 35.66752674447913 139.74236581487426 51.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d73dd30-ecd9-4b02-a87d-bca792ffde9a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3d73dd30-ecd9-4b02-a87d-bca792ffde9a_0">
											<gml:posList>35.66752700534319 139.74236510764285 51.9 35.667509592316634 139.74235517507373 51.9 35.667509592316634 139.74235517507373 52.817 35.66752700534319 139.74236510764285 52.817 35.66752700534319 139.74236510764285 51.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e738fefe-072b-473d-acfd-5d3e72316a90">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e738fefe-072b-473d-acfd-5d3e72316a90_0">
											<gml:posList>35.66752700534319 139.74236510764285 52.817 35.66752009698469 139.74238389345172 52.817 35.66752009698469 139.74238389345172 50.993 35.66752674447913 139.74236581487426 50.993 35.66752674447913 139.74236581487426 51.9 35.66752700534319 139.74236510764285 51.9 35.66752700534319 139.74236510764285 52.817</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_71ce04d6-7324-444e-99cd-de7e697c4add_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c048e1f6-856d-4d9a-b536-f671dc699c9c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66739956772872 139.74230358324093 29.32 35.66740766396596 139.74228225555913 29.32 35.66744044302109 139.7423009410623 29.32 35.66743248152735 139.7423216610761 29.32 35.66739956772872 139.74230358324093 29.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b38eb491-7709-47b0-87d3-d38efd1f27e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b38eb491-7709-47b0-87d3-d38efd1f27e4_0">
											<gml:posList>35.66744044302109 139.7423009410623 51.9 35.66744044302109 139.7423009410623 29.32 35.66740766396596 139.74228225555913 29.32 35.66740766396596 139.74228225555913 51.9 35.66744044302109 139.7423009410623 51.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f816a848-bd0a-476b-8fb8-6a1e8267b64d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f816a848-bd0a-476b-8fb8-6a1e8267b64d_0">
											<gml:posList>35.66740766396596 139.74228225555913 51.9 35.66740766396596 139.74228225555913 29.32 35.66739956772872 139.74230358324093 29.32 35.66739956772872 139.74230358324093 51.9 35.66740766396596 139.74228225555913 51.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9fcc4a50-e6da-4e88-af80-0860373f9560">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9fcc4a50-e6da-4e88-af80-0860373f9560_0">
											<gml:posList>35.66739956772872 139.74230358324093 51.9 35.66743248152735 139.7423216610761 51.9 35.66744044302109 139.7423009410623 51.9 35.66740766396596 139.74228225555913 51.9 35.66739956772872 139.74230358324093 51.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-719aef46-bf11-4ebb-b5bf-2cedce1b00ee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-719aef46-bf11-4ebb-b5bf-2cedce1b00ee_0">
											<gml:posList>35.66743248152735 139.7423216610761 51.9 35.66743248152735 139.7423216610761 29.32 35.66744044302109 139.7423009410623 29.32 35.66744044302109 139.7423009410623 51.9 35.66743248152735 139.7423216610761 51.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94b65cc5-24d7-4c62-a901-c156dd5cac64">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-94b65cc5-24d7-4c62-a901-c156dd5cac64_0">
											<gml:posList>35.66739956772872 139.74230358324093 51.9 35.66739956772872 139.74230358324093 29.32 35.66743248152735 139.7423216610761 29.32 35.66743248152735 139.7423216610761 51.9 35.66739956772872 139.74230358324093 51.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-7af13862-c460-45b2-b0bd-8fbcf9059f1d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7af13862-c460-45b2-b0bd-8fbcf9059f1d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7af13862-c460-45b2-b0bd-8fbcf9059f1d">
											<gml:posList>35.66754213877691 139.74238814320236 29.315 35.667578479780325 139.74240886822764 29.315 35.66754987273574 139.74248390212125 29.315 35.66732064478895 139.74235304773273 29.315 35.66735015112148 139.7422753619839 29.315 35.66739956772872 139.74230358324093 29.315 35.66743248152735 139.7423216610761 29.315 35.66744044302109 139.7423009410623 29.315 35.66747322207317 139.74231962658072 29.315 35.667471243143844 139.7423250412977 29.315 35.667490991721714 139.74233628566265 29.315 35.66748856293993 139.74234280547702 29.315 35.66754672660065 139.74237598754274 29.315 35.66754213877691 139.74238814320236 29.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1c4ad2ed-bf9e-4774-a28a-f66910ab59d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c4ad2ed-bf9e-4774-a28a-f66910ab59d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c4ad2ed-bf9e-4774-a28a-f66910ab59d5">
											<gml:posList>35.66735964955084 139.7423441999403 51.9 35.667360866003456 139.7423436683595 51.9 35.66737991925055 139.74229359800967 51.9 35.667379467436774 139.74229210733338 51.9 35.66735964955084 139.7423441999403 51.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a105b5df-e2cb-4fd6-b46e-d84605229611">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a105b5df-e2cb-4fd6-b46e-d84605229611">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a105b5df-e2cb-4fd6-b46e-d84605229611">
											<gml:posList>35.66739956772872 139.74230358324093 51.9 35.667379467436774 139.74229210733338 51.9 35.66737991925055 139.74229359800967 51.9 35.66739919894245 139.74230461092355 51.9 35.66739956772872 139.74230358324093 51.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d1f6c444-ed8b-4956-8478-85807d147657">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1f6c444-ed8b-4956-8478-85807d147657">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1f6c444-ed8b-4956-8478-85807d147657">
											<gml:posList>35.66743248152735 139.7423216610761 51.9 35.66739956772872 139.74230358324093 51.9 35.66739919894245 139.74230461092355 51.9 35.66743293332407 139.7423231296618 51.9 35.66743248152735 139.7423216610761 51.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bb855bab-f9db-40da-8a51-7cf0bc10e5b5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb855bab-f9db-40da-8a51-7cf0bc10e5b5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb855bab-f9db-40da-8a51-7cf0bc10e5b5">
											<gml:posList>35.66743248152735 139.7423216610761 51.9 35.66743293332407 139.7423231296618 51.9 35.66744088582102 139.74230243175 51.9 35.66744044302109 139.7423009410623 51.9 35.66743248152735 139.7423216610761 51.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-661c0b33-2714-42e0-9dad-2963ea6a03c0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-661c0b33-2714-42e0-9dad-2963ea6a03c0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-661c0b33-2714-42e0-9dad-2963ea6a03c0">
											<gml:posList>35.66732463894698 139.7423425386083 45.2 35.66732064478895 139.74235304773273 45.2 35.66754987273574 139.74248390212125 45.2 35.66755375898198 139.7424737134258 45.2 35.66732463894698 139.7423425386083 45.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-167c094c-f566-4594-8cfa-b5fec0feed88">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-167c094c-f566-4594-8cfa-b5fec0feed88">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-167c094c-f566-4594-8cfa-b5fec0feed88">
											<gml:posList>35.66753947895085 139.7424468108256 51.9 35.667539027147306 139.74244533119136 51.9 35.667360866003456 139.7423436683595 51.9 35.66735964955084 139.7423441999403 51.9 35.66753947895085 139.7424468108256 51.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-57c89ff2-03d3-4386-8668-356fd3bebecf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-57c89ff2-03d3-4386-8668-356fd3bebecf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-57c89ff2-03d3-4386-8668-356fd3bebecf">
											<gml:posList>35.66755375898198 139.7424737134258 47.3 35.667578479780325 139.74240886822764 47.3 35.66755789255745 139.7423971277195 47.3 35.66753947895085 139.7424468108256 47.3 35.66735964955084 139.7423441999403 47.3 35.667379467436774 139.74229210733338 47.3 35.66735015112148 139.7422753619839 47.3 35.66732463894698 139.7423425386083 47.3 35.66755375898198 139.7424737134258 47.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d8a78d9c-b336-4a70-94a5-2557bbd03c8c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d8a78d9c-b336-4a70-94a5-2557bbd03c8c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d8a78d9c-b336-4a70-94a5-2557bbd03c8c">
											<gml:posList>35.66744044302109 139.7423009410623 51.9 35.66744088582102 139.74230243175 51.9 35.66747203267857 139.7423201802237 51.9 35.66747322207317 139.74231962658072 51.9 35.66744044302109 139.7423009410623 51.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8beb13e8-dbaa-4e6a-8dd3-b5098211fddb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8beb13e8-dbaa-4e6a-8dd3-b5098211fddb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8beb13e8-dbaa-4e6a-8dd3-b5098211fddb">
											<gml:posList>35.6675409313462 139.74238868581938 50.993 35.66754552818374 139.74237653014976 50.993 35.66748736453149 139.74234335913 50.993 35.667489793304966 139.74233682826986 50.993 35.66747005374921 139.74232559494058 50.993 35.66747203267857 139.7423201802237 50.993 35.66744088582102 139.74230243175 50.993 35.66743293332407 139.7423231296618 50.993 35.66739919894245 139.74230461092355 50.993 35.66737991925055 139.74229359800967 50.993 35.667360866003456 139.7423436683595 50.993 35.667539027147306 139.74244533119136 50.993 35.66755669414043 139.74239767032626 50.993 35.6675409313462 139.74238868581938 50.993</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d628b8fa-98cc-4d3a-9fbb-ce7d31b96aca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d628b8fa-98cc-4d3a-9fbb-ce7d31b96aca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d628b8fa-98cc-4d3a-9fbb-ce7d31b96aca">
											<gml:posList>35.667471243143844 139.7423250412977 51.9 35.66747322207317 139.74231962658072 51.9 35.66747203267857 139.7423201802237 51.9 35.66747005374921 139.74232559494058 51.9 35.667471243143844 139.7423250412977 51.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8f4f7321-c4b7-429d-bca2-b5b5929eacb3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f4f7321-c4b7-429d-bca2-b5b5929eacb3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f4f7321-c4b7-429d-bca2-b5b5929eacb3">
											<gml:posList>35.667471243143844 139.7423250412977 51.9 35.66747005374921 139.74232559494058 51.9 35.667489793304966 139.74233682826986 51.9 35.667490991721714 139.74233628566265 51.9 35.667471243143844 139.7423250412977 51.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-077f9c92-e80a-43f4-8d66-525febf9ac0c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-077f9c92-e80a-43f4-8d66-525febf9ac0c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-077f9c92-e80a-43f4-8d66-525febf9ac0c">
											<gml:posList>35.66748856293993 139.74234280547702 51.9 35.667490991721714 139.74233628566265 51.9 35.667489793304966 139.74233682826986 51.9 35.66748736453149 139.74234335913 51.9 35.66748856293993 139.74234280547702 51.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d500309c-0c9e-4715-b093-998e4e5d66f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d500309c-0c9e-4715-b093-998e4e5d66f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d500309c-0c9e-4715-b093-998e4e5d66f7">
											<gml:posList>35.66748856293993 139.74234280547702 51.9 35.66748736453149 139.74234335913 51.9 35.66754552818374 139.74237653014976 51.9 35.66754672660065 139.74237598754274 51.9 35.66748856293993 139.74234280547702 51.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9ce2be27-fd28-4a2d-b037-e0f2671a54f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ce2be27-fd28-4a2d-b037-e0f2671a54f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ce2be27-fd28-4a2d-b037-e0f2671a54f7">
											<gml:posList>35.66754213877691 139.74238814320236 51.9 35.66754672660065 139.74237598754274 51.9 35.66754552818374 139.74237653014976 51.9 35.6675409313462 139.74238868581938 51.9 35.66754213877691 139.74238814320236 51.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dbc2ec76-0497-4510-a955-2a4c075e68c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dbc2ec76-0497-4510-a955-2a4c075e68c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dbc2ec76-0497-4510-a955-2a4c075e68c7">
											<gml:posList>35.66755789255745 139.7423971277195 51.9 35.66755669414043 139.74239767032626 51.9 35.667539027147306 139.74244533119136 51.9 35.66753947895085 139.7424468108256 51.9 35.66755789255745 139.7423971277195 51.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a414e85f-4baf-4e90-ad7f-51986ab4447c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a414e85f-4baf-4e90-ad7f-51986ab4447c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a414e85f-4baf-4e90-ad7f-51986ab4447c">
											<gml:posList>35.66754213877691 139.74238814320236 51.9 35.6675409313462 139.74238868581938 51.9 35.66755669414043 139.74239767032626 51.9 35.66755789255745 139.7423971277195 51.9 35.66754213877691 139.74238814320236 51.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-18a8a923-2196-437d-b95c-4fcf259bd3d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18a8a923-2196-437d-b95c-4fcf259bd3d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18a8a923-2196-437d-b95c-4fcf259bd3d5">
											<gml:posList>35.66748736453149 139.74234335913 51.9 35.66748736453149 139.74234335913 50.993 35.66754552818374 139.74237653014976 50.993 35.66754552818374 139.74237653014976 51.9 35.66748736453149 139.74234335913 51.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-011b3392-fecf-466c-9223-b613bcb1945d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-011b3392-fecf-466c-9223-b613bcb1945d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-011b3392-fecf-466c-9223-b613bcb1945d">
											<gml:posList>35.6675409313462 139.74238868581938 51.9 35.6675409313462 139.74238868581938 50.993 35.66755669414043 139.74239767032626 50.993 35.66755669414043 139.74239767032626 51.9 35.6675409313462 139.74238868581938 51.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-958ac6c2-d243-4580-8ca5-651384a73ffd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-958ac6c2-d243-4580-8ca5-651384a73ffd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-958ac6c2-d243-4580-8ca5-651384a73ffd">
											<gml:posList>35.66735015112148 139.7422753619839 29.315 35.66735015112148 139.7422753619839 47.3 35.667379467436774 139.74229210733338 47.3 35.667379467436774 139.74229210733338 51.9 35.66739956772872 139.74230358324093 51.9 35.66739956772872 139.74230358324093 29.315 35.66735015112148 139.7422753619839 29.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fbda9ef3-2a56-4952-aa35-fbece45c4cb0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fbda9ef3-2a56-4952-aa35-fbece45c4cb0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fbda9ef3-2a56-4952-aa35-fbece45c4cb0">
											<gml:posList>35.66737991925055 139.74229359800967 51.9 35.66737991925055 139.74229359800967 50.993 35.66739919894245 139.74230461092355 50.993 35.66739919894245 139.74230461092355 51.9 35.66737991925055 139.74229359800967 51.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-efb08d97-df9b-4c8e-9d9b-67d55e881334">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-efb08d97-df9b-4c8e-9d9b-67d55e881334">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-efb08d97-df9b-4c8e-9d9b-67d55e881334">
											<gml:posList>35.66747322207317 139.74231962658072 29.315 35.66744044302109 139.7423009410623 29.315 35.66744044302109 139.7423009410623 51.9 35.66747322207317 139.74231962658072 51.9 35.66747322207317 139.74231962658072 29.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-80b11773-f33d-4246-b505-cbea11cc568d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-80b11773-f33d-4246-b505-cbea11cc568d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-80b11773-f33d-4246-b505-cbea11cc568d">
											<gml:posList>35.66743248152735 139.7423216610761 51.9 35.66744044302109 139.7423009410623 51.9 35.66744044302109 139.7423009410623 29.315 35.66743248152735 139.7423216610761 29.315 35.66743248152735 139.7423216610761 51.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c185250d-806d-4acc-b94c-b39bda0251d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c185250d-806d-4acc-b94c-b39bda0251d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c185250d-806d-4acc-b94c-b39bda0251d8">
											<gml:posList>35.66744088582102 139.74230243175 51.9 35.66744088582102 139.74230243175 50.993 35.66747203267857 139.7423201802237 50.993 35.66747203267857 139.7423201802237 51.9 35.66744088582102 139.74230243175 51.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aecea577-4f17-49e0-8b14-5e1c178426b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aecea577-4f17-49e0-8b14-5e1c178426b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aecea577-4f17-49e0-8b14-5e1c178426b3">
											<gml:posList>35.66743248152735 139.7423216610761 29.315 35.66739956772872 139.74230358324093 29.315 35.66739956772872 139.74230358324093 51.9 35.66743248152735 139.7423216610761 51.9 35.66743248152735 139.7423216610761 29.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fe596431-4194-48e8-b094-10c0dac0082e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe596431-4194-48e8-b094-10c0dac0082e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe596431-4194-48e8-b094-10c0dac0082e">
											<gml:posList>35.66743293332407 139.7423231296618 51.9 35.66743293332407 139.7423231296618 50.993 35.66744088582102 139.74230243175 50.993 35.66744088582102 139.74230243175 51.9 35.66743293332407 139.7423231296618 51.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-83652928-f080-4afe-bcf7-35c104b88033">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83652928-f080-4afe-bcf7-35c104b88033">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83652928-f080-4afe-bcf7-35c104b88033">
											<gml:posList>35.66739919894245 139.74230461092355 51.9 35.66739919894245 139.74230461092355 50.993 35.66743293332407 139.7423231296618 50.993 35.66743293332407 139.7423231296618 51.9 35.66739919894245 139.74230461092355 51.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cdd4739e-f060-4ba7-8a4a-6a613c2026f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cdd4739e-f060-4ba7-8a4a-6a613c2026f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cdd4739e-f060-4ba7-8a4a-6a613c2026f0">
											<gml:posList>35.66732064478895 139.74235304773273 29.315 35.66732064478895 139.74235304773273 45.2 35.66732463894698 139.7423425386083 45.2 35.66732463894698 139.7423425386083 47.3 35.66735015112148 139.7422753619839 47.3 35.66735015112148 139.7422753619839 29.315 35.66732064478895 139.74235304773273 29.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2cfbd17b-661e-4eaa-8300-6d425a6109ad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2cfbd17b-661e-4eaa-8300-6d425a6109ad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2cfbd17b-661e-4eaa-8300-6d425a6109ad">
											<gml:posList>35.66735964955084 139.7423441999403 47.3 35.66735964955084 139.7423441999403 51.9 35.667379467436774 139.74229210733338 51.9 35.667379467436774 139.74229210733338 47.3 35.66735964955084 139.7423441999403 47.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cd34c132-d24c-45eb-9129-a2fa3fa5d6e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd34c132-d24c-45eb-9129-a2fa3fa5d6e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd34c132-d24c-45eb-9129-a2fa3fa5d6e2">
											<gml:posList>35.667360866003456 139.7423436683595 51.9 35.667360866003456 139.7423436683595 50.993 35.66737991925055 139.74229359800967 50.993 35.66737991925055 139.74229359800967 51.9 35.667360866003456 139.7423436683595 51.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9a8a8075-a2fa-4ea2-bc33-0c25f9547af2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a8a8075-a2fa-4ea2-bc33-0c25f9547af2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a8a8075-a2fa-4ea2-bc33-0c25f9547af2">
											<gml:posList>35.667471243143844 139.7423250412977 29.315 35.66747322207317 139.74231962658072 29.315 35.66747322207317 139.74231962658072 51.9 35.667471243143844 139.7423250412977 51.9 35.667471243143844 139.7423250412977 29.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3191b144-fe84-4aa6-b98e-1f30dfaf95d9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3191b144-fe84-4aa6-b98e-1f30dfaf95d9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3191b144-fe84-4aa6-b98e-1f30dfaf95d9">
											<gml:posList>35.66747203267857 139.7423201802237 51.9 35.66747203267857 139.7423201802237 50.993 35.66747005374921 139.74232559494058 50.993 35.66747005374921 139.74232559494058 51.9 35.66747203267857 139.7423201802237 51.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ce6e4059-6ee0-4c49-871e-7d1ef45bfc4e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce6e4059-6ee0-4c49-871e-7d1ef45bfc4e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce6e4059-6ee0-4c49-871e-7d1ef45bfc4e">
											<gml:posList>35.667490991721714 139.74233628566265 29.315 35.667471243143844 139.7423250412977 29.315 35.667471243143844 139.7423250412977 51.9 35.667490991721714 139.74233628566265 51.9 35.667490991721714 139.74233628566265 29.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-58c130fd-94b1-4b1c-bdfc-1f3e7258f8cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-58c130fd-94b1-4b1c-bdfc-1f3e7258f8cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-58c130fd-94b1-4b1c-bdfc-1f3e7258f8cf">
											<gml:posList>35.66747005374921 139.74232559494058 51.9 35.66747005374921 139.74232559494058 50.993 35.667489793304966 139.74233682826986 50.993 35.667489793304966 139.74233682826986 51.9 35.66747005374921 139.74232559494058 51.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-95868113-42f6-46e1-88de-38cf849c6efc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-95868113-42f6-46e1-88de-38cf849c6efc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-95868113-42f6-46e1-88de-38cf849c6efc">
											<gml:posList>35.66748856293993 139.74234280547702 29.315 35.667490991721714 139.74233628566265 29.315 35.667490991721714 139.74233628566265 51.9 35.66748856293993 139.74234280547702 51.9 35.66748856293993 139.74234280547702 29.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-71c9d580-993f-4830-990c-08e1628ef3d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-71c9d580-993f-4830-990c-08e1628ef3d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-71c9d580-993f-4830-990c-08e1628ef3d6">
											<gml:posList>35.667489793304966 139.74233682826986 51.9 35.667489793304966 139.74233682826986 50.993 35.66748736453149 139.74234335913 50.993 35.66748736453149 139.74234335913 51.9 35.667489793304966 139.74233682826986 51.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8f1fefa1-43d7-4b30-b2c6-b409d454504e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f1fefa1-43d7-4b30-b2c6-b409d454504e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f1fefa1-43d7-4b30-b2c6-b409d454504e">
											<gml:posList>35.66748856293993 139.74234280547702 51.9 35.66754672660065 139.74237598754274 51.9 35.66754672660065 139.74237598754274 29.315 35.66748856293993 139.74234280547702 29.315 35.66748856293993 139.74234280547702 51.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-45ec767b-5ed5-4494-ab4d-f7dd9e50cf6a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45ec767b-5ed5-4494-ab4d-f7dd9e50cf6a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45ec767b-5ed5-4494-ab4d-f7dd9e50cf6a">
											<gml:posList>35.66754213877691 139.74238814320236 29.315 35.66754672660065 139.74237598754274 29.315 35.66754672660065 139.74237598754274 51.9 35.66754213877691 139.74238814320236 51.9 35.66754213877691 139.74238814320236 29.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8616acdf-7147-4fe6-9f9a-fc43ec9a14ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8616acdf-7147-4fe6-9f9a-fc43ec9a14ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8616acdf-7147-4fe6-9f9a-fc43ec9a14ae">
											<gml:posList>35.66754552818374 139.74237653014976 51.9 35.66754552818374 139.74237653014976 50.993 35.6675409313462 139.74238868581938 50.993 35.6675409313462 139.74238868581938 51.9 35.66754552818374 139.74237653014976 51.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-30fd9981-5ec3-48c4-bd9d-0e285f6a0eb8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-30fd9981-5ec3-48c4-bd9d-0e285f6a0eb8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-30fd9981-5ec3-48c4-bd9d-0e285f6a0eb8">
											<gml:posList>35.667539027147306 139.74244533119136 51.9 35.667539027147306 139.74244533119136 50.993 35.667360866003456 139.7423436683595 50.993 35.667360866003456 139.7423436683595 51.9 35.667539027147306 139.74244533119136 51.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-51037cae-b41a-42ee-91a2-69fa253aa3e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-51037cae-b41a-42ee-91a2-69fa253aa3e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-51037cae-b41a-42ee-91a2-69fa253aa3e6">
											<gml:posList>35.66753947895085 139.7424468108256 47.3 35.66753947895085 139.7424468108256 51.9 35.66735964955084 139.7423441999403 51.9 35.66735964955084 139.7423441999403 47.3 35.66753947895085 139.7424468108256 47.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-17ee56fa-351b-454d-9152-e289c63193c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17ee56fa-351b-454d-9152-e289c63193c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17ee56fa-351b-454d-9152-e289c63193c4">
											<gml:posList>35.66754213877691 139.74238814320236 29.315 35.66754213877691 139.74238814320236 51.9 35.66755789255745 139.7423971277195 51.9 35.66755789255745 139.7423971277195 47.3 35.667578479780325 139.74240886822764 47.3 35.667578479780325 139.74240886822764 29.315 35.66754213877691 139.74238814320236 29.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-87e4215e-1478-454d-956a-27f35d596dd6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-87e4215e-1478-454d-956a-27f35d596dd6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-87e4215e-1478-454d-956a-27f35d596dd6">
											<gml:posList>35.66755375898198 139.7424737134258 45.2 35.66755375898198 139.7424737134258 47.3 35.66732463894698 139.7423425386083 47.3 35.66732463894698 139.7423425386083 45.2 35.66755375898198 139.7424737134258 45.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-998df9e0-3b9f-429c-95b4-6a3285d60c3b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-998df9e0-3b9f-429c-95b4-6a3285d60c3b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-998df9e0-3b9f-429c-95b4-6a3285d60c3b">
											<gml:posList>35.66732064478895 139.74235304773273 29.315 35.66754987273574 139.74248390212125 29.315 35.66754987273574 139.74248390212125 45.2 35.66732064478895 139.74235304773273 45.2 35.66732064478895 139.74235304773273 29.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f52a5a09-cf28-4b48-a5be-2a048964a55e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f52a5a09-cf28-4b48-a5be-2a048964a55e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f52a5a09-cf28-4b48-a5be-2a048964a55e">
											<gml:posList>35.66755669414043 139.74239767032626 51.9 35.66755669414043 139.74239767032626 50.993 35.667539027147306 139.74244533119136 50.993 35.667539027147306 139.74244533119136 51.9 35.66755669414043 139.74239767032626 51.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1c13e667-f8bc-4143-a15c-49dd75176264">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c13e667-f8bc-4143-a15c-49dd75176264">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c13e667-f8bc-4143-a15c-49dd75176264">
											<gml:posList>35.66755789255745 139.7423971277195 47.3 35.66755789255745 139.7423971277195 51.9 35.66753947895085 139.7424468108256 51.9 35.66753947895085 139.7424468108256 47.3 35.66755789255745 139.7423971277195 47.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9ce921c7-e591-44ad-bd9b-f6c01ab335f5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ce921c7-e591-44ad-bd9b-f6c01ab335f5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ce921c7-e591-44ad-bd9b-f6c01ab335f5">
											<gml:posList>35.667578479780325 139.74240886822764 29.315 35.667578479780325 139.74240886822764 47.3 35.66755375898198 139.7424737134258 47.3 35.66755375898198 139.7424737134258 45.2 35.66754987273574 139.74248390212125 45.2 35.66754987273574 139.74248390212125 29.315 35.667578479780325 139.74240886822764 29.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2338</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">244.25205</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">6</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.39</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>