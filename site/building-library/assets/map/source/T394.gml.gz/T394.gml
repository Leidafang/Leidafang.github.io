<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_72179f2f-e138-4775-a089-7c6c9c2bf5f4">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門駅南地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">15.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.668980284881606 139.74995347672342 0 35.668914543596244 139.74992148942522 0 35.66887630791083 139.750039512095 0 35.66894204915775 139.75007148842877 0 35.668980284881606 139.74995347672342 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668980284881606 139.74995347672342 5.757 35.66894204915775 139.75007148842877 5.757 35.66887630791083 139.750039512095 5.757 35.668914543596244 139.74992148942522 5.757 35.668980284881606 139.74995347672342 5.757</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668980284881606 139.74995347672342 5.757 35.668914543596244 139.74992148942522 5.757 35.668914543596244 139.74992148942522 21.27 35.668980284881606 139.74995347672342 21.27 35.668980284881606 139.74995347672342 5.757</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668914543596244 139.74992148942522 5.757 35.66887630791083 139.750039512095 5.757 35.66887630791083 139.750039512095 21.27 35.668914543596244 139.74992148942522 21.27 35.668914543596244 139.74992148942522 5.757</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66887630791083 139.750039512095 5.757 35.66894204915775 139.75007148842877 5.757 35.66894204915775 139.75007148842877 21.27 35.66887630791083 139.750039512095 21.27 35.66887630791083 139.750039512095 5.757</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66894204915775 139.75007148842877 5.757 35.668980284881606 139.74995347672342 5.757 35.668980284881606 139.74995347672342 21.27 35.66894204915775 139.75007148842877 21.27 35.66894204915775 139.75007148842877 5.757</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668980284881606 139.74995347672342 21.27 35.668914543596244 139.74992148942522 21.27 35.66887630791083 139.750039512095 21.27 35.66894204915775 139.75007148842877 21.27 35.668980284881606 139.74995347672342 21.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-84eacbf9-afeb-4af9-a85c-71d2965910ad"/>
							<gml:surfaceMember xlink:href="#poly-b4cb77da-7030-41ad-b552-396d674930cb"/>
							<gml:surfaceMember xlink:href="#poly-fdac5cd1-2529-413a-92e0-a23452973a87"/>
							<gml:surfaceMember xlink:href="#poly-c1a65ee5-023a-49ec-b0ee-a021302187ea"/>
							<gml:surfaceMember xlink:href="#poly-a73740d8-334b-40aa-9ce3-98b01fc0dec4"/>
							<gml:surfaceMember xlink:href="#poly-8261b7a7-bf9a-4fbe-9ed6-7fbe4921c2c3"/>
							<gml:surfaceMember xlink:href="#poly-3c4f8160-a601-451d-83f6-848cf68ce4e8"/>
							<gml:surfaceMember xlink:href="#poly-566d9092-b6ee-4446-b09e-30df384ffbce"/>
							<gml:surfaceMember xlink:href="#poly-16841307-de84-4bca-86cb-cc7aa411e7c4"/>
							<gml:surfaceMember xlink:href="#poly-7d48f4e8-500b-40ef-bf7d-2ff8a00b8c73"/>
							<gml:surfaceMember xlink:href="#poly-b9d09bfd-030f-47ba-8012-c5e69979ff2f"/>
							<gml:surfaceMember xlink:href="#poly-7009a41c-dc59-4064-9713-aabd39c1b864"/>
							<gml:surfaceMember xlink:href="#poly-3162a3c3-7dda-4083-b309-e6a5de5bd2bf"/>
							<gml:surfaceMember xlink:href="#poly-f860f3e5-ed69-4e89-a80f-41ede60da9b3"/>
							<gml:surfaceMember xlink:href="#poly-c4e3d4a3-f3e4-40eb-97da-c7b6418e221b"/>
							<gml:surfaceMember xlink:href="#poly-4757733f-784f-4364-9543-f2026ef442c5"/>
							<gml:surfaceMember xlink:href="#poly-3eec1258-25e6-4e3d-8349-12a1abfad988"/>
							<gml:surfaceMember xlink:href="#poly-7a68723f-9080-42e3-a365-9dffdc43a1af"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_72179f2f-e138-4775-a089-7c6c9c2bf5f4_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b7e30698-0a52-4919-9d25-78fb3cc52cff">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668944905967166 139.75001857482226 21.309 35.668944491007075 139.75001810027274 21.309 35.668944103057605 139.75001758151092 21.309 35.66894376014618 139.75001701851804 21.309 35.66894346228046 139.75001642234017 21.309 35.66894320045437 139.75001580403273 21.309 35.66894298367398 139.7500151525403 21.309 35.66894281194695 139.75001447890895 21.309 35.66894269429462 139.75001379417535 21.309 35.668942630717 139.7500130983395 21.309 35.668942603194296 139.75001240246618 21.309 35.668942638760036 139.75001169548122 21.309 35.668942719409685 139.75001101054156 21.309 35.66894284512797 139.75001032555502 21.309 35.66894301592254 139.75000965156775 21.309 35.668943240822394 139.75000901066244 21.309 35.668943510806166 139.75000839180237 21.309 35.6689438258815 139.75000780603364 21.309 35.668944177034675 139.75000725336557 21.309 35.66894456426568 139.75000673379822 21.309 35.66894498758982 139.75000626942366 21.309 35.66894544699944 139.75000584919584 21.309 35.66894593348081 139.75000547312416 21.309 35.66894643802786 139.750005152264 21.309 35.668946969661945 139.75000489765205 21.309 35.668947510340345 139.75000468721495 21.309 35.66894806909205 139.75000454303543 21.309 35.66894863689571 139.75000445407684 21.309 35.66894921375896 139.7500044313852 21.309 35.6689497816467 139.75000446393324 21.309 35.66895034958032 139.75000456275757 21.309 35.66895090853841 139.7500047168216 21.309 35.66895144951492 139.75000493718065 21.309 35.6689519725022 139.7500052127887 21.309 35.668952486513966 139.75000554363643 21.309 35.6689529645014 139.75000591870588 21.309 35.668953415485866 139.75000634903367 21.309 35.66895383044599 139.7500068235832 21.309 35.66895420938944 139.75000735340046 21.309 35.66895456130698 139.75000790533792 21.309 35.66895485917274 139.75000850151582 21.309 35.66895512099887 139.75000911982335 21.309 35.66895533777929 139.75000977131583 21.309 35.66895550950636 139.7500104449473 21.309 35.6689556271587 139.750011129681 21.309 35.668955690736325 139.75001182551696 21.309 35.6689557092453 139.75001252139978 21.309 35.668955682693294 139.75001322837545 21.309 35.66895560205127 139.7500139243613 21.309 35.66895547632531 139.75001459830187 21.309 35.66895530553073 139.75001527228923 21.309 35.66895508063084 139.75001591319466 21.309 35.66895481064703 139.7500165320548 21.309 35.66895449557166 139.75001711782357 21.309 35.66895414441844 139.75001767049164 21.309 35.66895375718738 139.75001819005902 21.309 35.66895333386319 139.75001865443355 21.309 35.66895287445354 139.75001907466134 21.309 35.668952387972126 139.750019450733 21.309 35.66895188342504 139.7500197715931 21.309 35.668951351798555 139.750020037251 21.309 35.668950811112495 139.75002023664194 21.309 35.668950252360766 139.75002038082133 21.309 35.66894968455709 139.75002046977983 21.309 35.668949107693834 139.75002049247135 21.309 35.668948539806095 139.75002045992323 21.309 35.6689479718725 139.75002036109876 21.309 35.66894741291443 139.75002020703465 21.309 35.66894687193794 139.7500199866755 21.309 35.66894633993697 139.75001971107673 21.309 35.66894583494662 139.75001939126562 21.309 35.66894535695159 139.75001900515008 21.309 35.668944905967166 139.75001857482226 21.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c66975b8-4fb6-47fc-85d3-f314ae48fe0b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c66975b8-4fb6-47fc-85d3-f314ae48fe0b_0">
											<gml:posList>35.66894921375896 139.7500044313852 24.077 35.66894921375896 139.7500044313852 21.309 35.66894863689571 139.75000445407684 21.309 35.66894863689571 139.75000445407684 24.077 35.66894921375896 139.7500044313852 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48976403-83e6-4c79-bf90-580e51b5e9b9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-48976403-83e6-4c79-bf90-580e51b5e9b9_0">
											<gml:posList>35.6689497816467 139.75000446393324 24.077 35.6689497816467 139.75000446393324 21.309 35.66894921375896 139.7500044313852 21.309 35.66894921375896 139.7500044313852 24.077 35.6689497816467 139.75000446393324 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63cfb1da-b935-4fcd-8c51-f549cf26a968">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-63cfb1da-b935-4fcd-8c51-f549cf26a968_0">
											<gml:posList>35.66894863689571 139.75000445407684 24.077 35.66894863689571 139.75000445407684 21.309 35.66894806909205 139.75000454303543 21.309 35.66894806909205 139.75000454303543 24.077 35.66894863689571 139.75000445407684 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00077542-2575-437a-95af-105ea81da31f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-00077542-2575-437a-95af-105ea81da31f_0">
											<gml:posList>35.66895034958032 139.75000456275757 24.077 35.66895034958032 139.75000456275757 21.309 35.6689497816467 139.75000446393324 21.309 35.6689497816467 139.75000446393324 24.077 35.66895034958032 139.75000456275757 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75c03577-8bfa-441a-884f-be457242448a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-75c03577-8bfa-441a-884f-be457242448a_0">
											<gml:posList>35.66894806909205 139.75000454303543 24.077 35.66894806909205 139.75000454303543 21.309 35.668947510340345 139.75000468721495 21.309 35.668947510340345 139.75000468721495 24.077 35.66894806909205 139.75000454303543 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e6c2977-9fde-422f-8558-99d7447ffafe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3e6c2977-9fde-422f-8558-99d7447ffafe_0">
											<gml:posList>35.66895090853841 139.7500047168216 24.077 35.66895090853841 139.7500047168216 21.309 35.66895034958032 139.75000456275757 21.309 35.66895034958032 139.75000456275757 24.077 35.66895090853841 139.7500047168216 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a6ec047b-565e-455e-807f-7f70a2d79ae3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a6ec047b-565e-455e-807f-7f70a2d79ae3_0">
											<gml:posList>35.668947510340345 139.75000468721495 24.077 35.668947510340345 139.75000468721495 21.309 35.668946969661945 139.75000489765205 21.309 35.668946969661945 139.75000489765205 24.077 35.668947510340345 139.75000468721495 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e1add2c9-87e1-43a6-93e3-dbb9242a556f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e1add2c9-87e1-43a6-93e3-dbb9242a556f_0">
											<gml:posList>35.66895144951492 139.75000493718065 24.077 35.66895144951492 139.75000493718065 21.309 35.66895090853841 139.7500047168216 21.309 35.66895090853841 139.7500047168216 24.077 35.66895144951492 139.75000493718065 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13cc01d9-cde0-4acc-a26e-76c45ce6e1e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-13cc01d9-cde0-4acc-a26e-76c45ce6e1e2_0">
											<gml:posList>35.668946969661945 139.75000489765205 24.077 35.668946969661945 139.75000489765205 21.309 35.66894643802786 139.750005152264 21.309 35.66894643802786 139.750005152264 24.077 35.668946969661945 139.75000489765205 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2527ae9a-1118-4a7c-a913-59209edda071">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2527ae9a-1118-4a7c-a913-59209edda071_0">
											<gml:posList>35.6689519725022 139.7500052127887 24.077 35.6689519725022 139.7500052127887 21.309 35.66895144951492 139.75000493718065 21.309 35.66895144951492 139.75000493718065 24.077 35.6689519725022 139.7500052127887 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8079a4a0-fd49-45c5-952a-0a92fde966d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8079a4a0-fd49-45c5-952a-0a92fde966d8_0">
											<gml:posList>35.66894643802786 139.750005152264 24.077 35.66894643802786 139.750005152264 21.309 35.66894593348081 139.75000547312416 21.309 35.66894593348081 139.75000547312416 24.077 35.66894643802786 139.750005152264 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13e4e768-3d28-4a5d-b21c-e5a6300e2842">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-13e4e768-3d28-4a5d-b21c-e5a6300e2842_0">
											<gml:posList>35.668952486513966 139.75000554363643 24.077 35.668952486513966 139.75000554363643 21.309 35.6689519725022 139.7500052127887 21.309 35.6689519725022 139.7500052127887 24.077 35.668952486513966 139.75000554363643 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0959a64-d047-48b1-b72b-76161fa422ed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0959a64-d047-48b1-b72b-76161fa422ed_0">
											<gml:posList>35.66894593348081 139.75000547312416 24.077 35.66894593348081 139.75000547312416 21.309 35.66894544699944 139.75000584919584 21.309 35.66894544699944 139.75000584919584 24.077 35.66894593348081 139.75000547312416 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-120ecb66-4273-4f76-919d-a7f1fe14bafd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-120ecb66-4273-4f76-919d-a7f1fe14bafd_0">
											<gml:posList>35.6689529645014 139.75000591870588 24.077 35.6689529645014 139.75000591870588 21.309 35.668952486513966 139.75000554363643 21.309 35.668952486513966 139.75000554363643 24.077 35.6689529645014 139.75000591870588 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b54108f-4a2c-4d0d-97d9-c19b988cfc79">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2b54108f-4a2c-4d0d-97d9-c19b988cfc79_0">
											<gml:posList>35.66894544699944 139.75000584919584 24.077 35.66894544699944 139.75000584919584 21.309 35.66894498758982 139.75000626942366 21.309 35.66894498758982 139.75000626942366 24.077 35.66894544699944 139.75000584919584 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e5b9594-5482-42eb-8554-adba84683010">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6e5b9594-5482-42eb-8554-adba84683010_0">
											<gml:posList>35.668953415485866 139.75000634903367 24.077 35.668953415485866 139.75000634903367 21.309 35.6689529645014 139.75000591870588 21.309 35.6689529645014 139.75000591870588 24.077 35.668953415485866 139.75000634903367 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8bab996-efb2-4055-889e-0ce9247a80a1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d8bab996-efb2-4055-889e-0ce9247a80a1_0">
											<gml:posList>35.66894498758982 139.75000626942366 24.077 35.66894498758982 139.75000626942366 21.309 35.66894456426568 139.75000673379822 21.309 35.66894456426568 139.75000673379822 24.077 35.66894498758982 139.75000626942366 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-692f97a8-48d2-4789-b535-d78198fc0032">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-692f97a8-48d2-4789-b535-d78198fc0032_0">
											<gml:posList>35.66895383044599 139.7500068235832 24.077 35.66895383044599 139.7500068235832 21.309 35.668953415485866 139.75000634903367 21.309 35.668953415485866 139.75000634903367 24.077 35.66895383044599 139.7500068235832 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a82266e0-9a08-441e-bbbe-523b27d3a99d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a82266e0-9a08-441e-bbbe-523b27d3a99d_0">
											<gml:posList>35.66894456426568 139.75000673379822 24.077 35.66894456426568 139.75000673379822 21.309 35.668944177034675 139.75000725336557 21.309 35.668944177034675 139.75000725336557 24.077 35.66894456426568 139.75000673379822 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c6288cc-18a5-4bd6-b73b-95525cb64558">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c6288cc-18a5-4bd6-b73b-95525cb64558_0">
											<gml:posList>35.66895420938944 139.75000735340046 24.077 35.66895420938944 139.75000735340046 21.309 35.66895383044599 139.7500068235832 21.309 35.66895383044599 139.7500068235832 24.077 35.66895420938944 139.75000735340046 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e237e2d6-fb1c-4265-9374-b26ad6b314e7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e237e2d6-fb1c-4265-9374-b26ad6b314e7_0">
											<gml:posList>35.668944177034675 139.75000725336557 24.077 35.668944177034675 139.75000725336557 21.309 35.6689438258815 139.75000780603364 21.309 35.6689438258815 139.75000780603364 24.077 35.668944177034675 139.75000725336557 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d2121937-5189-4c09-a803-ca1cba0c68bf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d2121937-5189-4c09-a803-ca1cba0c68bf_0">
											<gml:posList>35.66895456130698 139.75000790533792 24.077 35.66895456130698 139.75000790533792 21.309 35.66895420938944 139.75000735340046 21.309 35.66895420938944 139.75000735340046 24.077 35.66895456130698 139.75000790533792 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1a671da-8df5-4465-b093-a78e5ee8a6f4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a1a671da-8df5-4465-b093-a78e5ee8a6f4_0">
											<gml:posList>35.6689438258815 139.75000780603364 24.077 35.6689438258815 139.75000780603364 21.309 35.668943510806166 139.75000839180237 21.309 35.668943510806166 139.75000839180237 24.077 35.6689438258815 139.75000780603364 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d48326e-44e2-4123-a845-296f494e6fbb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6d48326e-44e2-4123-a845-296f494e6fbb_0">
											<gml:posList>35.66895485917274 139.75000850151582 24.077 35.66895485917274 139.75000850151582 21.309 35.66895456130698 139.75000790533792 21.309 35.66895456130698 139.75000790533792 24.077 35.66895485917274 139.75000850151582 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-28e211b5-3012-4268-8775-7dbf1f467c73">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-28e211b5-3012-4268-8775-7dbf1f467c73_0">
											<gml:posList>35.668943510806166 139.75000839180237 24.077 35.668943510806166 139.75000839180237 21.309 35.668943240822394 139.75000901066244 21.309 35.668943240822394 139.75000901066244 24.077 35.668943510806166 139.75000839180237 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01fe0e54-939d-4982-9e90-e792849ec364">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01fe0e54-939d-4982-9e90-e792849ec364_0">
											<gml:posList>35.66895512099887 139.75000911982335 24.077 35.66895512099887 139.75000911982335 21.309 35.66895485917274 139.75000850151582 21.309 35.66895485917274 139.75000850151582 24.077 35.66895512099887 139.75000911982335 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c8d21385-dac0-4855-94ff-2d53303524ed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c8d21385-dac0-4855-94ff-2d53303524ed_0">
											<gml:posList>35.668943240822394 139.75000901066244 24.077 35.668943240822394 139.75000901066244 21.309 35.66894301592254 139.75000965156775 21.309 35.66894301592254 139.75000965156775 24.077 35.668943240822394 139.75000901066244 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7104b8b2-8124-49bd-aa96-aa144f27313e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7104b8b2-8124-49bd-aa96-aa144f27313e_0">
											<gml:posList>35.66895533777929 139.75000977131583 24.077 35.66895533777929 139.75000977131583 21.309 35.66895512099887 139.75000911982335 21.309 35.66895512099887 139.75000911982335 24.077 35.66895533777929 139.75000977131583 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-994e6fb5-6123-46b6-89ce-506a78307eca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-994e6fb5-6123-46b6-89ce-506a78307eca_0">
											<gml:posList>35.66894301592254 139.75000965156775 24.077 35.66894301592254 139.75000965156775 21.309 35.66894284512797 139.75001032555502 21.309 35.66894284512797 139.75001032555502 24.077 35.66894301592254 139.75000965156775 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a967adaf-31ba-481c-8d71-bc16cb44e1e0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a967adaf-31ba-481c-8d71-bc16cb44e1e0_0">
											<gml:posList>35.66895550950636 139.7500104449473 24.077 35.66895550950636 139.7500104449473 21.309 35.66895533777929 139.75000977131583 21.309 35.66895533777929 139.75000977131583 24.077 35.66895550950636 139.7500104449473 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-65eaffc7-8f7d-496a-9132-c36f16ee743e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-65eaffc7-8f7d-496a-9132-c36f16ee743e_0">
											<gml:posList>35.66894284512797 139.75001032555502 24.077 35.66894284512797 139.75001032555502 21.309 35.668942719409685 139.75001101054156 21.309 35.668942719409685 139.75001101054156 24.077 35.66894284512797 139.75001032555502 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7728b5d3-7fdf-4cc5-9c21-350d4437c40c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7728b5d3-7fdf-4cc5-9c21-350d4437c40c_0">
											<gml:posList>35.6689556271587 139.750011129681 24.077 35.6689556271587 139.750011129681 21.309 35.66895550950636 139.7500104449473 21.309 35.66895550950636 139.7500104449473 24.077 35.6689556271587 139.750011129681 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb1de561-0ac4-4a8c-81bd-489065e38abd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb1de561-0ac4-4a8c-81bd-489065e38abd_0">
											<gml:posList>35.668942719409685 139.75001101054156 24.077 35.668942719409685 139.75001101054156 21.309 35.668942638760036 139.75001169548122 21.309 35.668942638760036 139.75001169548122 24.077 35.668942719409685 139.75001101054156 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab4d2d66-88c9-432d-b296-25e62d8470be">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ab4d2d66-88c9-432d-b296-25e62d8470be_0">
											<gml:posList>35.668955690736325 139.75001182551696 24.077 35.668955690736325 139.75001182551696 21.309 35.6689556271587 139.750011129681 21.309 35.6689556271587 139.750011129681 24.077 35.668955690736325 139.75001182551696 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc327c8a-f49c-41d7-a37c-31c64c358d3d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bc327c8a-f49c-41d7-a37c-31c64c358d3d_0">
											<gml:posList>35.668942638760036 139.75001169548122 24.077 35.668942638760036 139.75001169548122 21.309 35.668942603194296 139.75001240246618 21.309 35.668942603194296 139.75001240246618 24.077 35.668942638760036 139.75001169548122 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc13a4a2-89c3-4599-ad10-c00b23e53dbc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc13a4a2-89c3-4599-ad10-c00b23e53dbc_0">
											<gml:posList>35.6689557092453 139.75001252139978 24.077 35.6689557092453 139.75001252139978 21.309 35.668955690736325 139.75001182551696 21.309 35.668955690736325 139.75001182551696 24.077 35.6689557092453 139.75001252139978 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-380515fe-c7e6-42d7-9507-74a1e19b95cc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-380515fe-c7e6-42d7-9507-74a1e19b95cc_0">
											<gml:posList>35.66894863689571 139.75000445407684 24.077 35.66894806909205 139.75000454303543 24.077 35.668947510340345 139.75000468721495 24.077 35.668946969661945 139.75000489765205 24.077 35.66894643802786 139.750005152264 24.077 35.66894593348081 139.75000547312416 24.077 35.66894544699944 139.75000584919584 24.077 35.66894498758982 139.75000626942366 24.077 35.66894456426568 139.75000673379822 24.077 35.668944177034675 139.75000725336557 24.077 35.6689438258815 139.75000780603364 24.077 35.668943510806166 139.75000839180237 24.077 35.668943240822394 139.75000901066244 24.077 35.66894301592254 139.75000965156775 24.077 35.66894284512797 139.75001032555502 24.077 35.668942719409685 139.75001101054156 24.077 35.668942638760036 139.75001169548122 24.077 35.668942603194296 139.75001240246618 24.077 35.668942630717 139.7500130983395 24.077 35.66894269429462 139.75001379417535 24.077 35.66894281194695 139.75001447890895 24.077 35.66894298367398 139.7500151525403 24.077 35.66894320045437 139.75001580403273 24.077 35.66894346228046 139.75001642234017 24.077 35.66894376014618 139.75001701851804 24.077 35.668944103057605 139.75001758151092 24.077 35.668944491007075 139.75001810027274 24.077 35.668944905967166 139.75001857482226 24.077 35.66894535695159 139.75001900515008 24.077 35.66894583494662 139.75001939126562 24.077 35.66894633993697 139.75001971107673 24.077 35.66894687193794 139.7500199866755 24.077 35.66894741291443 139.75002020703465 24.077 35.6689479718725 139.75002036109876 24.077 35.668948539806095 139.75002045992323 24.077 35.668949107693834 139.75002049247135 24.077 35.66894968455709 139.75002046977983 24.077 35.668950252360766 139.75002038082133 24.077 35.668950811112495 139.75002023664194 24.077 35.668951351798555 139.750020037251 24.077 35.66895188342504 139.7500197715931 24.077 35.668952387972126 139.750019450733 24.077 35.66895287445354 139.75001907466134 24.077 35.66895333386319 139.75001865443355 24.077 35.66895375718738 139.75001819005902 24.077 35.66895414441844 139.75001767049164 24.077 35.66895449557166 139.75001711782357 24.077 35.66895481064703 139.7500165320548 24.077 35.66895508063084 139.75001591319466 24.077 35.66895530553073 139.75001527228923 24.077 35.66895547632531 139.75001459830187 24.077 35.66895560205127 139.7500139243613 24.077 35.668955682693294 139.75001322837545 24.077 35.6689557092453 139.75001252139978 24.077 35.668955690736325 139.75001182551696 24.077 35.6689556271587 139.750011129681 24.077 35.66895550950636 139.7500104449473 24.077 35.66895533777929 139.75000977131583 24.077 35.66895512099887 139.75000911982335 24.077 35.66895485917274 139.75000850151582 24.077 35.66895456130698 139.75000790533792 24.077 35.66895420938944 139.75000735340046 24.077 35.66895383044599 139.7500068235832 24.077 35.668953415485866 139.75000634903367 24.077 35.6689529645014 139.75000591870588 24.077 35.668952486513966 139.75000554363643 24.077 35.6689519725022 139.7500052127887 24.077 35.66895144951492 139.75000493718065 24.077 35.66895090853841 139.7500047168216 24.077 35.66895034958032 139.75000456275757 24.077 35.6689497816467 139.75000446393324 24.077 35.66894921375896 139.7500044313852 24.077 35.66894863689571 139.75000445407684 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-30bfc156-5ac4-41f0-81c1-e07cfbf68b8c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-30bfc156-5ac4-41f0-81c1-e07cfbf68b8c_0">
											<gml:posList>35.668942603194296 139.75001240246618 24.077 35.668942603194296 139.75001240246618 21.309 35.668942630717 139.7500130983395 21.309 35.668942630717 139.7500130983395 24.077 35.668942603194296 139.75001240246618 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9c050c2b-fbef-4369-bfb6-0b827fd6dcea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9c050c2b-fbef-4369-bfb6-0b827fd6dcea_0">
											<gml:posList>35.668955682693294 139.75001322837545 24.077 35.668955682693294 139.75001322837545 21.309 35.6689557092453 139.75001252139978 21.309 35.6689557092453 139.75001252139978 24.077 35.668955682693294 139.75001322837545 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c81c77d0-8f4c-41ca-bcb1-5586813c52a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c81c77d0-8f4c-41ca-bcb1-5586813c52a6_0">
											<gml:posList>35.668942630717 139.7500130983395 24.077 35.668942630717 139.7500130983395 21.309 35.66894269429462 139.75001379417535 21.309 35.66894269429462 139.75001379417535 24.077 35.668942630717 139.7500130983395 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bbfcc6ed-0cdd-46af-a697-b07ad52184bb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bbfcc6ed-0cdd-46af-a697-b07ad52184bb_0">
											<gml:posList>35.66895560205127 139.7500139243613 24.077 35.66895560205127 139.7500139243613 21.309 35.668955682693294 139.75001322837545 21.309 35.668955682693294 139.75001322837545 24.077 35.66895560205127 139.7500139243613 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c3a09d6-25b7-48da-a464-ecd188f991c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c3a09d6-25b7-48da-a464-ecd188f991c7_0">
											<gml:posList>35.66894269429462 139.75001379417535 24.077 35.66894269429462 139.75001379417535 21.309 35.66894281194695 139.75001447890895 21.309 35.66894281194695 139.75001447890895 24.077 35.66894269429462 139.75001379417535 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-30a099ae-57b6-4e09-8617-e12b0509b96f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-30a099ae-57b6-4e09-8617-e12b0509b96f_0">
											<gml:posList>35.66895547632531 139.75001459830187 24.077 35.66895547632531 139.75001459830187 21.309 35.66895560205127 139.7500139243613 21.309 35.66895560205127 139.7500139243613 24.077 35.66895547632531 139.75001459830187 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-10105b7b-3659-4ddd-9bad-a95e8faec0ac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-10105b7b-3659-4ddd-9bad-a95e8faec0ac_0">
											<gml:posList>35.66894281194695 139.75001447890895 24.077 35.66894281194695 139.75001447890895 21.309 35.66894298367398 139.7500151525403 21.309 35.66894298367398 139.7500151525403 24.077 35.66894281194695 139.75001447890895 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9bb3a659-7998-4441-9d68-10130fb4c3d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9bb3a659-7998-4441-9d68-10130fb4c3d4_0">
											<gml:posList>35.66895530553073 139.75001527228923 24.077 35.66895530553073 139.75001527228923 21.309 35.66895547632531 139.75001459830187 21.309 35.66895547632531 139.75001459830187 24.077 35.66895530553073 139.75001527228923 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-860b75ea-80f9-46c6-b34f-9e04bbfa78d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-860b75ea-80f9-46c6-b34f-9e04bbfa78d1_0">
											<gml:posList>35.66894298367398 139.7500151525403 24.077 35.66894298367398 139.7500151525403 21.309 35.66894320045437 139.75001580403273 21.309 35.66894320045437 139.75001580403273 24.077 35.66894298367398 139.7500151525403 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-379f9702-2875-42db-b567-acc1c8afc69b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-379f9702-2875-42db-b567-acc1c8afc69b_0">
											<gml:posList>35.66895508063084 139.75001591319466 24.077 35.66895508063084 139.75001591319466 21.309 35.66895530553073 139.75001527228923 21.309 35.66895530553073 139.75001527228923 24.077 35.66895508063084 139.75001591319466 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d55ae51b-620a-43b9-bbe6-10a0c0b36242">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d55ae51b-620a-43b9-bbe6-10a0c0b36242_0">
											<gml:posList>35.66894320045437 139.75001580403273 24.077 35.66894320045437 139.75001580403273 21.309 35.66894346228046 139.75001642234017 21.309 35.66894346228046 139.75001642234017 24.077 35.66894320045437 139.75001580403273 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eea736f1-446e-4a81-b934-f157a334f2a7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eea736f1-446e-4a81-b934-f157a334f2a7_0">
											<gml:posList>35.66895481064703 139.7500165320548 24.077 35.66895481064703 139.7500165320548 21.309 35.66895508063084 139.75001591319466 21.309 35.66895508063084 139.75001591319466 24.077 35.66895481064703 139.7500165320548 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d014357-58d4-40c9-b726-91e88ae58293">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d014357-58d4-40c9-b726-91e88ae58293_0">
											<gml:posList>35.66894346228046 139.75001642234017 24.077 35.66894346228046 139.75001642234017 21.309 35.66894376014618 139.75001701851804 21.309 35.66894376014618 139.75001701851804 24.077 35.66894346228046 139.75001642234017 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-441780af-e6ea-4f88-9f45-ecdf25126ca1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-441780af-e6ea-4f88-9f45-ecdf25126ca1_0">
											<gml:posList>35.66895449557166 139.75001711782357 24.077 35.66895449557166 139.75001711782357 21.309 35.66895481064703 139.7500165320548 21.309 35.66895481064703 139.7500165320548 24.077 35.66895449557166 139.75001711782357 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-91aaea2c-bddb-439c-b1ab-d5bd140048ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-91aaea2c-bddb-439c-b1ab-d5bd140048ce_0">
											<gml:posList>35.66894376014618 139.75001701851804 24.077 35.66894376014618 139.75001701851804 21.309 35.668944103057605 139.75001758151092 21.309 35.668944103057605 139.75001758151092 24.077 35.66894376014618 139.75001701851804 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f7174cf-930a-4487-837f-7aaceffeac39">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f7174cf-930a-4487-837f-7aaceffeac39_0">
											<gml:posList>35.66895414441844 139.75001767049164 24.077 35.66895414441844 139.75001767049164 21.309 35.66895449557166 139.75001711782357 21.309 35.66895449557166 139.75001711782357 24.077 35.66895414441844 139.75001767049164 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f9c802d-24ac-4601-be03-9e8b7cf93e33">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f9c802d-24ac-4601-be03-9e8b7cf93e33_0">
											<gml:posList>35.668944103057605 139.75001758151092 24.077 35.668944103057605 139.75001758151092 21.309 35.668944491007075 139.75001810027274 21.309 35.668944491007075 139.75001810027274 24.077 35.668944103057605 139.75001758151092 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5339dc12-8235-4fab-ac80-598a7b090079">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5339dc12-8235-4fab-ac80-598a7b090079_0">
											<gml:posList>35.66895375718738 139.75001819005902 24.077 35.66895375718738 139.75001819005902 21.309 35.66895414441844 139.75001767049164 21.309 35.66895414441844 139.75001767049164 24.077 35.66895375718738 139.75001819005902 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7fe41e9c-d0b5-4626-89d6-a8947761ccaf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7fe41e9c-d0b5-4626-89d6-a8947761ccaf_0">
											<gml:posList>35.668944491007075 139.75001810027274 24.077 35.668944491007075 139.75001810027274 21.309 35.668944905967166 139.75001857482226 21.309 35.668944905967166 139.75001857482226 24.077 35.668944491007075 139.75001810027274 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-108a226c-0a49-473e-939c-e8fa62fd7761">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-108a226c-0a49-473e-939c-e8fa62fd7761_0">
											<gml:posList>35.66895333386319 139.75001865443355 24.077 35.66895333386319 139.75001865443355 21.309 35.66895375718738 139.75001819005902 21.309 35.66895375718738 139.75001819005902 24.077 35.66895333386319 139.75001865443355 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2e9bfc8-c580-447f-8a1c-a6a63fa9e315">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b2e9bfc8-c580-447f-8a1c-a6a63fa9e315_0">
											<gml:posList>35.668944905967166 139.75001857482226 24.077 35.668944905967166 139.75001857482226 21.309 35.66894535695159 139.75001900515008 21.309 35.66894535695159 139.75001900515008 24.077 35.668944905967166 139.75001857482226 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-825e90e0-db54-45d2-bbb4-7c516f628a4c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-825e90e0-db54-45d2-bbb4-7c516f628a4c_0">
											<gml:posList>35.66895287445354 139.75001907466134 24.077 35.66895287445354 139.75001907466134 21.309 35.66895333386319 139.75001865443355 21.309 35.66895333386319 139.75001865443355 24.077 35.66895287445354 139.75001907466134 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04f623fa-33a5-4884-a09b-42848998ecdf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-04f623fa-33a5-4884-a09b-42848998ecdf_0">
											<gml:posList>35.66894535695159 139.75001900515008 24.077 35.66894535695159 139.75001900515008 21.309 35.66894583494662 139.75001939126562 21.309 35.66894583494662 139.75001939126562 24.077 35.66894535695159 139.75001900515008 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-39b6a694-4cf9-4668-83e6-0a4db1e80f5a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-39b6a694-4cf9-4668-83e6-0a4db1e80f5a_0">
											<gml:posList>35.668952387972126 139.750019450733 24.077 35.668952387972126 139.750019450733 21.309 35.66895287445354 139.75001907466134 21.309 35.66895287445354 139.75001907466134 24.077 35.668952387972126 139.750019450733 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6367271d-cfc5-4b97-9eea-eb3724a5f493">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6367271d-cfc5-4b97-9eea-eb3724a5f493_0">
											<gml:posList>35.66894583494662 139.75001939126562 24.077 35.66894583494662 139.75001939126562 21.309 35.66894633993697 139.75001971107673 21.309 35.66894633993697 139.75001971107673 24.077 35.66894583494662 139.75001939126562 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-09e7c58a-74f5-4045-9d44-485f3422c70a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-09e7c58a-74f5-4045-9d44-485f3422c70a_0">
											<gml:posList>35.66895188342504 139.7500197715931 24.077 35.66895188342504 139.7500197715931 21.309 35.668952387972126 139.750019450733 21.309 35.668952387972126 139.750019450733 24.077 35.66895188342504 139.7500197715931 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7bc4961-5f7f-446c-93d2-32bcf79e0b23">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f7bc4961-5f7f-446c-93d2-32bcf79e0b23_0">
											<gml:posList>35.66894633993697 139.75001971107673 24.077 35.66894633993697 139.75001971107673 21.309 35.66894687193794 139.7500199866755 21.309 35.66894687193794 139.7500199866755 24.077 35.66894633993697 139.75001971107673 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9fd08f5e-67c9-4833-a01a-4f59fefe06b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9fd08f5e-67c9-4833-a01a-4f59fefe06b3_0">
											<gml:posList>35.668951351798555 139.750020037251 24.077 35.668951351798555 139.750020037251 21.309 35.66895188342504 139.7500197715931 21.309 35.66895188342504 139.7500197715931 24.077 35.668951351798555 139.750020037251 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d44db57-3620-481e-88e4-3393d94f683d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6d44db57-3620-481e-88e4-3393d94f683d_0">
											<gml:posList>35.66894687193794 139.7500199866755 24.077 35.66894687193794 139.7500199866755 21.309 35.66894741291443 139.75002020703465 21.309 35.66894741291443 139.75002020703465 24.077 35.66894687193794 139.7500199866755 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e3f24dff-b59d-4436-b0d2-497a77ae7a37">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e3f24dff-b59d-4436-b0d2-497a77ae7a37_0">
											<gml:posList>35.668950811112495 139.75002023664194 24.077 35.668950811112495 139.75002023664194 21.309 35.668951351798555 139.750020037251 21.309 35.668951351798555 139.750020037251 24.077 35.668950811112495 139.75002023664194 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99cd937b-4b02-46f7-bcc4-1ac1bfd644ba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-99cd937b-4b02-46f7-bcc4-1ac1bfd644ba_0">
											<gml:posList>35.66894741291443 139.75002020703465 24.077 35.66894741291443 139.75002020703465 21.309 35.6689479718725 139.75002036109876 21.309 35.6689479718725 139.75002036109876 24.077 35.66894741291443 139.75002020703465 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e391488b-e2e8-44a3-b312-d0280360f7c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e391488b-e2e8-44a3-b312-d0280360f7c6_0">
											<gml:posList>35.668950252360766 139.75002038082133 24.077 35.668950252360766 139.75002038082133 21.309 35.668950811112495 139.75002023664194 21.309 35.668950811112495 139.75002023664194 24.077 35.668950252360766 139.75002038082133 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01634948-6caa-40f7-9e51-06c315823190">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01634948-6caa-40f7-9e51-06c315823190_0">
											<gml:posList>35.6689479718725 139.75002036109876 24.077 35.6689479718725 139.75002036109876 21.309 35.668948539806095 139.75002045992323 21.309 35.668948539806095 139.75002045992323 24.077 35.6689479718725 139.75002036109876 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e601ec6a-0516-4892-ba70-b2107dc44fbc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e601ec6a-0516-4892-ba70-b2107dc44fbc_0">
											<gml:posList>35.66894968455709 139.75002046977983 24.077 35.66894968455709 139.75002046977983 21.309 35.668950252360766 139.75002038082133 21.309 35.668950252360766 139.75002038082133 24.077 35.66894968455709 139.75002046977983 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7a615d1-27ae-4192-837e-c4edcbfa29c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d7a615d1-27ae-4192-837e-c4edcbfa29c6_0">
											<gml:posList>35.668948539806095 139.75002045992323 24.077 35.668948539806095 139.75002045992323 21.309 35.668949107693834 139.75002049247135 21.309 35.668949107693834 139.75002049247135 24.077 35.668948539806095 139.75002045992323 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e32392a3-bead-44fd-9482-dcfef8a91356">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e32392a3-bead-44fd-9482-dcfef8a91356_0">
											<gml:posList>35.668949107693834 139.75002049247135 24.077 35.668949107693834 139.75002049247135 21.309 35.66894968455709 139.75002046977983 21.309 35.66894968455709 139.75002046977983 24.077 35.668949107693834 139.75002049247135 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-84eacbf9-afeb-4af9-a85c-71d2965910ad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84eacbf9-afeb-4af9-a85c-71d2965910ad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84eacbf9-afeb-4af9-a85c-71d2965910ad">
											<gml:posList>35.668980284881584 139.7499534767234 5.757 35.66894204915773 139.75007148842877 5.757 35.66887630791081 139.750039512095 5.757 35.66891454359622 139.7499214894252 5.757 35.668980284881584 139.7499534767234 5.757</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b4cb77da-7030-41ad-b552-396d674930cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b4cb77da-7030-41ad-b552-396d674930cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b4cb77da-7030-41ad-b552-396d674930cb">
											<gml:posList>35.6688846548363 139.75001375507148 21.7 35.66888720478864 139.75001240480307 21.7 35.668915654450025 139.74992461430418 21.7 35.66891454359622 139.7499214894252 21.7 35.6688846548363 139.75001375507148 21.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fdac5cd1-2529-413a-92e0-a23452973a87">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fdac5cd1-2529-413a-92e0-a23452973a87">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fdac5cd1-2529-413a-92e0-a23452973a87">
											<gml:posList>35.66887973482057 139.75002892641567 13.1 35.66887630791081 139.750039512095 13.1 35.66894204915773 139.75007148842877 13.1 35.66894547607789 139.75006091378822 13.1 35.66887973482057 139.75002892641567 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c1a65ee5-023a-49ec-b0ee-a021302187ea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c1a65ee5-023a-49ec-b0ee-a021302187ea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c1a65ee5-023a-49ec-b0ee-a021302187ea">
											<gml:posList>35.6688846548363 139.75001375507148 15.6 35.66887973482057 139.75002892641567 15.6 35.66894547607789 139.75006091378822 15.6 35.66895039608993 139.75004573138747 15.6 35.6688846548363 139.75001375507148 15.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a73740d8-334b-40aa-9ce3-98b01fc0dec4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a73740d8-334b-40aa-9ce3-98b01fc0dec4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a73740d8-334b-40aa-9ce3-98b01fc0dec4">
											<gml:posList>35.66895039608993 139.75004573138747 21.7 35.66894928524691 139.75004261755151 21.7 35.66888720478864 139.75001240480307 21.7 35.6688846548363 139.75001375507148 21.7 35.66895039608993 139.75004573138747 21.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8261b7a7-bf9a-4fbe-9ed6-7fbe4921c2c3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8261b7a7-bf9a-4fbe-9ed6-7fbe4921c2c3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8261b7a7-bf9a-4fbe-9ed6-7fbe4921c2c3">
											<gml:posList>35.66897773492995 139.74995482699524 21.309 35.668915654450025 139.74992461430418 21.309 35.66888720478864 139.75001240480307 21.309 35.66894928524691 139.75004261755151 21.309 35.66897773492995 139.74995482699524 21.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3c4f8160-a601-451d-83f6-848cf68ce4e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c4f8160-a601-451d-83f6-848cf68ce4e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c4f8160-a601-451d-83f6-848cf68ce4e8">
											<gml:posList>35.66891454359622 139.7499214894252 21.7 35.668915654450025 139.74992461430418 21.7 35.66897773492995 139.74995482699524 21.7 35.668980284881584 139.7499534767234 21.7 35.66891454359622 139.7499214894252 21.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-566d9092-b6ee-4446-b09e-30df384ffbce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-566d9092-b6ee-4446-b09e-30df384ffbce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-566d9092-b6ee-4446-b09e-30df384ffbce">
											<gml:posList>35.668980284881584 139.7499534767234 21.7 35.66897773492995 139.74995482699524 21.7 35.66894928524691 139.75004261755151 21.7 35.66895039608993 139.75004573138747 21.7 35.668980284881584 139.7499534767234 21.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-16841307-de84-4bca-86cb-cc7aa411e7c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16841307-de84-4bca-86cb-cc7aa411e7c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16841307-de84-4bca-86cb-cc7aa411e7c4">
											<gml:posList>35.66891454359622 139.7499214894252 21.7 35.66891454359622 139.7499214894252 5.757 35.66887630791081 139.750039512095 5.757 35.66887630791081 139.750039512095 13.1 35.66887973482057 139.75002892641567 13.1 35.66887973482057 139.75002892641567 15.6 35.6688846548363 139.75001375507148 15.6 35.6688846548363 139.75001375507148 21.7 35.66891454359622 139.7499214894252 21.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7d48f4e8-500b-40ef-bf7d-2ff8a00b8c73">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d48f4e8-500b-40ef-bf7d-2ff8a00b8c73">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d48f4e8-500b-40ef-bf7d-2ff8a00b8c73">
											<gml:posList>35.66888720478864 139.75001240480307 21.7 35.66888720478864 139.75001240480307 21.309 35.668915654450025 139.74992461430418 21.309 35.668915654450025 139.74992461430418 21.7 35.66888720478864 139.75001240480307 21.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b9d09bfd-030f-47ba-8012-c5e69979ff2f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b9d09bfd-030f-47ba-8012-c5e69979ff2f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b9d09bfd-030f-47ba-8012-c5e69979ff2f">
											<gml:posList>35.66887630791081 139.750039512095 5.757 35.66894204915773 139.75007148842877 5.757 35.66894204915773 139.75007148842877 13.1 35.66887630791081 139.750039512095 13.1 35.66887630791081 139.750039512095 5.757</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7009a41c-dc59-4064-9713-aabd39c1b864">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7009a41c-dc59-4064-9713-aabd39c1b864">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7009a41c-dc59-4064-9713-aabd39c1b864">
											<gml:posList>35.66894547607789 139.75006091378822 15.6 35.66887973482057 139.75002892641567 15.6 35.66887973482057 139.75002892641567 13.1 35.66894547607789 139.75006091378822 13.1 35.66894547607789 139.75006091378822 15.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3162a3c3-7dda-4083-b309-e6a5de5bd2bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3162a3c3-7dda-4083-b309-e6a5de5bd2bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3162a3c3-7dda-4083-b309-e6a5de5bd2bf">
											<gml:posList>35.66895039608993 139.75004573138747 15.6 35.66895039608993 139.75004573138747 21.7 35.6688846548363 139.75001375507148 21.7 35.6688846548363 139.75001375507148 15.6 35.66895039608993 139.75004573138747 15.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f860f3e5-ed69-4e89-a80f-41ede60da9b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f860f3e5-ed69-4e89-a80f-41ede60da9b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f860f3e5-ed69-4e89-a80f-41ede60da9b3">
											<gml:posList>35.66894928524691 139.75004261755151 21.7 35.66894928524691 139.75004261755151 21.309 35.66888720478864 139.75001240480307 21.309 35.66888720478864 139.75001240480307 21.7 35.66894928524691 139.75004261755151 21.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c4e3d4a3-f3e4-40eb-97da-c7b6418e221b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4e3d4a3-f3e4-40eb-97da-c7b6418e221b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4e3d4a3-f3e4-40eb-97da-c7b6418e221b">
											<gml:posList>35.668915654450025 139.74992461430418 21.7 35.668915654450025 139.74992461430418 21.309 35.66897773492995 139.74995482699524 21.309 35.66897773492995 139.74995482699524 21.7 35.668915654450025 139.74992461430418 21.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4757733f-784f-4364-9543-f2026ef442c5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4757733f-784f-4364-9543-f2026ef442c5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4757733f-784f-4364-9543-f2026ef442c5">
											<gml:posList>35.668980284881584 139.7499534767234 5.757 35.66891454359622 139.7499214894252 5.757 35.66891454359622 139.7499214894252 21.7 35.668980284881584 139.7499534767234 21.7 35.668980284881584 139.7499534767234 5.757</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3eec1258-25e6-4e3d-8349-12a1abfad988">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3eec1258-25e6-4e3d-8349-12a1abfad988">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3eec1258-25e6-4e3d-8349-12a1abfad988">
											<gml:posList>35.668980284881584 139.7499534767234 21.7 35.66895039608993 139.75004573138747 21.7 35.66895039608993 139.75004573138747 15.6 35.66894547607789 139.75006091378822 15.6 35.66894547607789 139.75006091378822 13.1 35.66894204915773 139.75007148842877 13.1 35.66894204915773 139.75007148842877 5.757 35.668980284881584 139.7499534767234 5.757 35.668980284881584 139.7499534767234 21.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7a68723f-9080-42e3-a365-9dffdc43a1af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a68723f-9080-42e3-a365-9dffdc43a1af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a68723f-9080-42e3-a365-9dffdc43a1af">
											<gml:posList>35.66897773492995 139.74995482699524 21.7 35.66897773492995 139.74995482699524 21.309 35.66894928524691 139.75004261755151 21.309 35.66894928524691 139.75004261755151 21.7 35.66897773492995 139.74995482699524 21.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8497</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">76.7331</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>