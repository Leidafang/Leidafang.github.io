<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_7259a297-b0a7-416d-b1c9-d785bdd17879">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:measuredHeight uom="m">12.3</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67161053569216 139.7383649480622 0 35.671550971552136 139.73838600681665 0 35.67158615285685 139.7385356442167 0 35.67164566293186 139.73851457458161 0 35.67161053569216 139.7383649480622 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67161053569216 139.7383649480622 10.5 35.67164566293186 139.73851457458161 10.5 35.67158615285685 139.7385356442167 10.5 35.671550971552136 139.73838600681665 10.5 35.67161053569216 139.7383649480622 10.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67161053569216 139.7383649480622 10.5 35.671550971552136 139.73838600681665 10.5 35.671550971552136 139.73838600681665 22.82 35.67161053569216 139.7383649480622 22.82 35.67161053569216 139.7383649480622 10.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671550971552136 139.73838600681665 10.5 35.67158615285685 139.7385356442167 10.5 35.67158615285685 139.7385356442167 22.82 35.671550971552136 139.73838600681665 22.82 35.671550971552136 139.73838600681665 10.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67158615285685 139.7385356442167 10.5 35.67164566293186 139.73851457458161 10.5 35.67164566293186 139.73851457458161 22.82 35.67158615285685 139.7385356442167 22.82 35.67158615285685 139.7385356442167 10.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67164566293186 139.73851457458161 10.5 35.67161053569216 139.7383649480622 10.5 35.67161053569216 139.7383649480622 22.82 35.67164566293186 139.73851457458161 22.82 35.67164566293186 139.73851457458161 10.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67161053569216 139.7383649480622 22.82 35.671550971552136 139.73838600681665 22.82 35.67158615285685 139.7385356442167 22.82 35.67164566293186 139.73851457458161 22.82 35.67161053569216 139.7383649480622 22.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-eb83ab42-17a2-4372-97ef-88a8bf7020b8"/>
							<gml:surfaceMember xlink:href="#poly-e5151466-6851-4066-9d41-e7cbb0c0be3c"/>
							<gml:surfaceMember xlink:href="#poly-c0178f76-92d0-4efd-a356-600a5a08a817"/>
							<gml:surfaceMember xlink:href="#poly-4946faa6-f486-4293-88c4-edc9de9781d8"/>
							<gml:surfaceMember xlink:href="#poly-4e79f698-3842-40eb-b550-de4407449a82"/>
							<gml:surfaceMember xlink:href="#poly-ed5a4c80-0d34-4f65-9d4f-4f066239a279"/>
							<gml:surfaceMember xlink:href="#poly-84402f30-b8dd-4880-93b5-abca6e2a097e"/>
							<gml:surfaceMember xlink:href="#poly-54409137-e5da-41a8-9bb7-54d9a4d921b9"/>
							<gml:surfaceMember xlink:href="#poly-08bf04a3-357d-4241-889b-1d4db7a63f8a"/>
							<gml:surfaceMember xlink:href="#poly-27adfa5f-fc22-4693-ae36-7b41986d8b25"/>
							<gml:surfaceMember xlink:href="#poly-571aa872-6d88-437c-bc77-5599e85312fb"/>
							<gml:surfaceMember xlink:href="#poly-60e2f1f7-0b36-4071-ae98-e97e5337a685"/>
							<gml:surfaceMember xlink:href="#poly-73d4190d-24c5-46b5-a5a9-8d6df0661d26"/>
							<gml:surfaceMember xlink:href="#poly-75703879-8608-463d-9714-4f74f387b17d"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_7259a297-b0a7-416d-b1c9-d785bdd17879_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c927b7ba-d744-4f35-a3cf-d549c9500b42">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671607105836 139.73846197290453 23.487 35.671615306084696 139.73845912426864 23.487 35.67161729590912 139.738467760222 23.487 35.67160909566023 139.73847060885706 23.487 35.671607105836 139.73846197290453 23.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-995b30d1-dea4-4cf1-8d6a-f1005a5bc133">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671587208711095 139.73846855802597 23.487 35.671605537631436 139.7384622067352 23.487 35.67160759076925 139.73847111877336 23.487 35.671589261848446 139.73847747006224 23.487 35.671587208711095 139.73846855802597 23.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-954c7fe5-ed8e-4db3-8362-8796f4dfaef0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671612772451155 139.73849246538975 23.487 35.671614716960995 139.73850079209723 23.487 35.6716064716688 139.7385036739214 23.487 35.67160453617288 139.73849534720404 23.487 35.671612772451155 139.73849246538975 23.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-396df4df-b5b1-4e57-8b17-707ffac8a716">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67159435346163 139.73849890515208 23.487 35.671602887114474 139.73849592356893 23.487 35.67160483162407 139.73850425027547 23.487 35.67159629797102 139.73850723185785 23.487 35.67159435346163 139.73849890515208 23.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b157b6a-b27e-48a3-8a39-c032e050424a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4b157b6a-b27e-48a3-8a39-c032e050424a_0">
											<gml:posList>35.67160909566023 139.73847060885706 23.487 35.67160909566023 139.73847060885706 24.296 35.671607105836 139.73846197290453 24.296 35.671607105836 139.73846197290453 23.487 35.67160909566023 139.73847060885706 23.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c399e38d-d35e-40b3-9366-09f29fe2d2e1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c399e38d-d35e-40b3-9366-09f29fe2d2e1_0">
											<gml:posList>35.67160483162407 139.73850425027547 23.487 35.671602887114474 139.73849592356893 23.487 35.671602887114474 139.73849592356893 24.665 35.67160483162407 139.73850425027547 24.665 35.67160483162407 139.73850425027547 23.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb0f8d60-7504-4477-a6ce-bf92940a8083">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fb0f8d60-7504-4477-a6ce-bf92940a8083_0">
											<gml:posList>35.671587208711095 139.73846855802597 23.487 35.671589261848446 139.73847747006224 23.487 35.671589261848446 139.73847747006224 24.641 35.671587208711095 139.73846855802597 24.641 35.671587208711095 139.73846855802597 23.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f5f8050-253d-4b84-905b-84e3e7bddd0a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9f5f8050-253d-4b84-905b-84e3e7bddd0a_0">
											<gml:posList>35.67159435346163 139.73849890515208 23.487 35.67159629797102 139.73850723185785 23.487 35.67159629797102 139.73850723185785 24.665 35.67159435346163 139.73849890515208 24.665 35.67159435346163 139.73849890515208 23.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f800380-b69f-4dbd-80ac-029ef20ce37f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2f800380-b69f-4dbd-80ac-029ef20ce37f_0">
											<gml:posList>35.671605537631436 139.7384622067352 23.487 35.671587208711095 139.73846855802597 23.487 35.671587208711095 139.73846855802597 24.641 35.671605537631436 139.7384622067352 24.641 35.671605537631436 139.7384622067352 23.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-23ac475e-34c2-495f-bf01-02e7a00df234">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-23ac475e-34c2-495f-bf01-02e7a00df234_0">
											<gml:posList>35.67160759076925 139.73847111877336 24.641 35.671605537631436 139.7384622067352 24.641 35.671587208711095 139.73846855802597 24.641 35.671589261848446 139.73847747006224 24.641 35.67160759076925 139.73847111877336 24.641</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25e7260f-a6b7-4323-b995-1906ff339428">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-25e7260f-a6b7-4323-b995-1906ff339428_0">
											<gml:posList>35.671589261848446 139.73847747006224 23.487 35.67160759076925 139.73847111877336 23.487 35.67160759076925 139.73847111877336 24.641 35.671589261848446 139.73847747006224 24.641 35.671589261848446 139.73847747006224 23.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e1e07be-bd00-4b47-8955-6c85c519a356">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4e1e07be-bd00-4b47-8955-6c85c519a356_0">
											<gml:posList>35.671602887114474 139.73849592356893 23.487 35.67159435346163 139.73849890515208 23.487 35.67159435346163 139.73849890515208 24.665 35.671602887114474 139.73849592356893 24.665 35.671602887114474 139.73849592356893 23.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18cda227-9ac5-402b-850f-f56f2a49853e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-18cda227-9ac5-402b-850f-f56f2a49853e_0">
											<gml:posList>35.67159435346163 139.73849890515208 24.665 35.67159629797102 139.73850723185785 24.665 35.67160483162407 139.73850425027547 24.665 35.671602887114474 139.73849592356893 24.665 35.67159435346163 139.73849890515208 24.665</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a3b888a5-dcf7-4427-86ab-5a42adfdc4ac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a3b888a5-dcf7-4427-86ab-5a42adfdc4ac_0">
											<gml:posList>35.67159629797102 139.73850723185785 23.487 35.67160483162407 139.73850425027547 23.487 35.67160483162407 139.73850425027547 24.665 35.67159629797102 139.73850723185785 24.665 35.67159629797102 139.73850723185785 23.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac064180-a1a4-4e5b-b807-9e3ce1483dd9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ac064180-a1a4-4e5b-b807-9e3ce1483dd9_0">
											<gml:posList>35.67160453617288 139.73849534720404 23.487 35.6716064716688 139.7385036739214 23.487 35.6716064716688 139.7385036739214 24.665 35.67160453617288 139.73849534720404 24.665 35.67160453617288 139.73849534720404 23.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-504964d9-2ca6-4163-8f62-d4966bc9b555">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-504964d9-2ca6-4163-8f62-d4966bc9b555_0">
											<gml:posList>35.67160759076925 139.73847111877336 23.487 35.671605537631436 139.7384622067352 23.487 35.671605537631436 139.7384622067352 24.641 35.67160759076925 139.73847111877336 24.641 35.67160759076925 139.73847111877336 23.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b709223-c96d-4b99-b111-ec7337b45afa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6b709223-c96d-4b99-b111-ec7337b45afa_0">
											<gml:posList>35.671612772451155 139.73849246538975 23.487 35.67160453617288 139.73849534720404 23.487 35.67160453617288 139.73849534720404 24.665 35.671612772451155 139.73849246538975 24.665 35.671612772451155 139.73849246538975 23.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8ff05680-ca3f-49f5-8409-efa9621f7777">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8ff05680-ca3f-49f5-8409-efa9621f7777_0">
											<gml:posList>35.671612772451155 139.73849246538975 24.665 35.67160453617288 139.73849534720404 24.665 35.6716064716688 139.7385036739214 24.665 35.671614716960995 139.73850079209723 24.665 35.671612772451155 139.73849246538975 24.665</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4cc981a5-2ed5-44a0-94e7-8ccc21953090">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4cc981a5-2ed5-44a0-94e7-8ccc21953090_0">
											<gml:posList>35.6716064716688 139.7385036739214 23.487 35.671614716960995 139.73850079209723 23.487 35.671614716960995 139.73850079209723 24.665 35.6716064716688 139.7385036739214 24.665 35.6716064716688 139.7385036739214 23.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0352f075-c1f2-4539-9475-ea9a64827d67">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0352f075-c1f2-4539-9475-ea9a64827d67_0">
											<gml:posList>35.671615306084696 139.73845912426864 23.487 35.671607105836 139.73846197290453 23.487 35.671607105836 139.73846197290453 24.296 35.671615306084696 139.73845912426864 24.296 35.671615306084696 139.73845912426864 23.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e108030-20ba-4137-b5a1-0efa9dc94073">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e108030-20ba-4137-b5a1-0efa9dc94073_0">
											<gml:posList>35.67161729590912 139.738467760222 24.296 35.671615306084696 139.73845912426864 24.296 35.671607105836 139.73846197290453 24.296 35.67160909566023 139.73847060885706 24.296 35.67161729590912 139.738467760222 24.296</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-39706bfb-aede-4d8d-b02f-d5b299201a27">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-39706bfb-aede-4d8d-b02f-d5b299201a27_0">
											<gml:posList>35.67160909566023 139.73847060885706 23.487 35.67161729590912 139.738467760222 23.487 35.67161729590912 139.738467760222 24.296 35.67160909566023 139.73847060885706 24.296 35.67160909566023 139.73847060885706 23.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd803136-fa33-4e8d-9af2-ec050fd85b76">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dd803136-fa33-4e8d-9af2-ec050fd85b76_0">
											<gml:posList>35.671614716960995 139.73850079209723 23.487 35.671612772451155 139.73849246538975 23.487 35.671612772451155 139.73849246538975 24.665 35.671614716960995 139.73850079209723 24.665 35.671614716960995 139.73850079209723 23.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e8d6a76-dda7-4ad5-ae83-9711bab615bf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4e8d6a76-dda7-4ad5-ae83-9711bab615bf_0">
											<gml:posList>35.67161729590912 139.738467760222 23.487 35.671615306084696 139.73845912426864 23.487 35.671615306084696 139.73845912426864 24.296 35.67161729590912 139.738467760222 24.296 35.67161729590912 139.738467760222 23.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-eb83ab42-17a2-4372-97ef-88a8bf7020b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eb83ab42-17a2-4372-97ef-88a8bf7020b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eb83ab42-17a2-4372-97ef-88a8bf7020b8">
											<gml:posList>35.67161053569217 139.7383649480622 10.5 35.67164566293183 139.73851457458161 10.5 35.67158615285684 139.7385356442167 10.5 35.671550971552136 139.73838600681665 10.5 35.67161053569217 139.7383649480622 10.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e5151466-6851-4066-9d41-e7cbb0c0be3c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5151466-6851-4066-9d41-e7cbb0c0be3c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5151466-6851-4066-9d41-e7cbb0c0be3c">
											<gml:posList>35.67158615285684 139.7385356442167 24.083 35.671588348386706 139.73853079223983 24.083 35.67155493971441 139.73838869744404 24.083 35.671550971552136 139.73838600681665 24.083 35.67158615285684 139.7385356442167 24.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c0178f76-92d0-4efd-a356-600a5a08a817">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0178f76-92d0-4efd-a356-600a5a08a817">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0178f76-92d0-4efd-a356-600a5a08a817">
											<gml:posList>35.671550971552136 139.73838600681665 24.083 35.67155493971441 139.73838869744404 24.083 35.67160834919145 139.7383698110807 24.083 35.67161053569217 139.7383649480622 24.083 35.671550971552136 139.73838600681665 24.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4946faa6-f486-4293-88c4-edc9de9781d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4946faa6-f486-4293-88c4-edc9de9781d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4946faa6-f486-4293-88c4-edc9de9781d8">
											<gml:posList>35.67164170379483 139.73851189498075 23.487 35.67160834919145 139.7383698110807 23.487 35.67155493971441 139.73838869744404 23.487 35.671588348386706 139.73853079223983 23.487 35.67164170379483 139.73851189498075 23.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4e79f698-3842-40eb-b550-de4407449a82">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4e79f698-3842-40eb-b550-de4407449a82">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4e79f698-3842-40eb-b550-de4407449a82">
											<gml:posList>35.67164566293183 139.73851457458161 24.083 35.67164170379483 139.73851189498075 24.083 35.671588348386706 139.73853079223983 24.083 35.67158615285684 139.7385356442167 24.083 35.67164566293183 139.73851457458161 24.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ed5a4c80-0d34-4f65-9d4f-4f066239a279">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed5a4c80-0d34-4f65-9d4f-4f066239a279">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed5a4c80-0d34-4f65-9d4f-4f066239a279">
											<gml:posList>35.67161053569217 139.7383649480622 24.083 35.67160834919145 139.7383698110807 24.083 35.67164170379483 139.73851189498075 24.083 35.67164566293183 139.73851457458161 24.083 35.67161053569217 139.7383649480622 24.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-84402f30-b8dd-4880-93b5-abca6e2a097e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84402f30-b8dd-4880-93b5-abca6e2a097e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84402f30-b8dd-4880-93b5-abca6e2a097e">
											<gml:posList>35.67164566293183 139.73851457458161 10.5 35.67161053569217 139.7383649480622 10.5 35.67161053569217 139.7383649480622 24.083 35.67164566293183 139.73851457458161 24.083 35.67164566293183 139.73851457458161 10.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-54409137-e5da-41a8-9bb7-54d9a4d921b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-54409137-e5da-41a8-9bb7-54d9a4d921b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-54409137-e5da-41a8-9bb7-54d9a4d921b9">
											<gml:posList>35.671550971552136 139.73838600681665 10.5 35.67158615285684 139.7385356442167 10.5 35.67158615285684 139.7385356442167 24.083 35.671550971552136 139.73838600681665 24.083 35.671550971552136 139.73838600681665 10.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-08bf04a3-357d-4241-889b-1d4db7a63f8a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-08bf04a3-357d-4241-889b-1d4db7a63f8a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-08bf04a3-357d-4241-889b-1d4db7a63f8a">
											<gml:posList>35.671588348386706 139.73853079223983 24.083 35.671588348386706 139.73853079223983 23.487 35.67155493971441 139.73838869744404 23.487 35.67155493971441 139.73838869744404 24.083 35.671588348386706 139.73853079223983 24.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-27adfa5f-fc22-4693-ae36-7b41986d8b25">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-27adfa5f-fc22-4693-ae36-7b41986d8b25">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-27adfa5f-fc22-4693-ae36-7b41986d8b25">
											<gml:posList>35.67161053569217 139.7383649480622 10.5 35.671550971552136 139.73838600681665 10.5 35.671550971552136 139.73838600681665 24.083 35.67161053569217 139.7383649480622 24.083 35.67161053569217 139.7383649480622 10.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-571aa872-6d88-437c-bc77-5599e85312fb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-571aa872-6d88-437c-bc77-5599e85312fb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-571aa872-6d88-437c-bc77-5599e85312fb">
											<gml:posList>35.67155493971441 139.73838869744404 24.083 35.67155493971441 139.73838869744404 23.487 35.67160834919145 139.7383698110807 23.487 35.67160834919145 139.7383698110807 24.083 35.67155493971441 139.73838869744404 24.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-60e2f1f7-0b36-4071-ae98-e97e5337a685">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-60e2f1f7-0b36-4071-ae98-e97e5337a685">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-60e2f1f7-0b36-4071-ae98-e97e5337a685">
											<gml:posList>35.67164170379483 139.73851189498075 24.083 35.67164170379483 139.73851189498075 23.487 35.671588348386706 139.73853079223983 23.487 35.671588348386706 139.73853079223983 24.083 35.67164170379483 139.73851189498075 24.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-73d4190d-24c5-46b5-a5a9-8d6df0661d26">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73d4190d-24c5-46b5-a5a9-8d6df0661d26">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73d4190d-24c5-46b5-a5a9-8d6df0661d26">
											<gml:posList>35.67158615285684 139.7385356442167 10.5 35.67164566293183 139.73851457458161 10.5 35.67164566293183 139.73851457458161 24.083 35.67158615285684 139.7385356442167 24.083 35.67158615285684 139.7385356442167 10.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-75703879-8608-463d-9714-4f74f387b17d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-75703879-8608-463d-9714-4f74f387b17d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-75703879-8608-463d-9714-4f74f387b17d">
											<gml:posList>35.67160834919145 139.7383698110807 24.083 35.67160834919145 139.7383698110807 23.487 35.67164170379483 139.73851189498075 23.487 35.67164170379483 139.73851189498075 24.083 35.67160834919145 139.7383698110807 24.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-446</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">2</uro:rank>
					<uro:depth uom="m">0.79</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>