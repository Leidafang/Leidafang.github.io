<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_72c49bd6-2833-4ae5-b610-0969deed3b63">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.672222669288495 139.74163559262757 0 35.67223495783902 139.74161565065913 0 35.67221733280276 139.7415996202394 0 35.67220514329642 139.74161941848797 0 35.672222669288495 139.74163559262757 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672222669288495 139.74163559262757 7.818 35.67220514329642 139.74161941848797 7.818 35.67221733280276 139.7415996202394 7.818 35.67223495783902 139.74161565065913 7.818 35.672222669288495 139.74163559262757 7.818</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672222669288495 139.74163559262757 7.818 35.67223495783902 139.74161565065913 7.818 35.67223495783902 139.74161565065913 10.818 35.672222669288495 139.74163559262757 10.818 35.672222669288495 139.74163559262757 7.818</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67223495783902 139.74161565065913 7.818 35.67221733280276 139.7415996202394 7.818 35.67221733280276 139.7415996202394 10.818 35.67223495783902 139.74161565065913 10.818 35.67223495783902 139.74161565065913 7.818</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67221733280276 139.7415996202394 7.818 35.67220514329642 139.74161941848797 7.818 35.67220514329642 139.74161941848797 10.818 35.67221733280276 139.7415996202394 10.818 35.67221733280276 139.7415996202394 7.818</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67220514329642 139.74161941848797 7.818 35.672222669288495 139.74163559262757 7.818 35.672222669288495 139.74163559262757 10.818 35.67220514329642 139.74161941848797 10.818 35.67220514329642 139.74161941848797 7.818</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672222669288495 139.74163559262757 10.818 35.67223495783902 139.74161565065913 10.818 35.67221733280276 139.7415996202394 10.818 35.67220514329642 139.74161941848797 10.818 35.672222669288495 139.74163559262757 10.818</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-2086810c-c74b-4a8b-9197-1b86143005bb"/>
							<gml:surfaceMember xlink:href="#poly-43b3b0a6-20f7-418e-9605-1eba80cdc619"/>
							<gml:surfaceMember xlink:href="#poly-c482c213-8dab-464a-a845-dc5d4c4cf3e1"/>
							<gml:surfaceMember xlink:href="#poly-ff3a9db6-cbcb-4b62-a1e4-102716919c1c"/>
							<gml:surfaceMember xlink:href="#poly-31d1783b-3b68-429f-b8fd-99585ccb4e88"/>
							<gml:surfaceMember xlink:href="#poly-162d9119-d9f1-4aa1-82fc-8e85e876ad74"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-2086810c-c74b-4a8b-9197-1b86143005bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2086810c-c74b-4a8b-9197-1b86143005bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2086810c-c74b-4a8b-9197-1b86143005bb">
											<gml:posList>35.67220514329642 139.74161941848797 7.818 35.672217323789056 139.74159962024973 7.818 35.672234957838995 139.7416156506591 7.818 35.672222660274755 139.74163559263786 7.818 35.67220514329642 139.74161941848797 7.818</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-43b3b0a6-20f7-418e-9605-1eba80cdc619">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-43b3b0a6-20f7-418e-9605-1eba80cdc619">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-43b3b0a6-20f7-418e-9605-1eba80cdc619">
											<gml:posList>35.672217323789056 139.74159962024973 10.1 35.67220514329642 139.74161941848797 10.1 35.672222660274755 139.74163559263786 10.1 35.672234957838995 139.7416156506591 10.1 35.672217323789056 139.74159962024973 10.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c482c213-8dab-464a-a845-dc5d4c4cf3e1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c482c213-8dab-464a-a845-dc5d4c4cf3e1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c482c213-8dab-464a-a845-dc5d4c4cf3e1">
											<gml:posList>35.672217323789056 139.74159962024973 7.818 35.67220514329642 139.74161941848797 7.818 35.67220514329642 139.74161941848797 10.1 35.672217323789056 139.74159962024973 10.1 35.672217323789056 139.74159962024973 7.818</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ff3a9db6-cbcb-4b62-a1e4-102716919c1c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff3a9db6-cbcb-4b62-a1e4-102716919c1c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff3a9db6-cbcb-4b62-a1e4-102716919c1c">
											<gml:posList>35.67220514329642 139.74161941848797 7.818 35.672222660274755 139.74163559263786 7.818 35.672222660274755 139.74163559263786 10.1 35.67220514329642 139.74161941848797 10.1 35.67220514329642 139.74161941848797 7.818</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-31d1783b-3b68-429f-b8fd-99585ccb4e88">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31d1783b-3b68-429f-b8fd-99585ccb4e88">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31d1783b-3b68-429f-b8fd-99585ccb4e88">
											<gml:posList>35.672234957838995 139.7416156506591 7.818 35.672217323789056 139.74159962024973 7.818 35.672217323789056 139.74159962024973 10.1 35.672234957838995 139.7416156506591 10.1 35.672234957838995 139.7416156506591 7.818</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-162d9119-d9f1-4aa1-82fc-8e85e876ad74">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-162d9119-d9f1-4aa1-82fc-8e85e876ad74">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-162d9119-d9f1-4aa1-82fc-8e85e876ad74">
											<gml:posList>35.672222660274755 139.74163559263786 7.818 35.672234957838995 139.7416156506591 7.818 35.672234957838995 139.7416156506591 10.1 35.672222660274755 139.74163559263786 10.1 35.672222660274755 139.74163559263786 7.818</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4500</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">216</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>