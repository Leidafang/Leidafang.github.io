<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_74d320f0-521c-4742-b97c-301912ce4602">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">31.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67293481141441 139.73841813741808 0 35.67299220542475 139.73838842034206 0 35.67298740816442 139.7383745072842 0 35.673003482556744 139.73836677770328 0 35.672969778294906 139.73826152128433 0 35.67292362751559 139.73828372446593 0 35.67288230538223 139.73830249745114 0 35.67291400817117 139.7384072590451 0 35.67292874935416 139.73840056943794 0 35.67293481141441 139.73841813741808 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67293481141441 139.73841813741808 8.64 35.67292874935416 139.73840056943794 8.64 35.67291400817117 139.7384072590451 8.64 35.67288230538223 139.73830249745114 8.64 35.67292362751559 139.73828372446593 8.64 35.672969778294906 139.73826152128433 8.64 35.673003482556744 139.73836677770328 8.64 35.67298740816442 139.7383745072842 8.64 35.67299220542475 139.73838842034206 8.64 35.67293481141441 139.73841813741808 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67293481141441 139.73841813741808 8.64 35.67299220542475 139.73838842034206 8.64 35.67299220542475 139.73838842034206 39.81 35.67293481141441 139.73841813741808 39.81 35.67293481141441 139.73841813741808 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67299220542475 139.73838842034206 8.64 35.67298740816442 139.7383745072842 8.64 35.67298740816442 139.7383745072842 39.81 35.67299220542475 139.73838842034206 39.81 35.67299220542475 139.73838842034206 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67298740816442 139.7383745072842 8.64 35.673003482556744 139.73836677770328 8.64 35.673003482556744 139.73836677770328 39.81 35.67298740816442 139.7383745072842 39.81 35.67298740816442 139.7383745072842 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673003482556744 139.73836677770328 8.64 35.672969778294906 139.73826152128433 8.64 35.672969778294906 139.73826152128433 39.81 35.673003482556744 139.73836677770328 39.81 35.673003482556744 139.73836677770328 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672969778294906 139.73826152128433 8.64 35.67292362751559 139.73828372446593 8.64 35.67292362751559 139.73828372446593 39.81 35.672969778294906 139.73826152128433 39.81 35.672969778294906 139.73826152128433 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67292362751559 139.73828372446593 8.64 35.67288230538223 139.73830249745114 8.64 35.67288230538223 139.73830249745114 39.81 35.67292362751559 139.73828372446593 39.81 35.67292362751559 139.73828372446593 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67288230538223 139.73830249745114 8.64 35.67291400817117 139.7384072590451 8.64 35.67291400817117 139.7384072590451 39.81 35.67288230538223 139.73830249745114 39.81 35.67288230538223 139.73830249745114 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67291400817117 139.7384072590451 8.64 35.67292874935416 139.73840056943794 8.64 35.67292874935416 139.73840056943794 39.81 35.67291400817117 139.7384072590451 39.81 35.67291400817117 139.7384072590451 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67292874935416 139.73840056943794 8.64 35.67293481141441 139.73841813741808 8.64 35.67293481141441 139.73841813741808 39.81 35.67292874935416 139.73840056943794 39.81 35.67292874935416 139.73840056943794 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67293481141441 139.73841813741808 39.81 35.67299220542475 139.73838842034206 39.81 35.67298740816442 139.7383745072842 39.81 35.673003482556744 139.73836677770328 39.81 35.672969778294906 139.73826152128433 39.81 35.67292362751559 139.73828372446593 39.81 35.67288230538223 139.73830249745114 39.81 35.67291400817117 139.7384072590451 39.81 35.67292874935416 139.73840056943794 39.81 35.67293481141441 139.73841813741808 39.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-9ab3d918-1c20-454e-8372-16dff60c3dc5"/>
							<gml:surfaceMember xlink:href="#poly-612d297a-2389-4429-acab-fa63170357db"/>
							<gml:surfaceMember xlink:href="#poly-61036b8b-2d98-465a-b47d-523a85f7c4ba"/>
							<gml:surfaceMember xlink:href="#poly-2e55c7fd-aad7-4ef9-8a4d-af9f4fa47374"/>
							<gml:surfaceMember xlink:href="#poly-6db59d40-69c8-40d2-a5b5-1d310c6dfb9f"/>
							<gml:surfaceMember xlink:href="#poly-8cea3f6a-e527-4e71-a762-768e56c0d2f6"/>
							<gml:surfaceMember xlink:href="#poly-f800f5a1-9494-43db-9c11-964aa03f6aab"/>
							<gml:surfaceMember xlink:href="#poly-05b3ba85-e274-4131-bcbd-2a798bd33c71"/>
							<gml:surfaceMember xlink:href="#poly-33cbc39c-9e42-40b7-842b-c018355db2a0"/>
							<gml:surfaceMember xlink:href="#poly-76371f16-2213-45df-876f-7a352d1c129c"/>
							<gml:surfaceMember xlink:href="#poly-dbe181e3-13f3-4664-82ef-aaa62d12dc8e"/>
							<gml:surfaceMember xlink:href="#poly-5d2cdf54-67d9-4e2c-9d3e-6901226aa8f4"/>
							<gml:surfaceMember xlink:href="#poly-c94ddff6-c539-481c-aabf-e976bc0f6928"/>
							<gml:surfaceMember xlink:href="#poly-78463cbc-54f6-4dca-ad20-be0b81baba97"/>
							<gml:surfaceMember xlink:href="#poly-e316fe0f-8c6a-4e8e-91a8-86b71c125c77"/>
							<gml:surfaceMember xlink:href="#poly-668ff365-a469-4985-8b0c-21839f5da2c6"/>
							<gml:surfaceMember xlink:href="#poly-d5c384fb-2573-4333-9c7a-047498a87e51"/>
							<gml:surfaceMember xlink:href="#poly-10e43536-b9ed-41ca-86b6-71ded333a6f1"/>
							<gml:surfaceMember xlink:href="#poly-f74e63ff-7668-44b6-98c5-180b8518684d"/>
							<gml:surfaceMember xlink:href="#poly-1917800e-809c-483e-a72c-868d56eac312"/>
							<gml:surfaceMember xlink:href="#poly-7b721aee-709a-4cb3-af62-3c50309e951a"/>
							<gml:surfaceMember xlink:href="#poly-8750eb44-3a29-4010-adb8-a7602db46b61"/>
							<gml:surfaceMember xlink:href="#poly-9acbd20c-59c4-48ee-b95e-08ff4bb73b51"/>
							<gml:surfaceMember xlink:href="#poly-4c77ed5f-4151-4441-9828-439359e95ff0"/>
							<gml:surfaceMember xlink:href="#poly-d029a481-ffe1-4604-971a-bd4c1e9a5a3e"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_74d320f0-521c-4742-b97c-301912ce4602_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00e162f0-28b4-47b0-877e-fec203204163">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-00e162f0-28b4-47b0-877e-fec203204163_0">
											<gml:posList>35.672916633446796 139.73826162849406 39.277 35.67292362751558 139.7382837244659 8.86 35.67292362751558 139.7382837244659 39.277 35.672916633446796 139.73826162849406 39.277</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46147f89-0547-4776-bfc8-df99783d1306">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46147f89-0547-4776-bfc8-df99783d1306_0">
											<gml:posList>35.672916633446796 139.73826162849406 39.277 35.672916633446796 139.73826162849406 8.86 35.67292362751558 139.7382837244659 8.86 35.672916633446796 139.73826162849406 39.277</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf12788c-9530-4424-9db4-3aa71f1f8dc9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cf12788c-9530-4424-9db4-3aa71f1f8dc9_0">
											<gml:posList>35.672931313296026 139.73828001473902 39.277 35.672927816274886 139.73826898332163 39.277 35.67292362751558 139.7382837244659 39.277 35.672931313296026 139.73828001473902 39.277</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3044e286-814a-4b2a-a2b0-9d09649f0593">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3044e286-814a-4b2a-a2b0-9d09649f0593_0">
											<gml:posList>35.67292362751558 139.7382837244659 39.277 35.672927816274886 139.73826898332163 39.277 35.672916633446796 139.73826162849406 39.277 35.67292362751558 139.7382837244659 39.277</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4ecb659-aae3-4f1f-86e4-8f8edbd756f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b4ecb659-aae3-4f1f-86e4-8f8edbd756f0_0">
											<gml:posList>35.672927816274886 139.73826898332163 39.277 35.672924319252736 139.7382579519052 39.277 35.672916633446796 139.73826162849406 39.277 35.672927816274886 139.73826898332163 39.277</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eb7d0858-c209-4f2f-9428-425ad9599a0f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eb7d0858-c209-4f2f-9428-425ad9599a0f_0">
											<gml:posList>35.672927816274886 139.73826898332163 39.277 35.672931313296026 139.73828001473902 39.277 35.67294093631069 139.7382753968923 39.724 35.672927816274886 139.73826898332163 39.277</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-56288055-ca6a-405f-829c-9e14530b4dd4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-56288055-ca6a-405f-829c-9e14530b4dd4_0">
											<gml:posList>35.672937430292855 139.7382643875777 39.724 35.672927816274886 139.73826898332163 39.277 35.67294093631069 139.7382753968923 39.724 35.672937430292855 139.7382643875777 39.724</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-92d612c3-ca76-4ef2-99d4-888a1a3c5006">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-92d612c3-ca76-4ef2-99d4-888a1a3c5006_0">
											<gml:posList>35.672924319252736 139.7382579519052 39.277 35.67296276635167 139.738239624162 37.259 35.672916633446796 139.73826162849406 39.277 35.672924319252736 139.7382579519052 39.277</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4ef02e02-d9b6-4e1f-b255-26a8c4c79601">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4ef02e02-d9b6-4e1f-b255-26a8c4c79601_0">
											<gml:posList>35.672916633446796 139.73826162849406 39.277 35.67296276635167 139.738239624162 37.259 35.672916633446796 139.73826162849406 8.86 35.672916633446796 139.73826162849406 39.277</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e3ce0ab7-20b4-4f95-8ef3-28ddeb7be159">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e3ce0ab7-20b4-4f95-8ef3-28ddeb7be159_0">
											<gml:posList>35.67296276635167 139.738239624162 37.259 35.67296276635167 139.738239624162 8.86 35.672916633446796 139.73826162849406 8.86 35.67296276635167 139.738239624162 37.259</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c75f808-94c7-43fa-910a-0b3d613ff8f9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8c75f808-94c7-43fa-910a-0b3d613ff8f9_0">
											<gml:posList>35.672937430292855 139.7382643875777 39.724 35.67294093631069 139.7382753968923 39.724 35.672950550302716 139.73827076800856 40.08 35.672937430292855 139.7382643875777 39.724</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a701551a-b4bd-48f4-93d8-56f9122d105c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a701551a-b4bd-48f4-93d8-56f9122d105c_0">
											<gml:posList>35.6729470443019 139.73825978078602 40.08 35.672937430292855 139.7382643875777 39.724 35.672950550302716 139.73827076800856 40.08 35.6729470443019 139.73825978078602 40.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bbc99766-f5f0-4039-ad0e-51f6bf31630d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bbc99766-f5f0-4039-ad0e-51f6bf31630d_0">
											<gml:posList>35.67296276635167 139.738239624162 37.259 35.672924319252736 139.7382579519052 39.277 35.672927816274886 139.73826898332163 39.277 35.67296276635167 139.738239624162 37.259</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d52d2aeb-d75b-424a-b890-29899eba0d12">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d52d2aeb-d75b-424a-b890-29899eba0d12_0">
											<gml:posList>35.672966272328146 139.73825057824598 37.259 35.67296276635167 139.738239624162 37.259 35.672927816274886 139.73826898332163 39.277 35.672966272328146 139.73825057824598 37.259</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ae58eb1b-5c49-4c90-8d7b-b5559c510bed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ae58eb1b-5c49-4c90-8d7b-b5559c510bed_0">
											<gml:posList>35.6729470443019 139.73825978078602 40.08 35.672950550302716 139.73827076800856 40.08 35.672960164303255 139.7382661501703 40.316 35.6729470443019 139.73825978078602 40.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6929e69c-404a-42b4-af79-556ee7dfc510">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6929e69c-404a-42b4-af79-556ee7dfc510_0">
											<gml:posList>35.67295665831076 139.73825517399325 40.316 35.6729470443019 139.73825978078602 40.08 35.672960164303255 139.7382661501703 40.316 35.67295665831076 139.73825517399325 40.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-31c6e423-4ec5-4249-ab68-68a2033bc653">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-31c6e423-4ec5-4249-ab68-68a2033bc653_0">
											<gml:posList>35.67296977829489 139.73826152128433 40.419 35.67296627231942 139.73825056719937 40.419 35.67295665831076 139.73825517399325 40.316 35.67296977829489 139.73826152128433 40.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-08c731bc-9d99-4289-93b1-65c72e85f53d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-08c731bc-9d99-4289-93b1-65c72e85f53d_0">
											<gml:posList>35.672960164303255 139.7382661501703 40.316 35.67296977829489 139.73826152128433 40.419 35.67295665831076 139.73825517399325 40.316 35.672960164303255 139.7382661501703 40.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3cdf222f-479d-4e09-b1ef-de0af5a5ad7a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3cdf222f-479d-4e09-b1ef-de0af5a5ad7a_0">
											<gml:posList>35.67296627231942 139.73825056719937 40.419 35.67296977829489 139.73826152128433 40.419 35.672966272328146 139.73825057824598 37.259 35.67296627231942 139.73825056719937 40.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9cf1a51a-8f40-4e41-861e-216b0368c9bc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9cf1a51a-8f40-4e41-861e-216b0368c9bc_0">
											<gml:posList>35.67296977829489 139.73826152128433 40.419 35.67296977829489 139.73826152128433 8.86 35.672966272328146 139.73825057824598 37.259 35.67296977829489 139.73826152128433 40.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35dc8fdb-20a1-4714-9d5d-a3a665feb804">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-35dc8fdb-20a1-4714-9d5d-a3a665feb804_0">
											<gml:posList>35.672966272328146 139.73825057824598 37.259 35.67296276635167 139.738239624162 8.86 35.67296276635167 139.738239624162 37.259 35.672966272328146 139.73825057824598 37.259</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-159a091b-d895-4b74-88ba-9fea2abf56af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-159a091b-d895-4b74-88ba-9fea2abf56af_0">
											<gml:posList>35.672966272328146 139.73825057824598 37.259 35.67296977829489 139.73826152128433 8.86 35.67296276635167 139.738239624162 8.86 35.672966272328146 139.73825057824598 37.259</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5707c930-b198-498a-aa11-69a03bbd2366">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5707c930-b198-498a-aa11-69a03bbd2366_0">
											<gml:posList>35.672960164303255 139.7382661501703 40.316 35.672950550302716 139.73827076800856 40.08 35.67296977829489 139.73826152128433 40.419 35.672960164303255 139.7382661501703 40.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b438da3-42bf-4170-8dad-bea95385897a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b438da3-42bf-4170-8dad-bea95385897a_0">
											<gml:posList>35.67296977829489 139.73826152128433 40.419 35.672931313296026 139.73828001473902 39.277 35.67296977829489 139.73826152128433 8.86 35.67296977829489 139.73826152128433 40.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73f9088a-441e-447b-b06a-2151ddca2356">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73f9088a-441e-447b-b06a-2151ddca2356_0">
											<gml:posList>35.67296977829489 139.73826152128433 40.419 35.672950550302716 139.73827076800856 40.08 35.67294093631069 139.7382753968923 39.724 35.67296977829489 139.73826152128433 40.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-044d3da3-6577-4fa7-901e-d0c16431be8b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-044d3da3-6577-4fa7-901e-d0c16431be8b_0">
											<gml:posList>35.672931313296026 139.73828001473902 39.277 35.67292362751558 139.7382837244659 39.277 35.67292362751558 139.7382837244659 8.86 35.672931313296026 139.73828001473902 39.277</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa07ab68-f657-4a5d-a07e-ba898dc38ce4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aa07ab68-f657-4a5d-a07e-ba898dc38ce4_0">
											<gml:posList>35.67296977829489 139.73826152128433 8.86 35.672931313296026 139.73828001473902 39.277 35.67292362751558 139.7382837244659 8.86 35.67296977829489 139.73826152128433 8.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c11e4ed1-3627-4882-a214-335cc527c9f5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c11e4ed1-3627-4882-a214-335cc527c9f5_0">
											<gml:posList>35.67296977829489 139.73826152128433 40.419 35.67294093631069 139.7382753968923 39.724 35.672931313296026 139.73828001473902 39.277 35.67296977829489 139.73826152128433 40.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b8c964b-2960-45b6-8dfa-cb97363f8ee6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b8c964b-2960-45b6-8dfa-cb97363f8ee6_0">
											<gml:posList>35.67296627231942 139.73825056719937 40.419 35.672966272328146 139.73825057824598 37.259 35.67295665831076 139.73825517399325 40.316 35.67296627231942 139.73825056719937 40.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9619edd3-532b-4d63-9e67-1baec6a0fba3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9619edd3-532b-4d63-9e67-1baec6a0fba3_0">
											<gml:posList>35.67295665831076 139.73825517399325 40.316 35.672966272328146 139.73825057824598 37.259 35.6729470443019 139.73825978078602 40.08 35.67295665831076 139.73825517399325 40.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78181588-006c-4816-8890-e90802efc0d2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78181588-006c-4816-8890-e90802efc0d2_0">
											<gml:posList>35.6729470443019 139.73825978078602 40.08 35.672966272328146 139.73825057824598 37.259 35.672937430292855 139.7382643875777 39.724 35.6729470443019 139.73825978078602 40.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9adedfe7-6ed9-4a0a-b51c-f8cca52a7fa4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9adedfe7-6ed9-4a0a-b51c-f8cca52a7fa4_0">
											<gml:posList>35.672966272328146 139.73825057824598 37.259 35.672927816274886 139.73826898332163 39.277 35.672937430292855 139.7382643875777 39.724 35.672966272328146 139.73825057824598 37.259</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b6afb115-ac0b-4b74-95a0-f01d8ca385ca">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672916633446796 139.73826162849406 8.86 35.67296276635167 139.738239624162 8.86 35.67296977829489 139.73826152128433 8.86 35.67292362751558 139.7382837244659 8.86 35.672916633446796 139.73826162849406 8.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_74d320f0-521c-4742-b97c-301912ce4602_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df3ec929-0da2-4f3d-9b80-b85071375e8a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-df3ec929-0da2-4f3d-9b80-b85071375e8a_0">
											<gml:posList>35.6729215941927 139.73829993225257 40.023 35.672900041756485 139.73831057358956 41.736 35.6729215941927 139.73829993225257 41.736 35.6729215941927 139.73829993225257 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9c39c658-05f3-435c-a954-68028ec9942b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9c39c658-05f3-435c-a954-68028ec9942b_0">
											<gml:posList>35.6729215941927 139.73829993225257 40.023 35.672900041756485 139.73831057358956 40.023 35.672900041756485 139.73831057358956 41.736 35.6729215941927 139.73829993225257 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea7f4eb6-5e7c-4177-b033-acff1564af7f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea7f4eb6-5e7c-4177-b033-acff1564af7f_0">
											<gml:posList>35.672900041756485 139.73831057358956 40.023 35.67290210183567 139.7383168456204 41.736 35.672900041756485 139.73831057358956 41.736 35.672900041756485 139.73831057358956 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-977dea07-3fb6-445d-9ad7-653ab1ab3ca9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-977dea07-3fb6-445d-9ad7-653ab1ab3ca9_0">
											<gml:posList>35.672900041756485 139.73831057358956 40.023 35.67290210183567 139.7383168456204 40.023 35.67290210183567 139.7383168456204 41.736 35.672900041756485 139.73831057358956 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58f45d2e-1279-42bc-92d4-f39326312aee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-58f45d2e-1279-42bc-92d4-f39326312aee_0">
											<gml:posList>35.672988427377554 139.73835249016608 40.419 35.672985787386324 139.73835379679474 40.023 35.672988427377554 139.73835249016608 40.023 35.672988427377554 139.73835249016608 40.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f16b1187-1881-4aa9-8609-9f2708b8374e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f16b1187-1881-4aa9-8609-9f2708b8374e_0">
											<gml:posList>35.672988427377554 139.73835249016608 40.419 35.672985787386324 139.73835379679474 40.419 35.672985787386324 139.73835379679474 40.023 35.672988427377554 139.73835249016608 40.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4ca57000-d79d-4a10-9693-2ab981eb7abb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4ca57000-d79d-4a10-9693-2ab981eb7abb_0">
											<gml:posList>35.67291292798515 139.73835196100342 40.023 35.672920427363145 139.7383747633666 41.88 35.67291292798515 139.73835196100342 41.88 35.67291292798515 139.73835196100342 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-acfec4ab-71fc-466a-b7d7-e2fa32d7a856">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-acfec4ab-71fc-466a-b7d7-e2fa32d7a856_0">
											<gml:posList>35.67291292798515 139.73835196100342 40.023 35.672920427363145 139.7383747633666 40.023 35.672920427363145 139.7383747633666 41.88 35.67291292798515 139.73835196100342 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc1c628c-8b19-4d52-8a2f-7011cd54eb43">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cc1c628c-8b19-4d52-8a2f-7011cd54eb43_0">
											<gml:posList>35.672920427363145 139.7383747633666 40.023 35.6729280229744 139.738371009569 41.88 35.672920427363145 139.7383747633666 41.88 35.672920427363145 139.7383747633666 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-72c7c4fd-02af-4139-843a-a9dade060006">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-72c7c4fd-02af-4139-843a-a9dade060006_0">
											<gml:posList>35.672920427363145 139.7383747633666 40.023 35.6729280229744 139.738371009569 40.023 35.6729280229744 139.738371009569 41.88 35.672920427363145 139.7383747633666 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-581414d4-6cd7-4ab4-81c4-fdfd072b7174">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-581414d4-6cd7-4ab4-81c4-fdfd072b7174_0">
											<gml:posList>35.67291726779228 139.7383915800476 40.419 35.67291726779228 139.7383915800476 42.054 35.67291614740844 139.73838817901895 40.419 35.67291726779228 139.7383915800476 40.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-69368e9d-007a-4c5a-a664-547f7db78c92">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-69368e9d-007a-4c5a-a664-547f7db78c92_0">
											<gml:posList>35.67291614740844 139.73838817901895 40.023 35.67291614740844 139.73838817901895 40.419 35.6728902157835 139.73830929278313 40.023 35.67291614740844 139.73838817901895 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7fa9e2a4-ede6-4c24-9421-42949fe52cb3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7fa9e2a4-ede6-4c24-9421-42949fe52cb3_0">
											<gml:posList>35.6728902157835 139.73830929278313 40.023 35.67291614740844 139.73838817901895 40.419 35.6728902157835 139.73830929278313 42.054 35.6728902157835 139.73830929278313 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-beb1d8d7-92d0-4359-9b26-c006ebfcc4cc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-beb1d8d7-92d0-4359-9b26-c006ebfcc4cc_0">
											<gml:posList>35.67291614740844 139.73838817901895 40.419 35.67291726779228 139.7383915800476 42.054 35.6728902157835 139.73830929278313 42.054 35.67291614740844 139.73838817901895 40.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-87932c2a-bb21-4008-86cf-c430d82aae33">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-87932c2a-bb21-4008-86cf-c430d82aae33_0">
											<gml:posList>35.672918796413796 139.73838687238188 40.023 35.67289393096104 139.73831122153558 40.023 35.672918796413796 139.73838687238188 40.419 35.672918796413796 139.73838687238188 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-543462be-28e7-4cd1-a7f1-d9b6b4e8c623">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-543462be-28e7-4cd1-a7f1-d9b6b4e8c623_0">
											<gml:posList>35.67291899518597 139.73838746866335 40.419 35.672918796413796 139.73838687238188 40.419 35.67291899518597 139.73838746866335 42.054 35.67291899518597 139.73838746866335 40.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df3c089f-ed73-438b-a2d9-8161b5fe5a36">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-df3c089f-ed73-438b-a2d9-8161b5fe5a36_0">
											<gml:posList>35.67291899518597 139.73838746866335 42.054 35.672918796413796 139.73838687238188 40.419 35.67289393096104 139.73831122153558 42.054 35.67291899518597 139.73838746866335 42.054</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b16df65a-75a4-4798-ad62-72aa779ce638">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b16df65a-75a4-4798-ad62-72aa779ce638_0">
											<gml:posList>35.672918796413796 139.73838687238188 40.419 35.67289393096104 139.73831122153558 40.023 35.67289393096104 139.73831122153558 42.054 35.672918796413796 139.73838687238188 40.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ee048380-b66b-4f09-850a-1b4238272278">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ee048380-b66b-4f09-850a-1b4238272278_0">
											<gml:posList>35.672923654272445 139.73830620428484 41.736 35.672900041756485 139.73831057358956 41.736 35.67290210183567 139.7383168456204 41.736 35.672923654272445 139.73830620428484 41.736</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-769e5321-cd2b-4ee7-8753-ef66bc9ce586">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-769e5321-cd2b-4ee7-8753-ef66bc9ce586_0">
											<gml:posList>35.672923654272445 139.73830620428484 41.736 35.6729215941927 139.73829993225257 41.736 35.672900041756485 139.73831057358956 41.736 35.672923654272445 139.73830620428484 41.736</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-39009171-f90a-423c-918d-881f26a6e5b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-39009171-f90a-423c-918d-881f26a6e5b2_0">
											<gml:posList>35.67290210183567 139.7383168456204 40.023 35.672923654272445 139.73830620428484 41.736 35.67290210183567 139.7383168456204 41.736 35.67290210183567 139.7383168456204 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e73ffc4f-f9db-4514-8371-4ea69f22f7ad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e73ffc4f-f9db-4514-8371-4ea69f22f7ad_0">
											<gml:posList>35.67290210183567 139.7383168456204 40.023 35.672923654272445 139.73830620428484 40.023 35.672923654272445 139.73830620428484 41.736 35.67290210183567 139.7383168456204 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1139ed8c-b6a9-446c-b94f-86c6118308f4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1139ed8c-b6a9-446c-b94f-86c6118308f4_0">
											<gml:posList>35.67291292798515 139.73835196100342 40.023 35.67292053261812 139.73834821823993 41.88 35.67292053261812 139.73834821823993 40.023 35.67291292798515 139.73835196100342 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b357b3b7-2e09-40b6-ab20-9c9ebb55e1e1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b357b3b7-2e09-40b6-ab20-9c9ebb55e1e1_0">
											<gml:posList>35.67291292798515 139.73835196100342 40.023 35.67291292798515 139.73835196100342 41.88 35.67292053261812 139.73834821823993 41.88 35.67291292798515 139.73835196100342 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef7cc938-959f-4264-9f86-846c9f76ad2c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef7cc938-959f-4264-9f86-846c9f76ad2c_0">
											<gml:posList>35.672918796413796 139.73838687238188 40.023 35.67291614740844 139.73838817901895 40.419 35.67291614740844 139.73838817901895 40.023 35.672918796413796 139.73838687238188 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-edda3fb5-867e-4d4b-8c8f-2e3394eea48a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-edda3fb5-867e-4d4b-8c8f-2e3394eea48a_0">
											<gml:posList>35.672918796413796 139.73838687238188 40.023 35.672918796413796 139.73838687238188 40.419 35.67291614740844 139.73838817901895 40.419 35.672918796413796 139.73838687238188 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d43da60-d953-4908-b748-14fcfc1c0c16">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4d43da60-d953-4908-b748-14fcfc1c0c16_0">
											<gml:posList>35.67292053261812 139.73834821823993 41.88 35.67291292798515 139.73835196100342 41.88 35.672920427363145 139.7383747633666 41.88 35.67292053261812 139.73834821823993 41.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5073e8e1-ae0c-4804-b52c-08671d9d97dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5073e8e1-ae0c-4804-b52c-08671d9d97dd_0">
											<gml:posList>35.6729280229744 139.738371009569 41.88 35.67292053261812 139.73834821823993 41.88 35.672920427363145 139.7383747633666 41.88 35.6729280229744 139.738371009569 41.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-68401c1c-e24d-4a42-9784-0779696bfe5f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-68401c1c-e24d-4a42-9784-0779696bfe5f_0">
											<gml:posList>35.6728902157835 139.73830929278313 40.023 35.67295181862437 139.73827887471896 42.054 35.67295181862437 139.73827887471896 40.023 35.6728902157835 139.73830929278313 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fd12ff22-4e7f-40a7-b3ad-6ef00141606c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fd12ff22-4e7f-40a7-b3ad-6ef00141606c_0">
											<gml:posList>35.6728902157835 139.73830929278313 40.023 35.6728902157835 139.73830929278313 42.054 35.67295181862437 139.73827887471896 42.054 35.6728902157835 139.73830929278313 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-15214cbc-9498-4a8e-8a0b-a651a9294141">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-15214cbc-9498-4a8e-8a0b-a651a9294141_0">
											<gml:posList>35.6729502358027 139.73828342780035 40.023 35.67289393096104 139.73831122153558 42.054 35.67289393096104 139.73831122153558 40.023 35.6729502358027 139.73828342780035 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f4bd71e1-3b35-4047-9d31-3819d55ea2dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f4bd71e1-3b35-4047-9d31-3819d55ea2dd_0">
											<gml:posList>35.6729502358027 139.73828342780035 40.023 35.6729502358027 139.73828342780035 42.054 35.67289393096104 139.73831122153558 42.054 35.6729502358027 139.73828342780035 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38f5480b-2223-4b6a-8ec9-7d7b01d8490c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-38f5480b-2223-4b6a-8ec9-7d7b01d8490c_0">
											<gml:posList>35.6729215941927 139.73829993225257 40.023 35.672923654272445 139.73830620428484 41.736 35.672923654272445 139.73830620428484 40.023 35.6729215941927 139.73829993225257 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-660a64f2-518c-4ea1-bb85-e58e9650d6f3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-660a64f2-518c-4ea1-bb85-e58e9650d6f3_0">
											<gml:posList>35.6729215941927 139.73829993225257 40.023 35.6729215941927 139.73829993225257 41.736 35.672923654272445 139.73830620428484 41.736 35.6729215941927 139.73829993225257 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f2e247a9-63d8-4211-a275-55a7c6b736f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f2e247a9-63d8-4211-a275-55a7c6b736f0_0">
											<gml:posList>35.67292182834053 139.73832251124463 40.023 35.672926364034765 139.73833620366577 42.083 35.67292182834053 139.73832251124463 42.083 35.67292182834053 139.73832251124463 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-09ada472-6cdf-4107-97c1-a194656aed85">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-09ada472-6cdf-4107-97c1-a194656aed85_0">
											<gml:posList>35.67292182834053 139.73832251124463 40.023 35.672926364034765 139.73833620366577 40.023 35.672926364034765 139.73833620366577 42.083 35.67292182834053 139.73832251124463 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-909177d4-1892-4a69-8549-930b229df803">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-909177d4-1892-4a69-8549-930b229df803_0">
											<gml:posList>35.67292053261812 139.73834821823993 40.023 35.6729280229744 139.738371009569 41.88 35.6729280229744 139.738371009569 40.023 35.67292053261812 139.73834821823993 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a9794eb-8c55-49a0-ad6e-84922c8a19ff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a9794eb-8c55-49a0-ad6e-84922c8a19ff_0">
											<gml:posList>35.67292053261812 139.73834821823993 40.023 35.67292053261812 139.73834821823993 41.88 35.6729280229744 139.738371009569 41.88 35.67292053261812 139.73834821823993 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d5cb3cce-2430-400b-9f0b-eb15a38c2bfe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d5cb3cce-2430-400b-9f0b-eb15a38c2bfe_0">
											<gml:posList>35.67292880223021 139.7383190453907 40.023 35.67292182834053 139.73832251124463 42.083 35.67292880223021 139.7383190453907 42.083 35.67292880223021 139.7383190453907 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b41e2d50-4f26-49a3-9594-0239f084d644">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b41e2d50-4f26-49a3-9594-0239f084d644_0">
											<gml:posList>35.67292880223021 139.7383190453907 40.023 35.67292182834053 139.73832251124463 40.023 35.67292182834053 139.73832251124463 42.083 35.67292880223021 139.7383190453907 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-832871b6-4433-417a-b122-c1ddc019d5e6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-832871b6-4433-417a-b122-c1ddc019d5e6_0">
											<gml:posList>35.672926364034765 139.73833620366577 42.083 35.67293333792483 139.73833273781284 42.083 35.67292880223021 139.7383190453907 42.083 35.672926364034765 139.73833620366577 42.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-141df74f-b3f9-4195-863b-730117d81f70">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-141df74f-b3f9-4195-863b-730117d81f70_0">
											<gml:posList>35.67292182834053 139.73832251124463 42.083 35.672926364034765 139.73833620366577 42.083 35.67292880223021 139.7383190453907 42.083 35.67292182834053 139.73832251124463 42.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f43c95d-c293-4610-960e-069c02a8793b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f43c95d-c293-4610-960e-069c02a8793b_0">
											<gml:posList>35.672926364034765 139.73833620366577 40.023 35.67293333792483 139.73833273781284 42.083 35.672926364034765 139.73833620366577 42.083 35.672926364034765 139.73833620366577 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-299b21fd-4888-4898-90d9-ef729aea10f6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-299b21fd-4888-4898-90d9-ef729aea10f6_0">
											<gml:posList>35.672926364034765 139.73833620366577 40.023 35.67293333792483 139.73833273781284 40.023 35.67293333792483 139.73833273781284 42.083 35.672926364034765 139.73833620366577 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6596239d-4a4d-4bde-bc3a-04fc37eea590">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6596239d-4a4d-4bde-bc3a-04fc37eea590_0">
											<gml:posList>35.67293333792483 139.73833273781284 40.023 35.67292880223021 139.7383190453907 42.083 35.67293333792483 139.73833273781284 42.083 35.67293333792483 139.73833273781284 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0328fccf-b044-4000-8d18-50a37c510887">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0328fccf-b044-4000-8d18-50a37c510887_0">
											<gml:posList>35.67293333792483 139.73833273781284 40.023 35.67292880223021 139.7383190453907 40.023 35.67292880223021 139.7383190453907 42.083 35.67293333792483 139.73833273781284 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16f7fc4d-2687-40ce-b203-302caad24eb1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16f7fc4d-2687-40ce-b203-302caad24eb1_0">
											<gml:posList>35.67298971942386 139.73835639913835 42.054 35.672968431991045 139.73829164700226 42.054 35.672985977136236 139.7383543820407 42.054 35.67298971942386 139.73835639913835 42.054</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eabf7c12-5606-490b-8921-803753bf40c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eabf7c12-5606-490b-8921-803753bf40c1_0">
											<gml:posList>35.6728902157835 139.73830929278313 42.054 35.67289393096104 139.73831122153558 42.054 35.67295181862437 139.73827887471896 42.054 35.6728902157835 139.73830929278313 42.054</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ebc2e967-2d2a-4912-87a4-4f84e2f5414e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ebc2e967-2d2a-4912-87a4-4f84e2f5414e_0">
											<gml:posList>35.67295181862437 139.73827887471896 42.054 35.6729502358027 139.73828342780035 42.054 35.67295775488518 139.73829691784843 42.054 35.67295181862437 139.73827887471896 42.054</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0548f627-bf2f-4c42-aae4-c5e81df92d69">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0548f627-bf2f-4c42-aae4-c5e81df92d69_0">
											<gml:posList>35.6729668491689 139.7382962000843 42.054 35.672968431991045 139.73829164700226 42.054 35.67295775488518 139.73829691784843 42.054 35.6729668491689 139.7382962000843 42.054</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b61769d-4ae9-46ff-a52b-6599f9bc35a4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1b61769d-4ae9-46ff-a52b-6599f9bc35a4_0">
											<gml:posList>35.67298971942386 139.73835639913835 42.054 35.67291899518597 139.73838746866335 42.054 35.67291726779228 139.7383915800476 42.054 35.67298971942386 139.73835639913835 42.054</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3652a48d-6fda-40f7-8b72-764d69e59516">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3652a48d-6fda-40f7-8b72-764d69e59516_0">
											<gml:posList>35.67289393096104 139.73831122153558 42.054 35.6728902157835 139.73830929278313 42.054 35.67291726779228 139.7383915800476 42.054 35.67289393096104 139.73831122153558 42.054</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd76d67a-7989-4f13-bd28-c00dcdee683b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cd76d67a-7989-4f13-bd28-c00dcdee683b_0">
											<gml:posList>35.672985977136236 139.7383543820407 42.054 35.672968431991045 139.73829164700226 42.054 35.6729668491689 139.7382962000843 42.054 35.672985977136236 139.7383543820407 42.054</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63469717-22d3-4f82-8ce0-ed04331aa015">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-63469717-22d3-4f82-8ce0-ed04331aa015_0">
											<gml:posList>35.67298971942386 139.73835639913835 42.054 35.672985977136236 139.7383543820407 42.054 35.67291899518597 139.73838746866335 42.054 35.67298971942386 139.73835639913835 42.054</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-52486f76-91f5-4f2c-8e9c-8ed60adc3023">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-52486f76-91f5-4f2c-8e9c-8ed60adc3023_0">
											<gml:posList>35.67295181862437 139.73827887471896 42.054 35.67289393096104 139.73831122153558 42.054 35.6729502358027 139.73828342780035 42.054 35.67295181862437 139.73827887471896 42.054</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e00d7708-1bbe-4329-82c8-660f73ed94ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e00d7708-1bbe-4329-82c8-660f73ed94ca_0">
											<gml:posList>35.67295617206284 139.7383014709298 42.054 35.67295775488518 139.73829691784843 42.054 35.6729502358027 139.73828342780035 42.054 35.67295617206284 139.7383014709298 42.054</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25a9e633-d38b-437f-995c-c47568ad071b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-25a9e633-d38b-437f-995c-c47568ad071b_0">
											<gml:posList>35.67295617206284 139.7383014709298 42.054 35.6729668491689 139.7382962000843 42.054 35.67295775488518 139.73829691784843 42.054 35.67295617206284 139.7383014709298 42.054</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1dc531ed-53ba-45bd-81b7-952c9dcd2f2c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1dc531ed-53ba-45bd-81b7-952c9dcd2f2c_0">
											<gml:posList>35.67291899518597 139.73838746866335 42.054 35.67289393096104 139.73831122153558 42.054 35.67291726779228 139.7383915800476 42.054 35.67291899518597 139.73838746866335 42.054</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f740cf2b-db0e-4947-b36a-3762d70edde0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f740cf2b-db0e-4947-b36a-3762d70edde0_0">
											<gml:posList>35.67291899518597 139.73838746866335 40.419 35.672985977136236 139.7383543820407 42.054 35.672985977136236 139.7383543820407 40.419 35.67291899518597 139.73838746866335 40.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ffb8152-53e0-4340-b081-8130e90b0fb8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3ffb8152-53e0-4340-b081-8130e90b0fb8_0">
											<gml:posList>35.67291899518597 139.73838746866335 40.419 35.67291899518597 139.73838746866335 42.054 35.672985977136236 139.7383543820407 42.054 35.67291899518597 139.73838746866335 40.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cafe84a8-11e6-4eba-99a2-b52d5e2e6492">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cafe84a8-11e6-4eba-99a2-b52d5e2e6492_0">
											<gml:posList>35.6729502358027 139.73828342780035 40.023 35.67295617206284 139.7383014709298 42.054 35.6729502358027 139.73828342780035 42.054 35.6729502358027 139.73828342780035 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b172569-c26b-4d69-8b82-d9e1213c8ca4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7b172569-c26b-4d69-8b82-d9e1213c8ca4_0">
											<gml:posList>35.6729502358027 139.73828342780035 40.023 35.67295617206284 139.7383014709298 40.023 35.67295617206284 139.7383014709298 42.054 35.6729502358027 139.73828342780035 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eb9ea71f-02ee-46c9-b845-774c447de7e0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eb9ea71f-02ee-46c9-b845-774c447de7e0_0">
											<gml:posList>35.67298971942386 139.73835639913835 40.419 35.67291726779228 139.7383915800476 42.054 35.67291726779228 139.7383915800476 40.419 35.67298971942386 139.73835639913835 40.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bdc3c407-380a-46c2-baa8-cda4e5034624">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bdc3c407-380a-46c2-baa8-cda4e5034624_0">
											<gml:posList>35.67298971942386 139.73835639913835 40.419 35.67298971942386 139.73835639913835 42.054 35.67291726779228 139.7383915800476 42.054 35.67298971942386 139.73835639913835 40.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b00384c5-9ee7-41e0-b2f4-61c825142a01">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b00384c5-9ee7-41e0-b2f4-61c825142a01_0">
											<gml:posList>35.67295181862437 139.73827887471896 42.054 35.67295775488518 139.73829691784843 40.023 35.67295181862437 139.73827887471896 40.023 35.67295181862437 139.73827887471896 42.054</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f106d75-3bb3-4ac0-874d-c7e8df2e0785">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f106d75-3bb3-4ac0-874d-c7e8df2e0785_0">
											<gml:posList>35.67295181862437 139.73827887471896 42.054 35.67295775488518 139.73829691784843 42.054 35.67295775488518 139.73829691784843 40.023 35.67295181862437 139.73827887471896 42.054</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-45e07e99-c9f3-44ce-b532-0cd9540af926">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-45e07e99-c9f3-44ce-b532-0cd9540af926_0">
											<gml:posList>35.67295617206284 139.7383014709298 40.023 35.6729668491689 139.7382962000843 42.054 35.67295617206284 139.7383014709298 42.054 35.67295617206284 139.7383014709298 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd4f20b3-7d81-422b-9544-6e35992d658c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dd4f20b3-7d81-422b-9544-6e35992d658c_0">
											<gml:posList>35.67295617206284 139.7383014709298 40.023 35.6729668491689 139.7382962000843 40.023 35.6729668491689 139.7382962000843 42.054 35.67295617206284 139.7383014709298 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78b7761c-1184-4100-9188-1df116bb0d3a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78b7761c-1184-4100-9188-1df116bb0d3a_0">
											<gml:posList>35.672968431991045 139.73829164700226 40.023 35.67295775488518 139.73829691784843 42.054 35.672968431991045 139.73829164700226 42.054 35.672968431991045 139.73829164700226 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-21945221-a5ff-4803-903d-c2268af80722">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-21945221-a5ff-4803-903d-c2268af80722_0">
											<gml:posList>35.672968431991045 139.73829164700226 40.023 35.67295775488518 139.73829691784843 40.023 35.67295775488518 139.73829691784843 42.054 35.672968431991045 139.73829164700226 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb07169e-8fd3-4da0-b16d-b08c124518c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb07169e-8fd3-4da0-b16d-b08c124518c9_0">
											<gml:posList>35.67297827224584 139.73839101070487 37.597 35.67297827224584 139.73839101070487 37.957 35.67297331090072 139.7383747670075 37.597 35.67297827224584 139.73839101070487 37.597</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-194f320f-5dd6-486b-af30-59b69a8918a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-194f320f-5dd6-486b-af30-59b69a8918a5_0">
											<gml:posList>35.67297331090072 139.7383747670075 37.597 35.67297827224584 139.73839101070487 37.957 35.67297331090072 139.7383747670075 38.87 35.67297331090072 139.7383747670075 37.597</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4027697-4a18-4fd3-a2df-697e1b6cadaf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b4027697-4a18-4fd3-a2df-697e1b6cadaf_0">
											<gml:posList>35.67297331090072 139.7383747670075 38.87 35.67297827224584 139.73839101070487 37.957 35.672978443950704 139.73839157387903 38.87 35.67297331090072 139.7383747670075 38.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e95c107f-1321-4772-a33a-4c8c4c87af53">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e95c107f-1321-4772-a33a-4c8c4c87af53_0">
											<gml:posList>35.67297827224584 139.73839101070487 37.957 35.672978443950704 139.73839157387903 37.957 35.672978443950704 139.73839157387903 38.87 35.67297827224584 139.73839101070487 37.957</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ee38600-f6f9-441a-bad3-59a1bdc3e16d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3ee38600-f6f9-441a-bad3-59a1bdc3e16d_0">
											<gml:posList>35.672985787386324 139.73835379679474 40.023 35.672985787386324 139.73835379679474 40.419 35.6729668491689 139.7382962000843 40.023 35.672985787386324 139.73835379679474 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2532926f-2661-43e6-a489-ca355aaf8837">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2532926f-2661-43e6-a489-ca355aaf8837_0">
											<gml:posList>35.6729668491689 139.7382962000843 40.023 35.672985787386324 139.73835379679474 40.419 35.6729668491689 139.7382962000843 42.054 35.6729668491689 139.7382962000843 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-07455cc9-4e1a-4f68-9c96-35e39dc09190">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-07455cc9-4e1a-4f68-9c96-35e39dc09190_0">
											<gml:posList>35.6729668491689 139.7382962000843 42.054 35.672985787386324 139.73835379679474 40.419 35.672985977136236 139.7383543820407 42.054 35.6729668491689 139.7382962000843 42.054</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-21e8f633-586c-4e4a-899b-0daaacfea9bb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-21e8f633-586c-4e4a-899b-0daaacfea9bb_0">
											<gml:posList>35.672985787386324 139.73835379679474 40.419 35.672985977136236 139.7383543820407 40.419 35.672985977136236 139.7383543820407 42.054 35.672985787386324 139.73835379679474 40.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13b83707-245a-4668-b037-eb9d23c88fc9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-13b83707-245a-4668-b037-eb9d23c88fc9_0">
											<gml:posList>35.67298105089691 139.73837122292213 37.597 35.67297331090072 139.7383747670075 38.87 35.67298105089691 139.73837122292213 38.87 35.67298105089691 139.73837122292213 37.597</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-026e5267-9d98-4987-b483-03d0ad1be5c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-026e5267-9d98-4987-b483-03d0ad1be5c1_0">
											<gml:posList>35.67298105089691 139.73837122292213 37.597 35.67297331090072 139.7383747670075 37.597 35.67297331090072 139.7383747670075 38.87 35.67298105089691 139.73837122292213 37.597</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba4c4b0c-7a90-4656-95c3-8481c5dfbfa1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba4c4b0c-7a90-4656-95c3-8481c5dfbfa1_0">
											<gml:posList>35.67298971942386 139.73835639913835 40.419 35.672988427377554 139.73835249016608 40.419 35.67298971942386 139.73835639913835 42.054 35.67298971942386 139.73835639913835 40.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d77988eb-d751-4608-b8d9-4bb7a1a59815">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d77988eb-d751-4608-b8d9-4bb7a1a59815_0">
											<gml:posList>35.67298971942386 139.73835639913835 42.054 35.672988427377554 139.73835249016608 40.419 35.672968431991045 139.73829164700226 42.054 35.67298971942386 139.73835639913835 42.054</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f5b210c-04e6-4612-aac4-fcfb7d94b212">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f5b210c-04e6-4612-aac4-fcfb7d94b212_0">
											<gml:posList>35.672968431991045 139.73829164700226 42.054 35.672988427377554 139.73835249016608 40.419 35.672968431991045 139.73829164700226 40.023 35.672968431991045 139.73829164700226 42.054</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18b13fa3-fab8-4bd6-b8f1-7e82d568e4d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-18b13fa3-fab8-4bd6-b8f1-7e82d568e4d4_0">
											<gml:posList>35.672988427377554 139.73835249016608 40.419 35.672988427377554 139.73835249016608 40.023 35.672968431991045 139.73829164700226 40.023 35.672988427377554 139.73835249016608 40.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e9730c2-83e9-4c12-ac2f-1d7767de7453">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1e9730c2-83e9-4c12-ac2f-1d7767de7453_0">
											<gml:posList>35.67298105089691 139.73837122292213 38.87 35.672978443950704 139.73839157387903 38.87 35.672986183947394 139.738388029795 38.87 35.67298105089691 139.73837122292213 38.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46d79277-cbc4-4df3-b60f-5154b3def32c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46d79277-cbc4-4df3-b60f-5154b3def32c_0">
											<gml:posList>35.67298105089691 139.73837122292213 38.87 35.67297331090072 139.7383747670075 38.87 35.672978443950704 139.73839157387903 38.87 35.67298105089691 139.73837122292213 38.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-50e53dda-d9cb-4170-9766-0c0962a96120">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-50e53dda-d9cb-4170-9766-0c0962a96120_0">
											<gml:posList>35.67298588573687 139.73838706909237 37.957 35.67297827224584 139.73839101070487 37.597 35.67298588573687 139.73838706909237 37.597 35.67298588573687 139.73838706909237 37.957</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b3a44fb-df84-4817-8eba-18d28f626a83">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0b3a44fb-df84-4817-8eba-18d28f626a83_0">
											<gml:posList>35.67298588573687 139.73838706909237 37.957 35.67297827224584 139.73839101070487 37.957 35.67297827224584 139.73839101070487 37.597 35.67298588573687 139.73838706909237 37.957</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8252b22e-fc9e-4551-9923-db6ff1125744">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8252b22e-fc9e-4551-9923-db6ff1125744_0">
											<gml:posList>35.672978443950704 139.73839157387903 37.957 35.672986183947394 139.738388029795 38.87 35.672978443950704 139.73839157387903 38.87 35.672978443950704 139.73839157387903 37.957</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-83dbe2b5-e0b6-4f02-886f-b2a45fcb84ac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-83dbe2b5-e0b6-4f02-886f-b2a45fcb84ac_0">
											<gml:posList>35.672978443950704 139.73839157387903 37.957 35.672986183947394 139.738388029795 37.957 35.672986183947394 139.738388029795 38.87 35.672978443950704 139.73839157387903 37.957</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-290faa15-198c-4aff-b768-1794d56c91c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-290faa15-198c-4aff-b768-1794d56c91c9_0">
											<gml:posList>35.672986183947394 139.738388029795 37.957 35.67298588573687 139.73838706909237 37.957 35.672986183947394 139.738388029795 38.87 35.672986183947394 139.738388029795 37.957</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f94b538a-660e-4bbd-b18e-38591090d73c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f94b538a-660e-4bbd-b18e-38591090d73c_0">
											<gml:posList>35.672986183947394 139.738388029795 38.87 35.67298588573687 139.73838706909237 37.957 35.67298105089691 139.73837122292213 38.87 35.672986183947394 139.738388029795 38.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-041a64f1-8b59-49fc-9365-1a0e382dfc0d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-041a64f1-8b59-49fc-9365-1a0e382dfc0d_0">
											<gml:posList>35.67298105089691 139.73837122292213 38.87 35.67298588573687 139.73838706909237 37.957 35.67298105089691 139.73837122292213 37.597 35.67298105089691 139.73837122292213 38.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a3b2cb62-5180-439a-81de-3901eb55d36f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a3b2cb62-5180-439a-81de-3901eb55d36f_0">
											<gml:posList>35.67298588573687 139.73838706909237 37.957 35.67298588573687 139.73838706909237 37.597 35.67298105089691 139.73837122292213 37.597 35.67298588573687 139.73838706909237 37.957</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-460d9fa3-f3f0-4089-b6b3-330da026fc22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672923654272445 139.73830620428484 40.023 35.672900041756485 139.73831057358956 40.023 35.6729215941927 139.73829993225257 40.023 35.672923654272445 139.73830620428484 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4eec905e-1802-4a74-a971-9ff598d00cf3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672923654272445 139.73830620428484 40.023 35.67290210183567 139.7383168456204 40.023 35.672900041756485 139.73831057358956 40.023 35.672923654272445 139.73830620428484 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b51fc46e-1835-48bc-a1be-32661d64e8b5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672926364034765 139.73833620366577 40.023 35.67292182834053 139.73832251124463 40.023 35.67292880223021 139.7383190453907 40.023 35.672926364034765 139.73833620366577 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ab736e0-f8e0-4157-9ce2-4149ba4a02c4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67293333792483 139.73833273781284 40.023 35.672926364034765 139.73833620366577 40.023 35.67292880223021 139.7383190453907 40.023 35.67293333792483 139.73833273781284 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e39edea-06eb-4a86-9100-5fcb7a8a5a77">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672918796413796 139.73838687238188 40.023 35.67291614740844 139.73838817901895 40.023 35.67289393096104 139.73831122153558 40.023 35.672918796413796 139.73838687238188 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af5da8ed-3688-465a-8b5e-254c886d9223">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672985787386324 139.73835379679474 40.023 35.6729668491689 139.7382962000843 40.023 35.672988427377554 139.73835249016608 40.023 35.672985787386324 139.73835379679474 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dede2746-fde2-4c82-b90c-0ed9e3856287">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67291614740844 139.73838817901895 40.023 35.6728902157835 139.73830929278313 40.023 35.67289393096104 139.73831122153558 40.023 35.67291614740844 139.73838817901895 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f1a9048-734c-4ade-a21b-eca017e59e0f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6729668491689 139.7382962000843 40.023 35.67295617206284 139.7383014709298 40.023 35.67295775488518 139.73829691784843 40.023 35.6729668491689 139.7382962000843 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-85a2dd5b-4625-4c12-8f3f-933e0944b338">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672968431991045 139.73829164700226 40.023 35.672988427377554 139.73835249016608 40.023 35.6729668491689 139.7382962000843 40.023 35.672968431991045 139.73829164700226 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b26bb3e-e168-47e9-8109-b1450c9b0fbe">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67289393096104 139.73831122153558 40.023 35.6728902157835 139.73830929278313 40.023 35.67295181862437 139.73827887471896 40.023 35.67289393096104 139.73831122153558 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-39e929bb-05c8-4190-b097-30366bb0ddcd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67289393096104 139.73831122153558 40.023 35.67295181862437 139.73827887471896 40.023 35.6729502358027 139.73828342780035 40.023 35.67289393096104 139.73831122153558 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f19104da-050f-4d32-b19c-7b4998446e51">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67295775488518 139.73829691784843 40.023 35.67295617206284 139.7383014709298 40.023 35.6729502358027 139.73828342780035 40.023 35.67295775488518 139.73829691784843 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b6763982-9866-4ec8-9b0c-a1585dbb1f9d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67295775488518 139.73829691784843 40.023 35.672968431991045 139.73829164700226 40.023 35.6729668491689 139.7382962000843 40.023 35.67295775488518 139.73829691784843 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c30e56ee-e9c9-4692-9f55-f80e6fda84a9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67295181862437 139.73827887471896 40.023 35.67295775488518 139.73829691784843 40.023 35.6729502358027 139.73828342780035 40.023 35.67295181862437 139.73827887471896 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bdd0d12d-820a-417c-9ec0-f9af7462b6fa">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672920427363145 139.7383747633666 40.023 35.67291292798515 139.73835196100342 40.023 35.67292053261812 139.73834821823993 40.023 35.672920427363145 139.7383747633666 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9c40d88d-c99b-453e-ad83-aa3f1ccad9a8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6729280229744 139.738371009569 40.023 35.672920427363145 139.7383747633666 40.023 35.67292053261812 139.73834821823993 40.023 35.6729280229744 139.738371009569 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dfe4c4be-d3c8-4a3b-8ad5-40139576dd3a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67291614740844 139.73838817901895 40.419 35.67291899518597 139.73838746866335 40.419 35.67291726779228 139.7383915800476 40.419 35.67291614740844 139.73838817901895 40.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-934d6ff0-c650-43b5-894a-b05312f4a0b9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67291726779228 139.7383915800476 40.419 35.67291899518597 139.73838746866335 40.419 35.67298971942386 139.73835639913835 40.419 35.67291726779228 139.7383915800476 40.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60fc8d58-f416-4407-ba0d-7169066ddd10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67298971942386 139.73835639913835 40.419 35.672985977136236 139.7383543820407 40.419 35.672988427377554 139.73835249016608 40.419 35.67298971942386 139.73835639913835 40.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-567c3e27-945f-43a7-a2ef-d6db9f566553">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67291899518597 139.73838746866335 40.419 35.67291614740844 139.73838817901895 40.419 35.672918796413796 139.73838687238188 40.419 35.67291899518597 139.73838746866335 40.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5ad42ce4-c8b6-42d6-bb6f-80673431a833">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672988427377554 139.73835249016608 40.419 35.672985977136236 139.7383543820407 40.419 35.672985787386324 139.73835379679474 40.419 35.672988427377554 139.73835249016608 40.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f4e8680-ba43-46a0-8045-4d2cfc7b5993">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67291899518597 139.73838746866335 40.419 35.672985977136236 139.7383543820407 40.419 35.67298971942386 139.73835639913835 40.419 35.67291899518597 139.73838746866335 40.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7a4a6a4-46d6-442c-b2f6-548e1fc16ca8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67297331090072 139.7383747670075 37.597 35.67298588573687 139.73838706909237 37.597 35.67297827224584 139.73839101070487 37.597 35.67297331090072 139.7383747670075 37.597</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70339a13-0a02-484f-bbaa-d58511dc7c9d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67297331090072 139.7383747670075 37.597 35.67298105089691 139.73837122292213 37.597 35.67298588573687 139.73838706909237 37.597 35.67297331090072 139.7383747670075 37.597</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8af63772-944c-41f3-9f6a-7c135990d9ff">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67297827224584 139.73839101070487 37.957 35.672986183947394 139.738388029795 37.957 35.672978443950704 139.73839157387903 37.957 35.67297827224584 139.73839101070487 37.957</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf7888dc-5a33-4c94-b3cc-55bce4b34be9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67297827224584 139.73839101070487 37.957 35.67298588573687 139.73838706909237 37.957 35.672986183947394 139.738388029795 37.957 35.67297827224584 139.73839101070487 37.957</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_74d320f0-521c-4742-b97c-301912ce4602_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a6ac85d-a80b-469e-b612-fd073c921d5c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672963650267675 139.73830885225084 40.023 35.67297615756342 139.7383497872349 40.023 35.67295914580642 139.73835759525335 40.023 35.67294663851332 139.7383166602767 40.023 35.672963650267675 139.73830885225084 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78c9b410-06a7-436c-be97-6d6b1da58c67">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78c9b410-06a7-436c-be97-6d6b1da58c67_0">
											<gml:posList>35.67294663851332 139.7383166602767 40.023 35.67294663851332 139.7383166602767 42.614 35.672963650267675 139.73830885225084 42.614 35.672963650267675 139.73830885225084 40.023 35.67294663851332 139.7383166602767 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ead90c2d-2b00-43dd-9744-35f5761163d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ead90c2d-2b00-43dd-9744-35f5761163d1_0">
											<gml:posList>35.672963650267675 139.73830885225084 42.614 35.67297615756342 139.7383497872349 42.614 35.67297615756342 139.7383497872349 40.023 35.672963650267675 139.73830885225084 40.023 35.672963650267675 139.73830885225084 42.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25dd297a-845d-4cc9-9602-a0ce84168599">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-25dd297a-845d-4cc9-9602-a0ce84168599_0">
											<gml:posList>35.67295914580642 139.73835759525335 42.614 35.67297615756342 139.7383497872349 42.614 35.672963650267675 139.73830885225084 42.614 35.67294663851332 139.7383166602767 42.614 35.67295914580642 139.73835759525335 42.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d298afd-4106-4cb5-a349-acbd3a32062b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d298afd-4106-4cb5-a349-acbd3a32062b_0">
											<gml:posList>35.67295914580642 139.73835759525335 40.023 35.67295914580642 139.73835759525335 42.614 35.67294663851332 139.7383166602767 42.614 35.67294663851332 139.7383166602767 40.023 35.67295914580642 139.73835759525335 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d463f49-39e6-4e0d-b7de-07776bab9afe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8d463f49-39e6-4e0d-b7de-07776bab9afe_0">
											<gml:posList>35.67297615756342 139.7383497872349 42.614 35.67295914580642 139.73835759525335 42.614 35.67295914580642 139.73835759525335 40.023 35.67297615756342 139.7383497872349 40.023 35.67297615756342 139.7383497872349 42.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-9ab3d918-1c20-454e-8372-16dff60c3dc5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ab3d918-1c20-454e-8372-16dff60c3dc5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ab3d918-1c20-454e-8372-16dff60c3dc5">
											<gml:posList>35.67292874935416 139.73840056943794 8.64 35.672914008171176 139.73840725904506 8.64 35.672882305382196 139.73830249745114 8.64 35.67292362751558 139.7382837244659 8.64 35.67296977829489 139.73826152128433 8.64 35.673003482556716 139.73836677770328 8.64 35.67298740816442 139.73837450728416 8.64 35.672992205424755 139.73838842034203 8.64 35.67293481141439 139.73841813741805 8.64 35.67292874935416 139.73840056943794 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-612d297a-2389-4429-acab-fa63170357db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-612d297a-2389-4429-acab-fa63170357db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-612d297a-2389-4429-acab-fa63170357db">
											<gml:posList>35.672910727630274 139.73839640411384 40.419 35.67291314700742 139.73838966281784 40.419 35.67288767994713 139.73830551785 40.419 35.672882305382196 139.73830249745114 40.419 35.672910727630274 139.73839640411384 40.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-61036b8b-2d98-465a-b47d-523a85f7c4ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61036b8b-2d98-465a-b47d-523a85f7c4ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61036b8b-2d98-465a-b47d-523a85f7c4ba">
											<gml:posList>35.67292362751558 139.7382837244659 40.419 35.672882305382196 139.73830249745114 40.419 35.67288767994713 139.73830551785 40.419 35.67292511856349 139.7382885169268 40.419 35.67292362751558 139.7382837244659 40.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2e55c7fd-aad7-4ef9-8a4d-af9f4fa47374">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2e55c7fd-aad7-4ef9-8a4d-af9f4fa47374">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2e55c7fd-aad7-4ef9-8a4d-af9f4fa47374">
											<gml:posList>35.672910727630274 139.73839640411384 40.419 35.672914008171176 139.73840725904506 37.957 35.67292874935416 139.73840056943794 37.957 35.672910727630274 139.73839640411384 40.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6db59d40-69c8-40d2-a5b5-1d310c6dfb9f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6db59d40-69c8-40d2-a5b5-1d310c6dfb9f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6db59d40-69c8-40d2-a5b5-1d310c6dfb9f">
											<gml:posList>35.67291314700742 139.73838966281784 40.023 35.67299359023392 139.73834994332694 40.023 35.67296740391506 139.7382681631161 40.023 35.67292511856349 139.7382885169268 40.023 35.67288767994713 139.73830551785 40.023 35.67291314700742 139.73838966281784 40.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8cea3f6a-e527-4e71-a762-768e56c0d2f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8cea3f6a-e527-4e71-a762-768e56c0d2f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8cea3f6a-e527-4e71-a762-768e56c0d2f6">
											<gml:posList>35.67292362751558 139.7382837244659 40.419 35.67292511856349 139.7382885169268 40.419 35.67296740391506 139.7382681631161 40.419 35.67296977829489 139.73826152128433 40.419 35.67292362751558 139.7382837244659 40.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f800f5a1-9494-43db-9c11-964aa03f6aab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f800f5a1-9494-43db-9c11-964aa03f6aab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f800f5a1-9494-43db-9c11-964aa03f6aab">
											<gml:posList>35.67299900975288 139.73835282007386 40.419 35.67299359023392 139.73834994332694 40.419 35.67291314700742 139.73838966281784 40.419 35.672910727630274 139.73839640411384 40.419 35.67299900975288 139.73835282007386 40.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-05b3ba85-e274-4131-bcbd-2a798bd33c71">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-05b3ba85-e274-4131-bcbd-2a798bd33c71">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-05b3ba85-e274-4131-bcbd-2a798bd33c71">
											<gml:posList>35.672910727630274 139.73839640411384 40.419 35.67292874935416 139.73840056943794 37.957 35.67299900975288 139.73835282007386 40.419 35.672910727630274 139.73839640411384 40.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-33cbc39c-9e42-40b7-842b-c018355db2a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-33cbc39c-9e42-40b7-842b-c018355db2a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-33cbc39c-9e42-40b7-842b-c018355db2a0">
											<gml:posList>35.67292874935416 139.73840056943794 37.957 35.67300287715647 139.7383649004949 37.957 35.67299900975288 139.73835282007386 40.419 35.67292874935416 139.73840056943794 37.957</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-76371f16-2213-45df-876f-7a352d1c129c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-76371f16-2213-45df-876f-7a352d1c129c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-76371f16-2213-45df-876f-7a352d1c129c">
											<gml:posList>35.67292874935416 139.73840056943794 37.957 35.67293481141439 139.73841813741805 37.957 35.672992205424755 139.73838842034203 37.957 35.67298740816442 139.73837450728416 37.957 35.673003482556716 139.73836677770328 37.957 35.67300287715647 139.7383649004949 37.957 35.67292874935416 139.73840056943794 37.957</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dbe181e3-13f3-4664-82ef-aaa62d12dc8e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dbe181e3-13f3-4664-82ef-aaa62d12dc8e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dbe181e3-13f3-4664-82ef-aaa62d12dc8e">
											<gml:posList>35.67296977829489 139.73826152128433 40.419 35.67296740391506 139.7382681631161 40.419 35.67299359023392 139.73834994332694 40.419 35.67299900975288 139.73835282007386 40.419 35.67296977829489 139.73826152128433 40.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5d2cdf54-67d9-4e2c-9d3e-6901226aa8f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d2cdf54-67d9-4e2c-9d3e-6901226aa8f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d2cdf54-67d9-4e2c-9d3e-6901226aa8f4">
											<gml:posList>35.672882305382196 139.73830249745114 40.419 35.672882305382196 139.73830249745114 8.64 35.672914008171176 139.73840725904506 8.64 35.672914008171176 139.73840725904506 37.957 35.672910727630274 139.73839640411384 40.419 35.672882305382196 139.73830249745114 40.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c94ddff6-c539-481c-aabf-e976bc0f6928">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c94ddff6-c539-481c-aabf-e976bc0f6928">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c94ddff6-c539-481c-aabf-e976bc0f6928">
											<gml:posList>35.67291314700742 139.73838966281784 40.419 35.67291314700742 139.73838966281784 40.023 35.67288767994713 139.73830551785 40.023 35.67288767994713 139.73830551785 40.419 35.67291314700742 139.73838966281784 40.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-78463cbc-54f6-4dca-ad20-be0b81baba97">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78463cbc-54f6-4dca-ad20-be0b81baba97">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78463cbc-54f6-4dca-ad20-be0b81baba97">
											<gml:posList>35.67292362751558 139.7382837244659 8.64 35.672882305382196 139.73830249745114 8.64 35.672882305382196 139.73830249745114 40.419 35.67292362751558 139.7382837244659 40.419 35.67292362751558 139.7382837244659 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e316fe0f-8c6a-4e8e-91a8-86b71c125c77">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e316fe0f-8c6a-4e8e-91a8-86b71c125c77">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e316fe0f-8c6a-4e8e-91a8-86b71c125c77">
											<gml:posList>35.67288767994713 139.73830551785 40.419 35.67288767994713 139.73830551785 40.023 35.67292511856349 139.7382885169268 40.023 35.67292511856349 139.7382885169268 40.419 35.67288767994713 139.73830551785 40.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-668ff365-a469-4985-8b0c-21839f5da2c6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-668ff365-a469-4985-8b0c-21839f5da2c6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-668ff365-a469-4985-8b0c-21839f5da2c6">
											<gml:posList>35.672914008171176 139.73840725904506 8.64 35.67292874935416 139.73840056943794 8.64 35.67292874935416 139.73840056943794 37.957 35.672914008171176 139.73840725904506 37.957 35.672914008171176 139.73840725904506 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d5c384fb-2573-4333-9c7a-047498a87e51">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5c384fb-2573-4333-9c7a-047498a87e51">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5c384fb-2573-4333-9c7a-047498a87e51">
											<gml:posList>35.67292874935416 139.73840056943794 8.64 35.67293481141439 139.73841813741805 8.64 35.67293481141439 139.73841813741805 37.957 35.67292874935416 139.73840056943794 37.957 35.67292874935416 139.73840056943794 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-10e43536-b9ed-41ca-86b6-71ded333a6f1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-10e43536-b9ed-41ca-86b6-71ded333a6f1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-10e43536-b9ed-41ca-86b6-71ded333a6f1">
											<gml:posList>35.67292511856349 139.7382885169268 40.419 35.67292511856349 139.7382885169268 40.023 35.67296740391506 139.7382681631161 40.023 35.67296740391506 139.7382681631161 40.419 35.67292511856349 139.7382885169268 40.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f74e63ff-7668-44b6-98c5-180b8518684d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f74e63ff-7668-44b6-98c5-180b8518684d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f74e63ff-7668-44b6-98c5-180b8518684d">
											<gml:posList>35.67296977829489 139.73826152128433 8.64 35.67292362751558 139.7382837244659 8.64 35.67292362751558 139.7382837244659 40.419 35.67296977829489 139.73826152128433 40.419 35.67296977829489 139.73826152128433 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1917800e-809c-483e-a72c-868d56eac312">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1917800e-809c-483e-a72c-868d56eac312">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1917800e-809c-483e-a72c-868d56eac312">
											<gml:posList>35.67299359023392 139.73834994332694 40.419 35.67299359023392 139.73834994332694 40.023 35.67291314700742 139.73838966281784 40.023 35.67291314700742 139.73838966281784 40.419 35.67299359023392 139.73834994332694 40.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7b721aee-709a-4cb3-af62-3c50309e951a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b721aee-709a-4cb3-af62-3c50309e951a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b721aee-709a-4cb3-af62-3c50309e951a">
											<gml:posList>35.67293481141439 139.73841813741805 8.64 35.672992205424755 139.73838842034203 8.64 35.672992205424755 139.73838842034203 37.957 35.67293481141439 139.73841813741805 37.957 35.67293481141439 139.73841813741805 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8750eb44-3a29-4010-adb8-a7602db46b61">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8750eb44-3a29-4010-adb8-a7602db46b61">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8750eb44-3a29-4010-adb8-a7602db46b61">
											<gml:posList>35.67296740391506 139.7382681631161 40.419 35.67296740391506 139.7382681631161 40.023 35.67299359023392 139.73834994332694 40.023 35.67299359023392 139.73834994332694 40.419 35.67296740391506 139.7382681631161 40.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9acbd20c-59c4-48ee-b95e-08ff4bb73b51">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9acbd20c-59c4-48ee-b95e-08ff4bb73b51">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9acbd20c-59c4-48ee-b95e-08ff4bb73b51">
											<gml:posList>35.67296977829489 139.73826152128433 40.419 35.67299900975288 139.73835282007386 40.419 35.67300287715647 139.7383649004949 37.957 35.673003482556716 139.73836677770328 37.957 35.673003482556716 139.73836677770328 8.64 35.67296977829489 139.73826152128433 8.64 35.67296977829489 139.73826152128433 40.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4c77ed5f-4151-4441-9828-439359e95ff0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c77ed5f-4151-4441-9828-439359e95ff0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c77ed5f-4151-4441-9828-439359e95ff0">
											<gml:posList>35.672992205424755 139.73838842034203 8.64 35.67298740816442 139.73837450728416 8.64 35.67298740816442 139.73837450728416 37.957 35.672992205424755 139.73838842034203 37.957 35.672992205424755 139.73838842034203 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d029a481-ffe1-4604-971a-bd4c1e9a5a3e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d029a481-ffe1-4604-971a-bd4c1e9a5a3e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d029a481-ffe1-4604-971a-bd4c1e9a5a3e">
											<gml:posList>35.67298740816442 139.73837450728416 8.64 35.673003482556716 139.73836677770328 8.64 35.673003482556716 139.73836677770328 37.957 35.67298740816442 139.73837450728416 37.957 35.67298740816442 139.73837450728416 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-9675</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">155.0214</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>