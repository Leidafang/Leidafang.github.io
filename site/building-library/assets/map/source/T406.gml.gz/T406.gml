<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_757035e9-b503-4dea-a7d5-fcf5cf2da2fe">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>46</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13101046002</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>永田町二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">422</bldg:usage>
			<bldg:measuredHeight uom="m">14.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>1</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67442893386606 139.7404852605375 0 35.67449379359609 139.74049301761636 0 35.67450736383556 139.7403237644939 0 35.67444247700259 139.74031594130122 0 35.67437755411353 139.74030811816294 0 35.674363983980584 139.74047748148186 0 35.67442893386606 139.7404852605375 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67442893386606 139.7404852605375 22.584 35.674363983980584 139.74047748148186 22.584 35.67437755411353 139.74030811816294 22.584 35.67444247700259 139.74031594130122 22.584 35.67450736383556 139.7403237644939 22.584 35.67449379359609 139.74049301761636 22.584 35.67442893386606 139.7404852605375 22.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67442893386606 139.7404852605375 22.584 35.67449379359609 139.74049301761636 22.584 35.67449379359609 139.74049301761636 34.56 35.67442893386606 139.7404852605375 34.56 35.67442893386606 139.7404852605375 22.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67449379359609 139.74049301761636 22.584 35.67450736383556 139.7403237644939 22.584 35.67450736383556 139.7403237644939 34.56 35.67449379359609 139.74049301761636 34.56 35.67449379359609 139.74049301761636 22.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67450736383556 139.7403237644939 22.584 35.67444247700259 139.74031594130122 22.584 35.67444247700259 139.74031594130122 34.56 35.67450736383556 139.7403237644939 34.56 35.67450736383556 139.7403237644939 22.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67444247700259 139.74031594130122 22.584 35.67437755411353 139.74030811816294 22.584 35.67437755411353 139.74030811816294 34.56 35.67444247700259 139.74031594130122 34.56 35.67444247700259 139.74031594130122 22.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67437755411353 139.74030811816294 22.584 35.674363983980584 139.74047748148186 22.584 35.674363983980584 139.74047748148186 34.56 35.67437755411353 139.74030811816294 34.56 35.67437755411353 139.74030811816294 22.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674363983980584 139.74047748148186 22.584 35.67442893386606 139.7404852605375 22.584 35.67442893386606 139.7404852605375 34.56 35.674363983980584 139.74047748148186 34.56 35.674363983980584 139.74047748148186 22.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67442893386606 139.7404852605375 34.56 35.67449379359609 139.74049301761636 34.56 35.67450736383556 139.7403237644939 34.56 35.67444247700259 139.74031594130122 34.56 35.67437755411353 139.74030811816294 34.56 35.674363983980584 139.74047748148186 34.56 35.67442893386606 139.7404852605375 34.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-dba056b1-1576-430d-b3f6-37dfc1b15ed0"/>
							<gml:surfaceMember xlink:href="#poly-f81fefe2-db5a-47d5-a4cd-1e8879407d56"/>
							<gml:surfaceMember xlink:href="#poly-819615f8-ab5e-4083-b1f9-0c6ee1cb2d98"/>
							<gml:surfaceMember xlink:href="#poly-ae8355de-1902-4934-85e2-14d5e7a092bd"/>
							<gml:surfaceMember xlink:href="#poly-cc465f5a-a754-4ed7-9f55-6e0b1950a3ff"/>
							<gml:surfaceMember xlink:href="#poly-0645f334-4926-4e0f-8dca-8ecb3f710ecf"/>
							<gml:surfaceMember xlink:href="#poly-6fcd3633-6c33-4444-89fb-6aee55817f17"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-dba056b1-1576-430d-b3f6-37dfc1b15ed0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dba056b1-1576-430d-b3f6-37dfc1b15ed0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dba056b1-1576-430d-b3f6-37dfc1b15ed0">
											<gml:posList>35.67450736383556 139.7403237644939 22.584 35.67449379359609 139.74049301761636 22.584 35.674428942879736 139.74048526052704 22.584 35.67436398398056 139.74047748148186 22.584 35.67437755411355 139.74030811816294 22.584 35.67450736383556 139.7403237644939 22.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f81fefe2-db5a-47d5-a4cd-1e8879407d56">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f81fefe2-db5a-47d5-a4cd-1e8879407d56">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f81fefe2-db5a-47d5-a4cd-1e8879407d56">
											<gml:posList>35.674442477002586 139.74031594130122 37.041 35.67437755411355 139.74030811816294 33 35.67436398398056 139.74047748148186 33 35.674428942879736 139.74048526052704 37.041 35.674442477002586 139.74031594130122 37.041</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-819615f8-ab5e-4083-b1f9-0c6ee1cb2d98">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-819615f8-ab5e-4083-b1f9-0c6ee1cb2d98">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-819615f8-ab5e-4083-b1f9-0c6ee1cb2d98">
											<gml:posList>35.67449379359609 139.74049301761636 33 35.67450736383556 139.7403237644939 33 35.674442477002586 139.74031594130122 37.041 35.674428942879736 139.74048526052704 37.041 35.67449379359609 139.74049301761636 33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ae8355de-1902-4934-85e2-14d5e7a092bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ae8355de-1902-4934-85e2-14d5e7a092bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ae8355de-1902-4934-85e2-14d5e7a092bd">
											<gml:posList>35.67437755411355 139.74030811816294 33 35.67437755411355 139.74030811816294 22.584 35.67436398398056 139.74047748148186 22.584 35.67436398398056 139.74047748148186 33 35.67437755411355 139.74030811816294 33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cc465f5a-a754-4ed7-9f55-6e0b1950a3ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc465f5a-a754-4ed7-9f55-6e0b1950a3ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc465f5a-a754-4ed7-9f55-6e0b1950a3ff">
											<gml:posList>35.67436398398056 139.74047748148186 33 35.67436398398056 139.74047748148186 22.584 35.674428942879736 139.74048526052704 22.584 35.67449379359609 139.74049301761636 22.584 35.67449379359609 139.74049301761636 33 35.674428942879736 139.74048526052704 37.041 35.67436398398056 139.74047748148186 33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0645f334-4926-4e0f-8dca-8ecb3f710ecf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0645f334-4926-4e0f-8dca-8ecb3f710ecf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0645f334-4926-4e0f-8dca-8ecb3f710ecf">
											<gml:posList>35.67437755411355 139.74030811816294 22.584 35.67437755411355 139.74030811816294 33 35.674442477002586 139.74031594130122 37.041 35.67450736383556 139.7403237644939 33 35.67450736383556 139.7403237644939 22.584 35.67437755411355 139.74030811816294 22.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6fcd3633-6c33-4444-89fb-6aee55817f17">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6fcd3633-6c33-4444-89fb-6aee55817f17">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6fcd3633-6c33-4444-89fb-6aee55817f17">
											<gml:posList>35.67449379359609 139.74049301761636 33 35.67449379359609 139.74049301761636 22.584 35.67450736383556 139.7403237644939 22.584 35.67450736383556 139.7403237644939 33 35.67449379359609 139.74049301761636 33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都千代田区永田町二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4582</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">222.846</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1003</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1123</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">21</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>