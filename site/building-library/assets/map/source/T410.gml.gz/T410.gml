<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_766461b1-f376-40f7-be82-3a270ec247ba">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">3.4</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67006196272502 139.7383355546726 0 35.67007489752031 139.7383928139831 0 35.670145239884874 139.73836894816301 0 35.67013230507832 139.73831168880622 0 35.67006196272502 139.7383355546726 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67006196272502 139.7383355546726 20.592 35.67013230507832 139.73831168880622 20.592 35.670145239884874 139.73836894816301 20.592 35.67007489752031 139.7383928139831 20.592 35.67006196272502 139.7383355546726 20.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67006196272502 139.7383355546726 20.592 35.67007489752031 139.7383928139831 20.592 35.67007489752031 139.7383928139831 24.01 35.67006196272502 139.7383355546726 24.01 35.67006196272502 139.7383355546726 20.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67007489752031 139.7383928139831 20.592 35.670145239884874 139.73836894816301 20.592 35.670145239884874 139.73836894816301 24.01 35.67007489752031 139.7383928139831 24.01 35.67007489752031 139.7383928139831 20.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670145239884874 139.73836894816301 20.592 35.67013230507832 139.73831168880622 20.592 35.67013230507832 139.73831168880622 24.01 35.670145239884874 139.73836894816301 24.01 35.670145239884874 139.73836894816301 20.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67013230507832 139.73831168880622 20.592 35.67006196272502 139.7383355546726 20.592 35.67006196272502 139.7383355546726 24.01 35.67013230507832 139.73831168880622 24.01 35.67013230507832 139.73831168880622 20.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67006196272502 139.7383355546726 24.01 35.67007489752031 139.7383928139831 24.01 35.670145239884874 139.73836894816301 24.01 35.67013230507832 139.73831168880622 24.01 35.67006196272502 139.7383355546726 24.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-a6990c0b-df4b-42f5-a31c-dfbf97002043"/>
							<gml:surfaceMember xlink:href="#poly-86802248-e729-4a8a-917c-e86d4309156c"/>
							<gml:surfaceMember xlink:href="#poly-af3ef817-e068-4b31-a84a-802c5f1c0a83"/>
							<gml:surfaceMember xlink:href="#poly-e4183fc7-00d6-4682-acc0-1f8d87691912"/>
							<gml:surfaceMember xlink:href="#poly-bbfd87da-3631-40a0-8e40-27c043649bf8"/>
							<gml:surfaceMember xlink:href="#poly-a03800a0-c02b-4022-ab50-c14011e27192"/>
							<gml:surfaceMember xlink:href="#poly-f9f22bfa-06a7-46d9-b9bf-ba89b4a0b9ab"/>
							<gml:surfaceMember xlink:href="#poly-de1de563-5953-416d-b3c7-b0f8b1432b09"/>
							<gml:surfaceMember xlink:href="#poly-c425a0cc-02a2-4d22-91e7-4b40ec12dc52"/>
							<gml:surfaceMember xlink:href="#poly-b7544080-b0ab-4dd3-aff1-4c1a5884afd0"/>
							<gml:surfaceMember xlink:href="#poly-2f1a0a26-db01-415c-b627-c3afd6af8d82"/>
							<gml:surfaceMember xlink:href="#poly-fccce320-b543-4f4e-9290-c099f4e13d0d"/>
							<gml:surfaceMember xlink:href="#poly-90b4b5eb-cccc-4e6f-9789-df110042b97e"/>
							<gml:surfaceMember xlink:href="#poly-edfa569f-24a0-42a0-93b4-dfe2f7d81fe3"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-a6990c0b-df4b-42f5-a31c-dfbf97002043">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a6990c0b-df4b-42f5-a31c-dfbf97002043">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a6990c0b-df4b-42f5-a31c-dfbf97002043">
											<gml:posList>35.670061962725 139.7383355546726 20.592 35.6701323050783 139.7383116888062 20.592 35.670145239884874 139.73836894816304 20.592 35.6700748975203 139.7383928139831 20.592 35.670061962725 139.7383355546726 20.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-86802248-e729-4a8a-917c-e86d4309156c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-86802248-e729-4a8a-917c-e86d4309156c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-86802248-e729-4a8a-917c-e86d4309156c">
											<gml:posList>35.670061962725 139.7383355546726 24.63 35.67006646304751 139.73833868646582 24.63 35.670129749530695 139.73831720390098 24.63 35.6701323050783 139.7383116888062 24.63 35.670061962725 139.7383355546726 24.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-af3ef817-e068-4b31-a84a-802c5f1c0a83">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af3ef817-e068-4b31-a84a-802c5f1c0a83">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af3ef817-e068-4b31-a84a-802c5f1c0a83">
											<gml:posList>35.6701323050783 139.7383116888062 24.63 35.670129749530695 139.73831720390098 24.63 35.6701407395632 139.73836581636505 24.63 35.670145239884874 139.73836894816304 24.63 35.6701323050783 139.7383116888062 24.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e4183fc7-00d6-4682-acc0-1f8d87691912">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e4183fc7-00d6-4682-acc0-1f8d87691912">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e4183fc7-00d6-4682-acc0-1f8d87691912">
											<gml:posList>35.6701407395632 139.73836581636505 24.065 35.670129749530695 139.73831720390098 24.065 35.67006646304751 139.73833868646582 24.065 35.67007745307139 139.73838729889448 24.065 35.6701407395632 139.73836581636505 24.065</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bbfd87da-3631-40a0-8e40-27c043649bf8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bbfd87da-3631-40a0-8e40-27c043649bf8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bbfd87da-3631-40a0-8e40-27c043649bf8">
											<gml:posList>35.6700748975203 139.7383928139831 24.63 35.67007745307139 139.73838729889448 24.63 35.67006646304751 139.73833868646582 24.63 35.670061962725 139.7383355546726 24.63 35.6700748975203 139.7383928139831 24.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a03800a0-c02b-4022-ab50-c14011e27192">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a03800a0-c02b-4022-ab50-c14011e27192">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a03800a0-c02b-4022-ab50-c14011e27192">
											<gml:posList>35.670145239884874 139.73836894816304 24.63 35.6701407395632 139.73836581636505 24.63 35.67007745307139 139.73838729889448 24.63 35.6700748975203 139.7383928139831 24.63 35.670145239884874 139.73836894816304 24.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f9f22bfa-06a7-46d9-b9bf-ba89b4a0b9ab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9f22bfa-06a7-46d9-b9bf-ba89b4a0b9ab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9f22bfa-06a7-46d9-b9bf-ba89b4a0b9ab">
											<gml:posList>35.670061962725 139.7383355546726 20.592 35.6700748975203 139.7383928139831 20.592 35.6700748975203 139.7383928139831 24.63 35.670061962725 139.7383355546726 24.63 35.670061962725 139.7383355546726 20.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-de1de563-5953-416d-b3c7-b0f8b1432b09">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de1de563-5953-416d-b3c7-b0f8b1432b09">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de1de563-5953-416d-b3c7-b0f8b1432b09">
											<gml:posList>35.67006646304751 139.73833868646582 24.63 35.67007745307139 139.73838729889448 24.63 35.67007745307139 139.73838729889448 24.065 35.67006646304751 139.73833868646582 24.065 35.67006646304751 139.73833868646582 24.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c425a0cc-02a2-4d22-91e7-4b40ec12dc52">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c425a0cc-02a2-4d22-91e7-4b40ec12dc52">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c425a0cc-02a2-4d22-91e7-4b40ec12dc52">
											<gml:posList>35.6701323050783 139.7383116888062 20.592 35.670061962725 139.7383355546726 20.592 35.670061962725 139.7383355546726 24.63 35.6701323050783 139.7383116888062 24.63 35.6701323050783 139.7383116888062 20.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b7544080-b0ab-4dd3-aff1-4c1a5884afd0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b7544080-b0ab-4dd3-aff1-4c1a5884afd0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b7544080-b0ab-4dd3-aff1-4c1a5884afd0">
											<gml:posList>35.67006646304751 139.73833868646582 24.065 35.670129749530695 139.73831720390098 24.065 35.670129749530695 139.73831720390098 24.63 35.67006646304751 139.73833868646582 24.63 35.67006646304751 139.73833868646582 24.065</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2f1a0a26-db01-415c-b627-c3afd6af8d82">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f1a0a26-db01-415c-b627-c3afd6af8d82">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f1a0a26-db01-415c-b627-c3afd6af8d82">
											<gml:posList>35.67007745307139 139.73838729889448 24.63 35.6701407395632 139.73836581636505 24.63 35.6701407395632 139.73836581636505 24.065 35.67007745307139 139.73838729889448 24.065 35.67007745307139 139.73838729889448 24.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fccce320-b543-4f4e-9290-c099f4e13d0d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fccce320-b543-4f4e-9290-c099f4e13d0d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fccce320-b543-4f4e-9290-c099f4e13d0d">
											<gml:posList>35.6700748975203 139.7383928139831 20.592 35.670145239884874 139.73836894816304 20.592 35.670145239884874 139.73836894816304 24.63 35.6700748975203 139.7383928139831 24.63 35.6700748975203 139.7383928139831 20.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-90b4b5eb-cccc-4e6f-9789-df110042b97e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-90b4b5eb-cccc-4e6f-9789-df110042b97e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-90b4b5eb-cccc-4e6f-9789-df110042b97e">
											<gml:posList>35.670129749530695 139.73831720390098 24.065 35.6701407395632 139.73836581636505 24.065 35.6701407395632 139.73836581636505 24.63 35.670129749530695 139.73831720390098 24.63 35.670129749530695 139.73831720390098 24.065</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-edfa569f-24a0-42a0-93b4-dfe2f7d81fe3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-edfa569f-24a0-42a0-93b4-dfe2f7d81fe3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-edfa569f-24a0-42a0-93b4-dfe2f7d81fe3">
											<gml:posList>35.670145239884874 139.73836894816304 20.592 35.6701323050783 139.7383116888062 20.592 35.6701323050783 139.7383116888062 24.63 35.670145239884874 139.73836894816304 24.63 35.670145239884874 139.73836894816304 20.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-9659</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>