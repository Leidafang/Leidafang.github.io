<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_78ffa4a9-224c-4407-a9a0-e501161e50d4">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">4</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.669286552936285 139.74240573834476 0 35.66920863471583 139.74238914709804 0 35.66920163231147 139.74243857527964 0 35.669279550516904 139.74245515552684 0 35.669286552936285 139.74240573834476 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669286552936285 139.74240573834476 9.95 35.669279550516904 139.74245515552684 9.95 35.66920163231147 139.74243857527964 9.95 35.66920863471583 139.74238914709804 9.95 35.669286552936285 139.74240573834476 9.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669286552936285 139.74240573834476 9.95 35.66920863471583 139.74238914709804 9.95 35.66920863471583 139.74238914709804 13.94 35.669286552936285 139.74240573834476 13.94 35.669286552936285 139.74240573834476 9.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66920863471583 139.74238914709804 9.95 35.66920163231147 139.74243857527964 9.95 35.66920163231147 139.74243857527964 13.94 35.66920863471583 139.74238914709804 13.94 35.66920863471583 139.74238914709804 9.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66920163231147 139.74243857527964 9.95 35.669279550516904 139.74245515552684 9.95 35.669279550516904 139.74245515552684 13.94 35.66920163231147 139.74243857527964 13.94 35.66920163231147 139.74243857527964 9.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669279550516904 139.74245515552684 9.95 35.669286552936285 139.74240573834476 9.95 35.669286552936285 139.74240573834476 13.94 35.669279550516904 139.74245515552684 13.94 35.669279550516904 139.74245515552684 9.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669286552936285 139.74240573834476 13.94 35.66920863471583 139.74238914709804 13.94 35.66920163231147 139.74243857527964 13.94 35.669279550516904 139.74245515552684 13.94 35.669286552936285 139.74240573834476 13.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-1e47a7f5-50ec-4471-9130-b9e855034904"/>
							<gml:surfaceMember xlink:href="#poly-f0360231-4d7c-4f24-9dce-76314ffb57a7"/>
							<gml:surfaceMember xlink:href="#poly-3f3d46bb-b348-4d94-a699-42fb01326692"/>
							<gml:surfaceMember xlink:href="#poly-68aceba0-6e29-4884-9e07-7f201d45238e"/>
							<gml:surfaceMember xlink:href="#poly-c9f0c49f-7654-4456-9533-40475be6a71d"/>
							<gml:surfaceMember xlink:href="#poly-811f92a7-6b40-45dd-be50-d7b7c6f9341b"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-1e47a7f5-50ec-4471-9130-b9e855034904">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e47a7f5-50ec-4471-9130-b9e855034904">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e47a7f5-50ec-4471-9130-b9e855034904">
											<gml:posList>35.66928655293626 139.74240573834476 9.95 35.66927955051691 139.74245515552684 9.95 35.66920163231147 139.7424385752796 9.95 35.66920863471583 139.74238914709804 9.95 35.66928655293626 139.74240573834476 9.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f0360231-4d7c-4f24-9dce-76314ffb57a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f0360231-4d7c-4f24-9dce-76314ffb57a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f0360231-4d7c-4f24-9dce-76314ffb57a7">
											<gml:posList>35.66927955051691 139.74245515552684 14.781 35.66928655293626 139.74240573834476 14.781 35.66920863471583 139.74238914709804 14.781 35.66920163231147 139.7424385752796 14.781 35.66927955051691 139.74245515552684 14.781</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3f3d46bb-b348-4d94-a699-42fb01326692">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f3d46bb-b348-4d94-a699-42fb01326692">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f3d46bb-b348-4d94-a699-42fb01326692">
											<gml:posList>35.66928655293626 139.74240573834476 9.95 35.66920863471583 139.74238914709804 9.95 35.66920863471583 139.74238914709804 14.781 35.66928655293626 139.74240573834476 14.781 35.66928655293626 139.74240573834476 9.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-68aceba0-6e29-4884-9e07-7f201d45238e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-68aceba0-6e29-4884-9e07-7f201d45238e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-68aceba0-6e29-4884-9e07-7f201d45238e">
											<gml:posList>35.66920863471583 139.74238914709804 9.95 35.66920163231147 139.7424385752796 9.95 35.66920163231147 139.7424385752796 14.781 35.66920863471583 139.74238914709804 14.781 35.66920863471583 139.74238914709804 9.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c9f0c49f-7654-4456-9533-40475be6a71d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c9f0c49f-7654-4456-9533-40475be6a71d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c9f0c49f-7654-4456-9533-40475be6a71d">
											<gml:posList>35.66927955051691 139.74245515552684 9.95 35.66928655293626 139.74240573834476 9.95 35.66928655293626 139.74240573834476 14.781 35.66927955051691 139.74245515552684 14.781 35.66927955051691 139.74245515552684 9.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-811f92a7-6b40-45dd-be50-d7b7c6f9341b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-811f92a7-6b40-45dd-be50-d7b7c6f9341b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-811f92a7-6b40-45dd-be50-d7b7c6f9341b">
											<gml:posList>35.66920163231147 139.7424385752796 9.95 35.66927955051691 139.74245515552684 9.95 35.66927955051691 139.74245515552684 14.781 35.66920163231147 139.7424385752796 14.781 35.66920163231147 139.7424385752796 9.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4360</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>