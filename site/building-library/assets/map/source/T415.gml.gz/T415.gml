<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_794f6659-7e42-4f05-9b9a-9885ee2da946">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.669193560111964 139.739274960443 0 35.669181791455216 139.73926761754976 0 35.66916411271848 139.73931018783543 0 35.66917588137267 139.7393175307333 0 35.669193560111964 139.739274960443 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669193560111964 139.739274960443 13.468 35.66917588137267 139.7393175307333 13.468 35.66916411271848 139.73931018783543 13.468 35.669181791455216 139.73926761754976 13.468 35.669193560111964 139.739274960443 13.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669193560111964 139.739274960443 13.468 35.669181791455216 139.73926761754976 13.468 35.669181791455216 139.73926761754976 16.468 35.669193560111964 139.739274960443 16.468 35.669193560111964 139.739274960443 13.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669181791455216 139.73926761754976 13.468 35.66916411271848 139.73931018783543 13.468 35.66916411271848 139.73931018783543 16.468 35.669181791455216 139.73926761754976 16.468 35.669181791455216 139.73926761754976 13.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66916411271848 139.73931018783543 13.468 35.66917588137267 139.7393175307333 13.468 35.66917588137267 139.7393175307333 16.468 35.66916411271848 139.73931018783543 16.468 35.66916411271848 139.73931018783543 13.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66917588137267 139.7393175307333 13.468 35.669193560111964 139.739274960443 13.468 35.669193560111964 139.739274960443 16.468 35.66917588137267 139.7393175307333 16.468 35.66917588137267 139.7393175307333 13.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669193560111964 139.739274960443 16.468 35.669181791455216 139.73926761754976 16.468 35.66916411271848 139.73931018783543 16.468 35.66917588137267 139.7393175307333 16.468 35.669193560111964 139.739274960443 16.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-d4803371-ff71-42ea-92c4-46f93bd22878"/>
							<gml:surfaceMember xlink:href="#poly-bdef762e-3b32-4c6f-b65b-e35d42758cd4"/>
							<gml:surfaceMember xlink:href="#poly-8d21f997-0f3d-43b9-b3d3-f1bf7f322235"/>
							<gml:surfaceMember xlink:href="#poly-3d68aab8-47f4-4bc6-9dbb-39fb4aff5171"/>
							<gml:surfaceMember xlink:href="#poly-bce66382-d283-4d97-8fcc-43c1fd3cb119"/>
							<gml:surfaceMember xlink:href="#poly-70c518c1-a8b1-4910-8de0-bec6250bf22b"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-d4803371-ff71-42ea-92c4-46f93bd22878">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4803371-ff71-42ea-92c4-46f93bd22878">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4803371-ff71-42ea-92c4-46f93bd22878">
											<gml:posList>35.66919356011194 139.739274960443 13.468 35.669175881372645 139.7393175307333 13.468 35.66916411271846 139.73931018783543 13.468 35.66918179145521 139.73926761754976 13.468 35.66919356011194 139.739274960443 13.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bdef762e-3b32-4c6f-b65b-e35d42758cd4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bdef762e-3b32-4c6f-b65b-e35d42758cd4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bdef762e-3b32-4c6f-b65b-e35d42758cd4">
											<gml:posList>35.669175881372645 139.7393175307333 16.12 35.66919356011194 139.739274960443 16.12 35.66918179145521 139.73926761754976 16.12 35.66916411271846 139.73931018783543 16.12 35.669175881372645 139.7393175307333 16.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8d21f997-0f3d-43b9-b3d3-f1bf7f322235">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d21f997-0f3d-43b9-b3d3-f1bf7f322235">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d21f997-0f3d-43b9-b3d3-f1bf7f322235">
											<gml:posList>35.66919356011194 139.739274960443 13.468 35.66918179145521 139.73926761754976 13.468 35.66918179145521 139.73926761754976 16.12 35.66919356011194 139.739274960443 16.12 35.66919356011194 139.739274960443 13.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3d68aab8-47f4-4bc6-9dbb-39fb4aff5171">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d68aab8-47f4-4bc6-9dbb-39fb4aff5171">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d68aab8-47f4-4bc6-9dbb-39fb4aff5171">
											<gml:posList>35.66918179145521 139.73926761754976 13.468 35.66916411271846 139.73931018783543 13.468 35.66916411271846 139.73931018783543 16.12 35.66918179145521 139.73926761754976 16.12 35.66918179145521 139.73926761754976 13.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bce66382-d283-4d97-8fcc-43c1fd3cb119">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bce66382-d283-4d97-8fcc-43c1fd3cb119">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bce66382-d283-4d97-8fcc-43c1fd3cb119">
											<gml:posList>35.669175881372645 139.7393175307333 13.468 35.66919356011194 139.739274960443 13.468 35.66919356011194 139.739274960443 16.12 35.669175881372645 139.7393175307333 16.12 35.669175881372645 139.7393175307333 13.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-70c518c1-a8b1-4910-8de0-bec6250bf22b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70c518c1-a8b1-4910-8de0-bec6250bf22b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70c518c1-a8b1-4910-8de0-bec6250bf22b">
											<gml:posList>35.66916411271846 139.73931018783543 13.468 35.669175881372645 139.7393175307333 13.468 35.669175881372645 139.7393175307333 16.12 35.66916411271846 139.73931018783543 16.12 35.66916411271846 139.73931018783543 13.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-415</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.05</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>