<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_796bcd60-3199-468b-b620-0d65481b3ce8">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67150558825369 139.74557506721496 0 35.67152412086527 139.7456498311761 0 35.6715507041059 139.74563986032388 0 35.67153208135097 139.74556509643895 0 35.67150558825369 139.74557506721496 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67150558825369 139.74557506721496 7.643 35.67153208135097 139.74556509643895 7.643 35.6715507041059 139.74563986032388 7.643 35.67152412086527 139.7456498311761 7.643 35.67150558825369 139.74557506721496 7.643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67150558825369 139.74557506721496 7.643 35.67152412086527 139.7456498311761 7.643 35.67152412086527 139.7456498311761 10.643 35.67150558825369 139.74557506721496 10.643 35.67150558825369 139.74557506721496 7.643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67152412086527 139.7456498311761 7.643 35.6715507041059 139.74563986032388 7.643 35.6715507041059 139.74563986032388 10.643 35.67152412086527 139.7456498311761 10.643 35.67152412086527 139.7456498311761 7.643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6715507041059 139.74563986032388 7.643 35.67153208135097 139.74556509643895 7.643 35.67153208135097 139.74556509643895 10.643 35.6715507041059 139.74563986032388 10.643 35.6715507041059 139.74563986032388 7.643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67153208135097 139.74556509643895 7.643 35.67150558825369 139.74557506721496 7.643 35.67150558825369 139.74557506721496 10.643 35.67153208135097 139.74556509643895 10.643 35.67153208135097 139.74556509643895 7.643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67150558825369 139.74557506721496 10.643 35.67152412086527 139.7456498311761 10.643 35.6715507041059 139.74563986032388 10.643 35.67153208135097 139.74556509643895 10.643 35.67150558825369 139.74557506721496 10.643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-298f014a-7812-443f-8c58-3ee48b9ce8f8"/>
							<gml:surfaceMember xlink:href="#poly-9394f19d-d5f2-46b7-b9c3-a9e877b47a37"/>
							<gml:surfaceMember xlink:href="#poly-64963efa-29af-49f7-9bb4-1943f42a572a"/>
							<gml:surfaceMember xlink:href="#poly-9f032a79-bee0-46d6-9635-998025de547e"/>
							<gml:surfaceMember xlink:href="#poly-a92b957d-2f9d-4001-8e48-02b9b11f5ad2"/>
							<gml:surfaceMember xlink:href="#poly-01f44e79-c71d-4270-b440-f36a8c4e4044"/>
							<gml:surfaceMember xlink:href="#poly-184ea7b5-2351-472e-8166-6bc676b1ba59"/>
							<gml:surfaceMember xlink:href="#poly-c3f85c5f-65a7-4b1f-87cc-d70d66b96fd4"/>
							<gml:surfaceMember xlink:href="#poly-617f883f-35f7-4290-b0f2-464390d66581"/>
							<gml:surfaceMember xlink:href="#poly-bbbc1b2e-e7be-4ed1-a3b3-6f76fa9f627c"/>
							<gml:surfaceMember xlink:href="#poly-27e9d86d-fc3e-400e-a680-6215d6f21851"/>
							<gml:surfaceMember xlink:href="#poly-eb7666f5-d3ab-4667-8069-c6dde9ded466"/>
							<gml:surfaceMember xlink:href="#poly-a09ef0cf-7382-4639-b261-2c13b3307627"/>
							<gml:surfaceMember xlink:href="#poly-f71d45e9-17bb-4f7a-82c9-28b9a9ae2470"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-298f014a-7812-443f-8c58-3ee48b9ce8f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-298f014a-7812-443f-8c58-3ee48b9ce8f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-298f014a-7812-443f-8c58-3ee48b9ce8f8">
											<gml:posList>35.671505588253694 139.74557506721496 7.643 35.67153208135097 139.74556509643895 7.643 35.67155070410592 139.74563986032388 7.643 35.67152412086527 139.7456498311761 7.643 35.671505588253694 139.74557506721496 7.643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9394f19d-d5f2-46b7-b9c3-a9e877b47a37">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9394f19d-d5f2-46b7-b9c3-a9e877b47a37">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9394f19d-d5f2-46b7-b9c3-a9e877b47a37">
											<gml:posList>35.67152412086527 139.7456498311761 10.5 35.67152550668594 139.74564668143142 10.5 35.671508167393924 139.74557673240056 10.5 35.671505588253694 139.74557506721496 10.5 35.67152412086527 139.7456498311761 10.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-64963efa-29af-49f7-9bb4-1943f42a572a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-64963efa-29af-49f7-9bb4-1943f42a572a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-64963efa-29af-49f7-9bb4-1943f42a572a">
											<gml:posList>35.671505588253694 139.74557506721496 10.5 35.671508167393924 139.74557673240056 10.5 35.67153072258167 139.7455682572021 10.5 35.67153208135097 139.74556509643895 10.5 35.671505588253694 139.74557506721496 10.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9f032a79-bee0-46d6-9635-998025de547e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f032a79-bee0-46d6-9635-998025de547e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f032a79-bee0-46d6-9635-998025de547e">
											<gml:posList>35.67154814297792 139.74563817302283 10.114 35.67153072258167 139.7455682572021 10.114 35.671508167393924 139.74557673240056 10.114 35.67152550668594 139.74564668143142 10.114 35.67154814297792 139.74563817302283 10.114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a92b957d-2f9d-4001-8e48-02b9b11f5ad2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a92b957d-2f9d-4001-8e48-02b9b11f5ad2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a92b957d-2f9d-4001-8e48-02b9b11f5ad2">
											<gml:posList>35.67155070410592 139.74563986032388 10.5 35.67154814297792 139.74563817302283 10.5 35.67152550668594 139.74564668143142 10.5 35.67152412086527 139.7456498311761 10.5 35.67155070410592 139.74563986032388 10.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-01f44e79-c71d-4270-b440-f36a8c4e4044">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-01f44e79-c71d-4270-b440-f36a8c4e4044">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-01f44e79-c71d-4270-b440-f36a8c4e4044">
											<gml:posList>35.67153208135097 139.74556509643895 10.5 35.67153072258167 139.7455682572021 10.5 35.67154814297792 139.74563817302283 10.5 35.67155070410592 139.74563986032388 10.5 35.67153208135097 139.74556509643895 10.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-184ea7b5-2351-472e-8166-6bc676b1ba59">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-184ea7b5-2351-472e-8166-6bc676b1ba59">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-184ea7b5-2351-472e-8166-6bc676b1ba59">
											<gml:posList>35.67153208135097 139.74556509643895 7.643 35.671505588253694 139.74557506721496 7.643 35.671505588253694 139.74557506721496 10.5 35.67153208135097 139.74556509643895 10.5 35.67153208135097 139.74556509643895 7.643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c3f85c5f-65a7-4b1f-87cc-d70d66b96fd4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3f85c5f-65a7-4b1f-87cc-d70d66b96fd4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3f85c5f-65a7-4b1f-87cc-d70d66b96fd4">
											<gml:posList>35.671508167393924 139.74557673240056 10.5 35.671508167393924 139.74557673240056 10.114 35.67153072258167 139.7455682572021 10.114 35.67153072258167 139.7455682572021 10.5 35.671508167393924 139.74557673240056 10.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-617f883f-35f7-4290-b0f2-464390d66581">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-617f883f-35f7-4290-b0f2-464390d66581">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-617f883f-35f7-4290-b0f2-464390d66581">
											<gml:posList>35.67155070410592 139.74563986032388 7.643 35.67153208135097 139.74556509643895 7.643 35.67153208135097 139.74556509643895 10.5 35.67155070410592 139.74563986032388 10.5 35.67155070410592 139.74563986032388 7.643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bbbc1b2e-e7be-4ed1-a3b3-6f76fa9f627c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bbbc1b2e-e7be-4ed1-a3b3-6f76fa9f627c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bbbc1b2e-e7be-4ed1-a3b3-6f76fa9f627c">
											<gml:posList>35.67153072258167 139.7455682572021 10.5 35.67153072258167 139.7455682572021 10.114 35.67154814297792 139.74563817302283 10.114 35.67154814297792 139.74563817302283 10.5 35.67153072258167 139.7455682572021 10.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-27e9d86d-fc3e-400e-a680-6215d6f21851">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-27e9d86d-fc3e-400e-a680-6215d6f21851">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-27e9d86d-fc3e-400e-a680-6215d6f21851">
											<gml:posList>35.67152550668594 139.74564668143142 10.5 35.67152550668594 139.74564668143142 10.114 35.671508167393924 139.74557673240056 10.114 35.671508167393924 139.74557673240056 10.5 35.67152550668594 139.74564668143142 10.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eb7666f5-d3ab-4667-8069-c6dde9ded466">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eb7666f5-d3ab-4667-8069-c6dde9ded466">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eb7666f5-d3ab-4667-8069-c6dde9ded466">
											<gml:posList>35.671505588253694 139.74557506721496 7.643 35.67152412086527 139.7456498311761 7.643 35.67152412086527 139.7456498311761 10.5 35.671505588253694 139.74557506721496 10.5 35.671505588253694 139.74557506721496 7.643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a09ef0cf-7382-4639-b261-2c13b3307627">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a09ef0cf-7382-4639-b261-2c13b3307627">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a09ef0cf-7382-4639-b261-2c13b3307627">
											<gml:posList>35.67154814297792 139.74563817302283 10.5 35.67154814297792 139.74563817302283 10.114 35.67152550668594 139.74564668143142 10.114 35.67152550668594 139.74564668143142 10.5 35.67154814297792 139.74563817302283 10.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f71d45e9-17bb-4f7a-82c9-28b9a9ae2470">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f71d45e9-17bb-4f7a-82c9-28b9a9ae2470">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f71d45e9-17bb-4f7a-82c9-28b9a9ae2470">
											<gml:posList>35.67152412086527 139.7456498311761 7.643 35.67155070410592 139.74563986032388 7.643 35.67155070410592 139.74563986032388 10.5 35.67152412086527 139.7456498311761 10.5 35.67152412086527 139.7456498311761 7.643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-1142</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>