<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_7b1605c0-03ca-4920-9e46-48c8568318b3">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">3.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>1</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67070965738417 139.73835209681224 0 35.67068950739012 139.73835806359332 0 35.670699172675924 139.73840704249864 0 35.67078963136268 139.73838023645354 0 35.67078428288278 139.7383531461773 0 35.67078199392902 139.7383538227141 0 35.67077329697782 139.73830976927266 0 35.67074687839593 139.73829918507982 0 35.67074017841792 139.73828424736556 0 35.67071999238122 139.738290225255 0 35.67072213721217 139.73830109227794 0 35.670727254504406 139.7383093378038 0 35.670707870504536 139.7383150827631 0 35.670709744015205 139.73832480129084 0 35.67070461661083 139.73832658582168 0 35.67070965738417 139.73835209681224 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67070965738417 139.73835209681224 17.927 35.67070461661083 139.73832658582168 17.927 35.670709744015205 139.73832480129084 17.927 35.670707870504536 139.7383150827631 17.927 35.670727254504406 139.7383093378038 17.927 35.67072213721217 139.73830109227794 17.927 35.67071999238122 139.738290225255 17.927 35.67074017841792 139.73828424736556 17.927 35.67074687839593 139.73829918507982 17.927 35.67077329697782 139.73830976927266 17.927 35.67078199392902 139.7383538227141 17.927 35.67078428288278 139.7383531461773 17.927 35.67078963136268 139.73838023645354 17.927 35.670699172675924 139.73840704249864 17.927 35.67068950739012 139.73835806359332 17.927 35.67070965738417 139.73835209681224 17.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67070965738417 139.73835209681224 17.927 35.67068950739012 139.73835806359332 17.927 35.67068950739012 139.73835806359332 21.44 35.67070965738417 139.73835209681224 21.44 35.67070965738417 139.73835209681224 17.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67068950739012 139.73835806359332 17.927 35.670699172675924 139.73840704249864 17.927 35.670699172675924 139.73840704249864 21.44 35.67068950739012 139.73835806359332 21.44 35.67068950739012 139.73835806359332 17.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670699172675924 139.73840704249864 17.927 35.67078963136268 139.73838023645354 17.927 35.67078963136268 139.73838023645354 21.44 35.670699172675924 139.73840704249864 21.44 35.670699172675924 139.73840704249864 17.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67078963136268 139.73838023645354 17.927 35.67078428288278 139.7383531461773 17.927 35.67078428288278 139.7383531461773 21.44 35.67078963136268 139.73838023645354 21.44 35.67078963136268 139.73838023645354 17.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67078428288278 139.7383531461773 17.927 35.67078199392902 139.7383538227141 17.927 35.67078199392902 139.7383538227141 21.44 35.67078428288278 139.7383531461773 21.44 35.67078428288278 139.7383531461773 17.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67078199392902 139.7383538227141 17.927 35.67077329697782 139.73830976927266 17.927 35.67077329697782 139.73830976927266 21.44 35.67078199392902 139.7383538227141 21.44 35.67078199392902 139.7383538227141 17.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67077329697782 139.73830976927266 17.927 35.67074687839593 139.73829918507982 17.927 35.67074687839593 139.73829918507982 21.44 35.67077329697782 139.73830976927266 21.44 35.67077329697782 139.73830976927266 17.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67074687839593 139.73829918507982 17.927 35.67074017841792 139.73828424736556 17.927 35.67074017841792 139.73828424736556 21.44 35.67074687839593 139.73829918507982 21.44 35.67074687839593 139.73829918507982 17.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67074017841792 139.73828424736556 17.927 35.67071999238122 139.738290225255 17.927 35.67071999238122 139.738290225255 21.44 35.67074017841792 139.73828424736556 21.44 35.67074017841792 139.73828424736556 17.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67071999238122 139.738290225255 17.927 35.67072213721217 139.73830109227794 17.927 35.67072213721217 139.73830109227794 21.44 35.67071999238122 139.738290225255 21.44 35.67071999238122 139.738290225255 17.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67072213721217 139.73830109227794 17.927 35.670727254504406 139.7383093378038 17.927 35.670727254504406 139.7383093378038 21.44 35.67072213721217 139.73830109227794 21.44 35.67072213721217 139.73830109227794 17.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670727254504406 139.7383093378038 17.927 35.670707870504536 139.7383150827631 17.927 35.670707870504536 139.7383150827631 21.44 35.670727254504406 139.7383093378038 21.44 35.670727254504406 139.7383093378038 17.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670707870504536 139.7383150827631 17.927 35.670709744015205 139.73832480129084 17.927 35.670709744015205 139.73832480129084 21.44 35.670707870504536 139.7383150827631 21.44 35.670707870504536 139.7383150827631 17.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670709744015205 139.73832480129084 17.927 35.67070461661083 139.73832658582168 17.927 35.67070461661083 139.73832658582168 21.44 35.670709744015205 139.73832480129084 21.44 35.670709744015205 139.73832480129084 17.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67070461661083 139.73832658582168 17.927 35.67070965738417 139.73835209681224 17.927 35.67070965738417 139.73835209681224 21.44 35.67070461661083 139.73832658582168 21.44 35.67070461661083 139.73832658582168 17.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67070965738417 139.73835209681224 21.44 35.67068950739012 139.73835806359332 21.44 35.670699172675924 139.73840704249864 21.44 35.67078963136268 139.73838023645354 21.44 35.67078428288278 139.7383531461773 21.44 35.67078199392902 139.7383538227141 21.44 35.67077329697782 139.73830976927266 21.44 35.67074687839593 139.73829918507982 21.44 35.67074017841792 139.73828424736556 21.44 35.67071999238122 139.738290225255 21.44 35.67072213721217 139.73830109227794 21.44 35.670727254504406 139.7383093378038 21.44 35.670707870504536 139.7383150827631 21.44 35.670709744015205 139.73832480129084 21.44 35.67070461661083 139.73832658582168 21.44 35.67070965738417 139.73835209681224 21.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-2d1e8902-53c3-4085-8fc1-c930d022da16"/>
							<gml:surfaceMember xlink:href="#poly-02f6df5c-2298-46a4-a368-565629ac94c3"/>
							<gml:surfaceMember xlink:href="#poly-9e097b53-c2e5-4ed5-9519-dafc17c33cef"/>
							<gml:surfaceMember xlink:href="#poly-64b1d480-2bff-4b75-aa87-917be18962d4"/>
							<gml:surfaceMember xlink:href="#poly-7b770a7e-3ee1-486b-b0b4-c709b05b8510"/>
							<gml:surfaceMember xlink:href="#poly-de745883-f249-41fb-90e0-ef20657f671c"/>
							<gml:surfaceMember xlink:href="#poly-35b915fe-723d-4669-aa20-6f6b69429a8a"/>
							<gml:surfaceMember xlink:href="#poly-644c9d43-1c5e-4223-be9f-3154381be437"/>
							<gml:surfaceMember xlink:href="#poly-b7cd0ec4-e245-46b6-be48-054250d26e0a"/>
							<gml:surfaceMember xlink:href="#poly-44f547d1-91ae-4b81-9c5e-8405390d95a3"/>
							<gml:surfaceMember xlink:href="#poly-8e6b6b62-8602-4a52-9782-bdc1e045e15e"/>
							<gml:surfaceMember xlink:href="#poly-9f13b70c-4d1c-4c17-8143-69c514571941"/>
							<gml:surfaceMember xlink:href="#poly-c5ed327e-0200-4aff-a668-7cc5990d0bba"/>
							<gml:surfaceMember xlink:href="#poly-c39c49b4-078d-4346-b4ae-0e3a494a7f66"/>
							<gml:surfaceMember xlink:href="#poly-046fd526-b9b2-4a95-8992-23629403daf6"/>
							<gml:surfaceMember xlink:href="#poly-c036a4ba-5f6d-43e1-910e-69129c18b3d6"/>
							<gml:surfaceMember xlink:href="#poly-a70b3432-ce72-4130-b600-d51a8eef5fb1"/>
							<gml:surfaceMember xlink:href="#poly-2349e293-31c5-46ca-9cd8-285c0e8cf74e"/>
							<gml:surfaceMember xlink:href="#poly-79737454-038e-4e17-b34a-5990d599d45b"/>
							<gml:surfaceMember xlink:href="#poly-4fb47bf9-d4ef-4789-a665-530680e572f4"/>
							<gml:surfaceMember xlink:href="#poly-9be0311a-bfef-4476-9fde-ec9c82f2bb41"/>
							<gml:surfaceMember xlink:href="#poly-538d9d17-eab8-466f-9657-2554393c2fa6"/>
							<gml:surfaceMember xlink:href="#poly-43fa525c-fb01-45b9-850d-f9b92eee14fd"/>
							<gml:surfaceMember xlink:href="#poly-6ec1b75f-5cba-4cb8-bea0-3a0de600bd12"/>
							<gml:surfaceMember xlink:href="#poly-cda993e2-6265-4828-b030-8479f8ebb151"/>
							<gml:surfaceMember xlink:href="#poly-a029c73e-ed31-49ec-a2ae-e6ca35e396be"/>
							<gml:surfaceMember xlink:href="#poly-ce7a69d7-89fd-40ed-964b-6942c3f4da2f"/>
							<gml:surfaceMember xlink:href="#poly-7a341ee2-ab45-4fa0-8a8a-1f5d83010a07"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-2d1e8902-53c3-4085-8fc1-c930d022da16">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d1e8902-53c3-4085-8fc1-c930d022da16">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d1e8902-53c3-4085-8fc1-c930d022da16">
											<gml:posList>35.670746878395924 139.73829918507982 17.927 35.6707732969778 139.7383097692727 17.927 35.670781993929005 139.7383538227141 17.927 35.67078428288278 139.7383531461773 17.927 35.67078963136266 139.73838023645354 17.927 35.67069917267591 139.73840704249864 17.927 35.67068950739012 139.7383580635933 17.927 35.67070965738418 139.7383520968122 17.927 35.67070461661081 139.73832658582168 17.927 35.670709744015205 139.73832480129082 17.927 35.67070787050453 139.73831508276308 17.927 35.67072725450439 139.7383093378038 17.927 35.67072213721219 139.7383010922779 17.927 35.67071999238119 139.738290225255 17.927 35.67074017841792 139.73828424736556 17.927 35.670746878395924 139.73829918507982 17.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-02f6df5c-2298-46a4-a368-565629ac94c3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-02f6df5c-2298-46a4-a368-565629ac94c3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-02f6df5c-2298-46a4-a368-565629ac94c3">
											<gml:posList>35.670746878395924 139.73829918507982 21.163 35.67074012431815 139.73828422533705 21.225 35.670720010417355 139.73829023627994 21.362 35.67072214622591 139.73830109226722 21.337 35.67072724548195 139.7383093267682 21.294 35.67070791559058 139.73831510480227 21.426 35.670709744015205 139.73832480129082 21.404 35.670746878395924 139.73829918507982 21.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9e097b53-c2e5-4ed5-9519-dafc17c33cef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e097b53-c2e5-4ed5-9519-dafc17c33cef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e097b53-c2e5-4ed5-9519-dafc17c33cef">
											<gml:posList>35.670709744015205 139.73832480129082 21.404 35.67070461661081 139.73832658582168 21.41 35.67070966644146 139.738352152033 21.872 35.670748091339114 139.73833992243306 21.862 35.67075425516478 139.7383379378405 21.86 35.6707775051806 139.73833108367114 21.863 35.6707732969778 139.7383097692727 21.478 35.670746878395924 139.73829918507982 21.163 35.670709744015205 139.73832480129082 21.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-64b1d480-2bff-4b75-aa87-917be18962d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-64b1d480-2bff-4b75-aa87-917be18962d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-64b1d480-2bff-4b75-aa87-917be18962d4">
											<gml:posList>35.6707775051806 139.73833108367114 21.863 35.67075425516478 139.7383379378405 21.86 35.670781993929005 139.7383538227141 19.982 35.6707775051806 139.73833108367114 21.863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7b770a7e-3ee1-486b-b0b4-c709b05b8510">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b770a7e-3ee1-486b-b0b4-c709b05b8510">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b770a7e-3ee1-486b-b0b4-c709b05b8510">
											<gml:posList>35.67075425516478 139.7383379378405 21.86 35.670748091339114 139.73833992243306 21.862 35.670781993929005 139.7383538227141 19.982 35.67075425516478 139.7383379378405 21.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-de745883-f249-41fb-90e0-ef20657f671c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de745883-f249-41fb-90e0-ef20657f671c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de745883-f249-41fb-90e0-ef20657f671c">
											<gml:posList>35.670757919454076 139.7383896302357 21.328 35.670781993929005 139.7383538227141 19.982 35.670748091339114 139.73833992243306 21.862 35.670757919454076 139.7383896302357 21.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-35b915fe-723d-4669-aa20-6f6b69429a8a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-35b915fe-723d-4669-aa20-6f6b69429a8a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-35b915fe-723d-4669-aa20-6f6b69429a8a">
											<gml:posList>35.67073347992839 139.73839687241565 23.58 35.670757919454076 139.7383896302357 21.328 35.670748091339114 139.73833992243306 21.862 35.67073347992839 139.73839687241565 23.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-644c9d43-1c5e-4223-be9f-3154381be437">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-644c9d43-1c5e-4223-be9f-3154381be437">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-644c9d43-1c5e-4223-be9f-3154381be437">
											<gml:posList>35.670748091339114 139.73833992243306 21.862 35.67072375130715 139.73834759531536 23.58 35.67073347992839 139.73839687241565 23.58 35.670748091339114 139.73833992243306 21.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b7cd0ec4-e245-46b6-be48-054250d26e0a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b7cd0ec4-e245-46b6-be48-054250d26e0a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b7cd0ec4-e245-46b6-be48-054250d26e0a">
											<gml:posList>35.670757919454076 139.7383896302357 21.328 35.67078963136266 139.73838023645354 19.982 35.67078428288278 139.7383531461773 19.982 35.670757919454076 139.7383896302357 21.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-44f547d1-91ae-4b81-9c5e-8405390d95a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44f547d1-91ae-4b81-9c5e-8405390d95a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44f547d1-91ae-4b81-9c5e-8405390d95a3">
											<gml:posList>35.670757919454076 139.7383896302357 21.328 35.67078428288278 139.7383531461773 19.982 35.670781993929005 139.7383538227141 19.982 35.670757919454076 139.7383896302357 21.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8e6b6b62-8602-4a52-9782-bdc1e045e15e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8e6b6b62-8602-4a52-9782-bdc1e045e15e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8e6b6b62-8602-4a52-9782-bdc1e045e15e">
											<gml:posList>35.67072375130715 139.73834759531536 23.58 35.67068950739012 139.7383580635933 21.328 35.67069917267591 139.73840704249864 21.328 35.67073347992839 139.73839687241565 23.58 35.67072375130715 139.73834759531536 23.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9f13b70c-4d1c-4c17-8143-69c514571941">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f13b70c-4d1c-4c17-8143-69c514571941">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f13b70c-4d1c-4c17-8143-69c514571941">
											<gml:posList>35.67074017841792 139.73828424736556 17.927 35.67071999238119 139.738290225255 17.927 35.670720010417355 139.73829023627994 21.362 35.67074012431815 139.73828422533705 21.225 35.67074017841792 139.73828424736556 17.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c5ed327e-0200-4aff-a668-7cc5990d0bba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c5ed327e-0200-4aff-a668-7cc5990d0bba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c5ed327e-0200-4aff-a668-7cc5990d0bba">
											<gml:posList>35.670746878395924 139.73829918507982 17.927 35.67074017841792 139.73828424736556 17.927 35.67074012431815 139.73828422533705 21.225 35.670746878395924 139.73829918507982 21.163 35.670746878395924 139.73829918507982 17.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c39c49b4-078d-4346-b4ae-0e3a494a7f66">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c39c49b4-078d-4346-b4ae-0e3a494a7f66">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c39c49b4-078d-4346-b4ae-0e3a494a7f66">
											<gml:posList>35.67071999238119 139.738290225255 17.927 35.67072213721219 139.7383010922779 17.927 35.67072214622591 139.73830109226722 21.337 35.670720010417355 139.73829023627994 21.362 35.67071999238119 139.738290225255 17.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-046fd526-b9b2-4a95-8992-23629403daf6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-046fd526-b9b2-4a95-8992-23629403daf6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-046fd526-b9b2-4a95-8992-23629403daf6">
											<gml:posList>35.6707732969778 139.7383097692727 17.927 35.670746878395924 139.73829918507982 17.927 35.670746878395924 139.73829918507982 21.163 35.6707732969778 139.7383097692727 21.478 35.6707732969778 139.7383097692727 17.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c036a4ba-5f6d-43e1-910e-69129c18b3d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c036a4ba-5f6d-43e1-910e-69129c18b3d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c036a4ba-5f6d-43e1-910e-69129c18b3d6">
											<gml:posList>35.67072213721219 139.7383010922779 17.927 35.67072725450439 139.7383093378038 17.927 35.67072724548195 139.7383093267682 21.294 35.67072214622591 139.73830109226722 21.337 35.67072213721219 139.7383010922779 17.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a70b3432-ce72-4130-b600-d51a8eef5fb1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a70b3432-ce72-4130-b600-d51a8eef5fb1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a70b3432-ce72-4130-b600-d51a8eef5fb1">
											<gml:posList>35.67072725450439 139.7383093378038 17.927 35.67070787050453 139.73831508276308 17.927 35.67070791559058 139.73831510480227 21.426 35.67072724548195 139.7383093267682 21.294 35.67072725450439 139.7383093378038 17.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2349e293-31c5-46ca-9cd8-285c0e8cf74e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2349e293-31c5-46ca-9cd8-285c0e8cf74e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2349e293-31c5-46ca-9cd8-285c0e8cf74e">
											<gml:posList>35.67070787050453 139.73831508276308 17.927 35.670709744015205 139.73832480129082 17.927 35.670709744015205 139.73832480129082 21.404 35.67070791559058 139.73831510480227 21.426 35.67070787050453 139.73831508276308 17.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-79737454-038e-4e17-b34a-5990d599d45b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79737454-038e-4e17-b34a-5990d599d45b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79737454-038e-4e17-b34a-5990d599d45b">
											<gml:posList>35.67070461661081 139.73832658582168 21.41 35.670709744015205 139.73832480129082 21.404 35.670709744015205 139.73832480129082 17.927 35.67070461661081 139.73832658582168 17.927 35.67070461661081 139.73832658582168 21.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4fb47bf9-d4ef-4789-a665-530680e572f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4fb47bf9-d4ef-4789-a665-530680e572f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4fb47bf9-d4ef-4789-a665-530680e572f4">
											<gml:posList>35.6707775051806 139.73833108367114 21.863 35.670781993929005 139.7383538227141 19.982 35.670781993929005 139.7383538227141 17.927 35.6707732969778 139.7383097692727 17.927 35.6707732969778 139.7383097692727 21.478 35.6707775051806 139.73833108367114 21.863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9be0311a-bfef-4476-9fde-ec9c82f2bb41">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9be0311a-bfef-4476-9fde-ec9c82f2bb41">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9be0311a-bfef-4476-9fde-ec9c82f2bb41">
											<gml:posList>35.67070461661081 139.73832658582168 21.41 35.67070461661081 139.73832658582168 17.927 35.67070965738418 139.7383520968122 17.927 35.67070966644146 139.738352152033 21.872 35.67070461661081 139.73832658582168 21.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-538d9d17-eab8-466f-9657-2554393c2fa6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-538d9d17-eab8-466f-9657-2554393c2fa6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-538d9d17-eab8-466f-9657-2554393c2fa6">
											<gml:posList>35.67070966644146 139.738352152033 21.872 35.67072375130715 139.73834759531536 23.58 35.670748091339114 139.73833992243306 21.862 35.67070966644146 139.738352152033 21.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-43fa525c-fb01-45b9-850d-f9b92eee14fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-43fa525c-fb01-45b9-850d-f9b92eee14fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-43fa525c-fb01-45b9-850d-f9b92eee14fd">
											<gml:posList>35.67072375130715 139.73834759531536 23.58 35.67070966644146 139.738352152033 21.872 35.67068950739012 139.7383580635933 21.328 35.67072375130715 139.73834759531536 23.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6ec1b75f-5cba-4cb8-bea0-3a0de600bd12">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ec1b75f-5cba-4cb8-bea0-3a0de600bd12">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ec1b75f-5cba-4cb8-bea0-3a0de600bd12">
											<gml:posList>35.67078428288278 139.7383531461773 17.927 35.670781993929005 139.7383538227141 17.927 35.670781993929005 139.7383538227141 19.982 35.67078428288278 139.7383531461773 19.982 35.67078428288278 139.7383531461773 17.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cda993e2-6265-4828-b030-8479f8ebb151">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cda993e2-6265-4828-b030-8479f8ebb151">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cda993e2-6265-4828-b030-8479f8ebb151">
											<gml:posList>35.67070965738418 139.7383520968122 17.927 35.67068950739012 139.7383580635933 17.927 35.67068950739012 139.7383580635933 21.328 35.67070966644146 139.738352152033 21.872 35.67070965738418 139.7383520968122 17.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a029c73e-ed31-49ec-a2ae-e6ca35e396be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a029c73e-ed31-49ec-a2ae-e6ca35e396be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a029c73e-ed31-49ec-a2ae-e6ca35e396be">
											<gml:posList>35.67078963136266 139.73838023645354 17.927 35.67078428288278 139.7383531461773 17.927 35.67078428288278 139.7383531461773 19.982 35.67078963136266 139.73838023645354 19.982 35.67078963136266 139.73838023645354 17.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ce7a69d7-89fd-40ed-964b-6942c3f4da2f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce7a69d7-89fd-40ed-964b-6942c3f4da2f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce7a69d7-89fd-40ed-964b-6942c3f4da2f">
											<gml:posList>35.67068950739012 139.7383580635933 17.927 35.67069917267591 139.73840704249864 17.927 35.67069917267591 139.73840704249864 21.328 35.67068950739012 139.7383580635933 21.328 35.67068950739012 139.7383580635933 17.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7a341ee2-ab45-4fa0-8a8a-1f5d83010a07">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a341ee2-ab45-4fa0-8a8a-1f5d83010a07">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a341ee2-ab45-4fa0-8a8a-1f5d83010a07">
											<gml:posList>35.670757919454076 139.7383896302357 21.328 35.67073347992839 139.73839687241565 23.58 35.67069917267591 139.73840704249864 21.328 35.67069917267591 139.73840704249864 17.927 35.67078963136266 139.73838023645354 17.927 35.67078963136266 139.73838023645354 19.982 35.670757919454076 139.7383896302357 21.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4416</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">62.2135</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1003</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1242</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">21</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>