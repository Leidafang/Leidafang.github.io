<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_7c4ba13b-1e2c-4860-97fb-4968165d4c26">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">3.7</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.667085457303635 139.74609096124888 0 35.66710306800888 139.74603826462786 0 35.66705582785609 139.74601455653521 0 35.667038217153035 139.74606724208456 0 35.667085457303635 139.74609096124888 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667085457303635 139.74609096124888 8.234 35.667038217153035 139.74606724208456 8.234 35.66705582785609 139.74601455653521 8.234 35.66710306800888 139.74603826462786 8.234 35.667085457303635 139.74609096124888 8.234</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667085457303635 139.74609096124888 8.234 35.66710306800888 139.74603826462786 8.234 35.66710306800888 139.74603826462786 11.89 35.667085457303635 139.74609096124888 11.89 35.667085457303635 139.74609096124888 8.234</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66710306800888 139.74603826462786 8.234 35.66705582785609 139.74601455653521 8.234 35.66705582785609 139.74601455653521 11.89 35.66710306800888 139.74603826462786 11.89 35.66710306800888 139.74603826462786 8.234</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66705582785609 139.74601455653521 8.234 35.667038217153035 139.74606724208456 8.234 35.667038217153035 139.74606724208456 11.89 35.66705582785609 139.74601455653521 11.89 35.66705582785609 139.74601455653521 8.234</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667038217153035 139.74606724208456 8.234 35.667085457303635 139.74609096124888 8.234 35.667085457303635 139.74609096124888 11.89 35.667038217153035 139.74606724208456 11.89 35.667038217153035 139.74606724208456 8.234</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667085457303635 139.74609096124888 11.89 35.66710306800888 139.74603826462786 11.89 35.66705582785609 139.74601455653521 11.89 35.667038217153035 139.74606724208456 11.89 35.667085457303635 139.74609096124888 11.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-6393d3f2-cb7a-4965-91ea-22ce0e9959ca"/>
							<gml:surfaceMember xlink:href="#poly-24be4829-f5b6-4d88-93db-ff91792daea6"/>
							<gml:surfaceMember xlink:href="#poly-68b695d5-2f85-4339-8f36-c42504b19eaa"/>
							<gml:surfaceMember xlink:href="#poly-4c0d974d-faab-48e2-9173-271cb970944f"/>
							<gml:surfaceMember xlink:href="#poly-84650db5-d5f0-479b-a941-fc80f46119f3"/>
							<gml:surfaceMember xlink:href="#poly-ced936dc-80fa-4e07-a65b-e450d6f78bf5"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-6393d3f2-cb7a-4965-91ea-22ce0e9959ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6393d3f2-cb7a-4965-91ea-22ce0e9959ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6393d3f2-cb7a-4965-91ea-22ce0e9959ca">
											<gml:posList>35.667085457303635 139.74609096124888 8.234 35.66703821715302 139.74606724208454 8.234 35.667055827856075 139.7460145565352 8.234 35.66710306800888 139.74603826462786 8.234 35.667085457303635 139.74609096124888 8.234</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-24be4829-f5b6-4d88-93db-ff91792daea6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-24be4829-f5b6-4d88-93db-ff91792daea6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-24be4829-f5b6-4d88-93db-ff91792daea6">
											<gml:posList>35.66703821715302 139.74606724208454 12.525 35.667085457303635 139.74609096124888 12.525 35.66710306800888 139.74603826462786 12.525 35.667055827856075 139.7460145565352 12.525 35.66703821715302 139.74606724208454 12.525</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-68b695d5-2f85-4339-8f36-c42504b19eaa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-68b695d5-2f85-4339-8f36-c42504b19eaa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-68b695d5-2f85-4339-8f36-c42504b19eaa">
											<gml:posList>35.66710306800888 139.74603826462786 8.234 35.667055827856075 139.7460145565352 8.234 35.667055827856075 139.7460145565352 12.525 35.66710306800888 139.74603826462786 12.525 35.66710306800888 139.74603826462786 8.234</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4c0d974d-faab-48e2-9173-271cb970944f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c0d974d-faab-48e2-9173-271cb970944f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c0d974d-faab-48e2-9173-271cb970944f">
											<gml:posList>35.667055827856075 139.7460145565352 8.234 35.66703821715302 139.74606724208454 8.234 35.66703821715302 139.74606724208454 12.525 35.667055827856075 139.7460145565352 12.525 35.667055827856075 139.7460145565352 8.234</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-84650db5-d5f0-479b-a941-fc80f46119f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84650db5-d5f0-479b-a941-fc80f46119f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84650db5-d5f0-479b-a941-fc80f46119f3">
											<gml:posList>35.667085457303635 139.74609096124888 8.234 35.66710306800888 139.74603826462786 8.234 35.66710306800888 139.74603826462786 12.525 35.667085457303635 139.74609096124888 12.525 35.667085457303635 139.74609096124888 8.234</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ced936dc-80fa-4e07-a65b-e450d6f78bf5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ced936dc-80fa-4e07-a65b-e450d6f78bf5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ced936dc-80fa-4e07-a65b-e450d6f78bf5">
											<gml:posList>35.66703821715302 139.74606724208454 8.234 35.667085457303635 139.74609096124888 8.234 35.667085457303635 139.74609096124888 12.525 35.66703821715302 139.74606724208454 12.525 35.66703821715302 139.74606724208454 8.234</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5812</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">222</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>