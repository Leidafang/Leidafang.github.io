<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_7c831614-2472-41f7-ab47-ef1dd0e9ca34">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">39</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67156250879384 139.7424028699849 0 35.67163219896313 139.74246923523407 0 35.67167035371894 139.74240905518653 0 35.6717917771187 139.74221754870987 0 35.67167324223691 139.74210466731776 0 35.67165282042402 139.74208522673712 0 35.67149324253275 139.7423369020408 0 35.67156250879384 139.7424028699849 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67156250879384 139.7424028699849 7.31 35.67149324253275 139.7423369020408 7.31 35.67165282042402 139.74208522673712 7.31 35.67167324223691 139.74210466731776 7.31 35.6717917771187 139.74221754870987 7.31 35.67167035371894 139.74240905518653 7.31 35.67163219896313 139.74246923523407 7.31 35.67156250879384 139.7424028699849 7.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67156250879384 139.7424028699849 7.31 35.67163219896313 139.74246923523407 7.31 35.67163219896313 139.74246923523407 43.94 35.67156250879384 139.7424028699849 43.94 35.67156250879384 139.7424028699849 7.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67163219896313 139.74246923523407 7.31 35.67167035371894 139.74240905518653 7.31 35.67167035371894 139.74240905518653 43.94 35.67163219896313 139.74246923523407 43.94 35.67163219896313 139.74246923523407 7.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67167035371894 139.74240905518653 7.31 35.6717917771187 139.74221754870987 7.31 35.6717917771187 139.74221754870987 43.94 35.67167035371894 139.74240905518653 43.94 35.67167035371894 139.74240905518653 7.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6717917771187 139.74221754870987 7.31 35.67167324223691 139.74210466731776 7.31 35.67167324223691 139.74210466731776 43.94 35.6717917771187 139.74221754870987 43.94 35.6717917771187 139.74221754870987 7.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67167324223691 139.74210466731776 7.31 35.67165282042402 139.74208522673712 7.31 35.67165282042402 139.74208522673712 43.94 35.67167324223691 139.74210466731776 43.94 35.67167324223691 139.74210466731776 7.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67165282042402 139.74208522673712 7.31 35.67149324253275 139.7423369020408 7.31 35.67149324253275 139.7423369020408 43.94 35.67165282042402 139.74208522673712 43.94 35.67165282042402 139.74208522673712 7.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67149324253275 139.7423369020408 7.31 35.67156250879384 139.7424028699849 7.31 35.67156250879384 139.7424028699849 43.94 35.67149324253275 139.7423369020408 43.94 35.67149324253275 139.7423369020408 7.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67156250879384 139.7424028699849 43.94 35.67163219896313 139.74246923523407 43.94 35.67167035371894 139.74240905518653 43.94 35.6717917771187 139.74221754870987 43.94 35.67167324223691 139.74210466731776 43.94 35.67165282042402 139.74208522673712 43.94 35.67149324253275 139.7423369020408 43.94 35.67156250879384 139.7424028699849 43.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-e9f9b780-441a-4ddc-a407-98ce39cc9f49"/>
							<gml:surfaceMember xlink:href="#poly-f7f8bb0f-ff6d-4573-8b21-2cc15ef5033f"/>
							<gml:surfaceMember xlink:href="#poly-736d6730-1b53-43de-87db-34de1877c113"/>
							<gml:surfaceMember xlink:href="#poly-35d5e27f-ed9c-4e38-8200-1cd34b81029c"/>
							<gml:surfaceMember xlink:href="#poly-56f4bbc6-0263-45f4-829a-c5d664e20670"/>
							<gml:surfaceMember xlink:href="#poly-53f0b774-4780-4812-bf44-0008b1c3a433"/>
							<gml:surfaceMember xlink:href="#poly-bd08ff4a-d428-4dd9-b202-20cce327dab7"/>
							<gml:surfaceMember xlink:href="#poly-a4ac71b5-2878-41d1-96a6-fe5f3bb78080"/>
							<gml:surfaceMember xlink:href="#poly-f00f68a7-5df5-498e-a8f2-d64a1a068cd3"/>
							<gml:surfaceMember xlink:href="#poly-9a84e74d-668d-4582-b839-ea3bc1632d63"/>
							<gml:surfaceMember xlink:href="#poly-3c943b84-9574-4189-88fe-5cdd8957abbc"/>
							<gml:surfaceMember xlink:href="#poly-bed8afba-c589-4fdb-8591-fa46e6ab22d8"/>
							<gml:surfaceMember xlink:href="#poly-39458242-de9f-4397-9d12-6470b69bb84f"/>
							<gml:surfaceMember xlink:href="#poly-c372575f-c17b-4c4a-8b31-020dcdad6fde"/>
							<gml:surfaceMember xlink:href="#poly-76742dd5-7337-43a7-bd1d-a8162a516866"/>
							<gml:surfaceMember xlink:href="#poly-a34465b6-d133-4b92-ba02-08cd4d611a8e"/>
							<gml:surfaceMember xlink:href="#poly-3430f66b-1ff8-410a-bf3f-85180665475b"/>
							<gml:surfaceMember xlink:href="#poly-5e7d2dc9-e9df-49d9-ba7b-d497bcbd58a5"/>
							<gml:surfaceMember xlink:href="#poly-e02025e2-ff41-466e-84ba-cfa07c2dbefd"/>
							<gml:surfaceMember xlink:href="#poly-640881e8-0f9d-4a7c-97d1-1d87d5e105b8"/>
							<gml:surfaceMember xlink:href="#poly-4e4ad514-99c1-4ee1-9c24-60c58b4e82a8"/>
							<gml:surfaceMember xlink:href="#poly-581d1c48-22e3-4199-ab32-2fff7441ecce"/>
							<gml:surfaceMember xlink:href="#poly-fb9be92f-9746-4e02-a33a-69a4a3476d5f"/>
							<gml:surfaceMember xlink:href="#poly-a421bf5f-6cb7-4d4e-8213-2d7021c78321"/>
							<gml:surfaceMember xlink:href="#poly-1e15a828-38eb-403d-adaf-2676339437bd"/>
							<gml:surfaceMember xlink:href="#poly-ef78f125-2961-4a59-bdd2-5eb81b2f7071"/>
							<gml:surfaceMember xlink:href="#poly-3d9029fa-7a58-48bd-87b8-42b0c20ec23f"/>
							<gml:surfaceMember xlink:href="#poly-e98677ed-7942-4087-a975-3e5e50d1afe9"/>
							<gml:surfaceMember xlink:href="#poly-e0f37144-a68e-4bc6-903d-9205c3efee79"/>
							<gml:surfaceMember xlink:href="#poly-f0389415-0d06-4b59-9aa2-ca48fb83b2a3"/>
							<gml:surfaceMember xlink:href="#poly-c5769dfb-12e3-461d-9020-8848af97bd04"/>
							<gml:surfaceMember xlink:href="#poly-4eaac147-d2e8-429c-9ef1-38616250b930"/>
							<gml:surfaceMember xlink:href="#poly-d08a19a4-150e-4f9f-9d9c-4dbd3ef48d19"/>
							<gml:surfaceMember xlink:href="#poly-9431b299-f336-4682-bee4-c097f3996e66"/>
							<gml:surfaceMember xlink:href="#poly-579ef476-6fdf-48a2-9cc9-a0348b0a6ea6"/>
							<gml:surfaceMember xlink:href="#poly-be6a794b-08ac-423e-bf42-83202b562efd"/>
							<gml:surfaceMember xlink:href="#poly-fb977b71-16af-4f0b-8ccd-bcbfe38678b4"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-e9f9b780-441a-4ddc-a407-98ce39cc9f49">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e9f9b780-441a-4ddc-a407-98ce39cc9f49">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e9f9b780-441a-4ddc-a407-98ce39cc9f49">
											<gml:posList>35.671652820424 139.7420852267371 7.31 35.67179177711867 139.74221754870987 7.31 35.67163219896313 139.74246923523404 7.31 35.671493242532755 139.7423369020408 7.31 35.671652820424 139.7420852267371 7.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f7f8bb0f-ff6d-4573-8b21-2cc15ef5033f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f7f8bb0f-ff6d-4573-8b21-2cc15ef5033f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f7f8bb0f-ff6d-4573-8b21-2cc15ef5033f">
											<gml:posList>35.67163623094025 139.74218676233426 45.9 35.67166487115021 139.74221532899867 45.9 35.671672335015025 139.7422040752424 45.9 35.67164369480244 139.74217550857938 45.9 35.67163623094025 139.74218676233426 45.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-736d6730-1b53-43de-87db-34de1877c113">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-736d6730-1b53-43de-87db-34de1877c113">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-736d6730-1b53-43de-87db-34de1877c113">
											<gml:posList>35.671641202268425 139.74222878836147 43.5 35.67166487115021 139.74221532899867 43.5 35.67163623094025 139.74218676233426 43.5 35.671623973456036 139.7422121499213 43.5 35.671641202268425 139.74222878836147 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-35d5e27f-ed9c-4e38-8200-1cd34b81029c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-35d5e27f-ed9c-4e38-8200-1cd34b81029c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-35d5e27f-ed9c-4e38-8200-1cd34b81029c">
											<gml:posList>35.67160153444171 139.74229048355159 45.9 35.671641202268425 139.74222878836147 45.9 35.671623973456036 139.7422121499213 45.9 35.67158429661566 139.74227383407018 45.9 35.67160153444171 139.74229048355159 45.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-56f4bbc6-0263-45f4-829a-c5d664e20670">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56f4bbc6-0263-45f4-829a-c5d664e20670">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56f4bbc6-0263-45f4-829a-c5d664e20670">
											<gml:posList>35.67157361034234 139.7423387549951 43.5 35.67155939485805 139.74232572530465 43.5 35.671535018562906 139.74235731259316 43.5 35.67157016134711 139.7423907986111 43.5 35.67160066351692 139.7423426899583 43.5 35.67167035371891 139.74240905518653 43.5 35.67179177711867 139.74221754870987 43.5 35.67167324223692 139.74210466731776 43.5 35.67155612244487 139.74228938629204 43.5 35.67156981514561 139.7423024276155 43.5 35.671572907728894 139.74230358397864 43.5 35.67158429661566 139.74227383407018 43.5 35.671623973456036 139.7422121499213 43.5 35.67163623094025 139.74218676233426 43.5 35.67164369480244 139.74217550857938 43.5 35.671672335015025 139.7422040752424 43.5 35.67166487115021 139.74221532899867 43.5 35.671641202268425 139.74222878836147 43.5 35.67163940664756 139.74225012106425 43.5 35.67165713017338 139.74226538919586 43.5 35.67164615689893 139.7422845119911 43.5 35.671628442389206 139.7422692438471 43.5 35.67160153444171 139.74229048355159 43.5 35.6715871232239 139.74231662471377 43.5 35.67157361034234 139.7423387549951 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-53f0b774-4780-4812-bf44-0008b1c3a433">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-53f0b774-4780-4812-bf44-0008b1c3a433">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-53f0b774-4780-4812-bf44-0008b1c3a433">
											<gml:posList>35.671641202268425 139.74222878836147 43.5 35.67160153444171 139.74229048355159 43.5 35.671628442389206 139.7422692438471 43.5 35.67163940664756 139.74225012106425 43.5 35.671641202268425 139.74222878836147 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bd08ff4a-d428-4dd9-b202-20cce327dab7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd08ff4a-d428-4dd9-b202-20cce327dab7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd08ff4a-d428-4dd9-b202-20cce327dab7">
											<gml:posList>35.67164615689893 139.7422845119911 45.9 35.67165713017338 139.74226538919586 45.9 35.67163940664756 139.74225012106425 45.9 35.671628442389206 139.7422692438471 45.9 35.67164615689893 139.7422845119911 45.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a4ac71b5-2878-41d1-96a6-fe5f3bb78080">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4ac71b5-2878-41d1-96a6-fe5f3bb78080">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4ac71b5-2878-41d1-96a6-fe5f3bb78080">
											<gml:posList>35.67167035371891 139.74240905518653 46.3 35.67160066351692 139.7423426899583 46.3 35.67157016134711 139.7423907986111 46.3 35.671535018562906 139.74235731259316 46.3 35.67156981514561 139.7423024276155 46.3 35.67155612244487 139.74228938629204 46.3 35.67167324223692 139.74210466731776 46.3 35.671652820424 139.7420852267371 46.3 35.671493242532755 139.7423369020408 46.3 35.67163219896313 139.74246923523404 46.3 35.67167035371891 139.74240905518653 46.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f00f68a7-5df5-498e-a8f2-d64a1a068cd3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f00f68a7-5df5-498e-a8f2-d64a1a068cd3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f00f68a7-5df5-498e-a8f2-d64a1a068cd3">
											<gml:posList>35.67160153444171 139.74229048355159 43.5 35.67158429661566 139.74227383407018 43.5 35.671572907728894 139.74230358397864 43.5 35.6715871232239 139.74231662471377 43.5 35.67160153444171 139.74229048355159 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9a84e74d-668d-4582-b839-ea3bc1632d63">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a84e74d-668d-4582-b839-ea3bc1632d63">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a84e74d-668d-4582-b839-ea3bc1632d63">
											<gml:posList>35.6715871232239 139.74231662471377 44.5 35.671572907728894 139.74230358397864 44.5 35.67155939485805 139.74232572530465 44.5 35.67157361034234 139.7423387549951 44.5 35.6715871232239 139.74231662471377 44.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3c943b84-9574-4189-88fe-5cdd8957abbc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c943b84-9574-4189-88fe-5cdd8957abbc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c943b84-9574-4189-88fe-5cdd8957abbc">
											<gml:posList>35.67155939485805 139.74232572530465 43.5 35.671572907728894 139.74230358397864 43.5 35.67156981514561 139.7423024276155 43.5 35.671535018562906 139.74235731259316 43.5 35.67155939485805 139.74232572530465 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bed8afba-c589-4fdb-8591-fa46e6ab22d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bed8afba-c589-4fdb-8591-fa46e6ab22d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bed8afba-c589-4fdb-8591-fa46e6ab22d8">
											<gml:posList>35.67163623094025 139.74218676233426 43.5 35.67163623094025 139.74218676233426 45.9 35.67164369480244 139.74217550857938 45.9 35.67164369480244 139.74217550857938 43.5 35.67163623094025 139.74218676233426 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-39458242-de9f-4397-9d12-6470b69bb84f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-39458242-de9f-4397-9d12-6470b69bb84f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-39458242-de9f-4397-9d12-6470b69bb84f">
											<gml:posList>35.67158429661566 139.74227383407018 43.5 35.67158429661566 139.74227383407018 45.9 35.671623973456036 139.7422121499213 45.9 35.671623973456036 139.7422121499213 43.5 35.67158429661566 139.74227383407018 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c372575f-c17b-4c4a-8b31-020dcdad6fde">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c372575f-c17b-4c4a-8b31-020dcdad6fde">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c372575f-c17b-4c4a-8b31-020dcdad6fde">
											<gml:posList>35.671628442389206 139.7422692438471 43.5 35.671628442389206 139.7422692438471 45.9 35.67163940664756 139.74225012106425 45.9 35.67163940664756 139.74225012106425 43.5 35.671628442389206 139.7422692438471 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-76742dd5-7337-43a7-bd1d-a8162a516866">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-76742dd5-7337-43a7-bd1d-a8162a516866">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-76742dd5-7337-43a7-bd1d-a8162a516866">
											<gml:posList>35.67155939485805 139.74232572530465 43.5 35.67155939485805 139.74232572530465 44.5 35.671572907728894 139.74230358397864 44.5 35.671572907728894 139.74230358397864 43.5 35.67155939485805 139.74232572530465 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a34465b6-d133-4b92-ba02-08cd4d611a8e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a34465b6-d133-4b92-ba02-08cd4d611a8e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a34465b6-d133-4b92-ba02-08cd4d611a8e">
											<gml:posList>35.67157361034234 139.7423387549951 43.5 35.67157361034234 139.7423387549951 44.5 35.67155939485805 139.74232572530465 44.5 35.67155939485805 139.74232572530465 43.5 35.67157361034234 139.7423387549951 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3430f66b-1ff8-410a-bf3f-85180665475b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3430f66b-1ff8-410a-bf3f-85180665475b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3430f66b-1ff8-410a-bf3f-85180665475b">
											<gml:posList>35.671652820424 139.7420852267371 46.3 35.67167324223692 139.74210466731776 46.3 35.67167324223692 139.74210466731776 43.5 35.67179177711867 139.74221754870987 43.5 35.67179177711867 139.74221754870987 7.31 35.671652820424 139.7420852267371 7.31 35.671652820424 139.7420852267371 46.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5e7d2dc9-e9df-49d9-ba7b-d497bcbd58a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e7d2dc9-e9df-49d9-ba7b-d497bcbd58a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e7d2dc9-e9df-49d9-ba7b-d497bcbd58a5">
											<gml:posList>35.67164369480244 139.74217550857938 43.5 35.67164369480244 139.74217550857938 45.9 35.671672335015025 139.7422040752424 45.9 35.671672335015025 139.7422040752424 43.5 35.67164369480244 139.74217550857938 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e02025e2-ff41-466e-84ba-cfa07c2dbefd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e02025e2-ff41-466e-84ba-cfa07c2dbefd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e02025e2-ff41-466e-84ba-cfa07c2dbefd">
											<gml:posList>35.67167324223692 139.74210466731776 43.5 35.67167324223692 139.74210466731776 46.3 35.67155612244487 139.74228938629204 46.3 35.67155612244487 139.74228938629204 43.5 35.67167324223692 139.74210466731776 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-640881e8-0f9d-4a7c-97d1-1d87d5e105b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-640881e8-0f9d-4a7c-97d1-1d87d5e105b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-640881e8-0f9d-4a7c-97d1-1d87d5e105b8">
											<gml:posList>35.67166487115021 139.74221532899867 43.5 35.67166487115021 139.74221532899867 45.9 35.67163623094025 139.74218676233426 45.9 35.67163623094025 139.74218676233426 43.5 35.67166487115021 139.74221532899867 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4e4ad514-99c1-4ee1-9c24-60c58b4e82a8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4e4ad514-99c1-4ee1-9c24-60c58b4e82a8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4e4ad514-99c1-4ee1-9c24-60c58b4e82a8">
											<gml:posList>35.671672335015025 139.7422040752424 43.5 35.671672335015025 139.7422040752424 45.9 35.67166487115021 139.74221532899867 45.9 35.67166487115021 139.74221532899867 43.5 35.671672335015025 139.7422040752424 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-581d1c48-22e3-4199-ab32-2fff7441ecce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-581d1c48-22e3-4199-ab32-2fff7441ecce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-581d1c48-22e3-4199-ab32-2fff7441ecce">
											<gml:posList>35.671652820424 139.7420852267371 7.31 35.671493242532755 139.7423369020408 7.31 35.671493242532755 139.7423369020408 46.3 35.671652820424 139.7420852267371 46.3 35.671652820424 139.7420852267371 7.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fb9be92f-9746-4e02-a33a-69a4a3476d5f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb9be92f-9746-4e02-a33a-69a4a3476d5f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb9be92f-9746-4e02-a33a-69a4a3476d5f">
											<gml:posList>35.671623973456036 139.7422121499213 43.5 35.671623973456036 139.7422121499213 45.9 35.671641202268425 139.74222878836147 45.9 35.671641202268425 139.74222878836147 43.5 35.671623973456036 139.7422121499213 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a421bf5f-6cb7-4d4e-8213-2d7021c78321">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a421bf5f-6cb7-4d4e-8213-2d7021c78321">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a421bf5f-6cb7-4d4e-8213-2d7021c78321">
											<gml:posList>35.67163940664756 139.74225012106425 43.5 35.67163940664756 139.74225012106425 45.9 35.67165713017338 139.74226538919586 45.9 35.67165713017338 139.74226538919586 43.5 35.67163940664756 139.74225012106425 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1e15a828-38eb-403d-adaf-2676339437bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e15a828-38eb-403d-adaf-2676339437bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e15a828-38eb-403d-adaf-2676339437bd">
											<gml:posList>35.671641202268425 139.74222878836147 43.5 35.671641202268425 139.74222878836147 45.9 35.67160153444171 139.74229048355159 45.9 35.67160153444171 139.74229048355159 43.5 35.671641202268425 139.74222878836147 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ef78f125-2961-4a59-bdd2-5eb81b2f7071">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef78f125-2961-4a59-bdd2-5eb81b2f7071">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef78f125-2961-4a59-bdd2-5eb81b2f7071">
											<gml:posList>35.67165713017338 139.74226538919586 43.5 35.67165713017338 139.74226538919586 45.9 35.67164615689893 139.7422845119911 45.9 35.67164615689893 139.7422845119911 43.5 35.67165713017338 139.74226538919586 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3d9029fa-7a58-48bd-87b8-42b0c20ec23f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d9029fa-7a58-48bd-87b8-42b0c20ec23f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d9029fa-7a58-48bd-87b8-42b0c20ec23f">
											<gml:posList>35.67164615689893 139.7422845119911 43.5 35.67164615689893 139.7422845119911 45.9 35.671628442389206 139.7422692438471 45.9 35.671628442389206 139.7422692438471 43.5 35.67164615689893 139.7422845119911 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e98677ed-7942-4087-a975-3e5e50d1afe9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e98677ed-7942-4087-a975-3e5e50d1afe9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e98677ed-7942-4087-a975-3e5e50d1afe9">
											<gml:posList>35.67160153444171 139.74229048355159 43.5 35.67160153444171 139.74229048355159 45.9 35.67158429661566 139.74227383407018 45.9 35.67158429661566 139.74227383407018 43.5 35.67160153444171 139.74229048355159 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e0f37144-a68e-4bc6-903d-9205c3efee79">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e0f37144-a68e-4bc6-903d-9205c3efee79">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e0f37144-a68e-4bc6-903d-9205c3efee79">
											<gml:posList>35.67155612244487 139.74228938629204 43.5 35.67155612244487 139.74228938629204 46.3 35.67156981514561 139.7423024276155 46.3 35.67156981514561 139.7423024276155 43.5 35.67155612244487 139.74228938629204 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f0389415-0d06-4b59-9aa2-ca48fb83b2a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f0389415-0d06-4b59-9aa2-ca48fb83b2a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f0389415-0d06-4b59-9aa2-ca48fb83b2a3">
											<gml:posList>35.671572907728894 139.74230358397864 43.5 35.671572907728894 139.74230358397864 44.5 35.6715871232239 139.74231662471377 44.5 35.6715871232239 139.74231662471377 43.5 35.671572907728894 139.74230358397864 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c5769dfb-12e3-461d-9020-8848af97bd04">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c5769dfb-12e3-461d-9020-8848af97bd04">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c5769dfb-12e3-461d-9020-8848af97bd04">
											<gml:posList>35.6715871232239 139.74231662471377 43.5 35.6715871232239 139.74231662471377 44.5 35.67157361034234 139.7423387549951 44.5 35.67157361034234 139.7423387549951 43.5 35.6715871232239 139.74231662471377 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4eaac147-d2e8-429c-9ef1-38616250b930">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4eaac147-d2e8-429c-9ef1-38616250b930">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4eaac147-d2e8-429c-9ef1-38616250b930">
											<gml:posList>35.67156981514561 139.7423024276155 43.5 35.67156981514561 139.7423024276155 46.3 35.671535018562906 139.74235731259316 46.3 35.671535018562906 139.74235731259316 43.5 35.67156981514561 139.7423024276155 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d08a19a4-150e-4f9f-9d9c-4dbd3ef48d19">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d08a19a4-150e-4f9f-9d9c-4dbd3ef48d19">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d08a19a4-150e-4f9f-9d9c-4dbd3ef48d19">
											<gml:posList>35.67179177711867 139.74221754870987 7.31 35.67179177711867 139.74221754870987 43.5 35.67167035371891 139.74240905518653 43.5 35.67167035371891 139.74240905518653 46.3 35.67163219896313 139.74246923523404 46.3 35.67163219896313 139.74246923523404 7.31 35.67179177711867 139.74221754870987 7.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9431b299-f336-4682-bee4-c097f3996e66">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9431b299-f336-4682-bee4-c097f3996e66">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9431b299-f336-4682-bee4-c097f3996e66">
											<gml:posList>35.67160066351692 139.7423426899583 46.3 35.67160066351692 139.7423426899583 43.5 35.67157016134711 139.7423907986111 43.5 35.67157016134711 139.7423907986111 46.3 35.67160066351692 139.7423426899583 46.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-579ef476-6fdf-48a2-9cc9-a0348b0a6ea6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-579ef476-6fdf-48a2-9cc9-a0348b0a6ea6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-579ef476-6fdf-48a2-9cc9-a0348b0a6ea6">
											<gml:posList>35.671535018562906 139.74235731259316 43.5 35.671535018562906 139.74235731259316 46.3 35.67157016134711 139.7423907986111 46.3 35.67157016134711 139.7423907986111 43.5 35.671535018562906 139.74235731259316 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-be6a794b-08ac-423e-bf42-83202b562efd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-be6a794b-08ac-423e-bf42-83202b562efd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-be6a794b-08ac-423e-bf42-83202b562efd">
											<gml:posList>35.67160066351692 139.7423426899583 43.5 35.67160066351692 139.7423426899583 46.3 35.67167035371891 139.74240905518653 46.3 35.67167035371891 139.74240905518653 43.5 35.67160066351692 139.7423426899583 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fb977b71-16af-4f0b-8ccd-bcbfe38678b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb977b71-16af-4f0b-8ccd-bcbfe38678b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb977b71-16af-4f0b-8ccd-bcbfe38678b4">
											<gml:posList>35.671493242532755 139.7423369020408 46.3 35.671493242532755 139.7423369020408 7.31 35.67163219896313 139.74246923523404 7.31 35.67163219896313 139.74246923523404 46.3 35.671493242532755 139.7423369020408 46.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4483</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">544.9547</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.28</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>