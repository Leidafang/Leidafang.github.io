<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_7d39702c-88fc-43b6-b85b-43e9164ee6fd">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">12.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.668696177243916 139.73981233664827 0 35.6686526942929 139.73988109361767 0 35.668704471213076 139.73993018809895 0 35.668737330942434 139.73987812300552 0 35.66872756816644 139.739842124321 0 35.668696177243916 139.73981233664827 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668696177243916 139.73981233664827 11.39 35.66872756816644 139.739842124321 11.39 35.668737330942434 139.73987812300552 11.39 35.668704471213076 139.73993018809895 11.39 35.6686526942929 139.73988109361767 11.39 35.668696177243916 139.73981233664827 11.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668696177243916 139.73981233664827 11.39 35.6686526942929 139.73988109361767 11.39 35.6686526942929 139.73988109361767 23.64 35.668696177243916 139.73981233664827 23.64 35.668696177243916 139.73981233664827 11.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6686526942929 139.73988109361767 11.39 35.668704471213076 139.73993018809895 11.39 35.668704471213076 139.73993018809895 23.64 35.6686526942929 139.73988109361767 23.64 35.6686526942929 139.73988109361767 11.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668704471213076 139.73993018809895 11.39 35.668737330942434 139.73987812300552 11.39 35.668737330942434 139.73987812300552 23.64 35.668704471213076 139.73993018809895 23.64 35.668704471213076 139.73993018809895 11.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668737330942434 139.73987812300552 11.39 35.66872756816644 139.739842124321 11.39 35.66872756816644 139.739842124321 23.64 35.668737330942434 139.73987812300552 23.64 35.668737330942434 139.73987812300552 11.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66872756816644 139.739842124321 11.39 35.668696177243916 139.73981233664827 11.39 35.668696177243916 139.73981233664827 23.64 35.66872756816644 139.739842124321 23.64 35.66872756816644 139.739842124321 11.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668696177243916 139.73981233664827 23.64 35.6686526942929 139.73988109361767 23.64 35.668704471213076 139.73993018809895 23.64 35.668737330942434 139.73987812300552 23.64 35.66872756816644 139.739842124321 23.64 35.668696177243916 139.73981233664827 23.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-97538e21-aff5-4c98-a933-000e36166254"/>
							<gml:surfaceMember xlink:href="#poly-4ba6deb3-8e47-405e-bb30-389fa98c54c5"/>
							<gml:surfaceMember xlink:href="#poly-b6295954-580e-48f2-ba97-5084819c0852"/>
							<gml:surfaceMember xlink:href="#poly-fba08b4f-f47e-4fe0-97ca-e8f5c808e2e0"/>
							<gml:surfaceMember xlink:href="#poly-0a209ce6-1ef0-4542-9024-c4f3268b31a0"/>
							<gml:surfaceMember xlink:href="#poly-8fc4adc9-ac49-4cb8-b8d7-8fc71f90675a"/>
							<gml:surfaceMember xlink:href="#poly-cced3528-c4ad-489a-92b8-aea933ad3611"/>
							<gml:surfaceMember xlink:href="#poly-1e3c35f9-49ba-4f7c-850c-be35f7b94396"/>
							<gml:surfaceMember xlink:href="#poly-b2ebad0b-452d-417c-9df3-1455f7794dea"/>
							<gml:surfaceMember xlink:href="#poly-65850d61-1530-4b2e-a533-682469274a9a"/>
							<gml:surfaceMember xlink:href="#poly-ba413f40-f8d8-47ab-816a-30d89091886b"/>
							<gml:surfaceMember xlink:href="#poly-9cb03492-9656-4d4c-90b6-fe615f163e49"/>
							<gml:surfaceMember xlink:href="#poly-fb380d1a-51e2-4d47-b064-ef9e2b3d3b6c"/>
							<gml:surfaceMember xlink:href="#poly-cb2a25af-8333-47d5-b557-ccbc2ce8411c"/>
							<gml:surfaceMember xlink:href="#poly-734cba04-38b5-4335-8954-6222d2b13531"/>
							<gml:surfaceMember xlink:href="#poly-703305d1-e6e8-46d8-8461-3f7c111480b4"/>
							<gml:surfaceMember xlink:href="#poly-ce17d615-adcb-4456-8650-de73df2528f7"/>
							<gml:surfaceMember xlink:href="#poly-808297ac-bc5e-4049-8a29-bfb8b474e4e8"/>
							<gml:surfaceMember xlink:href="#poly-3fb218fe-8cb9-4791-a9e3-226102cc189e"/>
							<gml:surfaceMember xlink:href="#poly-05de1ab4-40b4-4fa8-9be0-b94c3f532f28"/>
							<gml:surfaceMember xlink:href="#poly-a4717c1f-3470-4594-8c94-51e82bd81150"/>
							<gml:surfaceMember xlink:href="#poly-91309473-cdbb-4901-b9cc-558e623222fe"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-97538e21-aff5-4c98-a933-000e36166254">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-97538e21-aff5-4c98-a933-000e36166254">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-97538e21-aff5-4c98-a933-000e36166254">
											<gml:posList>35.6686961772439 139.73981233664827 11.39 35.66872756816642 139.739842124321 11.39 35.66873733094243 139.73987812300552 11.39 35.668704471213054 139.73993018809895 11.39 35.66865269429288 139.73988109361767 11.39 35.6686961772439 139.73981233664827 11.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4ba6deb3-8e47-405e-bb30-389fa98c54c5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ba6deb3-8e47-405e-bb30-389fa98c54c5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ba6deb3-8e47-405e-bb30-389fa98c54c5">
											<gml:posList>35.66872254381658 139.7398373582939 23.854 35.6686961772439 139.73981233664827 23.854 35.66869641335941 139.7398146008085 23.854 35.66872127354174 139.73983821031948 23.854 35.66872254381658 139.7398373582939 23.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b6295954-580e-48f2-ba97-5084819c0852">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6295954-580e-48f2-ba97-5084819c0852">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6295954-580e-48f2-ba97-5084819c0852">
											<gml:posList>35.66865269429288 139.73988109361767 23.854 35.66865453286992 139.73988080427824 23.854 35.66869641335941 139.7398146008085 23.854 35.6686961772439 139.73981233664827 23.854 35.66865269429288 139.73988109361767 23.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fba08b4f-f47e-4fe0-97ca-e8f5c808e2e0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fba08b4f-f47e-4fe0-97ca-e8f5c808e2e0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fba08b4f-f47e-4fe0-97ca-e8f5c808e2e0">
											<gml:posList>35.66872254381658 139.7398373582939 23.854 35.66872127354174 139.73983821031948 23.854 35.66872398113559 139.7398775199874 23.854 35.66872534259385 139.739878015472 23.854 35.66872254381658 139.7398373582939 23.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0a209ce6-1ef0-4542-9024-c4f3268b31a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a209ce6-1ef0-4542-9024-c4f3268b31a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a209ce6-1ef0-4542-9024-c4f3268b31a0">
											<gml:posList>35.66873733094243 139.73987812300552 20.194 35.66872756816642 139.739842124321 20.194 35.66872254381658 139.7398373582939 20.194 35.66872534259385 139.739878015472 20.194 35.66871977877262 139.7398866047226 20.194 35.66872741000708 139.73989384202577 20.194 35.66873733094243 139.73987812300552 20.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8fc4adc9-ac49-4cb8-b8d7-8fc71f90675a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8fc4adc9-ac49-4cb8-b8d7-8fc71f90675a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8fc4adc9-ac49-4cb8-b8d7-8fc71f90675a">
											<gml:posList>35.66872398113559 139.7398775199874 23.546 35.66872127354174 139.73983821031948 23.546 35.66869641335941 139.7398146008085 23.546 35.66865453286992 139.73988080427824 23.546 35.66869625207493 139.7399203556629 23.546 35.66872398113559 139.7398775199874 23.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cced3528-c4ad-489a-92b8-aea933ad3611">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cced3528-c4ad-489a-92b8-aea933ad3611">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cced3528-c4ad-489a-92b8-aea933ad3611">
											<gml:posList>35.66872534259385 139.739878015472 23.854 35.66872398113559 139.7398775199874 23.854 35.66869625207493 139.7399203556629 23.854 35.66869647014382 139.73992259775238 23.854 35.66872534259385 139.739878015472 23.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1e3c35f9-49ba-4f7c-850c-be35f7b94396">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e3c35f9-49ba-4f7c-850c-be35f7b94396">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e3c35f9-49ba-4f7c-850c-be35f7b94396">
											<gml:posList>35.66869647014382 139.73992259775238 23.854 35.66869625207493 139.7399203556629 23.854 35.66865453286992 139.73988080427824 23.854 35.66865269429288 139.73988109361767 23.854 35.66869647014382 139.73992259775238 23.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b2ebad0b-452d-417c-9df3-1455f7794dea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b2ebad0b-452d-417c-9df3-1455f7794dea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b2ebad0b-452d-417c-9df3-1455f7794dea">
											<gml:posList>35.66871977877262 139.7398866047226 22.741 35.66869647014382 139.73992259775238 22.741 35.668704471213054 139.73993018809895 22.741 35.66872741000708 139.73989384202577 22.741 35.66871977877262 139.7398866047226 22.741</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-65850d61-1530-4b2e-a533-682469274a9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65850d61-1530-4b2e-a533-682469274a9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65850d61-1530-4b2e-a533-682469274a9a">
											<gml:posList>35.66872398113559 139.7398775199874 23.854 35.66872398113559 139.7398775199874 23.546 35.66869625207493 139.7399203556629 23.546 35.66869625207493 139.7399203556629 23.854 35.66872398113559 139.7398775199874 23.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ba413f40-f8d8-47ab-816a-30d89091886b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba413f40-f8d8-47ab-816a-30d89091886b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba413f40-f8d8-47ab-816a-30d89091886b">
											<gml:posList>35.66869641335941 139.7398146008085 23.854 35.66869641335941 139.7398146008085 23.546 35.66872127354174 139.73983821031948 23.546 35.66872127354174 139.73983821031948 23.854 35.66869641335941 139.7398146008085 23.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9cb03492-9656-4d4c-90b6-fe615f163e49">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9cb03492-9656-4d4c-90b6-fe615f163e49">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9cb03492-9656-4d4c-90b6-fe615f163e49">
											<gml:posList>35.6686961772439 139.73981233664827 11.39 35.6686961772439 139.73981233664827 23.854 35.66872254381658 139.7398373582939 23.854 35.66872254381658 139.7398373582939 20.194 35.66872756816642 139.739842124321 20.194 35.66872756816642 139.739842124321 11.39 35.6686961772439 139.73981233664827 11.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fb380d1a-51e2-4d47-b064-ef9e2b3d3b6c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb380d1a-51e2-4d47-b064-ef9e2b3d3b6c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb380d1a-51e2-4d47-b064-ef9e2b3d3b6c">
											<gml:posList>35.6686961772439 139.73981233664827 11.39 35.66865269429288 139.73988109361767 11.39 35.66865269429288 139.73988109361767 23.854 35.6686961772439 139.73981233664827 23.854 35.6686961772439 139.73981233664827 11.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cb2a25af-8333-47d5-b557-ccbc2ce8411c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb2a25af-8333-47d5-b557-ccbc2ce8411c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb2a25af-8333-47d5-b557-ccbc2ce8411c">
											<gml:posList>35.66865453286992 139.73988080427824 23.854 35.66865453286992 139.73988080427824 23.546 35.66869641335941 139.7398146008085 23.546 35.66869641335941 139.7398146008085 23.854 35.66865453286992 139.73988080427824 23.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-734cba04-38b5-4335-8954-6222d2b13531">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-734cba04-38b5-4335-8954-6222d2b13531">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-734cba04-38b5-4335-8954-6222d2b13531">
											<gml:posList>35.66872254381658 139.7398373582939 20.194 35.66872254381658 139.7398373582939 23.854 35.66872534259385 139.739878015472 23.854 35.66872534259385 139.739878015472 20.194 35.66872254381658 139.7398373582939 20.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-703305d1-e6e8-46d8-8461-3f7c111480b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-703305d1-e6e8-46d8-8461-3f7c111480b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-703305d1-e6e8-46d8-8461-3f7c111480b4">
											<gml:posList>35.66872127354174 139.73983821031948 23.854 35.66872127354174 139.73983821031948 23.546 35.66872398113559 139.7398775199874 23.546 35.66872398113559 139.7398775199874 23.854 35.66872127354174 139.73983821031948 23.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ce17d615-adcb-4456-8650-de73df2528f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce17d615-adcb-4456-8650-de73df2528f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce17d615-adcb-4456-8650-de73df2528f7">
											<gml:posList>35.66873733094243 139.73987812300552 11.39 35.66872756816642 139.739842124321 11.39 35.66872756816642 139.739842124321 20.194 35.66873733094243 139.73987812300552 20.194 35.66873733094243 139.73987812300552 11.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-808297ac-bc5e-4049-8a29-bfb8b474e4e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-808297ac-bc5e-4049-8a29-bfb8b474e4e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-808297ac-bc5e-4049-8a29-bfb8b474e4e8">
											<gml:posList>35.66871977877262 139.7398866047226 20.194 35.66871977877262 139.7398866047226 22.741 35.66872741000708 139.73989384202577 22.741 35.66872741000708 139.73989384202577 20.194 35.66871977877262 139.7398866047226 20.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3fb218fe-8cb9-4791-a9e3-226102cc189e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3fb218fe-8cb9-4791-a9e3-226102cc189e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3fb218fe-8cb9-4791-a9e3-226102cc189e">
											<gml:posList>35.66871977877262 139.7398866047226 22.741 35.66871977877262 139.7398866047226 20.194 35.66872534259385 139.739878015472 20.194 35.66872534259385 139.739878015472 23.854 35.66869647014382 139.73992259775238 23.854 35.66869647014382 139.73992259775238 22.741 35.66871977877262 139.7398866047226 22.741</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-05de1ab4-40b4-4fa8-9be0-b94c3f532f28">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-05de1ab4-40b4-4fa8-9be0-b94c3f532f28">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-05de1ab4-40b4-4fa8-9be0-b94c3f532f28">
											<gml:posList>35.66869625207493 139.7399203556629 23.854 35.66869625207493 139.7399203556629 23.546 35.66865453286992 139.73988080427824 23.546 35.66865453286992 139.73988080427824 23.854 35.66869625207493 139.7399203556629 23.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a4717c1f-3470-4594-8c94-51e82bd81150">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4717c1f-3470-4594-8c94-51e82bd81150">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4717c1f-3470-4594-8c94-51e82bd81150">
											<gml:posList>35.66872741000708 139.73989384202577 20.194 35.66872741000708 139.73989384202577 22.741 35.668704471213054 139.73993018809895 22.741 35.668704471213054 139.73993018809895 11.39 35.66873733094243 139.73987812300552 11.39 35.66873733094243 139.73987812300552 20.194 35.66872741000708 139.73989384202577 20.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-91309473-cdbb-4901-b9cc-558e623222fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-91309473-cdbb-4901-b9cc-558e623222fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-91309473-cdbb-4901-b9cc-558e623222fe">
											<gml:posList>35.66865269429288 139.73988109361767 23.854 35.66865269429288 139.73988109361767 11.39 35.668704471213054 139.73993018809895 11.39 35.668704471213054 139.73993018809895 22.741 35.66869647014382 139.73992259775238 22.741 35.66869647014382 139.73992259775238 23.854 35.66865269429288 139.73988109361767 23.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10116</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">54.42835</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>