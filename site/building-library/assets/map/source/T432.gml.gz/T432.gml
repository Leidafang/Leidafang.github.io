<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_7efe02f2-407b-494a-a853-2b79dea934dc">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">11.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67102380350453 139.73832874825214 0 35.67099068505782 139.7381664062491 0 35.670907778812165 139.73819180075694 0 35.67093425559341 139.7383217515685 0 35.67095085487597 139.73831667267496 0 35.670955741171944 139.73834060429976 0 35.670958003830236 139.7383522996918 0 35.67095558880642 139.73835313102816 0 35.670957127063815 139.73836064071617 0 35.671017143983 139.7383422326867 0 35.67102380350453 139.73832874825214 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67102380350453 139.73832874825214 17.715 35.671017143983 139.7383422326867 17.715 35.670957127063815 139.73836064071617 17.715 35.67095558880642 139.73835313102816 17.715 35.670958003830236 139.7383522996918 17.715 35.670955741171944 139.73834060429976 17.715 35.67095085487597 139.73831667267496 17.715 35.67093425559341 139.7383217515685 17.715 35.670907778812165 139.73819180075694 17.715 35.67099068505782 139.7381664062491 17.715 35.67102380350453 139.73832874825214 17.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67102380350453 139.73832874825214 17.715 35.67099068505782 139.7381664062491 17.715 35.67099068505782 139.7381664062491 29.21 35.67102380350453 139.73832874825214 29.21 35.67102380350453 139.73832874825214 17.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67099068505782 139.7381664062491 17.715 35.670907778812165 139.73819180075694 17.715 35.670907778812165 139.73819180075694 29.21 35.67099068505782 139.7381664062491 29.21 35.67099068505782 139.7381664062491 17.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670907778812165 139.73819180075694 17.715 35.67093425559341 139.7383217515685 17.715 35.67093425559341 139.7383217515685 29.21 35.670907778812165 139.73819180075694 29.21 35.670907778812165 139.73819180075694 17.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67093425559341 139.7383217515685 17.715 35.67095085487597 139.73831667267496 17.715 35.67095085487597 139.73831667267496 29.21 35.67093425559341 139.7383217515685 29.21 35.67093425559341 139.7383217515685 17.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67095085487597 139.73831667267496 17.715 35.670955741171944 139.73834060429976 17.715 35.670955741171944 139.73834060429976 29.21 35.67095085487597 139.73831667267496 29.21 35.67095085487597 139.73831667267496 17.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670955741171944 139.73834060429976 17.715 35.670958003830236 139.7383522996918 17.715 35.670958003830236 139.7383522996918 29.21 35.670955741171944 139.73834060429976 29.21 35.670955741171944 139.73834060429976 17.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670958003830236 139.7383522996918 17.715 35.67095558880642 139.73835313102816 17.715 35.67095558880642 139.73835313102816 29.21 35.670958003830236 139.7383522996918 29.21 35.670958003830236 139.7383522996918 17.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67095558880642 139.73835313102816 17.715 35.670957127063815 139.73836064071617 17.715 35.670957127063815 139.73836064071617 29.21 35.67095558880642 139.73835313102816 29.21 35.67095558880642 139.73835313102816 17.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670957127063815 139.73836064071617 17.715 35.671017143983 139.7383422326867 17.715 35.671017143983 139.7383422326867 29.21 35.670957127063815 139.73836064071617 29.21 35.670957127063815 139.73836064071617 17.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671017143983 139.7383422326867 17.715 35.67102380350453 139.73832874825214 17.715 35.67102380350453 139.73832874825214 29.21 35.671017143983 139.7383422326867 29.21 35.671017143983 139.7383422326867 17.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67102380350453 139.73832874825214 29.21 35.67099068505782 139.7381664062491 29.21 35.670907778812165 139.73819180075694 29.21 35.67093425559341 139.7383217515685 29.21 35.67095085487597 139.73831667267496 29.21 35.670955741171944 139.73834060429976 29.21 35.670958003830236 139.7383522996918 29.21 35.67095558880642 139.73835313102816 29.21 35.670957127063815 139.73836064071617 29.21 35.671017143983 139.7383422326867 29.21 35.67102380350453 139.73832874825214 29.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-245ae5e1-6231-4dca-a542-4f14dd622cf2"/>
							<gml:surfaceMember xlink:href="#poly-6887f60e-0b4f-4778-adbb-86a64cf3cd45"/>
							<gml:surfaceMember xlink:href="#poly-c2efaf20-dce9-417b-9edb-663fbc72dea4"/>
							<gml:surfaceMember xlink:href="#poly-7bf2033f-ee12-4be6-b0a3-4eb20467490f"/>
							<gml:surfaceMember xlink:href="#poly-fbac2f9f-a987-4b1a-96fd-0d6188adbb06"/>
							<gml:surfaceMember xlink:href="#poly-f602015f-ee61-4305-9eb9-78d2c650a4f8"/>
							<gml:surfaceMember xlink:href="#poly-7f9b42d7-55b0-4532-9bf0-86cf9f198cd0"/>
							<gml:surfaceMember xlink:href="#poly-30f896b9-6b4c-44e9-a0bc-b348c72185c1"/>
							<gml:surfaceMember xlink:href="#poly-13c7604a-a2e4-4bd7-9209-df331e22d1b0"/>
							<gml:surfaceMember xlink:href="#poly-b15acb27-b438-402a-97c7-ace07ec03279"/>
							<gml:surfaceMember xlink:href="#poly-71de3d94-3a15-45db-8a72-ef08d21228fa"/>
							<gml:surfaceMember xlink:href="#poly-d862de50-6a40-4c8f-8e90-c09727a9ffdc"/>
							<gml:surfaceMember xlink:href="#poly-aae40721-db48-4b32-969c-bc9ed74b7715"/>
							<gml:surfaceMember xlink:href="#poly-b8e4568a-63c9-402e-84bc-ca845d5788e3"/>
							<gml:surfaceMember xlink:href="#poly-1bc14eef-471d-472a-945a-f32f98ba5eb5"/>
							<gml:surfaceMember xlink:href="#poly-d16f96b2-37bd-4765-9d98-b17bb72fc9e7"/>
							<gml:surfaceMember xlink:href="#poly-c79011af-7b2d-4e7f-8344-c053d1cf2428"/>
							<gml:surfaceMember xlink:href="#poly-9bf12005-9706-4294-a46c-3bd8047730f0"/>
							<gml:surfaceMember xlink:href="#poly-6fa58d22-16b5-4fdb-a6a5-874c1009a04e"/>
							<gml:surfaceMember xlink:href="#poly-a8475515-4039-4118-b013-e17f8d110b68"/>
							<gml:surfaceMember xlink:href="#poly-fd66c887-2caa-4984-9a8e-847004ec93e8"/>
							<gml:surfaceMember xlink:href="#poly-4fa310f6-e25b-4be7-8ba7-255b8270d705"/>
							<gml:surfaceMember xlink:href="#poly-21dd378a-607f-4b92-a1f0-37307b051699"/>
							<gml:surfaceMember xlink:href="#poly-3b871717-f2ba-4840-8871-0176c28f6e2f"/>
							<gml:surfaceMember xlink:href="#poly-628ca0fa-57dd-4b0f-a6de-2c415de7eb60"/>
							<gml:surfaceMember xlink:href="#poly-0154f0f1-4da7-46ce-8102-a3fd22818715"/>
							<gml:surfaceMember xlink:href="#poly-3c6654b1-d8de-4be8-b338-fa95ea6d4389"/>
							<gml:surfaceMember xlink:href="#poly-f7390e2e-4636-4593-8d30-2477998a3176"/>
							<gml:surfaceMember xlink:href="#poly-7b05006c-d1c7-4429-b8ed-943b942f28c3"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_7efe02f2-407b-494a-a853-2b79dea934dc_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53abe4a6-7f5b-461c-a880-aad3e35cd913">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67092964666157 139.73826095800283 29.866 35.67092450692743 139.7382357121775 29.866 35.670955650845144 139.7382261753862 29.866 35.67096079959499 139.73825142121 29.866 35.67092964666157 139.73826095800283 29.866</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29abcc9b-3212-4c6b-8115-261bfbc2c59f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67098127235829 139.73830036536523 29.866 35.67098677394379 139.73832727878153 29.866 35.67095788296918 139.73833620531929 29.866 35.6709530057035 139.73831229577607 29.866 35.67095014002877 139.73831317183303 29.866 35.67094950664494 139.7383101017018 29.866 35.67098127235829 139.73830036536523 29.866</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fea5da8c-b6e5-490a-a05b-790d7fb0f69d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6709530057035 139.73831229577607 30.313 35.67095788296918 139.73833620531929 30.313 35.67098677394379 139.73832727878153 30.313 35.67098749787401 139.73833086798516 30.313 35.67095574117193 139.73834060429976 30.313 35.67095014002877 139.73831317183303 30.313 35.6709530057035 139.73831229577607 30.313</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99c6b36a-93a5-43ca-9733-60a345d18419">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67095600250884 139.73834052666575 26.166 35.67095616471226 139.73834047124188 26.139 35.67095574117193 139.73834060429976 26.139 35.67095600250884 139.73834052666575 26.166</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-051037f1-abdd-4173-86d5-e6187741efef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-051037f1-abdd-4173-86d5-e6187741efef_0">
											<gml:posList>35.670955650845144 139.7382261753862 29.866 35.67092450692743 139.7382357121775 29.866 35.67092450692743 139.7382357121775 32.981 35.670955650845144 139.7382261753862 32.981 35.670955650845144 139.7382261753862 29.866</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-31fa358d-3179-4c04-ad50-52bc61e1ed26">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-31fa358d-3179-4c04-ad50-52bc61e1ed26_0">
											<gml:posList>35.670955650845144 139.7382261753862 29.866 35.670955650845144 139.7382261753862 32.981 35.67096079959499 139.73825142121 32.981 35.67096079959499 139.73825142121 29.866 35.670955650845144 139.7382261753862 29.866</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dcd90354-dfd9-415e-88b4-618de29d853d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dcd90354-dfd9-415e-88b4-618de29d853d_0">
											<gml:posList>35.670955650845144 139.7382261753862 32.981 35.67092450692743 139.7382357121775 32.981 35.67092964666157 139.73826095800283 32.981 35.67096079959499 139.73825142121 32.981 35.670955650845144 139.7382261753862 32.981</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a31bc0ff-08ea-47ab-a0d7-8b41af29f277">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a31bc0ff-08ea-47ab-a0d7-8b41af29f277_0">
											<gml:posList>35.67092450692743 139.7382357121775 29.866 35.67092964666157 139.73826095800283 29.866 35.67092964666157 139.73826095800283 32.981 35.67092450692743 139.7382357121775 32.981 35.67092450692743 139.7382357121775 29.866</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-778b267b-447e-4072-a886-847a849e0028">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-778b267b-447e-4072-a886-847a849e0028_0">
											<gml:posList>35.67092964666157 139.73826095800283 29.866 35.67096079959499 139.73825142121 29.866 35.67096079959499 139.73825142121 32.981 35.67092964666157 139.73826095800283 32.981 35.67092964666157 139.73826095800283 29.866</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63d2a99d-afdf-4176-ae91-c61a9671bb36">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-63d2a99d-afdf-4176-ae91-c61a9671bb36_0">
											<gml:posList>35.67094950664494 139.7383101017018 29.866 35.67094950664494 139.7383101017018 34.004 35.67098127235829 139.73830036536523 34.004 35.67098127235829 139.73830036536523 29.866 35.67094950664494 139.7383101017018 29.866</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b7b1e953-ea43-4ae6-927f-01242851445f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b7b1e953-ea43-4ae6-927f-01242851445f_0">
											<gml:posList>35.6709530057035 139.73831229577607 30.313 35.67095014002877 139.73831317183303 30.313 35.67095014002877 139.73831317183303 29.866 35.6709530057035 139.73831229577607 29.866 35.6709530057035 139.73831229577607 30.313</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cacfa670-d59a-4a04-99aa-66557275eccc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cacfa670-d59a-4a04-99aa-66557275eccc_0">
											<gml:posList>35.67098127235829 139.73830036536523 29.866 35.67098127235829 139.73830036536523 34.004 35.67098749787401 139.73833086798516 34.004 35.67098749787401 139.73833086798516 30.313 35.67098677394379 139.73832727878153 30.313 35.67098677394379 139.73832727878153 29.866 35.67098127235829 139.73830036536523 29.866</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d3d5f63-362c-4fa9-a21a-0ca6c011057d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d3d5f63-362c-4fa9-a21a-0ca6c011057d_0">
											<gml:posList>35.67095574117193 139.73834060429976 34.004 35.67098749787401 139.73833086798516 34.004 35.67098127235829 139.73830036536523 34.004 35.67094950664494 139.7383101017018 34.004 35.67095574117193 139.73834060429976 34.004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cede3ab5-7381-4c28-ac3f-bc1bab914f07">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cede3ab5-7381-4c28-ac3f-bc1bab914f07_0">
											<gml:posList>35.6709530057035 139.73831229577607 29.866 35.67095788296918 139.73833620531929 29.866 35.67095788296918 139.73833620531929 30.313 35.6709530057035 139.73831229577607 30.313 35.6709530057035 139.73831229577607 29.866</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e029580a-bdcc-43ee-b90d-98a5e0b0066e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e029580a-bdcc-43ee-b90d-98a5e0b0066e_0">
											<gml:posList>35.67095014002877 139.73831317183303 30.313 35.67095574117193 139.73834060429976 30.313 35.67095574117193 139.73834060429976 34.004 35.67094950664494 139.7383101017018 34.004 35.67094950664494 139.7383101017018 29.866 35.67095014002877 139.73831317183303 29.866 35.67095014002877 139.73831317183303 30.313</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-baf442b5-7280-4359-aa78-48caa16f259c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-baf442b5-7280-4359-aa78-48caa16f259c_0">
											<gml:posList>35.67098677394379 139.73832727878153 29.866 35.67098677394379 139.73832727878153 30.313 35.67095788296918 139.73833620531929 30.313 35.67095788296918 139.73833620531929 29.866 35.67098677394379 139.73832727878153 29.866</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a26a76d-38dd-44e0-87a2-08678fbef171">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2a26a76d-38dd-44e0-87a2-08678fbef171_0">
											<gml:posList>35.67098749787401 139.73833086798516 30.313 35.67098749787401 139.73833086798516 34.004 35.67095574117193 139.73834060429976 34.004 35.67095574117193 139.73834060429976 30.313 35.67098749787401 139.73833086798516 30.313</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_7efe02f2-407b-494a-a853-2b79dea934dc_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35936d80-7361-43de-b5ae-465d2f0ba0df">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67094153079928 139.73835745575317 17.715 35.670934255593416 139.7383217515685 17.715 35.67095085487596 139.73831667267496 17.715 35.67095574117193 139.73834060429976 17.715 35.67095800383022 139.73835229969177 17.715 35.67095558880642 139.73835313102813 17.715 35.67094153079928 139.73835745575317 17.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5dff12b8-c58b-4e8c-8d27-36b3d99f0182">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5dff12b8-c58b-4e8c-8d27-36b3d99f0182_0">
											<gml:posList>35.670934255593416 139.7383217515685 30.313 35.670934255593416 139.7383217515685 17.715 35.67094153079928 139.73835745575317 17.715 35.67094153079928 139.73835745575317 30.313 35.670934255593416 139.7383217515685 30.313</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f854dba-04e3-4a4e-a81e-832d78eab5c8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f854dba-04e3-4a4e-a81e-832d78eab5c8_0">
											<gml:posList>35.67095085487596 139.73831667267496 30.313 35.67095085487596 139.73831667267496 17.715 35.670934255593416 139.7383217515685 17.715 35.670934255593416 139.7383217515685 30.313 35.67095085487596 139.73831667267496 30.313</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ceb2ba78-3a35-4829-b6c9-d6b8404b9c0a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ceb2ba78-3a35-4829-b6c9-d6b8404b9c0a_0">
											<gml:posList>35.67094153079928 139.73835745575317 30.313 35.67095558880642 139.73835313102813 30.313 35.67095800383022 139.73835229969177 30.313 35.67095574117193 139.73834060429976 30.313 35.67095085487596 139.73831667267496 30.313 35.670934255593416 139.7383217515685 30.313 35.67094153079928 139.73835745575317 30.313</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f9f2febd-61b4-4987-9a05-4ab42f2abcb9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f9f2febd-61b4-4987-9a05-4ab42f2abcb9_0">
											<gml:posList>35.67094153079928 139.73835745575317 30.313 35.67094153079928 139.73835745575317 17.715 35.67095558880642 139.73835313102813 17.715 35.67095558880642 139.73835313102813 30.313 35.67094153079928 139.73835745575317 30.313</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da8dd530-6001-4d24-868d-6f350960f3f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da8dd530-6001-4d24-868d-6f350960f3f0_0">
											<gml:posList>35.67095574117193 139.73834060429976 30.313 35.67095574117193 139.73834060429976 17.715 35.67095085487596 139.73831667267496 17.715 35.67095085487596 139.73831667267496 30.313 35.67095574117193 139.73834060429976 30.313</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c288cae5-7ff0-4dac-9a84-5025a7b7b762">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c288cae5-7ff0-4dac-9a84-5025a7b7b762_0">
											<gml:posList>35.67095558880642 139.73835313102813 30.313 35.67095558880642 139.73835313102813 17.715 35.67095800383022 139.73835229969177 17.715 35.67095800383022 139.73835229969177 30.313 35.67095558880642 139.73835313102813 30.313</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-997c9c79-3d43-49e4-8815-21cf74e8308d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-997c9c79-3d43-49e4-8815-21cf74e8308d_0">
											<gml:posList>35.67095800383022 139.73835229969177 30.313 35.67095800383022 139.73835229969177 17.715 35.67095574117193 139.73834060429976 17.715 35.67095574117193 139.73834060429976 30.313 35.67095800383022 139.73835229969177 30.313</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-245ae5e1-6231-4dca-a542-4f14dd622cf2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-245ae5e1-6231-4dca-a542-4f14dd622cf2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-245ae5e1-6231-4dca-a542-4f14dd622cf2">
											<gml:posList>35.67090777881216 139.73819180075694 17.715 35.670990685057795 139.7381664062491 17.715 35.67102380350453 139.73832874825214 17.715 35.67101714398301 139.7383422326867 17.715 35.67095712706381 139.73836064071617 17.715 35.67095558880642 139.73835313102813 17.715 35.67095800383022 139.73835229969177 17.715 35.67095574117193 139.73834060429976 17.715 35.67095085487596 139.73831667267496 17.715 35.670934255593416 139.7383217515685 17.715 35.67090777881216 139.73819180075694 17.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6887f60e-0b4f-4778-adbb-86a64cf3cd45">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6887f60e-0b4f-4778-adbb-86a64cf3cd45">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6887f60e-0b4f-4778-adbb-86a64cf3cd45">
											<gml:posList>35.670934255593416 139.7383217515685 30.313 35.67093640642115 139.73831737467066 30.313 35.67091881556148 139.7382310242364 30.313 35.67091521694916 139.7382283221534 30.313 35.670934255593416 139.7383217515685 30.313</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c2efaf20-dce9-417b-9edb-663fbc72dea4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c2efaf20-dce9-417b-9edb-663fbc72dea4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c2efaf20-dce9-417b-9edb-663fbc72dea4">
											<gml:posList>35.67095085487596 139.73831667267496 30.313 35.6709530057035 139.73831229577607 30.313 35.67093640642115 139.73831737467066 30.313 35.670934255593416 139.7383217515685 30.313 35.67095085487596 139.73831667267496 30.313</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7bf2033f-ee12-4be6-b0a3-4eb20467490f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7bf2033f-ee12-4be6-b0a3-4eb20467490f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7bf2033f-ee12-4be6-b0a3-4eb20467490f">
											<gml:posList>35.67091521694916 139.7382283221534 30.313 35.67091881556148 139.7382310242364 30.313 35.67097083125222 139.73821639241362 30.313 35.670972991142186 139.73821208177824 30.313 35.67091521694916 139.7382283221534 30.313</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fbac2f9f-a987-4b1a-96fd-0d6188adbb06">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fbac2f9f-a987-4b1a-96fd-0d6188adbb06">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fbac2f9f-a987-4b1a-96fd-0d6188adbb06">
											<gml:posList>35.670990685057795 139.7381664062491 26.139 35.67090777881216 139.73819180075694 26.139 35.67091521694916 139.7382283221534 26.139 35.67099841271494 139.73820428603776 26.139 35.670990685057795 139.7381664062491 26.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f602015f-ee61-4305-9eb9-78d2c650a4f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f602015f-ee61-4305-9eb9-78d2c650a4f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f602015f-ee61-4305-9eb9-78d2c650a4f8">
											<gml:posList>35.67095085487596 139.73831667267496 30.313 35.67095574117193 139.73834060429976 30.313 35.67095788296918 139.73833620531929 30.313 35.6709530057035 139.73831229577607 30.313 35.67095085487596 139.73831667267496 30.313</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7f9b42d7-55b0-4532-9bf0-86cf9f198cd0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f9b42d7-55b0-4532-9bf0-86cf9f198cd0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f9b42d7-55b0-4532-9bf0-86cf9f198cd0">
											<gml:posList>35.6709530057035 139.73831229577607 29.866 35.67095788296918 139.73833620531929 29.866 35.670992919811276 139.7383253825741 29.866 35.67097083125222 139.73821639241362 29.866 35.67091881556148 139.7382310242364 29.866 35.67093640642115 139.73831737467066 29.866 35.6709530057035 139.73831229577607 29.866</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-30f896b9-6b4c-44e9-a0bc-b348c72185c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-30f896b9-6b4c-44e9-a0bc-b348c72185c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-30f896b9-6b4c-44e9-a0bc-b348c72185c1">
											<gml:posList>35.67099648230549 139.73832800738245 30.313 35.670992919811276 139.7383253825741 30.313 35.67095788296918 139.73833620531929 30.313 35.67095574117193 139.73834060429976 30.313 35.67099648230549 139.73832800738245 30.313</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-13c7604a-a2e4-4bd7-9209-df331e22d1b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13c7604a-a2e4-4bd7-9209-df331e22d1b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13c7604a-a2e4-4bd7-9209-df331e22d1b0">
											<gml:posList>35.670972991142186 139.73821208177824 30.313 35.67097083125222 139.73821639241362 30.313 35.670992919811276 139.7383253825741 30.313 35.67099648230549 139.73832800738245 30.313 35.670972991142186 139.73821208177824 30.313</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b15acb27-b438-402a-97c7-ace07ec03279">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b15acb27-b438-402a-97c7-ace07ec03279">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b15acb27-b438-402a-97c7-ace07ec03279">
											<gml:posList>35.67095800383022 139.73835229969177 26.139 35.67095558880642 139.73835313102813 26.139 35.67095712706381 139.73836064071617 26.139 35.67101714398301 139.7383422326867 26.139 35.67102380350453 139.73832874825214 26.139 35.67102204807038 139.73832016732013 26.139 35.67095574117193 139.73834060429976 26.139 35.67095800383022 139.73835229969177 26.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-71de3d94-3a15-45db-8a72-ef08d21228fa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-71de3d94-3a15-45db-8a72-ef08d21228fa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-71de3d94-3a15-45db-8a72-ef08d21228fa">
											<gml:posList>35.67099841271494 139.73820428603776 26.139 35.670972991142186 139.73821208177824 30.313 35.67099648230549 139.73832800738245 30.313 35.67102204807038 139.73832016732013 26.139 35.67099841271494 139.73820428603776 26.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d862de50-6a40-4c8f-8e90-c09727a9ffdc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d862de50-6a40-4c8f-8e90-c09727a9ffdc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d862de50-6a40-4c8f-8e90-c09727a9ffdc">
											<gml:posList>35.670934255593416 139.7383217515685 17.715 35.670934255593416 139.7383217515685 30.313 35.67091521694916 139.7382283221534 30.313 35.67091521694916 139.7382283221534 26.139 35.67090777881216 139.73819180075694 26.139 35.67090777881216 139.73819180075694 17.715 35.670934255593416 139.7383217515685 17.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aae40721-db48-4b32-969c-bc9ed74b7715">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aae40721-db48-4b32-969c-bc9ed74b7715">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aae40721-db48-4b32-969c-bc9ed74b7715">
											<gml:posList>35.67093640642115 139.73831737467066 30.313 35.67093640642115 139.73831737467066 29.866 35.67091881556148 139.7382310242364 29.866 35.67091881556148 139.7382310242364 30.313 35.67093640642115 139.73831737467066 30.313</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b8e4568a-63c9-402e-84bc-ca845d5788e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8e4568a-63c9-402e-84bc-ca845d5788e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8e4568a-63c9-402e-84bc-ca845d5788e3">
											<gml:posList>35.670934255593416 139.7383217515685 17.715 35.67095085487596 139.73831667267496 17.715 35.67095085487596 139.73831667267496 30.313 35.670934255593416 139.7383217515685 30.313 35.670934255593416 139.7383217515685 17.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1bc14eef-471d-472a-945a-f32f98ba5eb5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1bc14eef-471d-472a-945a-f32f98ba5eb5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1bc14eef-471d-472a-945a-f32f98ba5eb5">
											<gml:posList>35.6709530057035 139.73831229577607 30.313 35.6709530057035 139.73831229577607 29.866 35.67093640642115 139.73831737467066 29.866 35.67093640642115 139.73831737467066 30.313 35.6709530057035 139.73831229577607 30.313</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d16f96b2-37bd-4765-9d98-b17bb72fc9e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d16f96b2-37bd-4765-9d98-b17bb72fc9e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d16f96b2-37bd-4765-9d98-b17bb72fc9e7">
											<gml:posList>35.67091881556148 139.7382310242364 30.313 35.67091881556148 139.7382310242364 29.866 35.67097083125222 139.73821639241362 29.866 35.67097083125222 139.73821639241362 30.313 35.67091881556148 139.7382310242364 30.313</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c79011af-7b2d-4e7f-8344-c053d1cf2428">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c79011af-7b2d-4e7f-8344-c053d1cf2428">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c79011af-7b2d-4e7f-8344-c053d1cf2428">
											<gml:posList>35.670990685057795 139.7381664062491 17.715 35.67090777881216 139.73819180075694 17.715 35.67090777881216 139.73819180075694 26.139 35.670990685057795 139.7381664062491 26.139 35.670990685057795 139.7381664062491 17.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9bf12005-9706-4294-a46c-3bd8047730f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9bf12005-9706-4294-a46c-3bd8047730f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9bf12005-9706-4294-a46c-3bd8047730f0">
											<gml:posList>35.67095085487596 139.73831667267496 30.313 35.67095085487596 139.73831667267496 17.715 35.67095574117193 139.73834060429976 17.715 35.67095574117193 139.73834060429976 26.139 35.67095574117193 139.73834060429976 30.313 35.67095085487596 139.73831667267496 30.313</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6fa58d22-16b5-4fdb-a6a5-874c1009a04e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6fa58d22-16b5-4fdb-a6a5-874c1009a04e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6fa58d22-16b5-4fdb-a6a5-874c1009a04e">
											<gml:posList>35.67095788296918 139.73833620531929 30.313 35.67095788296918 139.73833620531929 29.866 35.6709530057035 139.73831229577607 29.866 35.6709530057035 139.73831229577607 30.313 35.67095788296918 139.73833620531929 30.313</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a8475515-4039-4118-b013-e17f8d110b68">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a8475515-4039-4118-b013-e17f8d110b68">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a8475515-4039-4118-b013-e17f8d110b68">
											<gml:posList>35.67095558880642 139.73835313102813 17.715 35.67095712706381 139.73836064071617 17.715 35.67095712706381 139.73836064071617 26.139 35.67095558880642 139.73835313102813 26.139 35.67095558880642 139.73835313102813 17.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fd66c887-2caa-4984-9a8e-847004ec93e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fd66c887-2caa-4984-9a8e-847004ec93e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fd66c887-2caa-4984-9a8e-847004ec93e8">
											<gml:posList>35.67095800383022 139.73835229969177 17.715 35.67095558880642 139.73835313102813 17.715 35.67095558880642 139.73835313102813 26.139 35.67095800383022 139.73835229969177 26.139 35.67095800383022 139.73835229969177 17.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4fa310f6-e25b-4be7-8ba7-255b8270d705">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4fa310f6-e25b-4be7-8ba7-255b8270d705">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4fa310f6-e25b-4be7-8ba7-255b8270d705">
											<gml:posList>35.67095574117193 139.73834060429976 17.715 35.67095800383022 139.73835229969177 17.715 35.67095800383022 139.73835229969177 26.139 35.67095574117193 139.73834060429976 26.139 35.67095574117193 139.73834060429976 17.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-21dd378a-607f-4b92-a1f0-37307b051699">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21dd378a-607f-4b92-a1f0-37307b051699">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21dd378a-607f-4b92-a1f0-37307b051699">
											<gml:posList>35.67091521694916 139.7382283221534 26.139 35.67091521694916 139.7382283221534 30.313 35.670972991142186 139.73821208177824 30.313 35.67099841271494 139.73820428603776 26.139 35.67091521694916 139.7382283221534 26.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3b871717-f2ba-4840-8871-0176c28f6e2f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3b871717-f2ba-4840-8871-0176c28f6e2f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3b871717-f2ba-4840-8871-0176c28f6e2f">
											<gml:posList>35.670992919811276 139.7383253825741 30.313 35.670992919811276 139.7383253825741 29.866 35.67095788296918 139.73833620531929 29.866 35.67095788296918 139.73833620531929 30.313 35.670992919811276 139.7383253825741 30.313</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-628ca0fa-57dd-4b0f-a6de-2c415de7eb60">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-628ca0fa-57dd-4b0f-a6de-2c415de7eb60">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-628ca0fa-57dd-4b0f-a6de-2c415de7eb60">
											<gml:posList>35.67097083125222 139.73821639241362 30.313 35.67097083125222 139.73821639241362 29.866 35.670992919811276 139.7383253825741 29.866 35.670992919811276 139.7383253825741 30.313 35.67097083125222 139.73821639241362 30.313</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0154f0f1-4da7-46ce-8102-a3fd22818715">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0154f0f1-4da7-46ce-8102-a3fd22818715">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0154f0f1-4da7-46ce-8102-a3fd22818715">
											<gml:posList>35.67095712706381 139.73836064071617 17.715 35.67101714398301 139.7383422326867 17.715 35.67101714398301 139.7383422326867 26.139 35.67095712706381 139.73836064071617 26.139 35.67095712706381 139.73836064071617 17.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3c6654b1-d8de-4be8-b338-fa95ea6d4389">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c6654b1-d8de-4be8-b338-fa95ea6d4389">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c6654b1-d8de-4be8-b338-fa95ea6d4389">
											<gml:posList>35.67095574117193 139.73834060429976 26.139 35.67102204807038 139.73832016732013 26.139 35.67099648230549 139.73832800738245 30.313 35.67095574117193 139.73834060429976 30.313 35.67095574117193 139.73834060429976 26.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f7390e2e-4636-4593-8d30-2477998a3176">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f7390e2e-4636-4593-8d30-2477998a3176">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f7390e2e-4636-4593-8d30-2477998a3176">
											<gml:posList>35.67102380350453 139.73832874825214 17.715 35.670990685057795 139.7381664062491 17.715 35.670990685057795 139.7381664062491 26.139 35.67099841271494 139.73820428603776 26.139 35.67102204807038 139.73832016732013 26.139 35.67102380350453 139.73832874825214 26.139 35.67102380350453 139.73832874825214 17.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7b05006c-d1c7-4429-b8ed-943b942f28c3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b05006c-d1c7-4429-b8ed-943b942f28c3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b05006c-d1c7-4429-b8ed-943b942f28c3">
											<gml:posList>35.67101714398301 139.7383422326867 17.715 35.67102380350453 139.73832874825214 17.715 35.67102380350453 139.73832874825214 26.139 35.67101714398301 139.7383422326867 26.139 35.67101714398301 139.7383422326867 17.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8105</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">151.5651</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.04</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>