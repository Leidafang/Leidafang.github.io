<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_7f36d8bc-3524-401b-a55d-945ddf487bbb">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>46</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13101046002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">38.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.671492669751615 139.74309692904058 0 35.67158127288642 139.74308246896445 0 35.67166860523246 139.74306820912278 0 35.671759803998114 139.74305332629487 0 35.67176233616479 139.74289625396918 0 35.67176281827128 139.74286608556991 0 35.671762002471546 139.7428600109429 0 35.671672116825135 139.7427151831137 0 35.67164687599448 139.74271200817677 0 35.67162174869494 139.74275190314688 0 35.671496616151664 139.7429505596198 0 35.671459186860766 139.74304096143527 0 35.671492669751615 139.74309692904058 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671492669751615 139.74309692904058 7.95 35.671459186860766 139.74304096143527 7.95 35.671496616151664 139.7429505596198 7.95 35.67162174869494 139.74275190314688 7.95 35.67164687599448 139.74271200817677 7.95 35.671672116825135 139.7427151831137 7.95 35.671762002471546 139.7428600109429 7.95 35.67176281827128 139.74286608556991 7.95 35.67176233616479 139.74289625396918 7.95 35.671759803998114 139.74305332629487 7.95 35.67166860523246 139.74306820912278 7.95 35.67158127288642 139.74308246896445 7.95 35.671492669751615 139.74309692904058 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671492669751615 139.74309692904058 7.95 35.67158127288642 139.74308246896445 7.95 35.67158127288642 139.74308246896445 39.6 35.671492669751615 139.74309692904058 39.6 35.671492669751615 139.74309692904058 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67158127288642 139.74308246896445 7.95 35.67166860523246 139.74306820912278 7.95 35.67166860523246 139.74306820912278 39.6 35.67158127288642 139.74308246896445 39.6 35.67158127288642 139.74308246896445 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67166860523246 139.74306820912278 7.95 35.671759803998114 139.74305332629487 7.95 35.671759803998114 139.74305332629487 39.6 35.67166860523246 139.74306820912278 39.6 35.67166860523246 139.74306820912278 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671759803998114 139.74305332629487 7.95 35.67176233616479 139.74289625396918 7.95 35.67176233616479 139.74289625396918 39.6 35.671759803998114 139.74305332629487 39.6 35.671759803998114 139.74305332629487 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67176233616479 139.74289625396918 7.95 35.67176281827128 139.74286608556991 7.95 35.67176281827128 139.74286608556991 39.6 35.67176233616479 139.74289625396918 39.6 35.67176233616479 139.74289625396918 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67176281827128 139.74286608556991 7.95 35.671762002471546 139.7428600109429 7.95 35.671762002471546 139.7428600109429 39.6 35.67176281827128 139.74286608556991 39.6 35.67176281827128 139.74286608556991 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671762002471546 139.7428600109429 7.95 35.671672116825135 139.7427151831137 7.95 35.671672116825135 139.7427151831137 39.6 35.671762002471546 139.7428600109429 39.6 35.671762002471546 139.7428600109429 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671672116825135 139.7427151831137 7.95 35.67164687599448 139.74271200817677 7.95 35.67164687599448 139.74271200817677 39.6 35.671672116825135 139.7427151831137 39.6 35.671672116825135 139.7427151831137 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67164687599448 139.74271200817677 7.95 35.67162174869494 139.74275190314688 7.95 35.67162174869494 139.74275190314688 39.6 35.67164687599448 139.74271200817677 39.6 35.67164687599448 139.74271200817677 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67162174869494 139.74275190314688 7.95 35.671496616151664 139.7429505596198 7.95 35.671496616151664 139.7429505596198 39.6 35.67162174869494 139.74275190314688 39.6 35.67162174869494 139.74275190314688 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671496616151664 139.7429505596198 7.95 35.671459186860766 139.74304096143527 7.95 35.671459186860766 139.74304096143527 39.6 35.671496616151664 139.7429505596198 39.6 35.671496616151664 139.7429505596198 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671459186860766 139.74304096143527 7.95 35.671492669751615 139.74309692904058 7.95 35.671492669751615 139.74309692904058 39.6 35.671459186860766 139.74304096143527 39.6 35.671459186860766 139.74304096143527 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671492669751615 139.74309692904058 39.6 35.67158127288642 139.74308246896445 39.6 35.67166860523246 139.74306820912278 39.6 35.671759803998114 139.74305332629487 39.6 35.67176233616479 139.74289625396918 39.6 35.67176281827128 139.74286608556991 39.6 35.671762002471546 139.7428600109429 39.6 35.671672116825135 139.7427151831137 39.6 35.67164687599448 139.74271200817677 39.6 35.67162174869494 139.74275190314688 39.6 35.671496616151664 139.7429505596198 39.6 35.671459186860766 139.74304096143527 39.6 35.671492669751615 139.74309692904058 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-4306c8a0-da62-4f81-a78e-fe6b3a5fdb03"/>
							<gml:surfaceMember xlink:href="#poly-b95f3943-82da-4d44-a38b-2cc5675343ee"/>
							<gml:surfaceMember xlink:href="#poly-0a3b7a56-c902-41d7-8547-a9ae801ce0e8"/>
							<gml:surfaceMember xlink:href="#poly-9ab1a108-555e-4b4c-a5ea-33abcf7ec371"/>
							<gml:surfaceMember xlink:href="#poly-13da367b-4aa8-4a4a-a2cf-beed607500ae"/>
							<gml:surfaceMember xlink:href="#poly-00aaa92a-bd25-47b4-8e71-a64ea2b10313"/>
							<gml:surfaceMember xlink:href="#poly-44774fe9-1128-4f8d-b75f-8338d71fa70d"/>
							<gml:surfaceMember xlink:href="#poly-5eb8ce4c-7639-4aa1-8e34-12447c64d09e"/>
							<gml:surfaceMember xlink:href="#poly-2ce16b53-728b-4385-94b5-b69fa81f4328"/>
							<gml:surfaceMember xlink:href="#poly-9ee8ad5e-6271-48db-ad6b-4bad231d5517"/>
							<gml:surfaceMember xlink:href="#poly-c51bce8f-5aee-43ea-9d54-4a65afd6c59f"/>
							<gml:surfaceMember xlink:href="#poly-f7fb6b31-2b74-4640-a0db-d4e4e8b0f658"/>
							<gml:surfaceMember xlink:href="#poly-32210ce0-fe87-4e23-96f7-792a8d5818ba"/>
							<gml:surfaceMember xlink:href="#poly-b48eaf8a-7ae0-47ca-804b-8fff25a1abb5"/>
							<gml:surfaceMember xlink:href="#poly-c2cfaee7-9dc0-4144-b4c6-da34de72b49a"/>
							<gml:surfaceMember xlink:href="#poly-0fef74a4-5726-44d2-a058-cf5321215b24"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-4306c8a0-da62-4f81-a78e-fe6b3a5fdb03">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4306c8a0-da62-4f81-a78e-fe6b3a5fdb03">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4306c8a0-da62-4f81-a78e-fe6b3a5fdb03">
											<gml:posList>35.671646875994476 139.74271200817674 7.95 35.671672116825114 139.74271518311366 7.95 35.67176200247154 139.7428600109429 7.95 35.67176281827128 139.7428660855699 7.95 35.6717598039981 139.74305332629484 7.95 35.67149266975163 139.74309692904058 7.95 35.671459186860766 139.74304096143524 7.95 35.671496616151664 139.7429505596198 7.95 35.671646875994476 139.74271200817674 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b95f3943-82da-4d44-a38b-2cc5675343ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b95f3943-82da-4d44-a38b-2cc5675343ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b95f3943-82da-4d44-a38b-2cc5675343ee">
											<gml:posList>35.67162174869493 139.74275190314688 16.82 35.671762336164775 139.74289625396915 16.82 35.67176281827128 139.7428660855699 16.82 35.67176200247154 139.7428600109429 16.82 35.671672116825114 139.74271518311366 16.82 35.671646875994476 139.74271200817674 16.82 35.67162174869493 139.74275190314688 16.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0a3b7a56-c902-41d7-8547-a9ae801ce0e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a3b7a56-c902-41d7-8547-a9ae801ce0e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a3b7a56-c902-41d7-8547-a9ae801ce0e8">
											<gml:posList>35.67166860523245 139.74306820912278 39.8 35.6717598039981 139.74305332629484 39.8 35.671762336164775 139.74289625396915 39.8 35.67162174869493 139.74275190314688 39.8 35.671496616151664 139.7429505596198 39.8 35.671459186860766 139.74304096143524 39.8 35.67149266975163 139.74309692904058 39.8 35.67158127288641 139.74308246896445 39.8 35.67157078968611 139.74298600130032 39.8 35.671658122020716 139.7429717413555 39.8 35.67166860523245 139.74306820912278 39.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9ab1a108-555e-4b4c-a5ea-33abcf7ec371">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ab1a108-555e-4b4c-a5ea-33abcf7ec371">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ab1a108-555e-4b4c-a5ea-33abcf7ec371">
											<gml:posList>35.67166860523245 139.74306820912278 46.133 35.671658122020716 139.7429717413555 46.133 35.67157078968611 139.74298600130032 46.133 35.67158127288641 139.74308246896445 46.133 35.67166860523245 139.74306820912278 46.133</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-13da367b-4aa8-4a4a-a2cf-beed607500ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13da367b-4aa8-4a4a-a2cf-beed607500ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13da367b-4aa8-4a4a-a2cf-beed607500ae">
											<gml:posList>35.671672116825114 139.74271518311366 7.95 35.671646875994476 139.74271200817674 7.95 35.671646875994476 139.74271200817674 16.82 35.671672116825114 139.74271518311366 16.82 35.671672116825114 139.74271518311366 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-00aaa92a-bd25-47b4-8e71-a64ea2b10313">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-00aaa92a-bd25-47b4-8e71-a64ea2b10313">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-00aaa92a-bd25-47b4-8e71-a64ea2b10313">
											<gml:posList>35.67176200247154 139.7428600109429 7.95 35.671672116825114 139.74271518311366 7.95 35.671672116825114 139.74271518311366 16.82 35.67176200247154 139.7428600109429 16.82 35.67176200247154 139.7428600109429 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-44774fe9-1128-4f8d-b75f-8338d71fa70d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44774fe9-1128-4f8d-b75f-8338d71fa70d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44774fe9-1128-4f8d-b75f-8338d71fa70d">
											<gml:posList>35.67162174869493 139.74275190314688 16.82 35.67162174869493 139.74275190314688 39.8 35.671762336164775 139.74289625396915 39.8 35.671762336164775 139.74289625396915 16.82 35.67162174869493 139.74275190314688 16.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5eb8ce4c-7639-4aa1-8e34-12447c64d09e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5eb8ce4c-7639-4aa1-8e34-12447c64d09e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5eb8ce4c-7639-4aa1-8e34-12447c64d09e">
											<gml:posList>35.671496616151664 139.7429505596198 39.8 35.67162174869493 139.74275190314688 39.8 35.67162174869493 139.74275190314688 16.82 35.671646875994476 139.74271200817674 16.82 35.671646875994476 139.74271200817674 7.95 35.671496616151664 139.7429505596198 7.95 35.671496616151664 139.7429505596198 39.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2ce16b53-728b-4385-94b5-b69fa81f4328">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2ce16b53-728b-4385-94b5-b69fa81f4328">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2ce16b53-728b-4385-94b5-b69fa81f4328">
											<gml:posList>35.67176281827128 139.7428660855699 7.95 35.67176200247154 139.7428600109429 7.95 35.67176200247154 139.7428600109429 16.82 35.67176281827128 139.7428660855699 16.82 35.67176281827128 139.7428660855699 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9ee8ad5e-6271-48db-ad6b-4bad231d5517">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ee8ad5e-6271-48db-ad6b-4bad231d5517">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ee8ad5e-6271-48db-ad6b-4bad231d5517">
											<gml:posList>35.671762336164775 139.74289625396915 39.8 35.6717598039981 139.74305332629484 39.8 35.6717598039981 139.74305332629484 7.95 35.67176281827128 139.7428660855699 7.95 35.67176281827128 139.7428660855699 16.82 35.671762336164775 139.74289625396915 16.82 35.671762336164775 139.74289625396915 39.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c51bce8f-5aee-43ea-9d54-4a65afd6c59f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c51bce8f-5aee-43ea-9d54-4a65afd6c59f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c51bce8f-5aee-43ea-9d54-4a65afd6c59f">
											<gml:posList>35.67157078968611 139.74298600130032 39.8 35.67157078968611 139.74298600130032 46.133 35.671658122020716 139.7429717413555 46.133 35.671658122020716 139.7429717413555 39.8 35.67157078968611 139.74298600130032 39.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f7fb6b31-2b74-4640-a0db-d4e4e8b0f658">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f7fb6b31-2b74-4640-a0db-d4e4e8b0f658">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f7fb6b31-2b74-4640-a0db-d4e4e8b0f658">
											<gml:posList>35.671496616151664 139.7429505596198 7.95 35.671459186860766 139.74304096143524 7.95 35.671459186860766 139.74304096143524 39.8 35.671496616151664 139.7429505596198 39.8 35.671496616151664 139.7429505596198 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-32210ce0-fe87-4e23-96f7-792a8d5818ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-32210ce0-fe87-4e23-96f7-792a8d5818ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-32210ce0-fe87-4e23-96f7-792a8d5818ba">
											<gml:posList>35.671658122020716 139.7429717413555 39.8 35.671658122020716 139.7429717413555 46.133 35.67166860523245 139.74306820912278 46.133 35.67166860523245 139.74306820912278 39.8 35.671658122020716 139.7429717413555 39.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b48eaf8a-7ae0-47ca-804b-8fff25a1abb5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b48eaf8a-7ae0-47ca-804b-8fff25a1abb5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b48eaf8a-7ae0-47ca-804b-8fff25a1abb5">
											<gml:posList>35.67158127288641 139.74308246896445 39.8 35.67158127288641 139.74308246896445 46.133 35.67157078968611 139.74298600130032 46.133 35.67157078968611 139.74298600130032 39.8 35.67158127288641 139.74308246896445 39.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c2cfaee7-9dc0-4144-b4c6-da34de72b49a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c2cfaee7-9dc0-4144-b4c6-da34de72b49a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c2cfaee7-9dc0-4144-b4c6-da34de72b49a">
											<gml:posList>35.671459186860766 139.74304096143524 7.95 35.67149266975163 139.74309692904058 7.95 35.67149266975163 139.74309692904058 39.8 35.671459186860766 139.74304096143524 39.8 35.671459186860766 139.74304096143524 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0fef74a4-5726-44d2-a058-cf5321215b24">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0fef74a4-5726-44d2-a058-cf5321215b24">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0fef74a4-5726-44d2-a058-cf5321215b24">
											<gml:posList>35.6717598039981 139.74305332629484 7.95 35.6717598039981 139.74305332629484 39.8 35.67166860523245 139.74306820912278 39.8 35.67166860523245 139.74306820912278 46.133 35.67158127288641 139.74308246896445 46.133 35.67158127288641 139.74308246896445 39.8 35.67149266975163 139.74309692904058 39.8 35.67149266975163 139.74309692904058 7.95 35.6717598039981 139.74305332629484 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都千代田区永田町二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4481</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">745.19755</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.14</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>