<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_7f7162da-6f5d-4f4a-9860-3d0ddbe75b9b">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">16.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67171070438723 139.73874173402936 0 35.67168586973265 139.7385674505203 0 35.67162575830232 139.73858033543218 0 35.67162992738468 139.73860927215537 0 35.67160000687305 139.7386157144338 0 35.67162085538283 139.73876448521804 0 35.67171070438723 139.73874173402936 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67171070438723 139.73874173402936 13.142 35.67162085538283 139.73876448521804 13.142 35.67160000687305 139.7386157144338 13.142 35.67162992738468 139.73860927215537 13.142 35.67162575830232 139.73858033543218 13.142 35.67168586973265 139.7385674505203 13.142 35.67171070438723 139.73874173402936 13.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67171070438723 139.73874173402936 13.142 35.67168586973265 139.7385674505203 13.142 35.67168586973265 139.7385674505203 29.66 35.67171070438723 139.73874173402936 29.66 35.67171070438723 139.73874173402936 13.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67168586973265 139.7385674505203 13.142 35.67162575830232 139.73858033543218 13.142 35.67162575830232 139.73858033543218 29.66 35.67168586973265 139.7385674505203 29.66 35.67168586973265 139.7385674505203 13.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67162575830232 139.73858033543218 13.142 35.67162992738468 139.73860927215537 13.142 35.67162992738468 139.73860927215537 29.66 35.67162575830232 139.73858033543218 29.66 35.67162575830232 139.73858033543218 13.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67162992738468 139.73860927215537 13.142 35.67160000687305 139.7386157144338 13.142 35.67160000687305 139.7386157144338 29.66 35.67162992738468 139.73860927215537 29.66 35.67162992738468 139.73860927215537 13.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67160000687305 139.7386157144338 13.142 35.67162085538283 139.73876448521804 13.142 35.67162085538283 139.73876448521804 29.66 35.67160000687305 139.7386157144338 29.66 35.67160000687305 139.7386157144338 13.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67162085538283 139.73876448521804 13.142 35.67171070438723 139.73874173402936 13.142 35.67171070438723 139.73874173402936 29.66 35.67162085538283 139.73876448521804 29.66 35.67162085538283 139.73876448521804 13.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67171070438723 139.73874173402936 29.66 35.67168586973265 139.7385674505203 29.66 35.67162575830232 139.73858033543218 29.66 35.67162992738468 139.73860927215537 29.66 35.67160000687305 139.7386157144338 29.66 35.67162085538283 139.73876448521804 29.66 35.67171070438723 139.73874173402936 29.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-02fddc15-dbcd-445f-a869-c480a13f58e2"/>
							<gml:surfaceMember xlink:href="#poly-6bac3eaf-bb63-4631-9daf-1a56e6d530ce"/>
							<gml:surfaceMember xlink:href="#poly-cc86b34c-c442-434e-9226-70f9cb4100b9"/>
							<gml:surfaceMember xlink:href="#poly-bc0b1b66-a95c-4fe3-a9f2-1a6c60407c37"/>
							<gml:surfaceMember xlink:href="#poly-4f66258e-1069-47f8-9ff2-54b14f55d04d"/>
							<gml:surfaceMember xlink:href="#poly-98714683-9e33-4b10-9d53-297941ed8005"/>
							<gml:surfaceMember xlink:href="#poly-fa3c522e-93ed-4175-862c-36229451aa6c"/>
							<gml:surfaceMember xlink:href="#poly-0b1cee11-bc3e-4872-897f-75030481fad3"/>
							<gml:surfaceMember xlink:href="#poly-63037e34-9db6-46dd-bb07-5d987523b389"/>
							<gml:surfaceMember xlink:href="#poly-f0fdb780-f7da-4d0a-8c12-4eb9ec4ab18c"/>
							<gml:surfaceMember xlink:href="#poly-f9ad55e0-b3fb-4a30-8adc-7667aa3303c7"/>
							<gml:surfaceMember xlink:href="#poly-65184f4d-d74c-403d-96cf-6e956cde8f11"/>
							<gml:surfaceMember xlink:href="#poly-68259017-2c67-4b1f-a2ef-8c767fb6f744"/>
							<gml:surfaceMember xlink:href="#poly-5a4aa9ef-6f54-40cc-8a2e-c5e33fe9649a"/>
							<gml:surfaceMember xlink:href="#poly-2eea53ed-bc72-4598-9c7d-1468f0ae2b2e"/>
							<gml:surfaceMember xlink:href="#poly-9fc49fc4-3f36-4010-ab28-a94fc5f05e9b"/>
							<gml:surfaceMember xlink:href="#poly-d6c73a20-0efa-4c46-bf3a-cf6b50905276"/>
							<gml:surfaceMember xlink:href="#poly-f1337254-9ce1-4579-ac4b-38857f86bf59"/>
							<gml:surfaceMember xlink:href="#poly-341e7d0e-943e-484d-9803-3c14bb2b8368"/>
							<gml:surfaceMember xlink:href="#poly-a764f72f-1d9d-4070-8265-8aa36bc4517e"/>
							<gml:surfaceMember xlink:href="#poly-737cd167-ca0f-45d9-a154-31dd911c8568"/>
							<gml:surfaceMember xlink:href="#poly-2a7ce118-3586-4287-a6bb-2afeddc5e920"/>
							<gml:surfaceMember xlink:href="#poly-d3432473-da08-40ee-b1ce-fae82c0f3a5a"/>
							<gml:surfaceMember xlink:href="#poly-732a42d5-43a2-474c-a0cf-de66e81b9b44"/>
							<gml:surfaceMember xlink:href="#poly-6d2c8ee3-c1b4-47fb-89ab-cbe27d2db326"/>
							<gml:surfaceMember xlink:href="#poly-d7f86596-18a9-429d-a03c-06b803668a4f"/>
							<gml:surfaceMember xlink:href="#poly-2adadf8f-1230-46e3-aabd-505e4c324f83"/>
							<gml:surfaceMember xlink:href="#poly-f12b712e-0fa2-431b-93fe-6f5f165923cc"/>
							<gml:surfaceMember xlink:href="#poly-77b25497-3737-4943-ae69-b265e918b113"/>
							<gml:surfaceMember xlink:href="#poly-269388ab-b389-4f31-86f0-ce10460c5d02"/>
							<gml:surfaceMember xlink:href="#poly-fae1913f-8e37-4de9-afda-932a4830dd05"/>
							<gml:surfaceMember xlink:href="#poly-c92d68ca-1321-47d3-94e1-1e0a7e3c8203"/>
							<gml:surfaceMember xlink:href="#poly-e499ac44-1554-4744-81af-f901ea0e41f6"/>
							<gml:surfaceMember xlink:href="#poly-9c07c984-0e67-4060-95b2-aeacb02fcdf1"/>
							<gml:surfaceMember xlink:href="#poly-ca72c982-a503-437b-80bd-05d8ea5160f3"/>
							<gml:surfaceMember xlink:href="#poly-5624d334-ab07-4cfd-8678-ea18faaf1c90"/>
							<gml:surfaceMember xlink:href="#poly-99bfb003-0649-4738-bfae-75326645643c"/>
							<gml:surfaceMember xlink:href="#poly-91b1e196-c162-4fa9-b534-fe3c5aec5986"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_7f7162da-6f5d-4f4a-9860-3d0ddbe75b9b_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d9bdc3c3-2c30-4ff2-aef4-2f87f898599c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67167548433107 139.73864563843566 29.792 35.671672430861356 139.73862549334027 29.792 35.6716804967074 139.7386236611499 29.792 35.67168355918245 139.73864379519017 29.792 35.67167548433107 139.73864563843566 29.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f3f67ccb-0105-432e-b4a3-be5cea35c470">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671672430861356 139.73862549334027 29.792 35.67167548433107 139.73864563843566 29.792 35.67167548433107 139.73864563843566 30.118 35.671672430861356 139.73862549334027 30.118 35.671672430861356 139.73862549334027 29.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d507f536-a742-47cf-9821-2012e43bfa37">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67168040174304 139.7386977718173 29.792 35.6716729667521 139.73869947069832 29.792 35.671659720093956 139.73861224158617 29.792 35.67166714607864 139.7386105537544 29.792 35.67168040174304 139.7386977718173 29.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9723fb01-0a5f-4791-b818-79cbd0bd0b6e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6716729667521 139.73869947069832 29.792 35.6716729667521 139.73869947069832 30.118 35.671659720093956 139.73861224158617 30.118 35.671659720093956 139.73861224158617 29.792 35.6716729667521 139.73869947069832 29.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-86758396-1369-45ca-857f-042985c9cfa4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67166897438588 139.7387003812186 29.792 35.67165572772841 139.73861315211064 29.792 35.67165572772841 139.73861315211064 30.118 35.67166897438588 139.7387003812186 30.118 35.67166897438588 139.7387003812186 29.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-20ded087-0d42-48af-940d-e0f5cfefd34a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67166245862941 139.73870186913186 29.792 35.67164921197301 139.73861464003076 29.792 35.67165572772841 139.73861315211064 29.792 35.67166897438588 139.7387003812186 29.792 35.67166245862941 139.73870186913186 29.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0763ede5-2afe-42ea-a33a-fe037cc3a0c5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67166245862941 139.73870186913186 29.792 35.67166245862941 139.73870186913186 30.118 35.67164921197301 139.73861464003076 30.118 35.67164921197301 139.73861464003076 29.792 35.67166245862941 139.73870186913186 29.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c78337d-8d71-447a-83f0-dc6e5a1f134d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671658060715224 139.73870286850203 29.792 35.671644805054505 139.7386156504626 29.792 35.671644805054505 139.7386156504626 30.118 35.671658060715224 139.73870286850203 30.118 35.671658060715224 139.73870286850203 29.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-be508ab1-ae15-4be9-bac7-78771e465054">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671644805054505 139.7386156504626 29.792 35.671658060715224 139.73870286850203 29.792 35.6716510492909 139.7387044674643 29.792 35.67163780264506 139.73861724942157 29.792 35.671644805054505 139.7386156504626 29.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-86be70ff-173c-4146-9a9e-e64bd0e61f86">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6716510492909 139.7387044674643 29.792 35.6716510492909 139.7387044674643 30.118 35.67163780264506 139.73861724942157 30.118 35.67163780264506 139.73861724942157 29.792 35.6716510492909 139.7387044674643 29.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3c77732-b7bb-4af0-be21-3629d8337391">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671633413745276 139.73861824878543 29.792 35.671633413745276 139.73861824878543 30.118 35.671646660390394 139.73870546682352 30.118 35.671646660390394 139.73870546682352 29.792 35.671633413745276 139.73861824878543 29.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a6d1d96e-399d-48ff-9a17-a97108f43f9c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67163996439416 139.73870699913445 29.792 35.67162670873642 139.73861978111398 29.792 35.671633413745276 139.73861824878543 29.792 35.671646660390394 139.73870546682352 29.792 35.67163996439416 139.73870699913445 29.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ac3f03f-ec1d-41a1-85b2-da175b04c73c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6ac3f03f-ec1d-41a1-85b2-da175b04c73c_0">
											<gml:posList>35.67162670873642 139.73861978111398 29.792 35.67162670873642 139.73861978111398 30.118 35.671633413745276 139.73861824878543 30.118 35.671633413745276 139.73861824878543 29.792 35.67162670873642 139.73861978111398 29.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-12eda3e1-a786-48f5-979f-5e7f3227f5b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-12eda3e1-a786-48f5-979f-5e7f3227f5b1_0">
											<gml:posList>35.67162670873642 139.73861978111398 29.792 35.67163996439416 139.73870699913445 29.792 35.67163996439416 139.73870699913445 30.118 35.67162670873642 139.73861978111398 30.118 35.67162670873642 139.73861978111398 29.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c588a34-e10e-450e-b992-b30b81111b8c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2c588a34-e10e-450e-b992-b30b81111b8c_0">
											<gml:posList>35.671633413745276 139.73861824878543 30.118 35.67162670873642 139.73861978111398 30.118 35.67163996439416 139.73870699913445 30.118 35.671646660390394 139.73870546682352 30.118 35.671633413745276 139.73861824878543 30.118</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f30fc37f-f532-4fd9-b779-d14db416ab7f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f30fc37f-f532-4fd9-b779-d14db416ab7f_0">
											<gml:posList>35.67163780264506 139.73861724942157 29.792 35.67163780264506 139.73861724942157 30.118 35.671644805054505 139.7386156504626 30.118 35.671644805054505 139.7386156504626 29.792 35.67163780264506 139.73861724942157 29.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-03418d3d-eb8a-4132-99b7-9e8183068962">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-03418d3d-eb8a-4132-99b7-9e8183068962_0">
											<gml:posList>35.67163996439416 139.73870699913445 29.792 35.671646660390394 139.73870546682352 29.792 35.671646660390394 139.73870546682352 30.118 35.67163996439416 139.73870699913445 30.118 35.67163996439416 139.73870699913445 29.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7b855b3-223a-4c2a-bdd7-38e6e622123b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f7b855b3-223a-4c2a-bdd7-38e6e622123b_0">
											<gml:posList>35.6716510492909 139.7387044674643 30.118 35.671658060715224 139.73870286850203 30.118 35.671644805054505 139.7386156504626 30.118 35.67163780264506 139.73861724942157 30.118 35.6716510492909 139.7387044674643 30.118</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b6d47da-e947-478c-bcef-d954b3572764">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b6d47da-e947-478c-bcef-d954b3572764_0">
											<gml:posList>35.67165572772841 139.73861315211064 29.792 35.67164921197301 139.73861464003076 29.792 35.67164921197301 139.73861464003076 30.118 35.67165572772841 139.73861315211064 30.118 35.67165572772841 139.73861315211064 29.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9df13626-bce9-4f3d-a339-55647b1521bd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9df13626-bce9-4f3d-a339-55647b1521bd_0">
											<gml:posList>35.6716510492909 139.7387044674643 29.792 35.671658060715224 139.73870286850203 29.792 35.671658060715224 139.73870286850203 30.118 35.6716510492909 139.7387044674643 30.118 35.6716510492909 139.7387044674643 29.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0dea05d1-89e4-4755-adf7-27ceca20c006">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0dea05d1-89e4-4755-adf7-27ceca20c006_0">
											<gml:posList>35.67166245862941 139.73870186913186 30.118 35.67166897438588 139.7387003812186 30.118 35.67165572772841 139.73861315211064 30.118 35.67164921197301 139.73861464003076 30.118 35.67166245862941 139.73870186913186 30.118</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e62de63-60bb-4686-898a-6d9ed9fbec98">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e62de63-60bb-4686-898a-6d9ed9fbec98_0">
											<gml:posList>35.67166714607864 139.7386105537544 29.792 35.671659720093956 139.73861224158617 29.792 35.671659720093956 139.73861224158617 30.118 35.67166714607864 139.7386105537544 30.118 35.67166714607864 139.7386105537544 29.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8941e73-97a5-45f1-bb98-85e803ace912">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d8941e73-97a5-45f1-bb98-85e803ace912_0">
											<gml:posList>35.67166245862941 139.73870186913186 29.792 35.67166897438588 139.7387003812186 29.792 35.67166897438588 139.7387003812186 30.118 35.67166245862941 139.73870186913186 30.118 35.67166245862941 139.73870186913186 29.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-821b2244-078f-4202-8299-ebf9760c4743">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-821b2244-078f-4202-8299-ebf9760c4743_0">
											<gml:posList>35.67168040174304 139.7386977718173 30.118 35.67166714607864 139.7386105537544 30.118 35.671659720093956 139.73861224158617 30.118 35.6716729667521 139.73869947069832 30.118 35.67168040174304 139.7386977718173 30.118</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e253fb5b-a398-41a4-9f16-e73ac88e6c76">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e253fb5b-a398-41a4-9f16-e73ac88e6c76_0">
											<gml:posList>35.67168040174304 139.7386977718173 29.792 35.67166714607864 139.7386105537544 29.792 35.67166714607864 139.7386105537544 30.118 35.67168040174304 139.7386977718173 30.118 35.67168040174304 139.7386977718173 29.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-730ec242-26d2-4ae1-8971-b993cc2b4d8c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-730ec242-26d2-4ae1-8971-b993cc2b4d8c_0">
											<gml:posList>35.6716804967074 139.7386236611499 29.792 35.671672430861356 139.73862549334027 29.792 35.671672430861356 139.73862549334027 30.118 35.6716804967074 139.7386236611499 30.118 35.6716804967074 139.7386236611499 29.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-527b635f-934d-4b3a-9f97-9c62b32bd1ad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-527b635f-934d-4b3a-9f97-9c62b32bd1ad_0">
											<gml:posList>35.6716729667521 139.73869947069832 29.792 35.67168040174304 139.7386977718173 29.792 35.67168040174304 139.7386977718173 30.118 35.6716729667521 139.73869947069832 30.118 35.6716729667521 139.73869947069832 29.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c19ee840-e119-4446-9c23-2805089ec2da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c19ee840-e119-4446-9c23-2805089ec2da_0">
											<gml:posList>35.6716804967074 139.7386236611499 30.118 35.671672430861356 139.73862549334027 30.118 35.67167548433107 139.73864563843566 30.118 35.67168355918245 139.73864379519017 30.118 35.6716804967074 139.7386236611499 30.118</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e0190d8-ac35-4260-9c0d-14ee944af503">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7e0190d8-ac35-4260-9c0d-14ee944af503_0">
											<gml:posList>35.67167548433107 139.73864563843566 29.792 35.67168355918245 139.73864379519017 29.792 35.67168355918245 139.73864379519017 30.118 35.67167548433107 139.73864563843566 30.118 35.67167548433107 139.73864563843566 29.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f328a1a-8803-4eed-a46b-63c4f65079a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1f328a1a-8803-4eed-a46b-63c4f65079a6_0">
											<gml:posList>35.67168355918245 139.73864379519017 29.792 35.6716804967074 139.7386236611499 29.792 35.6716804967074 139.7386236611499 30.118 35.67168355918245 139.73864379519017 30.118 35.67168355918245 139.73864379519017 29.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-02fddc15-dbcd-445f-a869-c480a13f58e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-02fddc15-dbcd-445f-a869-c480a13f58e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-02fddc15-dbcd-445f-a869-c480a13f58e2">
											<gml:posList>35.67171070438723 139.73874173402936 13.142 35.67162085538281 139.73876448521804 13.142 35.67160000687303 139.73861571443376 13.142 35.67162992738468 139.73860927215534 13.142 35.67162575830233 139.73858033543218 13.142 35.671685869732656 139.7385674505203 13.142 35.67171070438723 139.73874173402936 13.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6bac3eaf-bb63-4631-9daf-1a56e6d530ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6bac3eaf-bb63-4631-9daf-1a56e6d530ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6bac3eaf-bb63-4631-9daf-1a56e6d530ce">
											<gml:posList>35.67162992738468 139.73860927215534 30.208 35.67160000687303 139.73861571443376 30.208 35.67160372305437 139.73861892455395 30.208 35.67163365257989 139.7386124822658 30.208 35.67162992738468 139.73860927215534 30.208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cc86b34c-c442-434e-9226-70f9cb4100b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc86b34c-c442-434e-9226-70f9cb4100b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc86b34c-c442-434e-9226-70f9cb4100b9">
											<gml:posList>35.67163129475019 139.7386058130067 32.23 35.67163241093071 139.73860387856237 32.23 35.671629483533096 139.7385835897268 32.23 35.67162789604046 139.73858222184543 32.23 35.67163129475019 139.7386058130067 32.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bc0b1b66-a95c-4fe3-a9f2-1a6c60407c37">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc0b1b66-a95c-4fe3-a9f2-1a6c60407c37">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc0b1b66-a95c-4fe3-a9f2-1a6c60407c37">
											<gml:posList>35.67162789604046 139.73858222184543 30.208 35.6716846548365 139.7385699374051 30.208 35.67162575830233 139.73858033543218 30.208 35.67162992738468 139.73860927215534 30.208 35.67163365257989 139.7386124822658 30.208 35.67163264658229 139.73860552420226 30.208 35.67163129475019 139.7386058130067 30.208 35.67162789604046 139.73858222184543 30.208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4f66258e-1069-47f8-9ff2-54b14f55d04d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f66258e-1069-47f8-9ff2-54b14f55d04d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f66258e-1069-47f8-9ff2-54b14f55d04d">
											<gml:posList>35.67162789604046 139.73858222184543 32.23 35.671629483533096 139.7385835897268 32.23 35.67168354767025 139.73857187184052 32.23 35.6716846548365 139.7385699374051 32.23 35.67162789604046 139.73858222184543 32.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-98714683-9e33-4b10-9d53-297941ed8005">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-98714683-9e33-4b10-9d53-297941ed8005">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-98714683-9e33-4b10-9d53-297941ed8005">
											<gml:posList>35.671686475069826 139.73859216068934 31.828 35.67168354767025 139.73857187184052 31.828 35.671629483533096 139.7385835897268 31.828 35.67163241093071 139.73860387856237 31.828 35.671686475069826 139.73859216068934 31.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fa3c522e-93ed-4175-862c-36229451aa6c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa3c522e-93ed-4175-862c-36229451aa6c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa3c522e-93ed-4175-862c-36229451aa6c">
											<gml:posList>35.67168805354861 139.73859352858256 32.23 35.671686475069826 139.73859216068934 32.23 35.67163241093071 139.73860387856237 32.23 35.67163129475019 139.7386058130067 32.23 35.67168805354861 139.73859352858256 32.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0b1cee11-bc3e-4872-897f-75030481fad3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b1cee11-bc3e-4872-897f-75030481fad3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b1cee11-bc3e-4872-897f-75030481fad3">
											<gml:posList>35.671685869732656 139.7385674505203 30.208 35.67162575830233 139.73858033543218 30.208 35.6716846548365 139.7385699374051 30.208 35.67168805354861 139.73859352858256 30.208 35.67168636826974 139.7385938951065 30.208 35.671707006340796 139.73873865643512 30.208 35.67171070438723 139.73874173402936 30.208 35.671685869732656 139.7385674505203 30.208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-63037e34-9db6-46dd-bb07-5d987523b389">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-63037e34-9db6-46dd-bb07-5d987523b389">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-63037e34-9db6-46dd-bb07-5d987523b389">
											<gml:posList>35.6716846548365 139.7385699374051 32.23 35.67168354767025 139.73857187184052 32.23 35.671686475069826 139.73859216068934 32.23 35.67168805354861 139.73859352858256 32.23 35.6716846548365 139.7385699374051 32.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f0fdb780-f7da-4d0a-8c12-4eb9ec4ab18c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f0fdb780-f7da-4d0a-8c12-4eb9ec4ab18c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f0fdb780-f7da-4d0a-8c12-4eb9ec4ab18c">
											<gml:posList>35.67161636842758 139.7387324558648 30.208 35.67161899686694 139.7387279126807 30.208 35.67160372305437 139.73861892455395 30.208 35.67160000687303 139.73861571443376 30.208 35.67161636842758 139.7387324558648 30.208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f9ad55e0-b3fb-4a30-8adc-7667aa3303c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9ad55e0-b3fb-4a30-8adc-7667aa3303c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9ad55e0-b3fb-4a30-8adc-7667aa3303c7">
											<gml:posList>35.67163424870671 139.73872869002656 30.208 35.67163677801237 139.73872416905115 30.208 35.67161899686694 139.7387279126807 30.208 35.67161636842758 139.7387324558648 30.208 35.67163424870671 139.73872869002656 30.208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-65184f4d-d74c-403d-96cf-6e956cde8f11">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65184f4d-d74c-403d-96cf-6e956cde8f11">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65184f4d-d74c-403d-96cf-6e956cde8f11">
											<gml:posList>35.67162085538281 139.73876448521804 29.396 35.6716394830556 139.7387597685119 29.396 35.67163424870671 139.73872869002656 29.396 35.67161636842758 139.7387324558648 29.396 35.67162085538281 139.73876448521804 29.396</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-68259017-2c67-4b1f-a2ef-8c767fb6f744">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-68259017-2c67-4b1f-a2ef-8c767fb6f744">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-68259017-2c67-4b1f-a2ef-8c767fb6f744">
											<gml:posList>35.67163424870671 139.73872869002656 30.208 35.6716394830556 139.7387597685119 30.208 35.671641985217136 139.738755115012 30.208 35.67163677801237 139.73872416905115 30.208 35.67163424870671 139.73872869002656 30.208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5a4aa9ef-6f54-40cc-8a2e-c5e33fe9649a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a4aa9ef-6f54-40cc-8a2e-c5e33fe9649a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a4aa9ef-6f54-40cc-8a2e-c5e33fe9649a">
											<gml:posList>35.671707006340796 139.73873865643512 29.792 35.67168636826974 139.7385938951065 29.792 35.67163264658229 139.73860552420226 29.792 35.67163365257989 139.7386124822658 29.792 35.67160372305437 139.73861892455395 29.792 35.67161899686694 139.7387279126807 29.792 35.67163677801237 139.73872416905115 29.792 35.671641985217136 139.738755115012 29.792 35.671707006340796 139.73873865643512 29.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2eea53ed-bc72-4598-9c7d-1468f0ae2b2e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2eea53ed-bc72-4598-9c7d-1468f0ae2b2e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2eea53ed-bc72-4598-9c7d-1468f0ae2b2e">
											<gml:posList>35.67171070438723 139.73874173402936 30.208 35.671707006340796 139.73873865643512 30.208 35.671641985217136 139.738755115012 30.208 35.6716394830556 139.7387597685119 30.208 35.67171070438723 139.73874173402936 30.208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9fc49fc4-3f36-4010-ab28-a94fc5f05e9b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9fc49fc4-3f36-4010-ab28-a94fc5f05e9b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9fc49fc4-3f36-4010-ab28-a94fc5f05e9b">
											<gml:posList>35.67162085538281 139.73876448521804 13.142 35.67162085538281 139.73876448521804 29.396 35.67161636842758 139.7387324558648 29.396 35.67161636842758 139.7387324558648 30.208 35.67160000687303 139.73861571443376 30.208 35.67160000687303 139.73861571443376 13.142 35.67162085538281 139.73876448521804 13.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d6c73a20-0efa-4c46-bf3a-cf6b50905276">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d6c73a20-0efa-4c46-bf3a-cf6b50905276">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d6c73a20-0efa-4c46-bf3a-cf6b50905276">
											<gml:posList>35.67161899686694 139.7387279126807 30.208 35.67161899686694 139.7387279126807 29.792 35.67160372305437 139.73861892455395 29.792 35.67160372305437 139.73861892455395 30.208 35.67161899686694 139.7387279126807 30.208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f1337254-9ce1-4579-ac4b-38857f86bf59">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f1337254-9ce1-4579-ac4b-38857f86bf59">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f1337254-9ce1-4579-ac4b-38857f86bf59">
											<gml:posList>35.67162992738468 139.73860927215534 13.142 35.67160000687303 139.73861571443376 13.142 35.67160000687303 139.73861571443376 30.208 35.67162992738468 139.73860927215534 30.208 35.67162992738468 139.73860927215534 13.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-341e7d0e-943e-484d-9803-3c14bb2b8368">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-341e7d0e-943e-484d-9803-3c14bb2b8368">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-341e7d0e-943e-484d-9803-3c14bb2b8368">
											<gml:posList>35.67160372305437 139.73861892455395 30.208 35.67160372305437 139.73861892455395 29.792 35.67163365257989 139.7386124822658 29.792 35.67163365257989 139.7386124822658 30.208 35.67160372305437 139.73861892455395 30.208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a764f72f-1d9d-4070-8265-8aa36bc4517e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a764f72f-1d9d-4070-8265-8aa36bc4517e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a764f72f-1d9d-4070-8265-8aa36bc4517e">
											<gml:posList>35.67161636842758 139.7387324558648 30.208 35.67161636842758 139.7387324558648 29.396 35.67163424870671 139.73872869002656 29.396 35.67163424870671 139.73872869002656 30.208 35.67161636842758 139.7387324558648 30.208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-737cd167-ca0f-45d9-a154-31dd911c8568">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-737cd167-ca0f-45d9-a154-31dd911c8568">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-737cd167-ca0f-45d9-a154-31dd911c8568">
											<gml:posList>35.67163677801237 139.73872416905115 30.208 35.67163677801237 139.73872416905115 29.792 35.67161899686694 139.7387279126807 29.792 35.67161899686694 139.7387279126807 30.208 35.67163677801237 139.73872416905115 30.208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2a7ce118-3586-4287-a6bb-2afeddc5e920">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a7ce118-3586-4287-a6bb-2afeddc5e920">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a7ce118-3586-4287-a6bb-2afeddc5e920">
											<gml:posList>35.67162575830233 139.73858033543218 13.142 35.67162992738468 139.73860927215534 13.142 35.67162992738468 139.73860927215534 30.208 35.67162575830233 139.73858033543218 30.208 35.67162575830233 139.73858033543218 13.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d3432473-da08-40ee-b1ce-fae82c0f3a5a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3432473-da08-40ee-b1ce-fae82c0f3a5a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3432473-da08-40ee-b1ce-fae82c0f3a5a">
											<gml:posList>35.67163129475019 139.7386058130067 30.208 35.67163129475019 139.7386058130067 32.23 35.67162789604046 139.73858222184543 32.23 35.67162789604046 139.73858222184543 30.208 35.67163129475019 139.7386058130067 30.208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-732a42d5-43a2-474c-a0cf-de66e81b9b44">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-732a42d5-43a2-474c-a0cf-de66e81b9b44">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-732a42d5-43a2-474c-a0cf-de66e81b9b44">
											<gml:posList>35.67163241093071 139.73860387856237 32.23 35.67163241093071 139.73860387856237 31.828 35.671629483533096 139.7385835897268 31.828 35.671629483533096 139.7385835897268 32.23 35.67163241093071 139.73860387856237 32.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6d2c8ee3-c1b4-47fb-89ab-cbe27d2db326">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d2c8ee3-c1b4-47fb-89ab-cbe27d2db326">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d2c8ee3-c1b4-47fb-89ab-cbe27d2db326">
											<gml:posList>35.67163365257989 139.7386124822658 30.208 35.67163365257989 139.7386124822658 29.792 35.67163264658229 139.73860552420226 29.792 35.67163264658229 139.73860552420226 30.208 35.67163365257989 139.7386124822658 30.208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d7f86596-18a9-429d-a03c-06b803668a4f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7f86596-18a9-429d-a03c-06b803668a4f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7f86596-18a9-429d-a03c-06b803668a4f">
											<gml:posList>35.671685869732656 139.7385674505203 13.142 35.67162575830233 139.73858033543218 13.142 35.67162575830233 139.73858033543218 30.208 35.671685869732656 139.7385674505203 30.208 35.671685869732656 139.7385674505203 13.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2adadf8f-1230-46e3-aabd-505e4c324f83">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2adadf8f-1230-46e3-aabd-505e4c324f83">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2adadf8f-1230-46e3-aabd-505e4c324f83">
											<gml:posList>35.67162789604046 139.73858222184543 30.208 35.67162789604046 139.73858222184543 32.23 35.6716846548365 139.7385699374051 32.23 35.6716846548365 139.7385699374051 30.208 35.67162789604046 139.73858222184543 30.208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f12b712e-0fa2-431b-93fe-6f5f165923cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f12b712e-0fa2-431b-93fe-6f5f165923cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f12b712e-0fa2-431b-93fe-6f5f165923cc">
											<gml:posList>35.671629483533096 139.7385835897268 32.23 35.671629483533096 139.7385835897268 31.828 35.67168354767025 139.73857187184052 31.828 35.67168354767025 139.73857187184052 32.23 35.671629483533096 139.7385835897268 32.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-77b25497-3737-4943-ae69-b265e918b113">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-77b25497-3737-4943-ae69-b265e918b113">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-77b25497-3737-4943-ae69-b265e918b113">
											<gml:posList>35.671686475069826 139.73859216068934 32.23 35.671686475069826 139.73859216068934 31.828 35.67163241093071 139.73860387856237 31.828 35.67163241093071 139.73860387856237 32.23 35.671686475069826 139.73859216068934 32.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-269388ab-b389-4f31-86f0-ce10460c5d02">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-269388ab-b389-4f31-86f0-ce10460c5d02">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-269388ab-b389-4f31-86f0-ce10460c5d02">
											<gml:posList>35.67163264658229 139.73860552420226 30.208 35.67163264658229 139.73860552420226 29.792 35.67168636826974 139.7385938951065 29.792 35.67168636826974 139.7385938951065 30.208 35.67168805354861 139.73859352858256 30.208 35.67168805354861 139.73859352858256 32.23 35.67163129475019 139.7386058130067 32.23 35.67163129475019 139.7386058130067 30.208 35.67163264658229 139.73860552420226 30.208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fae1913f-8e37-4de9-afda-932a4830dd05">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fae1913f-8e37-4de9-afda-932a4830dd05">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fae1913f-8e37-4de9-afda-932a4830dd05">
											<gml:posList>35.67168354767025 139.73857187184052 32.23 35.67168354767025 139.73857187184052 31.828 35.671686475069826 139.73859216068934 31.828 35.671686475069826 139.73859216068934 32.23 35.67168354767025 139.73857187184052 32.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c92d68ca-1321-47d3-94e1-1e0a7e3c8203">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c92d68ca-1321-47d3-94e1-1e0a7e3c8203">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c92d68ca-1321-47d3-94e1-1e0a7e3c8203">
											<gml:posList>35.6716846548365 139.7385699374051 30.208 35.6716846548365 139.7385699374051 32.23 35.67168805354861 139.73859352858256 32.23 35.67168805354861 139.73859352858256 30.208 35.6716846548365 139.7385699374051 30.208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e499ac44-1554-4744-81af-f901ea0e41f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e499ac44-1554-4744-81af-f901ea0e41f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e499ac44-1554-4744-81af-f901ea0e41f6">
											<gml:posList>35.67168636826974 139.7385938951065 30.208 35.67168636826974 139.7385938951065 29.792 35.671707006340796 139.73873865643512 29.792 35.671707006340796 139.73873865643512 30.208 35.67168636826974 139.7385938951065 30.208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9c07c984-0e67-4060-95b2-aeacb02fcdf1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c07c984-0e67-4060-95b2-aeacb02fcdf1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c07c984-0e67-4060-95b2-aeacb02fcdf1">
											<gml:posList>35.67171070438723 139.73874173402936 13.142 35.671685869732656 139.7385674505203 13.142 35.671685869732656 139.7385674505203 30.208 35.67171070438723 139.73874173402936 30.208 35.67171070438723 139.73874173402936 13.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ca72c982-a503-437b-80bd-05d8ea5160f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca72c982-a503-437b-80bd-05d8ea5160f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca72c982-a503-437b-80bd-05d8ea5160f3">
											<gml:posList>35.671641985217136 139.738755115012 30.208 35.671641985217136 139.738755115012 29.792 35.67163677801237 139.73872416905115 29.792 35.67163677801237 139.73872416905115 30.208 35.671641985217136 139.738755115012 30.208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5624d334-ab07-4cfd-8678-ea18faaf1c90">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5624d334-ab07-4cfd-8678-ea18faaf1c90">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5624d334-ab07-4cfd-8678-ea18faaf1c90">
											<gml:posList>35.67163424870671 139.73872869002656 30.208 35.67163424870671 139.73872869002656 29.396 35.6716394830556 139.7387597685119 29.396 35.6716394830556 139.7387597685119 30.208 35.67163424870671 139.73872869002656 30.208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-99bfb003-0649-4738-bfae-75326645643c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-99bfb003-0649-4738-bfae-75326645643c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-99bfb003-0649-4738-bfae-75326645643c">
											<gml:posList>35.671707006340796 139.73873865643512 30.208 35.671707006340796 139.73873865643512 29.792 35.671641985217136 139.738755115012 29.792 35.671641985217136 139.738755115012 30.208 35.671707006340796 139.73873865643512 30.208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-91b1e196-c162-4fa9-b534-fe3c5aec5986">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-91b1e196-c162-4fa9-b534-fe3c5aec5986">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-91b1e196-c162-4fa9-b534-fe3c5aec5986">
											<gml:posList>35.67162085538281 139.73876448521804 13.142 35.67171070438723 139.73874173402936 13.142 35.67171070438723 139.73874173402936 30.208 35.6716394830556 139.7387597685119 30.208 35.6716394830556 139.7387597685119 29.396 35.67162085538281 139.73876448521804 29.396 35.67162085538281 139.73876448521804 13.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1860</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">155.20095</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>