<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_80493f25-80dc-4e39-b97a-b07ac5137190">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:measuredHeight uom="m">3.2</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67436279417206 139.73796348342066 0 35.6743460027338 139.73790802633889 0 35.674335127083 139.73791296615937 0 35.6743519365377 139.7379684121664 0 35.67436279417206 139.73796348342066 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67436279417206 139.73796348342066 8.692 35.6743519365377 139.7379684121664 8.692 35.674335127083 139.73791296615937 8.692 35.6743460027338 139.73790802633889 8.692 35.67436279417206 139.73796348342066 8.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67436279417206 139.73796348342066 8.692 35.6743460027338 139.73790802633889 8.692 35.6743460027338 139.73790802633889 11.89 35.67436279417206 139.73796348342066 11.89 35.67436279417206 139.73796348342066 8.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6743460027338 139.73790802633889 8.692 35.674335127083 139.73791296615937 8.692 35.674335127083 139.73791296615937 11.89 35.6743460027338 139.73790802633889 11.89 35.6743460027338 139.73790802633889 8.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674335127083 139.73791296615937 8.692 35.6743519365377 139.7379684121664 8.692 35.6743519365377 139.7379684121664 11.89 35.674335127083 139.73791296615937 11.89 35.674335127083 139.73791296615937 8.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6743519365377 139.7379684121664 8.692 35.67436279417206 139.73796348342066 8.692 35.67436279417206 139.73796348342066 11.89 35.6743519365377 139.7379684121664 11.89 35.6743519365377 139.7379684121664 8.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67436279417206 139.73796348342066 11.89 35.6743460027338 139.73790802633889 11.89 35.674335127083 139.73791296615937 11.89 35.6743519365377 139.7379684121664 11.89 35.67436279417206 139.73796348342066 11.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-10c42fcb-5d9e-4691-88a5-c0581f305916"/>
							<gml:surfaceMember xlink:href="#poly-ca32bc75-c1e3-4ff6-9082-0bf224aafaec"/>
							<gml:surfaceMember xlink:href="#poly-4382f889-3bae-4949-a8a2-5ffb63a47de6"/>
							<gml:surfaceMember xlink:href="#poly-c61253b2-e095-46a1-9f00-cff4c4ee59b5"/>
							<gml:surfaceMember xlink:href="#poly-d3494d11-925f-48f5-a5df-8128985f3de1"/>
							<gml:surfaceMember xlink:href="#poly-ac074926-676d-4a7b-919d-6a988a0be124"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-10c42fcb-5d9e-4691-88a5-c0581f305916">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-10c42fcb-5d9e-4691-88a5-c0581f305916">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-10c42fcb-5d9e-4691-88a5-c0581f305916">
											<gml:posList>35.67436279417206 139.73796348342066 8.692 35.674351936537704 139.7379684121664 8.692 35.67433512708298 139.73791296615937 8.692 35.67434600273377 139.73790802633889 8.692 35.67436279417206 139.73796348342066 8.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ca32bc75-c1e3-4ff6-9082-0bf224aafaec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca32bc75-c1e3-4ff6-9082-0bf224aafaec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca32bc75-c1e3-4ff6-9082-0bf224aafaec">
											<gml:posList>35.67434600273377 139.73790802633889 11.51 35.67433512708298 139.73791296615937 11.51 35.674351936537704 139.7379684121664 11.51 35.67436279417206 139.73796348342066 11.51 35.67434600273377 139.73790802633889 11.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4382f889-3bae-4949-a8a2-5ffb63a47de6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4382f889-3bae-4949-a8a2-5ffb63a47de6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4382f889-3bae-4949-a8a2-5ffb63a47de6">
											<gml:posList>35.67433512708298 139.73791296615937 8.692 35.67433512708298 139.73791296615937 11.51 35.67434600273377 139.73790802633889 11.51 35.67434600273377 139.73790802633889 8.692 35.67433512708298 139.73791296615937 8.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c61253b2-e095-46a1-9f00-cff4c4ee59b5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c61253b2-e095-46a1-9f00-cff4c4ee59b5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c61253b2-e095-46a1-9f00-cff4c4ee59b5">
											<gml:posList>35.674351936537704 139.7379684121664 8.692 35.674351936537704 139.7379684121664 11.51 35.67433512708298 139.73791296615937 11.51 35.67433512708298 139.73791296615937 8.692 35.674351936537704 139.7379684121664 8.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d3494d11-925f-48f5-a5df-8128985f3de1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3494d11-925f-48f5-a5df-8128985f3de1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3494d11-925f-48f5-a5df-8128985f3de1">
											<gml:posList>35.67434600273377 139.73790802633889 8.692 35.67434600273377 139.73790802633889 11.51 35.67436279417206 139.73796348342066 11.51 35.67436279417206 139.73796348342066 8.692 35.67434600273377 139.73790802633889 8.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ac074926-676d-4a7b-919d-6a988a0be124">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ac074926-676d-4a7b-919d-6a988a0be124">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ac074926-676d-4a7b-919d-6a988a0be124">
											<gml:posList>35.67436279417206 139.73796348342066 8.692 35.67436279417206 139.73796348342066 11.51 35.674351936537704 139.7379684121664 11.51 35.674351936537704 139.7379684121664 8.692 35.67436279417206 139.73796348342066 8.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-9936</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.17</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>