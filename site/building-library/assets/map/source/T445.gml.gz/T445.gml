<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_82fa9d9f-f88d-462a-8b0b-ba9a9c3c64da">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">403</bldg:usage>
			<bldg:measuredHeight uom="m">30.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67359581452626 139.73805232759727 0 35.67362682831505 139.7380378526914 0 35.67363470834709 139.7380632065651 0 35.6736786700754 139.73804268476124 0 35.673584398488934 139.73773939918212 0 35.67350948631001 139.7377745948906 0 35.67359581452626 139.73805232759727 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67359581452626 139.73805232759727 8.98 35.67350948631001 139.7377745948906 8.98 35.673584398488934 139.73773939918212 8.98 35.6736786700754 139.73804268476124 8.98 35.67363470834709 139.7380632065651 8.98 35.67362682831505 139.7380378526914 8.98 35.67359581452626 139.73805232759727 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67359581452626 139.73805232759727 8.98 35.67362682831505 139.7380378526914 8.98 35.67362682831505 139.7380378526914 39.18 35.67359581452626 139.73805232759727 39.18 35.67359581452626 139.73805232759727 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67362682831505 139.7380378526914 8.98 35.67363470834709 139.7380632065651 8.98 35.67363470834709 139.7380632065651 39.18 35.67362682831505 139.7380378526914 39.18 35.67362682831505 139.7380378526914 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67363470834709 139.7380632065651 8.98 35.6736786700754 139.73804268476124 8.98 35.6736786700754 139.73804268476124 39.18 35.67363470834709 139.7380632065651 39.18 35.67363470834709 139.7380632065651 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6736786700754 139.73804268476124 8.98 35.673584398488934 139.73773939918212 8.98 35.673584398488934 139.73773939918212 39.18 35.6736786700754 139.73804268476124 39.18 35.6736786700754 139.73804268476124 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673584398488934 139.73773939918212 8.98 35.67350948631001 139.7377745948906 8.98 35.67350948631001 139.7377745948906 39.18 35.673584398488934 139.73773939918212 39.18 35.673584398488934 139.73773939918212 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67350948631001 139.7377745948906 8.98 35.67359581452626 139.73805232759727 8.98 35.67359581452626 139.73805232759727 39.18 35.67350948631001 139.7377745948906 39.18 35.67350948631001 139.7377745948906 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67359581452626 139.73805232759727 39.18 35.67362682831505 139.7380378526914 39.18 35.67363470834709 139.7380632065651 39.18 35.6736786700754 139.73804268476124 39.18 35.673584398488934 139.73773939918212 39.18 35.67350948631001 139.7377745948906 39.18 35.67359581452626 139.73805232759727 39.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-fd02a6c9-9dcc-48a4-9d3b-fa2829d92bfc"/>
							<gml:surfaceMember xlink:href="#poly-b81fdde0-d40c-4ab8-bdec-45ce82a3341c"/>
							<gml:surfaceMember xlink:href="#poly-c24cacdc-21c7-4ca1-ac3f-a37a59d7c30d"/>
							<gml:surfaceMember xlink:href="#poly-7d7cca03-a3d4-42fb-9f0a-8913374c23d4"/>
							<gml:surfaceMember xlink:href="#poly-05f7f37b-b77d-4a32-8ec3-afdf125aaa88"/>
							<gml:surfaceMember xlink:href="#poly-31a759ca-4ed3-42fc-ae8a-d8700d860fb5"/>
							<gml:surfaceMember xlink:href="#poly-82d1e8ff-8a7e-48a3-8757-967293d3fa67"/>
							<gml:surfaceMember xlink:href="#poly-641e336c-14e3-46f4-9f8f-1f70d8ce9079"/>
							<gml:surfaceMember xlink:href="#poly-fa80d17a-291b-42f1-a26f-f21f02dc9d6f"/>
							<gml:surfaceMember xlink:href="#poly-a4bd5c9f-db68-4c65-936e-cf65ad0ac06f"/>
							<gml:surfaceMember xlink:href="#poly-95b8e871-7ee1-4b6b-a323-0152bcdd2cf2"/>
							<gml:surfaceMember xlink:href="#poly-243a8da2-e880-4faa-a5f5-80716082c2c8"/>
							<gml:surfaceMember xlink:href="#poly-e058d48d-fadb-4349-92f6-06c3822cbd9f"/>
							<gml:surfaceMember xlink:href="#poly-c9b31798-c29c-4bb0-a410-4bfa346a3e08"/>
							<gml:surfaceMember xlink:href="#poly-edf306b5-7fde-4fea-9428-c27312270c7f"/>
							<gml:surfaceMember xlink:href="#poly-90b87664-10d3-452f-b62f-306b81921434"/>
							<gml:surfaceMember xlink:href="#poly-cbf922c7-62d3-4bdf-9a3a-d4193b6c5bd6"/>
							<gml:surfaceMember xlink:href="#poly-85dacc02-d653-4a92-a162-f89cd7edd033"/>
							<gml:surfaceMember xlink:href="#poly-67aaa366-80e9-40ab-8f28-cf2875a0cd6b"/>
							<gml:surfaceMember xlink:href="#poly-6c5cf20b-a158-4d70-8b15-f44c98f4a3a4"/>
							<gml:surfaceMember xlink:href="#poly-e75bdf9d-05c1-4e94-886c-d1a3f310833e"/>
							<gml:surfaceMember xlink:href="#poly-cb120126-9811-495b-ab69-bf4ab6ac750f"/>
							<gml:surfaceMember xlink:href="#poly-cee41064-f0ae-4e8d-ad33-2817cdeca6d3"/>
							<gml:surfaceMember xlink:href="#poly-8c3fc4d7-f4a7-4081-9bed-32cbbc726509"/>
							<gml:surfaceMember xlink:href="#poly-45b92af2-8a50-4eb1-b055-6d94217d77ba"/>
							<gml:surfaceMember xlink:href="#poly-fa60f0ce-63b2-4d7d-9296-ee1e8acef7b6"/>
							<gml:surfaceMember xlink:href="#poly-664d95df-a473-40a7-bdb3-4fdcbecbf041"/>
							<gml:surfaceMember xlink:href="#poly-47650654-bf27-4d3c-ab7b-a80bcddad5f6"/>
							<gml:surfaceMember xlink:href="#poly-d9cb9adb-4bed-42b1-a8ce-43ac5470161f"/>
							<gml:surfaceMember xlink:href="#poly-e3a69b28-b2a6-487d-bc89-e2596bf2b64d"/>
							<gml:surfaceMember xlink:href="#poly-61fc309c-5ee5-4994-a8cd-86ae33d042b4"/>
							<gml:surfaceMember xlink:href="#poly-dd760f56-96f2-4220-99ae-3c5f98f03347"/>
							<gml:surfaceMember xlink:href="#poly-2db6dd4d-fd96-4ee9-9e48-e79ffc710f89"/>
							<gml:surfaceMember xlink:href="#poly-d54ac6a9-3898-4d9f-a098-fa9f219276ce"/>
							<gml:surfaceMember xlink:href="#poly-44f6bac4-2d5a-4050-b5be-759ec6913f16"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_82fa9d9f-f88d-462a-8b0b-ba9a9c3c64da_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-efbc28c7-97ea-4781-9f3e-9d92be20a906">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67358087392583 139.7379437341981 41.314 35.673585853049936 139.73795959133602 41.314 35.673579014193464 139.7379628251084 41.314 35.673574035069784 139.73794696797162 41.314 35.67358087392583 139.7379437341981 41.314</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d3d15688-2779-48fb-a830-9ea6bbd18862">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67357540453123 139.7379689382274 41.314 35.67358022506764 139.73796665687286 41.314 35.67358999352112 139.73799774171704 41.314 35.673585172984126 139.73800002307 41.314 35.67357540453123 139.7379689382274 41.314</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26451fcb-8082-4105-9976-32968e2197c4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673594640269236 139.73795812271746 41.314 35.673589513380364 139.73796054804447 41.314 35.67358300711377 139.7379398653147 41.314 35.673588134010984 139.73793745103325 41.314 35.673594640269236 139.73795812271746 41.314</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d149ce15-662e-43dd-a43f-0533dd37633b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673594640269236 139.73795812271746 41.314 35.673588134010984 139.73793745103325 41.314 35.673588134010984 139.73793745103325 42.753 35.673594640269236 139.73795812271746 42.753 35.673594640269236 139.73795812271746 41.314</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-169b2246-9e25-44db-a030-da6434e55448">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67359740659666 139.73795700370943 42.753 35.67359085513835 139.7379361663779 42.753 35.67359085513835 139.7379361663779 41.314 35.67359740659666 139.73795700370943 41.314 35.67359740659666 139.73795700370943 42.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-250ea79a-8945-4d3d-8a65-19e69460a520">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67359740659666 139.73795700370943 41.314 35.67359085513835 139.7379361663779 41.314 35.67359572973892 139.7379338628632 41.314 35.67360228120638 139.7379547112425 41.314 35.67359740659666 139.73795700370943 41.314</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60f9d84e-7491-44db-84c7-f535aaa1ee84">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67361059443049 139.73798071634056 41.314 35.67361511278304 139.73799522633666 41.314 35.673595380019194 139.73800444065967 41.314 35.673590861667726 139.73798993066663 41.314 35.67361059443049 139.73798071634056 41.314</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59c6a24a-56f0-404c-99f1-dbb61080fb17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67359637405557 139.7380076319746 41.47 35.673595380019194 139.73800444065967 41.47 35.67361511278304 139.73799522633666 41.47 35.67361610681968 139.73799841765228 41.47 35.67359637405557 139.7380076319746 41.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-55c2653f-e381-43e9-a641-26fe0431d88d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673617754836094 139.737939625127 41.314 35.67362414317232 139.7379366017746 41.314 35.67363243866162 139.73796297144028 41.314 35.673626041311024 139.73796599480167 41.314 35.673617754836094 139.737939625127 41.314</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa732bbc-d82d-40ef-9bfc-a616314df30f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67364674104207 139.7379599386741 41.314 35.673639406614974 139.73796340501934 41.314 35.67363009902507 139.7379337998705 41.314 35.67363743345132 139.73793033352297 41.314 35.67364674104207 139.7379599386741 41.314</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fca548b6-9866-494e-849b-03e5924890c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fca548b6-9866-494e-849b-03e5924890c6_0">
											<gml:posList>35.673595380019194 139.73800444065967 41.314 35.67361511278304 139.73799522633666 41.314 35.67361511278304 139.73799522633666 41.47 35.673595380019194 139.73800444065967 41.47 35.673595380019194 139.73800444065967 41.314</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e082b8d6-be85-4e3a-a639-fa69e608c209">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e082b8d6-be85-4e3a-a639-fa69e608c209_0">
											<gml:posList>35.673579014193464 139.7379628251084 42.969 35.673574035069784 139.73794696797162 42.969 35.673574035069784 139.73794696797162 41.314 35.673579014193464 139.7379628251084 41.314 35.673579014193464 139.7379628251084 42.969</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-700e8cec-c7c5-40fd-a81e-f9b29538ee26">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-700e8cec-c7c5-40fd-a81e-f9b29538ee26_0">
											<gml:posList>35.673574035069784 139.73794696797162 42.969 35.67358087392583 139.7379437341981 42.969 35.67358087392583 139.7379437341981 41.314 35.673574035069784 139.73794696797162 41.314 35.673574035069784 139.73794696797162 42.969</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a0e7718f-4c49-4a37-907b-f5595fdefe49">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a0e7718f-4c49-4a37-907b-f5595fdefe49_0">
											<gml:posList>35.67357540453123 139.7379689382274 42.567 35.67358022506764 139.73796665687286 42.567 35.67358022506764 139.73796665687286 41.314 35.67357540453123 139.7379689382274 41.314 35.67357540453123 139.7379689382274 42.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ba99b67-e3ec-438c-a9f2-111a96a2acac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9ba99b67-e3ec-438c-a9f2-111a96a2acac_0">
											<gml:posList>35.673579014193464 139.7379628251084 42.969 35.673585853049936 139.73795959133602 42.969 35.67358087392583 139.7379437341981 42.969 35.673574035069784 139.73794696797162 42.969 35.673579014193464 139.7379628251084 42.969</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-39bddd5d-a78a-4fed-8d10-ff7e7d3cae5f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-39bddd5d-a78a-4fed-8d10-ff7e7d3cae5f_0">
											<gml:posList>35.67357540453123 139.7379689382274 42.567 35.67357540453123 139.7379689382274 41.314 35.673585172984126 139.73800002307 41.314 35.673585172984126 139.73800002307 42.567 35.67357540453123 139.7379689382274 42.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a5ec69be-f13d-4d83-9f3a-2a2974e2e203">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a5ec69be-f13d-4d83-9f3a-2a2974e2e203_0">
											<gml:posList>35.673579014193464 139.7379628251084 42.969 35.673579014193464 139.7379628251084 41.314 35.673585853049936 139.73795959133602 41.314 35.673585853049936 139.73795959133602 42.969 35.673579014193464 139.7379628251084 42.969</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-45ba7889-5ede-48c5-a5dc-d3b59fc7e9cd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-45ba7889-5ede-48c5-a5dc-d3b59fc7e9cd_0">
											<gml:posList>35.67358999352112 139.73799774171704 42.567 35.67358022506764 139.73796665687286 42.567 35.67357540453123 139.7379689382274 42.567 35.673585172984126 139.73800002307 42.567 35.67358999352112 139.73799774171704 42.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8f8892c-16e4-4b8b-9ace-09b9b13baac4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b8f8892c-16e4-4b8b-9ace-09b9b13baac4_0">
											<gml:posList>35.67358087392583 139.7379437341981 42.969 35.673585853049936 139.73795959133602 42.969 35.673585853049936 139.73795959133602 41.314 35.67358087392583 139.7379437341981 41.314 35.67358087392583 139.7379437341981 42.969</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c98058b5-753f-483c-9820-3a38b7cd8e09">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c98058b5-753f-483c-9820-3a38b7cd8e09_0">
											<gml:posList>35.67358999352112 139.73799774171704 42.567 35.67358999352112 139.73799774171704 41.314 35.67358022506764 139.73796665687286 41.314 35.67358022506764 139.73796665687286 42.567 35.67358999352112 139.73799774171704 42.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e7d08422-5f92-42b3-b38b-db565082876c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e7d08422-5f92-42b3-b38b-db565082876c_0">
											<gml:posList>35.67358300711377 139.7379398653147 42.753 35.673588134010984 139.73793745103325 42.753 35.673588134010984 139.73793745103325 41.314 35.67358300711377 139.7379398653147 41.314 35.67358300711377 139.7379398653147 42.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-918100c4-820c-49c6-8218-d7ebd52dbc31">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-918100c4-820c-49c6-8218-d7ebd52dbc31_0">
											<gml:posList>35.673589513380364 139.73796054804447 42.753 35.67358300711377 139.7379398653147 42.753 35.67358300711377 139.7379398653147 41.314 35.673589513380364 139.73796054804447 41.314 35.673589513380364 139.73796054804447 42.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63c2bb36-4d16-4488-b006-6ac488f79582">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-63c2bb36-4d16-4488-b006-6ac488f79582_0">
											<gml:posList>35.673585172984126 139.73800002307 41.314 35.67358999352112 139.73799774171704 41.314 35.67358999352112 139.73799774171704 42.567 35.673585172984126 139.73800002307 42.567 35.673585172984126 139.73800002307 41.314</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16cb793b-1f9e-499d-84d5-917b7464369f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16cb793b-1f9e-499d-84d5-917b7464369f_0">
											<gml:posList>35.67358300711377 139.7379398653147 42.753 35.673589513380364 139.73796054804447 42.753 35.673594640269236 139.73795812271746 42.753 35.673588134010984 139.73793745103325 42.753 35.67358300711377 139.7379398653147 42.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb8d372e-2a6f-49ca-a8d0-b8af722cb939">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fb8d372e-2a6f-49ca-a8d0-b8af722cb939_0">
											<gml:posList>35.673594640269236 139.73795812271746 42.753 35.673589513380364 139.73796054804447 42.753 35.673589513380364 139.73796054804447 41.314 35.673594640269236 139.73795812271746 41.314 35.673594640269236 139.73795812271746 42.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-71c33065-6584-41e8-b0b5-1bc66bf8927c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-71c33065-6584-41e8-b0b5-1bc66bf8927c_0">
											<gml:posList>35.67359085513835 139.7379361663779 42.753 35.67359572973892 139.7379338628632 42.753 35.67359572973892 139.7379338628632 41.314 35.67359085513835 139.7379361663779 41.314 35.67359085513835 139.7379361663779 42.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a05a12d-09a5-43d4-a9ed-36c948563611">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6a05a12d-09a5-43d4-a9ed-36c948563611_0">
											<gml:posList>35.673590861667726 139.73798993066663 41.314 35.673595380019194 139.73800444065967 41.314 35.673595380019194 139.73800444065967 41.47 35.67359637405557 139.7380076319746 41.47 35.67359637405557 139.7380076319746 42.346 35.673590861667726 139.73798993066663 42.346 35.673590861667726 139.73798993066663 41.314</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2063649f-9e75-448f-9cf3-792f5609ece8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2063649f-9e75-448f-9cf3-792f5609ece8_0">
											<gml:posList>35.67359572973892 139.7379338628632 42.753 35.67359085513835 139.7379361663779 42.753 35.67359740659666 139.73795700370943 42.753 35.67360228120638 139.7379547112425 42.753 35.67359572973892 139.7379338628632 42.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2bf6ab2f-42e4-498b-97a0-eeeb695bbb62">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2bf6ab2f-42e4-498b-97a0-eeeb695bbb62_0">
											<gml:posList>35.67359572973892 139.7379338628632 42.753 35.67360228120638 139.7379547112425 42.753 35.67360228120638 139.7379547112425 41.314 35.67359572973892 139.7379338628632 41.314 35.67359572973892 139.7379338628632 42.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0877b1a9-5722-4fe9-bf8e-a68329079f85">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0877b1a9-5722-4fe9-bf8e-a68329079f85_0">
											<gml:posList>35.67360228120638 139.7379547112425 42.753 35.67359740659666 139.73795700370943 42.753 35.67359740659666 139.73795700370943 41.314 35.67360228120638 139.7379547112425 41.314 35.67360228120638 139.7379547112425 42.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a799b55b-8017-4f8f-9b06-d7d0c5a618e9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a799b55b-8017-4f8f-9b06-d7d0c5a618e9_0">
											<gml:posList>35.67361059443049 139.73798071634056 42.346 35.67361059443049 139.73798071634056 41.314 35.673590861667726 139.73798993066663 41.314 35.673590861667726 139.73798993066663 42.346 35.67361059443049 139.73798071634056 42.346</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a88e86a-070a-42c5-a445-fbf86c39c5bd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6a88e86a-070a-42c5-a445-fbf86c39c5bd_0">
											<gml:posList>35.67361059443049 139.73798071634056 42.346 35.673590861667726 139.73798993066663 42.346 35.67359637405557 139.7380076319746 42.346 35.67361610681968 139.73799841765228 42.346 35.67361059443049 139.73798071634056 42.346</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fdf35d02-dd1e-4c37-bca6-a6e5eb6f35b6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fdf35d02-dd1e-4c37-bca6-a6e5eb6f35b6_0">
											<gml:posList>35.67361610681968 139.73799841765228 42.346 35.67359637405557 139.7380076319746 42.346 35.67359637405557 139.7380076319746 41.47 35.67361610681968 139.73799841765228 41.47 35.67361610681968 139.73799841765228 42.346</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c68c9b0-c054-4e47-b1fc-6407ac3cf3fc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c68c9b0-c054-4e47-b1fc-6407ac3cf3fc_0">
											<gml:posList>35.67361511278304 139.73799522633666 41.314 35.67361059443049 139.73798071634056 41.314 35.67361059443049 139.73798071634056 42.346 35.67361610681968 139.73799841765228 42.346 35.67361610681968 139.73799841765228 41.47 35.67361511278304 139.73799522633666 41.47 35.67361511278304 139.73799522633666 41.314</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d3250646-1b88-486a-8ead-755a2a627068">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d3250646-1b88-486a-8ead-755a2a627068_0">
											<gml:posList>35.673617754836094 139.737939625127 43.044 35.67362414317232 139.7379366017746 43.044 35.67362414317232 139.7379366017746 41.314 35.673617754836094 139.737939625127 41.314 35.673617754836094 139.737939625127 43.044</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-984604db-6436-4014-9993-a78a65758cc7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-984604db-6436-4014-9993-a78a65758cc7_0">
											<gml:posList>35.673626041311024 139.73796599480167 43.044 35.673617754836094 139.737939625127 43.044 35.673617754836094 139.737939625127 41.314 35.673626041311024 139.73796599480167 41.314 35.673626041311024 139.73796599480167 43.044</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5055562c-8e33-4a4f-b3b5-5eb32bd75ed4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5055562c-8e33-4a4f-b3b5-5eb32bd75ed4_0">
											<gml:posList>35.67363243866162 139.73796297144028 43.044 35.67362414317232 139.7379366017746 43.044 35.673617754836094 139.737939625127 43.044 35.673626041311024 139.73796599480167 43.044 35.67363243866162 139.73796297144028 43.044</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e0896dd-876f-4aa2-9def-d17a845589ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9e0896dd-876f-4aa2-9def-d17a845589ea_0">
											<gml:posList>35.67362414317232 139.7379366017746 43.044 35.67363243866162 139.73796297144028 43.044 35.67363243866162 139.73796297144028 41.314 35.67362414317232 139.7379366017746 41.314 35.67362414317232 139.7379366017746 43.044</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3dc7f44b-5f53-4571-85fc-641ae66ae313">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3dc7f44b-5f53-4571-85fc-641ae66ae313_0">
											<gml:posList>35.67363243866162 139.73796297144028 43.044 35.673626041311024 139.73796599480167 43.044 35.673626041311024 139.73796599480167 41.314 35.67363243866162 139.73796297144028 41.314 35.67363243866162 139.73796297144028 43.044</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fd8a7b2e-f34e-4903-8fd9-cd74cea02f5b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fd8a7b2e-f34e-4903-8fd9-cd74cea02f5b_0">
											<gml:posList>35.67363009902507 139.7379337998705 43.044 35.67363743345132 139.73793033352297 43.044 35.67363743345132 139.73793033352297 41.314 35.67363009902507 139.7379337998705 41.314 35.67363009902507 139.7379337998705 43.044</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-06f343ab-0e21-408e-a47d-c61d793a34f9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-06f343ab-0e21-408e-a47d-c61d793a34f9_0">
											<gml:posList>35.673639406614974 139.73796340501934 43.044 35.67363009902507 139.7379337998705 43.044 35.67363009902507 139.7379337998705 41.314 35.673639406614974 139.73796340501934 41.314 35.673639406614974 139.73796340501934 43.044</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-120d2ba9-c413-4b52-8419-5aa6708eed03">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-120d2ba9-c413-4b52-8419-5aa6708eed03_0">
											<gml:posList>35.67363009902507 139.7379337998705 43.044 35.673639406614974 139.73796340501934 43.044 35.67364674104207 139.7379599386741 43.044 35.67363743345132 139.73793033352297 43.044 35.67363009902507 139.7379337998705 43.044</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f1eb832-496d-4df2-a15b-3853f19ef62a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5f1eb832-496d-4df2-a15b-3853f19ef62a_0">
											<gml:posList>35.67364674104207 139.7379599386741 43.044 35.67364674104207 139.7379599386741 41.314 35.67363743345132 139.73793033352297 41.314 35.67363743345132 139.73793033352297 43.044 35.67364674104207 139.7379599386741 43.044</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-52a156c6-987b-4e6f-ad7e-42fccc1cf733">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-52a156c6-987b-4e6f-ad7e-42fccc1cf733_0">
											<gml:posList>35.67364674104207 139.7379599386741 43.044 35.673639406614974 139.73796340501934 43.044 35.673639406614974 139.73796340501934 41.314 35.67364674104207 139.7379599386741 41.314 35.67364674104207 139.7379599386741 43.044</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_82fa9d9f-f88d-462a-8b0b-ba9a9c3c64da_BuildingInstallation_1000">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-21fdcd16-98c4-479d-bce1-5004df24e34b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-21fdcd16-98c4-479d-bce1-5004df24e34b_0">
											<gml:posList>35.67353340888309 139.73776342026153 32.869 35.67353057133325 139.73775429907562 32.869 35.67353057133325 139.73775429907562 9.14 35.67353340888309 139.73776342026153 9.14 35.67353340888309 139.73776342026153 32.869</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-061b32dd-7d07-4f5b-806d-e41433a64917">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-061b32dd-7d07-4f5b-806d-e41433a64917_0">
											<gml:posList>35.67353057133325 139.73775429907562 32.869 35.6735573682278 139.7377417954067 32.869 35.6735573682278 139.7377417954067 9.14 35.67353057133325 139.73775429907562 9.14 35.67353057133325 139.73775429907562 32.869</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9bd4e29-53b5-416d-8806-dc14da52d3fe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b9bd4e29-53b5-416d-8806-dc14da52d3fe_0">
											<gml:posList>35.6735573682278 139.7377417954067 32.869 35.673560142524714 139.73775071783007 32.869 35.673560142524714 139.73775071783007 9.14 35.6735573682278 139.7377417954067 9.14 35.6735573682278 139.7377417954067 32.869</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-577fee66-76a7-463e-8849-1c2774bd04fb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-577fee66-76a7-463e-8849-1c2774bd04fb_0">
											<gml:posList>35.673560142524714 139.73775071783007 32.869 35.67353340888309 139.73776342026153 32.869 35.67353340888309 139.73776342026153 9.14 35.673560142524714 139.73775071783007 9.14 35.673560142524714 139.73775071783007 32.869</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-652c4af4-898e-426a-9aa7-af765f5cbdf5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-652c4af4-898e-426a-9aa7-af765f5cbdf5_0">
											<gml:posList>35.67353057133325 139.73775429907562 32.869 35.67353340888309 139.73776342026153 32.869 35.673560142524714 139.73775071783007 32.869 35.6735573682278 139.7377417954067 32.869 35.67353057133325 139.73775429907562 32.869</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-34feb2d1-eec8-406d-bd5c-d1800041c9e4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67353340888309 139.73776342026153 9.14 35.67353057133325 139.73775429907562 9.14 35.6735573682278 139.7377417954067 9.14 35.673560142524714 139.73775071783007 9.14 35.67353340888309 139.73776342026153 9.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_82fa9d9f-f88d-462a-8b0b-ba9a9c3c64da_BuildingInstallation_1061">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4404a401-639d-4f80-91d2-983c4825e9ae">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673607077850114 139.7378313138544 41.314 35.67360532085867 139.73783217759032 41.314 35.6736004682516 139.73781675112716 41.314 35.67353977451885 139.73784540123964 41.314 35.6735446271398 139.73786084978624 41.314 35.67354277101475 139.7378617357323 41.314 35.67353716836313 139.73784390199341 41.314 35.67360149326528 139.7378135353153 41.314 35.673607077850114 139.7378313138544 41.314</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a119afe-95aa-4d3d-b05a-8482437fed95">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4a119afe-95aa-4d3d-b05a-8482437fed95_0">
											<gml:posList>35.673607077850114 139.7378313138544 42.589 35.673607077850114 139.7378313138544 41.314 35.67360149326528 139.7378135353153 41.314 35.67360149326528 139.7378135353153 42.589 35.673607077850114 139.7378313138544 42.589</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-830f7e21-127d-44bf-b848-d9dd6c1546b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-830f7e21-127d-44bf-b848-d9dd6c1546b1_0">
											<gml:posList>35.6736004682516 139.73781675112716 42.589 35.6736004682516 139.73781675112716 41.314 35.67360532085867 139.73783217759032 41.314 35.67360532085867 139.73783217759032 42.589 35.6736004682516 139.73781675112716 42.589</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1419544e-905f-4f58-81b9-05e5629bf881">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1419544e-905f-4f58-81b9-05e5629bf881_0">
											<gml:posList>35.67360149326528 139.7378135353153 41.314 35.67353716836313 139.73784390199341 41.314 35.67353716836313 139.73784390199341 42.589 35.67360149326528 139.7378135353153 42.589 35.67360149326528 139.7378135353153 41.314</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2065be78-56ce-48d9-abe0-50a459c791fb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2065be78-56ce-48d9-abe0-50a459c791fb_0">
											<gml:posList>35.67353977451885 139.73784540123964 41.314 35.6736004682516 139.73781675112716 41.314 35.6736004682516 139.73781675112716 42.589 35.67353977451885 139.73784540123964 42.589 35.67353977451885 139.73784540123964 41.314</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81fc0686-5906-489e-8240-c0c4b394921b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81fc0686-5906-489e-8240-c0c4b394921b_0">
											<gml:posList>35.67360532085867 139.73783217759032 42.589 35.67360532085867 139.73783217759032 41.314 35.673607077850114 139.7378313138544 41.314 35.673607077850114 139.7378313138544 42.589 35.67360532085867 139.73783217759032 42.589</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b11ced5c-5cef-4732-8670-b8f1b088b84c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b11ced5c-5cef-4732-8670-b8f1b088b84c_0">
											<gml:posList>35.6736004682516 139.73781675112716 42.589 35.67360532085867 139.73783217759032 42.589 35.673607077850114 139.7378313138544 42.589 35.67360149326528 139.7378135353153 42.589 35.67353716836313 139.73784390199341 42.589 35.67354277101475 139.7378617357323 42.589 35.6735446271398 139.73786084978624 42.589 35.67353977451885 139.73784540123964 42.589 35.6736004682516 139.73781675112716 42.589</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3eaf7ab6-e175-48c0-a965-330dcb487333">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3eaf7ab6-e175-48c0-a965-330dcb487333_0">
											<gml:posList>35.67353716836313 139.73784390199341 42.589 35.67353716836313 139.73784390199341 41.314 35.67354277101475 139.7378617357323 41.314 35.67354277101475 139.7378617357323 42.589 35.67353716836313 139.73784390199341 42.589</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-93217949-e713-4749-932d-7c418ffa6f5c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-93217949-e713-4749-932d-7c418ffa6f5c_0">
											<gml:posList>35.6735446271398 139.73786084978624 42.589 35.6735446271398 139.73786084978624 41.314 35.67353977451885 139.73784540123964 41.314 35.67353977451885 139.73784540123964 42.589 35.6735446271398 139.73786084978624 42.589</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-041fbaab-46ec-4867-a0e7-1e64e457ff0c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-041fbaab-46ec-4867-a0e7-1e64e457ff0c_0">
											<gml:posList>35.67354277101475 139.7378617357323 42.589 35.67354277101475 139.7378617357323 41.314 35.6735446271398 139.73786084978624 41.314 35.6735446271398 139.73786084978624 42.589 35.67354277101475 139.7378617357323 42.589</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_82fa9d9f-f88d-462a-8b0b-ba9a9c3c64da_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dcb77ca9-0e96-4311-993e-b8bb27b69abf">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6736369946559 139.738070583049 8.98 35.673611594338 139.73808243320568 8.98 35.67360142800908 139.73804971390362 8.98 35.67362682831504 139.7380378526914 8.98 35.6736369946559 139.738070583049 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58c5c5eb-13e6-4105-9a34-6bdb9d92b071">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-58c5c5eb-13e6-4105-9a34-6bdb9d92b071_0">
											<gml:posList>35.67360142800908 139.73804971390362 8.98 35.673611594338 139.73808243320568 8.98 35.673611603351716 139.73808243319496 34.49 35.67360906402157 139.73807425060434 34.49 35.67360143701405 139.73804970284624 36.453 35.67360142800908 139.73804971390362 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4c214e5-78ce-48f3-837a-2a1b7ff9e30e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4c214e5-78ce-48f3-837a-2a1b7ff9e30e_0">
											<gml:posList>35.67361414167842 139.73804377775903 36.453 35.67360143701405 139.73804970284624 36.453 35.67360906402157 139.73807425060434 34.49 35.67362175967341 139.73806832553117 34.49 35.67361414167842 139.73804377775903 36.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f6130299-88e8-4021-b5a8-44c369c70901">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f6130299-88e8-4021-b5a8-44c369c70901_0">
											<gml:posList>35.6736141326647 139.73804377776975 33.257 35.67362682831504 139.7380378526914 33.257 35.67362682831504 139.7380378526914 8.98 35.67360142800908 139.73804971390362 8.98 35.67360143701405 139.73804970284624 36.453 35.67361414167842 139.73804377775903 36.453 35.6736141326647 139.73804377776975 33.257</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e40594d-314b-46e7-816a-5ddc7c88acc6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9e40594d-314b-46e7-816a-5ddc7c88acc6_0">
											<gml:posList>35.67362175967341 139.73806832553117 34.49 35.6736141326647 139.73804377776975 33.257 35.67361414167842 139.73804377775903 36.453 35.67362175967341 139.73806832553117 34.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-088cc21f-5bb3-470d-880f-8f8e608ba910">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-088cc21f-5bb3-470d-880f-8f8e608ba910_0">
											<gml:posList>35.67360906402157 139.73807425060434 34.49 35.673611603351716 139.73808243319496 34.49 35.67363700366961 139.73807058303828 34.49 35.67363445532494 139.73806240045613 34.49 35.67362175967341 139.73806832553117 34.49 35.67360906402157 139.73807425060434 34.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-50cc7271-c41d-4589-92f9-80da6ecbb027">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-50cc7271-c41d-4589-92f9-80da6ecbb027_0">
											<gml:posList>35.6736369946559 139.738070583049 8.98 35.67363700366961 139.73807058303828 34.49 35.673611603351716 139.73808243319496 34.49 35.673611594338 139.73808243320568 8.98 35.6736369946559 139.738070583049 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-786ed21b-43ed-4ca5-9527-f5ba5c3d0943">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-786ed21b-43ed-4ca5-9527-f5ba5c3d0943_0">
											<gml:posList>35.67363445532494 139.73806240045613 34.49 35.67362682831504 139.7380378526914 33.257 35.6736141326647 139.73804377776975 33.257 35.67362175967341 139.73806832553117 34.49 35.67363445532494 139.73806240045613 34.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70bcc3c2-199a-4391-a096-c84dcfe53e9f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-70bcc3c2-199a-4391-a096-c84dcfe53e9f_0">
											<gml:posList>35.67363700366961 139.73807058303828 34.49 35.6736369946559 139.738070583049 8.98 35.67362682831504 139.7380378526914 8.98 35.67362682831504 139.7380378526914 33.257 35.67363445532494 139.73806240045613 34.49 35.67363700366961 139.73807058303828 34.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_82fa9d9f-f88d-462a-8b0b-ba9a9c3c64da_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-688a9c5e-3d11-4a29-9d8c-dd07a33328c2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67360531184495 139.73783217760106 41.314 35.67363190630747 139.737916774744 41.314 35.67357121255988 139.73794543583878 41.314 35.6735446271398 139.73786084978624 41.314 35.67360531184495 139.73783217760106 41.314</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec63cfd3-16a4-4a2b-b49e-420ec7bf0f69">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67363857619736 139.73799609321662 36.453 35.67365547969419 139.73798819681005 36.453 35.673665329755174 139.73801990020485 36.453 35.67364842625629 139.7380277966057 36.453 35.67363857619736 139.73799609321662 36.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c687f1b1-1016-4013-8e1e-91a522f1a71e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67364842625629 139.7380277966057 36.453 35.673665329755174 139.73801990020485 36.453 35.67366586291986 139.73802161181132 36.346 35.67364895941212 139.73802949716514 36.347 35.67364842625629 139.7380277966057 36.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-22fd1c04-4483-4506-a724-5b8369f0dc45">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-22fd1c04-4483-4506-a724-5b8369f0dc45_0">
											<gml:posList>35.67357121255988 139.73794543583878 45.127 35.6735446271398 139.73786084978624 45.127 35.6735446271398 139.73786084978624 41.314 35.67357121255988 139.73794543583878 41.314 35.67357121255988 139.73794543583878 45.127</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e59a20b-1df5-4e5b-b808-a32527718c52">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e59a20b-1df5-4e5b-b808-a32527718c52_0">
											<gml:posList>35.67360531184495 139.73783217760106 45.127 35.67360531184495 139.73783217760106 41.314 35.6735446271398 139.73786084978624 41.314 35.6735446271398 139.73786084978624 45.127 35.67360531184495 139.73783217760106 45.127</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e3f0c82-e359-4767-b2db-5827c587b3f4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6e3f0c82-e359-4767-b2db-5827c587b3f4_0">
											<gml:posList>35.67363190630747 139.737916774744 45.127 35.67360531184495 139.73783217760106 45.127 35.6735446271398 139.73786084978624 45.127 35.67357121255988 139.73794543583878 45.127 35.67363190630747 139.737916774744 45.127</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29ff7f4e-b141-401c-82b4-869b7e8a558d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29ff7f4e-b141-401c-82b4-869b7e8a558d_0">
											<gml:posList>35.67363190630747 139.737916774744 41.314 35.67363190630747 139.737916774744 45.127 35.67357121255988 139.73794543583878 45.127 35.67357121255988 139.73794543583878 41.314 35.67363190630747 139.737916774744 41.314</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2fa451c0-a495-49b4-801c-7bbfb87423a7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2fa451c0-a495-49b4-801c-7bbfb87423a7_0">
											<gml:posList>35.67360531184495 139.73783217760106 45.127 35.67363190630747 139.737916774744 45.127 35.67363190630747 139.737916774744 41.314 35.67360531184495 139.73783217760106 41.314 35.67360531184495 139.73783217760106 45.127</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b01e9970-f224-43fb-8bd7-3a22ba6021f2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b01e9970-f224-43fb-8bd7-3a22ba6021f2_0">
											<gml:posList>35.67364842625629 139.7380277966057 36.453 35.67364895941212 139.73802949716514 36.347 35.67364895941212 139.73802949716514 38.478 35.67363857619736 139.73799609321662 38.478 35.67363857619736 139.73799609321662 36.453 35.67364842625629 139.7380277966057 36.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6763ba8e-1c65-4bbc-95e4-92d00849791e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6763ba8e-1c65-4bbc-95e4-92d00849791e_0">
											<gml:posList>35.67363857619736 139.73799609321662 38.478 35.67365547969419 139.73798819681005 38.478 35.67365547969419 139.73798819681005 36.453 35.67363857619736 139.73799609321662 36.453 35.67363857619736 139.73799609321662 38.478</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da2cb4fa-5645-4564-b183-da92bb6f95a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da2cb4fa-5645-4564-b183-da92bb6f95a6_0">
											<gml:posList>35.67364895941212 139.73802949716514 38.478 35.67366586291986 139.73802161181132 38.478 35.67365547969419 139.73798819681005 38.478 35.67363857619736 139.73799609321662 38.478 35.67364895941212 139.73802949716514 38.478</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-853bb33c-18ee-4439-b308-62a664096f86">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-853bb33c-18ee-4439-b308-62a664096f86_0">
											<gml:posList>35.67366586291986 139.73802161181132 38.478 35.67364895941212 139.73802949716514 38.478 35.67364895941212 139.73802949716514 36.347 35.67366586291986 139.73802161181132 36.346 35.67366586291986 139.73802161181132 38.478</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74192110-6d0d-400f-a86e-f922ea471da1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-74192110-6d0d-400f-a86e-f922ea471da1_0">
											<gml:posList>35.673665329755174 139.73801990020485 36.453 35.67365547969419 139.73798819681005 36.453 35.67365547969419 139.73798819681005 38.478 35.67366586291986 139.73802161181132 38.478 35.67366586291986 139.73802161181132 36.346 35.673665329755174 139.73801990020485 36.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-fd02a6c9-9dcc-48a4-9d3b-fa2829d92bfc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fd02a6c9-9dcc-48a4-9d3b-fa2829d92bfc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fd02a6c9-9dcc-48a4-9d3b-fa2829d92bfc">
											<gml:posList>35.67367867007536 139.73804268476124 8.98 35.67363470834708 139.7380632065651 8.98 35.67362682831504 139.7380378526914 8.98 35.67359581452624 139.73805232759727 8.98 35.67350948630999 139.7377745948906 8.98 35.67358439848891 139.73773939918212 8.98 35.67367867007536 139.73804268476124 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b81fdde0-d40c-4ab8-bdec-45ce82a3341c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b81fdde0-d40c-4ab8-bdec-45ce82a3341c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b81fdde0-d40c-4ab8-bdec-45ce82a3341c">
											<gml:posList>35.67351401315983 139.73777706395347 33.386 35.67350948630999 139.7377745948906 33.386 35.67352085457912 139.73781114589008 33.386 35.673524143367786 139.7378096064812 33.386 35.67351401315983 139.73777706395347 33.386</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c24cacdc-21c7-4ca1-ac3f-a37a59d7c30d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c24cacdc-21c7-4ca1-ac3f-a37a59d7c30d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c24cacdc-21c7-4ca1-ac3f-a37a59d7c30d">
											<gml:posList>35.67357230061319 139.7378170719018 38.915 35.67356444683417 139.73779079011814 38.915 35.67352085457912 139.73781114589008 38.915 35.67352897866011 139.73783729477913 38.915 35.67357230061319 139.7378170719018 38.915</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7d7cca03-a3d4-42fb-9f0a-8913374c23d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d7cca03-a3d4-42fb-9f0a-8913374c23d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d7cca03-a3d4-42fb-9f0a-8913374c23d4">
											<gml:posList>35.67350948630999 139.7377745948906 33.386 35.67351401315983 139.73777706395347 33.386 35.67358235677757 139.7377449470603 33.386 35.67358439848891 139.73773939918212 33.386 35.67350948630999 139.7377745948906 33.386</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-05f7f37b-b77d-4a32-8ec3-afdf125aaa88">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-05f7f37b-b77d-4a32-8ec3-afdf125aaa88">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-05f7f37b-b77d-4a32-8ec3-afdf125aaa88">
											<gml:posList>35.67357230061319 139.7378170719018 41.47 35.67352897866011 139.73783729477913 41.47 35.67353319892838 139.73783962060432 41.47 35.67357647583076 139.73781941987423 41.47 35.67357230061319 139.7378170719018 41.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-31a759ca-4ed3-42fc-ae8a-d8700d860fb5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31a759ca-4ed3-42fc-ae8a-d8700d860fb5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31a759ca-4ed3-42fc-ae8a-d8700d860fb5">
											<gml:posList>35.67351401315983 139.73777706395347 32.754 35.673524143367786 139.7378096064812 32.754 35.67356444683417 139.73779079011814 32.754 35.67359219740676 139.73777604283887 32.754 35.67358235677757 139.7377449470603 32.754 35.67351401315983 139.73777706395347 32.754</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-82d1e8ff-8a7e-48a3-8757-967293d3fa67">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-82d1e8ff-8a7e-48a3-8757-967293d3fa67">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-82d1e8ff-8a7e-48a3-8757-967293d3fa67">
											<gml:posList>35.67358393120177 139.73801407594982 41.47 35.67358581998966 139.73800890384805 41.47 35.67353319892838 139.73783962060432 41.47 35.67352897866011 139.73783729477913 41.47 35.67358393120177 139.73801407594982 41.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-641e336c-14e3-46f4-9f8f-1f70d8ce9079">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-641e336c-14e3-46f4-9f8f-1f70d8ce9079">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-641e336c-14e3-46f4-9f8f-1f70d8ce9079">
											<gml:posList>35.67357230061319 139.7378170719018 41.47 35.67357647583076 139.73781941987423 41.47 35.67356856783847 139.73779297245312 41.47 35.67356444683417 139.73779079011814 41.47 35.67357230061319 139.7378170719018 41.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fa80d17a-291b-42f1-a26f-f21f02dc9d6f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa80d17a-291b-42f1-a26f-f21f02dc9d6f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa80d17a-291b-42f1-a26f-f21f02dc9d6f">
											<gml:posList>35.67356444683417 139.73779079011814 41.47 35.67356856783847 139.73779297245312 41.47 35.67359343524035 139.737779764102 41.47 35.673595278800555 139.73777440425405 41.47 35.67356444683417 139.73779079011814 41.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a4bd5c9f-db68-4c65-936e-cf65ad0ac06f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4bd5c9f-db68-4c65-936e-cf65ad0ac06f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4bd5c9f-db68-4c65-936e-cf65ad0ac06f">
											<gml:posList>35.67358235677757 139.7377449470603 33.386 35.67359219740676 139.73777604283887 33.386 35.673595278800555 139.73777440425405 33.386 35.67358439848891 139.73773939918212 33.386 35.67358235677757 139.7377449470603 33.386</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-95b8e871-7ee1-4b6b-a323-0152bcdd2cf2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-95b8e871-7ee1-4b6b-a323-0152bcdd2cf2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-95b8e871-7ee1-4b6b-a323-0152bcdd2cf2">
											<gml:posList>35.67357647583076 139.73781941987423 41.314 35.67353319892838 139.73783962060432 41.314 35.67358581998966 139.73800890384805 41.314 35.67365466841937 139.7379767644297 41.314 35.67359343524035 139.737779764102 41.314 35.67356856783847 139.73779297245312 41.314 35.67357647583076 139.73781941987423 41.314</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-243a8da2-e880-4faa-a5f5-80716082c2c8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-243a8da2-e880-4faa-a5f5-80716082c2c8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-243a8da2-e880-4faa-a5f5-80716082c2c8">
											<gml:posList>35.67365889768983 139.73797907920843 41.47 35.67365466841937 139.7379767644297 41.47 35.67358581998966 139.73800890384805 41.47 35.67358393120177 139.73801407594982 41.47 35.67365889768983 139.73797907920843 41.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e058d48d-fadb-4349-92f6-06c3822cbd9f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e058d48d-fadb-4349-92f6-06c3822cbd9f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e058d48d-fadb-4349-92f6-06c3822cbd9f">
											<gml:posList>35.673595278800555 139.73777440425405 41.47 35.67359343524035 139.737779764102 41.47 35.67365466841937 139.7379767644297 41.47 35.67365889768983 139.73797907920843 41.47 35.673595278800555 139.73777440425405 41.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c9b31798-c29c-4bb0-a410-4bfa346a3e08">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c9b31798-c29c-4bb0-a410-4bfa346a3e08">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c9b31798-c29c-4bb0-a410-4bfa346a3e08">
											<gml:posList>35.67362682831504 139.7380378526914 36.453 35.673640352947245 139.73803157313102 36.453 35.67367079906149 139.73801734191167 36.453 35.67365889768983 139.73797907920843 36.453 35.67358393120177 139.73801407594982 36.453 35.67359581452624 139.73805232759727 36.453 35.67362682831504 139.7380378526914 36.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-edf306b5-7fde-4fea-9428-c27312270c7f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-edf306b5-7fde-4fea-9428-c27312270c7f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-edf306b5-7fde-4fea-9428-c27312270c7f">
											<gml:posList>35.673640352947245 139.73803157313102 36.453 35.67362682831504 139.7380378526914 36.453 35.67363470834708 139.7380632065651 34.876 35.67367867007536 139.73804268476124 34.876 35.67367079906149 139.73801734191167 36.453 35.673640352947245 139.73803157313102 36.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-90b87664-10d3-452f-b62f-306b81921434">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-90b87664-10d3-452f-b62f-306b81921434">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-90b87664-10d3-452f-b62f-306b81921434">
											<gml:posList>35.67358581998966 139.73800890384805 41.47 35.67358581998966 139.73800890384805 41.314 35.67353319892838 139.73783962060432 41.314 35.67353319892838 139.73783962060432 41.47 35.67358581998966 139.73800890384805 41.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cbf922c7-62d3-4bdf-9a3a-d4193b6c5bd6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cbf922c7-62d3-4bdf-9a3a-d4193b6c5bd6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cbf922c7-62d3-4bdf-9a3a-d4193b6c5bd6">
											<gml:posList>35.67358235677757 139.7377449470603 33.386 35.67358235677757 139.7377449470603 32.754 35.67359219740676 139.73777604283887 32.754 35.67359219740676 139.73777604283887 33.386 35.67358235677757 139.7377449470603 33.386</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-85dacc02-d653-4a92-a162-f89cd7edd033">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85dacc02-d653-4a92-a162-f89cd7edd033">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85dacc02-d653-4a92-a162-f89cd7edd033">
											<gml:posList>35.67358439848891 139.73773939918212 8.98 35.67350948630999 139.7377745948906 8.98 35.67350948630999 139.7377745948906 33.386 35.67358439848891 139.73773939918212 33.386 35.67358439848891 139.73773939918212 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-67aaa366-80e9-40ab-8f28-cf2875a0cd6b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67aaa366-80e9-40ab-8f28-cf2875a0cd6b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67aaa366-80e9-40ab-8f28-cf2875a0cd6b">
											<gml:posList>35.67351401315983 139.73777706395347 33.386 35.67351401315983 139.73777706395347 32.754 35.67358235677757 139.7377449470603 32.754 35.67358235677757 139.7377449470603 33.386 35.67351401315983 139.73777706395347 33.386</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6c5cf20b-a158-4d70-8b15-f44c98f4a3a4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c5cf20b-a158-4d70-8b15-f44c98f4a3a4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c5cf20b-a158-4d70-8b15-f44c98f4a3a4">
											<gml:posList>35.67356444683417 139.73779079011814 38.915 35.67356444683417 139.73779079011814 41.47 35.673595278800555 139.73777440425405 41.47 35.673595278800555 139.73777440425405 33.386 35.67359219740676 139.73777604283887 33.386 35.67359219740676 139.73777604283887 32.754 35.67356444683417 139.73779079011814 32.754 35.67356444683417 139.73779079011814 38.915</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e75bdf9d-05c1-4e94-886c-d1a3f310833e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e75bdf9d-05c1-4e94-886c-d1a3f310833e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e75bdf9d-05c1-4e94-886c-d1a3f310833e">
											<gml:posList>35.67356856783847 139.73779297245312 41.47 35.67356856783847 139.73779297245312 41.314 35.67359343524035 139.737779764102 41.314 35.67359343524035 139.737779764102 41.47 35.67356856783847 139.73779297245312 41.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cb120126-9811-495b-ab69-bf4ab6ac750f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb120126-9811-495b-ab69-bf4ab6ac750f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb120126-9811-495b-ab69-bf4ab6ac750f">
											<gml:posList>35.673524143367786 139.7378096064812 33.386 35.673524143367786 139.7378096064812 32.754 35.67351401315983 139.73777706395347 32.754 35.67351401315983 139.73777706395347 33.386 35.673524143367786 139.7378096064812 33.386</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cee41064-f0ae-4e8d-ad33-2817cdeca6d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cee41064-f0ae-4e8d-ad33-2817cdeca6d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cee41064-f0ae-4e8d-ad33-2817cdeca6d3">
											<gml:posList>35.673524143367786 139.7378096064812 33.386 35.67352085457912 139.73781114589008 33.386 35.67352085457912 139.73781114589008 38.915 35.67356444683417 139.73779079011814 38.915 35.67356444683417 139.73779079011814 32.754 35.673524143367786 139.7378096064812 32.754 35.673524143367786 139.7378096064812 33.386</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8c3fc4d7-f4a7-4081-9bed-32cbbc726509">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c3fc4d7-f4a7-4081-9bed-32cbbc726509">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c3fc4d7-f4a7-4081-9bed-32cbbc726509">
											<gml:posList>35.67357230061319 139.7378170719018 41.47 35.67356444683417 139.73779079011814 41.47 35.67356444683417 139.73779079011814 38.915 35.67357230061319 139.7378170719018 38.915 35.67357230061319 139.7378170719018 41.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-45b92af2-8a50-4eb1-b055-6d94217d77ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45b92af2-8a50-4eb1-b055-6d94217d77ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45b92af2-8a50-4eb1-b055-6d94217d77ba">
											<gml:posList>35.67357647583076 139.73781941987423 41.47 35.67357647583076 139.73781941987423 41.314 35.67356856783847 139.73779297245312 41.314 35.67356856783847 139.73779297245312 41.47 35.67357647583076 139.73781941987423 41.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fa60f0ce-63b2-4d7d-9296-ee1e8acef7b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa60f0ce-63b2-4d7d-9296-ee1e8acef7b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa60f0ce-63b2-4d7d-9296-ee1e8acef7b6">
											<gml:posList>35.67352897866011 139.73783729477913 41.47 35.67357230061319 139.7378170719018 41.47 35.67357230061319 139.7378170719018 38.915 35.67352897866011 139.73783729477913 38.915 35.67352897866011 139.73783729477913 41.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-664d95df-a473-40a7-bdb3-4fdcbecbf041">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-664d95df-a473-40a7-bdb3-4fdcbecbf041">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-664d95df-a473-40a7-bdb3-4fdcbecbf041">
											<gml:posList>35.67353319892838 139.73783962060432 41.47 35.67353319892838 139.73783962060432 41.314 35.67357647583076 139.73781941987423 41.314 35.67357647583076 139.73781941987423 41.47 35.67353319892838 139.73783962060432 41.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-47650654-bf27-4d3c-ab7b-a80bcddad5f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47650654-bf27-4d3c-ab7b-a80bcddad5f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47650654-bf27-4d3c-ab7b-a80bcddad5f6">
											<gml:posList>35.67359343524035 139.737779764102 41.47 35.67359343524035 139.737779764102 41.314 35.67365466841937 139.7379767644297 41.314 35.67365466841937 139.7379767644297 41.47 35.67359343524035 139.737779764102 41.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d9cb9adb-4bed-42b1-a8ce-43ac5470161f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d9cb9adb-4bed-42b1-a8ce-43ac5470161f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d9cb9adb-4bed-42b1-a8ce-43ac5470161f">
											<gml:posList>35.67358439848891 139.73773939918212 8.98 35.67358439848891 139.73773939918212 33.386 35.673595278800555 139.73777440425405 33.386 35.673595278800555 139.73777440425405 41.47 35.67365889768983 139.73797907920843 41.47 35.67365889768983 139.73797907920843 36.453 35.67367079906149 139.73801734191167 36.453 35.67367867007536 139.73804268476124 34.876 35.67367867007536 139.73804268476124 8.98 35.67358439848891 139.73773939918212 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e3a69b28-b2a6-487d-bc89-e2596bf2b64d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e3a69b28-b2a6-487d-bc89-e2596bf2b64d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e3a69b28-b2a6-487d-bc89-e2596bf2b64d">
											<gml:posList>35.67352085457912 139.73781114589008 33.386 35.67350948630999 139.7377745948906 33.386 35.67350948630999 139.7377745948906 8.98 35.67359581452624 139.73805232759727 8.98 35.67359581452624 139.73805232759727 36.453 35.67358393120177 139.73801407594982 36.453 35.67358393120177 139.73801407594982 41.47 35.67352897866011 139.73783729477913 41.47 35.67352897866011 139.73783729477913 38.915 35.67352085457912 139.73781114589008 38.915 35.67352085457912 139.73781114589008 33.386</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-61fc309c-5ee5-4994-a8cd-86ae33d042b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61fc309c-5ee5-4994-a8cd-86ae33d042b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61fc309c-5ee5-4994-a8cd-86ae33d042b4">
											<gml:posList>35.67365466841937 139.7379767644297 41.47 35.67365466841937 139.7379767644297 41.314 35.67358581998966 139.73800890384805 41.314 35.67358581998966 139.73800890384805 41.47 35.67365466841937 139.7379767644297 41.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dd760f56-96f2-4220-99ae-3c5f98f03347">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd760f56-96f2-4220-99ae-3c5f98f03347">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd760f56-96f2-4220-99ae-3c5f98f03347">
											<gml:posList>35.67365889768983 139.73797907920843 36.453 35.67365889768983 139.73797907920843 41.47 35.67358393120177 139.73801407594982 41.47 35.67358393120177 139.73801407594982 36.453 35.67365889768983 139.73797907920843 36.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2db6dd4d-fd96-4ee9-9e48-e79ffc710f89">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2db6dd4d-fd96-4ee9-9e48-e79ffc710f89">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2db6dd4d-fd96-4ee9-9e48-e79ffc710f89">
											<gml:posList>35.67359581452624 139.73805232759727 36.453 35.67359581452624 139.73805232759727 8.98 35.67362682831504 139.7380378526914 8.98 35.67362682831504 139.7380378526914 36.453 35.67359581452624 139.73805232759727 36.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d54ac6a9-3898-4d9f-a098-fa9f219276ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d54ac6a9-3898-4d9f-a098-fa9f219276ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d54ac6a9-3898-4d9f-a098-fa9f219276ce">
											<gml:posList>35.67362682831504 139.7380378526914 8.98 35.67363470834708 139.7380632065651 8.98 35.67363470834708 139.7380632065651 34.876 35.67362682831504 139.7380378526914 36.453 35.67362682831504 139.7380378526914 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-44f6bac4-2d5a-4050-b5be-759ec6913f16">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44f6bac4-2d5a-4050-b5be-759ec6913f16">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44f6bac4-2d5a-4050-b5be-759ec6913f16">
											<gml:posList>35.67363470834708 139.7380632065651 8.98 35.67367867007536 139.73804268476124 8.98 35.67367867007536 139.73804268476124 34.876 35.67363470834708 139.7380632065651 34.876 35.67363470834708 139.7380632065651 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7483</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">570.39703</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1241</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.03</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>