<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_830c6d09-4edc-4fb3-8f42-f90f324ca8df">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">403</bldg:usage>
			<bldg:measuredHeight uom="m">11.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67076120743123 139.74166736533155 0 35.67069950208654 139.74159983250158 0 35.67063431061395 139.74168905068706 0 35.67069601599331 139.74175669399392 0 35.67076120743123 139.74166736533155 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67076120743123 139.74166736533155 8.67 35.67069601599331 139.74175669399392 8.67 35.67063431061395 139.74168905068706 8.67 35.67069950208654 139.74159983250158 8.67 35.67076120743123 139.74166736533155 8.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67076120743123 139.74166736533155 8.67 35.67069950208654 139.74159983250158 8.67 35.67069950208654 139.74159983250158 20.49 35.67076120743123 139.74166736533155 20.49 35.67076120743123 139.74166736533155 8.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67069950208654 139.74159983250158 8.67 35.67063431061395 139.74168905068706 8.67 35.67063431061395 139.74168905068706 20.49 35.67069950208654 139.74159983250158 20.49 35.67069950208654 139.74159983250158 8.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67063431061395 139.74168905068706 8.67 35.67069601599331 139.74175669399392 8.67 35.67069601599331 139.74175669399392 20.49 35.67063431061395 139.74168905068706 20.49 35.67063431061395 139.74168905068706 8.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67069601599331 139.74175669399392 8.67 35.67076120743123 139.74166736533155 8.67 35.67076120743123 139.74166736533155 20.49 35.67069601599331 139.74175669399392 20.49 35.67069601599331 139.74175669399392 8.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67076120743123 139.74166736533155 20.49 35.67069950208654 139.74159983250158 20.49 35.67063431061395 139.74168905068706 20.49 35.67069601599331 139.74175669399392 20.49 35.67076120743123 139.74166736533155 20.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-17c410d0-b86d-49f2-ba81-f852ecdc5237"/>
							<gml:surfaceMember xlink:href="#poly-5a217415-82a4-4e0c-b877-188931af467e"/>
							<gml:surfaceMember xlink:href="#poly-c428ae63-d1ff-4117-a7c9-c4ff323f6fe0"/>
							<gml:surfaceMember xlink:href="#poly-c3dc03dc-9e97-40d1-a73c-71ead101f4fe"/>
							<gml:surfaceMember xlink:href="#poly-7bb3fdd5-3229-4e2d-a107-dbdbf6a7a27f"/>
							<gml:surfaceMember xlink:href="#poly-8d958254-26da-4916-9948-82e5ea658190"/>
							<gml:surfaceMember xlink:href="#poly-66874c1a-f5b9-43f3-8592-b446603df378"/>
							<gml:surfaceMember xlink:href="#poly-bcd47e3d-cfd6-468a-a439-67c35ebdfce9"/>
							<gml:surfaceMember xlink:href="#poly-4b9a06cc-314a-4711-8e16-8688a79370aa"/>
							<gml:surfaceMember xlink:href="#poly-d7ae1e8f-500e-4d52-851b-fd5cb7ead078"/>
							<gml:surfaceMember xlink:href="#poly-858bd252-7d7f-4a9b-9890-baf3d73c78e2"/>
							<gml:surfaceMember xlink:href="#poly-208aec70-7981-4909-986f-caea74ba70b3"/>
							<gml:surfaceMember xlink:href="#poly-61c6eb59-6f44-4850-b64b-ef57a7d81daf"/>
							<gml:surfaceMember xlink:href="#poly-b1a0957b-8b58-4b58-a903-2796b14a6c05"/>
							<gml:surfaceMember xlink:href="#poly-7a2b0dbf-05f5-4b29-87b4-e231304c1d7f"/>
							<gml:surfaceMember xlink:href="#poly-8d6111fe-cc22-41a8-a8dc-bce79ea93767"/>
							<gml:surfaceMember xlink:href="#poly-5ef01c52-4eda-476f-93ba-cb6e16d16f6b"/>
							<gml:surfaceMember xlink:href="#poly-78d3f0bf-05c7-4836-b215-98c51a29d968"/>
							<gml:surfaceMember xlink:href="#poly-190f7b00-6011-41cd-a3ed-1d2dc4079537"/>
							<gml:surfaceMember xlink:href="#poly-49e44567-f861-435a-af4e-28e8977326e1"/>
							<gml:surfaceMember xlink:href="#poly-0445ad00-a5c1-42c9-97a1-5e6273636b7d"/>
							<gml:surfaceMember xlink:href="#poly-16153eab-6497-4530-b2e8-d3777bb8219d"/>
							<gml:surfaceMember xlink:href="#poly-51545bb8-9f65-414d-95d1-8ebe78bf5d80"/>
							<gml:surfaceMember xlink:href="#poly-5e7fe379-7bca-4da0-bc14-21f53d864a10"/>
							<gml:surfaceMember xlink:href="#poly-b7524f3b-9084-4f9f-a827-8c4d3778ac40"/>
							<gml:surfaceMember xlink:href="#poly-9b7bf9b8-cd59-426c-8d19-e469a909a3da"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_830c6d09-4edc-4fb3-8f42-f90f324ca8df_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0c3e4b4e-c4fe-4bb8-934e-c2d0af1f7d16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67071826615887 139.7416320331078 16.805 35.67065452679197 139.74171061204447 16.805 35.67064030027388 139.74169501988655 16.805 35.67070883038752 139.74161047046655 16.805 35.67072308396597 139.74162607363812 16.805 35.67071826615887 139.7416320331078 16.805</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd3732e6-efdf-43e3-b45b-13c404141716">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dd3732e6-efdf-43e3-b45b-13c404141716_0">
											<gml:posList>35.67070883038752 139.74161047046655 20.196 35.67072308396597 139.74162607363812 20.196 35.67072308396597 139.74162607363812 16.805 35.67070883038752 139.74161047046655 16.805 35.67070883038752 139.74161047046655 20.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b953ecfb-e304-45c5-80b5-3364db8fd9d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b953ecfb-e304-45c5-80b5-3364db8fd9d6_0">
											<gml:posList>35.67071826615887 139.7416320331078 20.196 35.67071826615887 139.7416320331078 16.805 35.67072308396597 139.74162607363812 16.805 35.67072308396597 139.74162607363812 20.196 35.67071826615887 139.7416320331078 20.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43c51aed-414d-4971-b70f-65041736119d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-43c51aed-414d-4971-b70f-65041736119d_0">
											<gml:posList>35.67064030027388 139.74169501988655 20.196 35.67070883038752 139.74161047046655 20.196 35.67070883038752 139.74161047046655 16.805 35.67064030027388 139.74169501988655 16.805 35.67064030027388 139.74169501988655 20.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c210561-7d1a-4a77-acdc-d71ecb34fc3a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c210561-7d1a-4a77-acdc-d71ecb34fc3a_0">
											<gml:posList>35.67070883038752 139.74161047046655 20.196 35.67064030027388 139.74169501988655 20.196 35.67065452679197 139.74171061204447 20.196 35.67071826615887 139.7416320331078 20.196 35.67072308396597 139.74162607363812 20.196 35.67070883038752 139.74161047046655 20.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-647da170-8b4c-4efd-ac32-3c2556ca870f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-647da170-8b4c-4efd-ac32-3c2556ca870f_0">
											<gml:posList>35.67071826615887 139.7416320331078 16.805 35.67071826615887 139.7416320331078 20.196 35.67065452679197 139.74171061204447 20.196 35.67065452679197 139.74171061204447 16.805 35.67071826615887 139.7416320331078 16.805</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e0ba1540-ef77-4f9e-be38-0af85269a6ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e0ba1540-ef77-4f9e-be38-0af85269a6ce_0">
											<gml:posList>35.67065452679197 139.74171061204447 16.805 35.67065452679197 139.74171061204447 20.196 35.67064030027388 139.74169501988655 20.196 35.67064030027388 139.74169501988655 16.805 35.67065452679197 139.74171061204447 16.805</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-17c410d0-b86d-49f2-ba81-f852ecdc5237">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17c410d0-b86d-49f2-ba81-f852ecdc5237">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17c410d0-b86d-49f2-ba81-f852ecdc5237">
											<gml:posList>35.670761207431234 139.74166736533152 8.67 35.670696015993315 139.74175669399392 8.67 35.67063431061394 139.74168905068706 8.67 35.67069950208653 139.7415998325016 8.67 35.670761207431234 139.74166736533152 8.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5a217415-82a4-4e0c-b877-188931af467e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a217415-82a4-4e0c-b877-188931af467e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a217415-82a4-4e0c-b877-188931af467e">
											<gml:posList>35.67072327307747 139.74162584144935 21.455 35.670723385246596 139.74163109936313 21.455 35.67075680897015 139.741667679657 21.455 35.670761207431234 139.74166736533152 21.455 35.67072327307747 139.74162584144935 21.455</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c428ae63-d1ff-4117-a7c9-c4ff323f6fe0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c428ae63-d1ff-4117-a7c9-c4ff323f6fe0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c428ae63-d1ff-4117-a7c9-c4ff323f6fe0">
											<gml:posList>35.67069950208653 139.7415998325016 16.805 35.67063431061394 139.74168905068706 16.805 35.670639994009065 139.74169528534767 16.805 35.670708667677715 139.74160986310594 16.805 35.67069950208653 139.7415998325016 16.805</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c3dc03dc-9e97-40d1-a73c-71ead101f4fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3dc03dc-9e97-40d1-a73c-71ead101f4fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3dc03dc-9e97-40d1-a73c-71ead101f4fe">
											<gml:posList>35.67065432878425 139.74171099889114 20.688 35.67072327307747 139.74162584144935 20.688 35.670708667677715 139.74160986310594 20.688 35.670639994009065 139.74169528534767 20.688 35.67065432878425 139.74171099889114 20.688</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7bb3fdd5-3229-4e2d-a107-dbdbf6a7a27f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7bb3fdd5-3229-4e2d-a107-dbdbf6a7a27f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7bb3fdd5-3229-4e2d-a107-dbdbf6a7a27f">
											<gml:posList>35.67075680897015 139.741667679657 20.969 35.670723385246596 139.74163109936313 20.969 35.6707041691336 139.741668137507 20.969 35.67073193789646 139.7417003278397 20.969 35.67075680897015 139.741667679657 20.969</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8d958254-26da-4916-9948-82e5ea658190">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d958254-26da-4916-9948-82e5ea658190">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d958254-26da-4916-9948-82e5ea658190">
											<gml:posList>35.670723385246596 139.74163109936313 21.455 35.67072327307747 139.74162584144935 21.455 35.67065432878425 139.74171099889114 21.455 35.67065883551946 139.74171082804656 21.455 35.670723385246596 139.74163109936313 21.455</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-66874c1a-f5b9-43f3-8592-b446603df378">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66874c1a-f5b9-43f3-8592-b446603df378">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66874c1a-f5b9-43f3-8592-b446603df378">
											<gml:posList>35.670723385246596 139.74163109936313 20.969 35.67065883551946 139.74171082804656 20.969 35.67069542542781 139.74167946996417 20.969 35.6707041691336 139.741668137507 20.969 35.670723385246596 139.74163109936313 20.969</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bcd47e3d-cfd6-468a-a439-67c35ebdfce9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bcd47e3d-cfd6-468a-a439-67c35ebdfce9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bcd47e3d-cfd6-468a-a439-67c35ebdfce9">
											<gml:posList>35.67072319418767 139.7417116602973 23.056 35.67073193789646 139.7417003278397 23.056 35.6707041691336 139.741668137507 23.056 35.67069542542781 139.74167946996417 23.056 35.67072319418767 139.7417116602973 23.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4b9a06cc-314a-4711-8e16-8688a79370aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b9a06cc-314a-4711-8e16-8688a79370aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b9a06cc-314a-4711-8e16-8688a79370aa">
											<gml:posList>35.67069576852301 139.74175130368067 20.969 35.67075680897015 139.741667679657 20.969 35.67073193789646 139.7417003278397 20.969 35.67072319418767 139.7417116602973 20.969 35.67069576852301 139.74175130368067 20.969</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d7ae1e8f-500e-4d52-851b-fd5cb7ead078">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7ae1e8f-500e-4d52-851b-fd5cb7ead078">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7ae1e8f-500e-4d52-851b-fd5cb7ead078">
											<gml:posList>35.67069576852301 139.74175130368067 21.455 35.670696015993315 139.74175669399392 21.455 35.670761207431234 139.74166736533152 21.455 35.67075680897015 139.741667679657 21.455 35.67069576852301 139.74175130368067 21.455</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-858bd252-7d7f-4a9b-9890-baf3d73c78e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-858bd252-7d7f-4a9b-9890-baf3d73c78e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-858bd252-7d7f-4a9b-9890-baf3d73c78e2">
											<gml:posList>35.67069576852301 139.74175130368067 20.969 35.67072319418767 139.7417116602973 20.969 35.67069542542781 139.74167946996417 20.969 35.67065883551946 139.74171082804656 20.969 35.67069576852301 139.74175130368067 20.969</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-208aec70-7981-4909-986f-caea74ba70b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-208aec70-7981-4909-986f-caea74ba70b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-208aec70-7981-4909-986f-caea74ba70b3">
											<gml:posList>35.67065432878425 139.74171099889114 21.455 35.670696015993315 139.74175669399392 21.455 35.67069576852301 139.74175130368067 21.455 35.67065883551946 139.74171082804656 21.455 35.67065432878425 139.74171099889114 21.455</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-61c6eb59-6f44-4850-b64b-ef57a7d81daf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61c6eb59-6f44-4850-b64b-ef57a7d81daf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61c6eb59-6f44-4850-b64b-ef57a7d81daf">
											<gml:posList>35.67065883551946 139.74171082804656 20.969 35.670723385246596 139.74163109936313 20.969 35.670723385246596 139.74163109936313 21.455 35.67065883551946 139.74171082804656 21.455 35.67065883551946 139.74171082804656 20.969</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b1a0957b-8b58-4b58-a903-2796b14a6c05">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b1a0957b-8b58-4b58-a903-2796b14a6c05">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b1a0957b-8b58-4b58-a903-2796b14a6c05">
											<gml:posList>35.67069576852301 139.74175130368067 21.455 35.67075680897015 139.741667679657 21.455 35.67075680897015 139.741667679657 20.969 35.67069576852301 139.74175130368067 20.969 35.67069576852301 139.74175130368067 21.455</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7a2b0dbf-05f5-4b29-87b4-e231304c1d7f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a2b0dbf-05f5-4b29-87b4-e231304c1d7f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a2b0dbf-05f5-4b29-87b4-e231304c1d7f">
											<gml:posList>35.670696015993315 139.74175669399392 21.455 35.67065432878425 139.74171099889114 21.455 35.67065432878425 139.74171099889114 20.688 35.670639994009065 139.74169528534767 20.688 35.670639994009065 139.74169528534767 16.805 35.67063431061394 139.74168905068706 16.805 35.67063431061394 139.74168905068706 8.67 35.670696015993315 139.74175669399392 8.67 35.670696015993315 139.74175669399392 21.455</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8d6111fe-cc22-41a8-a8dc-bce79ea93767">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d6111fe-cc22-41a8-a8dc-bce79ea93767">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d6111fe-cc22-41a8-a8dc-bce79ea93767">
											<gml:posList>35.67063431061394 139.74168905068706 8.67 35.67063431061394 139.74168905068706 16.805 35.67069950208653 139.7415998325016 16.805 35.67069950208653 139.7415998325016 8.67 35.67063431061394 139.74168905068706 8.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5ef01c52-4eda-476f-93ba-cb6e16d16f6b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5ef01c52-4eda-476f-93ba-cb6e16d16f6b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5ef01c52-4eda-476f-93ba-cb6e16d16f6b">
											<gml:posList>35.670639994009065 139.74169528534767 16.805 35.670639994009065 139.74169528534767 20.688 35.670708667677715 139.74160986310594 20.688 35.670708667677715 139.74160986310594 16.805 35.670639994009065 139.74169528534767 16.805</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-78d3f0bf-05c7-4836-b215-98c51a29d968">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78d3f0bf-05c7-4836-b215-98c51a29d968">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78d3f0bf-05c7-4836-b215-98c51a29d968">
											<gml:posList>35.67065883551946 139.74171082804656 21.455 35.67069576852301 139.74175130368067 21.455 35.67069576852301 139.74175130368067 20.969 35.67065883551946 139.74171082804656 20.969 35.67065883551946 139.74171082804656 21.455</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-190f7b00-6011-41cd-a3ed-1d2dc4079537">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-190f7b00-6011-41cd-a3ed-1d2dc4079537">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-190f7b00-6011-41cd-a3ed-1d2dc4079537">
											<gml:posList>35.67072327307747 139.74162584144935 21.455 35.67072327307747 139.74162584144935 20.688 35.67065432878425 139.74171099889114 20.688 35.67065432878425 139.74171099889114 21.455 35.67072327307747 139.74162584144935 21.455</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-49e44567-f861-435a-af4e-28e8977326e1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-49e44567-f861-435a-af4e-28e8977326e1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-49e44567-f861-435a-af4e-28e8977326e1">
											<gml:posList>35.6707041691336 139.741668137507 20.969 35.67069542542781 139.74167946996417 20.969 35.67069542542781 139.74167946996417 23.056 35.6707041691336 139.741668137507 23.056 35.6707041691336 139.741668137507 20.969</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0445ad00-a5c1-42c9-97a1-5e6273636b7d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0445ad00-a5c1-42c9-97a1-5e6273636b7d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0445ad00-a5c1-42c9-97a1-5e6273636b7d">
											<gml:posList>35.67072319418767 139.7417116602973 23.056 35.67069542542781 139.74167946996417 23.056 35.67069542542781 139.74167946996417 20.969 35.67072319418767 139.7417116602973 20.969 35.67072319418767 139.7417116602973 23.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-16153eab-6497-4530-b2e8-d3777bb8219d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16153eab-6497-4530-b2e8-d3777bb8219d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16153eab-6497-4530-b2e8-d3777bb8219d">
											<gml:posList>35.67073193789646 139.7417003278397 20.969 35.6707041691336 139.741668137507 20.969 35.6707041691336 139.741668137507 23.056 35.67073193789646 139.7417003278397 23.056 35.67073193789646 139.7417003278397 20.969</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-51545bb8-9f65-414d-95d1-8ebe78bf5d80">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-51545bb8-9f65-414d-95d1-8ebe78bf5d80">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-51545bb8-9f65-414d-95d1-8ebe78bf5d80">
											<gml:posList>35.67072319418767 139.7417116602973 20.969 35.67073193789646 139.7417003278397 20.969 35.67073193789646 139.7417003278397 23.056 35.67072319418767 139.7417116602973 23.056 35.67072319418767 139.7417116602973 20.969</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5e7fe379-7bca-4da0-bc14-21f53d864a10">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e7fe379-7bca-4da0-bc14-21f53d864a10">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e7fe379-7bca-4da0-bc14-21f53d864a10">
											<gml:posList>35.670696015993315 139.74175669399392 21.455 35.670696015993315 139.74175669399392 8.67 35.670761207431234 139.74166736533152 8.67 35.670761207431234 139.74166736533152 21.455 35.670696015993315 139.74175669399392 21.455</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b7524f3b-9084-4f9f-a827-8c4d3778ac40">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b7524f3b-9084-4f9f-a827-8c4d3778ac40">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b7524f3b-9084-4f9f-a827-8c4d3778ac40">
											<gml:posList>35.67069950208653 139.7415998325016 8.67 35.67069950208653 139.7415998325016 16.805 35.670708667677715 139.74160986310594 16.805 35.670708667677715 139.74160986310594 20.688 35.67072327307747 139.74162584144935 20.688 35.67072327307747 139.74162584144935 21.455 35.670761207431234 139.74166736533152 21.455 35.670761207431234 139.74166736533152 8.67 35.67069950208653 139.7415998325016 8.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9b7bf9b8-cd59-426c-8d19-e469a909a3da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b7bf9b8-cd59-426c-8d19-e469a909a3da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b7bf9b8-cd59-426c-8d19-e469a909a3da">
											<gml:posList>35.670723385246596 139.74163109936313 20.969 35.67075680897015 139.741667679657 20.969 35.67075680897015 139.741667679657 21.455 35.670723385246596 139.74163109936313 21.455 35.670723385246596 139.74163109936313 20.969</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4949</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">99.5798</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1241</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>