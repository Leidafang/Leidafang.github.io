<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_832d0cc4-4b94-481c-99c6-857a42ecf7d7">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>6</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001006</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">44</bldg:measuredHeight>
			<bldg:storeysAboveGround>14</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>3</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.669014427264536 139.73760131524347 0 35.66905962394962 139.73764898033485 0 35.66908943927282 139.73762364922854 0 35.6691230174584 139.737682926629 0 35.669149950327615 139.73766002909437 0 35.66920573347396 139.73775860418246 0 35.669211318212604 139.73775384770335 0 35.66922648239608 139.73778045072845 0 35.669260711489585 139.7377513586811 0 35.669252226663815 139.73773634609458 0 35.66929879612607 139.73769663503572 0 35.669271175432534 139.73764795465158 0 35.6692882899201 139.73763335336412 0 35.669252996643706 139.7375709850017 0 35.66926740893775 139.73755881707223 0 35.669231122706464 139.73749468256955 0 35.66924733641869 139.73748085556082 0 35.66918911599538 139.73737808601567 0 35.66917110078224 139.73739346164368 0 35.6691500692292 139.7373563719475 0 35.66896487233601 139.73751388958087 0 35.669014427264536 139.73760131524347 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669014427264536 139.73760131524347 21.407 35.66896487233601 139.73751388958087 21.407 35.6691500692292 139.7373563719475 21.407 35.66917110078224 139.73739346164368 21.407 35.66918911599538 139.73737808601567 21.407 35.66924733641869 139.73748085556082 21.407 35.669231122706464 139.73749468256955 21.407 35.66926740893775 139.73755881707223 21.407 35.669252996643706 139.7375709850017 21.407 35.6692882899201 139.73763335336412 21.407 35.669271175432534 139.73764795465158 21.407 35.66929879612607 139.73769663503572 21.407 35.669252226663815 139.73773634609458 21.407 35.669260711489585 139.7377513586811 21.407 35.66922648239608 139.73778045072845 21.407 35.669211318212604 139.73775384770335 21.407 35.66920573347396 139.73775860418246 21.407 35.669149950327615 139.73766002909437 21.407 35.6691230174584 139.737682926629 21.407 35.66908943927282 139.73762364922854 21.407 35.66905962394962 139.73764898033485 21.407 35.669014427264536 139.73760131524347 21.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669014427264536 139.73760131524347 21.407 35.66905962394962 139.73764898033485 21.407 35.66905962394962 139.73764898033485 65.43 35.669014427264536 139.73760131524347 65.43 35.669014427264536 139.73760131524347 21.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66905962394962 139.73764898033485 21.407 35.66908943927282 139.73762364922854 21.407 35.66908943927282 139.73762364922854 65.43 35.66905962394962 139.73764898033485 65.43 35.66905962394962 139.73764898033485 21.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66908943927282 139.73762364922854 21.407 35.6691230174584 139.737682926629 21.407 35.6691230174584 139.737682926629 65.43 35.66908943927282 139.73762364922854 65.43 35.66908943927282 139.73762364922854 21.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6691230174584 139.737682926629 21.407 35.669149950327615 139.73766002909437 21.407 35.669149950327615 139.73766002909437 65.43 35.6691230174584 139.737682926629 65.43 35.6691230174584 139.737682926629 21.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669149950327615 139.73766002909437 21.407 35.66920573347396 139.73775860418246 21.407 35.66920573347396 139.73775860418246 65.43 35.669149950327615 139.73766002909437 65.43 35.669149950327615 139.73766002909437 21.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66920573347396 139.73775860418246 21.407 35.669211318212604 139.73775384770335 21.407 35.669211318212604 139.73775384770335 65.43 35.66920573347396 139.73775860418246 65.43 35.66920573347396 139.73775860418246 21.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669211318212604 139.73775384770335 21.407 35.66922648239608 139.73778045072845 21.407 35.66922648239608 139.73778045072845 65.43 35.669211318212604 139.73775384770335 65.43 35.669211318212604 139.73775384770335 21.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66922648239608 139.73778045072845 21.407 35.669260711489585 139.7377513586811 21.407 35.669260711489585 139.7377513586811 65.43 35.66922648239608 139.73778045072845 65.43 35.66922648239608 139.73778045072845 21.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669260711489585 139.7377513586811 21.407 35.669252226663815 139.73773634609458 21.407 35.669252226663815 139.73773634609458 65.43 35.669260711489585 139.7377513586811 65.43 35.669260711489585 139.7377513586811 21.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669252226663815 139.73773634609458 21.407 35.66929879612607 139.73769663503572 21.407 35.66929879612607 139.73769663503572 65.43 35.669252226663815 139.73773634609458 65.43 35.669252226663815 139.73773634609458 21.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66929879612607 139.73769663503572 21.407 35.669271175432534 139.73764795465158 21.407 35.669271175432534 139.73764795465158 65.43 35.66929879612607 139.73769663503572 65.43 35.66929879612607 139.73769663503572 21.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669271175432534 139.73764795465158 21.407 35.6692882899201 139.73763335336412 21.407 35.6692882899201 139.73763335336412 65.43 35.669271175432534 139.73764795465158 65.43 35.669271175432534 139.73764795465158 21.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6692882899201 139.73763335336412 21.407 35.669252996643706 139.7375709850017 21.407 35.669252996643706 139.7375709850017 65.43 35.6692882899201 139.73763335336412 65.43 35.6692882899201 139.73763335336412 21.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669252996643706 139.7375709850017 21.407 35.66926740893775 139.73755881707223 21.407 35.66926740893775 139.73755881707223 65.43 35.669252996643706 139.7375709850017 65.43 35.669252996643706 139.7375709850017 21.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66926740893775 139.73755881707223 21.407 35.669231122706464 139.73749468256955 21.407 35.669231122706464 139.73749468256955 65.43 35.66926740893775 139.73755881707223 65.43 35.66926740893775 139.73755881707223 21.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669231122706464 139.73749468256955 21.407 35.66924733641869 139.73748085556082 21.407 35.66924733641869 139.73748085556082 65.43 35.669231122706464 139.73749468256955 65.43 35.669231122706464 139.73749468256955 21.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66924733641869 139.73748085556082 21.407 35.66918911599538 139.73737808601567 21.407 35.66918911599538 139.73737808601567 65.43 35.66924733641869 139.73748085556082 65.43 35.66924733641869 139.73748085556082 21.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66918911599538 139.73737808601567 21.407 35.66917110078224 139.73739346164368 21.407 35.66917110078224 139.73739346164368 65.43 35.66918911599538 139.73737808601567 65.43 35.66918911599538 139.73737808601567 21.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66917110078224 139.73739346164368 21.407 35.6691500692292 139.7373563719475 21.407 35.6691500692292 139.7373563719475 65.43 35.66917110078224 139.73739346164368 65.43 35.66917110078224 139.73739346164368 21.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6691500692292 139.7373563719475 21.407 35.66896487233601 139.73751388958087 21.407 35.66896487233601 139.73751388958087 65.43 35.6691500692292 139.7373563719475 65.43 35.6691500692292 139.7373563719475 21.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66896487233601 139.73751388958087 21.407 35.669014427264536 139.73760131524347 21.407 35.669014427264536 139.73760131524347 65.43 35.66896487233601 139.73751388958087 65.43 35.66896487233601 139.73751388958087 21.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669014427264536 139.73760131524347 65.43 35.66905962394962 139.73764898033485 65.43 35.66908943927282 139.73762364922854 65.43 35.6691230174584 139.737682926629 65.43 35.669149950327615 139.73766002909437 65.43 35.66920573347396 139.73775860418246 65.43 35.669211318212604 139.73775384770335 65.43 35.66922648239608 139.73778045072845 65.43 35.669260711489585 139.7377513586811 65.43 35.669252226663815 139.73773634609458 65.43 35.66929879612607 139.73769663503572 65.43 35.669271175432534 139.73764795465158 65.43 35.6692882899201 139.73763335336412 65.43 35.669252996643706 139.7375709850017 65.43 35.66926740893775 139.73755881707223 65.43 35.669231122706464 139.73749468256955 65.43 35.66924733641869 139.73748085556082 65.43 35.66918911599538 139.73737808601567 65.43 35.66917110078224 139.73739346164368 65.43 35.6691500692292 139.7373563719475 65.43 35.66896487233601 139.73751388958087 65.43 35.669014427264536 139.73760131524347 65.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-4c4822ce-a69b-43de-9899-b17281f771a2"/>
							<gml:surfaceMember xlink:href="#poly-05487ba2-031b-4e19-81ae-ae5bc2821a10"/>
							<gml:surfaceMember xlink:href="#poly-186fae0c-8de3-4241-be89-a64f965fa6a2"/>
							<gml:surfaceMember xlink:href="#poly-bad33ba3-0972-4a0d-9438-3938c0ca9297"/>
							<gml:surfaceMember xlink:href="#poly-e6789cab-5149-49df-b92e-4d67d4f35093"/>
							<gml:surfaceMember xlink:href="#poly-068e7fca-8999-40a1-81f5-3ccb8d3e2eaf"/>
							<gml:surfaceMember xlink:href="#poly-17dfbbdd-2d09-47ca-9b28-ac5ac66e04ba"/>
							<gml:surfaceMember xlink:href="#poly-78065ef7-dfb8-48e3-afdb-cb36109e4b57"/>
							<gml:surfaceMember xlink:href="#poly-20cce136-f745-4382-b9f2-428c663a3c1e"/>
							<gml:surfaceMember xlink:href="#poly-2a28ec74-19bb-48d5-a0c2-6317a0ee8fce"/>
							<gml:surfaceMember xlink:href="#poly-7655203d-8bd5-469e-a160-081a1afa8e99"/>
							<gml:surfaceMember xlink:href="#poly-a8b4c66f-cf0d-405e-a9a3-c334d3a329b7"/>
							<gml:surfaceMember xlink:href="#poly-48f28059-181e-4b46-a1e5-3bd886a84f72"/>
							<gml:surfaceMember xlink:href="#poly-579a1667-9f90-4a0a-a061-5887c3f87722"/>
							<gml:surfaceMember xlink:href="#poly-7665fb03-6493-4a20-9a1d-9d4e66e1e036"/>
							<gml:surfaceMember xlink:href="#poly-373c98c4-a285-4de1-bf92-83cc8052b139"/>
							<gml:surfaceMember xlink:href="#poly-bcb5e73e-9a74-42df-b043-2c0ff9f8575d"/>
							<gml:surfaceMember xlink:href="#poly-1db170f5-294b-47f7-ba02-223a619625c8"/>
							<gml:surfaceMember xlink:href="#poly-4e610d04-91ba-4152-9dcd-719c806a821b"/>
							<gml:surfaceMember xlink:href="#poly-def6bc74-5cb8-4924-9554-25f6e3649f87"/>
							<gml:surfaceMember xlink:href="#poly-f4c2d244-18f7-46f5-9d9f-60383f655bbb"/>
							<gml:surfaceMember xlink:href="#poly-59eb91e6-b025-440b-915d-d2934068562c"/>
							<gml:surfaceMember xlink:href="#poly-ca77e437-d8f7-41ef-ba8c-80c30115181f"/>
							<gml:surfaceMember xlink:href="#poly-9218dc1c-260e-4c5c-9cad-490aaca31272"/>
							<gml:surfaceMember xlink:href="#poly-4b4cb39f-29b2-4941-8a86-d48a0be8d9e7"/>
							<gml:surfaceMember xlink:href="#poly-88e4f3d5-3c46-4775-b8d6-ae523d9732a0"/>
							<gml:surfaceMember xlink:href="#poly-f4c202e9-fe46-435e-a719-b892b356deff"/>
							<gml:surfaceMember xlink:href="#poly-0c0bc66a-9351-44b6-9c12-c617a0b05d64"/>
							<gml:surfaceMember xlink:href="#poly-77e1f90c-7622-4594-8186-29754c883cd0"/>
							<gml:surfaceMember xlink:href="#poly-9897496d-5c95-4c0b-8cdc-a06c11bf3bc1"/>
							<gml:surfaceMember xlink:href="#poly-a3d9a5da-eb7f-4af0-9805-378e1b944077"/>
							<gml:surfaceMember xlink:href="#poly-52c2c8cf-63ce-49f3-8249-73058166bd17"/>
							<gml:surfaceMember xlink:href="#poly-b1b3af09-380a-4055-8420-020b22aa2f98"/>
							<gml:surfaceMember xlink:href="#poly-134c9579-db17-49a0-a2af-956def9bd4b3"/>
							<gml:surfaceMember xlink:href="#poly-4cb63583-439a-4c07-a0bb-38ca584e77ab"/>
							<gml:surfaceMember xlink:href="#poly-96519a86-754d-4868-9159-217f6c6175fa"/>
							<gml:surfaceMember xlink:href="#poly-cfa637fd-80f8-41da-8ad5-e08723d41502"/>
							<gml:surfaceMember xlink:href="#poly-d6fd6e98-926a-446c-8f37-8b4228dc4f7a"/>
							<gml:surfaceMember xlink:href="#poly-6dfc4e3b-8177-4b04-b2e9-d9e7eb897225"/>
							<gml:surfaceMember xlink:href="#poly-809f737c-26b2-4184-a617-58301b25abb1"/>
							<gml:surfaceMember xlink:href="#poly-e97958e1-4155-408a-a977-e14fcf4e4fff"/>
							<gml:surfaceMember xlink:href="#poly-57ec232c-7992-412e-be62-786f85ea94cb"/>
							<gml:surfaceMember xlink:href="#poly-f15e6c35-e629-4ab8-9edf-b4d02d75d086"/>
							<gml:surfaceMember xlink:href="#poly-b6bbca85-7a15-493e-aed3-bd30a425e69a"/>
							<gml:surfaceMember xlink:href="#poly-a008e095-457a-4f85-87db-d230ba5641ff"/>
							<gml:surfaceMember xlink:href="#poly-70cbb254-c112-40f6-95e1-82ce0517e511"/>
							<gml:surfaceMember xlink:href="#poly-f0666dc7-bf6f-4a53-8f32-583905e8b173"/>
							<gml:surfaceMember xlink:href="#poly-aad567dd-89de-4945-aa97-2d0afd71ecf9"/>
							<gml:surfaceMember xlink:href="#poly-10ecefec-d660-4cc8-ae44-f4afd12ff7bd"/>
							<gml:surfaceMember xlink:href="#poly-6363caff-935e-4098-93ca-c5002a48a848"/>
							<gml:surfaceMember xlink:href="#poly-3656ad47-8ec9-4319-8119-c1912a8538cd"/>
							<gml:surfaceMember xlink:href="#poly-8f994ee5-3a71-45a3-bea8-f0db7bb7fadb"/>
							<gml:surfaceMember xlink:href="#poly-fc19cb0d-d6b2-4dee-82ad-daa7c0c4d65c"/>
							<gml:surfaceMember xlink:href="#poly-c4113146-e839-47bd-8c78-519aa42f8a11"/>
							<gml:surfaceMember xlink:href="#poly-1ad4f09e-92df-4b33-abe5-9a93cdbcd8f9"/>
							<gml:surfaceMember xlink:href="#poly-9cb66e8b-689a-44c7-b251-b8ded5e1f014"/>
							<gml:surfaceMember xlink:href="#poly-897ebfed-11ee-48db-abae-7f6d0dbbd1e5"/>
							<gml:surfaceMember xlink:href="#poly-2eebb203-e27f-459d-8697-3171b1bdc401"/>
							<gml:surfaceMember xlink:href="#poly-fbfacd22-c4da-42f4-af4b-99942e13d44f"/>
							<gml:surfaceMember xlink:href="#poly-efe567c1-4c2f-4a30-91e2-42210cd7c758"/>
							<gml:surfaceMember xlink:href="#poly-b3b82e89-d63e-49e8-a90c-f946ec3efa1d"/>
							<gml:surfaceMember xlink:href="#poly-0b3ace85-301c-48fe-a6fb-d7e7411d7cee"/>
							<gml:surfaceMember xlink:href="#poly-7f5a1a6d-5f30-4842-b2fe-d1e7093595cd"/>
							<gml:surfaceMember xlink:href="#poly-3a8a04eb-9c1c-4e33-b742-fcf020b2d587"/>
							<gml:surfaceMember xlink:href="#poly-e29d158b-a0a0-47f8-aef6-175eb1cfa18d"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_832d0cc4-4b94-481c-99c6-857a42ecf7d7_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9287cd63-849f-46d9-a4aa-c70dd9184a38">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669167625979846 139.73756896611246 65.702 35.66914975502261 139.737539085692 65.702 35.66917152565498 139.73751953019038 65.702 35.669171948992364 139.73751914307124 65.702 35.66918948599861 139.7375484605436 65.702 35.66918982897701 139.73754903453082 65.702 35.669167625979846 139.73756896611246 65.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3cd43ee3-c6fc-4ff6-9678-8e3d12cd5473">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6690801224885 139.7375599244678 65.702 35.66907994195923 139.73755960434713 65.702 35.66909705660362 139.73754521295115 65.702 35.66909738088678 139.73754494745774 65.702 35.66910691292752 139.73756196913143 65.702 35.66910709345678 139.73756228925222 65.702 35.669089978810376 139.73757668064638 65.702 35.669089654527134 139.73757694613963 65.702 35.6690801224885 139.7375599244678 65.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-810fa185-435f-4de0-9b0d-c17950c67f7b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66911726515415 139.7375675792237 65.702 35.66914095500274 139.73754712671186 65.702 35.66917292587623 139.73760274978048 65.702 35.6691604413992 139.7376135125327 65.702 35.669137713383655 139.73757397257813 65.702 35.66912649898341 139.73758365129697 65.702 35.66911726515415 139.7375675792237 65.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c10ad3e3-fb48-4b07-85d2-788d0eaeb228">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c10ad3e3-fb48-4b07-85d2-788d0eaeb228_0">
											<gml:posList>35.66910709345678 139.73756228925222 65.702 35.66910691292752 139.73756196913143 65.702 35.66910709345678 139.73756228925222 66.526 35.66910709345678 139.73756228925222 65.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9152e4f1-d1d1-4c71-a466-efd4699ec9d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9152e4f1-d1d1-4c71-a466-efd4699ec9d7_0">
											<gml:posList>35.669089654527134 139.73757694613963 65.702 35.669089978810376 139.73757668064638 65.702 35.669089654527134 139.73757694613963 66.526 35.669089654527134 139.73757694613963 65.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-689da282-7b0f-4b62-aaaf-5a368f1d67e5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-689da282-7b0f-4b62-aaaf-5a368f1d67e5_0">
											<gml:posList>35.669171948992364 139.73751914307124 65.702 35.66917152565498 139.73751953019038 65.702 35.669171948992364 139.73751914307124 66.563 35.669171948992364 139.73751914307124 65.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d58d4f8-f162-45c7-908d-a069cb2fbd8f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8d58d4f8-f162-45c7-908d-a069cb2fbd8f_0">
											<gml:posList>35.66917152565498 139.73751953019038 65.702 35.66914975502261 139.737539085692 65.702 35.66914975502261 139.737539085692 66.563 35.669171948992364 139.73751914307124 66.563 35.66917152565498 139.73751953019038 65.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6f8f7f9-92de-4753-bfda-b8325f4a698a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d6f8f7f9-92de-4753-bfda-b8325f4a698a_0">
											<gml:posList>35.66918948599861 139.7375484605436 65.702 35.669171948992364 139.73751914307124 65.702 35.669171948992364 139.73751914307124 66.563 35.66918982897701 139.73754903453082 66.563 35.66918948599861 139.7375484605436 65.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4dfe8b15-a03b-417e-94ff-631fd7bf076d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4dfe8b15-a03b-417e-94ff-631fd7bf076d_0">
											<gml:posList>35.66914975502261 139.737539085692 66.563 35.669167625979846 139.73756896611246 66.563 35.66918982897701 139.73754903453082 66.563 35.669171948992364 139.73751914307124 66.563 35.66914975502261 139.737539085692 66.563</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2cf828bc-b056-49cb-8c04-1ccc6da58436">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2cf828bc-b056-49cb-8c04-1ccc6da58436_0">
											<gml:posList>35.66909738088678 139.73754494745774 65.702 35.66909705660362 139.73754521295115 65.702 35.66909738088678 139.73754494745774 66.526 35.66909738088678 139.73754494745774 65.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38607fcc-ec1c-43f8-9bf0-7bb178249513">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-38607fcc-ec1c-43f8-9bf0-7bb178249513_0">
											<gml:posList>35.66918982897701 139.73754903453082 65.702 35.66918948599861 139.7375484605436 65.702 35.66918982897701 139.73754903453082 66.563 35.66918982897701 139.73754903453082 65.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-299c2400-36b3-4ca1-aa2b-10fb1883f537">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-299c2400-36b3-4ca1-aa2b-10fb1883f537_0">
											<gml:posList>35.66909705660362 139.73754521295115 65.702 35.66907994195923 139.73755960434713 65.702 35.66907994195923 139.73755960434713 66.526 35.66909738088678 139.73754494745774 66.526 35.66909705660362 139.73754521295115 65.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b9b4076-97e8-4f16-9fc1-d4a860fb951a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1b9b4076-97e8-4f16-9fc1-d4a860fb951a_0">
											<gml:posList>35.66910691292752 139.73756196913143 65.702 35.66909738088678 139.73754494745774 65.702 35.66909738088678 139.73754494745774 66.526 35.66910709345678 139.73756228925222 66.526 35.66910691292752 139.73756196913143 65.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e3991dbf-e721-4f6a-bd5c-4bd587fcaa84">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e3991dbf-e721-4f6a-bd5c-4bd587fcaa84_0">
											<gml:posList>35.669167625979846 139.73756896611246 65.702 35.669167625979846 139.73756896611246 66.563 35.66914975502261 139.737539085692 66.563 35.66914975502261 139.737539085692 65.702 35.669167625979846 139.73756896611246 65.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16576cbc-1970-49bd-978c-d212ee416d45">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16576cbc-1970-49bd-978c-d212ee416d45_0">
											<gml:posList>35.66914095500274 139.73754712671186 65.702 35.66911726515415 139.7375675792237 65.702 35.66911726515415 139.7375675792237 66.548 35.66914095500274 139.73754712671186 66.548 35.66914095500274 139.73754712671186 65.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-033dd9b6-47c1-4a4b-a456-270f56015166">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-033dd9b6-47c1-4a4b-a456-270f56015166_0">
											<gml:posList>35.669167625979846 139.73756896611246 65.702 35.66918982897701 139.73754903453082 65.702 35.66918982897701 139.73754903453082 66.563 35.669167625979846 139.73756896611246 66.563 35.669167625979846 139.73756896611246 65.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01997e46-e673-4a87-bee7-8301f4ff0ecf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01997e46-e673-4a87-bee7-8301f4ff0ecf_0">
											<gml:posList>35.66907994195923 139.73755960434713 65.702 35.6690801224885 139.7375599244678 65.702 35.66907994195923 139.73755960434713 66.526 35.66907994195923 139.73755960434713 65.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f257cce9-7b1e-40c5-a1df-2f740f136ebb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f257cce9-7b1e-40c5-a1df-2f740f136ebb_0">
											<gml:posList>35.66909738088678 139.73754494745774 66.526 35.66907994195923 139.73755960434713 66.526 35.669089654527134 139.73757694613963 66.526 35.66910709345678 139.73756228925222 66.526 35.66909738088678 139.73754494745774 66.526</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d45bebf-3f4e-44c0-bf9b-c29fea22ab84">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d45bebf-3f4e-44c0-bf9b-c29fea22ab84_0">
											<gml:posList>35.6690801224885 139.7375599244678 65.702 35.669089654527134 139.73757694613963 65.702 35.669089654527134 139.73757694613963 66.526 35.66907994195923 139.73755960434713 66.526 35.6690801224885 139.7375599244678 65.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e7b4b1cf-23d4-484a-a518-da73c4292d2c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e7b4b1cf-23d4-484a-a518-da73c4292d2c_0">
											<gml:posList>35.66910709345678 139.73756228925222 66.526 35.669089654527134 139.73757694613963 66.526 35.669089978810376 139.73757668064638 65.702 35.66910709345678 139.73756228925222 65.702 35.66910709345678 139.73756228925222 66.526</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ae74d1af-a4be-4558-bd6e-3821296e4a81">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ae74d1af-a4be-4558-bd6e-3821296e4a81_0">
											<gml:posList>35.66917292587623 139.73760274978048 65.702 35.66914095500274 139.73754712671186 65.702 35.66914095500274 139.73754712671186 66.548 35.66917292587623 139.73760274978048 66.548 35.66917292587623 139.73760274978048 65.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a12034e-cb1b-4538-b020-a4fbd5b530b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3a12034e-cb1b-4538-b020-a4fbd5b530b2_0">
											<gml:posList>35.66911726515415 139.7375675792237 65.702 35.66912649898341 139.73758365129697 65.702 35.66912649898341 139.73758365129697 66.548 35.66911726515415 139.7375675792237 66.548 35.66911726515415 139.7375675792237 65.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7506780-8cca-4474-b104-3639db0b14f7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d7506780-8cca-4474-b104-3639db0b14f7_0">
											<gml:posList>35.66912649898341 139.73758365129697 65.702 35.669137713383655 139.73757397257813 65.702 35.669137713383655 139.73757397257813 66.548 35.66912649898341 139.73758365129697 66.548 35.66912649898341 139.73758365129697 65.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e72394fe-ec3e-4421-a232-316ffa30aa14">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e72394fe-ec3e-4421-a232-316ffa30aa14_0">
											<gml:posList>35.669137713383655 139.73757397257813 66.548 35.6691604413992 139.7376135125327 66.548 35.66917292587623 139.73760274978048 66.548 35.66914095500274 139.73754712671186 66.548 35.66911726515415 139.7375675792237 66.548 35.66912649898341 139.73758365129697 66.548 35.669137713383655 139.73757397257813 66.548</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e63f569-8f86-4c95-8c59-d827edc3f46d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e63f569-8f86-4c95-8c59-d827edc3f46d_0">
											<gml:posList>35.6691604413992 139.7376135125327 65.702 35.6691604413992 139.7376135125327 66.548 35.669137713383655 139.73757397257813 66.548 35.669137713383655 139.73757397257813 65.702 35.6691604413992 139.7376135125327 65.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00f367e8-75c6-47e8-ba25-079d9861ca13">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-00f367e8-75c6-47e8-ba25-079d9861ca13_0">
											<gml:posList>35.6691604413992 139.7376135125327 65.702 35.66917292587623 139.73760274978048 65.702 35.66917292587623 139.73760274978048 66.548 35.6691604413992 139.7376135125327 66.548 35.6691604413992 139.7376135125327 65.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-4c4822ce-a69b-43de-9899-b17281f771a2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c4822ce-a69b-43de-9899-b17281f771a2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c4822ce-a69b-43de-9899-b17281f771a2">
											<gml:posList>35.669089439272796 139.73762364922854 21.407 35.66905962394962 139.73764898033485 21.407 35.669014427264536 139.73760131524347 21.407 35.66896487233602 139.73751388958087 21.407 35.66915006922918 139.7373563719475 21.407 35.6691711007822 139.73739346164368 21.407 35.66918911599536 139.73737808601564 21.407 35.66924733641867 139.7374808555608 21.407 35.66923112270646 139.73749468256955 21.407 35.66926740893776 139.73755881707223 21.407 35.66925299664368 139.73757098500167 21.407 35.66928828992009 139.73763335336412 21.407 35.669271175432506 139.73764795465158 21.407 35.66929879612606 139.73769663503572 21.407 35.66925222666379 139.73773634609455 21.407 35.66926071148958 139.73775135868107 21.407 35.66922648239608 139.73778045072845 21.407 35.669211318212604 139.73775384770332 21.407 35.66920573347396 139.73775860418246 21.407 35.66914995032762 139.73766002909437 21.407 35.6691230174584 139.737682926629 21.407 35.669089439272796 139.73762364922854 21.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-05487ba2-031b-4e19-81ae-ae5bc2821a10">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-05487ba2-031b-4e19-81ae-ae5bc2821a10">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-05487ba2-031b-4e19-81ae-ae5bc2821a10">
											<gml:posList>35.66896487233602 139.73751388958087 66.512 35.669014427264536 139.73760131524347 66.512 35.66901722807376 139.7375982189995 66.512 35.668970074177714 139.73751504320134 66.512 35.66896487233602 139.73751388958087 66.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-186fae0c-8de3-4241-be89-a64f965fa6a2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-186fae0c-8de3-4241-be89-a64f965fa6a2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-186fae0c-8de3-4241-be89-a64f965fa6a2">
											<gml:posList>35.669014427264536 139.73760131524347 66.512 35.66905962394962 139.73764898033485 66.512 35.66905987174315 139.73764320294075 66.512 35.66901722807376 139.7375982189995 66.512 35.669014427264536 139.73760131524347 66.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bad33ba3-0972-4a0d-9438-3938c0ca9297">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bad33ba3-0972-4a0d-9438-3938c0ca9297">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bad33ba3-0972-4a0d-9438-3938c0ca9297">
											<gml:posList>35.66915006922918 139.7373563719475 66.512 35.66896487233602 139.73751388958087 66.512 35.668970074177714 139.73751504320134 66.512 35.6691491278681 139.73736274666797 66.512 35.66915006922918 139.7373563719475 66.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e6789cab-5149-49df-b92e-4d67d4f35093">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e6789cab-5149-49df-b92e-4d67d4f35093">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e6789cab-5149-49df-b92e-4d67d4f35093">
											<gml:posList>35.6691711007822 139.73739346164368 66.512 35.66915006922918 139.7373563719475 66.512 35.6691491278681 139.73736274666797 66.512 35.66917016843289 139.7373998363546 66.512 35.6691711007822 139.73739346164368 66.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-068e7fca-8999-40a1-81f5-3ccb8d3e2eaf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-068e7fca-8999-40a1-81f5-3ccb8d3e2eaf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-068e7fca-8999-40a1-81f5-3ccb8d3e2eaf">
											<gml:posList>35.66918911599536 139.73737808601564 66.512 35.6691711007822 139.73739346164368 66.512 35.66917016843289 139.7373998363546 66.512 35.66918818364686 139.73738446072818 66.512 35.66918911599536 139.73737808601564 66.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-17dfbbdd-2d09-47ca-9b28-ac5ac66e04ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17dfbbdd-2d09-47ca-9b28-ac5ac66e04ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17dfbbdd-2d09-47ca-9b28-ac5ac66e04ba">
											<gml:posList>35.66924733641867 139.7374808555608 66.512 35.66918911599536 139.73737808601564 66.512 35.66918818364686 139.73738446072818 66.512 35.669242134585666 139.73747971298468 66.512 35.66924733641867 139.7374808555608 66.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-78065ef7-dfb8-48e3-afdb-cb36109e4b57">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78065ef7-dfb8-48e3-afdb-cb36109e4b57">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78065ef7-dfb8-48e3-afdb-cb36109e4b57">
											<gml:posList>35.66923112270646 139.73749468256955 66.512 35.66924733641867 139.7374808555608 66.512 35.669242134585666 139.73747971298468 66.512 35.66922592087358 139.73749353999278 66.512 35.66923112270646 139.73749468256955 66.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-20cce136-f745-4382-b9f2-428c663a3c1e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20cce136-f745-4382-b9f2-428c663a3c1e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20cce136-f745-4382-b9f2-428c663a3c1e">
											<gml:posList>35.66926740893776 139.73755881707223 66.512 35.66923112270646 139.73749468256955 66.512 35.66922592087358 139.73749353999278 66.512 35.669262198074215 139.73755765240935 66.512 35.66926740893776 139.73755881707223 66.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2a28ec74-19bb-48d5-a0c2-6317a0ee8fce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a28ec74-19bb-48d5-a0c2-6317a0ee8fce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a28ec74-19bb-48d5-a0c2-6317a0ee8fce">
											<gml:posList>35.66925299664368 139.73757098500167 66.512 35.66926740893776 139.73755881707223 66.512 35.669262198074215 139.73755765240935 66.512 35.669247785780236 139.73756982033822 66.512 35.66925299664368 139.73757098500167 66.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7655203d-8bd5-469e-a160-081a1afa8e99">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7655203d-8bd5-469e-a160-081a1afa8e99">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7655203d-8bd5-469e-a160-081a1afa8e99">
											<gml:posList>35.669247785780236 139.73756982033822 65.702 35.669262198074215 139.73755765240935 65.702 35.66922592087358 139.73749353999278 65.702 35.669242134585666 139.73747971298468 65.702 35.66918818364686 139.73738446072818 65.702 35.66917016843289 139.7373998363546 65.702 35.6691491278681 139.73736274666797 65.702 35.668970074177714 139.73751504320134 65.702 35.66901722807376 139.7375982189995 65.702 35.66905987174315 139.73764320294075 65.702 35.66909038064771 139.73761727451583 65.702 35.66912395883645 139.73767655191432 65.702 35.66915089170445 139.7376536543773 65.702 35.66920667485599 139.73775222946207 65.702 35.66921225058066 139.73774747299322 65.702 35.669227414774305 139.7377740870635 65.702 35.66925550965036 139.73775020504115 65.702 35.66924703383815 139.73773519244497 65.702 35.669293594295134 139.73769549244489 65.702 35.66926597360111 139.73764681206427 65.702 35.669283097102266 139.7376322107668 65.702 35.669247785780236 139.73756982033822 65.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a8b4c66f-cf0d-405e-a9a3-c334d3a329b7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a8b4c66f-cf0d-405e-a9a3-c334d3a329b7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a8b4c66f-cf0d-405e-a9a3-c334d3a329b7">
											<gml:posList>35.66928828992009 139.73763335336412 66.512 35.66925299664368 139.73757098500167 66.512 35.669247785780236 139.73756982033822 66.512 35.669283097102266 139.7376322107668 66.512 35.66928828992009 139.73763335336412 66.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-48f28059-181e-4b46-a1e5-3bd886a84f72">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-48f28059-181e-4b46-a1e5-3bd886a84f72">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-48f28059-181e-4b46-a1e5-3bd886a84f72">
											<gml:posList>35.66905962394962 139.73764898033485 66.512 35.669089439272796 139.73762364922854 66.512 35.66909038064771 139.73761727451583 66.512 35.66905987174315 139.73764320294075 66.512 35.66905962394962 139.73764898033485 66.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-579a1667-9f90-4a0a-a061-5887c3f87722">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-579a1667-9f90-4a0a-a061-5887c3f87722">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-579a1667-9f90-4a0a-a061-5887c3f87722">
											<gml:posList>35.669271175432506 139.73764795465158 66.512 35.66928828992009 139.73763335336412 66.512 35.669283097102266 139.7376322107668 66.512 35.66926597360111 139.73764681206427 66.512 35.669271175432506 139.73764795465158 66.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7665fb03-6493-4a20-9a1d-9d4e66e1e036">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7665fb03-6493-4a20-9a1d-9d4e66e1e036">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7665fb03-6493-4a20-9a1d-9d4e66e1e036">
											<gml:posList>35.669089439272796 139.73762364922854 66.512 35.6691230174584 139.737682926629 66.512 35.66912395883645 139.73767655191432 66.512 35.66909038064771 139.73761727451583 66.512 35.669089439272796 139.73762364922854 66.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-373c98c4-a285-4de1-bf92-83cc8052b139">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-373c98c4-a285-4de1-bf92-83cc8052b139">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-373c98c4-a285-4de1-bf92-83cc8052b139">
											<gml:posList>35.6691230174584 139.737682926629 66.512 35.66914995032762 139.73766002909437 66.512 35.66915089170445 139.7376536543773 66.512 35.66912395883645 139.73767655191432 66.512 35.6691230174584 139.737682926629 66.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bcb5e73e-9a74-42df-b043-2c0ff9f8575d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bcb5e73e-9a74-42df-b043-2c0ff9f8575d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bcb5e73e-9a74-42df-b043-2c0ff9f8575d">
											<gml:posList>35.66929879612606 139.73769663503572 66.512 35.669271175432506 139.73764795465158 66.512 35.66926597360111 139.73764681206427 66.512 35.669293594295134 139.73769549244489 66.512 35.66929879612606 139.73769663503572 66.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1db170f5-294b-47f7-ba02-223a619625c8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1db170f5-294b-47f7-ba02-223a619625c8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1db170f5-294b-47f7-ba02-223a619625c8">
											<gml:posList>35.66914995032762 139.73766002909437 66.512 35.66920573347396 139.73775860418246 66.512 35.66920667485599 139.73775222946207 66.512 35.66915089170445 139.7376536543773 66.512 35.66914995032762 139.73766002909437 66.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4e610d04-91ba-4152-9dcd-719c806a821b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4e610d04-91ba-4152-9dcd-719c806a821b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4e610d04-91ba-4152-9dcd-719c806a821b">
											<gml:posList>35.66925222666379 139.73773634609455 66.512 35.66929879612606 139.73769663503572 66.512 35.669293594295134 139.73769549244489 66.512 35.66924703383815 139.73773519244497 66.512 35.66925222666379 139.73773634609455 66.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-def6bc74-5cb8-4924-9554-25f6e3649f87">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-def6bc74-5cb8-4924-9554-25f6e3649f87">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-def6bc74-5cb8-4924-9554-25f6e3649f87">
											<gml:posList>35.66926071148958 139.73775135868107 66.512 35.66925222666379 139.73773634609455 66.512 35.66924703383815 139.73773519244497 66.512 35.66925550965036 139.73775020504115 66.512 35.66926071148958 139.73775135868107 66.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f4c2d244-18f7-46f5-9d9f-60383f655bbb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4c2d244-18f7-46f5-9d9f-60383f655bbb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4c2d244-18f7-46f5-9d9f-60383f655bbb">
											<gml:posList>35.66920573347396 139.73775860418246 66.512 35.669211318212604 139.73775384770332 66.512 35.66921225058066 139.73774747299322 66.512 35.66920667485599 139.73775222946207 66.512 35.66920573347396 139.73775860418246 66.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-59eb91e6-b025-440b-915d-d2934068562c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-59eb91e6-b025-440b-915d-d2934068562c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-59eb91e6-b025-440b-915d-d2934068562c">
											<gml:posList>35.669211318212604 139.73775384770332 66.512 35.66922648239608 139.73778045072845 66.512 35.669227414774305 139.7377740870635 66.512 35.66921225058066 139.73774747299322 66.512 35.669211318212604 139.73775384770332 66.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ca77e437-d8f7-41ef-ba8c-80c30115181f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca77e437-d8f7-41ef-ba8c-80c30115181f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca77e437-d8f7-41ef-ba8c-80c30115181f">
											<gml:posList>35.66922648239608 139.73778045072845 66.512 35.66926071148958 139.73775135868107 66.512 35.66925550965036 139.73775020504115 66.512 35.669227414774305 139.7377740870635 66.512 35.66922648239608 139.73778045072845 66.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9218dc1c-260e-4c5c-9cad-490aaca31272">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9218dc1c-260e-4c5c-9cad-490aaca31272">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9218dc1c-260e-4c5c-9cad-490aaca31272">
											<gml:posList>35.6691711007822 139.73739346164368 21.407 35.66915006922918 139.7373563719475 21.407 35.66915006922918 139.7373563719475 66.512 35.6691711007822 139.73739346164368 66.512 35.6691711007822 139.73739346164368 21.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4b4cb39f-29b2-4941-8a86-d48a0be8d9e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b4cb39f-29b2-4941-8a86-d48a0be8d9e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b4cb39f-29b2-4941-8a86-d48a0be8d9e7">
											<gml:posList>35.66917016843289 139.7373998363546 66.512 35.6691491278681 139.73736274666797 66.512 35.6691491278681 139.73736274666797 65.702 35.66917016843289 139.7373998363546 65.702 35.66917016843289 139.7373998363546 66.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-88e4f3d5-3c46-4775-b8d6-ae523d9732a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-88e4f3d5-3c46-4775-b8d6-ae523d9732a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-88e4f3d5-3c46-4775-b8d6-ae523d9732a0">
											<gml:posList>35.66918911599536 139.73737808601564 21.407 35.6691711007822 139.73739346164368 21.407 35.6691711007822 139.73739346164368 66.512 35.66918911599536 139.73737808601564 66.512 35.66918911599536 139.73737808601564 21.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f4c202e9-fe46-435e-a719-b892b356deff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4c202e9-fe46-435e-a719-b892b356deff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4c202e9-fe46-435e-a719-b892b356deff">
											<gml:posList>35.66918818364686 139.73738446072818 66.512 35.66917016843289 139.7373998363546 66.512 35.66917016843289 139.7373998363546 65.702 35.66918818364686 139.73738446072818 65.702 35.66918818364686 139.73738446072818 66.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0c0bc66a-9351-44b6-9c12-c617a0b05d64">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c0bc66a-9351-44b6-9c12-c617a0b05d64">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c0bc66a-9351-44b6-9c12-c617a0b05d64">
											<gml:posList>35.66924733641867 139.7374808555608 21.407 35.66918911599536 139.73737808601564 21.407 35.66918911599536 139.73737808601564 66.512 35.66924733641867 139.7374808555608 66.512 35.66924733641867 139.7374808555608 21.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-77e1f90c-7622-4594-8186-29754c883cd0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-77e1f90c-7622-4594-8186-29754c883cd0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-77e1f90c-7622-4594-8186-29754c883cd0">
											<gml:posList>35.669242134585666 139.73747971298468 66.512 35.66918818364686 139.73738446072818 66.512 35.66918818364686 139.73738446072818 65.702 35.669242134585666 139.73747971298468 65.702 35.669242134585666 139.73747971298468 66.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9897496d-5c95-4c0b-8cdc-a06c11bf3bc1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9897496d-5c95-4c0b-8cdc-a06c11bf3bc1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9897496d-5c95-4c0b-8cdc-a06c11bf3bc1">
											<gml:posList>35.66915006922918 139.7373563719475 21.407 35.66896487233602 139.73751388958087 21.407 35.66896487233602 139.73751388958087 66.512 35.66915006922918 139.7373563719475 66.512 35.66915006922918 139.7373563719475 21.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a3d9a5da-eb7f-4af0-9805-378e1b944077">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a3d9a5da-eb7f-4af0-9805-378e1b944077">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a3d9a5da-eb7f-4af0-9805-378e1b944077">
											<gml:posList>35.6691491278681 139.73736274666797 66.512 35.668970074177714 139.73751504320134 66.512 35.668970074177714 139.73751504320134 65.702 35.6691491278681 139.73736274666797 65.702 35.6691491278681 139.73736274666797 66.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-52c2c8cf-63ce-49f3-8249-73058166bd17">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-52c2c8cf-63ce-49f3-8249-73058166bd17">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-52c2c8cf-63ce-49f3-8249-73058166bd17">
											<gml:posList>35.66922592087358 139.73749353999278 66.512 35.669242134585666 139.73747971298468 66.512 35.669242134585666 139.73747971298468 65.702 35.66922592087358 139.73749353999278 65.702 35.66922592087358 139.73749353999278 66.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b1b3af09-380a-4055-8420-020b22aa2f98">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b1b3af09-380a-4055-8420-020b22aa2f98">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b1b3af09-380a-4055-8420-020b22aa2f98">
											<gml:posList>35.66923112270646 139.73749468256955 21.407 35.66924733641867 139.7374808555608 21.407 35.66924733641867 139.7374808555608 66.512 35.66923112270646 139.73749468256955 66.512 35.66923112270646 139.73749468256955 21.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-134c9579-db17-49a0-a2af-956def9bd4b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-134c9579-db17-49a0-a2af-956def9bd4b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-134c9579-db17-49a0-a2af-956def9bd4b3">
											<gml:posList>35.669262198074215 139.73755765240935 66.512 35.66922592087358 139.73749353999278 66.512 35.66922592087358 139.73749353999278 65.702 35.669262198074215 139.73755765240935 65.702 35.669262198074215 139.73755765240935 66.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4cb63583-439a-4c07-a0bb-38ca584e77ab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4cb63583-439a-4c07-a0bb-38ca584e77ab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4cb63583-439a-4c07-a0bb-38ca584e77ab">
											<gml:posList>35.66926740893776 139.73755881707223 21.407 35.66923112270646 139.73749468256955 21.407 35.66923112270646 139.73749468256955 66.512 35.66926740893776 139.73755881707223 66.512 35.66926740893776 139.73755881707223 21.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-96519a86-754d-4868-9159-217f6c6175fa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96519a86-754d-4868-9159-217f6c6175fa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96519a86-754d-4868-9159-217f6c6175fa">
											<gml:posList>35.668970074177714 139.73751504320134 66.512 35.66901722807376 139.7375982189995 66.512 35.66901722807376 139.7375982189995 65.702 35.668970074177714 139.73751504320134 65.702 35.668970074177714 139.73751504320134 66.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cfa637fd-80f8-41da-8ad5-e08723d41502">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cfa637fd-80f8-41da-8ad5-e08723d41502">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cfa637fd-80f8-41da-8ad5-e08723d41502">
											<gml:posList>35.66896487233602 139.73751388958087 21.407 35.669014427264536 139.73760131524347 21.407 35.669014427264536 139.73760131524347 66.512 35.66896487233602 139.73751388958087 66.512 35.66896487233602 139.73751388958087 21.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d6fd6e98-926a-446c-8f37-8b4228dc4f7a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d6fd6e98-926a-446c-8f37-8b4228dc4f7a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d6fd6e98-926a-446c-8f37-8b4228dc4f7a">
											<gml:posList>35.669247785780236 139.73756982033822 66.512 35.669262198074215 139.73755765240935 66.512 35.669262198074215 139.73755765240935 65.702 35.669247785780236 139.73756982033822 65.702 35.669247785780236 139.73756982033822 66.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6dfc4e3b-8177-4b04-b2e9-d9e7eb897225">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6dfc4e3b-8177-4b04-b2e9-d9e7eb897225">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6dfc4e3b-8177-4b04-b2e9-d9e7eb897225">
											<gml:posList>35.66925299664368 139.73757098500167 21.407 35.66926740893776 139.73755881707223 21.407 35.66926740893776 139.73755881707223 66.512 35.66925299664368 139.73757098500167 66.512 35.66925299664368 139.73757098500167 21.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-809f737c-26b2-4184-a617-58301b25abb1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-809f737c-26b2-4184-a617-58301b25abb1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-809f737c-26b2-4184-a617-58301b25abb1">
											<gml:posList>35.669283097102266 139.7376322107668 66.512 35.669247785780236 139.73756982033822 66.512 35.669247785780236 139.73756982033822 65.702 35.669283097102266 139.7376322107668 65.702 35.669283097102266 139.7376322107668 66.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e97958e1-4155-408a-a977-e14fcf4e4fff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e97958e1-4155-408a-a977-e14fcf4e4fff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e97958e1-4155-408a-a977-e14fcf4e4fff">
											<gml:posList>35.66928828992009 139.73763335336412 21.407 35.66925299664368 139.73757098500167 21.407 35.66925299664368 139.73757098500167 66.512 35.66928828992009 139.73763335336412 66.512 35.66928828992009 139.73763335336412 21.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-57ec232c-7992-412e-be62-786f85ea94cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-57ec232c-7992-412e-be62-786f85ea94cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-57ec232c-7992-412e-be62-786f85ea94cb">
											<gml:posList>35.66901722807376 139.7375982189995 66.512 35.66905987174315 139.73764320294075 66.512 35.66905987174315 139.73764320294075 65.702 35.66901722807376 139.7375982189995 65.702 35.66901722807376 139.7375982189995 66.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f15e6c35-e629-4ab8-9edf-b4d02d75d086">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f15e6c35-e629-4ab8-9edf-b4d02d75d086">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f15e6c35-e629-4ab8-9edf-b4d02d75d086">
											<gml:posList>35.669014427264536 139.73760131524347 21.407 35.66905962394962 139.73764898033485 21.407 35.66905962394962 139.73764898033485 66.512 35.669014427264536 139.73760131524347 66.512 35.669014427264536 139.73760131524347 21.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b6bbca85-7a15-493e-aed3-bd30a425e69a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6bbca85-7a15-493e-aed3-bd30a425e69a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6bbca85-7a15-493e-aed3-bd30a425e69a">
											<gml:posList>35.66905987174315 139.73764320294075 66.512 35.66909038064771 139.73761727451583 66.512 35.66909038064771 139.73761727451583 65.702 35.66905987174315 139.73764320294075 65.702 35.66905987174315 139.73764320294075 66.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a008e095-457a-4f85-87db-d230ba5641ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a008e095-457a-4f85-87db-d230ba5641ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a008e095-457a-4f85-87db-d230ba5641ff">
											<gml:posList>35.66905962394962 139.73764898033485 21.407 35.669089439272796 139.73762364922854 21.407 35.669089439272796 139.73762364922854 66.512 35.66905962394962 139.73764898033485 66.512 35.66905962394962 139.73764898033485 21.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-70cbb254-c112-40f6-95e1-82ce0517e511">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70cbb254-c112-40f6-95e1-82ce0517e511">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70cbb254-c112-40f6-95e1-82ce0517e511">
											<gml:posList>35.66926597360111 139.73764681206427 66.512 35.669283097102266 139.7376322107668 66.512 35.669283097102266 139.7376322107668 65.702 35.66926597360111 139.73764681206427 65.702 35.66926597360111 139.73764681206427 66.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f0666dc7-bf6f-4a53-8f32-583905e8b173">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f0666dc7-bf6f-4a53-8f32-583905e8b173">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f0666dc7-bf6f-4a53-8f32-583905e8b173">
											<gml:posList>35.669271175432506 139.73764795465158 21.407 35.66928828992009 139.73763335336412 21.407 35.66928828992009 139.73763335336412 66.512 35.669271175432506 139.73764795465158 66.512 35.669271175432506 139.73764795465158 21.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aad567dd-89de-4945-aa97-2d0afd71ecf9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aad567dd-89de-4945-aa97-2d0afd71ecf9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aad567dd-89de-4945-aa97-2d0afd71ecf9">
											<gml:posList>35.66909038064771 139.73761727451583 66.512 35.66912395883645 139.73767655191432 66.512 35.66912395883645 139.73767655191432 65.702 35.66909038064771 139.73761727451583 65.702 35.66909038064771 139.73761727451583 66.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-10ecefec-d660-4cc8-ae44-f4afd12ff7bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-10ecefec-d660-4cc8-ae44-f4afd12ff7bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-10ecefec-d660-4cc8-ae44-f4afd12ff7bd">
											<gml:posList>35.669089439272796 139.73762364922854 21.407 35.6691230174584 139.737682926629 21.407 35.6691230174584 139.737682926629 66.512 35.669089439272796 139.73762364922854 66.512 35.669089439272796 139.73762364922854 21.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6363caff-935e-4098-93ca-c5002a48a848">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6363caff-935e-4098-93ca-c5002a48a848">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6363caff-935e-4098-93ca-c5002a48a848">
											<gml:posList>35.66912395883645 139.73767655191432 66.512 35.66915089170445 139.7376536543773 66.512 35.66915089170445 139.7376536543773 65.702 35.66912395883645 139.73767655191432 65.702 35.66912395883645 139.73767655191432 66.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3656ad47-8ec9-4319-8119-c1912a8538cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3656ad47-8ec9-4319-8119-c1912a8538cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3656ad47-8ec9-4319-8119-c1912a8538cd">
											<gml:posList>35.669293594295134 139.73769549244489 66.512 35.66926597360111 139.73764681206427 66.512 35.66926597360111 139.73764681206427 65.702 35.669293594295134 139.73769549244489 65.702 35.669293594295134 139.73769549244489 66.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8f994ee5-3a71-45a3-bea8-f0db7bb7fadb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f994ee5-3a71-45a3-bea8-f0db7bb7fadb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f994ee5-3a71-45a3-bea8-f0db7bb7fadb">
											<gml:posList>35.6691230174584 139.737682926629 21.407 35.66914995032762 139.73766002909437 21.407 35.66914995032762 139.73766002909437 66.512 35.6691230174584 139.737682926629 66.512 35.6691230174584 139.737682926629 21.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fc19cb0d-d6b2-4dee-82ad-daa7c0c4d65c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc19cb0d-d6b2-4dee-82ad-daa7c0c4d65c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc19cb0d-d6b2-4dee-82ad-daa7c0c4d65c">
											<gml:posList>35.66929879612606 139.73769663503572 21.407 35.669271175432506 139.73764795465158 21.407 35.669271175432506 139.73764795465158 66.512 35.66929879612606 139.73769663503572 66.512 35.66929879612606 139.73769663503572 21.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c4113146-e839-47bd-8c78-519aa42f8a11">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4113146-e839-47bd-8c78-519aa42f8a11">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4113146-e839-47bd-8c78-519aa42f8a11">
											<gml:posList>35.66915089170445 139.7376536543773 66.512 35.66920667485599 139.73775222946207 66.512 35.66920667485599 139.73775222946207 65.702 35.66915089170445 139.7376536543773 65.702 35.66915089170445 139.7376536543773 66.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1ad4f09e-92df-4b33-abe5-9a93cdbcd8f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ad4f09e-92df-4b33-abe5-9a93cdbcd8f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ad4f09e-92df-4b33-abe5-9a93cdbcd8f9">
											<gml:posList>35.66914995032762 139.73766002909437 21.407 35.66920573347396 139.73775860418246 21.407 35.66920573347396 139.73775860418246 66.512 35.66914995032762 139.73766002909437 66.512 35.66914995032762 139.73766002909437 21.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9cb66e8b-689a-44c7-b251-b8ded5e1f014">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9cb66e8b-689a-44c7-b251-b8ded5e1f014">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9cb66e8b-689a-44c7-b251-b8ded5e1f014">
											<gml:posList>35.66924703383815 139.73773519244497 66.512 35.669293594295134 139.73769549244489 66.512 35.669293594295134 139.73769549244489 65.702 35.66924703383815 139.73773519244497 65.702 35.66924703383815 139.73773519244497 66.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-897ebfed-11ee-48db-abae-7f6d0dbbd1e5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-897ebfed-11ee-48db-abae-7f6d0dbbd1e5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-897ebfed-11ee-48db-abae-7f6d0dbbd1e5">
											<gml:posList>35.66925222666379 139.73773634609455 21.407 35.66929879612606 139.73769663503572 21.407 35.66929879612606 139.73769663503572 66.512 35.66925222666379 139.73773634609455 66.512 35.66925222666379 139.73773634609455 21.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2eebb203-e27f-459d-8697-3171b1bdc401">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2eebb203-e27f-459d-8697-3171b1bdc401">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2eebb203-e27f-459d-8697-3171b1bdc401">
											<gml:posList>35.66925550965036 139.73775020504115 66.512 35.66924703383815 139.73773519244497 66.512 35.66924703383815 139.73773519244497 65.702 35.66925550965036 139.73775020504115 65.702 35.66925550965036 139.73775020504115 66.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fbfacd22-c4da-42f4-af4b-99942e13d44f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fbfacd22-c4da-42f4-af4b-99942e13d44f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fbfacd22-c4da-42f4-af4b-99942e13d44f">
											<gml:posList>35.66926071148958 139.73775135868107 21.407 35.66925222666379 139.73773634609455 21.407 35.66925222666379 139.73773634609455 66.512 35.66926071148958 139.73775135868107 66.512 35.66926071148958 139.73775135868107 21.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-efe567c1-4c2f-4a30-91e2-42210cd7c758">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-efe567c1-4c2f-4a30-91e2-42210cd7c758">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-efe567c1-4c2f-4a30-91e2-42210cd7c758">
											<gml:posList>35.66920667485599 139.73775222946207 66.512 35.66921225058066 139.73774747299322 66.512 35.66921225058066 139.73774747299322 65.702 35.66920667485599 139.73775222946207 65.702 35.66920667485599 139.73775222946207 66.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b3b82e89-d63e-49e8-a90c-f946ec3efa1d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b3b82e89-d63e-49e8-a90c-f946ec3efa1d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b3b82e89-d63e-49e8-a90c-f946ec3efa1d">
											<gml:posList>35.66920573347396 139.73775860418246 21.407 35.669211318212604 139.73775384770332 21.407 35.669211318212604 139.73775384770332 66.512 35.66920573347396 139.73775860418246 66.512 35.66920573347396 139.73775860418246 21.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0b3ace85-301c-48fe-a6fb-d7e7411d7cee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b3ace85-301c-48fe-a6fb-d7e7411d7cee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b3ace85-301c-48fe-a6fb-d7e7411d7cee">
											<gml:posList>35.66921225058066 139.73774747299322 66.512 35.669227414774305 139.7377740870635 66.512 35.669227414774305 139.7377740870635 65.702 35.66921225058066 139.73774747299322 65.702 35.66921225058066 139.73774747299322 66.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7f5a1a6d-5f30-4842-b2fe-d1e7093595cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f5a1a6d-5f30-4842-b2fe-d1e7093595cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f5a1a6d-5f30-4842-b2fe-d1e7093595cd">
											<gml:posList>35.669227414774305 139.7377740870635 66.512 35.66925550965036 139.73775020504115 66.512 35.66925550965036 139.73775020504115 65.702 35.669227414774305 139.7377740870635 65.702 35.669227414774305 139.7377740870635 66.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3a8a04eb-9c1c-4e33-b742-fcf020b2d587">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a8a04eb-9c1c-4e33-b742-fcf020b2d587">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a8a04eb-9c1c-4e33-b742-fcf020b2d587">
											<gml:posList>35.66922648239608 139.73778045072845 21.407 35.66926071148958 139.73775135868107 21.407 35.66926071148958 139.73775135868107 66.512 35.66922648239608 139.73778045072845 66.512 35.66922648239608 139.73778045072845 21.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e29d158b-a0a0-47f8-aef6-175eb1cfa18d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e29d158b-a0a0-47f8-aef6-175eb1cfa18d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e29d158b-a0a0-47f8-aef6-175eb1cfa18d">
											<gml:posList>35.669211318212604 139.73775384770332 21.407 35.66922648239608 139.73778045072845 21.407 35.66922648239608 139.73778045072845 66.512 35.669211318212604 139.73775384770332 66.512 35.669211318212604 139.73775384770332 21.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂六丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7368</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">1048.0137</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">6</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>