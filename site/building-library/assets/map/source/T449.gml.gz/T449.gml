<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_83998ecc-743c-4c60-96cf-7cc53f519ddd">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">31.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66691225049645 139.74224580367598 0 35.6669296192157 139.74224481191737 0 35.66692944437028 139.74224007347453 0 35.66693958438013 139.74223948757464 0 35.66693827858102 139.7422053244436 0 35.666943596455035 139.742205020164 0 35.666943247111995 139.74219600719948 0 35.666956794168755 139.74219522964324 0 35.666954863086914 139.74214477467962 0 35.666939396190024 139.74214566488547 0 35.666938274161545 139.7421161518227 0 35.66690387022482 139.74211812397033 0 35.66690284031055 139.7420912286662 0 35.666865110450594 139.74209339238612 0 35.66658601962487 139.7419170886075 0 35.666573145436935 139.74193744952836 0 35.666574350191446 139.74196901686673 0 35.66656045160828 139.7419698059036 0 35.666562971442566 139.7420358233832 0 35.66657782543118 139.7420349669955 0 35.6665795359354 139.74207975550763 0 35.666614002969396 139.74207778328002 0 35.666614085608046 139.74207978246503 0 35.66663258098423 139.74207871207196 0 35.66663349137129 139.74210250356734 0 35.66665439331275 139.74210129789228 0 35.66665452218285 139.7421048323845 0 35.666706772541886 139.7421018347701 0 35.66670864857228 139.74215098624018 0 35.666720861471994 139.7421500445094 0 35.666721854707795 139.74217613345482 0 35.66673440128286 139.74217541226352 0 35.6667346219938 139.7421811999895 0 35.66675832708825 139.74217983650627 0 35.66675906293437 139.7421993203918 0 35.66676986993511 139.74219870059272 0 35.66677002626987 139.74220279839284 0 35.66679436230035 139.742201401061 0 35.66679500595806 139.74221817884762 0 35.66684985216395 139.7422150347569 0 35.66685160869758 139.7422611820027 0 35.66686958131183 139.74226015642495 0 35.66687105265772 139.74229870451285 0 35.66691101783423 139.742296416848 0 35.666909868400595 139.74226637362716 0 35.666913023071864 139.74226619331196 0 35.66691225049645 139.74224580367598 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66691225049645 139.74224580367598 24.76 35.666913023071864 139.74226619331196 24.76 35.666909868400595 139.74226637362716 24.76 35.66691101783423 139.742296416848 24.76 35.66687105265772 139.74229870451285 24.76 35.66686958131183 139.74226015642495 24.76 35.66685160869758 139.7422611820027 24.76 35.66684985216395 139.7422150347569 24.76 35.66679500595806 139.74221817884762 24.76 35.66679436230035 139.742201401061 24.76 35.66677002626987 139.74220279839284 24.76 35.66676986993511 139.74219870059272 24.76 35.66675906293437 139.7421993203918 24.76 35.66675832708825 139.74217983650627 24.76 35.6667346219938 139.7421811999895 24.76 35.66673440128286 139.74217541226352 24.76 35.666721854707795 139.74217613345482 24.76 35.666720861471994 139.7421500445094 24.76 35.66670864857228 139.74215098624018 24.76 35.666706772541886 139.7421018347701 24.76 35.66665452218285 139.7421048323845 24.76 35.66665439331275 139.74210129789228 24.76 35.66663349137129 139.74210250356734 24.76 35.66663258098423 139.74207871207196 24.76 35.666614085608046 139.74207978246503 24.76 35.666614002969396 139.74207778328002 24.76 35.6665795359354 139.74207975550763 24.76 35.66657782543118 139.7420349669955 24.76 35.666562971442566 139.7420358233832 24.76 35.66656045160828 139.7419698059036 24.76 35.666574350191446 139.74196901686673 24.76 35.666573145436935 139.74193744952836 24.76 35.66658601962487 139.7419170886075 24.76 35.666865110450594 139.74209339238612 24.76 35.66690284031055 139.7420912286662 24.76 35.66690387022482 139.74211812397033 24.76 35.666938274161545 139.7421161518227 24.76 35.666939396190024 139.74214566488547 24.76 35.666954863086914 139.74214477467962 24.76 35.666956794168755 139.74219522964324 24.76 35.666943247111995 139.74219600719948 24.76 35.666943596455035 139.742205020164 24.76 35.66693827858102 139.7422053244436 24.76 35.66693958438013 139.74223948757464 24.76 35.66692944437028 139.74224007347453 24.76 35.6669296192157 139.74224481191737 24.76 35.66691225049645 139.74224580367598 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66691225049645 139.74224580367598 24.76 35.6669296192157 139.74224481191737 24.76 35.6669296192157 139.74224481191737 56.53 35.66691225049645 139.74224580367598 56.53 35.66691225049645 139.74224580367598 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6669296192157 139.74224481191737 24.76 35.66692944437028 139.74224007347453 24.76 35.66692944437028 139.74224007347453 56.53 35.6669296192157 139.74224481191737 56.53 35.6669296192157 139.74224481191737 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66692944437028 139.74224007347453 24.76 35.66693958438013 139.74223948757464 24.76 35.66693958438013 139.74223948757464 56.53 35.66692944437028 139.74224007347453 56.53 35.66692944437028 139.74224007347453 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66693958438013 139.74223948757464 24.76 35.66693827858102 139.7422053244436 24.76 35.66693827858102 139.7422053244436 56.53 35.66693958438013 139.74223948757464 56.53 35.66693958438013 139.74223948757464 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66693827858102 139.7422053244436 24.76 35.666943596455035 139.742205020164 24.76 35.666943596455035 139.742205020164 56.53 35.66693827858102 139.7422053244436 56.53 35.66693827858102 139.7422053244436 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666943596455035 139.742205020164 24.76 35.666943247111995 139.74219600719948 24.76 35.666943247111995 139.74219600719948 56.53 35.666943596455035 139.742205020164 56.53 35.666943596455035 139.742205020164 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666943247111995 139.74219600719948 24.76 35.666956794168755 139.74219522964324 24.76 35.666956794168755 139.74219522964324 56.53 35.666943247111995 139.74219600719948 56.53 35.666943247111995 139.74219600719948 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666956794168755 139.74219522964324 24.76 35.666954863086914 139.74214477467962 24.76 35.666954863086914 139.74214477467962 56.53 35.666956794168755 139.74219522964324 56.53 35.666956794168755 139.74219522964324 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666954863086914 139.74214477467962 24.76 35.666939396190024 139.74214566488547 24.76 35.666939396190024 139.74214566488547 56.53 35.666954863086914 139.74214477467962 56.53 35.666954863086914 139.74214477467962 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666939396190024 139.74214566488547 24.76 35.666938274161545 139.7421161518227 24.76 35.666938274161545 139.7421161518227 56.53 35.666939396190024 139.74214566488547 56.53 35.666939396190024 139.74214566488547 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666938274161545 139.7421161518227 24.76 35.66690387022482 139.74211812397033 24.76 35.66690387022482 139.74211812397033 56.53 35.666938274161545 139.7421161518227 56.53 35.666938274161545 139.7421161518227 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66690387022482 139.74211812397033 24.76 35.66690284031055 139.7420912286662 24.76 35.66690284031055 139.7420912286662 56.53 35.66690387022482 139.74211812397033 56.53 35.66690387022482 139.74211812397033 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66690284031055 139.7420912286662 24.76 35.666865110450594 139.74209339238612 24.76 35.666865110450594 139.74209339238612 56.53 35.66690284031055 139.7420912286662 56.53 35.66690284031055 139.7420912286662 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666865110450594 139.74209339238612 24.76 35.66658601962487 139.7419170886075 24.76 35.66658601962487 139.7419170886075 56.53 35.666865110450594 139.74209339238612 56.53 35.666865110450594 139.74209339238612 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66658601962487 139.7419170886075 24.76 35.666573145436935 139.74193744952836 24.76 35.666573145436935 139.74193744952836 56.53 35.66658601962487 139.7419170886075 56.53 35.66658601962487 139.7419170886075 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666573145436935 139.74193744952836 24.76 35.666574350191446 139.74196901686673 24.76 35.666574350191446 139.74196901686673 56.53 35.666573145436935 139.74193744952836 56.53 35.666573145436935 139.74193744952836 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666574350191446 139.74196901686673 24.76 35.66656045160828 139.7419698059036 24.76 35.66656045160828 139.7419698059036 56.53 35.666574350191446 139.74196901686673 56.53 35.666574350191446 139.74196901686673 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66656045160828 139.7419698059036 24.76 35.666562971442566 139.7420358233832 24.76 35.666562971442566 139.7420358233832 56.53 35.66656045160828 139.7419698059036 56.53 35.66656045160828 139.7419698059036 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666562971442566 139.7420358233832 24.76 35.66657782543118 139.7420349669955 24.76 35.66657782543118 139.7420349669955 56.53 35.666562971442566 139.7420358233832 56.53 35.666562971442566 139.7420358233832 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66657782543118 139.7420349669955 24.76 35.6665795359354 139.74207975550763 24.76 35.6665795359354 139.74207975550763 56.53 35.66657782543118 139.7420349669955 56.53 35.66657782543118 139.7420349669955 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6665795359354 139.74207975550763 24.76 35.666614002969396 139.74207778328002 24.76 35.666614002969396 139.74207778328002 56.53 35.6665795359354 139.74207975550763 56.53 35.6665795359354 139.74207975550763 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666614002969396 139.74207778328002 24.76 35.666614085608046 139.74207978246503 24.76 35.666614085608046 139.74207978246503 56.53 35.666614002969396 139.74207778328002 56.53 35.666614002969396 139.74207778328002 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666614085608046 139.74207978246503 24.76 35.66663258098423 139.74207871207196 24.76 35.66663258098423 139.74207871207196 56.53 35.666614085608046 139.74207978246503 56.53 35.666614085608046 139.74207978246503 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66663258098423 139.74207871207196 24.76 35.66663349137129 139.74210250356734 24.76 35.66663349137129 139.74210250356734 56.53 35.66663258098423 139.74207871207196 56.53 35.66663258098423 139.74207871207196 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66663349137129 139.74210250356734 24.76 35.66665439331275 139.74210129789228 24.76 35.66665439331275 139.74210129789228 56.53 35.66663349137129 139.74210250356734 56.53 35.66663349137129 139.74210250356734 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66665439331275 139.74210129789228 24.76 35.66665452218285 139.7421048323845 24.76 35.66665452218285 139.7421048323845 56.53 35.66665439331275 139.74210129789228 56.53 35.66665439331275 139.74210129789228 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66665452218285 139.7421048323845 24.76 35.666706772541886 139.7421018347701 24.76 35.666706772541886 139.7421018347701 56.53 35.66665452218285 139.7421048323845 56.53 35.66665452218285 139.7421048323845 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666706772541886 139.7421018347701 24.76 35.66670864857228 139.74215098624018 24.76 35.66670864857228 139.74215098624018 56.53 35.666706772541886 139.7421018347701 56.53 35.666706772541886 139.7421018347701 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66670864857228 139.74215098624018 24.76 35.666720861471994 139.7421500445094 24.76 35.666720861471994 139.7421500445094 56.53 35.66670864857228 139.74215098624018 56.53 35.66670864857228 139.74215098624018 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666720861471994 139.7421500445094 24.76 35.666721854707795 139.74217613345482 24.76 35.666721854707795 139.74217613345482 56.53 35.666720861471994 139.7421500445094 56.53 35.666720861471994 139.7421500445094 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666721854707795 139.74217613345482 24.76 35.66673440128286 139.74217541226352 24.76 35.66673440128286 139.74217541226352 56.53 35.666721854707795 139.74217613345482 56.53 35.666721854707795 139.74217613345482 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66673440128286 139.74217541226352 24.76 35.6667346219938 139.7421811999895 24.76 35.6667346219938 139.7421811999895 56.53 35.66673440128286 139.74217541226352 56.53 35.66673440128286 139.74217541226352 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6667346219938 139.7421811999895 24.76 35.66675832708825 139.74217983650627 24.76 35.66675832708825 139.74217983650627 56.53 35.6667346219938 139.7421811999895 56.53 35.6667346219938 139.7421811999895 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66675832708825 139.74217983650627 24.76 35.66675906293437 139.7421993203918 24.76 35.66675906293437 139.7421993203918 56.53 35.66675832708825 139.74217983650627 56.53 35.66675832708825 139.74217983650627 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66675906293437 139.7421993203918 24.76 35.66676986993511 139.74219870059272 24.76 35.66676986993511 139.74219870059272 56.53 35.66675906293437 139.7421993203918 56.53 35.66675906293437 139.7421993203918 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66676986993511 139.74219870059272 24.76 35.66677002626987 139.74220279839284 24.76 35.66677002626987 139.74220279839284 56.53 35.66676986993511 139.74219870059272 56.53 35.66676986993511 139.74219870059272 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66677002626987 139.74220279839284 24.76 35.66679436230035 139.742201401061 24.76 35.66679436230035 139.742201401061 56.53 35.66677002626987 139.74220279839284 56.53 35.66677002626987 139.74220279839284 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66679436230035 139.742201401061 24.76 35.66679500595806 139.74221817884762 24.76 35.66679500595806 139.74221817884762 56.53 35.66679436230035 139.742201401061 56.53 35.66679436230035 139.742201401061 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66679500595806 139.74221817884762 24.76 35.66684985216395 139.7422150347569 24.76 35.66684985216395 139.7422150347569 56.53 35.66679500595806 139.74221817884762 56.53 35.66679500595806 139.74221817884762 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66684985216395 139.7422150347569 24.76 35.66685160869758 139.7422611820027 24.76 35.66685160869758 139.7422611820027 56.53 35.66684985216395 139.7422150347569 56.53 35.66684985216395 139.7422150347569 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66685160869758 139.7422611820027 24.76 35.66686958131183 139.74226015642495 24.76 35.66686958131183 139.74226015642495 56.53 35.66685160869758 139.7422611820027 56.53 35.66685160869758 139.7422611820027 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66686958131183 139.74226015642495 24.76 35.66687105265772 139.74229870451285 24.76 35.66687105265772 139.74229870451285 56.53 35.66686958131183 139.74226015642495 56.53 35.66686958131183 139.74226015642495 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66687105265772 139.74229870451285 24.76 35.66691101783423 139.742296416848 24.76 35.66691101783423 139.742296416848 56.53 35.66687105265772 139.74229870451285 56.53 35.66687105265772 139.74229870451285 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66691101783423 139.742296416848 24.76 35.666909868400595 139.74226637362716 24.76 35.666909868400595 139.74226637362716 56.53 35.66691101783423 139.742296416848 56.53 35.66691101783423 139.742296416848 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666909868400595 139.74226637362716 24.76 35.666913023071864 139.74226619331196 24.76 35.666913023071864 139.74226619331196 56.53 35.666909868400595 139.74226637362716 56.53 35.666909868400595 139.74226637362716 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666913023071864 139.74226619331196 24.76 35.66691225049645 139.74224580367598 24.76 35.66691225049645 139.74224580367598 56.53 35.666913023071864 139.74226619331196 56.53 35.666913023071864 139.74226619331196 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66691225049645 139.74224580367598 56.53 35.6669296192157 139.74224481191737 56.53 35.66692944437028 139.74224007347453 56.53 35.66693958438013 139.74223948757464 56.53 35.66693827858102 139.7422053244436 56.53 35.666943596455035 139.742205020164 56.53 35.666943247111995 139.74219600719948 56.53 35.666956794168755 139.74219522964324 56.53 35.666954863086914 139.74214477467962 56.53 35.666939396190024 139.74214566488547 56.53 35.666938274161545 139.7421161518227 56.53 35.66690387022482 139.74211812397033 56.53 35.66690284031055 139.7420912286662 56.53 35.666865110450594 139.74209339238612 56.53 35.66658601962487 139.7419170886075 56.53 35.666573145436935 139.74193744952836 56.53 35.666574350191446 139.74196901686673 56.53 35.66656045160828 139.7419698059036 56.53 35.666562971442566 139.7420358233832 56.53 35.66657782543118 139.7420349669955 56.53 35.6665795359354 139.74207975550763 56.53 35.666614002969396 139.74207778328002 56.53 35.666614085608046 139.74207978246503 56.53 35.66663258098423 139.74207871207196 56.53 35.66663349137129 139.74210250356734 56.53 35.66665439331275 139.74210129789228 56.53 35.66665452218285 139.7421048323845 56.53 35.666706772541886 139.7421018347701 56.53 35.66670864857228 139.74215098624018 56.53 35.666720861471994 139.7421500445094 56.53 35.666721854707795 139.74217613345482 56.53 35.66673440128286 139.74217541226352 56.53 35.6667346219938 139.7421811999895 56.53 35.66675832708825 139.74217983650627 56.53 35.66675906293437 139.7421993203918 56.53 35.66676986993511 139.74219870059272 56.53 35.66677002626987 139.74220279839284 56.53 35.66679436230035 139.742201401061 56.53 35.66679500595806 139.74221817884762 56.53 35.66684985216395 139.7422150347569 56.53 35.66685160869758 139.7422611820027 56.53 35.66686958131183 139.74226015642495 56.53 35.66687105265772 139.74229870451285 56.53 35.66691101783423 139.742296416848 56.53 35.666909868400595 139.74226637362716 56.53 35.666913023071864 139.74226619331196 56.53 35.66691225049645 139.74224580367598 56.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-8626d597-c6d6-4449-9969-5315b79fecad"/>
							<gml:surfaceMember xlink:href="#poly-ffb19a6c-5630-44e5-a57d-8078fadc2321"/>
							<gml:surfaceMember xlink:href="#poly-a7e0fbc6-8fdb-4747-a66d-69df8e56d75a"/>
							<gml:surfaceMember xlink:href="#poly-bc395ad2-e35a-4f6e-88e1-b0ff791cf593"/>
							<gml:surfaceMember xlink:href="#poly-1c543cf2-ed3f-4017-a7cf-7df0fff3e837"/>
							<gml:surfaceMember xlink:href="#poly-893450a7-5a61-476c-bad5-860a80658c5d"/>
							<gml:surfaceMember xlink:href="#poly-f26e734f-26f4-4979-9b11-5a09c5593fa9"/>
							<gml:surfaceMember xlink:href="#poly-052e5d76-e583-4123-95be-921cc0166556"/>
							<gml:surfaceMember xlink:href="#poly-3af6b848-cf54-4051-9dbd-c2dbf0c8f4e7"/>
							<gml:surfaceMember xlink:href="#poly-764c07bb-8bbd-4d86-bb79-b558c0460149"/>
							<gml:surfaceMember xlink:href="#poly-bff4b848-be18-4471-bfe4-68e99101543e"/>
							<gml:surfaceMember xlink:href="#poly-7daf5680-6dc2-4ecb-8c58-27809853a095"/>
							<gml:surfaceMember xlink:href="#poly-a05b3033-cf88-447f-b9b7-920137513b35"/>
							<gml:surfaceMember xlink:href="#poly-7228f8b4-3362-41b8-af18-f5a680c2ac7c"/>
							<gml:surfaceMember xlink:href="#poly-9e24f01b-1119-49f4-a676-a959cc7ff5f5"/>
							<gml:surfaceMember xlink:href="#poly-4d08e447-84a1-4ca8-a913-b0ec08029c81"/>
							<gml:surfaceMember xlink:href="#poly-dd0c831b-6f14-4c2d-8fd3-19e17565405b"/>
							<gml:surfaceMember xlink:href="#poly-0ce7258b-54b9-4efb-876f-e20fd2ccd878"/>
							<gml:surfaceMember xlink:href="#poly-2c6187df-2200-4e1a-8891-365daa1bf1fc"/>
							<gml:surfaceMember xlink:href="#poly-04e1bd39-9b4b-45fd-8f25-4ee5bb32b6e8"/>
							<gml:surfaceMember xlink:href="#poly-7c77cc92-82d3-417d-a685-42b5bad12fa2"/>
							<gml:surfaceMember xlink:href="#poly-e22a25df-6b09-4ded-9e1a-5cc2a1b32b0a"/>
							<gml:surfaceMember xlink:href="#poly-bee5aede-0fcf-4b2c-b018-f02ea4637edb"/>
							<gml:surfaceMember xlink:href="#poly-c92e5170-52f7-4d29-81fc-f3d7bf916693"/>
							<gml:surfaceMember xlink:href="#poly-a06bd503-d797-4b9f-bb8f-1dcc9cc8ad09"/>
							<gml:surfaceMember xlink:href="#poly-efb2ae00-bdf7-4fb7-aaa2-8e8dab74fba3"/>
							<gml:surfaceMember xlink:href="#poly-a430a499-7830-4540-973c-8f2dbeb8a7f3"/>
							<gml:surfaceMember xlink:href="#poly-725f2a49-e3fc-4979-b7e8-827b00daa330"/>
							<gml:surfaceMember xlink:href="#poly-6403e9e1-4eae-4a54-ae71-5f3a9535efa1"/>
							<gml:surfaceMember xlink:href="#poly-0a69b2da-d701-4bd8-a972-6c856daeb048"/>
							<gml:surfaceMember xlink:href="#poly-17fba13b-f059-44d0-9704-0da930a3502f"/>
							<gml:surfaceMember xlink:href="#poly-7aded37b-bed7-4f89-be2a-5f8e1b36f23d"/>
							<gml:surfaceMember xlink:href="#poly-a7be4a50-4320-4a73-8c1f-5cdddbe76c9a"/>
							<gml:surfaceMember xlink:href="#poly-3a978c8c-af5b-49a4-84d0-79552cacf6e2"/>
							<gml:surfaceMember xlink:href="#poly-d238c705-9a96-42db-889f-fdf493546a71"/>
							<gml:surfaceMember xlink:href="#poly-c03b1815-6398-4f78-a8e1-0ca99cbef3c0"/>
							<gml:surfaceMember xlink:href="#poly-ae83533a-9d1d-4e31-9064-a1fc21a9b301"/>
							<gml:surfaceMember xlink:href="#poly-79800983-4fdf-4d80-b3a3-bc8e5901827c"/>
							<gml:surfaceMember xlink:href="#poly-3a813e11-90e2-498a-a840-f9768e41c9af"/>
							<gml:surfaceMember xlink:href="#poly-9508c875-b8f7-4e44-ad20-4dfa5c42d00a"/>
							<gml:surfaceMember xlink:href="#poly-7cbeb549-a5ba-431d-9629-eb78a7a452ef"/>
							<gml:surfaceMember xlink:href="#poly-e9c84c98-03da-4c2a-8dae-566ed6990366"/>
							<gml:surfaceMember xlink:href="#poly-af287ef1-5a70-47b9-94dd-1b02e3617ce5"/>
							<gml:surfaceMember xlink:href="#poly-45c0bb7d-65e1-40e8-9989-c5416cc42db9"/>
							<gml:surfaceMember xlink:href="#poly-f8b99107-9210-4509-a19b-fa1c7b7b81b2"/>
							<gml:surfaceMember xlink:href="#poly-739935b3-43b0-4be4-a444-b1d14e777f22"/>
							<gml:surfaceMember xlink:href="#poly-fb8690ba-a807-4efb-99ca-4fff1a40d64b"/>
							<gml:surfaceMember xlink:href="#poly-71fa9df9-c07b-4f34-b404-12f25f4e4104"/>
							<gml:surfaceMember xlink:href="#poly-0da56f73-335a-4c95-90a7-c798af45f317"/>
							<gml:surfaceMember xlink:href="#poly-f93ba772-e7d9-42f5-9efe-cdb518a031ae"/>
							<gml:surfaceMember xlink:href="#poly-3be027c7-8704-4008-95b9-700acba64c0c"/>
							<gml:surfaceMember xlink:href="#poly-9e7c3b51-5976-41e5-aa73-345a603e3151"/>
							<gml:surfaceMember xlink:href="#poly-450ab019-45f4-46db-8e32-3d658d6c6cb0"/>
							<gml:surfaceMember xlink:href="#poly-0d81932b-1fb9-45ff-9ac2-3daf0406ea87"/>
							<gml:surfaceMember xlink:href="#poly-54cafbdc-ed75-46b0-a6d9-fac7043411c0"/>
							<gml:surfaceMember xlink:href="#poly-1333d9e3-bcfc-4f44-962d-d33d559f8846"/>
							<gml:surfaceMember xlink:href="#poly-44dc822b-6ef8-497c-92c7-10efcc9a02d1"/>
							<gml:surfaceMember xlink:href="#poly-8d429143-1304-4d19-b9d9-5a6b5b74e9ab"/>
							<gml:surfaceMember xlink:href="#poly-9d1de19c-ceab-4c1d-b857-a8bf3c2793dd"/>
							<gml:surfaceMember xlink:href="#poly-fb4c0cd7-f0c0-4cb0-b0b2-4ff75f89a43f"/>
							<gml:surfaceMember xlink:href="#poly-67abb687-7400-4997-a2ec-482e60394bce"/>
							<gml:surfaceMember xlink:href="#poly-3e651ab1-2b6e-4ee4-b0d6-b263cd3a36ed"/>
							<gml:surfaceMember xlink:href="#poly-6db14ed1-552e-4fcd-bbb8-648d7e896412"/>
							<gml:surfaceMember xlink:href="#poly-0a0ec481-3338-4bb4-b24b-4ee8caaa9db6"/>
							<gml:surfaceMember xlink:href="#poly-b671fbbc-c6c5-4549-a4f3-c5020ded58df"/>
							<gml:surfaceMember xlink:href="#poly-bbfae854-a9d1-4cb3-9c49-0aab29235b03"/>
							<gml:surfaceMember xlink:href="#poly-260bbbcf-efca-4095-a444-f10d575244fa"/>
							<gml:surfaceMember xlink:href="#poly-a539ab8d-8ea5-48b9-bc3f-c895c8298dd4"/>
							<gml:surfaceMember xlink:href="#poly-dd5f5f58-73de-4251-a526-87040aa09a38"/>
							<gml:surfaceMember xlink:href="#poly-ac5bbd7f-af45-4ce4-ba1d-e1f6a3f1508e"/>
							<gml:surfaceMember xlink:href="#poly-3ecbadbe-b40b-47b7-9554-fecb14b70128"/>
							<gml:surfaceMember xlink:href="#poly-32d055d7-f9d6-4742-b1f2-239368d678ff"/>
							<gml:surfaceMember xlink:href="#poly-4ca13ee5-d0c2-416e-a76c-d24815b37704"/>
							<gml:surfaceMember xlink:href="#poly-e09a987f-3f87-4ebd-8f3f-58d8108911c1"/>
							<gml:surfaceMember xlink:href="#poly-bdfb8d21-62ad-420a-a033-65ca08f4d3cd"/>
							<gml:surfaceMember xlink:href="#poly-d1dbc4b8-8c8c-46cd-86ba-dfa582f0c04d"/>
							<gml:surfaceMember xlink:href="#poly-eeaa1708-4026-43e7-8325-155f206a4c37"/>
							<gml:surfaceMember xlink:href="#poly-dec6634d-f1c2-45a3-8aa0-66de2c9b9087"/>
							<gml:surfaceMember xlink:href="#poly-c835db36-7df2-41da-b299-2626f17cb162"/>
							<gml:surfaceMember xlink:href="#poly-2f260c17-ff50-4e4b-a7d2-f13fa68ce480"/>
							<gml:surfaceMember xlink:href="#poly-85497710-e707-4bb4-8908-7e36215616f8"/>
							<gml:surfaceMember xlink:href="#poly-6e2bbfed-28d4-4a49-b8f7-5aa5bcb17e42"/>
							<gml:surfaceMember xlink:href="#poly-92417f4f-6915-4965-8746-fa91200e540d"/>
							<gml:surfaceMember xlink:href="#poly-5f3abf65-78ad-42e0-9793-1a8a166ce33b"/>
							<gml:surfaceMember xlink:href="#poly-5f60bf31-db1f-4e98-a7cf-8e338f053eb2"/>
							<gml:surfaceMember xlink:href="#poly-c12f868e-808b-416b-a622-e18b980f0926"/>
							<gml:surfaceMember xlink:href="#poly-83a81208-1b0e-4409-8b41-e2a8d6941906"/>
							<gml:surfaceMember xlink:href="#poly-4c9ab3bb-3279-435a-a385-43f642a215c0"/>
							<gml:surfaceMember xlink:href="#poly-405e7530-00ad-4f12-a9e0-d80836e820e5"/>
							<gml:surfaceMember xlink:href="#poly-86b47fec-8312-47a3-83b8-51e4bd558280"/>
							<gml:surfaceMember xlink:href="#poly-0ac6faeb-3fed-41c0-8704-b3f486db8b74"/>
							<gml:surfaceMember xlink:href="#poly-2432218e-b741-4ee6-8ebe-7fde71375a8e"/>
							<gml:surfaceMember xlink:href="#poly-06e69818-d5bf-4e56-bde4-d14e905b7966"/>
							<gml:surfaceMember xlink:href="#poly-60d540e1-f99e-42eb-b413-4d6e69605c61"/>
							<gml:surfaceMember xlink:href="#poly-30de84e7-1869-43d7-9520-24efb74fcfb1"/>
							<gml:surfaceMember xlink:href="#poly-6c2321f6-b2c1-464c-bfb6-4762095f16f0"/>
							<gml:surfaceMember xlink:href="#poly-b2408e3e-1c80-4baf-94e0-261c1314ddc7"/>
							<gml:surfaceMember xlink:href="#poly-6ed21f42-1879-44dd-bdec-7e529e6c470a"/>
							<gml:surfaceMember xlink:href="#poly-fa0f3952-c623-4835-976c-97b61b86f659"/>
							<gml:surfaceMember xlink:href="#poly-350ff88e-db42-402f-8a6e-22b9d40b1092"/>
							<gml:surfaceMember xlink:href="#poly-8e8ec719-69c0-4ad7-af08-9ebef66f4a0d"/>
							<gml:surfaceMember xlink:href="#poly-43861f6a-b4f8-4330-a5e2-67ba70d3a92f"/>
							<gml:surfaceMember xlink:href="#poly-99c852c9-e62b-4a35-94f0-3d8aeaa02147"/>
							<gml:surfaceMember xlink:href="#poly-848c2629-909f-4a26-9a81-705e6ed2d04e"/>
							<gml:surfaceMember xlink:href="#poly-7ac9ccae-c60a-4b47-929b-4b7b568f7639"/>
							<gml:surfaceMember xlink:href="#poly-4b1b0923-4903-4c60-bd78-9e2c9b756370"/>
							<gml:surfaceMember xlink:href="#poly-2b068a0d-f864-40bd-b24d-be49058184d1"/>
							<gml:surfaceMember xlink:href="#poly-0bd22f3f-3fe4-41f7-b447-d138cd39afa4"/>
							<gml:surfaceMember xlink:href="#poly-ad281013-e780-494f-996b-29467adb9fe8"/>
							<gml:surfaceMember xlink:href="#poly-fda4ad3e-ff6e-45b2-aa4f-45d437e3678b"/>
							<gml:surfaceMember xlink:href="#poly-9530dfda-f466-4031-8055-a11dffdc30fa"/>
							<gml:surfaceMember xlink:href="#poly-77b65ede-0aa9-497d-b0a6-05ef60db50b9"/>
							<gml:surfaceMember xlink:href="#poly-f14472f6-2dbf-48aa-b4d3-3ac950acada0"/>
							<gml:surfaceMember xlink:href="#poly-057b2c28-315c-46d0-88be-15354dc07e9a"/>
							<gml:surfaceMember xlink:href="#poly-f296db8e-10e5-4899-a686-2a48a28b227a"/>
							<gml:surfaceMember xlink:href="#poly-f6e5ae6b-a8f7-46b6-a658-8013d06227b4"/>
							<gml:surfaceMember xlink:href="#poly-2551a5d4-3259-49b6-922d-aaf2decd49dc"/>
							<gml:surfaceMember xlink:href="#poly-4b5ecd9e-04d0-41e7-9a16-1a2971fb5a22"/>
							<gml:surfaceMember xlink:href="#poly-df851d8c-faba-43b3-80b5-60850ed3524d"/>
							<gml:surfaceMember xlink:href="#poly-3451d221-a601-4b32-9c6b-3c12a7c94dad"/>
							<gml:surfaceMember xlink:href="#poly-d8289195-fe76-44c8-8e77-fb43fa85f771"/>
							<gml:surfaceMember xlink:href="#poly-55f9eda2-b7e3-48ad-85c5-fba5715b745c"/>
							<gml:surfaceMember xlink:href="#poly-315918a8-ceae-4046-a0b8-62845a801038"/>
							<gml:surfaceMember xlink:href="#poly-e4e403f3-bda5-472e-a146-5b7cb6d4fe6f"/>
							<gml:surfaceMember xlink:href="#poly-a4a98f1d-c659-4779-b913-0342f8acf834"/>
							<gml:surfaceMember xlink:href="#poly-37b7cced-543c-4780-8046-1c0ac313a7d8"/>
							<gml:surfaceMember xlink:href="#poly-7f340590-48ce-4ffe-9e44-fa2b988e3b8a"/>
							<gml:surfaceMember xlink:href="#poly-c06c595c-8fc8-4f70-8937-3594c6672505"/>
							<gml:surfaceMember xlink:href="#poly-605a79da-9372-4624-bf8e-576dd90f7b86"/>
							<gml:surfaceMember xlink:href="#poly-c6a8f438-5314-420c-8fed-47ddb1ae1520"/>
							<gml:surfaceMember xlink:href="#poly-2eb59687-4fbc-40da-be25-3580829314f2"/>
							<gml:surfaceMember xlink:href="#poly-fcb5a851-c585-492b-bd3d-83685be4f769"/>
							<gml:surfaceMember xlink:href="#poly-19c29231-9133-43a6-b436-ffea4dee2d72"/>
							<gml:surfaceMember xlink:href="#poly-bf6fa59b-909f-4d74-9b86-f565945ff164"/>
							<gml:surfaceMember xlink:href="#poly-fc984566-6fb0-49a8-99ce-24dfdc224f5b"/>
							<gml:surfaceMember xlink:href="#poly-e32fe0de-a624-4cba-b8ab-76dd186fb34b"/>
							<gml:surfaceMember xlink:href="#poly-0671c651-1d46-4255-a9b0-150bac43482c"/>
							<gml:surfaceMember xlink:href="#poly-28974766-b7a1-4c0f-87a3-2fd61e1ef943"/>
							<gml:surfaceMember xlink:href="#poly-abb22d26-1aac-474f-a4b4-9071a3825ca4"/>
							<gml:surfaceMember xlink:href="#poly-fe735e88-6de2-4ae8-8df0-3073e528ee86"/>
							<gml:surfaceMember xlink:href="#poly-1b305b74-e91e-495b-ba4d-bb360607382d"/>
							<gml:surfaceMember xlink:href="#poly-8b839752-3ef4-486a-9058-087e4358bb63"/>
							<gml:surfaceMember xlink:href="#poly-45ba4c22-7cb4-4b0c-9647-4b39a90888e8"/>
							<gml:surfaceMember xlink:href="#poly-787de74a-fe1b-4082-94bb-85dca33df6ca"/>
							<gml:surfaceMember xlink:href="#poly-22dea2d6-f295-4af3-a792-5dc239094671"/>
							<gml:surfaceMember xlink:href="#poly-6150b553-d469-487d-af15-21569f920a19"/>
							<gml:surfaceMember xlink:href="#poly-f55c08c7-7f10-4cbe-bb0a-c2bfea4a950c"/>
							<gml:surfaceMember xlink:href="#poly-fb3bc802-a1a5-43d7-b7c9-7bddd8ca34ec"/>
							<gml:surfaceMember xlink:href="#poly-aca5cc4e-e82d-4f46-b629-ba4565d5fefe"/>
							<gml:surfaceMember xlink:href="#poly-a6879e4e-5973-4718-a64a-538bc412381e"/>
							<gml:surfaceMember xlink:href="#poly-cdba9942-ba6c-404c-98f5-1a69db9dec2a"/>
							<gml:surfaceMember xlink:href="#poly-4ae5d345-3120-4f41-9b54-3d0b2c7aa6af"/>
							<gml:surfaceMember xlink:href="#poly-663c0ede-319c-42b2-adf7-ef644f07e0ee"/>
							<gml:surfaceMember xlink:href="#poly-11d85a99-e816-44c9-b658-9de12dc01f46"/>
							<gml:surfaceMember xlink:href="#poly-04b3eba7-6491-479f-8aa9-2d7ffe3745da"/>
							<gml:surfaceMember xlink:href="#poly-9a2399cc-2385-44d5-ac2a-4512215e84c7"/>
							<gml:surfaceMember xlink:href="#poly-a63ab339-ab7d-4ecc-a1e3-046f72467d88"/>
							<gml:surfaceMember xlink:href="#poly-67af45a9-003b-4d3b-aff1-934c71ad3e56"/>
							<gml:surfaceMember xlink:href="#poly-be8e8496-7ee9-4356-8fd3-8229a27f725e"/>
							<gml:surfaceMember xlink:href="#poly-0f369677-d119-4d4c-8608-0aedd85e7f99"/>
							<gml:surfaceMember xlink:href="#poly-c13419ce-a17b-40af-9101-8eb4e4508224"/>
							<gml:surfaceMember xlink:href="#poly-34cc2458-44e4-4569-87a4-59ed4ef054dc"/>
							<gml:surfaceMember xlink:href="#poly-167b2d48-9a5f-4209-bef1-0b98d2dffd20"/>
							<gml:surfaceMember xlink:href="#poly-bf169383-42a1-48d0-9842-f4f0879d2d8d"/>
							<gml:surfaceMember xlink:href="#poly-321c846d-c188-486c-bc3d-9a3a1a92f843"/>
							<gml:surfaceMember xlink:href="#poly-56ecb822-dcf2-400d-8fe9-4170a6156124"/>
							<gml:surfaceMember xlink:href="#poly-a79aadf7-ee43-42ab-8d73-5b4adc4f8b6b"/>
							<gml:surfaceMember xlink:href="#poly-d26d4a9b-93c3-46a9-b960-97392dd5852a"/>
							<gml:surfaceMember xlink:href="#poly-bf472489-a386-49b4-b8d3-166c1115a90b"/>
							<gml:surfaceMember xlink:href="#poly-88bef192-3bf5-4655-adf0-2283c7dd71ec"/>
							<gml:surfaceMember xlink:href="#poly-55ce3edb-26df-412b-abeb-efb3fc31594b"/>
							<gml:surfaceMember xlink:href="#poly-d7497a37-1d09-44ff-b6eb-f368aa88b221"/>
							<gml:surfaceMember xlink:href="#poly-71c195c6-4708-4d57-8be8-6a2c4c330121"/>
							<gml:surfaceMember xlink:href="#poly-a1e648d3-72c2-48e0-a03a-90d8693e765a"/>
							<gml:surfaceMember xlink:href="#poly-58175734-5774-4e09-b813-a9dc9e001790"/>
							<gml:surfaceMember xlink:href="#poly-eebdc101-98f8-4462-b043-aaff432507c5"/>
							<gml:surfaceMember xlink:href="#poly-37b12263-12db-4545-ad86-f3c5a9adfb0f"/>
							<gml:surfaceMember xlink:href="#poly-60d3b8df-2893-4f15-a7fe-a088d002ce09"/>
							<gml:surfaceMember xlink:href="#poly-fc8b0a51-d292-45f7-957f-15deab8b1c83"/>
							<gml:surfaceMember xlink:href="#poly-5cb414f3-7ea9-4130-98de-aa5917b09050"/>
							<gml:surfaceMember xlink:href="#poly-aecdbedf-3dcf-4199-8873-c8caeb826d62"/>
							<gml:surfaceMember xlink:href="#poly-e9d8688e-555b-4aa6-8d25-3d07fe6cbb5b"/>
							<gml:surfaceMember xlink:href="#poly-b0a85c78-3070-4690-a2a0-68d7e34c57ec"/>
							<gml:surfaceMember xlink:href="#poly-1aefd9db-2afa-4157-b1ce-44a4fd3965d0"/>
							<gml:surfaceMember xlink:href="#poly-d066539a-7faa-4314-8d54-3ea62692928b"/>
							<gml:surfaceMember xlink:href="#poly-f417eca0-60ab-4282-9dfd-25b03487f1ca"/>
							<gml:surfaceMember xlink:href="#poly-d95a4ead-ed93-47ec-9395-fe408209a5be"/>
							<gml:surfaceMember xlink:href="#poly-0d1ae567-e275-4005-8b68-4941649d0c2b"/>
							<gml:surfaceMember xlink:href="#poly-1ae1cb4d-57c5-4a8b-a28e-80c500d5315a"/>
							<gml:surfaceMember xlink:href="#poly-df8ec68d-9321-449b-9de5-df0e79e824c7"/>
							<gml:surfaceMember xlink:href="#poly-afe081b5-a766-426f-9d31-1543c62caaf5"/>
							<gml:surfaceMember xlink:href="#poly-4cd13fb2-a82e-4feb-9b9b-e17d72056978"/>
							<gml:surfaceMember xlink:href="#poly-6f7d7f18-8725-499e-830e-ef1682626f0c"/>
							<gml:surfaceMember xlink:href="#poly-19762ece-1692-4d42-b2f6-ac3d0671a61b"/>
							<gml:surfaceMember xlink:href="#poly-bc315bdc-e26e-48b1-92f7-529dd9646541"/>
							<gml:surfaceMember xlink:href="#poly-efc5ded0-d9f6-4f3d-a0ed-7f651987cf3d"/>
							<gml:surfaceMember xlink:href="#poly-cb48ee06-e340-4af4-bfe4-90abb67967bd"/>
							<gml:surfaceMember xlink:href="#poly-f0ba701a-d486-4d0c-8527-e06d3766ff1f"/>
							<gml:surfaceMember xlink:href="#poly-a3732e60-c46e-4499-842b-35754907c079"/>
							<gml:surfaceMember xlink:href="#poly-6c539952-b1c6-4747-b8e5-bf412c3128d4"/>
							<gml:surfaceMember xlink:href="#poly-cbf81cd6-6024-4032-b74a-cc0c817f1538"/>
							<gml:surfaceMember xlink:href="#poly-894ae5a0-1dd3-4801-a4fd-34997e9acebf"/>
							<gml:surfaceMember xlink:href="#poly-8cf22887-4257-4171-9c5a-6a99d2a1d16e"/>
							<gml:surfaceMember xlink:href="#poly-71585931-85d1-4c9e-bbdd-53fe19dcbe26"/>
							<gml:surfaceMember xlink:href="#poly-f8462681-8ae3-4832-b5c1-e9d2a58d37f4"/>
							<gml:surfaceMember xlink:href="#poly-cac83495-c4ee-44c2-92bf-a389c3d78576"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_83998ecc-743c-4c60-96cf-7cc53f519ddd_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d55c93b-5fcb-4ed4-9ad9-9de2fa3dc3c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d55c93b-5fcb-4ed4-9ad9-9de2fa3dc3c9_0">
											<gml:posList>35.66670677254189 139.7421018347701 56.6 35.66670677254189 139.7421018347701 58.895 35.666706671265246 139.7420990292639 56.6 35.66670677254189 139.7421018347701 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61513024-c253-4b67-81b9-c149ea0a8608">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-61513024-c253-4b67-81b9-c149ea0a8608_0">
											<gml:posList>35.66670677254189 139.7421018347701 58.895 35.6667063126495 139.74208968496447 58.895 35.666706671265246 139.7420990292639 56.6 35.66670677254189 139.7421018347701 58.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f9d0954e-acf6-47cf-b3b9-bd90a89e91ad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f9d0954e-acf6-47cf-b3b9-bd90a89e91ad_0">
											<gml:posList>35.666706671265246 139.7420990292639 56.6 35.6667063126495 139.74208968496447 56.038 35.666706671265246 139.7420990292639 56.038 35.666706671265246 139.7420990292639 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9daddb93-4ba0-4f49-8c04-eaa84acf604f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9daddb93-4ba0-4f49-8c04-eaa84acf604f_0">
											<gml:posList>35.666706671265246 139.7420990292639 56.6 35.6667063126495 139.74208968496447 58.895 35.6667063126495 139.74208968496447 56.038 35.666706671265246 139.7420990292639 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-abbbefa2-348a-4441-90a0-31ab3cbd52fb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-abbbefa2-348a-4441-90a0-31ab3cbd52fb_0">
											<gml:posList>35.66670880743525 139.74209891637594 56.038 35.666706671265246 139.7420990292639 56.6 35.666706671265246 139.7420990292639 56.038 35.66670880743525 139.74209891637594 56.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-674d7a69-68f2-4235-b860-d36dbd87bd16">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-674d7a69-68f2-4235-b860-d36dbd87bd16_0">
											<gml:posList>35.66670880743525 139.74209891637594 56.038 35.66670880743525 139.74209891637594 56.6 35.666706671265246 139.7420990292639 56.6 35.66670880743525 139.74209891637594 56.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8caaf339-e90b-4b44-ae68-fa8459ae8c45">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8caaf339-e90b-4b44-ae68-fa8459ae8c45_0">
											<gml:posList>35.66670880743525 139.74209891637594 56.038 35.66670890870352 139.74210171083644 56.6 35.66670880743525 139.74209891637594 56.6 35.66670880743525 139.74209891637594 56.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b12272ff-6ca5-447f-9d82-cbeb334797ed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b12272ff-6ca5-447f-9d82-cbeb334797ed_0">
											<gml:posList>35.66670880743525 139.74209891637594 56.038 35.66670890870352 139.74210171083644 56.038 35.66670890870352 139.74210171083644 56.6 35.66670880743525 139.74209891637594 56.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9160dd6f-49b0-43e2-b4c9-c9b11943b66c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9160dd6f-49b0-43e2-b4c9-c9b11943b66c_0">
											<gml:posList>35.66672655662188 139.74208852421663 56.038 35.6667063126495 139.74208968496447 58.895 35.66672655662188 139.74208852421663 58.895 35.66672655662188 139.74208852421663 56.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7effe039-3e0c-4450-8f9b-fca166ba3202">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7effe039-3e0c-4450-8f9b-fca166ba3202_0">
											<gml:posList>35.66672655662188 139.74208852421663 56.038 35.6667063126495 139.74208968496447 56.038 35.6667063126495 139.74208968496447 58.895 35.66672655662188 139.74208852421663 56.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec5a808b-3bba-4952-bc72-68ec8e181ef8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ec5a808b-3bba-4952-bc72-68ec8e181ef8_0">
											<gml:posList>35.66670890870352 139.74210171083644 56.6 35.666726358545674 139.74210071895692 58.895 35.66670677254189 139.7421018347701 58.895 35.66670890870352 139.74210171083644 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3fd9b13c-8853-48b6-b48a-1eaf2e5c1384">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3fd9b13c-8853-48b6-b48a-1eaf2e5c1384_0">
											<gml:posList>35.66670677254189 139.7421018347701 58.895 35.66670677254189 139.7421018347701 56.6 35.66670890870352 139.74210171083644 56.6 35.66670677254189 139.7421018347701 58.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e3663dfc-88aa-42ff-8114-b4372dfd4633">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e3663dfc-88aa-42ff-8114-b4372dfd4633_0">
											<gml:posList>35.666726358545674 139.74210071895692 56.038 35.666726358545674 139.74210071895692 58.895 35.66670890870352 139.74210171083644 56.6 35.666726358545674 139.74210071895692 56.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-41146dc7-c48a-4168-93f3-eac25c3b951f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-41146dc7-c48a-4168-93f3-eac25c3b951f_0">
											<gml:posList>35.66670890870352 139.74210171083644 56.038 35.666726358545674 139.74210071895692 56.038 35.66670890870352 139.74210171083644 56.6 35.66670890870352 139.74210171083644 56.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f593f9ae-313d-47ca-b5f5-ba9b5d6aa4dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f593f9ae-313d-47ca-b5f5-ba9b5d6aa4dc_0">
											<gml:posList>35.66672701651438 139.7421006740253 58.895 35.66672655662188 139.74208852421663 58.895 35.666726358545674 139.74210071895692 58.895 35.66672701651438 139.7421006740253 58.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-877da56d-0c45-447f-af64-b79491b0e094">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-877da56d-0c45-447f-af64-b79491b0e094_0">
											<gml:posList>35.666726358545674 139.74210071895692 58.895 35.6667063126495 139.74208968496447 58.895 35.66670677254189 139.7421018347701 58.895 35.666726358545674 139.74210071895692 58.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-88075ec1-e912-4114-b940-2710e070e9bc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-88075ec1-e912-4114-b940-2710e070e9bc_0">
											<gml:posList>35.666726358545674 139.74210071895692 58.895 35.66672655662188 139.74208852421663 58.895 35.6667063126495 139.74208968496447 58.895 35.666726358545674 139.74210071895692 58.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-68bc96c5-38c8-4a9b-a1a2-a0899aaf2c6f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-68bc96c5-38c8-4a9b-a1a2-a0899aaf2c6f_0">
											<gml:posList>35.666726358545674 139.74210071895692 58.895 35.66672701651438 139.7421006740253 56.038 35.66672701651438 139.7421006740253 58.895 35.666726358545674 139.74210071895692 58.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab531c83-b3b5-4a52-b25b-efa2cf5c5806">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ab531c83-b3b5-4a52-b25b-efa2cf5c5806_0">
											<gml:posList>35.666726358545674 139.74210071895692 58.895 35.666726358545674 139.74210071895692 56.038 35.66672701651438 139.7421006740253 56.038 35.666726358545674 139.74210071895692 58.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-12c058ef-e6fe-41ad-a520-877c52a5ba8d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-12c058ef-e6fe-41ad-a520-877c52a5ba8d_0">
											<gml:posList>35.66672655662188 139.74208852421663 58.895 35.66672701651438 139.7421006740253 56.038 35.66672655662188 139.74208852421663 56.038 35.66672655662188 139.74208852421663 58.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37c12dce-bede-4850-bc9b-fbdbfe734297">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-37c12dce-bede-4850-bc9b-fbdbfe734297_0">
											<gml:posList>35.66672655662188 139.74208852421663 58.895 35.66672701651438 139.7421006740253 58.895 35.66672701651438 139.7421006740253 56.038 35.66672655662188 139.74208852421663 58.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-83ad6a29-e7af-4028-a517-05b34bcb17da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-83ad6a29-e7af-4028-a517-05b34bcb17da_0">
											<gml:posList>35.66684919020247 139.74219789246908 56.038 35.666849622315574 139.74220908134626 58.895 35.66684919020247 139.74219789246908 58.895 35.66684919020247 139.74219789246908 56.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a3435447-6a17-4813-bc2c-a63663c05dc1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a3435447-6a17-4813-bc2c-a63663c05dc1_0">
											<gml:posList>35.66684919020247 139.74219789246908 56.038 35.666849622315574 139.74220908134626 56.038 35.666849622315574 139.74220908134626 58.895 35.66684919020247 139.74219789246908 56.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca856459-c9ff-45f9-b9ac-bcbee8ba0562">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ca856459-c9ff-45f9-b9ac-bcbee8ba0562_0">
											<gml:posList>35.66684919020247 139.74219789246908 56.038 35.66687106558504 139.74219663048027 58.895 35.66687106558504 139.74219663048027 56.038 35.66684919020247 139.74219789246908 56.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6fcb7b3d-e00a-4007-af93-36fea8aeab10">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6fcb7b3d-e00a-4007-af93-36fea8aeab10_0">
											<gml:posList>35.66684919020247 139.74219789246908 56.038 35.66684919020247 139.74219789246908 58.895 35.66687106558504 139.74219663048027 58.895 35.66684919020247 139.74219789246908 56.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f97a230-40bf-4bfa-b112-7f503bfb4a8f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0f97a230-40bf-4bfa-b112-7f503bfb4a8f_0">
											<gml:posList>35.66684919020247 139.74219789246908 58.895 35.666849622315574 139.74220908134626 58.895 35.6668714886929 139.74220783041653 58.895 35.66684919020247 139.74219789246908 58.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46daf815-f89b-4362-ba4b-3cd46d17dffe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46daf815-f89b-4362-ba4b-3cd46d17dffe_0">
											<gml:posList>35.66687106558504 139.74219663048027 58.895 35.66684919020247 139.74219789246908 58.895 35.6668714886929 139.74220783041653 58.895 35.66687106558504 139.74219663048027 58.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e95e7f07-1a40-4c6c-b13a-b7a27ddf1b5e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e95e7f07-1a40-4c6c-b13a-b7a27ddf1b5e_0">
											<gml:posList>35.666849622315574 139.74220908134626 56.038 35.6668714886929 139.74220783041653 58.895 35.666849622315574 139.74220908134626 58.895 35.666849622315574 139.74220908134626 56.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5ee24e11-529a-4b1e-aac8-6b4bc6492953">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5ee24e11-529a-4b1e-aac8-6b4bc6492953_0">
											<gml:posList>35.666849622315574 139.74220908134626 56.038 35.6668714886929 139.74220783041653 56.038 35.6668714886929 139.74220783041653 58.895 35.666849622315574 139.74220908134626 56.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c8ded6f0-1d4a-47a1-9147-e098692c71b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c8ded6f0-1d4a-47a1-9147-e098692c71b0_0">
											<gml:posList>35.66687106558504 139.74219663048027 56.038 35.6668714886929 139.74220783041653 58.895 35.6668714886929 139.74220783041653 56.038 35.66687106558504 139.74219663048027 56.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f8e220f-5c6a-47df-b737-497a247a14c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1f8e220f-5c6a-47df-b737-497a247a14c9_0">
											<gml:posList>35.66687106558504 139.74219663048027 56.038 35.66687106558504 139.74219663048027 58.895 35.6668714886929 139.74220783041653 58.895 35.66687106558504 139.74219663048027 56.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b5ad8a55-601f-447d-a261-787bf832febb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6668714886929 139.74220783041653 56.038 35.666849622315574 139.74220908134626 56.038 35.66684919020247 139.74219789246908 56.038 35.6668714886929 139.74220783041653 56.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25467421-7eb7-4ac7-9f25-165bb11e9f3b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66687106558504 139.74219663048027 56.038 35.6668714886929 139.74220783041653 56.038 35.66684919020247 139.74219789246908 56.038 35.66687106558504 139.74219663048027 56.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ff9bd52-ec00-480e-82b7-a1cf7360a20c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66670677254189 139.7421018347701 56.6 35.666706671265246 139.7420990292639 56.6 35.66670890870352 139.74210171083644 56.6 35.66670677254189 139.7421018347701 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5df76e47-6f00-4139-a932-d0176b73db5e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666706671265246 139.7420990292639 56.6 35.66670880743525 139.74209891637594 56.6 35.66670890870352 139.74210171083644 56.6 35.666706671265246 139.7420990292639 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75b2ff04-3d0d-4b4b-afef-8c0a61cfa1c8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666726358545674 139.74210071895692 56.038 35.66670890870352 139.74210171083644 56.038 35.66670880743525 139.74209891637594 56.038 35.666726358545674 139.74210071895692 56.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e261431e-9e68-4738-8423-c63cd25154b8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66672701651438 139.7421006740253 56.038 35.666726358545674 139.74210071895692 56.038 35.66672655662188 139.74208852421663 56.038 35.66672701651438 139.7421006740253 56.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a44bffcb-f60f-451b-8dd6-00792c0329b7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66670880743525 139.74209891637594 56.038 35.666706671265246 139.7420990292639 56.038 35.6667063126495 139.74208968496447 56.038 35.66670880743525 139.74209891637594 56.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3e8a9d5-8574-4594-aabc-baa52b3d454c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66672655662188 139.74208852421663 56.038 35.66670880743525 139.74209891637594 56.038 35.6667063126495 139.74208968496447 56.038 35.66672655662188 139.74208852421663 56.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b635d76-a00e-4e44-b2f7-1007de3ec25a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666726358545674 139.74210071895692 56.038 35.66670880743525 139.74209891637594 56.038 35.66672655662188 139.74208852421663 56.038 35.666726358545674 139.74210071895692 56.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_83998ecc-743c-4c60-96cf-7cc53f519ddd_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-72645baf-14d2-4c9e-a617-5654bbcd451f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66668413264386 139.74215288084906 24.8 35.666682238218584 139.74210324340189 24.8 35.66670677255026 139.74210184581582 24.8 35.66670864857229 139.74215098624018 24.8 35.66668413264386 139.74215288084906 24.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-317394ce-f07b-4986-9abf-46aae4bc17e0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66684985216397 139.74221503475687 24.8 35.6668514798404 139.7422576585473 24.8 35.666829234902586 139.74225893198462 24.8 35.666827607226615 139.742216308206 24.8 35.66684985216397 139.74221503475687 24.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4cc023f9-c31f-4fc0-b342-a228bfff44da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4cc023f9-c31f-4fc0-b342-a228bfff44da_0">
											<gml:posList>35.66670677255026 139.74210184581582 56.6 35.66670677255026 139.74210184581582 24.8 35.666682238218584 139.74210324340189 24.8 35.666682238218584 139.74210324340189 56.6 35.66670677255026 139.74210184581582 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d22ce87-3768-4c40-b7ca-b2cd5b136473">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d22ce87-3768-4c40-b7ca-b2cd5b136473_0">
											<gml:posList>35.66670864857229 139.74215098624018 56.6 35.66670864857229 139.74215098624018 24.8 35.66670677255026 139.74210184581582 24.8 35.66670677255026 139.74210184581582 56.6 35.66670864857229 139.74215098624018 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-30883065-990a-49d1-8a76-c649e7bfb45e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-30883065-990a-49d1-8a76-c649e7bfb45e_0">
											<gml:posList>35.66670864857229 139.74215098624018 56.6 35.66670677255026 139.74210184581582 56.6 35.666682238218584 139.74210324340189 56.6 35.66668413264386 139.74215288084906 56.6 35.66670864857229 139.74215098624018 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-91f87341-a3c1-4216-8d46-89d167bd9eca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-91f87341-a3c1-4216-8d46-89d167bd9eca_0">
											<gml:posList>35.666682238218584 139.74210324340189 56.6 35.666682238218584 139.74210324340189 24.8 35.66668413264386 139.74215288084906 24.8 35.66668413264386 139.74215288084906 56.6 35.666682238218584 139.74210324340189 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8463369-a536-495e-a9ba-4e5359119864">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8463369-a536-495e-a9ba-4e5359119864_0">
											<gml:posList>35.66668413264386 139.74215288084906 56.6 35.66668413264386 139.74215288084906 24.8 35.66670864857229 139.74215098624018 24.8 35.66670864857229 139.74215098624018 56.6 35.66668413264386 139.74215288084906 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d139e61e-aef7-4e5f-8ec7-559bacb84057">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d139e61e-aef7-4e5f-8ec7-559bacb84057_0">
											<gml:posList>35.66684985216397 139.74221503475687 56.6 35.66684985216397 139.74221503475687 24.8 35.666827607226615 139.742216308206 24.8 35.666827607226615 139.742216308206 56.6 35.66684985216397 139.74221503475687 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bec5c5cf-a6d9-46e0-871e-a9a509fdad9f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bec5c5cf-a6d9-46e0-871e-a9a509fdad9f_0">
											<gml:posList>35.6668514798404 139.7422576585473 56.6 35.6668514798404 139.7422576585473 24.8 35.66684985216397 139.74221503475687 24.8 35.66684985216397 139.74221503475687 56.6 35.6668514798404 139.7422576585473 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f09e8c7-722f-4570-8b24-f841f2e9927a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f09e8c7-722f-4570-8b24-f841f2e9927a_0">
											<gml:posList>35.666827607226615 139.742216308206 56.6 35.666829234902586 139.74225893198462 56.6 35.6668514798404 139.7422576585473 56.6 35.66684985216397 139.74221503475687 56.6 35.666827607226615 139.742216308206 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-010087a9-9e5f-4ca0-92b0-a222efac0e90">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-010087a9-9e5f-4ca0-92b0-a222efac0e90_0">
											<gml:posList>35.666827607226615 139.742216308206 56.6 35.666827607226615 139.742216308206 24.8 35.666829234902586 139.74225893198462 24.8 35.666829234902586 139.74225893198462 56.6 35.666827607226615 139.742216308206 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a9fc37b-d426-4105-b546-4e00a637c51a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1a9fc37b-d426-4105-b546-4e00a637c51a_0">
											<gml:posList>35.666829234902586 139.74225893198462 56.6 35.666829234902586 139.74225893198462 24.8 35.6668514798404 139.7422576585473 24.8 35.6668514798404 139.7422576585473 56.6 35.666829234902586 139.74225893198462 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-8626d597-c6d6-4449-9969-5315b79fecad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8626d597-c6d6-4449-9969-5315b79fecad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8626d597-c6d6-4449-9969-5315b79fecad">
											<gml:posList>35.66670677254189 139.7421018347701 24.76 35.66665452218282 139.7421048323845 24.76 35.66665439331274 139.74210129789228 24.76 35.66663349137127 139.74210250356734 24.76 35.666632580984206 139.74207871207196 24.76 35.66661408560804 139.74207978246503 24.76 35.666614002969396 139.74207778328002 24.76 35.666579535935384 139.74207975550763 24.76 35.66657782543117 139.7420349669955 24.76 35.666562971442545 139.7420358233832 24.76 35.66656045160828 139.7419698059036 24.76 35.66657435019143 139.74196901686673 24.76 35.666573145436935 139.74193744952834 24.76 35.66658601962487 139.7419170886075 24.76 35.666865110450566 139.74209339238612 24.76 35.666902840310534 139.7420912286662 24.76 35.66690387022484 139.7421181239703 24.76 35.66693827416154 139.7421161518227 24.76 35.666939396189996 139.74214566488547 24.76 35.666954863086914 139.7421447746796 24.76 35.66695679416878 139.74219522964322 24.76 35.66694324711201 139.74219600719948 24.76 35.66694359645502 139.742205020164 24.76 35.66693827858102 139.7422053244436 24.76 35.666939584380124 139.74223948757464 24.76 35.666929444370275 139.74224007347453 24.76 35.66692961921568 139.74224481191737 24.76 35.666912250496445 139.74224580367598 24.76 35.666913023071835 139.74226619331193 24.76 35.666909868400566 139.74226637362713 24.76 35.66691101783421 139.742296416848 24.76 35.666871052657676 139.74229870451282 24.76 35.66686958131183 139.74226015642495 24.76 35.66685160869755 139.7422611820027 24.76 35.66684985216397 139.74221503475687 24.76 35.66679500595806 139.74221817884762 24.76 35.666794362300344 139.742201401061 24.76 35.666770026269845 139.74220279839284 24.76 35.66676986993511 139.7421987005927 24.76 35.666759062934354 139.7421993203918 24.76 35.666758327088225 139.74217983650627 24.76 35.66673462199377 139.7421811999895 24.76 35.666734401282866 139.74217541226352 24.76 35.66672185470779 139.74217613345482 24.76 35.666720861471994 139.7421500445094 24.76 35.66670864857229 139.74215098624018 24.76 35.66670677254189 139.7421018347701 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ffb19a6c-5630-44e5-a57d-8078fadc2321">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ffb19a6c-5630-44e5-a57d-8078fadc2321">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ffb19a6c-5630-44e5-a57d-8078fadc2321">
											<gml:posList>35.666562971442545 139.7420358233832 56.6 35.66656515955099 139.7420328827267 56.6 35.66656337521858 139.7419858520238 56.6 35.66656096652521 139.74198318170014 56.6 35.666562971442545 139.7420358233832 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a7e0fbc6-8fdb-4747-a66d-69df8e56d75a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a7e0fbc6-8fdb-4747-a66d-69df8e56d75a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a7e0fbc6-8fdb-4747-a66d-69df8e56d75a">
											<gml:posList>35.66659037891034 139.74205524372266 51.4 35.66658958784476 139.74203429085924 51.4 35.66657782543117 139.7420349669955 51.4 35.66657862551036 139.7420559198456 51.4 35.66659037891034 139.74205524372266 51.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bc395ad2-e35a-4f6e-88e1-b0ff791cf593">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc395ad2-e35a-4f6e-88e1-b0ff791cf593">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc395ad2-e35a-4f6e-88e1-b0ff791cf593">
											<gml:posList>35.66660358557093 139.74203349067463 56.6 35.66660578269303 139.74203055000632 56.6 35.66656515955099 139.7420328827267 56.6 35.666562971442545 139.7420358233832 56.6 35.66660358557093 139.74203349067463 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1c543cf2-ed3f-4017-a7cf-7df0fff3e837">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c543cf2-ed3f-4017-a7cf-7df0fff3e837">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c543cf2-ed3f-4017-a7cf-7df0fff3e837">
											<gml:posList>35.66656096652521 139.74198318170014 56.6 35.66656337521858 139.7419858520238 56.6 35.666615427290104 139.74198287665274 56.6 35.666617597369765 139.7419799360134 56.6 35.66656096652521 139.74198318170014 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-893450a7-5a61-476c-bad5-860a80658c5d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-893450a7-5a61-476c-bad5-860a80658c5d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-893450a7-5a61-476c-bad5-860a80658c5d">
											<gml:posList>35.666573145436935 139.74193744952834 48.1 35.666614489641766 139.74193507175457 48.1 35.66658601962487 139.7419170886075 48.1 35.666573145436935 139.74193744952834 48.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f26e734f-26f4-4979-9b11-5a09c5593fa9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f26e734f-26f4-4979-9b11-5a09c5593fa9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f26e734f-26f4-4979-9b11-5a09c5593fa9">
											<gml:posList>35.666614002969396 139.74207778328002 48.4 35.6666130925356 139.74205393656203 48.4 35.66657862551036 139.7420559198456 48.4 35.666579535935384 139.74207975550763 48.4 35.666614002969396 139.74207778328002 48.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-052e5d76-e583-4123-95be-921cc0166556">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-052e5d76-e583-4123-95be-921cc0166556">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-052e5d76-e583-4123-95be-921cc0166556">
											<gml:posList>35.66659037891034 139.74205524372266 54.4 35.666604385650395 139.74205444353143 54.4 35.66660358557093 139.74203349067463 54.4 35.66658958784476 139.74203429085924 54.4 35.66659037891034 139.74205524372266 54.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3af6b848-cf54-4051-9dbd-c2dbf0c8f4e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3af6b848-cf54-4051-9dbd-c2dbf0c8f4e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3af6b848-cf54-4051-9dbd-c2dbf0c8f4e7">
											<gml:posList>35.66660358557093 139.74203349067463 56.6 35.666604385650395 139.74205444353143 56.6 35.666606573759275 139.74205150287392 56.6 35.66660578269303 139.74203055000632 56.6 35.66660358557093 139.74203349067463 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-764c07bb-8bbd-4d86-bb79-b558c0460149">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-764c07bb-8bbd-4d86-bb79-b558c0460149">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-764c07bb-8bbd-4d86-bb79-b558c0460149">
											<gml:posList>35.6666130925356 139.74205393656203 56.6 35.666615289658196 139.74205099589392 56.6 35.666606573759275 139.74205150287392 56.6 35.666604385650395 139.74205444353143 56.6 35.6666130925356 139.74205393656203 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bff4b848-be18-4471-bfe4-68e99101543e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bff4b848-be18-4471-bfe4-68e99101543e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bff4b848-be18-4471-bfe4-68e99101543e">
											<gml:posList>35.6666130925356 139.74205393656203 56.6 35.66661408560804 139.74207978246503 56.6 35.66661627371753 139.7420768418079 56.6 35.666615289658196 139.74205099589392 56.6 35.6666130925356 139.74205393656203 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7daf5680-6dc2-4ecb-8c58-27809853a095">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7daf5680-6dc2-4ecb-8c58-27809853a095">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7daf5680-6dc2-4ecb-8c58-27809853a095">
											<gml:posList>35.666618130715214 139.74199384199414 56.6 35.666617597369765 139.7419799360134 56.6 35.666615427290104 139.74198287665274 56.6 35.66661595162148 139.74199678264338 56.6 35.666618130715214 139.74199384199414 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a05b3033-cf88-447f-b9b7-920137513b35">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a05b3033-cf88-447f-b9b7-920137513b35">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a05b3033-cf88-447f-b9b7-920137513b35">
											<gml:posList>35.66668879868397 139.74200608855736 54.6 35.66668786057468 139.74198142446392 54.6 35.66665218607178 139.7419838841232 54.6 35.666651288002384 139.7419644777707 54.6 35.66661641537787 139.7419664836473 54.6 35.666615744090684 139.74194897691268 54.6 35.66657367881243 139.74195138863826 54.6 35.66657435019143 139.74196901686673 54.6 35.66656045160828 139.7419698059036 54.6 35.66656096652521 139.74198318170014 54.6 35.666617597369765 139.7419799360134 54.6 35.666618130715214 139.74199384199414 54.6 35.66665386862464 139.74199179096075 54.6 35.666654493890356 139.74200804958716 54.6 35.66668879868397 139.74200608855736 54.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7228f8b4-3362-41b8-af18-f5a680c2ac7c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7228f8b4-3362-41b8-af18-f5a680c2ac7c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7228f8b4-3362-41b8-af18-f5a680c2ac7c">
											<gml:posList>35.666651288002384 139.7419644777707 51.2 35.66665218607178 139.7419838841232 51.2 35.66668786057468 139.74198142446392 51.2 35.666614489641766 139.74193507175457 51.2 35.666573145436935 139.74193744952834 51.2 35.66657367881243 139.74195138863826 51.2 35.666615744090684 139.74194897691268 51.2 35.66661641537787 139.7419664836473 51.2 35.666651288002384 139.7419644777707 51.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9e24f01b-1119-49f4-a676-a959cc7ff5f5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e24f01b-1119-49f4-a676-a959cc7ff5f5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e24f01b-1119-49f4-a676-a959cc7ff5f5">
											<gml:posList>35.6666534829338 139.74207751743643 56.6 35.66665568005696 139.7420745767675 56.6 35.66661627371753 139.7420768418079 56.6 35.66661408560804 139.74207978246503 56.6 35.6666534829338 139.74207751743643 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4d08e447-84a1-4ca8-a913-b0ec08029c81">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d08e447-84a1-4ca8-a913-b0ec08029c81">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d08e447-84a1-4ca8-a913-b0ec08029c81">
											<gml:posList>35.666618130715214 139.74199384199414 56.6 35.66661595162148 139.74199678264338 56.6 35.66665169854469 139.7419947316011 56.6 35.66665386862464 139.74199179096075 56.6 35.666618130715214 139.74199384199414 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dd0c831b-6f14-4c2d-8fd3-19e17565405b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd0c831b-6f14-4c2d-8fd3-19e17565405b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd0c831b-6f14-4c2d-8fd3-19e17565405b">
											<gml:posList>35.66663349137127 139.74210250356734 47.7 35.66665439331274 139.74210129789228 47.7 35.6666534829338 139.74207751743643 47.7 35.666632580984206 139.74207871207196 47.7 35.66663349137127 139.74210250356734 47.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0ce7258b-54b9-4efb-876f-e20fd2ccd878">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ce7258b-54b9-4efb-876f-e20fd2ccd878">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ce7258b-54b9-4efb-876f-e20fd2ccd878">
											<gml:posList>35.666654493890356 139.74200804958716 56.6 35.66665386862464 139.74199179096075 56.6 35.66665169854469 139.7419947316011 56.6 35.66665231479628 139.74201099023736 56.6 35.666654493890356 139.74200804958716 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2c6187df-2200-4e1a-8891-365daa1bf1fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c6187df-2200-4e1a-8891-365daa1bf1fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c6187df-2200-4e1a-8891-365daa1bf1fc">
											<gml:posList>35.6666534829338 139.74207751743643 56.6 35.66665452218282 139.7421048323845 56.6 35.66665671029291 139.74210189172655 56.6 35.66665568005696 139.7420745767675 56.6 35.6666534829338 139.74207751743643 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-04e1bd39-9b4b-45fd-8f25-4ee5bb32b6e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04e1bd39-9b4b-45fd-8f25-4ee5bb32b6e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04e1bd39-9b4b-45fd-8f25-4ee5bb32b6e8">
											<gml:posList>35.666654493890356 139.74200804958716 56.6 35.66665231479628 139.74201099023736 56.6 35.66668662860369 139.74200902919858 56.6 35.66668879868397 139.74200608855736 56.6 35.666654493890356 139.74200804958716 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7c77cc92-82d3-417d-a685-42b5bad12fa2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c77cc92-82d3-417d-a685-42b5bad12fa2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c77cc92-82d3-417d-a685-42b5bad12fa2">
											<gml:posList>35.666706671265246 139.7420990292639 56.6 35.66665671029291 139.74210189172655 56.6 35.66665452218282 139.7421048323845 56.6 35.66670677254189 139.7421018347701 56.6 35.66670890870352 139.74210171083644 56.6 35.66670880743525 139.74209891637594 56.6 35.666706671265246 139.7420990292639 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e22a25df-6b09-4ded-9e1a-5cc2a1b32b0a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e22a25df-6b09-4ded-9e1a-5cc2a1b32b0a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e22a25df-6b09-4ded-9e1a-5cc2a1b32b0a">
											<gml:posList>35.66668970904352 139.74202982483985 56.6 35.66668879868397 139.74200608855736 56.6 35.66668662860369 139.74200902919858 56.6 35.66668752994893 139.74203276549073 56.6 35.66668970904352 139.74202982483985 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bee5aede-0fcf-4b2c-b018-f02ea4637edb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bee5aede-0fcf-4b2c-b018-f02ea4637edb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bee5aede-0fcf-4b2c-b018-f02ea4637edb">
											<gml:posList>35.66672460014167 139.742004633926 51.2 35.66668786057468 139.74198142446392 51.2 35.666688817163795 139.74200668500686 51.2 35.66672460014167 139.742004633926 51.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c92e5170-52f7-4d29-81fc-f3d7bf916693">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c92e5170-52f7-4d29-81fc-f3d7bf916693">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c92e5170-52f7-4d29-81fc-f3d7bf916693">
											<gml:posList>35.66668970904352 139.74202982483985 56.6 35.66668752994893 139.74203276549073 56.6 35.666723321940985 139.74203071441127 56.6 35.66672549202179 139.7420277737693 56.6 35.66668970904352 139.74202982483985 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a06bd503-d797-4b9f-bb8f-1dcc9cc8ad09">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a06bd503-d797-4b9f-bb8f-1dcc9cc8ad09">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a06bd503-d797-4b9f-bb8f-1dcc9cc8ad09">
											<gml:posList>35.666688817163795 139.74200668500686 54.6 35.66668970904352 139.74202982483985 54.6 35.66672549202179 139.7420277737693 54.6 35.66672460014167 139.742004633926 54.6 35.666688817163795 139.74200668500686 54.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-efb2ae00-bdf7-4fb7-aaa2-8e8dab74fba3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-efb2ae00-bdf7-4fb7-aaa2-8e8dab74fba3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-efb2ae00-bdf7-4fb7-aaa2-8e8dab74fba3">
											<gml:posList>35.66673403791606 139.74210027943533 61.762 35.66670677254189 139.7421018347701 61.762 35.66670864857229 139.74215098624018 61.762 35.666720861471994 139.7421500445094 61.762 35.666736220188035 139.74214913233843 61.762 35.66673403791606 139.74210027943533 61.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a430a499-7830-4540-973c-8f2dbeb8a7f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a430a499-7830-4540-973c-8f2dbeb8a7f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a430a499-7830-4540-973c-8f2dbeb8a7f3">
											<gml:posList>35.666726466904954 139.7420533988138 56.6 35.66672549202179 139.7420277737693 56.6 35.666723321940985 139.74203071441127 56.6 35.66672428780981 139.7420563394654 56.6 35.666726466904954 139.7420533988138 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-725f2a49-e3fc-4979-b7e8-827b00daa330">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-725f2a49-e3fc-4979-b7e8-827b00daa330">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-725f2a49-e3fc-4979-b7e8-827b00daa330">
											<gml:posList>35.66672185470779 139.74217613345482 54.1 35.666734401282866 139.74217541226352 54.1 35.66673340803854 139.7421493122683 54.1 35.666720861471994 139.7421500445094 54.1 35.66672185470779 139.74217613345482 54.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6403e9e1-4eae-4a54-ae71-5f3a9535efa1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6403e9e1-4eae-4a54-ae71-5f3a9535efa1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6403e9e1-4eae-4a54-ae71-5f3a9535efa1">
											<gml:posList>35.66673581671144 139.74215196051117 56.6 35.66673569741687 139.74214916607016 56.6 35.66673340803854 139.7421493122683 56.6 35.66673462199377 139.7421811999895 56.6 35.66673681009733 139.74217824828494 56.6 35.66673581671144 139.74215196051117 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0a69b2da-d701-4bd8-a972-6c856daeb048">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a69b2da-d701-4bd8-a972-6c856daeb048">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a69b2da-d701-4bd8-a972-6c856daeb048">
											<gml:posList>35.66676042888189 139.74202727006684 51.2 35.66672460014167 139.742004633926 51.2 35.66672554723482 139.7420292648835 51.2 35.66676042888189 139.74202727006684 51.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-17fba13b-f059-44d0-9704-0da930a3502f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17fba13b-f059-44d0-9704-0da930a3502f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17fba13b-f059-44d0-9704-0da930a3502f">
											<gml:posList>35.666726466904954 139.7420533988138 56.6 35.66672428780981 139.7420563394654 56.6 35.66675917847108 139.74205434465026 56.6 35.66676134855244 139.74205140400758 56.6 35.666726466904954 139.7420533988138 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7aded37b-bed7-4f89-be2a-5f8e1b36f23d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7aded37b-bed7-4f89-be2a-5f8e1b36f23d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7aded37b-bed7-4f89-be2a-5f8e1b36f23d">
											<gml:posList>35.66672554723482 139.7420292648835 54.6 35.666726466904954 139.7420533988138 54.6 35.66676134855244 139.74205140400758 54.6 35.66676042888189 139.74202727006684 54.6 35.66672554723482 139.7420292648835 54.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a7be4a50-4320-4a73-8c1f-5cdddbe76c9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a7be4a50-4320-4a73-8c1f-5cdddbe76c9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a7be4a50-4320-4a73-8c1f-5cdddbe76c9a">
											<gml:posList>35.66684745248115 139.74221235336083 56.038 35.66684974187623 139.74221222925578 56.038 35.666849622315574 139.74220908134626 56.038 35.66687933931598 139.742207379664 56.038 35.66688132569871 139.74225948033964 56.038 35.666871870698614 139.74226002127548 56.038 35.66687198097688 139.74226281573164 56.038 35.666872091338625 139.7422657206455 56.038 35.66691062339017 139.74226351191226 56.038 35.66690945544454 139.7422328391035 56.038 35.66692683318575 139.74223185837764 56.038 35.66692573887999 139.74220321790366 56.038 35.66694119677201 139.74220233876508 56.038 35.666939145938514 139.74214848184536 56.038 35.66686843625076 139.7421525387315 56.038 35.6668678752132 139.7421377490757 56.038 35.66683363351448 139.74213970998198 56.038 35.66683208836766 139.74209899702794 56.038 35.66679590880147 139.7421010706123 56.038 35.66679496151371 139.7420761634884 56.038 35.66676007987437 139.74207816933045 56.038 35.66675917847108 139.74205434465026 56.038 35.66672428780981 139.7420563394654 56.038 35.666723321940985 139.74203071441127 56.038 35.66668752994893 139.74203276549073 56.038 35.66668662860369 139.74200902919858 56.038 35.66665231479628 139.74201099023736 56.038 35.66665169854469 139.7419947316011 56.038 35.66661595162148 139.74199678264338 56.038 35.666615427290104 139.74198287665274 56.038 35.66656337521858 139.7419858520238 56.038 35.66656515955099 139.7420328827267 56.038 35.66660578269303 139.74203055000632 56.038 35.666606573759275 139.74205150287392 56.038 35.666615289658196 139.74205099589392 56.038 35.66661627371753 139.7420768418079 56.038 35.66665568005696 139.7420745767675 56.038 35.66665671029291 139.74210189172655 56.038 35.666706671265246 139.7420990292639 56.038 35.66670880743525 139.74209891637594 56.038 35.66670890870352 139.74210171083644 56.038 35.66673403791606 139.74210027943533 56.038 35.666736220188035 139.74214913233843 56.038 35.66673569741687 139.74214916607016 56.038 35.66673581671144 139.74215196051117 56.038 35.66673681009733 139.74217824828494 56.038 35.666771313178664 139.74217626500888 56.038 35.66677220536021 139.7421998466978 56.038 35.66679655040438 139.74219844935476 56.038 35.66679718504878 139.7422152271521 56.038 35.66684745248115 139.74221235336083 56.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3a978c8c-af5b-49a4-84d0-79552cacf6e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a978c8c-af5b-49a4-84d0-79552cacf6e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a978c8c-af5b-49a4-84d0-79552cacf6e2">
											<gml:posList>35.66676912507516 139.74217921671482 56.6 35.666771313178664 139.74217626500888 56.6 35.66673681009733 139.74217824828494 56.6 35.66673462199377 139.7421811999895 56.6 35.66676912507516 139.74217921671482 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d238c705-9a96-42db-889f-fdf493546a71">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d238c705-9a96-42db-889f-fdf493546a71">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d238c705-9a96-42db-889f-fdf493546a71">
											<gml:posList>35.666762258970046 139.74207522867815 56.6 35.66676134855244 139.74205140400758 56.6 35.66675917847108 139.74205434465026 56.6 35.66676007987437 139.74207816933045 56.6 35.666762258970046 139.74207522867815 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c03b1815-6398-4f78-a8e1-0ca99cbef3c0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c03b1815-6398-4f78-a8e1-0ca99cbef3c0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c03b1815-6398-4f78-a8e1-0ca99cbef3c0">
											<gml:posList>35.66676912507516 139.74217921671482 54.2 35.666758327088225 139.74217983650627 54.2 35.666759062934354 139.7421993203918 54.2 35.66676986993511 139.7421987005927 54.2 35.66676912507516 139.74217921671482 54.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ae83533a-9d1d-4e31-9064-a1fc21a9b301">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ae83533a-9d1d-4e31-9064-a1fc21a9b301">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ae83533a-9d1d-4e31-9064-a1fc21a9b301">
											<gml:posList>35.66676912507516 139.74217921671482 56.6 35.666770026269845 139.74220279839284 56.6 35.66677220536021 139.7421998466978 56.6 35.666771313178664 139.74217626500888 56.6 35.66676912507516 139.74217921671482 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-79800983-4fdf-4d80-b3a3-bc8e5901827c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79800983-4fdf-4d80-b3a3-bc8e5901827c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79800983-4fdf-4d80-b3a3-bc8e5901827c">
											<gml:posList>35.66676134855244 139.74205140400758 51.2 35.66679625760929 139.74204989518213 51.2 35.66676042888189 139.74202727006684 51.2 35.66676134855244 139.74205140400758 51.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3a813e11-90e2-498a-a840-f9768e41c9af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a813e11-90e2-498a-a840-f9768e41c9af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a813e11-90e2-498a-a840-f9768e41c9af">
											<gml:posList>35.666762258970046 139.74207522867815 56.6 35.66676007987437 139.74207816933045 56.6 35.66679496151371 139.7420761634884 56.6 35.66679714060932 139.74207322283476 56.6 35.666762258970046 139.74207522867815 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9508c875-b8f7-4e44-ad20-4dfa5c42d00a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9508c875-b8f7-4e44-ad20-4dfa5c42d00a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9508c875-b8f7-4e44-ad20-4dfa5c42d00a">
											<gml:posList>35.66676134855244 139.74205140400758 54.6 35.666762258970046 139.74207522867815 54.6 35.66679714060932 139.74207322283476 54.6 35.66679625760929 139.74204989518213 54.6 35.66676134855244 139.74205140400758 54.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7cbeb549-a5ba-431d-9629-eb78a7a452ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7cbeb549-a5ba-431d-9629-eb78a7a452ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7cbeb549-a5ba-431d-9629-eb78a7a452ef">
											<gml:posList>35.666794362300344 139.742201401061 56.6 35.66679655040438 139.74219844935476 56.6 35.66677220536021 139.7421998466978 56.6 35.666770026269845 139.74220279839284 56.6 35.666794362300344 139.742201401061 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e9c84c98-03da-4c2a-8dae-566ed6990366">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e9c84c98-03da-4c2a-8dae-566ed6990366">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e9c84c98-03da-4c2a-8dae-566ed6990366">
											<gml:posList>35.666794362300344 139.742201401061 56.6 35.66679500595806 139.74221817884762 56.6 35.66679718504878 139.7422152271521 56.6 35.66679655040438 139.74219844935476 56.6 35.666794362300344 139.742201401061 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-af287ef1-5a70-47b9-94dd-1b02e3617ce5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af287ef1-5a70-47b9-94dd-1b02e3617ce5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af287ef1-5a70-47b9-94dd-1b02e3617ce5">
											<gml:posList>35.66679809691141 139.74209812994906 56.6 35.66679714060932 139.74207322283476 56.6 35.66679496151371 139.7420761634884 56.6 35.66679590880147 139.7421010706123 56.6 35.66679809691141 139.74209812994906 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-45c0bb7d-65e1-40e8-9989-c5416cc42db9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45c0bb7d-65e1-40e8-9989-c5416cc42db9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45c0bb7d-65e1-40e8-9989-c5416cc42db9">
											<gml:posList>35.66683339395909 139.74207335830803 51.2 35.66679625760929 139.74204989518213 51.2 35.66679722340708 139.74207543189374 51.2 35.66683339395909 139.74207335830803 51.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f8b99107-9210-4509-a19b-fa1c7b7b81b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f8b99107-9210-4509-a19b-fa1c7b7b81b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f8b99107-9210-4509-a19b-fa1c7b7b81b2">
											<gml:posList>35.66679809691141 139.74209812994906 56.6 35.66679590880147 139.7421010706123 56.6 35.66683208836766 139.74209899702794 56.6 35.66683426746382 139.74209605637358 56.6 35.66679809691141 139.74209812994906 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-739935b3-43b0-4be4-a444-b1d14e777f22">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-739935b3-43b0-4be4-a444-b1d14e777f22">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-739935b3-43b0-4be4-a444-b1d14e777f22">
											<gml:posList>35.66683426746382 139.74209605637358 54.6 35.66683339395909 139.74207335830803 54.6 35.66679722340708 139.74207543189374 54.6 35.66679809691141 139.74209812994906 54.6 35.66683426746382 139.74209605637358 54.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fb8690ba-a807-4efb-99ca-4fff1a40d64b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb8690ba-a807-4efb-99ca-4fff1a40d64b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb8690ba-a807-4efb-99ca-4fff1a40d64b">
											<gml:posList>35.66684745248115 139.74221235336083 56.6 35.66679718504878 139.7422152271521 56.6 35.66679500595806 139.74221817884762 56.6 35.66684985216397 139.74221503475687 56.6 35.66684974187623 139.74221222925578 56.6 35.66684745248115 139.74221235336083 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-71fa9df9-c07b-4f34-b404-12f25f4e4104">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-71fa9df9-c07b-4f34-b404-12f25f4e4104">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-71fa9df9-c07b-4f34-b404-12f25f4e4104">
											<gml:posList>35.66683582163372 139.74213678036415 56.6 35.66683426746382 139.74209605637358 56.6 35.66683208836766 139.74209899702794 56.6 35.66683363351448 139.74213970998198 56.6 35.66683582163372 139.74213678036415 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0da56f73-335a-4c95-90a7-c798af45f317">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0da56f73-335a-4c95-90a7-c798af45f317">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0da56f73-335a-4c95-90a7-c798af45f317">
											<gml:posList>35.666834230731006 139.7420951617079 45.3 35.666865110450566 139.74209339238612 45.3 35.66683339395909 139.74207335830803 45.3 35.666834230731006 139.7420951617079 45.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f93ba772-e7d9-42f5-9efe-cdb518a031ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f93ba772-e7d9-42f5-9efe-cdb518a031ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f93ba772-e7d9-42f5-9efe-cdb518a031ae">
											<gml:posList>35.66683582163372 139.74213678036415 56.6 35.66683363351448 139.74213970998198 56.6 35.6668678752132 139.7421377490757 56.6 35.66687005431864 139.7421348194668 56.6 35.66683582163372 139.74213678036415 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3be027c7-8704-4008-95b9-700acba64c0c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3be027c7-8704-4008-95b9-700acba64c0c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3be027c7-8704-4008-95b9-700acba64c0c">
											<gml:posList>35.66686893229592 139.74210531747548 51.1 35.66683469059776 139.74210727839565 51.1 35.66683522390344 139.74212115127762 51.1 35.66686945658811 139.74211919037361 51.1 35.66686893229592 139.74210531747548 51.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9e7c3b51-5976-41e5-aa73-345a603e3151">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e7c3b51-5976-41e5-aa73-345a603e3151">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e7c3b51-5976-41e5-aa73-345a603e3151">
											<gml:posList>35.66686945658811 139.74211919037361 54.6 35.66683522390344 139.74212115127762 54.6 35.66683582163372 139.74213678036415 54.6 35.66687005431864 139.7421348194668 54.6 35.66686945658811 139.74211919037361 54.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-450ab019-45f4-46db-8e32-3d658d6c6cb0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-450ab019-45f4-46db-8e32-3d658d6c6cb0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-450ab019-45f4-46db-8e32-3d658d6c6cb0">
											<gml:posList>35.66686893229592 139.74210531747548 48.7 35.66686945658811 139.74211919037361 48.7 35.66688933140735 139.74211857129387 48.7 35.66688877949693 139.7420920399614 48.7 35.666834230731006 139.7420951617079 48.7 35.66683469059776 139.74210727839565 48.7 35.66686893229592 139.74210531747548 48.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0d81932b-1fb9-45ff-9ac2-3daf0406ea87">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d81932b-1fb9-45ff-9ac2-3daf0406ea87">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d81932b-1fb9-45ff-9ac2-3daf0406ea87">
											<gml:posList>35.66687933931598 139.742207379664 61.762 35.666849622315574 139.74220908134626 61.762 35.66685160869755 139.7422611820027 61.762 35.66688132569871 139.74225948033964 61.762 35.66687933931598 139.742207379664 61.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-54cafbdc-ed75-46b0-a6d9-fac7043411c0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-54cafbdc-ed75-46b0-a6d9-fac7043411c0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-54cafbdc-ed75-46b0-a6d9-fac7043411c0">
											<gml:posList>35.6668706243703 139.74214960911272 56.6 35.66687005431864 139.7421348194668 56.6 35.6668678752132 139.7421377490757 56.6 35.66686843625076 139.7421525387315 56.6 35.6668706243703 139.74214960911272 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1333d9e3-bcfc-4f44-962d-d33d559f8846">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1333d9e3-bcfc-4f44-962d-d33d559f8846">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1333d9e3-bcfc-4f44-962d-d33d559f8846">
											<gml:posList>35.666871870698614 139.74226002127548 56.6 35.66686958131183 139.74226015642495 56.6 35.66687198097688 139.74226281573164 56.6 35.666871870698614 139.74226002127548 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-44dc822b-6ef8-497c-92c7-10efcc9a02d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44dc822b-6ef8-497c-92c7-10efcc9a02d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44dc822b-6ef8-497c-92c7-10efcc9a02d1">
											<gml:posList>35.666869912246696 139.74226867234245 56.6 35.666872091338625 139.7422657206455 56.6 35.66687198097688 139.74226281573164 56.6 35.66686958131183 139.74226015642495 56.6 35.666869912246696 139.74226867234245 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8d429143-1304-4d19-b9d9-5a6b5b74e9ab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d429143-1304-4d19-b9d9-5a6b5b74e9ab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d429143-1304-4d19-b9d9-5a6b5b74e9ab">
											<gml:posList>35.66690296203547 139.74213292634937 54.6 35.66687005431864 139.7421348194668 54.6 35.6668706243703 139.74214960911272 54.6 35.66690353209572 139.74214772704713 54.6 35.66690296203547 139.74213292634937 54.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9d1de19c-ceab-4c1d-b857-a8bf3c2793dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d1de19c-ceab-4c1d-b857-a8bf3c2793dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d1de19c-ceab-4c1d-b857-a8bf3c2793dd">
											<gml:posList>35.666871052657676 139.74229870451282 47.75 35.66691101783421 139.742296416848 47.75 35.666909868400566 139.74226637362713 47.75 35.666869912246696 139.74226867234245 47.75 35.666871052657676 139.74229870451282 47.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fb4c0cd7-f0c0-4cb0-b0b2-4ff75f89a43f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb4c0cd7-f0c0-4cb0-b0b2-4ff75f89a43f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb4c0cd7-f0c0-4cb0-b0b2-4ff75f89a43f">
											<gml:posList>35.666913023071835 139.74226619331193 56.6 35.66691062339017 139.74226351191226 56.6 35.666872091338625 139.7422657206455 56.6 35.666869912246696 139.74226867234245 56.6 35.666913023071835 139.74226619331193 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-67abb687-7400-4997-a2ec-482e60394bce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67abb687-7400-4997-a2ec-482e60394bce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67abb687-7400-4997-a2ec-482e60394bce">
											<gml:posList>35.66688933140735 139.74211857129387 45.3 35.66690387022484 139.7421181239703 45.3 35.666902840310534 139.7420912286662 45.3 35.66688877949693 139.7420920399614 45.3 35.66688933140735 139.74211857129387 45.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3e651ab1-2b6e-4ee4-b0d6-b263cd3a36ed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e651ab1-2b6e-4ee4-b0d6-b263cd3a36ed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e651ab1-2b6e-4ee4-b0d6-b263cd3a36ed">
											<gml:posList>35.666926092495814 139.74214643112742 51.1 35.66692497045918 139.74211690702376 51.1 35.66690387022484 139.7421181239703 51.1 35.66686945658811 139.74211919037361 51.1 35.66687005431864 139.7421348194668 51.1 35.66690296203547 139.74213292634937 51.1 35.66690353209572 139.74214772704713 51.1 35.666926092495814 139.74214643112742 51.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6db14ed1-552e-4fcd-bbb8-648d7e896412">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6db14ed1-552e-4fcd-bbb8-648d7e896412">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6db14ed1-552e-4fcd-bbb8-648d7e896412">
											<gml:posList>35.6668706243703 139.74214960911272 56.6 35.66686843625076 139.7421525387315 56.6 35.666939145938514 139.74214848184536 56.6 35.66694132504419 139.74214555223415 56.6 35.6668706243703 139.74214960911272 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0a0ec481-3338-4bb4-b24b-4ee8caaa9db6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a0ec481-3338-4bb4-b24b-4ee8caaa9db6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a0ec481-3338-4bb4-b24b-4ee8caaa9db6">
											<gml:posList>35.66691185513524 139.742235531548 56.6 35.66690945544454 139.7422328391035 56.6 35.66691062339017 139.74226351191226 56.6 35.666913023071835 139.74226619331193 56.6 35.66691185513524 139.742235531548 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b671fbbc-c6c5-4549-a4f3-c5020ded58df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b671fbbc-c6c5-4549-a4f3-c5020ded58df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b671fbbc-c6c5-4549-a4f3-c5020ded58df">
											<gml:posList>35.66691185513524 139.742235531548 56.6 35.66692923286811 139.74223453977692 56.6 35.66692683318575 139.74223185837764 56.6 35.66690945544454 139.7422328391035 56.6 35.66691185513524 139.742235531548 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bbfae854-a9d1-4cb3-9c49-0aab29235b03">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bbfae854-a9d1-4cb3-9c49-0aab29235b03">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bbfae854-a9d1-4cb3-9c49-0aab29235b03">
											<gml:posList>35.66692961921568 139.74224481191737 54.4 35.66692923286811 139.74223453977692 54.4 35.66691185513524 139.742235531548 54.4 35.666912250496445 139.74224580367598 54.4 35.66692961921568 139.74224481191737 54.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-260bbbcf-efca-4095-a444-f10d575244fa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-260bbbcf-efca-4095-a444-f10d575244fa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-260bbbcf-efca-4095-a444-f10d575244fa">
											<gml:posList>35.66692813857134 139.74220591034782 56.6 35.66692573887999 139.74220321790366 56.6 35.66692683318575 139.74223185837764 56.6 35.66692923286811 139.74223453977692 56.6 35.66692813857134 139.74220591034782 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a539ab8d-8ea5-48b9-bc3f-c895c8298dd4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a539ab8d-8ea5-48b9-bc3f-c895c8298dd4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a539ab8d-8ea5-48b9-bc3f-c895c8298dd4">
											<gml:posList>35.666926092495814 139.74214643112742 48.4 35.666939396189996 139.74214566488547 48.4 35.66693827416154 139.7421161518227 48.4 35.66692497045918 139.74211690702376 48.4 35.666926092495814 139.74214643112742 48.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dd5f5f58-73de-4251-a526-87040aa09a38">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd5f5f58-73de-4251-a526-87040aa09a38">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd5f5f58-73de-4251-a526-87040aa09a38">
											<gml:posList>35.66692813857134 139.74220591034782 48.5 35.666929444370275 139.74224007347453 48.5 35.666939584380124 139.74223948757464 48.5 35.66693827858102 139.7422053244436 48.5 35.66692813857134 139.74220591034782 48.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ac5bbd7f-af45-4ce4-ba1d-e1f6a3f1508e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ac5bbd7f-af45-4ce4-ba1d-e1f6a3f1508e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ac5bbd7f-af45-4ce4-ba1d-e1f6a3f1508e">
											<gml:posList>35.66692813857134 139.74220591034782 56.6 35.66694359645502 139.742205020164 56.6 35.66694119677201 139.74220233876508 56.6 35.66692573887999 139.74220321790366 56.6 35.66692813857134 139.74220591034782 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3ecbadbe-b40b-47b7-9554-fecb14b70128">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ecbadbe-b40b-47b7-9554-fecb14b70128">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ecbadbe-b40b-47b7-9554-fecb14b70128">
											<gml:posList>35.66694132504419 139.74214555223415 56.6 35.666939145938514 139.74214848184536 56.6 35.66694119677201 139.74220233876508 56.6 35.66694359645502 139.742205020164 56.6 35.66694132504419 139.74214555223415 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-32d055d7-f9d6-4742-b1f2-239368d678ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-32d055d7-f9d6-4742-b1f2-239368d678ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-32d055d7-f9d6-4742-b1f2-239368d678ff">
											<gml:posList>35.66694324711201 139.74219600719948 44.9 35.66695679416878 139.74219522964322 44.9 35.666954863086914 139.7421447746796 44.9 35.66694132504419 139.74214555223415 44.9 35.66694324711201 139.74219600719948 44.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4ca13ee5-d0c2-416e-a76c-d24815b37704">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ca13ee5-d0c2-416e-a76c-d24815b37704">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ca13ee5-d0c2-416e-a76c-d24815b37704">
											<gml:posList>35.66658601962487 139.7419170886075 24.76 35.666573145436935 139.74193744952834 24.76 35.666573145436935 139.74193744952834 48.1 35.66658601962487 139.7419170886075 48.1 35.66658601962487 139.7419170886075 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e09a987f-3f87-4ebd-8f3f-58d8108911c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e09a987f-3f87-4ebd-8f3f-58d8108911c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e09a987f-3f87-4ebd-8f3f-58d8108911c1">
											<gml:posList>35.666573145436935 139.74193744952834 48.1 35.666573145436935 139.74193744952834 51.2 35.666614489641766 139.74193507175457 51.2 35.666614489641766 139.74193507175457 48.1 35.666573145436935 139.74193744952834 48.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bdfb8d21-62ad-420a-a033-65ca08f4d3cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bdfb8d21-62ad-420a-a033-65ca08f4d3cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bdfb8d21-62ad-420a-a033-65ca08f4d3cd">
											<gml:posList>35.66657367881243 139.74195138863826 54.6 35.666615744090684 139.74194897691268 54.6 35.666615744090684 139.74194897691268 51.2 35.66657367881243 139.74195138863826 51.2 35.66657367881243 139.74195138863826 54.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d1dbc4b8-8c8c-46cd-86ba-dfa582f0c04d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1dbc4b8-8c8c-46cd-86ba-dfa582f0c04d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1dbc4b8-8c8c-46cd-86ba-dfa582f0c04d">
											<gml:posList>35.66657367881243 139.74195138863826 51.2 35.666573145436935 139.74193744952834 51.2 35.666573145436935 139.74193744952834 48.1 35.666573145436935 139.74193744952834 24.76 35.66657435019143 139.74196901686673 24.76 35.66657435019143 139.74196901686673 54.6 35.66657367881243 139.74195138863826 54.6 35.66657367881243 139.74195138863826 51.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eeaa1708-4026-43e7-8325-155f206a4c37">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eeaa1708-4026-43e7-8325-155f206a4c37">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eeaa1708-4026-43e7-8325-155f206a4c37">
											<gml:posList>35.666615744090684 139.74194897691268 54.6 35.66661641537787 139.7419664836473 54.6 35.66661641537787 139.7419664836473 51.2 35.666615744090684 139.74194897691268 51.2 35.666615744090684 139.74194897691268 54.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dec6634d-f1c2-45a3-8aa0-66de2c9b9087">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dec6634d-f1c2-45a3-8aa0-66de2c9b9087">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dec6634d-f1c2-45a3-8aa0-66de2c9b9087">
											<gml:posList>35.66661641537787 139.7419664836473 54.6 35.666651288002384 139.7419644777707 54.6 35.666651288002384 139.7419644777707 51.2 35.66661641537787 139.7419664836473 51.2 35.66661641537787 139.7419664836473 54.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c835db36-7df2-41da-b299-2626f17cb162">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c835db36-7df2-41da-b299-2626f17cb162">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c835db36-7df2-41da-b299-2626f17cb162">
											<gml:posList>35.66657435019143 139.74196901686673 24.76 35.66656045160828 139.7419698059036 24.76 35.66656045160828 139.7419698059036 54.6 35.66657435019143 139.74196901686673 54.6 35.66657435019143 139.74196901686673 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2f260c17-ff50-4e4b-a7d2-f13fa68ce480">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f260c17-ff50-4e4b-a7d2-f13fa68ce480">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f260c17-ff50-4e4b-a7d2-f13fa68ce480">
											<gml:posList>35.666651288002384 139.7419644777707 54.6 35.66665218607178 139.7419838841232 54.6 35.66665218607178 139.7419838841232 51.2 35.666651288002384 139.7419644777707 51.2 35.666651288002384 139.7419644777707 54.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-85497710-e707-4bb4-8908-7e36215616f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85497710-e707-4bb4-8908-7e36215616f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85497710-e707-4bb4-8908-7e36215616f8">
											<gml:posList>35.66656096652521 139.74198318170014 54.6 35.66656096652521 139.74198318170014 56.6 35.666617597369765 139.7419799360134 56.6 35.666617597369765 139.7419799360134 54.6 35.66656096652521 139.74198318170014 54.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6e2bbfed-28d4-4a49-b8f7-5aa5bcb17e42">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e2bbfed-28d4-4a49-b8f7-5aa5bcb17e42">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e2bbfed-28d4-4a49-b8f7-5aa5bcb17e42">
											<gml:posList>35.66665218607178 139.7419838841232 54.6 35.66668786057468 139.74198142446392 54.6 35.66668786057468 139.74198142446392 51.2 35.66665218607178 139.7419838841232 51.2 35.66665218607178 139.7419838841232 54.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-92417f4f-6915-4965-8746-fa91200e540d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-92417f4f-6915-4965-8746-fa91200e540d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-92417f4f-6915-4965-8746-fa91200e540d">
											<gml:posList>35.66656337521858 139.7419858520238 56.6 35.66656337521858 139.7419858520238 56.038 35.666615427290104 139.74198287665274 56.038 35.666615427290104 139.74198287665274 56.6 35.66656337521858 139.7419858520238 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5f3abf65-78ad-42e0-9793-1a8a166ce33b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f3abf65-78ad-42e0-9793-1a8a166ce33b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f3abf65-78ad-42e0-9793-1a8a166ce33b">
											<gml:posList>35.666617597369765 139.7419799360134 54.6 35.666617597369765 139.7419799360134 56.6 35.666618130715214 139.74199384199414 56.6 35.666618130715214 139.74199384199414 54.6 35.666617597369765 139.7419799360134 54.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5f60bf31-db1f-4e98-a7cf-8e338f053eb2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f60bf31-db1f-4e98-a7cf-8e338f053eb2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f60bf31-db1f-4e98-a7cf-8e338f053eb2">
											<gml:posList>35.666615427290104 139.74198287665274 56.6 35.666615427290104 139.74198287665274 56.038 35.66661595162148 139.74199678264338 56.038 35.66661595162148 139.74199678264338 56.6 35.666615427290104 139.74198287665274 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c12f868e-808b-416b-a622-e18b980f0926">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c12f868e-808b-416b-a622-e18b980f0926">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c12f868e-808b-416b-a622-e18b980f0926">
											<gml:posList>35.666618130715214 139.74199384199414 54.6 35.666618130715214 139.74199384199414 56.6 35.66665386862464 139.74199179096075 56.6 35.66665386862464 139.74199179096075 54.6 35.666618130715214 139.74199384199414 54.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-83a81208-1b0e-4409-8b41-e2a8d6941906">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83a81208-1b0e-4409-8b41-e2a8d6941906">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83a81208-1b0e-4409-8b41-e2a8d6941906">
											<gml:posList>35.66661595162148 139.74199678264338 56.6 35.66661595162148 139.74199678264338 56.038 35.66665169854469 139.7419947316011 56.038 35.66665169854469 139.7419947316011 56.6 35.66661595162148 139.74199678264338 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4c9ab3bb-3279-435a-a385-43f642a215c0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c9ab3bb-3279-435a-a385-43f642a215c0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c9ab3bb-3279-435a-a385-43f642a215c0">
											<gml:posList>35.66665386862464 139.74199179096075 54.6 35.66665386862464 139.74199179096075 56.6 35.666654493890356 139.74200804958716 56.6 35.666654493890356 139.74200804958716 54.6 35.66665386862464 139.74199179096075 54.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-405e7530-00ad-4f12-a9e0-d80836e820e5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-405e7530-00ad-4f12-a9e0-d80836e820e5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-405e7530-00ad-4f12-a9e0-d80836e820e5">
											<gml:posList>35.666562971442545 139.7420358233832 24.76 35.666562971442545 139.7420358233832 56.6 35.66656096652521 139.74198318170014 56.6 35.66656096652521 139.74198318170014 54.6 35.66656045160828 139.7419698059036 54.6 35.66656045160828 139.7419698059036 24.76 35.666562971442545 139.7420358233832 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-86b47fec-8312-47a3-83b8-51e4bd558280">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-86b47fec-8312-47a3-83b8-51e4bd558280">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-86b47fec-8312-47a3-83b8-51e4bd558280">
											<gml:posList>35.66665169854469 139.7419947316011 56.6 35.66665169854469 139.7419947316011 56.038 35.66665231479628 139.74201099023736 56.038 35.66665231479628 139.74201099023736 56.6 35.66665169854469 139.7419947316011 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0ac6faeb-3fed-41c0-8704-b3f486db8b74">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ac6faeb-3fed-41c0-8704-b3f486db8b74">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ac6faeb-3fed-41c0-8704-b3f486db8b74">
											<gml:posList>35.666614489641766 139.74193507175457 48.1 35.666614489641766 139.74193507175457 51.2 35.66668786057468 139.74198142446392 51.2 35.66672460014167 139.742004633926 51.2 35.66676042888189 139.74202727006684 51.2 35.66679625760929 139.74204989518213 51.2 35.66683339395909 139.74207335830803 51.2 35.66683339395909 139.74207335830803 45.3 35.666865110450566 139.74209339238612 45.3 35.666865110450566 139.74209339238612 24.76 35.66658601962487 139.7419170886075 24.76 35.66658601962487 139.7419170886075 48.1 35.666614489641766 139.74193507175457 48.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2432218e-b741-4ee6-8ebe-7fde71375a8e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2432218e-b741-4ee6-8ebe-7fde71375a8e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2432218e-b741-4ee6-8ebe-7fde71375a8e">
											<gml:posList>35.666688817163795 139.74200668500686 54.6 35.666688817163795 139.74200668500686 51.2 35.66668786057468 139.74198142446392 51.2 35.66668786057468 139.74198142446392 54.6 35.66668879868397 139.74200608855736 54.6 35.66668879868397 139.74200608855736 56.6 35.66668970904352 139.74202982483985 56.6 35.66668970904352 139.74202982483985 54.6 35.666688817163795 139.74200668500686 54.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-06e69818-d5bf-4e56-bde4-d14e905b7966">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-06e69818-d5bf-4e56-bde4-d14e905b7966">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-06e69818-d5bf-4e56-bde4-d14e905b7966">
											<gml:posList>35.666688817163795 139.74200668500686 51.2 35.666688817163795 139.74200668500686 54.6 35.66672460014167 139.742004633926 54.6 35.66672460014167 139.742004633926 51.2 35.666688817163795 139.74200668500686 51.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-60d540e1-f99e-42eb-b413-4d6e69605c61">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-60d540e1-f99e-42eb-b413-4d6e69605c61">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-60d540e1-f99e-42eb-b413-4d6e69605c61">
											<gml:posList>35.666654493890356 139.74200804958716 54.6 35.666654493890356 139.74200804958716 56.6 35.66668879868397 139.74200608855736 56.6 35.66668879868397 139.74200608855736 54.6 35.666654493890356 139.74200804958716 54.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-30de84e7-1869-43d7-9520-24efb74fcfb1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-30de84e7-1869-43d7-9520-24efb74fcfb1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-30de84e7-1869-43d7-9520-24efb74fcfb1">
											<gml:posList>35.66656515955099 139.7420328827267 56.6 35.66656515955099 139.7420328827267 56.038 35.66656337521858 139.7419858520238 56.038 35.66656337521858 139.7419858520238 56.6 35.66656515955099 139.7420328827267 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6c2321f6-b2c1-464c-bfb6-4762095f16f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c2321f6-b2c1-464c-bfb6-4762095f16f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c2321f6-b2c1-464c-bfb6-4762095f16f0">
											<gml:posList>35.66665231479628 139.74201099023736 56.6 35.66665231479628 139.74201099023736 56.038 35.66668662860369 139.74200902919858 56.038 35.66668662860369 139.74200902919858 56.6 35.66665231479628 139.74201099023736 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b2408e3e-1c80-4baf-94e0-261c1314ddc7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b2408e3e-1c80-4baf-94e0-261c1314ddc7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b2408e3e-1c80-4baf-94e0-261c1314ddc7">
											<gml:posList>35.66668662860369 139.74200902919858 56.6 35.66668662860369 139.74200902919858 56.038 35.66668752994893 139.74203276549073 56.038 35.66668752994893 139.74203276549073 56.6 35.66668662860369 139.74200902919858 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6ed21f42-1879-44dd-bdec-7e529e6c470a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ed21f42-1879-44dd-bdec-7e529e6c470a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ed21f42-1879-44dd-bdec-7e529e6c470a">
											<gml:posList>35.66672554723482 139.7420292648835 51.2 35.66672554723482 139.7420292648835 54.6 35.66676042888189 139.74202727006684 54.6 35.66676042888189 139.74202727006684 51.2 35.66672554723482 139.7420292648835 51.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fa0f3952-c623-4835-976c-97b61b86f659">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa0f3952-c623-4835-976c-97b61b86f659">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa0f3952-c623-4835-976c-97b61b86f659">
											<gml:posList>35.66668970904352 139.74202982483985 54.6 35.66668970904352 139.74202982483985 56.6 35.66672549202179 139.7420277737693 56.6 35.66672549202179 139.7420277737693 54.6 35.66668970904352 139.74202982483985 54.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-350ff88e-db42-402f-8a6e-22b9d40b1092">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-350ff88e-db42-402f-8a6e-22b9d40b1092">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-350ff88e-db42-402f-8a6e-22b9d40b1092">
											<gml:posList>35.66672554723482 139.7420292648835 54.6 35.66672554723482 139.7420292648835 51.2 35.66672460014167 139.742004633926 51.2 35.66672460014167 139.742004633926 54.6 35.66672549202179 139.7420277737693 54.6 35.66672549202179 139.7420277737693 56.6 35.666726466904954 139.7420533988138 56.6 35.666726466904954 139.7420533988138 54.6 35.66672554723482 139.7420292648835 54.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8e8ec719-69c0-4ad7-af08-9ebef66f4a0d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8e8ec719-69c0-4ad7-af08-9ebef66f4a0d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8e8ec719-69c0-4ad7-af08-9ebef66f4a0d">
											<gml:posList>35.66660578269303 139.74203055000632 56.6 35.66660578269303 139.74203055000632 56.038 35.66656515955099 139.7420328827267 56.038 35.66656515955099 139.7420328827267 56.6 35.66660578269303 139.74203055000632 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-43861f6a-b4f8-4330-a5e2-67ba70d3a92f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-43861f6a-b4f8-4330-a5e2-67ba70d3a92f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-43861f6a-b4f8-4330-a5e2-67ba70d3a92f">
											<gml:posList>35.66668752994893 139.74203276549073 56.6 35.66668752994893 139.74203276549073 56.038 35.666723321940985 139.74203071441127 56.038 35.666723321940985 139.74203071441127 56.6 35.66668752994893 139.74203276549073 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-99c852c9-e62b-4a35-94f0-3d8aeaa02147">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-99c852c9-e62b-4a35-94f0-3d8aeaa02147">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-99c852c9-e62b-4a35-94f0-3d8aeaa02147">
											<gml:posList>35.66658958784476 139.74203429085924 54.4 35.66660358557093 139.74203349067463 54.4 35.66660358557093 139.74203349067463 56.6 35.666562971442545 139.7420358233832 56.6 35.666562971442545 139.7420358233832 24.76 35.66657782543117 139.7420349669955 24.76 35.66657782543117 139.7420349669955 51.4 35.66658958784476 139.74203429085924 51.4 35.66658958784476 139.74203429085924 54.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-848c2629-909f-4a26-9a81-705e6ed2d04e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-848c2629-909f-4a26-9a81-705e6ed2d04e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-848c2629-909f-4a26-9a81-705e6ed2d04e">
											<gml:posList>35.66676042888189 139.74202727006684 51.2 35.66676042888189 139.74202727006684 54.6 35.66676134855244 139.74205140400758 54.6 35.66676134855244 139.74205140400758 51.2 35.66676042888189 139.74202727006684 51.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7ac9ccae-c60a-4b47-929b-4b7b568f7639">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ac9ccae-c60a-4b47-929b-4b7b568f7639">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ac9ccae-c60a-4b47-929b-4b7b568f7639">
											<gml:posList>35.666606573759275 139.74205150287392 56.6 35.666606573759275 139.74205150287392 56.038 35.66660578269303 139.74203055000632 56.038 35.66660578269303 139.74203055000632 56.6 35.666606573759275 139.74205150287392 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4b1b0923-4903-4c60-bd78-9e2c9b756370">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b1b0923-4903-4c60-bd78-9e2c9b756370">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b1b0923-4903-4c60-bd78-9e2c9b756370">
											<gml:posList>35.666723321940985 139.74203071441127 56.6 35.666723321940985 139.74203071441127 56.038 35.66672428780981 139.7420563394654 56.038 35.66672428780981 139.7420563394654 56.6 35.666723321940985 139.74203071441127 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2b068a0d-f864-40bd-b24d-be49058184d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b068a0d-f864-40bd-b24d-be49058184d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b068a0d-f864-40bd-b24d-be49058184d1">
											<gml:posList>35.666604385650395 139.74205444353143 54.4 35.666604385650395 139.74205444353143 56.6 35.66660358557093 139.74203349067463 56.6 35.66660358557093 139.74203349067463 54.4 35.666604385650395 139.74205444353143 54.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0bd22f3f-3fe4-41f7-b447-d138cd39afa4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0bd22f3f-3fe4-41f7-b447-d138cd39afa4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0bd22f3f-3fe4-41f7-b447-d138cd39afa4">
											<gml:posList>35.66659037891034 139.74205524372266 51.4 35.66659037891034 139.74205524372266 54.4 35.66658958784476 139.74203429085924 54.4 35.66658958784476 139.74203429085924 51.4 35.66659037891034 139.74205524372266 51.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ad281013-e780-494f-996b-29467adb9fe8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad281013-e780-494f-996b-29467adb9fe8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad281013-e780-494f-996b-29467adb9fe8">
											<gml:posList>35.66676134855244 139.74205140400758 51.2 35.66676134855244 139.74205140400758 54.6 35.66679625760929 139.74204989518213 54.6 35.66679625760929 139.74204989518213 51.2 35.66676134855244 139.74205140400758 51.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fda4ad3e-ff6e-45b2-aa4f-45d437e3678b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fda4ad3e-ff6e-45b2-aa4f-45d437e3678b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fda4ad3e-ff6e-45b2-aa4f-45d437e3678b">
											<gml:posList>35.666615289658196 139.74205099589392 56.6 35.666615289658196 139.74205099589392 56.038 35.666606573759275 139.74205150287392 56.038 35.666606573759275 139.74205150287392 56.6 35.666615289658196 139.74205099589392 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9530dfda-f466-4031-8055-a11dffdc30fa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9530dfda-f466-4031-8055-a11dffdc30fa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9530dfda-f466-4031-8055-a11dffdc30fa">
											<gml:posList>35.666726466904954 139.7420533988138 56.6 35.66676134855244 139.74205140400758 56.6 35.66676134855244 139.74205140400758 54.6 35.666726466904954 139.7420533988138 54.6 35.666726466904954 139.7420533988138 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-77b65ede-0aa9-497d-b0a6-05ef60db50b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-77b65ede-0aa9-497d-b0a6-05ef60db50b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-77b65ede-0aa9-497d-b0a6-05ef60db50b9">
											<gml:posList>35.66659037891034 139.74205524372266 51.4 35.66657862551036 139.7420559198456 51.4 35.66657862551036 139.7420559198456 48.4 35.6666130925356 139.74205393656203 48.4 35.6666130925356 139.74205393656203 56.6 35.666604385650395 139.74205444353143 56.6 35.666604385650395 139.74205444353143 54.4 35.66659037891034 139.74205524372266 54.4 35.66659037891034 139.74205524372266 51.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f14472f6-2dbf-48aa-b4d3-3ac950acada0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f14472f6-2dbf-48aa-b4d3-3ac950acada0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f14472f6-2dbf-48aa-b4d3-3ac950acada0">
											<gml:posList>35.66672428780981 139.7420563394654 56.6 35.66672428780981 139.7420563394654 56.038 35.66675917847108 139.74205434465026 56.038 35.66675917847108 139.74205434465026 56.6 35.66672428780981 139.7420563394654 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-057b2c28-315c-46d0-88be-15354dc07e9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-057b2c28-315c-46d0-88be-15354dc07e9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-057b2c28-315c-46d0-88be-15354dc07e9a">
											<gml:posList>35.66657782543117 139.7420349669955 51.4 35.66657782543117 139.7420349669955 24.76 35.666579535935384 139.74207975550763 24.76 35.666579535935384 139.74207975550763 48.4 35.66657862551036 139.7420559198456 48.4 35.66657862551036 139.7420559198456 51.4 35.66657782543117 139.7420349669955 51.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f296db8e-10e5-4899-a686-2a48a28b227a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f296db8e-10e5-4899-a686-2a48a28b227a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f296db8e-10e5-4899-a686-2a48a28b227a">
											<gml:posList>35.66676134855244 139.74205140400758 56.6 35.666762258970046 139.74207522867815 56.6 35.666762258970046 139.74207522867815 54.6 35.66676134855244 139.74205140400758 54.6 35.66676134855244 139.74205140400758 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f6e5ae6b-a8f7-46b6-a658-8013d06227b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f6e5ae6b-a8f7-46b6-a658-8013d06227b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f6e5ae6b-a8f7-46b6-a658-8013d06227b4">
											<gml:posList>35.66661627371753 139.7420768418079 56.6 35.66661627371753 139.7420768418079 56.038 35.666615289658196 139.74205099589392 56.038 35.666615289658196 139.74205099589392 56.6 35.66661627371753 139.7420768418079 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2551a5d4-3259-49b6-922d-aaf2decd49dc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2551a5d4-3259-49b6-922d-aaf2decd49dc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2551a5d4-3259-49b6-922d-aaf2decd49dc">
											<gml:posList>35.66675917847108 139.74205434465026 56.6 35.66675917847108 139.74205434465026 56.038 35.66676007987437 139.74207816933045 56.038 35.66676007987437 139.74207816933045 56.6 35.66675917847108 139.74205434465026 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4b5ecd9e-04d0-41e7-9a16-1a2971fb5a22">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b5ecd9e-04d0-41e7-9a16-1a2971fb5a22">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b5ecd9e-04d0-41e7-9a16-1a2971fb5a22">
											<gml:posList>35.666614002969396 139.74207778328002 48.4 35.666614002969396 139.74207778328002 24.76 35.66661408560804 139.74207978246503 24.76 35.66661408560804 139.74207978246503 56.6 35.6666130925356 139.74205393656203 56.6 35.6666130925356 139.74205393656203 48.4 35.666614002969396 139.74207778328002 48.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-df851d8c-faba-43b3-80b5-60850ed3524d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df851d8c-faba-43b3-80b5-60850ed3524d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df851d8c-faba-43b3-80b5-60850ed3524d">
											<gml:posList>35.66679722340708 139.74207543189374 54.6 35.66679722340708 139.74207543189374 51.2 35.66679625760929 139.74204989518213 51.2 35.66679625760929 139.74204989518213 54.6 35.66679714060932 139.74207322283476 54.6 35.66679714060932 139.74207322283476 56.6 35.66679809691141 139.74209812994906 56.6 35.66679809691141 139.74209812994906 54.6 35.66679722340708 139.74207543189374 54.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3451d221-a601-4b32-9c6b-3c12a7c94dad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3451d221-a601-4b32-9c6b-3c12a7c94dad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3451d221-a601-4b32-9c6b-3c12a7c94dad">
											<gml:posList>35.666762258970046 139.74207522867815 56.6 35.66679714060932 139.74207322283476 56.6 35.66679714060932 139.74207322283476 54.6 35.666762258970046 139.74207522867815 54.6 35.666762258970046 139.74207522867815 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d8289195-fe76-44c8-8e77-fb43fa85f771">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d8289195-fe76-44c8-8e77-fb43fa85f771">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d8289195-fe76-44c8-8e77-fb43fa85f771">
											<gml:posList>35.66679722340708 139.74207543189374 51.2 35.66679722340708 139.74207543189374 54.6 35.66683339395909 139.74207335830803 54.6 35.66683339395909 139.74207335830803 51.2 35.66679722340708 139.74207543189374 51.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-55f9eda2-b7e3-48ad-85c5-fba5715b745c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-55f9eda2-b7e3-48ad-85c5-fba5715b745c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-55f9eda2-b7e3-48ad-85c5-fba5715b745c">
											<gml:posList>35.66665568005696 139.7420745767675 56.6 35.66665568005696 139.7420745767675 56.038 35.66661627371753 139.7420768418079 56.038 35.66661627371753 139.7420768418079 56.6 35.66665568005696 139.7420745767675 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-315918a8-ceae-4046-a0b8-62845a801038">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-315918a8-ceae-4046-a0b8-62845a801038">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-315918a8-ceae-4046-a0b8-62845a801038">
											<gml:posList>35.66676007987437 139.74207816933045 56.6 35.66676007987437 139.74207816933045 56.038 35.66679496151371 139.7420761634884 56.038 35.66679496151371 139.7420761634884 56.6 35.66676007987437 139.74207816933045 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e4e403f3-bda5-472e-a146-5b7cb6d4fe6f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e4e403f3-bda5-472e-a146-5b7cb6d4fe6f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e4e403f3-bda5-472e-a146-5b7cb6d4fe6f">
											<gml:posList>35.66661408560804 139.74207978246503 56.6 35.66661408560804 139.74207978246503 24.76 35.666632580984206 139.74207871207196 24.76 35.666632580984206 139.74207871207196 47.7 35.6666534829338 139.74207751743643 47.7 35.6666534829338 139.74207751743643 56.6 35.66661408560804 139.74207978246503 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a4a98f1d-c659-4779-b913-0342f8acf834">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4a98f1d-c659-4779-b913-0342f8acf834">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4a98f1d-c659-4779-b913-0342f8acf834">
											<gml:posList>35.666579535935384 139.74207975550763 24.76 35.666614002969396 139.74207778328002 24.76 35.666614002969396 139.74207778328002 48.4 35.666579535935384 139.74207975550763 48.4 35.666579535935384 139.74207975550763 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-37b7cced-543c-4780-8046-1c0ac313a7d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37b7cced-543c-4780-8046-1c0ac313a7d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37b7cced-543c-4780-8046-1c0ac313a7d8">
											<gml:posList>35.66665671029291 139.74210189172655 56.6 35.66665671029291 139.74210189172655 56.038 35.66665568005696 139.7420745767675 56.038 35.66665568005696 139.7420745767675 56.6 35.66665671029291 139.74210189172655 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7f340590-48ce-4ffe-9e44-fa2b988e3b8a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f340590-48ce-4ffe-9e44-fa2b988e3b8a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f340590-48ce-4ffe-9e44-fa2b988e3b8a">
											<gml:posList>35.66679496151371 139.7420761634884 56.6 35.66679496151371 139.7420761634884 56.038 35.66679590880147 139.7421010706123 56.038 35.66679590880147 139.7421010706123 56.6 35.66679496151371 139.7420761634884 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c06c595c-8fc8-4f70-8937-3594c6672505">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c06c595c-8fc8-4f70-8937-3594c6672505">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c06c595c-8fc8-4f70-8937-3594c6672505">
											<gml:posList>35.666632580984206 139.74207871207196 24.76 35.66663349137127 139.74210250356734 24.76 35.66663349137127 139.74210250356734 47.7 35.666632580984206 139.74207871207196 47.7 35.666632580984206 139.74207871207196 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-605a79da-9372-4624-bf8e-576dd90f7b86">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-605a79da-9372-4624-bf8e-576dd90f7b86">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-605a79da-9372-4624-bf8e-576dd90f7b86">
											<gml:posList>35.66665439331274 139.74210129789228 47.7 35.66665439331274 139.74210129789228 24.76 35.66665452218282 139.7421048323845 24.76 35.66665452218282 139.7421048323845 56.6 35.6666534829338 139.74207751743643 56.6 35.6666534829338 139.74207751743643 47.7 35.66665439331274 139.74210129789228 47.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c6a8f438-5314-420c-8fed-47ddb1ae1520">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6a8f438-5314-420c-8fed-47ddb1ae1520">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6a8f438-5314-420c-8fed-47ddb1ae1520">
											<gml:posList>35.666902840310534 139.7420912286662 24.76 35.666865110450566 139.74209339238612 24.76 35.666865110450566 139.74209339238612 45.3 35.666834230731006 139.7420951617079 45.3 35.666834230731006 139.7420951617079 48.7 35.66688877949693 139.7420920399614 48.7 35.66688877949693 139.7420920399614 45.3 35.666902840310534 139.7420912286662 45.3 35.666902840310534 139.7420912286662 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2eb59687-4fbc-40da-be25-3580829314f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2eb59687-4fbc-40da-be25-3580829314f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2eb59687-4fbc-40da-be25-3580829314f2">
											<gml:posList>35.66679809691141 139.74209812994906 56.6 35.66683426746382 139.74209605637358 56.6 35.66683426746382 139.74209605637358 54.6 35.66679809691141 139.74209812994906 54.6 35.66679809691141 139.74209812994906 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fcb5a851-c585-492b-bd3d-83685be4f769">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fcb5a851-c585-492b-bd3d-83685be4f769">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fcb5a851-c585-492b-bd3d-83685be4f769">
											<gml:posList>35.66670880743525 139.74209891637594 56.6 35.66670880743525 139.74209891637594 56.038 35.666706671265246 139.7420990292639 56.038 35.666706671265246 139.7420990292639 56.6 35.66670880743525 139.74209891637594 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-19c29231-9133-43a6-b436-ffea4dee2d72">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-19c29231-9133-43a6-b436-ffea4dee2d72">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-19c29231-9133-43a6-b436-ffea4dee2d72">
											<gml:posList>35.66679590880147 139.7421010706123 56.6 35.66679590880147 139.7421010706123 56.038 35.66683208836766 139.74209899702794 56.038 35.66683208836766 139.74209899702794 56.6 35.66679590880147 139.7421010706123 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bf6fa59b-909f-4d74-9b86-f565945ff164">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf6fa59b-909f-4d74-9b86-f565945ff164">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf6fa59b-909f-4d74-9b86-f565945ff164">
											<gml:posList>35.66670890870352 139.74210171083644 56.6 35.66670890870352 139.74210171083644 56.038 35.66670880743525 139.74209891637594 56.038 35.66670880743525 139.74209891637594 56.6 35.66670890870352 139.74210171083644 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fc984566-6fb0-49a8-99ce-24dfdc224f5b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc984566-6fb0-49a8-99ce-24dfdc224f5b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc984566-6fb0-49a8-99ce-24dfdc224f5b">
											<gml:posList>35.666706671265246 139.7420990292639 56.6 35.666706671265246 139.7420990292639 56.038 35.66665671029291 139.74210189172655 56.038 35.66665671029291 139.74210189172655 56.6 35.666706671265246 139.7420990292639 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e32fe0de-a624-4cba-b8ab-76dd186fb34b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e32fe0de-a624-4cba-b8ab-76dd186fb34b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e32fe0de-a624-4cba-b8ab-76dd186fb34b">
											<gml:posList>35.66670890870352 139.74210171083644 56.6 35.66670677254189 139.7421018347701 56.6 35.66670677254189 139.7421018347701 61.762 35.66673403791606 139.74210027943533 61.762 35.66673403791606 139.74210027943533 56.038 35.66670890870352 139.74210171083644 56.038 35.66670890870352 139.74210171083644 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0671c651-1d46-4255-a9b0-150bac43482c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0671c651-1d46-4255-a9b0-150bac43482c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0671c651-1d46-4255-a9b0-150bac43482c">
											<gml:posList>35.66663349137127 139.74210250356734 24.76 35.66665439331274 139.74210129789228 24.76 35.66665439331274 139.74210129789228 47.7 35.66663349137127 139.74210250356734 47.7 35.66663349137127 139.74210250356734 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-28974766-b7a1-4c0f-87a3-2fd61e1ef943">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28974766-b7a1-4c0f-87a3-2fd61e1ef943">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28974766-b7a1-4c0f-87a3-2fd61e1ef943">
											<gml:posList>35.66665452218282 139.7421048323845 24.76 35.66670677254189 139.7421018347701 24.76 35.66670677254189 139.7421018347701 56.6 35.66665452218282 139.7421048323845 56.6 35.66665452218282 139.7421048323845 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-abb22d26-1aac-474f-a4b4-9071a3825ca4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-abb22d26-1aac-474f-a4b4-9071a3825ca4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-abb22d26-1aac-474f-a4b4-9071a3825ca4">
											<gml:posList>35.66690387022484 139.7421181239703 24.76 35.666902840310534 139.7420912286662 24.76 35.666902840310534 139.7420912286662 45.3 35.66690387022484 139.7421181239703 45.3 35.66690387022484 139.7421181239703 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fe735e88-6de2-4ae8-8df0-3073e528ee86">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe735e88-6de2-4ae8-8df0-3073e528ee86">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe735e88-6de2-4ae8-8df0-3073e528ee86">
											<gml:posList>35.666834230731006 139.7420951617079 48.7 35.666834230731006 139.7420951617079 45.3 35.66683339395909 139.74207335830803 45.3 35.66683339395909 139.74207335830803 51.2 35.66683339395909 139.74207335830803 54.6 35.66683426746382 139.74209605637358 54.6 35.66683426746382 139.74209605637358 56.6 35.66683582163372 139.74213678036415 56.6 35.66683582163372 139.74213678036415 54.6 35.66683522390344 139.74212115127762 54.6 35.66683522390344 139.74212115127762 51.1 35.66683469059776 139.74210727839565 51.1 35.66683469059776 139.74210727839565 48.7 35.666834230731006 139.7420951617079 48.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b305b74-e91e-495b-ba4d-bb360607382d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b305b74-e91e-495b-ba4d-bb360607382d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b305b74-e91e-495b-ba4d-bb360607382d">
											<gml:posList>35.66688877949693 139.7420920399614 45.3 35.66688877949693 139.7420920399614 48.7 35.66688933140735 139.74211857129387 48.7 35.66688933140735 139.74211857129387 45.3 35.66688877949693 139.7420920399614 45.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8b839752-3ef4-486a-9058-087e4358bb63">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b839752-3ef4-486a-9058-087e4358bb63">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b839752-3ef4-486a-9058-087e4358bb63">
											<gml:posList>35.66683469059776 139.74210727839565 48.7 35.66683469059776 139.74210727839565 51.1 35.66686893229592 139.74210531747548 51.1 35.66686893229592 139.74210531747548 48.7 35.66683469059776 139.74210727839565 48.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-45ba4c22-7cb4-4b0c-9647-4b39a90888e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45ba4c22-7cb4-4b0c-9647-4b39a90888e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45ba4c22-7cb4-4b0c-9647-4b39a90888e8">
											<gml:posList>35.66686893229592 139.74210531747548 48.7 35.66686893229592 139.74210531747548 51.1 35.66686945658811 139.74211919037361 51.1 35.66686945658811 139.74211919037361 48.7 35.66686893229592 139.74210531747548 48.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-787de74a-fe1b-4082-94bb-85dca33df6ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-787de74a-fe1b-4082-94bb-85dca33df6ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-787de74a-fe1b-4082-94bb-85dca33df6ca">
											<gml:posList>35.66693827416154 139.7421161518227 24.76 35.66690387022484 139.7421181239703 24.76 35.66690387022484 139.7421181239703 45.3 35.66690387022484 139.7421181239703 51.1 35.66692497045918 139.74211690702376 51.1 35.66692497045918 139.74211690702376 48.4 35.66693827416154 139.7421161518227 48.4 35.66693827416154 139.7421161518227 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-22dea2d6-f295-4af3-a792-5dc239094671">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22dea2d6-f295-4af3-a792-5dc239094671">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22dea2d6-f295-4af3-a792-5dc239094671">
											<gml:posList>35.66690387022484 139.7421181239703 51.1 35.66690387022484 139.7421181239703 45.3 35.66688933140735 139.74211857129387 45.3 35.66688933140735 139.74211857129387 48.7 35.66686945658811 139.74211919037361 48.7 35.66686945658811 139.74211919037361 51.1 35.66690387022484 139.7421181239703 51.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6150b553-d469-487d-af15-21569f920a19">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6150b553-d469-487d-af15-21569f920a19">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6150b553-d469-487d-af15-21569f920a19">
											<gml:posList>35.66683208836766 139.74209899702794 56.6 35.66683208836766 139.74209899702794 56.038 35.66683363351448 139.74213970998198 56.038 35.66683363351448 139.74213970998198 56.6 35.66683208836766 139.74209899702794 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f55c08c7-7f10-4cbe-bb0a-c2bfea4a950c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f55c08c7-7f10-4cbe-bb0a-c2bfea4a950c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f55c08c7-7f10-4cbe-bb0a-c2bfea4a950c">
											<gml:posList>35.66683522390344 139.74212115127762 51.1 35.66683522390344 139.74212115127762 54.6 35.66686945658811 139.74211919037361 54.6 35.66686945658811 139.74211919037361 51.1 35.66683522390344 139.74212115127762 51.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fb3bc802-a1a5-43d7-b7c9-7bddd8ca34ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb3bc802-a1a5-43d7-b7c9-7bddd8ca34ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb3bc802-a1a5-43d7-b7c9-7bddd8ca34ec">
											<gml:posList>35.66673403791606 139.74210027943533 61.762 35.666736220188035 139.74214913233843 61.762 35.666736220188035 139.74214913233843 56.038 35.66673403791606 139.74210027943533 56.038 35.66673403791606 139.74210027943533 61.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aca5cc4e-e82d-4f46-b629-ba4565d5fefe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aca5cc4e-e82d-4f46-b629-ba4565d5fefe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aca5cc4e-e82d-4f46-b629-ba4565d5fefe">
											<gml:posList>35.66670864857229 139.74215098624018 61.762 35.66670677254189 139.7421018347701 61.762 35.66670677254189 139.7421018347701 56.6 35.66670677254189 139.7421018347701 24.76 35.66670864857229 139.74215098624018 24.76 35.66670864857229 139.74215098624018 61.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a6879e4e-5973-4718-a64a-538bc412381e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a6879e4e-5973-4718-a64a-538bc412381e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a6879e4e-5973-4718-a64a-538bc412381e">
											<gml:posList>35.66686945658811 139.74211919037361 51.1 35.66686945658811 139.74211919037361 54.6 35.66687005431864 139.7421348194668 54.6 35.66687005431864 139.7421348194668 51.1 35.66686945658811 139.74211919037361 51.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cdba9942-ba6c-404c-98f5-1a69db9dec2a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cdba9942-ba6c-404c-98f5-1a69db9dec2a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cdba9942-ba6c-404c-98f5-1a69db9dec2a">
											<gml:posList>35.666939396189996 139.74214566488547 24.76 35.66693827416154 139.7421161518227 24.76 35.66693827416154 139.7421161518227 48.4 35.666939396189996 139.74214566488547 48.4 35.666939396189996 139.74214566488547 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4ae5d345-3120-4f41-9b54-3d0b2c7aa6af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ae5d345-3120-4f41-9b54-3d0b2c7aa6af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ae5d345-3120-4f41-9b54-3d0b2c7aa6af">
											<gml:posList>35.66692497045918 139.74211690702376 48.4 35.66692497045918 139.74211690702376 51.1 35.666926092495814 139.74214643112742 51.1 35.666926092495814 139.74214643112742 48.4 35.66692497045918 139.74211690702376 48.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-663c0ede-319c-42b2-adf7-ef644f07e0ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-663c0ede-319c-42b2-adf7-ef644f07e0ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-663c0ede-319c-42b2-adf7-ef644f07e0ee">
											<gml:posList>35.66687005431864 139.7421348194668 51.1 35.66687005431864 139.7421348194668 54.6 35.66690296203547 139.74213292634937 54.6 35.66690296203547 139.74213292634937 51.1 35.66687005431864 139.7421348194668 51.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-11d85a99-e816-44c9-b658-9de12dc01f46">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11d85a99-e816-44c9-b658-9de12dc01f46">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11d85a99-e816-44c9-b658-9de12dc01f46">
											<gml:posList>35.66683582163372 139.74213678036415 56.6 35.66687005431864 139.7421348194668 56.6 35.66687005431864 139.7421348194668 54.6 35.66683582163372 139.74213678036415 54.6 35.66683582163372 139.74213678036415 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-04b3eba7-6491-479f-8aa9-2d7ffe3745da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04b3eba7-6491-479f-8aa9-2d7ffe3745da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04b3eba7-6491-479f-8aa9-2d7ffe3745da">
											<gml:posList>35.66683363351448 139.74213970998198 56.6 35.66683363351448 139.74213970998198 56.038 35.6668678752132 139.7421377490757 56.038 35.6668678752132 139.7421377490757 56.6 35.66683363351448 139.74213970998198 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9a2399cc-2385-44d5-ac2a-4512215e84c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a2399cc-2385-44d5-ac2a-4512215e84c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a2399cc-2385-44d5-ac2a-4512215e84c7">
											<gml:posList>35.66690296203547 139.74213292634937 51.1 35.66690296203547 139.74213292634937 54.6 35.66690353209572 139.74214772704713 54.6 35.66690353209572 139.74214772704713 51.1 35.66690296203547 139.74213292634937 51.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a63ab339-ab7d-4ecc-a1e3-046f72467d88">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a63ab339-ab7d-4ecc-a1e3-046f72467d88">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a63ab339-ab7d-4ecc-a1e3-046f72467d88">
											<gml:posList>35.66687005431864 139.7421348194668 56.6 35.6668706243703 139.74214960911272 56.6 35.6668706243703 139.74214960911272 54.6 35.66687005431864 139.7421348194668 54.6 35.66687005431864 139.7421348194668 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-67af45a9-003b-4d3b-aff1-934c71ad3e56">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67af45a9-003b-4d3b-aff1-934c71ad3e56">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67af45a9-003b-4d3b-aff1-934c71ad3e56">
											<gml:posList>35.6668678752132 139.7421377490757 56.6 35.6668678752132 139.7421377490757 56.038 35.66686843625076 139.7421525387315 56.038 35.66686843625076 139.7421525387315 56.6 35.6668678752132 139.7421377490757 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-be8e8496-7ee9-4356-8fd3-8229a27f725e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-be8e8496-7ee9-4356-8fd3-8229a27f725e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-be8e8496-7ee9-4356-8fd3-8229a27f725e">
											<gml:posList>35.666939396189996 139.74214566488547 48.4 35.666926092495814 139.74214643112742 48.4 35.666926092495814 139.74214643112742 51.1 35.66690353209572 139.74214772704713 51.1 35.66690353209572 139.74214772704713 54.6 35.6668706243703 139.74214960911272 54.6 35.6668706243703 139.74214960911272 56.6 35.66694132504419 139.74214555223415 56.6 35.66694132504419 139.74214555223415 44.9 35.666954863086914 139.7421447746796 44.9 35.666954863086914 139.7421447746796 24.76 35.666939396189996 139.74214566488547 24.76 35.666939396189996 139.74214566488547 48.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0f369677-d119-4d4c-8608-0aedd85e7f99">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0f369677-d119-4d4c-8608-0aedd85e7f99">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0f369677-d119-4d4c-8608-0aedd85e7f99">
											<gml:posList>35.66673569741687 139.74214916607016 56.6 35.66673569741687 139.74214916607016 56.038 35.666736220188035 139.74214913233843 56.038 35.666736220188035 139.74214913233843 61.762 35.666720861471994 139.7421500445094 61.762 35.666720861471994 139.7421500445094 54.1 35.66673340803854 139.7421493122683 54.1 35.66673340803854 139.7421493122683 56.6 35.66673569741687 139.74214916607016 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c13419ce-a17b-40af-9101-8eb4e4508224">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c13419ce-a17b-40af-9101-8eb4e4508224">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c13419ce-a17b-40af-9101-8eb4e4508224">
											<gml:posList>35.66670864857229 139.74215098624018 61.762 35.66670864857229 139.74215098624018 24.76 35.666720861471994 139.7421500445094 24.76 35.666720861471994 139.7421500445094 54.1 35.666720861471994 139.7421500445094 61.762 35.66670864857229 139.74215098624018 61.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-34cc2458-44e4-4569-87a4-59ed4ef054dc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-34cc2458-44e4-4569-87a4-59ed4ef054dc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-34cc2458-44e4-4569-87a4-59ed4ef054dc">
											<gml:posList>35.66673581671144 139.74215196051117 56.6 35.66673581671144 139.74215196051117 56.038 35.66673569741687 139.74214916607016 56.038 35.66673569741687 139.74214916607016 56.6 35.66673581671144 139.74215196051117 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-167b2d48-9a5f-4209-bef1-0b98d2dffd20">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-167b2d48-9a5f-4209-bef1-0b98d2dffd20">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-167b2d48-9a5f-4209-bef1-0b98d2dffd20">
											<gml:posList>35.66686843625076 139.7421525387315 56.6 35.66686843625076 139.7421525387315 56.038 35.666939145938514 139.74214848184536 56.038 35.666939145938514 139.74214848184536 56.6 35.66686843625076 139.7421525387315 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bf169383-42a1-48d0-9842-f4f0879d2d8d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf169383-42a1-48d0-9842-f4f0879d2d8d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf169383-42a1-48d0-9842-f4f0879d2d8d">
											<gml:posList>35.666720861471994 139.7421500445094 24.76 35.66672185470779 139.74217613345482 24.76 35.66672185470779 139.74217613345482 54.1 35.666720861471994 139.7421500445094 54.1 35.666720861471994 139.7421500445094 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-321c846d-c188-486c-bc3d-9a3a1a92f843">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-321c846d-c188-486c-bc3d-9a3a1a92f843">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-321c846d-c188-486c-bc3d-9a3a1a92f843">
											<gml:posList>35.66673681009733 139.74217824828494 56.6 35.66673681009733 139.74217824828494 56.038 35.66673581671144 139.74215196051117 56.038 35.66673581671144 139.74215196051117 56.6 35.66673681009733 139.74217824828494 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-56ecb822-dcf2-400d-8fe9-4170a6156124">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56ecb822-dcf2-400d-8fe9-4170a6156124">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56ecb822-dcf2-400d-8fe9-4170a6156124">
											<gml:posList>35.666734401282866 139.74217541226352 54.1 35.666734401282866 139.74217541226352 24.76 35.66673462199377 139.7421811999895 24.76 35.66673462199377 139.7421811999895 56.6 35.66673340803854 139.7421493122683 56.6 35.66673340803854 139.7421493122683 54.1 35.666734401282866 139.74217541226352 54.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a79aadf7-ee43-42ab-8d73-5b4adc4f8b6b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a79aadf7-ee43-42ab-8d73-5b4adc4f8b6b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a79aadf7-ee43-42ab-8d73-5b4adc4f8b6b">
											<gml:posList>35.66695679416878 139.74219522964322 24.76 35.666954863086914 139.7421447746796 24.76 35.666954863086914 139.7421447746796 44.9 35.66695679416878 139.74219522964322 44.9 35.66695679416878 139.74219522964322 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d26d4a9b-93c3-46a9-b960-97392dd5852a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d26d4a9b-93c3-46a9-b960-97392dd5852a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d26d4a9b-93c3-46a9-b960-97392dd5852a">
											<gml:posList>35.66694359645502 139.742205020164 56.6 35.66694359645502 139.742205020164 24.76 35.66694324711201 139.74219600719948 24.76 35.66694324711201 139.74219600719948 44.9 35.66694132504419 139.74214555223415 44.9 35.66694132504419 139.74214555223415 56.6 35.66694359645502 139.742205020164 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bf472489-a386-49b4-b8d3-166c1115a90b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf472489-a386-49b4-b8d3-166c1115a90b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf472489-a386-49b4-b8d3-166c1115a90b">
											<gml:posList>35.666939145938514 139.74214848184536 56.6 35.666939145938514 139.74214848184536 56.038 35.66694119677201 139.74220233876508 56.038 35.66694119677201 139.74220233876508 56.6 35.666939145938514 139.74214848184536 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-88bef192-3bf5-4655-adf0-2283c7dd71ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-88bef192-3bf5-4655-adf0-2283c7dd71ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-88bef192-3bf5-4655-adf0-2283c7dd71ec">
											<gml:posList>35.66672185470779 139.74217613345482 24.76 35.666734401282866 139.74217541226352 24.76 35.666734401282866 139.74217541226352 54.1 35.66672185470779 139.74217613345482 54.1 35.66672185470779 139.74217613345482 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-55ce3edb-26df-412b-abeb-efb3fc31594b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-55ce3edb-26df-412b-abeb-efb3fc31594b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-55ce3edb-26df-412b-abeb-efb3fc31594b">
											<gml:posList>35.666771313178664 139.74217626500888 56.6 35.666771313178664 139.74217626500888 56.038 35.66673681009733 139.74217824828494 56.038 35.66673681009733 139.74217824828494 56.6 35.666771313178664 139.74217626500888 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d7497a37-1d09-44ff-b6eb-f368aa88b221">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7497a37-1d09-44ff-b6eb-f368aa88b221">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7497a37-1d09-44ff-b6eb-f368aa88b221">
											<gml:posList>35.66673462199377 139.7421811999895 56.6 35.66673462199377 139.7421811999895 24.76 35.666758327088225 139.74217983650627 24.76 35.666758327088225 139.74217983650627 54.2 35.66676912507516 139.74217921671482 54.2 35.66676912507516 139.74217921671482 56.6 35.66673462199377 139.7421811999895 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-71c195c6-4708-4d57-8be8-6a2c4c330121">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-71c195c6-4708-4d57-8be8-6a2c4c330121">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-71c195c6-4708-4d57-8be8-6a2c4c330121">
											<gml:posList>35.66677220536021 139.7421998466978 56.6 35.66677220536021 139.7421998466978 56.038 35.666771313178664 139.74217626500888 56.038 35.666771313178664 139.74217626500888 56.6 35.66677220536021 139.7421998466978 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a1e648d3-72c2-48e0-a03a-90d8693e765a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a1e648d3-72c2-48e0-a03a-90d8693e765a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a1e648d3-72c2-48e0-a03a-90d8693e765a">
											<gml:posList>35.666758327088225 139.74217983650627 24.76 35.666759062934354 139.7421993203918 24.76 35.666759062934354 139.7421993203918 54.2 35.666758327088225 139.74217983650627 54.2 35.666758327088225 139.74217983650627 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-58175734-5774-4e09-b813-a9dc9e001790">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-58175734-5774-4e09-b813-a9dc9e001790">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-58175734-5774-4e09-b813-a9dc9e001790">
											<gml:posList>35.66676986993511 139.7421987005927 54.2 35.66676986993511 139.7421987005927 24.76 35.666770026269845 139.74220279839284 24.76 35.666770026269845 139.74220279839284 56.6 35.66676912507516 139.74217921671482 56.6 35.66676912507516 139.74217921671482 54.2 35.66676986993511 139.7421987005927 54.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eebdc101-98f8-4462-b043-aaff432507c5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eebdc101-98f8-4462-b043-aaff432507c5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eebdc101-98f8-4462-b043-aaff432507c5">
											<gml:posList>35.66694324711201 139.74219600719948 24.76 35.66695679416878 139.74219522964322 24.76 35.66695679416878 139.74219522964322 44.9 35.66694324711201 139.74219600719948 44.9 35.66694324711201 139.74219600719948 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-37b12263-12db-4545-ad86-f3c5a9adfb0f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37b12263-12db-4545-ad86-f3c5a9adfb0f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37b12263-12db-4545-ad86-f3c5a9adfb0f">
											<gml:posList>35.666759062934354 139.7421993203918 24.76 35.66676986993511 139.7421987005927 24.76 35.66676986993511 139.7421987005927 54.2 35.666759062934354 139.7421993203918 54.2 35.666759062934354 139.7421993203918 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-60d3b8df-2893-4f15-a7fe-a088d002ce09">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-60d3b8df-2893-4f15-a7fe-a088d002ce09">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-60d3b8df-2893-4f15-a7fe-a088d002ce09">
											<gml:posList>35.66679655040438 139.74219844935476 56.6 35.66679655040438 139.74219844935476 56.038 35.66677220536021 139.7421998466978 56.038 35.66677220536021 139.7421998466978 56.6 35.66679655040438 139.74219844935476 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fc8b0a51-d292-45f7-957f-15deab8b1c83">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc8b0a51-d292-45f7-957f-15deab8b1c83">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc8b0a51-d292-45f7-957f-15deab8b1c83">
											<gml:posList>35.666770026269845 139.74220279839284 24.76 35.666794362300344 139.742201401061 24.76 35.666794362300344 139.742201401061 56.6 35.666770026269845 139.74220279839284 56.6 35.666770026269845 139.74220279839284 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5cb414f3-7ea9-4130-98de-aa5917b09050">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5cb414f3-7ea9-4130-98de-aa5917b09050">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5cb414f3-7ea9-4130-98de-aa5917b09050">
											<gml:posList>35.66694119677201 139.74220233876508 56.6 35.66694119677201 139.74220233876508 56.038 35.66692573887999 139.74220321790366 56.038 35.66692573887999 139.74220321790366 56.6 35.66694119677201 139.74220233876508 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aecdbedf-3dcf-4199-8873-c8caeb826d62">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aecdbedf-3dcf-4199-8873-c8caeb826d62">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aecdbedf-3dcf-4199-8873-c8caeb826d62">
											<gml:posList>35.66693827858102 139.7422053244436 48.5 35.66693827858102 139.7422053244436 24.76 35.66694359645502 139.742205020164 24.76 35.66694359645502 139.742205020164 56.6 35.66692813857134 139.74220591034782 56.6 35.66692813857134 139.74220591034782 48.5 35.66693827858102 139.7422053244436 48.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e9d8688e-555b-4aa6-8d25-3d07fe6cbb5b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e9d8688e-555b-4aa6-8d25-3d07fe6cbb5b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e9d8688e-555b-4aa6-8d25-3d07fe6cbb5b">
											<gml:posList>35.66679718504878 139.7422152271521 56.6 35.66679718504878 139.7422152271521 56.038 35.66679655040438 139.74219844935476 56.038 35.66679655040438 139.74219844935476 56.6 35.66679718504878 139.7422152271521 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b0a85c78-3070-4690-a2a0-68d7e34c57ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b0a85c78-3070-4690-a2a0-68d7e34c57ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b0a85c78-3070-4690-a2a0-68d7e34c57ec">
											<gml:posList>35.666849622315574 139.74220908134626 61.762 35.66687933931598 139.742207379664 61.762 35.66687933931598 139.742207379664 56.038 35.666849622315574 139.74220908134626 56.038 35.666849622315574 139.74220908134626 61.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1aefd9db-2afa-4157-b1ce-44a4fd3965d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1aefd9db-2afa-4157-b1ce-44a4fd3965d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1aefd9db-2afa-4157-b1ce-44a4fd3965d0">
											<gml:posList>35.666794362300344 139.742201401061 24.76 35.66679500595806 139.74221817884762 24.76 35.66679500595806 139.74221817884762 56.6 35.666794362300344 139.742201401061 56.6 35.666794362300344 139.742201401061 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d066539a-7faa-4314-8d54-3ea62692928b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d066539a-7faa-4314-8d54-3ea62692928b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d066539a-7faa-4314-8d54-3ea62692928b">
											<gml:posList>35.66684974187623 139.74221222925578 56.6 35.66684974187623 139.74221222925578 56.038 35.66684745248115 139.74221235336083 56.038 35.66684745248115 139.74221235336083 56.6 35.66684974187623 139.74221222925578 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f417eca0-60ab-4282-9dfd-25b03487f1ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f417eca0-60ab-4282-9dfd-25b03487f1ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f417eca0-60ab-4282-9dfd-25b03487f1ca">
											<gml:posList>35.66684745248115 139.74221235336083 56.6 35.66684745248115 139.74221235336083 56.038 35.66679718504878 139.7422152271521 56.038 35.66679718504878 139.7422152271521 56.6 35.66684745248115 139.74221235336083 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d95a4ead-ed93-47ec-9395-fe408209a5be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d95a4ead-ed93-47ec-9395-fe408209a5be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d95a4ead-ed93-47ec-9395-fe408209a5be">
											<gml:posList>35.66679500595806 139.74221817884762 24.76 35.66684985216397 139.74221503475687 24.76 35.66684985216397 139.74221503475687 56.6 35.66679500595806 139.74221817884762 56.6 35.66679500595806 139.74221817884762 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0d1ae567-e275-4005-8b68-4941649d0c2b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d1ae567-e275-4005-8b68-4941649d0c2b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d1ae567-e275-4005-8b68-4941649d0c2b">
											<gml:posList>35.66692573887999 139.74220321790366 56.6 35.66692573887999 139.74220321790366 56.038 35.66692683318575 139.74223185837764 56.038 35.66692683318575 139.74223185837764 56.6 35.66692573887999 139.74220321790366 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1ae1cb4d-57c5-4a8b-a28e-80c500d5315a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ae1cb4d-57c5-4a8b-a28e-80c500d5315a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ae1cb4d-57c5-4a8b-a28e-80c500d5315a">
											<gml:posList>35.666939584380124 139.74223948757464 24.76 35.66693827858102 139.7422053244436 24.76 35.66693827858102 139.7422053244436 48.5 35.666939584380124 139.74223948757464 48.5 35.666939584380124 139.74223948757464 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-df8ec68d-9321-449b-9de5-df0e79e824c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df8ec68d-9321-449b-9de5-df0e79e824c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df8ec68d-9321-449b-9de5-df0e79e824c7">
											<gml:posList>35.66692813857134 139.74220591034782 56.6 35.66692923286811 139.74223453977692 56.6 35.66692923286811 139.74223453977692 54.4 35.66692961921568 139.74224481191737 54.4 35.66692961921568 139.74224481191737 24.76 35.666929444370275 139.74224007347453 24.76 35.666929444370275 139.74224007347453 48.5 35.66692813857134 139.74220591034782 48.5 35.66692813857134 139.74220591034782 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-afe081b5-a766-426f-9d31-1543c62caaf5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-afe081b5-a766-426f-9d31-1543c62caaf5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-afe081b5-a766-426f-9d31-1543c62caaf5">
											<gml:posList>35.66692683318575 139.74223185837764 56.6 35.66692683318575 139.74223185837764 56.038 35.66690945544454 139.7422328391035 56.038 35.66690945544454 139.7422328391035 56.6 35.66692683318575 139.74223185837764 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4cd13fb2-a82e-4feb-9b9b-e17d72056978">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4cd13fb2-a82e-4feb-9b9b-e17d72056978">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4cd13fb2-a82e-4feb-9b9b-e17d72056978">
											<gml:posList>35.66687933931598 139.742207379664 61.762 35.66688132569871 139.74225948033964 61.762 35.66688132569871 139.74225948033964 56.038 35.66687933931598 139.742207379664 56.038 35.66687933931598 139.742207379664 61.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6f7d7f18-8725-499e-830e-ef1682626f0c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f7d7f18-8725-499e-830e-ef1682626f0c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f7d7f18-8725-499e-830e-ef1682626f0c">
											<gml:posList>35.66692923286811 139.74223453977692 54.4 35.66692923286811 139.74223453977692 56.6 35.66691185513524 139.742235531548 56.6 35.66691185513524 139.742235531548 54.4 35.66692923286811 139.74223453977692 54.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-19762ece-1692-4d42-b2f6-ac3d0671a61b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-19762ece-1692-4d42-b2f6-ac3d0671a61b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-19762ece-1692-4d42-b2f6-ac3d0671a61b">
											<gml:posList>35.666849622315574 139.74220908134626 61.762 35.666849622315574 139.74220908134626 56.038 35.66684974187623 139.74221222925578 56.038 35.66684974187623 139.74221222925578 56.6 35.66684985216397 139.74221503475687 56.6 35.66684985216397 139.74221503475687 24.76 35.66685160869755 139.7422611820027 24.76 35.66685160869755 139.7422611820027 61.762 35.666849622315574 139.74220908134626 61.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bc315bdc-e26e-48b1-92f7-529dd9646541">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc315bdc-e26e-48b1-92f7-529dd9646541">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc315bdc-e26e-48b1-92f7-529dd9646541">
											<gml:posList>35.666929444370275 139.74224007347453 24.76 35.666939584380124 139.74223948757464 24.76 35.666939584380124 139.74223948757464 48.5 35.666929444370275 139.74224007347453 48.5 35.666929444370275 139.74224007347453 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-efc5ded0-d9f6-4f3d-a0ed-7f651987cf3d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-efc5ded0-d9f6-4f3d-a0ed-7f651987cf3d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-efc5ded0-d9f6-4f3d-a0ed-7f651987cf3d">
											<gml:posList>35.666912250496445 139.74224580367598 24.76 35.66692961921568 139.74224481191737 24.76 35.66692961921568 139.74224481191737 54.4 35.666912250496445 139.74224580367598 54.4 35.666912250496445 139.74224580367598 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cb48ee06-e340-4af4-bfe4-90abb67967bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb48ee06-e340-4af4-bfe4-90abb67967bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb48ee06-e340-4af4-bfe4-90abb67967bd">
											<gml:posList>35.66690945544454 139.7422328391035 56.6 35.66690945544454 139.7422328391035 56.038 35.66691062339017 139.74226351191226 56.038 35.66691062339017 139.74226351191226 56.6 35.66690945544454 139.7422328391035 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f0ba701a-d486-4d0c-8527-e06d3766ff1f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f0ba701a-d486-4d0c-8527-e06d3766ff1f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f0ba701a-d486-4d0c-8527-e06d3766ff1f">
											<gml:posList>35.666913023071835 139.74226619331193 56.6 35.666913023071835 139.74226619331193 24.76 35.666912250496445 139.74224580367598 24.76 35.666912250496445 139.74224580367598 54.4 35.66691185513524 139.742235531548 54.4 35.66691185513524 139.742235531548 56.6 35.666913023071835 139.74226619331193 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a3732e60-c46e-4499-842b-35754907c079">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a3732e60-c46e-4499-842b-35754907c079">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a3732e60-c46e-4499-842b-35754907c079">
											<gml:posList>35.666871870698614 139.74226002127548 56.6 35.666871870698614 139.74226002127548 56.038 35.66688132569871 139.74225948033964 56.038 35.66688132569871 139.74225948033964 61.762 35.66685160869755 139.7422611820027 61.762 35.66685160869755 139.7422611820027 24.76 35.66686958131183 139.74226015642495 24.76 35.66686958131183 139.74226015642495 56.6 35.666871870698614 139.74226002127548 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6c539952-b1c6-4747-b8e5-bf412c3128d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c539952-b1c6-4747-b8e5-bf412c3128d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c539952-b1c6-4747-b8e5-bf412c3128d4">
											<gml:posList>35.66687198097688 139.74226281573164 56.6 35.66687198097688 139.74226281573164 56.038 35.666871870698614 139.74226002127548 56.038 35.666871870698614 139.74226002127548 56.6 35.66687198097688 139.74226281573164 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cbf81cd6-6024-4032-b74a-cc0c817f1538">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cbf81cd6-6024-4032-b74a-cc0c817f1538">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cbf81cd6-6024-4032-b74a-cc0c817f1538">
											<gml:posList>35.666872091338625 139.7422657206455 56.6 35.666872091338625 139.7422657206455 56.038 35.66687198097688 139.74226281573164 56.038 35.66687198097688 139.74226281573164 56.6 35.666872091338625 139.7422657206455 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-894ae5a0-1dd3-4801-a4fd-34997e9acebf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-894ae5a0-1dd3-4801-a4fd-34997e9acebf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-894ae5a0-1dd3-4801-a4fd-34997e9acebf">
											<gml:posList>35.66691062339017 139.74226351191226 56.6 35.66691062339017 139.74226351191226 56.038 35.666872091338625 139.7422657206455 56.038 35.666872091338625 139.7422657206455 56.6 35.66691062339017 139.74226351191226 56.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8cf22887-4257-4171-9c5a-6a99d2a1d16e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8cf22887-4257-4171-9c5a-6a99d2a1d16e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8cf22887-4257-4171-9c5a-6a99d2a1d16e">
											<gml:posList>35.666909868400566 139.74226637362713 47.75 35.666909868400566 139.74226637362713 24.76 35.666913023071835 139.74226619331193 24.76 35.666913023071835 139.74226619331193 56.6 35.666869912246696 139.74226867234245 56.6 35.666869912246696 139.74226867234245 47.75 35.666909868400566 139.74226637362713 47.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-71585931-85d1-4c9e-bbdd-53fe19dcbe26">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-71585931-85d1-4c9e-bbdd-53fe19dcbe26">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-71585931-85d1-4c9e-bbdd-53fe19dcbe26">
											<gml:posList>35.666869912246696 139.74226867234245 47.75 35.666869912246696 139.74226867234245 56.6 35.66686958131183 139.74226015642495 56.6 35.66686958131183 139.74226015642495 24.76 35.666871052657676 139.74229870451282 24.76 35.666871052657676 139.74229870451282 47.75 35.666869912246696 139.74226867234245 47.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f8462681-8ae3-4832-b5c1-e9d2a58d37f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f8462681-8ae3-4832-b5c1-e9d2a58d37f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f8462681-8ae3-4832-b5c1-e9d2a58d37f4">
											<gml:posList>35.66691101783421 139.742296416848 24.76 35.666909868400566 139.74226637362713 24.76 35.666909868400566 139.74226637362713 47.75 35.66691101783421 139.742296416848 47.75 35.66691101783421 139.742296416848 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cac83495-c4ee-44c2-92bf-a389c3d78576">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cac83495-c4ee-44c2-92bf-a389c3d78576">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cac83495-c4ee-44c2-92bf-a389c3d78576">
											<gml:posList>35.666871052657676 139.74229870451282 24.76 35.66691101783421 139.742296416848 24.76 35.66691101783421 139.742296416848 47.75 35.666871052657676 139.74229870451282 47.75 35.666871052657676 139.74229870451282 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-146</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">510.7098</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">6</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>