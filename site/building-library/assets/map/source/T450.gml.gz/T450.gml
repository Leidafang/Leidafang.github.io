<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_83b7a5a2-e050-4c8b-8653-eba8e754fc06">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">17.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67123056266792 139.7410083873343 0 35.67122764527968 139.74101237843556 0 35.671211894057556 139.74099509795118 0 35.67116474766398 139.7410596630367 0 35.67126485710944 139.74116945931533 0 35.671314920943885 139.74110089206494 0 35.67123056266792 139.7410083873343 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67123056266792 139.7410083873343 8.493 35.671314920943885 139.74110089206494 8.493 35.67126485710944 139.74116945931533 8.493 35.67116474766398 139.7410596630367 8.493 35.671211894057556 139.74099509795118 8.493 35.67122764527968 139.74101237843556 8.493 35.67123056266792 139.7410083873343 8.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67123056266792 139.7410083873343 8.493 35.67122764527968 139.74101237843556 8.493 35.67122764527968 139.74101237843556 25.520000000000003 35.67123056266792 139.7410083873343 25.520000000000003 35.67123056266792 139.7410083873343 8.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67122764527968 139.74101237843556 8.493 35.671211894057556 139.74099509795118 8.493 35.671211894057556 139.74099509795118 25.520000000000003 35.67122764527968 139.74101237843556 25.520000000000003 35.67122764527968 139.74101237843556 8.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671211894057556 139.74099509795118 8.493 35.67116474766398 139.7410596630367 8.493 35.67116474766398 139.7410596630367 25.520000000000003 35.671211894057556 139.74099509795118 25.520000000000003 35.671211894057556 139.74099509795118 8.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67116474766398 139.7410596630367 8.493 35.67126485710944 139.74116945931533 8.493 35.67126485710944 139.74116945931533 25.520000000000003 35.67116474766398 139.7410596630367 25.520000000000003 35.67116474766398 139.7410596630367 8.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67126485710944 139.74116945931533 8.493 35.671314920943885 139.74110089206494 8.493 35.671314920943885 139.74110089206494 25.520000000000003 35.67126485710944 139.74116945931533 25.520000000000003 35.67126485710944 139.74116945931533 8.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671314920943885 139.74110089206494 8.493 35.67123056266792 139.7410083873343 8.493 35.67123056266792 139.7410083873343 25.520000000000003 35.671314920943885 139.74110089206494 25.520000000000003 35.671314920943885 139.74110089206494 8.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67123056266792 139.7410083873343 25.520000000000003 35.67122764527968 139.74101237843556 25.520000000000003 35.671211894057556 139.74099509795118 25.520000000000003 35.67116474766398 139.7410596630367 25.520000000000003 35.67126485710944 139.74116945931533 25.520000000000003 35.671314920943885 139.74110089206494 25.520000000000003 35.67123056266792 139.7410083873343 25.520000000000003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-4b8ebf96-c7e9-4ff4-a9fd-5c3238f91439"/>
							<gml:surfaceMember xlink:href="#poly-3a1817b1-4c67-4e9c-8aba-23fd7e669092"/>
							<gml:surfaceMember xlink:href="#poly-e1077324-80e8-4f7b-828d-f632eeb4199c"/>
							<gml:surfaceMember xlink:href="#poly-b0ef3860-6155-4b2d-8f22-0a9a0e4c0ec1"/>
							<gml:surfaceMember xlink:href="#poly-8a688c11-2b40-4828-9c7b-b25dd1ac376a"/>
							<gml:surfaceMember xlink:href="#poly-68a705e7-eecc-4130-a48b-2ec9d66cf7b0"/>
							<gml:surfaceMember xlink:href="#poly-b9e7ddc5-7c4c-4293-9805-7460d3a8483c"/>
							<gml:surfaceMember xlink:href="#poly-4db4ed04-9b60-4927-8e0c-0200d5514a26"/>
							<gml:surfaceMember xlink:href="#poly-c509da2a-c54a-4dc3-b075-359d221d3015"/>
							<gml:surfaceMember xlink:href="#poly-3f662b5c-6d08-48f9-8716-2cea827a80e5"/>
							<gml:surfaceMember xlink:href="#poly-0ac0474f-c32f-47e8-8d91-ca32a317d7b3"/>
							<gml:surfaceMember xlink:href="#poly-b50d6fff-9d75-4808-b1c9-f017f700419d"/>
							<gml:surfaceMember xlink:href="#poly-2b7cdc1d-6cb6-4ce3-865d-7ed934aa0726"/>
							<gml:surfaceMember xlink:href="#poly-11c155b7-9a8c-4ad1-bf32-837c3b3ea5e7"/>
							<gml:surfaceMember xlink:href="#poly-396d6c26-a335-444b-a345-385ad05161a5"/>
							<gml:surfaceMember xlink:href="#poly-6a419dd8-5a23-4414-b31e-97fd5613e951"/>
							<gml:surfaceMember xlink:href="#poly-45d80877-9b7d-42ee-b99a-a07a8a647c3b"/>
							<gml:surfaceMember xlink:href="#poly-eb1a6d29-da02-42f7-8672-9784a5a6e6f5"/>
							<gml:surfaceMember xlink:href="#poly-3be84f81-bdd0-44aa-a637-89cb15e6ff6d"/>
							<gml:surfaceMember xlink:href="#poly-8bc4a8e1-17ee-4e55-9d5a-fd12a0308a63"/>
							<gml:surfaceMember xlink:href="#poly-99cd9ebe-0245-4d8f-b786-b5c8830085e6"/>
							<gml:surfaceMember xlink:href="#poly-85e15423-a600-4e02-b649-92b52e8efe37"/>
							<gml:surfaceMember xlink:href="#poly-edab8a5b-7eeb-4769-8709-f3f5f87a6be3"/>
							<gml:surfaceMember xlink:href="#poly-9965cb5c-1136-411a-a8a9-efeb76c7ed87"/>
							<gml:surfaceMember xlink:href="#poly-ab9e5542-b0f6-4ccd-aed3-26bb210f35e9"/>
							<gml:surfaceMember xlink:href="#poly-0d1092c2-ecba-4046-90b8-4c3778d1ddbe"/>
							<gml:surfaceMember xlink:href="#poly-d50cf904-e19c-482f-b13f-9fed978f6b01"/>
							<gml:surfaceMember xlink:href="#poly-9f07243d-10b0-4f92-80e6-f3a8bfb23a2a"/>
							<gml:surfaceMember xlink:href="#poly-9e36ca2f-d321-4929-861d-a2fb48eaf140"/>
							<gml:surfaceMember xlink:href="#poly-31711d7c-5888-439b-b3ed-21585f8278f4"/>
							<gml:surfaceMember xlink:href="#poly-e1283dd6-7489-437a-ae41-8354734d00e1"/>
							<gml:surfaceMember xlink:href="#poly-ccf3be73-7d51-4caa-9724-3e5a2ac4d8bc"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_83b7a5a2-e050-4c8b-8653-eba8e754fc06_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24fce23c-c69c-4875-822c-614e7514b3d5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671194497861975 139.74105428235328 30.728 35.67118783460701 139.74106329281466 30.728 35.671179751430316 139.7410543214187 30.728 35.67118641468461 139.74104531095747 30.728 35.671194497861975 139.74105428235328 30.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b6a4144-41bb-46eb-b137-f4366928d69c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5b6a4144-41bb-46eb-b137-f4366928d69c_0">
											<gml:posList>35.67118641468461 139.74104531095747 30.728 35.67118641468461 139.74104531095747 34.423 35.671194497861975 139.74105428235328 34.423 35.671194497861975 139.74105428235328 30.728 35.67118641468461 139.74104531095747 30.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8769c40f-eda7-4acb-bac8-f7cf3d8cf414">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8769c40f-eda7-4acb-bac8-f7cf3d8cf414_0">
											<gml:posList>35.671179751430316 139.7410543214187 30.728 35.671179751430316 139.7410543214187 34.423 35.67118641468461 139.74104531095747 34.423 35.67118641468461 139.74104531095747 30.728 35.671179751430316 139.7410543214187 30.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a9173e6-149d-494f-88f8-e75d9ec72ef8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2a9173e6-149d-494f-88f8-e75d9ec72ef8_0">
											<gml:posList>35.671194497861975 139.74105428235328 34.423 35.67118641468461 139.74104531095747 34.423 35.671179751430316 139.7410543214187 34.423 35.67118783460701 139.74106329281466 34.423 35.671194497861975 139.74105428235328 34.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97d9b792-9846-4a5e-92d4-87203151ad5f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-97d9b792-9846-4a5e-92d4-87203151ad5f_0">
											<gml:posList>35.671194497861975 139.74105428235328 30.728 35.671194497861975 139.74105428235328 34.423 35.67118783460701 139.74106329281466 34.423 35.67118783460701 139.74106329281466 30.728 35.671194497861975 139.74105428235328 30.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c4e081d-db98-407a-8ff5-526de99879b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6c4e081d-db98-407a-8ff5-526de99879b1_0">
											<gml:posList>35.67118783460701 139.74106329281466 30.728 35.67118783460701 139.74106329281466 34.423 35.671179751430316 139.7410543214187 34.423 35.671179751430316 139.7410543214187 30.728 35.67118783460701 139.74106329281466 30.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-4b8ebf96-c7e9-4ff4-a9fd-5c3238f91439">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b8ebf96-c7e9-4ff4-a9fd-5c3238f91439">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b8ebf96-c7e9-4ff4-a9fd-5c3238f91439">
											<gml:posList>35.671164747664 139.7410596630367 8.493 35.671211894057535 139.74099509795116 8.493 35.67122764527964 139.74101237843558 8.493 35.67123056266792 139.74100838733426 8.493 35.67131492094388 139.7411008920649 8.493 35.671264857109435 139.74116945931533 8.493 35.671164747664 139.7410596630367 8.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3a1817b1-4c67-4e9c-8aba-23fd7e669092">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a1817b1-4c67-4e9c-8aba-23fd7e669092">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a1817b1-4c67-4e9c-8aba-23fd7e669092">
											<gml:posList>35.67122764527964 139.74101237843558 26.383 35.671211894057535 139.74099509795116 26.383 35.67121219677906 139.74100196844725 26.383 35.67122794800019 139.74101924893304 26.383 35.67122764527964 139.74101237843558 26.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e1077324-80e8-4f7b-828d-f632eeb4199c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e1077324-80e8-4f7b-828d-f632eeb4199c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e1077324-80e8-4f7b-828d-f632eeb4199c">
											<gml:posList>35.67121219677906 139.74100196844725 26.383 35.671211894057535 139.74099509795116 26.383 35.67118882510008 139.74102668400153 26.383 35.67119177506813 139.741029917192 26.383 35.67121219677906 139.74100196844725 26.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b0ef3860-6155-4b2d-8f22-0a9a0e4c0ec1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b0ef3860-6155-4b2d-8f22-0a9a0e4c0ec1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b0ef3860-6155-4b2d-8f22-0a9a0e4c0ec1">
											<gml:posList>35.67122764527964 139.74101237843558 26.383 35.67122794800019 139.74101924893304 26.383 35.67123086538023 139.7410152467856 26.383 35.67123056266792 139.74100838733426 26.383 35.67122764527964 139.74101237843558 26.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8a688c11-2b40-4828-9c7b-b25dd1ac376a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a688c11-2b40-4828-9c7b-b25dd1ac376a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a688c11-2b40-4828-9c7b-b25dd1ac376a">
											<gml:posList>35.67123056266792 139.74100838733426 26.383 35.67123086538023 139.7410152467856 26.383 35.67127363541853 139.74106214466372 26.383 35.67127923265178 139.741061762645 26.383 35.67123056266792 139.74100838733426 26.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-68a705e7-eecc-4130-a48b-2ec9d66cf7b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-68a705e7-eecc-4130-a48b-2ec9d66cf7b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-68a705e7-eecc-4130-a48b-2ec9d66cf7b0">
											<gml:posList>35.67118882510008 139.74102668400153 31.148 35.67118906359759 139.74103208540234 31.148 35.67120358790699 139.74104800859746 31.148 35.67120799538827 139.74104770527214 31.148 35.67118882510008 139.74102668400153 31.148</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b9e7ddc5-7c4c-4293-9805-7460d3a8483c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b9e7ddc5-7c4c-4293-9805-7460d3a8483c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b9e7ddc5-7c4c-4293-9805-7460d3a8483c">
											<gml:posList>35.671164747664 139.7410596630367 31.148 35.67116914613162 139.74105935972258 31.148 35.67118906359759 139.74103208540234 31.148 35.67118882510008 139.74102668400153 31.148 35.671164747664 139.7410596630367 31.148</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4db4ed04-9b60-4927-8e0c-0200d5514a26">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4db4ed04-9b60-4927-8e0c-0200d5514a26">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4db4ed04-9b60-4927-8e0c-0200d5514a26">
											<gml:posList>35.67120358790699 139.74104800859746 30.728 35.67118906359759 139.74103208540234 30.728 35.67116914613162 139.74105935972258 30.728 35.6711836614322 139.74107529397543 30.728 35.67120358790699 139.74104800859746 30.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c509da2a-c54a-4dc3-b075-359d221d3015">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c509da2a-c54a-4dc3-b075-359d221d3015">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c509da2a-c54a-4dc3-b075-359d221d3015">
											<gml:posList>35.67122884810611 139.7411234704583 25.845 35.67127363541853 139.74106214466372 25.845 35.67123086538023 139.7410152467856 25.845 35.67122794800019 139.74101924893304 25.845 35.67121219677906 139.74100196844725 25.845 35.67119177506813 139.741029917192 25.845 35.67120799538827 139.74104770527214 25.845 35.67118655619948 139.74107706911008 25.845 35.67122884810611 139.7411234704583 25.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3f662b5c-6d08-48f9-8716-2cea827a80e5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f662b5c-6d08-48f9-8716-2cea827a80e5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f662b5c-6d08-48f9-8716-2cea827a80e5">
											<gml:posList>35.67120799538827 139.74104770527214 31.148 35.67120358790699 139.74104800859746 31.148 35.6711836614322 139.74107529397543 31.148 35.6711839089328 139.7410806843193 31.148 35.67120799538827 139.74104770527214 31.148</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0ac0474f-c32f-47e8-8d91-ca32a317d7b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ac0474f-c32f-47e8-8d91-ca32a317d7b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ac0474f-c32f-47e8-8d91-ca32a317d7b3">
											<gml:posList>35.6711839089328 139.7410806843193 31.148 35.6711836614322 139.74107529397543 31.148 35.67116914613162 139.74105935972258 31.148 35.671164747664 139.7410596630367 31.148 35.6711839089328 139.7410806843193 31.148</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b50d6fff-9d75-4808-b1c9-f017f700419d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b50d6fff-9d75-4808-b1c9-f017f700419d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b50d6fff-9d75-4808-b1c9-f017f700419d">
											<gml:posList>35.67127923265178 139.741061762645 26.383 35.67127363541853 139.74106214466372 26.383 35.67122884810611 139.7411234704583 26.383 35.67122916883085 139.74113031884283 26.383 35.67127923265178 139.741061762645 26.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2b7cdc1d-6cb6-4ce3-865d-7ed934aa0726">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b7cdc1d-6cb6-4ce3-865d-7ed934aa0726">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b7cdc1d-6cb6-4ce3-865d-7ed934aa0726">
											<gml:posList>35.67122884810611 139.7411234704583 26.383 35.67118655619948 139.74107706911008 26.383 35.6711839089328 139.7410806843193 26.383 35.67122916883085 139.74113031884283 26.383 35.67122884810611 139.7411234704583 26.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-11c155b7-9a8c-4ad1-bf32-837c3b3ea5e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11c155b7-9a8c-4ad1-bf32-837c3b3ea5e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11c155b7-9a8c-4ad1-bf32-837c3b3ea5e7">
											<gml:posList>35.67122916883085 139.74113031884283 26.383 35.671264857109435 139.74116945931533 17.838 35.67131492094388 139.7411008920649 17.838 35.67127923265178 139.741061762645 26.383 35.67122916883085 139.74113031884283 26.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-396d6c26-a335-444b-a345-385ad05161a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-396d6c26-a335-444b-a345-385ad05161a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-396d6c26-a335-444b-a345-385ad05161a5">
											<gml:posList>35.671211894057535 139.74099509795116 8.493 35.671164747664 139.7410596630367 8.493 35.671164747664 139.7410596630367 31.148 35.67118882510008 139.74102668400153 31.148 35.67118882510008 139.74102668400153 26.383 35.671211894057535 139.74099509795116 26.383 35.671211894057535 139.74099509795116 8.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6a419dd8-5a23-4414-b31e-97fd5613e951">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a419dd8-5a23-4414-b31e-97fd5613e951">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a419dd8-5a23-4414-b31e-97fd5613e951">
											<gml:posList>35.67123086538023 139.7410152467856 26.383 35.67123086538023 139.7410152467856 25.845 35.67127363541853 139.74106214466372 25.845 35.67127363541853 139.74106214466372 26.383 35.67123086538023 139.7410152467856 26.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-45d80877-9b7d-42ee-b99a-a07a8a647c3b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45d80877-9b7d-42ee-b99a-a07a8a647c3b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45d80877-9b7d-42ee-b99a-a07a8a647c3b">
											<gml:posList>35.67116914613162 139.74105935972258 31.148 35.67116914613162 139.74105935972258 30.728 35.67118906359759 139.74103208540234 30.728 35.67118906359759 139.74103208540234 31.148 35.67116914613162 139.74105935972258 31.148</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eb1a6d29-da02-42f7-8672-9784a5a6e6f5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eb1a6d29-da02-42f7-8672-9784a5a6e6f5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eb1a6d29-da02-42f7-8672-9784a5a6e6f5">
											<gml:posList>35.67122884810611 139.7411234704583 26.383 35.67122884810611 139.7411234704583 25.845 35.67118655619948 139.74107706911008 25.845 35.67118655619948 139.74107706911008 26.383 35.67122884810611 139.7411234704583 26.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3be84f81-bdd0-44aa-a637-89cb15e6ff6d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3be84f81-bdd0-44aa-a637-89cb15e6ff6d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3be84f81-bdd0-44aa-a637-89cb15e6ff6d">
											<gml:posList>35.6711836614322 139.74107529397543 31.148 35.6711836614322 139.74107529397543 30.728 35.67116914613162 139.74105935972258 30.728 35.67116914613162 139.74105935972258 31.148 35.6711836614322 139.74107529397543 31.148</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8bc4a8e1-17ee-4e55-9d5a-fd12a0308a63">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8bc4a8e1-17ee-4e55-9d5a-fd12a0308a63">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8bc4a8e1-17ee-4e55-9d5a-fd12a0308a63">
											<gml:posList>35.6711839089328 139.7410806843193 31.148 35.6711839089328 139.7410806843193 26.383 35.67118655619948 139.74107706911008 26.383 35.67118655619948 139.74107706911008 25.845 35.67120799538827 139.74104770527214 25.845 35.67120799538827 139.74104770527214 31.148 35.6711839089328 139.7410806843193 31.148</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-99cd9ebe-0245-4d8f-b786-b5c8830085e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-99cd9ebe-0245-4d8f-b786-b5c8830085e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-99cd9ebe-0245-4d8f-b786-b5c8830085e6">
											<gml:posList>35.67118906359759 139.74103208540234 31.148 35.67118906359759 139.74103208540234 30.728 35.67120358790699 139.74104800859746 30.728 35.67120358790699 139.74104800859746 31.148 35.67118906359759 139.74103208540234 31.148</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-85e15423-a600-4e02-b649-92b52e8efe37">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85e15423-a600-4e02-b649-92b52e8efe37">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85e15423-a600-4e02-b649-92b52e8efe37">
											<gml:posList>35.67119177506813 139.741029917192 26.383 35.67118882510008 139.74102668400153 26.383 35.67118882510008 139.74102668400153 31.148 35.67120799538827 139.74104770527214 31.148 35.67120799538827 139.74104770527214 25.845 35.67119177506813 139.741029917192 25.845 35.67119177506813 139.741029917192 26.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-edab8a5b-7eeb-4769-8709-f3f5f87a6be3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-edab8a5b-7eeb-4769-8709-f3f5f87a6be3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-edab8a5b-7eeb-4769-8709-f3f5f87a6be3">
											<gml:posList>35.67119177506813 139.741029917192 26.383 35.67119177506813 139.741029917192 25.845 35.67121219677906 139.74100196844725 25.845 35.67121219677906 139.74100196844725 26.383 35.67119177506813 139.741029917192 26.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9965cb5c-1136-411a-a8a9-efeb76c7ed87">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9965cb5c-1136-411a-a8a9-efeb76c7ed87">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9965cb5c-1136-411a-a8a9-efeb76c7ed87">
											<gml:posList>35.671164747664 139.7410596630367 8.493 35.671264857109435 139.74116945931533 8.493 35.671264857109435 139.74116945931533 17.838 35.67122916883085 139.74113031884283 26.383 35.6711839089328 139.7410806843193 26.383 35.6711839089328 139.7410806843193 31.148 35.671164747664 139.7410596630367 31.148 35.671164747664 139.7410596630367 8.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ab9e5542-b0f6-4ccd-aed3-26bb210f35e9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab9e5542-b0f6-4ccd-aed3-26bb210f35e9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab9e5542-b0f6-4ccd-aed3-26bb210f35e9">
											<gml:posList>35.67122764527964 139.74101237843558 8.493 35.671211894057535 139.74099509795116 8.493 35.671211894057535 139.74099509795116 26.383 35.67122764527964 139.74101237843558 26.383 35.67122764527964 139.74101237843558 8.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0d1092c2-ecba-4046-90b8-4c3778d1ddbe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d1092c2-ecba-4046-90b8-4c3778d1ddbe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d1092c2-ecba-4046-90b8-4c3778d1ddbe">
											<gml:posList>35.67121219677906 139.74100196844725 26.383 35.67121219677906 139.74100196844725 25.845 35.67122794800019 139.74101924893304 25.845 35.67122794800019 139.74101924893304 26.383 35.67121219677906 139.74100196844725 26.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d50cf904-e19c-482f-b13f-9fed978f6b01">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d50cf904-e19c-482f-b13f-9fed978f6b01">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d50cf904-e19c-482f-b13f-9fed978f6b01">
											<gml:posList>35.67123056266792 139.74100838733426 8.493 35.67122764527964 139.74101237843558 8.493 35.67122764527964 139.74101237843558 26.383 35.67123056266792 139.74100838733426 26.383 35.67123056266792 139.74100838733426 8.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9f07243d-10b0-4f92-80e6-f3a8bfb23a2a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f07243d-10b0-4f92-80e6-f3a8bfb23a2a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f07243d-10b0-4f92-80e6-f3a8bfb23a2a">
											<gml:posList>35.67122794800019 139.74101924893304 26.383 35.67122794800019 139.74101924893304 25.845 35.67123086538023 139.7410152467856 25.845 35.67123086538023 139.7410152467856 26.383 35.67122794800019 139.74101924893304 26.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9e36ca2f-d321-4929-861d-a2fb48eaf140">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e36ca2f-d321-4929-861d-a2fb48eaf140">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e36ca2f-d321-4929-861d-a2fb48eaf140">
											<gml:posList>35.67127363541853 139.74106214466372 26.383 35.67127363541853 139.74106214466372 25.845 35.67122884810611 139.7411234704583 25.845 35.67122884810611 139.7411234704583 26.383 35.67127363541853 139.74106214466372 26.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-31711d7c-5888-439b-b3ed-21585f8278f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31711d7c-5888-439b-b3ed-21585f8278f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31711d7c-5888-439b-b3ed-21585f8278f4">
											<gml:posList>35.67123056266792 139.74100838733426 26.383 35.67127923265178 139.741061762645 26.383 35.67131492094388 139.7411008920649 17.838 35.67131492094388 139.7411008920649 8.493 35.67123056266792 139.74100838733426 8.493 35.67123056266792 139.74100838733426 26.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e1283dd6-7489-437a-ae41-8354734d00e1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e1283dd6-7489-437a-ae41-8354734d00e1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e1283dd6-7489-437a-ae41-8354734d00e1">
											<gml:posList>35.671264857109435 139.74116945931533 8.493 35.67131492094388 139.7411008920649 8.493 35.67131492094388 139.7411008920649 17.838 35.671264857109435 139.74116945931533 17.838 35.671264857109435 139.74116945931533 8.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ccf3be73-7d51-4caa-9724-3e5a2ac4d8bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ccf3be73-7d51-4caa-9724-3e5a2ac4d8bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ccf3be73-7d51-4caa-9724-3e5a2ac4d8bc">
											<gml:posList>35.67120358790699 139.74104800859746 31.148 35.67120358790699 139.74104800859746 30.728 35.6711836614322 139.74107529397543 30.728 35.6711836614322 139.74107529397543 31.148 35.67120358790699 139.74104800859746 31.148</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10868</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">139.40424</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>