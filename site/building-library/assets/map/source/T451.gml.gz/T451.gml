<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_841126d9-3891-4b33-b2e0-7461c68ebec4">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">10.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67096638608193 139.7402911986062 0 35.67104396381218 139.74036843303506 0 35.671115539442766 139.7402603166337 0 35.671037871592375 139.74018319280893 0 35.67096638608193 139.7402911986062 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67096638608193 139.7402911986062 11.77 35.671037871592375 139.74018319280893 11.77 35.671115539442766 139.7402603166337 11.77 35.67104396381218 139.74036843303506 11.77 35.67096638608193 139.7402911986062 11.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67096638608193 139.7402911986062 11.77 35.67104396381218 139.74036843303506 11.77 35.67104396381218 139.74036843303506 21.89 35.67096638608193 139.7402911986062 21.89 35.67096638608193 139.7402911986062 11.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67104396381218 139.74036843303506 11.77 35.671115539442766 139.7402603166337 11.77 35.671115539442766 139.7402603166337 21.89 35.67104396381218 139.74036843303506 21.89 35.67104396381218 139.74036843303506 11.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671115539442766 139.7402603166337 11.77 35.671037871592375 139.74018319280893 11.77 35.671037871592375 139.74018319280893 21.89 35.671115539442766 139.7402603166337 21.89 35.671115539442766 139.7402603166337 11.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671037871592375 139.74018319280893 11.77 35.67096638608193 139.7402911986062 11.77 35.67096638608193 139.7402911986062 21.89 35.671037871592375 139.74018319280893 21.89 35.671037871592375 139.74018319280893 11.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67096638608193 139.7402911986062 21.89 35.67104396381218 139.74036843303506 21.89 35.671115539442766 139.7402603166337 21.89 35.671037871592375 139.74018319280893 21.89 35.67096638608193 139.7402911986062 21.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-630f3b9b-451f-4e85-b7cd-d0d01205c6a2"/>
							<gml:surfaceMember xlink:href="#poly-7faa5d5a-5e51-4509-b441-3371b4904e96"/>
							<gml:surfaceMember xlink:href="#poly-ec478dca-a7d5-4666-9f04-cad28a573bb5"/>
							<gml:surfaceMember xlink:href="#poly-814abc47-6196-42b4-9686-966cde5dd61c"/>
							<gml:surfaceMember xlink:href="#poly-bfce6e7e-eda6-4347-8a51-7e3e91b42baa"/>
							<gml:surfaceMember xlink:href="#poly-3e5ff04f-36ae-432c-a99a-e87da7bb9c01"/>
							<gml:surfaceMember xlink:href="#poly-52405ecc-6b32-4896-87d0-9353db3753f7"/>
							<gml:surfaceMember xlink:href="#poly-1dbfbc40-b63c-49be-9736-65a7d997dbe1"/>
							<gml:surfaceMember xlink:href="#poly-18011a73-4135-48c7-a5b6-a42542ea6c32"/>
							<gml:surfaceMember xlink:href="#poly-7902785e-6edb-407a-937f-fe600b511e6a"/>
							<gml:surfaceMember xlink:href="#poly-b86268f2-af6e-4f06-b249-4111b97e914f"/>
							<gml:surfaceMember xlink:href="#poly-02ff606b-ed0c-441c-8e36-b935dd2c6bfa"/>
							<gml:surfaceMember xlink:href="#poly-486703f3-e567-4fd4-ab79-d327e1f3469b"/>
							<gml:surfaceMember xlink:href="#poly-94c16b93-e482-474d-bc41-1c0ca6d2f1bc"/>
							<gml:surfaceMember xlink:href="#poly-4bce0827-3b55-44a9-89a6-4b9628d764ce"/>
							<gml:surfaceMember xlink:href="#poly-7e618c44-bff6-4d8a-bf8b-82af1556edd3"/>
							<gml:surfaceMember xlink:href="#poly-35fc4fab-2879-4e41-a603-310d837e0672"/>
							<gml:surfaceMember xlink:href="#poly-7ca27174-b3c4-4c33-a07e-6976cac7a210"/>
							<gml:surfaceMember xlink:href="#poly-c6d5ea16-ab5a-4f4f-b6d3-ecb063abee4d"/>
							<gml:surfaceMember xlink:href="#poly-0f9a1d5d-f126-4f82-9264-6a7f29054917"/>
							<gml:surfaceMember xlink:href="#poly-e470cf53-5864-4977-9d83-5be092983be0"/>
							<gml:surfaceMember xlink:href="#poly-2c7e7cd1-8c97-4917-b653-b90549596645"/>
							<gml:surfaceMember xlink:href="#poly-547b1925-551c-449e-b650-070b40f38a4d"/>
							<gml:surfaceMember xlink:href="#poly-2ca66212-619e-4cb8-be47-dcee749bf717"/>
							<gml:surfaceMember xlink:href="#poly-87c63084-4d56-41d5-9eed-93154c31af61"/>
							<gml:surfaceMember xlink:href="#poly-5d3b4b01-6d84-4c12-b2c6-e3a67527f5e4"/>
							<gml:surfaceMember xlink:href="#poly-5f29b76f-d15f-4dc4-b380-7f1000151734"/>
							<gml:surfaceMember xlink:href="#poly-396d6253-1592-43a1-847d-be62bd373dae"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_841126d9-3891-4b33-b2e0-7461c68ebec4_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b34bc02-80e8-403b-ad3f-9bd291b6b6d9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671033648342636 139.74029353970028 23.22 35.67105141171449 139.74026673168342 23.22 35.67106643112868 139.7402816820587 23.22 35.67104865873982 139.74030849008778 23.22 35.671033648342636 139.74029353970028 23.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a00128d2-9d5c-4c20-9549-ecd559a5d18c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67104940364751 139.74032764359723 23.22 35.67106519530058 139.740303787247 23.22 35.67107595695681 139.74031450077095 23.22 35.671060390806794 139.74033856674143 23.22 35.67104940364751 139.74032764359723 23.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8f27b49-48ab-40c5-8173-56b6da9908a1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671060390806794 139.74033856674143 23.506 35.67107595695681 139.74031450077095 23.506 35.67107658840373 139.74031512968062 23.506 35.67106079673992 139.7403389749857 23.506 35.671060390806794 139.74033856674143 23.506</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-92b9b391-7660-4ba1-b19d-0615b5c56991">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671068634531 139.74029859146984 23.22 35.67108537151772 139.74027330903093 23.22 35.671095862543055 139.74028373566225 23.22 35.671079351076415 139.74030924981415 23.22 35.671068634531 139.74029859146984 23.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f606ddc-dfbf-4194-b7bd-998f03b52367">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671079351076415 139.74030924981415 23.506 35.671095862543055 139.74028373566225 23.506 35.671096773628896 139.74028464040626 23.506 35.671080027626104 139.74030992285688 23.506 35.671079351076415 139.74030924981415 23.506</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3fc465b9-e9ac-492b-99cd-a3288290214c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3fc465b9-e9ac-492b-99cd-a3288290214c_0">
											<gml:posList>35.67105141171449 139.74026673168342 23.22 35.67105141171449 139.74026673168342 24.377 35.67106643112868 139.7402816820587 24.377 35.67106643112868 139.7402816820587 23.22 35.67105141171449 139.74026673168342 23.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f09d41d9-03e2-42ba-bc70-dbeb59abfe62">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f09d41d9-03e2-42ba-bc70-dbeb59abfe62_0">
											<gml:posList>35.67108537151772 139.74027330903093 23.22 35.67108537151772 139.74027330903093 24.039 35.671096773628896 139.74028464040626 24.039 35.671096773628896 139.74028464040626 23.506 35.671095862543055 139.74028373566225 23.506 35.671095862543055 139.74028373566225 23.22 35.67108537151772 139.74027330903093 23.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-828ad065-e209-4326-a508-53b272c9473d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-828ad065-e209-4326-a508-53b272c9473d_0">
											<gml:posList>35.671033648342636 139.74029353970028 23.22 35.671033648342636 139.74029353970028 24.377 35.67105141171449 139.74026673168342 24.377 35.67105141171449 139.74026673168342 23.22 35.671033648342636 139.74029353970028 23.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a67d055b-3e38-4a88-9e39-78ef9e7ca4ac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a67d055b-3e38-4a88-9e39-78ef9e7ca4ac_0">
											<gml:posList>35.67108537151772 139.74027330903093 23.22 35.671068634531 139.74029859146984 23.22 35.671068634531 139.74029859146984 24.039 35.67108537151772 139.74027330903093 24.039 35.67108537151772 139.74027330903093 23.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-88562f29-8a6d-406e-ac25-0c9f8e7b1592">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-88562f29-8a6d-406e-ac25-0c9f8e7b1592_0">
											<gml:posList>35.67106643112868 139.7402816820587 24.377 35.67105141171449 139.74026673168342 24.377 35.671033648342636 139.74029353970028 24.377 35.67104865873982 139.74030849008778 24.377 35.67106643112868 139.7402816820587 24.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a75115f0-8440-434f-8b4a-c23eccc8996f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a75115f0-8440-434f-8b4a-c23eccc8996f_0">
											<gml:posList>35.671096773628896 139.74028464040626 24.039 35.67108537151772 139.74027330903093 24.039 35.671068634531 139.74029859146984 24.039 35.671080027626104 139.74030992285688 24.039 35.671096773628896 139.74028464040626 24.039</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad660763-6ebf-48ae-a43d-dfa7b07e68d2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ad660763-6ebf-48ae-a43d-dfa7b07e68d2_0">
											<gml:posList>35.67104865873982 139.74030849008778 23.22 35.67106643112868 139.7402816820587 23.22 35.67106643112868 139.7402816820587 24.377 35.67104865873982 139.74030849008778 24.377 35.67104865873982 139.74030849008778 23.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-96e61a89-9dca-49e2-bfbf-b444a3dfcc2e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-96e61a89-9dca-49e2-bfbf-b444a3dfcc2e_0">
											<gml:posList>35.671095862543055 139.74028373566225 23.22 35.671095862543055 139.74028373566225 23.506 35.671079351076415 139.74030924981415 23.506 35.671079351076415 139.74030924981415 23.22 35.671095862543055 139.74028373566225 23.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d94c3b2-b601-4585-b56f-66ad8cf97d5b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8d94c3b2-b601-4585-b56f-66ad8cf97d5b_0">
											<gml:posList>35.671080027626104 139.74030992285688 23.506 35.671096773628896 139.74028464040626 23.506 35.671096773628896 139.74028464040626 24.039 35.671080027626104 139.74030992285688 24.039 35.671080027626104 139.74030992285688 23.506</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-edaafc4e-ad0c-4cd1-8bef-8a0ca493279f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-edaafc4e-ad0c-4cd1-8bef-8a0ca493279f_0">
											<gml:posList>35.67104865873982 139.74030849008778 23.22 35.67104865873982 139.74030849008778 24.377 35.671033648342636 139.74029353970028 24.377 35.671033648342636 139.74029353970028 23.22 35.67104865873982 139.74030849008778 23.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-69ee3887-883c-4019-a348-d0ff81933675">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-69ee3887-883c-4019-a348-d0ff81933675_0">
											<gml:posList>35.671080027626104 139.74030992285688 24.039 35.671068634531 139.74029859146984 24.039 35.671068634531 139.74029859146984 23.22 35.671079351076415 139.74030924981415 23.22 35.671079351076415 139.74030924981415 23.506 35.671080027626104 139.74030992285688 23.506 35.671080027626104 139.74030992285688 24.039</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b0619acb-346d-4e7d-b20b-541dd8c72d77">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b0619acb-346d-4e7d-b20b-541dd8c72d77_0">
											<gml:posList>35.67107595695681 139.74031450077095 23.506 35.67107595695681 139.74031450077095 23.22 35.67106519530058 139.740303787247 23.22 35.67106519530058 139.740303787247 24.039 35.67107658840373 139.74031512968062 24.039 35.67107658840373 139.74031512968062 23.506 35.67107595695681 139.74031450077095 23.506</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-15e1da75-6394-4fb3-933d-1846d6e4513a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-15e1da75-6394-4fb3-933d-1846d6e4513a_0">
											<gml:posList>35.67106519530058 139.740303787247 23.22 35.67104940364751 139.74032764359723 23.22 35.67104940364751 139.74032764359723 24.039 35.67106519530058 139.740303787247 24.039 35.67106519530058 139.740303787247 23.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-729b5005-803f-4843-8543-de65b7733ac2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-729b5005-803f-4843-8543-de65b7733ac2_0">
											<gml:posList>35.67104940364751 139.74032764359723 24.039 35.67106079673992 139.7403389749857 24.039 35.67107658840373 139.74031512968062 24.039 35.67106519530058 139.740303787247 24.039 35.67104940364751 139.74032764359723 24.039</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46d383d3-6e46-49c1-ae51-910a63e4ab2c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46d383d3-6e46-49c1-ae51-910a63e4ab2c_0">
											<gml:posList>35.671060390806794 139.74033856674143 23.506 35.671060390806794 139.74033856674143 23.22 35.67107595695681 139.74031450077095 23.22 35.67107595695681 139.74031450077095 23.506 35.671060390806794 139.74033856674143 23.506</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e9b2e8d-0e15-4323-a4f1-9ba23e698b3b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3e9b2e8d-0e15-4323-a4f1-9ba23e698b3b_0">
											<gml:posList>35.67106079673992 139.7403389749857 23.506 35.67107658840373 139.74031512968062 23.506 35.67107658840373 139.74031512968062 24.039 35.67106079673992 139.7403389749857 24.039 35.67106079673992 139.7403389749857 23.506</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4289637a-60d0-413a-9608-ecd97c83ee9c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4289637a-60d0-413a-9608-ecd97c83ee9c_0">
											<gml:posList>35.671060390806794 139.74033856674143 23.506 35.67106079673992 139.7403389749857 23.506 35.67106079673992 139.7403389749857 24.039 35.67104940364751 139.74032764359723 24.039 35.67104940364751 139.74032764359723 23.22 35.671060390806794 139.74033856674143 23.22 35.671060390806794 139.74033856674143 23.506</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-630f3b9b-451f-4e85-b7cd-d0d01205c6a2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-630f3b9b-451f-4e85-b7cd-d0d01205c6a2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-630f3b9b-451f-4e85-b7cd-d0d01205c6a2">
											<gml:posList>35.67096638608189 139.74029119860617 11.77 35.671037871592375 139.74018319280893 11.77 35.67111553944277 139.74026031663368 11.77 35.671043963812174 139.74036843303503 11.77 35.67096638608189 139.74029119860617 11.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7faa5d5a-5e51-4509-b441-3371b4904e96">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7faa5d5a-5e51-4509-b441-3371b4904e96">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7faa5d5a-5e51-4509-b441-3371b4904e96">
											<gml:posList>35.671037871592375 139.74018319280893 23.506 35.67103819914552 139.74018714702171 23.506 35.67111135666614 139.74025979126407 23.506 35.67111553944277 139.74026031663368 23.506 35.671037871592375 139.74018319280893 23.506</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ec478dca-a7d5-4666-9f04-cad28a573bb5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec478dca-a7d5-4666-9f04-cad28a573bb5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec478dca-a7d5-4666-9f04-cad28a573bb5">
											<gml:posList>35.67096638608189 139.74029119860617 23.506 35.670969594659574 139.74029079721444 23.506 35.67103819914552 139.74018714702171 23.506 35.671037871592375 139.74018319280893 23.506 35.67096638608189 139.74029119860617 23.506</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-814abc47-6196-42b4-9686-966cde5dd61c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-814abc47-6196-42b4-9686-966cde5dd61c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-814abc47-6196-42b4-9686-966cde5dd61c">
											<gml:posList>35.67101859328064 139.74025578970924 25.897 35.67101894817143 139.74026013051179 25.897 35.67103919957441 139.74028028868443 25.897 35.671042741617015 139.74027983167312 25.897 35.67101859328064 139.74025578970924 25.897</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bfce6e7e-eda6-4347-8a51-7e3e91b42baa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bfce6e7e-eda6-4347-8a51-7e3e91b42baa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bfce6e7e-eda6-4347-8a51-7e3e91b42baa">
											<gml:posList>35.67101859328064 139.74025578970924 23.22 35.671042741617015 139.74027983167312 23.22 35.67111135666614 139.74025979126407 23.22 35.67103819914552 139.74018714702171 23.22 35.670969594659574 139.74029079721444 23.22 35.671043618246046 139.74036448988846 23.22 35.67101374218198 139.74032356467808 23.22 35.67098960287647 139.74029953374554 23.22 35.67101859328064 139.74025578970924 23.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3e5ff04f-36ae-432c-a99a-e87da7bb9c01">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e5ff04f-36ae-432c-a99a-e87da7bb9c01">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e5ff04f-36ae-432c-a99a-e87da7bb9c01">
											<gml:posList>35.67098960287647 139.74029953374554 25.897 35.670993135913996 139.74029908779215 25.897 35.67101894817143 139.74026013051179 25.897 35.67101859328064 139.74025578970924 25.897 35.67098960287647 139.74029953374554 25.897</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-52405ecc-6b32-4896-87d0-9353db3753f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-52405ecc-6b32-4896-87d0-9353db3753f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-52405ecc-6b32-4896-87d0-9353db3753f7">
											<gml:posList>35.67103919957441 139.74028028868443 25.341 35.67101894817143 139.74026013051179 25.341 35.670993135913996 139.74029908779215 25.341 35.67101337828829 139.74031923493234 25.341 35.67103919957441 139.74028028868443 25.341</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1dbfbc40-b63c-49be-9736-65a7d997dbe1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1dbfbc40-b63c-49be-9736-65a7d997dbe1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1dbfbc40-b63c-49be-9736-65a7d997dbe1">
											<gml:posList>35.671042741617015 139.74027983167312 25.897 35.67103919957441 139.74028028868443 25.897 35.67101337828829 139.74031923493234 25.897 35.67101374218198 139.74032356467808 25.897 35.671042741617015 139.74027983167312 25.897</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-18011a73-4135-48c7-a5b6-a42542ea6c32">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18011a73-4135-48c7-a5b6-a42542ea6c32">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18011a73-4135-48c7-a5b6-a42542ea6c32">
											<gml:posList>35.67101374218198 139.74032356467808 25.897 35.67101337828829 139.74031923493234 25.897 35.670993135913996 139.74029908779215 25.897 35.67098960287647 139.74029953374554 25.897 35.67101374218198 139.74032356467808 25.897</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7902785e-6edb-407a-937f-fe600b511e6a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7902785e-6edb-407a-937f-fe600b511e6a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7902785e-6edb-407a-937f-fe600b511e6a">
											<gml:posList>35.671042741617015 139.74027983167312 23.22 35.67101374218198 139.74032356467808 23.22 35.671043618246046 139.74036448988846 23.22 35.67111135666614 139.74025979126407 23.22 35.671042741617015 139.74027983167312 23.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b86268f2-af6e-4f06-b249-4111b97e914f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b86268f2-af6e-4f06-b249-4111b97e914f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b86268f2-af6e-4f06-b249-4111b97e914f">
											<gml:posList>35.67111553944277 139.74026031663368 23.506 35.67111135666614 139.74025979126407 23.506 35.671043618246046 139.74036448988846 23.506 35.671043963812174 139.74036843303503 23.506 35.67111553944277 139.74026031663368 23.506</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-02ff606b-ed0c-441c-8e36-b935dd2c6bfa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-02ff606b-ed0c-441c-8e36-b935dd2c6bfa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-02ff606b-ed0c-441c-8e36-b935dd2c6bfa">
											<gml:posList>35.671043963812174 139.74036843303503 23.506 35.671043618246046 139.74036448988846 23.506 35.670969594659574 139.74029079721444 23.506 35.67096638608189 139.74029119860617 23.506 35.671043963812174 139.74036843303503 23.506</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-486703f3-e567-4fd4-ab79-d327e1f3469b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-486703f3-e567-4fd4-ab79-d327e1f3469b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-486703f3-e567-4fd4-ab79-d327e1f3469b">
											<gml:posList>35.670993135913996 139.74029908779215 25.897 35.670993135913996 139.74029908779215 25.341 35.67101894817143 139.74026013051179 25.341 35.67101894817143 139.74026013051179 25.897 35.670993135913996 139.74029908779215 25.897</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-94c16b93-e482-474d-bc41-1c0ca6d2f1bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-94c16b93-e482-474d-bc41-1c0ca6d2f1bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-94c16b93-e482-474d-bc41-1c0ca6d2f1bc">
											<gml:posList>35.67103919957441 139.74028028868443 25.897 35.67103919957441 139.74028028868443 25.341 35.67101337828829 139.74031923493234 25.341 35.67101337828829 139.74031923493234 25.897 35.67103919957441 139.74028028868443 25.897</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4bce0827-3b55-44a9-89a6-4b9628d764ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4bce0827-3b55-44a9-89a6-4b9628d764ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4bce0827-3b55-44a9-89a6-4b9628d764ce">
											<gml:posList>35.67098960287647 139.74029953374554 23.22 35.67101374218198 139.74032356467808 23.22 35.67101374218198 139.74032356467808 25.897 35.67098960287647 139.74029953374554 25.897 35.67098960287647 139.74029953374554 23.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7e618c44-bff6-4d8a-bf8b-82af1556edd3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e618c44-bff6-4d8a-bf8b-82af1556edd3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e618c44-bff6-4d8a-bf8b-82af1556edd3">
											<gml:posList>35.671037871592375 139.74018319280893 11.77 35.67096638608189 139.74029119860617 11.77 35.67096638608189 139.74029119860617 23.506 35.671037871592375 139.74018319280893 23.506 35.671037871592375 139.74018319280893 11.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-35fc4fab-2879-4e41-a603-310d837e0672">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-35fc4fab-2879-4e41-a603-310d837e0672">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-35fc4fab-2879-4e41-a603-310d837e0672">
											<gml:posList>35.67101337828829 139.74031923493234 25.897 35.67101337828829 139.74031923493234 25.341 35.670993135913996 139.74029908779215 25.341 35.670993135913996 139.74029908779215 25.897 35.67101337828829 139.74031923493234 25.897</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7ca27174-b3c4-4c33-a07e-6976cac7a210">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ca27174-b3c4-4c33-a07e-6976cac7a210">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ca27174-b3c4-4c33-a07e-6976cac7a210">
											<gml:posList>35.670969594659574 139.74029079721444 23.506 35.670969594659574 139.74029079721444 23.22 35.67103819914552 139.74018714702171 23.22 35.67103819914552 139.74018714702171 23.506 35.670969594659574 139.74029079721444 23.506</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c6d5ea16-ab5a-4f4f-b6d3-ecb063abee4d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6d5ea16-ab5a-4f4f-b6d3-ecb063abee4d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6d5ea16-ab5a-4f4f-b6d3-ecb063abee4d">
											<gml:posList>35.67098960287647 139.74029953374554 25.897 35.67101859328064 139.74025578970924 25.897 35.67101859328064 139.74025578970924 23.22 35.67098960287647 139.74029953374554 23.22 35.67098960287647 139.74029953374554 25.897</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0f9a1d5d-f126-4f82-9264-6a7f29054917">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0f9a1d5d-f126-4f82-9264-6a7f29054917">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0f9a1d5d-f126-4f82-9264-6a7f29054917">
											<gml:posList>35.67096638608189 139.74029119860617 11.77 35.671043963812174 139.74036843303503 11.77 35.671043963812174 139.74036843303503 23.506 35.67096638608189 139.74029119860617 23.506 35.67096638608189 139.74029119860617 11.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e470cf53-5864-4977-9d83-5be092983be0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e470cf53-5864-4977-9d83-5be092983be0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e470cf53-5864-4977-9d83-5be092983be0">
											<gml:posList>35.671043618246046 139.74036448988846 23.506 35.671043618246046 139.74036448988846 23.22 35.670969594659574 139.74029079721444 23.22 35.670969594659574 139.74029079721444 23.506 35.671043618246046 139.74036448988846 23.506</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2c7e7cd1-8c97-4917-b653-b90549596645">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c7e7cd1-8c97-4917-b653-b90549596645">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c7e7cd1-8c97-4917-b653-b90549596645">
											<gml:posList>35.67101374218198 139.74032356467808 23.22 35.671042741617015 139.74027983167312 23.22 35.671042741617015 139.74027983167312 25.897 35.67101374218198 139.74032356467808 25.897 35.67101374218198 139.74032356467808 23.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-547b1925-551c-449e-b650-070b40f38a4d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-547b1925-551c-449e-b650-070b40f38a4d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-547b1925-551c-449e-b650-070b40f38a4d">
											<gml:posList>35.67101894817143 139.74026013051179 25.897 35.67101894817143 139.74026013051179 25.341 35.67103919957441 139.74028028868443 25.341 35.67103919957441 139.74028028868443 25.897 35.67101894817143 139.74026013051179 25.897</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2ca66212-619e-4cb8-be47-dcee749bf717">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2ca66212-619e-4cb8-be47-dcee749bf717">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2ca66212-619e-4cb8-be47-dcee749bf717">
											<gml:posList>35.67101859328064 139.74025578970924 25.897 35.671042741617015 139.74027983167312 25.897 35.671042741617015 139.74027983167312 23.22 35.67101859328064 139.74025578970924 23.22 35.67101859328064 139.74025578970924 25.897</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-87c63084-4d56-41d5-9eed-93154c31af61">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-87c63084-4d56-41d5-9eed-93154c31af61">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-87c63084-4d56-41d5-9eed-93154c31af61">
											<gml:posList>35.67103819914552 139.74018714702171 23.506 35.67103819914552 139.74018714702171 23.22 35.67111135666614 139.74025979126407 23.22 35.67111135666614 139.74025979126407 23.506 35.67103819914552 139.74018714702171 23.506</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5d3b4b01-6d84-4c12-b2c6-e3a67527f5e4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d3b4b01-6d84-4c12-b2c6-e3a67527f5e4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d3b4b01-6d84-4c12-b2c6-e3a67527f5e4">
											<gml:posList>35.67111553944277 139.74026031663368 11.77 35.671037871592375 139.74018319280893 11.77 35.671037871592375 139.74018319280893 23.506 35.67111553944277 139.74026031663368 23.506 35.67111553944277 139.74026031663368 11.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5f29b76f-d15f-4dc4-b380-7f1000151734">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f29b76f-d15f-4dc4-b380-7f1000151734">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f29b76f-d15f-4dc4-b380-7f1000151734">
											<gml:posList>35.67111135666614 139.74025979126407 23.506 35.67111135666614 139.74025979126407 23.22 35.671043618246046 139.74036448988846 23.22 35.671043618246046 139.74036448988846 23.506 35.67111135666614 139.74025979126407 23.506</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-396d6253-1592-43a1-847d-be62bd373dae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-396d6253-1592-43a1-847d-be62bd373dae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-396d6253-1592-43a1-847d-be62bd373dae">
											<gml:posList>35.671043963812174 139.74036843303503 11.77 35.67111553944277 139.74026031663368 11.77 35.67111553944277 139.74026031663368 23.506 35.671043963812174 139.74036843303503 23.506 35.671043963812174 139.74036843303503 11.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8350</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">139.68915</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.05</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>