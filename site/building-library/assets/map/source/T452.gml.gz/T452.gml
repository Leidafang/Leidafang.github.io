<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_8460c7c3-4759-430f-b5fd-f79808b8bc49">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門駅南地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">30.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>10</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.668955951091505 139.74870488808216 0 35.66891943371721 139.74881649182058 0 35.668966770977306 139.74883809221245 0 35.66896803049622 139.7488346666048 0 35.66897208806854 139.74883665062066 0 35.669008875717665 139.7487248256115 0 35.668962889487425 139.74870178786082 0 35.66895838239112 139.74870146123612 0 35.668955951091505 139.74870488808216 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668955951091505 139.74870488808216 5.81 35.66895838239112 139.74870146123612 5.81 35.668962889487425 139.74870178786082 5.81 35.669008875717665 139.7487248256115 5.81 35.66897208806854 139.74883665062066 5.81 35.66896803049622 139.7488346666048 5.81 35.668966770977306 139.74883809221245 5.81 35.66891943371721 139.74881649182058 5.81 35.668955951091505 139.74870488808216 5.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668955951091505 139.74870488808216 5.81 35.66891943371721 139.74881649182058 5.81 35.66891943371721 139.74881649182058 36.7 35.668955951091505 139.74870488808216 36.7 35.668955951091505 139.74870488808216 5.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66891943371721 139.74881649182058 5.81 35.668966770977306 139.74883809221245 5.81 35.668966770977306 139.74883809221245 36.7 35.66891943371721 139.74881649182058 36.7 35.66891943371721 139.74881649182058 5.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668966770977306 139.74883809221245 5.81 35.66896803049622 139.7488346666048 5.81 35.66896803049622 139.7488346666048 36.7 35.668966770977306 139.74883809221245 36.7 35.668966770977306 139.74883809221245 5.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66896803049622 139.7488346666048 5.81 35.66897208806854 139.74883665062066 5.81 35.66897208806854 139.74883665062066 36.7 35.66896803049622 139.7488346666048 36.7 35.66896803049622 139.7488346666048 5.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66897208806854 139.74883665062066 5.81 35.669008875717665 139.7487248256115 5.81 35.669008875717665 139.7487248256115 36.7 35.66897208806854 139.74883665062066 36.7 35.66897208806854 139.74883665062066 5.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669008875717665 139.7487248256115 5.81 35.668962889487425 139.74870178786082 5.81 35.668962889487425 139.74870178786082 36.7 35.669008875717665 139.7487248256115 36.7 35.669008875717665 139.7487248256115 5.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668962889487425 139.74870178786082 5.81 35.66895838239112 139.74870146123612 5.81 35.66895838239112 139.74870146123612 36.7 35.668962889487425 139.74870178786082 36.7 35.668962889487425 139.74870178786082 5.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66895838239112 139.74870146123612 5.81 35.668955951091505 139.74870488808216 5.81 35.668955951091505 139.74870488808216 36.7 35.66895838239112 139.74870146123612 36.7 35.66895838239112 139.74870146123612 5.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668955951091505 139.74870488808216 36.7 35.66891943371721 139.74881649182058 36.7 35.668966770977306 139.74883809221245 36.7 35.66896803049622 139.7488346666048 36.7 35.66897208806854 139.74883665062066 36.7 35.669008875717665 139.7487248256115 36.7 35.668962889487425 139.74870178786082 36.7 35.66895838239112 139.74870146123612 36.7 35.668955951091505 139.74870488808216 36.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-da53cc7c-ccb9-4200-bd35-37ae70acb385"/>
							<gml:surfaceMember xlink:href="#poly-4b268921-ea21-4f6e-b9ea-ec08ec11cc3e"/>
							<gml:surfaceMember xlink:href="#poly-85c7c5bc-90b7-4a8e-a172-49f93c45aa6f"/>
							<gml:surfaceMember xlink:href="#poly-058f247a-1c52-42f5-9b43-2d452c5252d1"/>
							<gml:surfaceMember xlink:href="#poly-66e11c82-0d0b-47f9-b0d8-6822e58279b3"/>
							<gml:surfaceMember xlink:href="#poly-ff687b07-a250-4a47-bd7e-c906fbce04f7"/>
							<gml:surfaceMember xlink:href="#poly-74324fbf-15c7-45ea-ab30-7d3557799e61"/>
							<gml:surfaceMember xlink:href="#poly-4e20714c-86b0-43df-af74-d55c02965c8f"/>
							<gml:surfaceMember xlink:href="#poly-ba8eaa46-f780-4f96-8876-4b5d2e9fa2ce"/>
							<gml:surfaceMember xlink:href="#poly-0196132c-247c-4f7a-954b-eb5c27aea71b"/>
							<gml:surfaceMember xlink:href="#poly-c0bc6fb1-2b17-44cd-8c50-c2fd977b6fce"/>
							<gml:surfaceMember xlink:href="#poly-485c16ef-96c1-4d38-aef6-a0494454c2ad"/>
							<gml:surfaceMember xlink:href="#poly-e31c2a07-2b71-4764-9687-8c06d71b47af"/>
							<gml:surfaceMember xlink:href="#poly-9c0f6fdc-29dd-41fe-84db-39e3f08e57d4"/>
							<gml:surfaceMember xlink:href="#poly-d8ba8e6a-9783-460b-a67d-c0367e033ae5"/>
							<gml:surfaceMember xlink:href="#poly-7994ab8e-c444-46ec-a372-003b89224d99"/>
							<gml:surfaceMember xlink:href="#poly-55d3740c-5d78-4356-83bf-c9b2472cd170"/>
							<gml:surfaceMember xlink:href="#poly-a56e4120-6f4f-4ed5-bf4e-d19ed0debb80"/>
							<gml:surfaceMember xlink:href="#poly-e4939aea-2527-4408-b2c8-e2701cc31a41"/>
							<gml:surfaceMember xlink:href="#poly-f2058c75-fb7b-47d4-b975-88c25741f06f"/>
							<gml:surfaceMember xlink:href="#poly-e9482bde-1c52-4ce1-b202-834d0e24406b"/>
							<gml:surfaceMember xlink:href="#poly-91f353ce-4242-4e12-b3b2-fad7bbfff2db"/>
							<gml:surfaceMember xlink:href="#poly-c8cd6d0b-1ad1-4264-b30c-8c5cb669e64a"/>
							<gml:surfaceMember xlink:href="#poly-6f1b59ba-0c4b-47d9-8060-bbfe9e7b4ada"/>
							<gml:surfaceMember xlink:href="#poly-59791c21-f628-4cbf-9450-7e339dad770f"/>
							<gml:surfaceMember xlink:href="#poly-0996848b-ca8d-4abd-9e5a-05b70fad960a"/>
							<gml:surfaceMember xlink:href="#poly-8c25f11b-d7e4-4c86-8da3-e2beb3d79c6c"/>
							<gml:surfaceMember xlink:href="#poly-16e3831e-02bf-4ac1-87e2-a3184fa5e9cd"/>
							<gml:surfaceMember xlink:href="#poly-54d023e5-0631-4826-9863-785e73e76de4"/>
							<gml:surfaceMember xlink:href="#poly-4deb6518-55f3-4491-97b6-83fbaae44d09"/>
							<gml:surfaceMember xlink:href="#poly-781e5975-a951-455b-85e1-6fccf58b34d9"/>
							<gml:surfaceMember xlink:href="#poly-c8972823-eec3-4868-9213-5470cd63526f"/>
							<gml:surfaceMember xlink:href="#poly-1b31652b-2a00-4249-8619-4a0a9f254c55"/>
							<gml:surfaceMember xlink:href="#poly-c6680fdb-b1e4-40f8-9a01-5de90225cfa7"/>
							<gml:surfaceMember xlink:href="#poly-62ea6a14-8e87-4b68-b845-243d788aeca3"/>
							<gml:surfaceMember xlink:href="#poly-3fd3934e-dfa0-43bb-a713-424b5e15fde5"/>
							<gml:surfaceMember xlink:href="#poly-0f131570-7b64-4414-b991-8778b13b9b7a"/>
							<gml:surfaceMember xlink:href="#poly-7329679e-789c-4a08-aa76-3c728d8d5851"/>
							<gml:surfaceMember xlink:href="#poly-a0ff8329-af2e-482b-9bf2-6282ddb05edd"/>
							<gml:surfaceMember xlink:href="#poly-b0e2c5c8-a9d6-4f5a-b29c-4089c8d46bf9"/>
							<gml:surfaceMember xlink:href="#poly-b48d128a-8563-4fc5-8928-de1ebb880c6d"/>
							<gml:surfaceMember xlink:href="#poly-eaf23138-a5d5-48ec-974d-ff87cebf899e"/>
							<gml:surfaceMember xlink:href="#poly-e69fbd13-3497-4afa-a04e-4b47be4348db"/>
							<gml:surfaceMember xlink:href="#poly-b73baa96-e5cc-4fc1-8d17-ef5365e7c688"/>
							<gml:surfaceMember xlink:href="#poly-b3cad81d-593c-4b33-b61e-6691475e550f"/>
							<gml:surfaceMember xlink:href="#poly-d67475d6-6093-420b-8132-52254e67029b"/>
							<gml:surfaceMember xlink:href="#poly-a30a99e5-190c-4b91-85c6-1b14a73a9118"/>
							<gml:surfaceMember xlink:href="#poly-f93dc8fe-5608-4780-b48e-57a9a6df3675"/>
							<gml:surfaceMember xlink:href="#poly-e1db354b-c58b-4fc3-8823-01f156cf057d"/>
							<gml:surfaceMember xlink:href="#poly-0ee2745a-610a-4aa1-8f31-d5b11494c697"/>
							<gml:surfaceMember xlink:href="#poly-c66e7844-8132-4801-bb27-760510608e17"/>
							<gml:surfaceMember xlink:href="#poly-646ee386-04db-488f-b9d4-9190ba157f9e"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_8460c7c3-4759-430f-b5fd-f79808b8bc49_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d592067a-e090-4f14-95a3-d1ef6fcb164a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66894515250207 139.74878168066036 36.725 35.66895242007899 139.7487595808696 36.725 35.668960715593684 139.74876368125575 36.725 35.66895344801602 139.7487857810484 36.725 35.66894515250207 139.74878168066036 36.725</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d17d058c-6294-4655-b538-554ae714a671">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d17d058c-6294-4655-b538-554ae714a671_0">
											<gml:posList>35.668960715593684 139.74876368125575 38.371 35.668960715593684 139.74876368125575 36.725 35.66895242007899 139.7487595808696 36.725 35.66895242007899 139.7487595808696 38.371 35.668960715593684 139.74876368125575 38.371</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1822f059-f43b-4dd8-b13b-7297efb3c179">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1822f059-f43b-4dd8-b13b-7297efb3c179_0">
											<gml:posList>35.66895242007899 139.7487595808696 38.371 35.66895242007899 139.7487595808696 36.725 35.66894515250207 139.74878168066036 36.725 35.66894515250207 139.74878168066036 38.371 35.66895242007899 139.7487595808696 38.371</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a451b836-dd80-40ad-9189-8a0f4f71134d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a451b836-dd80-40ad-9189-8a0f4f71134d_0">
											<gml:posList>35.66895344801602 139.7487857810484 38.371 35.668960715593684 139.74876368125575 38.371 35.66895242007899 139.7487595808696 38.371 35.66894515250207 139.74878168066036 38.371 35.66895344801602 139.7487857810484 38.371</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b429e4de-8815-4846-b09b-872a08c43f54">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b429e4de-8815-4846-b09b-872a08c43f54_0">
											<gml:posList>35.66895344801602 139.7487857810484 38.371 35.66895344801602 139.7487857810484 36.725 35.668960715593684 139.74876368125575 36.725 35.668960715593684 139.74876368125575 38.371 35.66895344801602 139.7487857810484 38.371</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce59e03f-470f-4e07-ab0c-ba41323bba52">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce59e03f-470f-4e07-ab0c-ba41323bba52_0">
											<gml:posList>35.66894515250207 139.74878168066036 38.371 35.66894515250207 139.74878168066036 36.725 35.66895344801602 139.7487857810484 36.725 35.66895344801602 139.7487857810484 38.371 35.66894515250207 139.74878168066036 38.371</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_8460c7c3-4759-430f-b5fd-f79808b8bc49_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4411db6-72cf-4674-87d7-7c21a210ce4f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66896025971773 139.74878196297354 40.703 35.66896445115539 139.74876920034836 40.703 35.66897546975384 139.7487746344384 40.703 35.66897126930962 139.74878740812062 40.703 35.66896025971773 139.74878196297354 40.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c89a99b-35aa-40cc-9ab6-5a467030a0f1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668973495753264 139.74874897650784 36.725 35.66897932421672 139.74873127455962 36.725 35.66899146992847 139.74873727080578 36.725 35.6689856414719 139.7487549838023 36.725 35.668973495753264 139.74874897650784 36.725</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-34785c41-21c5-4738-8468-a6609441d803">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-34785c41-21c5-4738-8468-a6609441d803_0">
											<gml:posList>35.66899146992847 139.74873727080578 36.725 35.66897932421672 139.74873127455962 36.725 35.66897932421672 139.74873127455962 38.519 35.66899146992847 139.74873727080578 38.519 35.66899146992847 139.74873727080578 36.725</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-87093fde-4592-403a-ac2b-bd8dc6f2d6df">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-87093fde-4592-403a-ac2b-bd8dc6f2d6df_0">
											<gml:posList>35.668973495753264 139.74874897650784 36.725 35.668973495753264 139.74874897650784 38.519 35.66897932421672 139.74873127455962 38.519 35.66897932421672 139.74873127455962 36.725 35.668973495753264 139.74874897650784 36.725</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-773d3614-0d2f-4472-8e81-b92899a860d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-773d3614-0d2f-4472-8e81-b92899a860d6_0">
											<gml:posList>35.66899146992847 139.74873727080578 38.519 35.66897932421672 139.74873127455962 38.519 35.668973495753264 139.74874897650784 38.519 35.6689856414719 139.7487549838023 38.519 35.66899146992847 139.74873727080578 38.519</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-15b03beb-df48-4ef8-825f-80b78825ae34">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-15b03beb-df48-4ef8-825f-80b78825ae34_0">
											<gml:posList>35.66899146992847 139.74873727080578 36.725 35.66899146992847 139.74873727080578 38.519 35.6689856414719 139.7487549838023 38.519 35.6689856414719 139.7487549838023 36.725 35.66899146992847 139.74873727080578 36.725</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-65140f5a-1766-40d7-a5b6-bfbf665568e8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-65140f5a-1766-40d7-a5b6-bfbf665568e8_0">
											<gml:posList>35.6689856414719 139.7487549838023 36.725 35.6689856414719 139.7487549838023 38.519 35.668973495753264 139.74874897650784 38.519 35.668973495753264 139.74874897650784 36.725 35.6689856414719 139.7487549838023 36.725</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-45188605-37dd-44ed-a394-5a02e6cec9c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-45188605-37dd-44ed-a394-5a02e6cec9c9_0">
											<gml:posList>35.66896445115539 139.74876920034836 40.703 35.66896445115539 139.74876920034836 42.474 35.66897546975384 139.7487746344384 42.474 35.66897546975384 139.7487746344384 40.703 35.66896445115539 139.74876920034836 40.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-299264fc-0d5e-41ec-b558-715fefaeceeb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-299264fc-0d5e-41ec-b558-715fefaeceeb_0">
											<gml:posList>35.66896445115539 139.74876920034836 40.703 35.66896025971773 139.74878196297354 40.703 35.66896025971773 139.74878196297354 42.474 35.66896445115539 139.74876920034836 42.474 35.66896445115539 139.74876920034836 40.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-56cd07a8-7055-4312-b4bc-d19a43c3621e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-56cd07a8-7055-4312-b4bc-d19a43c3621e_0">
											<gml:posList>35.66896025971773 139.74878196297354 42.474 35.66897126930962 139.74878740812062 42.474 35.66897546975384 139.7487746344384 42.474 35.66896445115539 139.74876920034836 42.474 35.66896025971773 139.74878196297354 42.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8ede75c4-bdf5-4047-a370-d361b5529a00">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8ede75c4-bdf5-4047-a370-d361b5529a00_0">
											<gml:posList>35.66897126930962 139.74878740812062 40.703 35.66897546975384 139.7487746344384 40.703 35.66897546975384 139.7487746344384 42.474 35.66897126930962 139.74878740812062 42.474 35.66897126930962 139.74878740812062 40.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e458b3b-b679-4efa-ae15-8eb78dd64311">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8e458b3b-b679-4efa-ae15-8eb78dd64311_0">
											<gml:posList>35.66897126930962 139.74878740812062 40.703 35.66897126930962 139.74878740812062 42.474 35.66896025971773 139.74878196297354 42.474 35.66896025971773 139.74878196297354 40.703 35.66897126930962 139.74878740812062 40.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-da53cc7c-ccb9-4200-bd35-37ae70acb385">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da53cc7c-ccb9-4200-bd35-37ae70acb385">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da53cc7c-ccb9-4200-bd35-37ae70acb385">
											<gml:posList>35.66900887571768 139.7487248256115 5.81 35.66897208806853 139.7488366506207 5.81 35.66896803049622 139.74883466660478 5.81 35.66896677097733 139.74883809221242 5.81 35.66891943371721 139.74881649182055 5.81 35.668955951091505 139.7487048880822 5.81 35.66895838239111 139.7487014612361 5.81 35.66896288948743 139.7487017878608 5.81 35.66900887571768 139.7487248256115 5.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4b268921-ea21-4f6e-b9ea-ec08ec11cc3e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b268921-ea21-4f6e-b9ea-ec08ec11cc3e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b268921-ea21-4f6e-b9ea-ec08ec11cc3e">
											<gml:posList>35.66896013049151 139.74879047962563 40.636 35.6689586968126 139.74878977418916 40.636 35.66895955484608 139.74879223655682 40.636 35.66896013049151 139.74879047962563 40.636</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-85c7c5bc-90b7-4a8e-a172-49f93c45aa6f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85c7c5bc-90b7-4a8e-a172-49f93c45aa6f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85c7c5bc-90b7-4a8e-a172-49f93c45aa6f">
											<gml:posList>35.66897236780327 139.7487985634893 40.636 35.66897437712767 139.74879751199455 40.636 35.66897295246252 139.74879680654834 40.636 35.66897236780327 139.7487985634893 40.636</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-058f247a-1c52-42f5-9b43-2d452c5252d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-058f247a-1c52-42f5-9b43-2d452c5252d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-058f247a-1c52-42f5-9b43-2d452c5252d1">
											<gml:posList>35.668955951091505 139.7487048880822 37.1 35.66891943371721 139.74881649182055 37.1 35.66892125379227 139.74881549575676 37.1 35.66895720451192 139.74870561579948 37.1 35.668955951091505 139.7487048880822 37.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-66e11c82-0d0b-47f9-b0d8-6822e58279b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66e11c82-0d0b-47f9-b0d8-6822e58279b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66e11c82-0d0b-47f9-b0d8-6822e58279b3">
											<gml:posList>35.66896677097733 139.74883809221242 37.1 35.66896603034025 139.74883593901015 37.1 35.66892125379227 139.74881549575676 37.1 35.66891943371721 139.74881649182055 37.1 35.66896677097733 139.74883809221242 37.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ff687b07-a250-4a47-bd7e-c906fbce04f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff687b07-a250-4a47-bd7e-c906fbce04f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff687b07-a250-4a47-bd7e-c906fbce04f7">
											<gml:posList>35.66892423994522 139.74880636856383 36.725 35.668943536035314 139.74881591411204 36.725 35.66895305225742 139.74878698548667 36.725 35.66896197483118 139.74875985798917 36.725 35.66894258857617 139.7487502794092 36.725 35.66892423994522 139.74880636856383 36.725</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-74324fbf-15c7-45ea-ab30-7d3557799e61">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74324fbf-15c7-45ea-ab30-7d3557799e61">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74324fbf-15c7-45ea-ab30-7d3557799e61">
											<gml:posList>35.66896603034025 139.74883593901015 36.725 35.6689688283305 139.74882841369075 36.725 35.6689648518971 139.74882645168196 36.725 35.668949180589834 139.74881870281624 36.725 35.668943536035314 139.74881591411204 36.725 35.66892423994522 139.74880636856383 36.725 35.66892125379227 139.74881549575676 36.725 35.66896603034025 139.74883593901015 36.725</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4e20714c-86b0-43df-af74-d55c02965c8f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4e20714c-86b0-43df-af74-d55c02965c8f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4e20714c-86b0-43df-af74-d55c02965c8f">
											<gml:posList>35.668949180589834 139.74881870281624 36.725 35.6689586968126 139.74878977418916 36.725 35.66895305225742 139.74878698548667 36.725 35.668943536035314 139.74881591411204 36.725 35.668949180589834 139.74881870281624 36.725</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ba8eaa46-f780-4f96-8876-4b5d2e9fa2ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba8eaa46-f780-4f96-8876-4b5d2e9fa2ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba8eaa46-f780-4f96-8876-4b5d2e9fa2ce">
											<gml:posList>35.668949180589834 139.74881870281624 40.636 35.66895118991441 139.74881765132233 40.636 35.66895955484608 139.74879223655682 40.636 35.6689586968126 139.74878977418916 40.636 35.668949180589834 139.74881870281624 40.636</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0196132c-247c-4f7a-954b-eb5c27aea71b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0196132c-247c-4f7a-954b-eb5c27aea71b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0196132c-247c-4f7a-954b-eb5c27aea71b">
											<gml:posList>35.6689648518971 139.74882645168196 40.636 35.6689639938643 139.74882398931376 40.636 35.66895118991441 139.74881765132233 40.636 35.668949180589834 139.74881870281624 40.636 35.6689648518971 139.74882645168196 40.636</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c0bc6fb1-2b17-44cd-8c50-c2fd977b6fce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0bc6fb1-2b17-44cd-8c50-c2fd977b6fce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0bc6fb1-2b17-44cd-8c50-c2fd977b6fce">
											<gml:posList>35.66895884327122 139.74870313975143 37.1 35.66895838239111 139.7487014612361 37.1 35.668955951091505 139.7487048880822 37.1 35.66895720451192 139.74870561579948 37.1 35.66895884327122 139.74870313975143 37.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-485c16ef-96c1-4d38-aef6-a0494454c2ad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-485c16ef-96c1-4d38-aef6-a0494454c2ad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-485c16ef-96c1-4d38-aef6-a0494454c2ad">
											<gml:posList>35.66895305225742 139.74878698548667 40.955 35.66895496246174 139.74878597828067 40.955 35.6689627877113 139.74876219889754 40.955 35.66896197483118 139.74875985798917 40.955 35.66895305225742 139.74878698548667 40.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e31c2a07-2b71-4764-9687-8c06d71b47af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e31c2a07-2b71-4764-9687-8c06d71b47af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e31c2a07-2b71-4764-9687-8c06d71b47af">
											<gml:posList>35.66896252108138 139.7487034341133 37.1 35.66896288948743 139.7487017878608 37.1 35.66895838239111 139.7487014612361 37.1 35.66895884327122 139.74870313975143 37.1 35.66896252108138 139.7487034341133 37.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9c0f6fdc-29dd-41fe-84db-39e3f08e57d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c0f6fdc-29dd-41fe-84db-39e3f08e57d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c0f6fdc-29dd-41fe-84db-39e3f08e57d4">
											<gml:posList>35.66895955484608 139.74879223655682 40.424 35.66895118991441 139.74881765132233 40.424 35.6689639938643 139.74882398931376 40.424 35.66897236780327 139.7487985634893 40.424 35.66897295246252 139.74879680654834 40.424 35.66896013049151 139.74879047962563 40.424 35.66895955484608 139.74879223655682 40.424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d8ba8e6a-9783-460b-a67d-c0367e033ae5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d8ba8e6a-9783-460b-a67d-c0367e033ae5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d8ba8e6a-9783-460b-a67d-c0367e033ae5">
											<gml:posList>35.66897437712767 139.74879751199455 40.955 35.66897355522674 139.74879516004896 40.955 35.66895496246174 139.74878597828067 40.955 35.66895305225742 139.74878698548667 40.955 35.66897437712767 139.74879751199455 40.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7994ab8e-c444-46ec-a372-003b89224d99">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7994ab8e-c444-46ec-a372-003b89224d99">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7994ab8e-c444-46ec-a372-003b89224d99">
											<gml:posList>35.668981371472114 139.74877139171676 40.703 35.6689627877113 139.74876219889754 40.703 35.66895496246174 139.74878597828067 40.703 35.66897355522674 139.74879516004896 40.703 35.668981371472114 139.74877139171676 40.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-55d3740c-5d78-4356-83bf-c9b2472cd170">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-55d3740c-5d78-4356-83bf-c9b2472cd170">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-55d3740c-5d78-4356-83bf-c9b2472cd170">
											<gml:posList>35.66897437712767 139.74879751199455 40.636 35.66897236780327 139.7487985634893 40.636 35.6689639938643 139.74882398931376 40.636 35.6689648518971 139.74882645168196 40.636 35.66897437712767 139.74879751199455 40.636</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a56e4120-6f4f-4ed5-bf4e-d19ed0debb80">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a56e4120-6f4f-4ed5-bf4e-d19ed0debb80">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a56e4120-6f4f-4ed5-bf4e-d19ed0debb80">
											<gml:posList>35.66896197483118 139.74875985798917 40.955 35.6689627877113 139.74876219889754 40.955 35.668981371472114 139.74877139171676 40.955 35.66898329069779 139.7487703955466 40.955 35.66896197483118 139.74875985798917 40.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e4939aea-2527-4408-b2c8-e2701cc31a41">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e4939aea-2527-4408-b2c8-e2701cc31a41">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e4939aea-2527-4408-b2c8-e2701cc31a41">
											<gml:posList>35.66895884327122 139.74870313975143 36.725 35.66895720451192 139.74870561579948 36.725 35.66894258857617 139.7487502794092 36.725 35.66896197483118 139.74875985798917 36.725 35.66898329069779 139.7487703955466 36.725 35.6689892959265 139.7487733606057 36.725 35.669007010504906 139.74872572231143 36.725 35.66896252108138 139.7487034341133 36.725 35.66895884327122 139.74870313975143 36.725</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f2058c75-fb7b-47d4-b975-88c25741f06f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f2058c75-fb7b-47d4-b975-88c25741f06f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f2058c75-fb7b-47d4-b975-88c25741f06f">
											<gml:posList>35.6689688283305 139.74882841369075 36.725 35.6689892959265 139.7487733606057 36.725 35.66898329069779 139.7487703955466 36.725 35.6689648518971 139.74882645168196 36.725 35.6689688283305 139.74882841369075 36.725</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e9482bde-1c52-4ce1-b202-834d0e24406b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e9482bde-1c52-4ce1-b202-834d0e24406b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e9482bde-1c52-4ce1-b202-834d0e24406b">
											<gml:posList>35.66898329069779 139.7487703955466 40.955 35.668981371472114 139.74877139171676 40.955 35.66897355522674 139.74879516004896 40.955 35.66897437712767 139.74879751199455 40.955 35.66898329069779 139.7487703955466 40.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-91f353ce-4242-4e12-b3b2-fad7bbfff2db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-91f353ce-4242-4e12-b3b2-fad7bbfff2db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-91f353ce-4242-4e12-b3b2-fad7bbfff2db">
											<gml:posList>35.66896288948743 139.7487017878608 37.1 35.66896252108138 139.7487034341133 37.1 35.669007010504906 139.74872572231143 37.1 35.66900887571768 139.7487248256115 37.1 35.66896288948743 139.7487017878608 37.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c8cd6d0b-1ad1-4264-b30c-8c5cb669e64a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8cd6d0b-1ad1-4264-b30c-8c5cb669e64a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8cd6d0b-1ad1-4264-b30c-8c5cb669e64a">
											<gml:posList>35.66896603034025 139.74883593901015 37.1 35.66896677097733 139.74883809221242 37.1 35.66896803049622 139.74883466660478 37.1 35.66897208806853 139.7488366506207 37.1 35.66900887571768 139.7487248256115 37.1 35.669007010504906 139.74872572231143 37.1 35.66896603034025 139.74883593901015 37.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6f1b59ba-0c4b-47d9-8060-bbfe9e7b4ada">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f1b59ba-0c4b-47d9-8060-bbfe9e7b4ada">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f1b59ba-0c4b-47d9-8060-bbfe9e7b4ada">
											<gml:posList>35.66895496246174 139.74878597828067 40.955 35.66895496246174 139.74878597828067 40.703 35.6689627877113 139.74876219889754 40.703 35.6689627877113 139.74876219889754 40.955 35.66895496246174 139.74878597828067 40.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-59791c21-f628-4cbf-9450-7e339dad770f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-59791c21-f628-4cbf-9450-7e339dad770f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-59791c21-f628-4cbf-9450-7e339dad770f">
											<gml:posList>35.66895838239111 139.7487014612361 37.1 35.66896288948743 139.7487017878608 37.1 35.66896288948743 139.7487017878608 5.81 35.66895838239111 139.7487014612361 5.81 35.66895838239111 139.7487014612361 37.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0996848b-ca8d-4abd-9e5a-05b70fad960a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0996848b-ca8d-4abd-9e5a-05b70fad960a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0996848b-ca8d-4abd-9e5a-05b70fad960a">
											<gml:posList>35.66895838239111 139.7487014612361 5.81 35.668955951091505 139.7487048880822 5.81 35.668955951091505 139.7487048880822 37.1 35.66895838239111 139.7487014612361 37.1 35.66895838239111 139.7487014612361 5.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8c25f11b-d7e4-4c86-8da3-e2beb3d79c6c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c25f11b-d7e4-4c86-8da3-e2beb3d79c6c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c25f11b-d7e4-4c86-8da3-e2beb3d79c6c">
											<gml:posList>35.66896252108138 139.7487034341133 36.725 35.66896252108138 139.7487034341133 37.1 35.66895884327122 139.74870313975143 37.1 35.66895884327122 139.74870313975143 36.725 35.66896252108138 139.7487034341133 36.725</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-16e3831e-02bf-4ac1-87e2-a3184fa5e9cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16e3831e-02bf-4ac1-87e2-a3184fa5e9cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16e3831e-02bf-4ac1-87e2-a3184fa5e9cd">
											<gml:posList>35.66895884327122 139.74870313975143 36.725 35.66895884327122 139.74870313975143 37.1 35.66895720451192 139.74870561579948 37.1 35.66895720451192 139.74870561579948 36.725 35.66895884327122 139.74870313975143 36.725</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-54d023e5-0631-4826-9863-785e73e76de4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-54d023e5-0631-4826-9863-785e73e76de4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-54d023e5-0631-4826-9863-785e73e76de4">
											<gml:posList>35.66900887571768 139.7487248256115 5.81 35.66896288948743 139.7487017878608 5.81 35.66896288948743 139.7487017878608 37.1 35.66900887571768 139.7487248256115 37.1 35.66900887571768 139.7487248256115 5.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4deb6518-55f3-4491-97b6-83fbaae44d09">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4deb6518-55f3-4491-97b6-83fbaae44d09">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4deb6518-55f3-4491-97b6-83fbaae44d09">
											<gml:posList>35.669007010504906 139.74872572231143 36.725 35.669007010504906 139.74872572231143 37.1 35.66896252108138 139.7487034341133 37.1 35.66896252108138 139.7487034341133 36.725 35.669007010504906 139.74872572231143 36.725</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-781e5975-a951-455b-85e1-6fccf58b34d9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-781e5975-a951-455b-85e1-6fccf58b34d9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-781e5975-a951-455b-85e1-6fccf58b34d9">
											<gml:posList>35.66892125379227 139.74881549575676 37.1 35.66892125379227 139.74881549575676 36.725 35.66892423994522 139.74880636856383 36.725 35.66894258857617 139.7487502794092 36.725 35.66895720451192 139.74870561579948 36.725 35.66895720451192 139.74870561579948 37.1 35.66892125379227 139.74881549575676 37.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c8972823-eec3-4868-9213-5470cd63526f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8972823-eec3-4868-9213-5470cd63526f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8972823-eec3-4868-9213-5470cd63526f">
											<gml:posList>35.668955951091505 139.7487048880822 5.81 35.66891943371721 139.74881649182055 5.81 35.66891943371721 139.74881649182055 37.1 35.668955951091505 139.7487048880822 37.1 35.668955951091505 139.7487048880822 5.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b31652b-2a00-4249-8619-4a0a9f254c55">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b31652b-2a00-4249-8619-4a0a9f254c55">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b31652b-2a00-4249-8619-4a0a9f254c55">
											<gml:posList>35.66898329069779 139.7487703955466 36.725 35.66896197483118 139.74875985798917 36.725 35.66896197483118 139.74875985798917 40.955 35.66898329069779 139.7487703955466 40.955 35.66898329069779 139.7487703955466 36.725</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c6680fdb-b1e4-40f8-9a01-5de90225cfa7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6680fdb-b1e4-40f8-9a01-5de90225cfa7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6680fdb-b1e4-40f8-9a01-5de90225cfa7">
											<gml:posList>35.6689627877113 139.74876219889754 40.955 35.6689627877113 139.74876219889754 40.703 35.668981371472114 139.74877139171676 40.703 35.668981371472114 139.74877139171676 40.955 35.6689627877113 139.74876219889754 40.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-62ea6a14-8e87-4b68-b845-243d788aeca3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-62ea6a14-8e87-4b68-b845-243d788aeca3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-62ea6a14-8e87-4b68-b845-243d788aeca3">
											<gml:posList>35.66896197483118 139.74875985798917 36.725 35.66895305225742 139.74878698548667 36.725 35.66895305225742 139.74878698548667 40.955 35.66896197483118 139.74875985798917 40.955 35.66896197483118 139.74875985798917 36.725</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3fd3934e-dfa0-43bb-a713-424b5e15fde5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3fd3934e-dfa0-43bb-a713-424b5e15fde5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3fd3934e-dfa0-43bb-a713-424b5e15fde5">
											<gml:posList>35.66897208806853 139.7488366506207 5.81 35.66900887571768 139.7487248256115 5.81 35.66900887571768 139.7487248256115 37.1 35.66897208806853 139.7488366506207 37.1 35.66897208806853 139.7488366506207 5.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0f131570-7b64-4414-b991-8778b13b9b7a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0f131570-7b64-4414-b991-8778b13b9b7a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0f131570-7b64-4414-b991-8778b13b9b7a">
											<gml:posList>35.669007010504906 139.74872572231143 37.1 35.669007010504906 139.74872572231143 36.725 35.6689892959265 139.7487733606057 36.725 35.6689688283305 139.74882841369075 36.725 35.66896603034025 139.74883593901015 36.725 35.66896603034025 139.74883593901015 37.1 35.669007010504906 139.74872572231143 37.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7329679e-789c-4a08-aa76-3c728d8d5851">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7329679e-789c-4a08-aa76-3c728d8d5851">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7329679e-789c-4a08-aa76-3c728d8d5851">
											<gml:posList>35.668981371472114 139.74877139171676 40.955 35.668981371472114 139.74877139171676 40.703 35.66897355522674 139.74879516004896 40.703 35.66897355522674 139.74879516004896 40.955 35.668981371472114 139.74877139171676 40.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a0ff8329-af2e-482b-9bf2-6282ddb05edd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a0ff8329-af2e-482b-9bf2-6282ddb05edd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a0ff8329-af2e-482b-9bf2-6282ddb05edd">
											<gml:posList>35.66897355522674 139.74879516004896 40.955 35.66897355522674 139.74879516004896 40.703 35.66895496246174 139.74878597828067 40.703 35.66895496246174 139.74878597828067 40.955 35.66897355522674 139.74879516004896 40.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b0e2c5c8-a9d6-4f5a-b29c-4089c8d46bf9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b0e2c5c8-a9d6-4f5a-b29c-4089c8d46bf9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b0e2c5c8-a9d6-4f5a-b29c-4089c8d46bf9">
											<gml:posList>35.66895955484608 139.74879223655682 40.636 35.66895955484608 139.74879223655682 40.424 35.66896013049151 139.74879047962563 40.424 35.66896013049151 139.74879047962563 40.636 35.66895955484608 139.74879223655682 40.636</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b48d128a-8563-4fc5-8928-de1ebb880c6d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b48d128a-8563-4fc5-8928-de1ebb880c6d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b48d128a-8563-4fc5-8928-de1ebb880c6d">
											<gml:posList>35.66897295246252 139.74879680654834 40.636 35.66897437712767 139.74879751199455 40.636 35.66897437712767 139.74879751199455 40.955 35.66895305225742 139.74878698548667 40.955 35.66895305225742 139.74878698548667 36.725 35.6689586968126 139.74878977418916 36.725 35.6689586968126 139.74878977418916 40.636 35.66896013049151 139.74879047962563 40.636 35.66896013049151 139.74879047962563 40.424 35.66897295246252 139.74879680654834 40.424 35.66897295246252 139.74879680654834 40.636</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eaf23138-a5d5-48ec-974d-ff87cebf899e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eaf23138-a5d5-48ec-974d-ff87cebf899e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eaf23138-a5d5-48ec-974d-ff87cebf899e">
											<gml:posList>35.66891943371721 139.74881649182055 5.81 35.66896677097733 139.74883809221242 5.81 35.66896677097733 139.74883809221242 37.1 35.66891943371721 139.74881649182055 37.1 35.66891943371721 139.74881649182055 5.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e69fbd13-3497-4afa-a04e-4b47be4348db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e69fbd13-3497-4afa-a04e-4b47be4348db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e69fbd13-3497-4afa-a04e-4b47be4348db">
											<gml:posList>35.66896603034025 139.74883593901015 37.1 35.66896603034025 139.74883593901015 36.725 35.66892125379227 139.74881549575676 36.725 35.66892125379227 139.74881549575676 37.1 35.66896603034025 139.74883593901015 37.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b73baa96-e5cc-4fc1-8d17-ef5365e7c688">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b73baa96-e5cc-4fc1-8d17-ef5365e7c688">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b73baa96-e5cc-4fc1-8d17-ef5365e7c688">
											<gml:posList>35.668949180589834 139.74881870281624 36.725 35.668949180589834 139.74881870281624 40.636 35.6689586968126 139.74878977418916 40.636 35.6689586968126 139.74878977418916 36.725 35.668949180589834 139.74881870281624 36.725</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b3cad81d-593c-4b33-b61e-6691475e550f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b3cad81d-593c-4b33-b61e-6691475e550f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b3cad81d-593c-4b33-b61e-6691475e550f">
											<gml:posList>35.66895118991441 139.74881765132233 40.636 35.66895118991441 139.74881765132233 40.424 35.66895955484608 139.74879223655682 40.424 35.66895955484608 139.74879223655682 40.636 35.66895118991441 139.74881765132233 40.636</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d67475d6-6093-420b-8132-52254e67029b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d67475d6-6093-420b-8132-52254e67029b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d67475d6-6093-420b-8132-52254e67029b">
											<gml:posList>35.6689648518971 139.74882645168196 36.725 35.6689648518971 139.74882645168196 40.636 35.668949180589834 139.74881870281624 40.636 35.668949180589834 139.74881870281624 36.725 35.6689648518971 139.74882645168196 36.725</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a30a99e5-190c-4b91-85c6-1b14a73a9118">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a30a99e5-190c-4b91-85c6-1b14a73a9118">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a30a99e5-190c-4b91-85c6-1b14a73a9118">
											<gml:posList>35.6689639938643 139.74882398931376 40.636 35.6689639938643 139.74882398931376 40.424 35.66895118991441 139.74881765132233 40.424 35.66895118991441 139.74881765132233 40.636 35.6689639938643 139.74882398931376 40.636</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f93dc8fe-5608-4780-b48e-57a9a6df3675">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f93dc8fe-5608-4780-b48e-57a9a6df3675">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f93dc8fe-5608-4780-b48e-57a9a6df3675">
											<gml:posList>35.66896677097733 139.74883809221242 5.81 35.66896803049622 139.74883466660478 5.81 35.66896803049622 139.74883466660478 37.1 35.66896677097733 139.74883809221242 37.1 35.66896677097733 139.74883809221242 5.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e1db354b-c58b-4fc3-8823-01f156cf057d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e1db354b-c58b-4fc3-8823-01f156cf057d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e1db354b-c58b-4fc3-8823-01f156cf057d">
											<gml:posList>35.66897236780327 139.7487985634893 40.636 35.66897236780327 139.7487985634893 40.424 35.6689639938643 139.74882398931376 40.424 35.6689639938643 139.74882398931376 40.636 35.66897236780327 139.7487985634893 40.636</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0ee2745a-610a-4aa1-8f31-d5b11494c697">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ee2745a-610a-4aa1-8f31-d5b11494c697">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ee2745a-610a-4aa1-8f31-d5b11494c697">
											<gml:posList>35.66896803049622 139.74883466660478 5.81 35.66897208806853 139.7488366506207 5.81 35.66897208806853 139.7488366506207 37.1 35.66896803049622 139.74883466660478 37.1 35.66896803049622 139.74883466660478 5.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c66e7844-8132-4801-bb27-760510608e17">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c66e7844-8132-4801-bb27-760510608e17">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c66e7844-8132-4801-bb27-760510608e17">
											<gml:posList>35.66897295246252 139.74879680654834 40.636 35.66897295246252 139.74879680654834 40.424 35.66897236780327 139.7487985634893 40.424 35.66897236780327 139.7487985634893 40.636 35.66897295246252 139.74879680654834 40.636</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-646ee386-04db-488f-b9d4-9190ba157f9e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-646ee386-04db-488f-b9d4-9190ba157f9e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-646ee386-04db-488f-b9d4-9190ba157f9e">
											<gml:posList>35.6689648518971 139.74882645168196 36.725 35.66898329069779 139.7487703955466 36.725 35.66898329069779 139.7487703955466 40.955 35.66897437712767 139.74879751199455 40.955 35.66897437712767 139.74879751199455 40.636 35.6689648518971 139.74882645168196 40.636 35.6689648518971 139.74882645168196 36.725</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7615</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">69.0633</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>