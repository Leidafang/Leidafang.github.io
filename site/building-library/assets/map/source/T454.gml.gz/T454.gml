<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_84cace58-a0a0-4f46-9297-72caf5fa711e">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>0.85</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>29</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103029002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">8</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.6671418202905 139.73839354747176 0 35.667125313325236 139.7383785447129 0 35.66706336226547 139.7384590315138 0 35.6670888924319 139.73848606353184 0 35.66714165943392 139.7384181798254 0 35.6671418202905 139.73839354747176 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6671418202905 139.73839354747176 12.723 35.66714165943392 139.7384181798254 12.723 35.6670888924319 139.73848606353184 12.723 35.66706336226547 139.7384590315138 12.723 35.667125313325236 139.7383785447129 12.723 35.6671418202905 139.73839354747176 12.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6671418202905 139.73839354747176 12.723 35.667125313325236 139.7383785447129 12.723 35.667125313325236 139.7383785447129 20.75 35.6671418202905 139.73839354747176 20.75 35.6671418202905 139.73839354747176 12.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667125313325236 139.7383785447129 12.723 35.66706336226547 139.7384590315138 12.723 35.66706336226547 139.7384590315138 20.75 35.667125313325236 139.7383785447129 20.75 35.667125313325236 139.7383785447129 12.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66706336226547 139.7384590315138 12.723 35.6670888924319 139.73848606353184 12.723 35.6670888924319 139.73848606353184 20.75 35.66706336226547 139.7384590315138 20.75 35.66706336226547 139.7384590315138 12.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6670888924319 139.73848606353184 12.723 35.66714165943392 139.7384181798254 12.723 35.66714165943392 139.7384181798254 20.75 35.6670888924319 139.73848606353184 20.75 35.6670888924319 139.73848606353184 12.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66714165943392 139.7384181798254 12.723 35.6671418202905 139.73839354747176 12.723 35.6671418202905 139.73839354747176 20.75 35.66714165943392 139.7384181798254 20.75 35.66714165943392 139.7384181798254 12.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6671418202905 139.73839354747176 20.75 35.667125313325236 139.7383785447129 20.75 35.66706336226547 139.7384590315138 20.75 35.6670888924319 139.73848606353184 20.75 35.66714165943392 139.7384181798254 20.75 35.6671418202905 139.73839354747176 20.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-b1965ffa-037b-4bf1-9d8d-da7927523eb2"/>
							<gml:surfaceMember xlink:href="#poly-4efc2378-b936-4acb-8f86-71d776318d81"/>
							<gml:surfaceMember xlink:href="#poly-06de0ee6-ea8c-4d14-858b-21c1a400d279"/>
							<gml:surfaceMember xlink:href="#poly-575e7950-9e01-4a02-9199-5bb1f25dfdfb"/>
							<gml:surfaceMember xlink:href="#poly-607db3ca-8f72-48f3-ac62-467c2865e73d"/>
							<gml:surfaceMember xlink:href="#poly-aba8db04-3354-4a42-8411-c0e853536980"/>
							<gml:surfaceMember xlink:href="#poly-8f516bce-749b-4913-875b-ecd723ea8975"/>
							<gml:surfaceMember xlink:href="#poly-72208ebe-3692-43a1-b0a7-d4aa72bfc3c7"/>
							<gml:surfaceMember xlink:href="#poly-a5e73ba2-1dbd-4aa8-a6b4-e1798e13df24"/>
							<gml:surfaceMember xlink:href="#poly-daa8dfd5-2872-4b7e-8298-cb037f2aecaf"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-b1965ffa-037b-4bf1-9d8d-da7927523eb2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b1965ffa-037b-4bf1-9d8d-da7927523eb2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b1965ffa-037b-4bf1-9d8d-da7927523eb2">
											<gml:posList>35.6671418202905 139.73839354747176 12.723 35.66714165943392 139.7384181798254 12.723 35.667088892431885 139.73848606353184 12.723 35.667063362265466 139.7384590315138 12.723 35.66712531332522 139.7383785447129 12.723 35.6671418202905 139.73839354747176 12.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4efc2378-b936-4acb-8f86-71d776318d81">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4efc2378-b936-4acb-8f86-71d776318d81">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4efc2378-b936-4acb-8f86-71d776318d81">
											<gml:posList>35.66710909620242 139.73839961722783 19.934 35.66713377139245 139.73842831817186 19.934 35.66714165943392 139.7384181798254 19.934 35.6671418202905 139.73839354747176 19.934 35.66712531332522 139.7383785447129 19.934 35.66710909620242 139.73839961722783 19.934</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-06de0ee6-ea8c-4d14-858b-21c1a400d279">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-06de0ee6-ea8c-4d14-858b-21c1a400d279">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-06de0ee6-ea8c-4d14-858b-21c1a400d279">
											<gml:posList>35.66707278046345 139.73846900577703 22.77 35.66711814522556 139.73841007794243 22.77 35.66710909620242 139.73839961722783 22.77 35.667063362265466 139.7384590315138 22.77 35.66707278046345 139.73846900577703 22.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-575e7950-9e01-4a02-9199-5bb1f25dfdfb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-575e7950-9e01-4a02-9199-5bb1f25dfdfb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-575e7950-9e01-4a02-9199-5bb1f25dfdfb">
											<gml:posList>35.667088892431885 139.73848606353184 19.934 35.66713377139245 139.73842831817186 19.934 35.66711814522556 139.73841007794243 22.77 35.66707278046345 139.73846900577703 22.77 35.667088892431885 139.73848606353184 19.934</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-607db3ca-8f72-48f3-ac62-467c2865e73d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-607db3ca-8f72-48f3-ac62-467c2865e73d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-607db3ca-8f72-48f3-ac62-467c2865e73d">
											<gml:posList>35.6671418202905 139.73839354747176 12.723 35.66712531332522 139.7383785447129 12.723 35.66712531332522 139.7383785447129 19.934 35.6671418202905 139.73839354747176 19.934 35.6671418202905 139.73839354747176 12.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aba8db04-3354-4a42-8411-c0e853536980">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aba8db04-3354-4a42-8411-c0e853536980">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aba8db04-3354-4a42-8411-c0e853536980">
											<gml:posList>35.66714165943392 139.7384181798254 12.723 35.6671418202905 139.73839354747176 12.723 35.6671418202905 139.73839354747176 19.934 35.66714165943392 139.7384181798254 19.934 35.66714165943392 139.7384181798254 12.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8f516bce-749b-4913-875b-ecd723ea8975">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f516bce-749b-4913-875b-ecd723ea8975">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f516bce-749b-4913-875b-ecd723ea8975">
											<gml:posList>35.66711814522556 139.73841007794243 22.77 35.66713377139245 139.73842831817186 19.934 35.66710909620242 139.73839961722783 19.934 35.66710909620242 139.73839961722783 22.77 35.66711814522556 139.73841007794243 22.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-72208ebe-3692-43a1-b0a7-d4aa72bfc3c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-72208ebe-3692-43a1-b0a7-d4aa72bfc3c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-72208ebe-3692-43a1-b0a7-d4aa72bfc3c7">
											<gml:posList>35.667063362265466 139.7384590315138 12.723 35.667063362265466 139.7384590315138 22.77 35.66710909620242 139.73839961722783 22.77 35.66710909620242 139.73839961722783 19.934 35.66712531332522 139.7383785447129 19.934 35.66712531332522 139.7383785447129 12.723 35.667063362265466 139.7384590315138 12.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a5e73ba2-1dbd-4aa8-a6b4-e1798e13df24">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5e73ba2-1dbd-4aa8-a6b4-e1798e13df24">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5e73ba2-1dbd-4aa8-a6b4-e1798e13df24">
											<gml:posList>35.667088892431885 139.73848606353184 12.723 35.66714165943392 139.7384181798254 12.723 35.66714165943392 139.7384181798254 19.934 35.66713377139245 139.73842831817186 19.934 35.667088892431885 139.73848606353184 19.934 35.667088892431885 139.73848606353184 12.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-daa8dfd5-2872-4b7e-8298-cb037f2aecaf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-daa8dfd5-2872-4b7e-8298-cb037f2aecaf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-daa8dfd5-2872-4b7e-8298-cb037f2aecaf">
											<gml:posList>35.667063362265466 139.7384590315138 22.77 35.667063362265466 139.7384590315138 12.723 35.667088892431885 139.73848606353184 12.723 35.667088892431885 139.73848606353184 19.934 35.66707278046345 139.73846900577703 22.77 35.667063362265466 139.7384590315138 22.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区六本木二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6916</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">36.85865</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1221</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>