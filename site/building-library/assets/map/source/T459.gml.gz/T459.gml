<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_85ee4033-c001-4cfb-af82-511e504db9c1">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">422</bldg:usage>
			<bldg:measuredHeight uom="m">6.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.667882029426956 139.7420079991289 0 35.66780448565721 139.74221210530703 0 35.66787428207183 139.74225190174226 0 35.66792177999016 139.74212691842393 0 35.66793070742812 139.74213198939358 0 35.667960663211865 139.74205286648998 0 35.667882029426956 139.7420079991289 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667882029426956 139.7420079991289 28.745 35.667960663211865 139.74205286648998 28.745 35.66793070742812 139.74213198939358 28.745 35.66792177999016 139.74212691842393 28.745 35.66787428207183 139.74225190174226 28.745 35.66780448565721 139.74221210530703 28.745 35.667882029426956 139.7420079991289 28.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667882029426956 139.7420079991289 28.745 35.66780448565721 139.74221210530703 28.745 35.66780448565721 139.74221210530703 35.1 35.667882029426956 139.7420079991289 35.1 35.667882029426956 139.7420079991289 28.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66780448565721 139.74221210530703 28.745 35.66787428207183 139.74225190174226 28.745 35.66787428207183 139.74225190174226 35.1 35.66780448565721 139.74221210530703 35.1 35.66780448565721 139.74221210530703 28.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66787428207183 139.74225190174226 28.745 35.66792177999016 139.74212691842393 28.745 35.66792177999016 139.74212691842393 35.1 35.66787428207183 139.74225190174226 35.1 35.66787428207183 139.74225190174226 28.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66792177999016 139.74212691842393 28.745 35.66793070742812 139.74213198939358 28.745 35.66793070742812 139.74213198939358 35.1 35.66792177999016 139.74212691842393 35.1 35.66792177999016 139.74212691842393 28.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66793070742812 139.74213198939358 28.745 35.667960663211865 139.74205286648998 28.745 35.667960663211865 139.74205286648998 35.1 35.66793070742812 139.74213198939358 35.1 35.66793070742812 139.74213198939358 28.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667960663211865 139.74205286648998 28.745 35.667882029426956 139.7420079991289 28.745 35.667882029426956 139.7420079991289 35.1 35.667960663211865 139.74205286648998 35.1 35.667960663211865 139.74205286648998 28.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667882029426956 139.7420079991289 35.1 35.66780448565721 139.74221210530703 35.1 35.66787428207183 139.74225190174226 35.1 35.66792177999016 139.74212691842393 35.1 35.66793070742812 139.74213198939358 35.1 35.667960663211865 139.74205286648998 35.1 35.667882029426956 139.7420079991289 35.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-36272e6a-0109-4f88-b16b-6f95de9aa68e"/>
							<gml:surfaceMember xlink:href="#poly-2c95a161-e6fa-4a52-b6d0-428788a69de0"/>
							<gml:surfaceMember xlink:href="#poly-3a47ccde-4b06-4b60-b30e-fad5eeb61aec"/>
							<gml:surfaceMember xlink:href="#poly-46c1711e-8d37-45d6-b186-938ed585c567"/>
							<gml:surfaceMember xlink:href="#poly-34831d19-5bac-4358-a67f-8a388bb210e2"/>
							<gml:surfaceMember xlink:href="#poly-955f6fda-239b-4c69-be9e-5fd53f799194"/>
							<gml:surfaceMember xlink:href="#poly-522df0c5-af84-4744-9780-3e964e05a366"/>
							<gml:surfaceMember xlink:href="#poly-6622cb7c-4d3b-4c16-9ba7-523e9dccbe37"/>
							<gml:surfaceMember xlink:href="#poly-832b1050-cb05-4322-9e9a-52c4de6d7899"/>
							<gml:surfaceMember xlink:href="#poly-50c2d02a-7a60-4848-8bf2-6fb4db2e2848"/>
							<gml:surfaceMember xlink:href="#poly-2048a6ac-af15-47a1-83f4-aef86e8b4052"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-36272e6a-0109-4f88-b16b-6f95de9aa68e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36272e6a-0109-4f88-b16b-6f95de9aa68e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36272e6a-0109-4f88-b16b-6f95de9aa68e">
											<gml:posList>35.66788202942691 139.7420079991289 28.745 35.66796066321187 139.74205286648996 28.745 35.66793070742813 139.74213198939358 28.745 35.66792177999014 139.7421269184239 28.745 35.66787428207183 139.74225190174224 28.745 35.667804485657214 139.74221210530703 28.745 35.66788202942691 139.7420079991289 28.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2c95a161-e6fa-4a52-b6d0-428788a69de0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c95a161-e6fa-4a52-b6d0-428788a69de0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c95a161-e6fa-4a52-b6d0-428788a69de0">
											<gml:posList>35.66785198351816 139.74208709998229 34.1 35.667804485657214 139.74221210530703 34.1 35.66783938386626 139.742232003516 35.414 35.667886881755884 139.74210700919446 35.414 35.66785198351816 139.74208709998229 34.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3a47ccde-4b06-4b60-b30e-fad5eeb61aec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a47ccde-4b06-4b60-b30e-fad5eeb61aec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a47ccde-4b06-4b60-b30e-fad5eeb61aec">
											<gml:posList>35.66787428207183 139.74225190174224 34.1 35.66792177999014 139.7421269184239 34.1 35.667886881755884 139.74210700919446 35.414 35.66783938386626 139.742232003516 35.414 35.66787428207183 139.74225190174224 34.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-46c1711e-8d37-45d6-b186-938ed585c567">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-46c1711e-8d37-45d6-b186-938ed585c567">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-46c1711e-8d37-45d6-b186-938ed585c567">
											<gml:posList>35.66788202942691 139.7420079991289 36.129 35.66785198351816 139.74208709998229 36.129 35.66789134547535 139.74210954467694 37.22 35.66792134632159 139.74203043279846 37.22 35.66788202942691 139.7420079991289 36.129</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-34831d19-5bac-4358-a67f-8a388bb210e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-34831d19-5bac-4358-a67f-8a388bb210e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-34831d19-5bac-4358-a67f-8a388bb210e2">
											<gml:posList>35.66793070742813 139.74213198939358 36.129 35.66796066321187 139.74205286648996 36.129 35.66792134632159 139.74203043279846 37.22 35.66789134547535 139.74210954467694 37.22 35.66793070742813 139.74213198939358 36.129</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-955f6fda-239b-4c69-be9e-5fd53f799194">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-955f6fda-239b-4c69-be9e-5fd53f799194">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-955f6fda-239b-4c69-be9e-5fd53f799194">
											<gml:posList>35.66792134632159 139.74203043279846 37.22 35.66796066321187 139.74205286648996 36.129 35.66796066321187 139.74205286648996 28.745 35.66788202942691 139.7420079991289 28.745 35.66788202942691 139.7420079991289 36.129 35.66792134632159 139.74203043279846 37.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-522df0c5-af84-4744-9780-3e964e05a366">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-522df0c5-af84-4744-9780-3e964e05a366">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-522df0c5-af84-4744-9780-3e964e05a366">
											<gml:posList>35.66793070742813 139.74213198939358 28.745 35.66796066321187 139.74205286648996 28.745 35.66796066321187 139.74205286648996 36.129 35.66793070742813 139.74213198939358 36.129 35.66793070742813 139.74213198939358 28.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6622cb7c-4d3b-4c16-9ba7-523e9dccbe37">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6622cb7c-4d3b-4c16-9ba7-523e9dccbe37">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6622cb7c-4d3b-4c16-9ba7-523e9dccbe37">
											<gml:posList>35.66792177999014 139.7421269184239 34.1 35.66792177999014 139.7421269184239 28.745 35.66793070742813 139.74213198939358 28.745 35.66793070742813 139.74213198939358 36.129 35.66789134547535 139.74210954467694 37.22 35.66785198351816 139.74208709998229 36.129 35.66785198351816 139.74208709998229 34.1 35.667886881755884 139.74210700919446 35.414 35.66792177999014 139.7421269184239 34.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-832b1050-cb05-4322-9e9a-52c4de6d7899">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-832b1050-cb05-4322-9e9a-52c4de6d7899">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-832b1050-cb05-4322-9e9a-52c4de6d7899">
											<gml:posList>35.667804485657214 139.74221210530703 28.745 35.667804485657214 139.74221210530703 34.1 35.66785198351816 139.74208709998229 34.1 35.66785198351816 139.74208709998229 36.129 35.66788202942691 139.7420079991289 36.129 35.66788202942691 139.7420079991289 28.745 35.667804485657214 139.74221210530703 28.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-50c2d02a-7a60-4848-8bf2-6fb4db2e2848">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50c2d02a-7a60-4848-8bf2-6fb4db2e2848">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50c2d02a-7a60-4848-8bf2-6fb4db2e2848">
											<gml:posList>35.66787428207183 139.74225190174224 28.745 35.66792177999014 139.7421269184239 28.745 35.66792177999014 139.7421269184239 34.1 35.66787428207183 139.74225190174224 34.1 35.66787428207183 139.74225190174224 28.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2048a6ac-af15-47a1-83f4-aef86e8b4052">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2048a6ac-af15-47a1-83f4-aef86e8b4052">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2048a6ac-af15-47a1-83f4-aef86e8b4052">
											<gml:posList>35.66783938386626 139.742232003516 35.414 35.667804485657214 139.74221210530703 34.1 35.667804485657214 139.74221210530703 28.745 35.66787428207183 139.74225190174224 28.745 35.66787428207183 139.74225190174224 34.1 35.66783938386626 139.742232003516 35.414</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-3568</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">182.6661</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1003</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">6</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1123</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.08</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">22</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>