<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_86c1f1e0-f5b7-4418-ba26-5fd509f4201b">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="説明注記">
				<gen:value>配電室</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">422</bldg:usage>
			<bldg:storeysAboveGround>0</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66974191376608 139.7485016595009 0 35.669684057471976 139.7484673340046 0 35.66965729835558 139.74853507529238 0 35.66969661464995 139.7485583963525 0 35.66973991627529 139.74850670971492 0 35.66974191376608 139.7485016595009 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66974191376608 139.7485016595009 6.38 35.66973991627529 139.74850670971492 6.38 35.66969661464995 139.7485583963525 6.38 35.66965729835558 139.74853507529238 6.38 35.669684057471976 139.7484673340046 6.38 35.66974191376608 139.7485016595009 6.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66974191376608 139.7485016595009 6.38 35.669684057471976 139.7484673340046 6.38 35.669684057471976 139.7484673340046 9.379999999999999 35.66974191376608 139.7485016595009 9.379999999999999 35.66974191376608 139.7485016595009 6.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669684057471976 139.7484673340046 6.38 35.66965729835558 139.74853507529238 6.38 35.66965729835558 139.74853507529238 9.379999999999999 35.669684057471976 139.7484673340046 9.379999999999999 35.669684057471976 139.7484673340046 6.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66965729835558 139.74853507529238 6.38 35.66969661464995 139.7485583963525 6.38 35.66969661464995 139.7485583963525 9.379999999999999 35.66965729835558 139.74853507529238 9.379999999999999 35.66965729835558 139.74853507529238 6.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66969661464995 139.7485583963525 6.38 35.66973991627529 139.74850670971492 6.38 35.66973991627529 139.74850670971492 9.379999999999999 35.66969661464995 139.7485583963525 9.379999999999999 35.66969661464995 139.7485583963525 6.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66973991627529 139.74850670971492 6.38 35.66974191376608 139.7485016595009 6.38 35.66974191376608 139.7485016595009 9.379999999999999 35.66973991627529 139.74850670971492 9.379999999999999 35.66973991627529 139.74850670971492 6.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66974191376608 139.7485016595009 9.379999999999999 35.669684057471976 139.7484673340046 9.379999999999999 35.66965729835558 139.74853507529238 9.379999999999999 35.66969661464995 139.7485583963525 9.379999999999999 35.66973991627529 139.74850670971492 9.379999999999999 35.66974191376608 139.7485016595009 9.379999999999999</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-94490385-d0d5-4789-adca-38a6a0a46945"/>
							<gml:surfaceMember xlink:href="#poly-60a8ad69-7465-4e78-8e6c-ae1a378ceced"/>
							<gml:surfaceMember xlink:href="#poly-c09d5a4d-4aa8-4fb0-9a59-d3df078269ee"/>
							<gml:surfaceMember xlink:href="#poly-093b706e-eb33-43c6-af11-d9d64ed64a7e"/>
							<gml:surfaceMember xlink:href="#poly-6b574f9b-e20f-42c0-931a-a858eebb8dc4"/>
							<gml:surfaceMember xlink:href="#poly-f3e22e68-0d1f-4bcc-a0ac-9b7e9b6e0714"/>
							<gml:surfaceMember xlink:href="#poly-634377c2-fe5c-4274-805c-f52b4d5659c3"/>
							<gml:surfaceMember xlink:href="#poly-d3a43231-6f77-4e59-950f-5db7d2a8767e"/>
							<gml:surfaceMember xlink:href="#poly-bb46dc56-c4f3-4cf5-8503-ec727f5ebe8f"/>
							<gml:surfaceMember xlink:href="#poly-d0927855-66d6-4507-8eb6-c049a902a805"/>
							<gml:surfaceMember xlink:href="#poly-91c1a500-0c1a-46c6-96c2-456ff185fd43"/>
							<gml:surfaceMember xlink:href="#poly-6e611cbe-f293-4237-9d3f-30e44c578dd6"/>
							<gml:surfaceMember xlink:href="#poly-ad04f403-504d-4339-aa67-969aef7b29b9"/>
							<gml:surfaceMember xlink:href="#poly-7a0049b9-a4b5-4507-b546-7983a5afc3cb"/>
							<gml:surfaceMember xlink:href="#poly-b0194017-7c04-48b2-ac18-18c3b8ad2683"/>
							<gml:surfaceMember xlink:href="#poly-0675d981-f562-4fa1-a2d6-4283c665ffea"/>
							<gml:surfaceMember xlink:href="#poly-90202e6b-8d74-4d59-9814-2a31b1fee874"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-94490385-d0d5-4789-adca-38a6a0a46945">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-94490385-d0d5-4789-adca-38a6a0a46945">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-94490385-d0d5-4789-adca-38a6a0a46945">
											<gml:posList>35.66974191376608 139.7485016595009 6.38 35.669739916275276 139.7485067097149 6.38 35.66969661464996 139.74855839635248 6.38 35.669657298355574 139.74853507529238 6.38 35.66968405747194 139.74846733400457 6.38 35.66974191376608 139.7485016595009 6.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-60a8ad69-7465-4e78-8e6c-ae1a378ceced">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-60a8ad69-7465-4e78-8e6c-ae1a378ceced">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-60a8ad69-7465-4e78-8e6c-ae1a378ceced">
											<gml:posList>35.669657298355574 139.74853507529238 9.95 35.66965977639115 139.74853402328628 9.95 35.66968491592455 139.74847038183734 9.95 35.66968405747194 139.74846733400457 9.95 35.669657298355574 139.74853507529238 9.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c09d5a4d-4aa8-4fb0-9a59-d3df078269ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c09d5a4d-4aa8-4fb0-9a59-d3df078269ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c09d5a4d-4aa8-4fb0-9a59-d3df078269ee">
											<gml:posList>35.66969661464996 139.74855839635248 9.95 35.66969626118597 139.74855565727705 9.95 35.66965977639115 139.74853402328628 9.95 35.669657298355574 139.74853507529238 9.95 35.66969661464996 139.74855839635248 9.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-093b706e-eb33-43c6-af11-d9d64ed64a7e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-093b706e-eb33-43c6-af11-d9d64ed64a7e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-093b706e-eb33-43c6-af11-d9d64ed64a7e">
											<gml:posList>35.6697383739944 139.74850538580594 9.699 35.66973942672489 139.74850272256475 9.699 35.66968491592455 139.74847038183734 9.699 35.66965977639115 139.74853402328628 9.699 35.66969626118597 139.74855565727705 9.699 35.6697383739944 139.74850538580594 9.699</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6b574f9b-e20f-42c0-931a-a858eebb8dc4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b574f9b-e20f-42c0-931a-a858eebb8dc4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b574f9b-e20f-42c0-931a-a858eebb8dc4">
											<gml:posList>35.66968405747194 139.74846733400457 9.95 35.66968491592455 139.74847038183734 9.95 35.66973942672489 139.74850272256475 9.95 35.66974191376608 139.7485016595009 9.95 35.66968405747194 139.74846733400457 9.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f3e22e68-0d1f-4bcc-a0ac-9b7e9b6e0714">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f3e22e68-0d1f-4bcc-a0ac-9b7e9b6e0714">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f3e22e68-0d1f-4bcc-a0ac-9b7e9b6e0714">
											<gml:posList>35.669739916275276 139.7485067097149 9.95 35.6697383739944 139.74850538580594 9.95 35.66969626118597 139.74855565727705 9.95 35.66969661464996 139.74855839635248 9.95 35.669739916275276 139.7485067097149 9.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-634377c2-fe5c-4274-805c-f52b4d5659c3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-634377c2-fe5c-4274-805c-f52b4d5659c3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-634377c2-fe5c-4274-805c-f52b4d5659c3">
											<gml:posList>35.669739916275276 139.7485067097149 9.95 35.66974191376608 139.7485016595009 9.95 35.66973942672489 139.74850272256475 9.95 35.6697383739944 139.74850538580594 9.95 35.669739916275276 139.7485067097149 9.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d3a43231-6f77-4e59-950f-5db7d2a8767e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3a43231-6f77-4e59-950f-5db7d2a8767e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3a43231-6f77-4e59-950f-5db7d2a8767e">
											<gml:posList>35.66974191376608 139.7485016595009 6.38 35.66968405747194 139.74846733400457 6.38 35.66968405747194 139.74846733400457 9.95 35.66974191376608 139.7485016595009 9.95 35.66974191376608 139.7485016595009 6.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bb46dc56-c4f3-4cf5-8503-ec727f5ebe8f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb46dc56-c4f3-4cf5-8503-ec727f5ebe8f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb46dc56-c4f3-4cf5-8503-ec727f5ebe8f">
											<gml:posList>35.66968491592455 139.74847038183734 9.95 35.66968491592455 139.74847038183734 9.699 35.66973942672489 139.74850272256475 9.699 35.66973942672489 139.74850272256475 9.95 35.66968491592455 139.74847038183734 9.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d0927855-66d6-4507-8eb6-c049a902a805">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d0927855-66d6-4507-8eb6-c049a902a805">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d0927855-66d6-4507-8eb6-c049a902a805">
											<gml:posList>35.66968405747194 139.74846733400457 6.38 35.669657298355574 139.74853507529238 6.38 35.669657298355574 139.74853507529238 9.95 35.66968405747194 139.74846733400457 9.95 35.66968405747194 139.74846733400457 6.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-91c1a500-0c1a-46c6-96c2-456ff185fd43">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-91c1a500-0c1a-46c6-96c2-456ff185fd43">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-91c1a500-0c1a-46c6-96c2-456ff185fd43">
											<gml:posList>35.66965977639115 139.74853402328628 9.95 35.66965977639115 139.74853402328628 9.699 35.66968491592455 139.74847038183734 9.699 35.66968491592455 139.74847038183734 9.95 35.66965977639115 139.74853402328628 9.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6e611cbe-f293-4237-9d3f-30e44c578dd6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e611cbe-f293-4237-9d3f-30e44c578dd6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e611cbe-f293-4237-9d3f-30e44c578dd6">
											<gml:posList>35.66973942672489 139.74850272256475 9.95 35.66973942672489 139.74850272256475 9.699 35.6697383739944 139.74850538580594 9.699 35.6697383739944 139.74850538580594 9.95 35.66973942672489 139.74850272256475 9.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ad04f403-504d-4339-aa67-969aef7b29b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad04f403-504d-4339-aa67-969aef7b29b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad04f403-504d-4339-aa67-969aef7b29b9">
											<gml:posList>35.669739916275276 139.7485067097149 6.38 35.66974191376608 139.7485016595009 6.38 35.66974191376608 139.7485016595009 9.95 35.669739916275276 139.7485067097149 9.95 35.669739916275276 139.7485067097149 6.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7a0049b9-a4b5-4507-b546-7983a5afc3cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a0049b9-a4b5-4507-b546-7983a5afc3cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a0049b9-a4b5-4507-b546-7983a5afc3cb">
											<gml:posList>35.6697383739944 139.74850538580594 9.95 35.6697383739944 139.74850538580594 9.699 35.66969626118597 139.74855565727705 9.699 35.66969626118597 139.74855565727705 9.95 35.6697383739944 139.74850538580594 9.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b0194017-7c04-48b2-ac18-18c3b8ad2683">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b0194017-7c04-48b2-ac18-18c3b8ad2683">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b0194017-7c04-48b2-ac18-18c3b8ad2683">
											<gml:posList>35.66969661464996 139.74855839635248 6.38 35.669739916275276 139.7485067097149 6.38 35.669739916275276 139.7485067097149 9.95 35.66969661464996 139.74855839635248 9.95 35.66969661464996 139.74855839635248 6.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0675d981-f562-4fa1-a2d6-4283c665ffea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0675d981-f562-4fa1-a2d6-4283c665ffea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0675d981-f562-4fa1-a2d6-4283c665ffea">
											<gml:posList>35.66969626118597 139.74855565727705 9.95 35.66969626118597 139.74855565727705 9.699 35.66965977639115 139.74853402328628 9.699 35.66965977639115 139.74853402328628 9.95 35.66969626118597 139.74855565727705 9.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-90202e6b-8d74-4d59-9814-2a31b1fee874">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-90202e6b-8d74-4d59-9814-2a31b1fee874">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-90202e6b-8d74-4d59-9814-2a31b1fee874">
											<gml:posList>35.669657298355574 139.74853507529238 6.38 35.66969661464996 139.74855839635248 6.38 35.66969661464996 139.74855839635248 9.95 35.669657298355574 139.74853507529238 9.95 35.669657298355574 139.74853507529238 6.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4478</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">39.649</uro:buildingRoofEdgeArea>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1123</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>