<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_88436cfe-8722-4464-a21c-be28480a31f7">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="説明注記">
				<gen:value>エレベーター</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">3.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>0</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67085423106626 139.74130358082377 0 35.670866394597304 139.74128524100624 0 35.670843283976204 139.74126242374223 0 35.67083148985071 139.74128055325372 0 35.67081335740484 139.74126113255036 0 35.670801481547954 139.7412784668142 0 35.670849436115624 139.74132763417535 0 35.670861149867584 139.74131047683565 0 35.67085423106626 139.74130358082377 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67085423106626 139.74130358082377 8.927 35.670861149867584 139.74131047683565 8.927 35.670849436115624 139.74132763417535 8.927 35.670801481547954 139.7412784668142 8.927 35.67081335740484 139.74126113255036 8.927 35.67083148985071 139.74128055325372 8.927 35.670843283976204 139.74126242374223 8.927 35.670866394597304 139.74128524100624 8.927 35.67085423106626 139.74130358082377 8.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67085423106626 139.74130358082377 8.927 35.670866394597304 139.74128524100624 8.927 35.670866394597304 139.74128524100624 12.69 35.67085423106626 139.74130358082377 12.69 35.67085423106626 139.74130358082377 8.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670866394597304 139.74128524100624 8.927 35.670843283976204 139.74126242374223 8.927 35.670843283976204 139.74126242374223 12.69 35.670866394597304 139.74128524100624 12.69 35.670866394597304 139.74128524100624 8.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670843283976204 139.74126242374223 8.927 35.67083148985071 139.74128055325372 8.927 35.67083148985071 139.74128055325372 12.69 35.670843283976204 139.74126242374223 12.69 35.670843283976204 139.74126242374223 8.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67083148985071 139.74128055325372 8.927 35.67081335740484 139.74126113255036 8.927 35.67081335740484 139.74126113255036 12.69 35.67083148985071 139.74128055325372 12.69 35.67083148985071 139.74128055325372 8.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67081335740484 139.74126113255036 8.927 35.670801481547954 139.7412784668142 8.927 35.670801481547954 139.7412784668142 12.69 35.67081335740484 139.74126113255036 12.69 35.67081335740484 139.74126113255036 8.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670801481547954 139.7412784668142 8.927 35.670849436115624 139.74132763417535 8.927 35.670849436115624 139.74132763417535 12.69 35.670801481547954 139.7412784668142 12.69 35.670801481547954 139.7412784668142 8.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670849436115624 139.74132763417535 8.927 35.670861149867584 139.74131047683565 8.927 35.670861149867584 139.74131047683565 12.69 35.670849436115624 139.74132763417535 12.69 35.670849436115624 139.74132763417535 8.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670861149867584 139.74131047683565 8.927 35.67085423106626 139.74130358082377 8.927 35.67085423106626 139.74130358082377 12.69 35.670861149867584 139.74131047683565 12.69 35.670861149867584 139.74131047683565 8.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67085423106626 139.74130358082377 12.69 35.670866394597304 139.74128524100624 12.69 35.670843283976204 139.74126242374223 12.69 35.67083148985071 139.74128055325372 12.69 35.67081335740484 139.74126113255036 12.69 35.670801481547954 139.7412784668142 12.69 35.670849436115624 139.74132763417535 12.69 35.670861149867584 139.74131047683565 12.69 35.67085423106626 139.74130358082377 12.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-eae44ca5-bfdf-466a-ba50-e5f0cba95ba8"/>
							<gml:surfaceMember xlink:href="#poly-2b02b9e1-f5eb-4b37-a372-386c257ee9e2"/>
							<gml:surfaceMember xlink:href="#poly-2a7f8346-a8e8-45f5-a28a-e3146821abde"/>
							<gml:surfaceMember xlink:href="#poly-ccd22da4-6c15-4de0-a838-2ac18f1dd012"/>
							<gml:surfaceMember xlink:href="#poly-1d345864-f4e5-4892-8b40-f1a14c257b63"/>
							<gml:surfaceMember xlink:href="#poly-ee191547-456e-4cb2-9256-548e3abd12e5"/>
							<gml:surfaceMember xlink:href="#poly-1e7dd8b2-af51-4454-903a-d0165a13f52e"/>
							<gml:surfaceMember xlink:href="#poly-75778596-799c-42cb-a749-26588a596ac8"/>
							<gml:surfaceMember xlink:href="#poly-7e3534c5-c3a3-4f11-ae4f-13a794defcb1"/>
							<gml:surfaceMember xlink:href="#poly-98695a68-94a6-43d2-832f-86d9ce95e5da"/>
							<gml:surfaceMember xlink:href="#poly-4673da8f-5d7a-4dac-b6f1-87c826e1dbfc"/>
							<gml:surfaceMember xlink:href="#poly-cdcb94e3-1670-4790-8cf2-3e36759a19e6"/>
							<gml:surfaceMember xlink:href="#poly-760b52d6-ec0a-4041-b050-9475b3c7a63f"/>
							<gml:surfaceMember xlink:href="#poly-0a15c6b4-1c47-424d-b35e-9faeb939875b"/>
							<gml:surfaceMember xlink:href="#poly-035a4ff1-cdd1-4473-b1d3-baf337cf333d"/>
							<gml:surfaceMember xlink:href="#poly-5958578a-c52d-4a4d-8178-1c2c954ec293"/>
							<gml:surfaceMember xlink:href="#poly-666264e0-4804-471a-a580-e4f1720a956b"/>
							<gml:surfaceMember xlink:href="#poly-3ef546e6-2d7f-45b4-b385-df7ae042f266"/>
							<gml:surfaceMember xlink:href="#poly-80cf141b-68fa-4b52-94df-cf2a75b41f3a"/>
							<gml:surfaceMember xlink:href="#poly-fc9d790e-1e3c-41c4-86a2-ac231b070a80"/>
							<gml:surfaceMember xlink:href="#poly-dc1dd7e5-97c5-4abf-8b77-a621014262a7"/>
							<gml:surfaceMember xlink:href="#poly-de0576f1-033b-4b1a-a6e7-45347759ffe8"/>
							<gml:surfaceMember xlink:href="#poly-7beff711-82ab-4fdc-9051-1354a7d96bc0"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-eae44ca5-bfdf-466a-ba50-e5f0cba95ba8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eae44ca5-bfdf-466a-ba50-e5f0cba95ba8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eae44ca5-bfdf-466a-ba50-e5f0cba95ba8">
											<gml:posList>35.67083148985071 139.74128055325372 8.927 35.670843283976204 139.74126242374226 8.927 35.67086639459731 139.7412852410062 8.927 35.67085423106624 139.74130358082374 8.927 35.67086114986756 139.74131047683565 8.927 35.67084943611563 139.74132763417535 8.927 35.670801481547954 139.74127846681418 8.927 35.670813357404846 139.74126113255033 8.927 35.67083148985071 139.74128055325372 8.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2b02b9e1-f5eb-4b37-a372-386c257ee9e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b02b9e1-f5eb-4b37-a372-386c257ee9e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b02b9e1-f5eb-4b37-a372-386c257ee9e2">
											<gml:posList>35.67086639459731 139.7412852410062 15.051 35.670843283976204 139.74126242374226 15.051 35.670843702180136 139.74126709585678 15.051 35.6708625731591 139.74128574247817 15.051 35.67086639459731 139.7412852410062 15.051</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2a7f8346-a8e8-45f5-a28a-e3146821abde">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a7f8346-a8e8-45f5-a28a-e3146821abde">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a7f8346-a8e8-45f5-a28a-e3146821abde">
											<gml:posList>35.670843283976204 139.74126242374226 15.051 35.670826988241984 139.74128742923386 15.051 35.67083077363378 139.7412869388499 15.051 35.670843702180136 139.74126709585678 15.051 35.670843283976204 139.74126242374226 15.051</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ccd22da4-6c15-4de0-a838-2ac18f1dd012">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ccd22da4-6c15-4de0-a838-2ac18f1dd012">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ccd22da4-6c15-4de0-a838-2ac18f1dd012">
											<gml:posList>35.670843702180136 139.74126709585678 14.622 35.67083077363378 139.7412869388499 14.622 35.67084947334055 139.74130557462323 14.622 35.6708521112543 139.74130150654796 14.622 35.6708625731591 139.74128574247817 14.622 35.670843702180136 139.74126709585678 14.622</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1d345864-f4e5-4892-8b40-f1a14c257b63">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d345864-f4e5-4892-8b40-f1a14c257b63">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d345864-f4e5-4892-8b40-f1a14c257b63">
											<gml:posList>35.67084943611563 139.74132763417535 13.19 35.67086114986756 139.74131047683565 13.19 35.67085423106624 139.74130358082374 13.19 35.670849891559705 139.741310268831 13.19 35.670826988241984 139.74128742923386 13.19 35.67083148985071 139.74128055325372 13.19 35.670813357404846 139.74126113255033 13.19 35.670801481547954 139.74127846681418 13.19 35.67084943611563 139.74132763417535 13.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ee191547-456e-4cb2-9256-548e3abd12e5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee191547-456e-4cb2-9256-548e3abd12e5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee191547-456e-4cb2-9256-548e3abd12e5">
											<gml:posList>35.6708625731591 139.74128574247817 15.051 35.6708521112543 139.74130150654796 15.051 35.67085423106624 139.74130358082374 15.051 35.67086639459731 139.7412852410062 15.051 35.6708625731591 139.74128574247817 15.051</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1e7dd8b2-af51-4454-903a-d0165a13f52e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e7dd8b2-af51-4454-903a-d0165a13f52e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e7dd8b2-af51-4454-903a-d0165a13f52e">
											<gml:posList>35.670826988241984 139.74128742923386 15.051 35.670849891559705 139.741310268831 15.051 35.67084947334055 139.74130557462323 15.051 35.67083077363378 139.7412869388499 15.051 35.670826988241984 139.74128742923386 15.051</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-75778596-799c-42cb-a749-26588a596ac8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-75778596-799c-42cb-a749-26588a596ac8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-75778596-799c-42cb-a749-26588a596ac8">
											<gml:posList>35.67084947334055 139.74130557462323 15.051 35.670849891559705 139.741310268831 15.051 35.67085423106624 139.74130358082374 15.051 35.6708521112543 139.74130150654796 15.051 35.67084947334055 139.74130557462323 15.051</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7e3534c5-c3a3-4f11-ae4f-13a794defcb1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e3534c5-c3a3-4f11-ae4f-13a794defcb1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e3534c5-c3a3-4f11-ae4f-13a794defcb1">
											<gml:posList>35.67083077363378 139.7412869388499 15.051 35.67084947334055 139.74130557462323 15.051 35.67084947334055 139.74130557462323 14.622 35.67083077363378 139.7412869388499 14.622 35.67083077363378 139.7412869388499 15.051</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-98695a68-94a6-43d2-832f-86d9ce95e5da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-98695a68-94a6-43d2-832f-86d9ce95e5da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-98695a68-94a6-43d2-832f-86d9ce95e5da">
											<gml:posList>35.6708625731591 139.74128574247817 15.051 35.670843702180136 139.74126709585678 15.051 35.670843702180136 139.74126709585678 14.622 35.6708625731591 139.74128574247817 14.622 35.6708625731591 139.74128574247817 15.051</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4673da8f-5d7a-4dac-b6f1-87c826e1dbfc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4673da8f-5d7a-4dac-b6f1-87c826e1dbfc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4673da8f-5d7a-4dac-b6f1-87c826e1dbfc">
											<gml:posList>35.670813357404846 139.74126113255033 13.19 35.670813357404846 139.74126113255033 8.927 35.670801481547954 139.74127846681418 8.927 35.670801481547954 139.74127846681418 13.19 35.670813357404846 139.74126113255033 13.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cdcb94e3-1670-4790-8cf2-3e36759a19e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cdcb94e3-1670-4790-8cf2-3e36759a19e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cdcb94e3-1670-4790-8cf2-3e36759a19e6">
											<gml:posList>35.67083148985071 139.74128055325372 13.19 35.67083148985071 139.74128055325372 8.927 35.670813357404846 139.74126113255033 8.927 35.670813357404846 139.74126113255033 13.19 35.67083148985071 139.74128055325372 13.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-760b52d6-ec0a-4041-b050-9475b3c7a63f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-760b52d6-ec0a-4041-b050-9475b3c7a63f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-760b52d6-ec0a-4041-b050-9475b3c7a63f">
											<gml:posList>35.67086639459731 139.7412852410062 15.051 35.67086639459731 139.7412852410062 8.927 35.670843283976204 139.74126242374226 8.927 35.670843283976204 139.74126242374226 15.051 35.67086639459731 139.7412852410062 15.051</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0a15c6b4-1c47-424d-b35e-9faeb939875b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a15c6b4-1c47-424d-b35e-9faeb939875b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a15c6b4-1c47-424d-b35e-9faeb939875b">
											<gml:posList>35.670843283976204 139.74126242374226 15.051 35.670843283976204 139.74126242374226 8.927 35.67083148985071 139.74128055325372 8.927 35.67083148985071 139.74128055325372 13.19 35.670826988241984 139.74128742923386 13.19 35.670826988241984 139.74128742923386 15.051 35.670843283976204 139.74126242374226 15.051</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-035a4ff1-cdd1-4473-b1d3-baf337cf333d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-035a4ff1-cdd1-4473-b1d3-baf337cf333d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-035a4ff1-cdd1-4473-b1d3-baf337cf333d">
											<gml:posList>35.670843702180136 139.74126709585678 15.051 35.67083077363378 139.7412869388499 15.051 35.67083077363378 139.7412869388499 14.622 35.670843702180136 139.74126709585678 14.622 35.670843702180136 139.74126709585678 15.051</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5958578a-c52d-4a4d-8178-1c2c954ec293">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5958578a-c52d-4a4d-8178-1c2c954ec293">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5958578a-c52d-4a4d-8178-1c2c954ec293">
											<gml:posList>35.6708521112543 139.74130150654796 15.051 35.6708625731591 139.74128574247817 15.051 35.6708625731591 139.74128574247817 14.622 35.6708521112543 139.74130150654796 14.622 35.6708521112543 139.74130150654796 15.051</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-666264e0-4804-471a-a580-e4f1720a956b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-666264e0-4804-471a-a580-e4f1720a956b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-666264e0-4804-471a-a580-e4f1720a956b">
											<gml:posList>35.67086639459731 139.7412852410062 15.051 35.67085423106624 139.74130358082374 15.051 35.67085423106624 139.74130358082374 13.19 35.67085423106624 139.74130358082374 8.927 35.67086639459731 139.7412852410062 8.927 35.67086639459731 139.7412852410062 15.051</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3ef546e6-2d7f-45b4-b385-df7ae042f266">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ef546e6-2d7f-45b4-b385-df7ae042f266">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ef546e6-2d7f-45b4-b385-df7ae042f266">
											<gml:posList>35.670826988241984 139.74128742923386 13.19 35.670849891559705 139.741310268831 13.19 35.670849891559705 139.741310268831 15.051 35.670826988241984 139.74128742923386 15.051 35.670826988241984 139.74128742923386 13.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-80cf141b-68fa-4b52-94df-cf2a75b41f3a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-80cf141b-68fa-4b52-94df-cf2a75b41f3a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-80cf141b-68fa-4b52-94df-cf2a75b41f3a">
											<gml:posList>35.670801481547954 139.74127846681418 13.19 35.670801481547954 139.74127846681418 8.927 35.67084943611563 139.74132763417535 8.927 35.67084943611563 139.74132763417535 13.19 35.670801481547954 139.74127846681418 13.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fc9d790e-1e3c-41c4-86a2-ac231b070a80">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc9d790e-1e3c-41c4-86a2-ac231b070a80">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc9d790e-1e3c-41c4-86a2-ac231b070a80">
											<gml:posList>35.67084947334055 139.74130557462323 15.051 35.6708521112543 139.74130150654796 15.051 35.6708521112543 139.74130150654796 14.622 35.67084947334055 139.74130557462323 14.622 35.67084947334055 139.74130557462323 15.051</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dc1dd7e5-97c5-4abf-8b77-a621014262a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc1dd7e5-97c5-4abf-8b77-a621014262a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc1dd7e5-97c5-4abf-8b77-a621014262a7">
											<gml:posList>35.670849891559705 139.741310268831 13.19 35.67085423106624 139.74130358082374 13.19 35.67085423106624 139.74130358082374 15.051 35.670849891559705 139.741310268831 15.051 35.670849891559705 139.741310268831 13.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-de0576f1-033b-4b1a-a6e7-45347759ffe8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de0576f1-033b-4b1a-a6e7-45347759ffe8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de0576f1-033b-4b1a-a6e7-45347759ffe8">
											<gml:posList>35.67086114986756 139.74131047683565 13.19 35.67086114986756 139.74131047683565 8.927 35.67085423106624 139.74130358082374 8.927 35.67085423106624 139.74130358082374 13.19 35.67086114986756 139.74131047683565 13.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7beff711-82ab-4fdc-9051-1354a7d96bc0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7beff711-82ab-4fdc-9051-1354a7d96bc0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7beff711-82ab-4fdc-9051-1354a7d96bc0">
											<gml:posList>35.67084943611563 139.74132763417535 13.19 35.67084943611563 139.74132763417535 8.927 35.67086114986756 139.74131047683565 8.927 35.67086114986756 139.74131047683565 13.19 35.67084943611563 139.74132763417535 13.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2076</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">17.43745</uro:buildingRoofEdgeArea>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>