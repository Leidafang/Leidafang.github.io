<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_8905a809-d174-4b44-a8c1-f0f10a16bbf7">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">17</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.671161853937676 139.74105924660518 0 35.67112385453745 139.74110955128577 0 35.67112791426553 139.74111418608823 0 35.67109666786141 139.74115498309024 0 35.67109775069192 139.74115652833547 0 35.67105830990014 139.74120793922128 0 35.67106543699418 139.74121610533382 0 35.67104905103168 139.74124097845166 0 35.67104887347579 139.74135066892754 0 35.671138282219886 139.74135270934633 0 35.67115052869585 139.7413367443446 0 35.671159533049 139.74132447254533 0 35.67116350263157 139.7413291074642 0 35.671202943474405 139.74127769657034 0 35.67123391925437 139.74123656848147 0 35.67127363021508 139.74118482579493 0 35.671161853937676 139.74105924660518 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671161853937676 139.74105924660518 8.307 35.67127363021508 139.74118482579493 8.307 35.67123391925437 139.74123656848147 8.307 35.671202943474405 139.74127769657034 8.307 35.67116350263157 139.7413291074642 8.307 35.671159533049 139.74132447254533 8.307 35.67115052869585 139.7413367443446 8.307 35.671138282219886 139.74135270934633 8.307 35.67104887347579 139.74135066892754 8.307 35.67104905103168 139.74124097845166 8.307 35.67106543699418 139.74121610533382 8.307 35.67105830990014 139.74120793922128 8.307 35.67109775069192 139.74115652833547 8.307 35.67109666786141 139.74115498309024 8.307 35.67112791426553 139.74111418608823 8.307 35.67112385453745 139.74110955128577 8.307 35.671161853937676 139.74105924660518 8.307</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671161853937676 139.74105924660518 8.307 35.67112385453745 139.74110955128577 8.307 35.67112385453745 139.74110955128577 20.11 35.671161853937676 139.74105924660518 20.11 35.671161853937676 139.74105924660518 8.307</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67112385453745 139.74110955128577 8.307 35.67112791426553 139.74111418608823 8.307 35.67112791426553 139.74111418608823 20.11 35.67112385453745 139.74110955128577 20.11 35.67112385453745 139.74110955128577 8.307</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67112791426553 139.74111418608823 8.307 35.67109666786141 139.74115498309024 8.307 35.67109666786141 139.74115498309024 20.11 35.67112791426553 139.74111418608823 20.11 35.67112791426553 139.74111418608823 8.307</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67109666786141 139.74115498309024 8.307 35.67109775069192 139.74115652833547 8.307 35.67109775069192 139.74115652833547 20.11 35.67109666786141 139.74115498309024 20.11 35.67109666786141 139.74115498309024 8.307</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67109775069192 139.74115652833547 8.307 35.67105830990014 139.74120793922128 8.307 35.67105830990014 139.74120793922128 20.11 35.67109775069192 139.74115652833547 20.11 35.67109775069192 139.74115652833547 8.307</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67105830990014 139.74120793922128 8.307 35.67106543699418 139.74121610533382 8.307 35.67106543699418 139.74121610533382 20.11 35.67105830990014 139.74120793922128 20.11 35.67105830990014 139.74120793922128 8.307</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67106543699418 139.74121610533382 8.307 35.67104905103168 139.74124097845166 8.307 35.67104905103168 139.74124097845166 20.11 35.67106543699418 139.74121610533382 20.11 35.67106543699418 139.74121610533382 8.307</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67104905103168 139.74124097845166 8.307 35.67104887347579 139.74135066892754 8.307 35.67104887347579 139.74135066892754 20.11 35.67104905103168 139.74124097845166 20.11 35.67104905103168 139.74124097845166 8.307</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67104887347579 139.74135066892754 8.307 35.671138282219886 139.74135270934633 8.307 35.671138282219886 139.74135270934633 20.11 35.67104887347579 139.74135066892754 20.11 35.67104887347579 139.74135066892754 8.307</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671138282219886 139.74135270934633 8.307 35.67115052869585 139.7413367443446 8.307 35.67115052869585 139.7413367443446 20.11 35.671138282219886 139.74135270934633 20.11 35.671138282219886 139.74135270934633 8.307</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67115052869585 139.7413367443446 8.307 35.671159533049 139.74132447254533 8.307 35.671159533049 139.74132447254533 20.11 35.67115052869585 139.7413367443446 20.11 35.67115052869585 139.7413367443446 8.307</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671159533049 139.74132447254533 8.307 35.67116350263157 139.7413291074642 8.307 35.67116350263157 139.7413291074642 20.11 35.671159533049 139.74132447254533 20.11 35.671159533049 139.74132447254533 8.307</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67116350263157 139.7413291074642 8.307 35.671202943474405 139.74127769657034 8.307 35.671202943474405 139.74127769657034 20.11 35.67116350263157 139.7413291074642 20.11 35.67116350263157 139.7413291074642 8.307</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671202943474405 139.74127769657034 8.307 35.67123391925437 139.74123656848147 8.307 35.67123391925437 139.74123656848147 20.11 35.671202943474405 139.74127769657034 20.11 35.671202943474405 139.74127769657034 8.307</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67123391925437 139.74123656848147 8.307 35.67127363021508 139.74118482579493 8.307 35.67127363021508 139.74118482579493 20.11 35.67123391925437 139.74123656848147 20.11 35.67123391925437 139.74123656848147 8.307</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67127363021508 139.74118482579493 8.307 35.671161853937676 139.74105924660518 8.307 35.671161853937676 139.74105924660518 20.11 35.67127363021508 139.74118482579493 20.11 35.67127363021508 139.74118482579493 8.307</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671161853937676 139.74105924660518 20.11 35.67112385453745 139.74110955128577 20.11 35.67112791426553 139.74111418608823 20.11 35.67109666786141 139.74115498309024 20.11 35.67109775069192 139.74115652833547 20.11 35.67105830990014 139.74120793922128 20.11 35.67106543699418 139.74121610533382 20.11 35.67104905103168 139.74124097845166 20.11 35.67104887347579 139.74135066892754 20.11 35.671138282219886 139.74135270934633 20.11 35.67115052869585 139.7413367443446 20.11 35.671159533049 139.74132447254533 20.11 35.67116350263157 139.7413291074642 20.11 35.671202943474405 139.74127769657034 20.11 35.67123391925437 139.74123656848147 20.11 35.67127363021508 139.74118482579493 20.11 35.671161853937676 139.74105924660518 20.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-e637c15f-579a-44f4-8e87-80f8bb8d03a4"/>
							<gml:surfaceMember xlink:href="#poly-bb635282-0999-4c61-8ff9-5198dbf47bda"/>
							<gml:surfaceMember xlink:href="#poly-98dc81d2-284d-4eed-a04b-89f4f8db6655"/>
							<gml:surfaceMember xlink:href="#poly-702b7c17-e3a8-4d83-bd5a-3753b94bd4b7"/>
							<gml:surfaceMember xlink:href="#poly-2398f44f-1152-49ed-94d5-d99e6c32895c"/>
							<gml:surfaceMember xlink:href="#poly-5bcb81ac-ad95-4963-a5d7-0f453c4cdaf5"/>
							<gml:surfaceMember xlink:href="#poly-b1b052c0-70a7-48dd-b6af-74ccbd3a881f"/>
							<gml:surfaceMember xlink:href="#poly-7be1b634-9865-46e7-93d4-d001654c5971"/>
							<gml:surfaceMember xlink:href="#poly-675a93ad-a9f9-41d9-95cc-c53577c73f14"/>
							<gml:surfaceMember xlink:href="#poly-02fdf5b7-0a90-46ec-9c2b-03c222de5442"/>
							<gml:surfaceMember xlink:href="#poly-46ae3a51-612d-4fdb-a1a6-f7aceb5338d5"/>
							<gml:surfaceMember xlink:href="#poly-b0ed6f0c-b86d-4f56-9fcc-94e78b671e3a"/>
							<gml:surfaceMember xlink:href="#poly-4c0d9981-7d09-4cc3-aecd-c8c5a47cfa2c"/>
							<gml:surfaceMember xlink:href="#poly-cf8094e6-4edf-4876-b251-d35081c1d6f5"/>
							<gml:surfaceMember xlink:href="#poly-3229870e-ebcb-43c5-950d-9180d23b9549"/>
							<gml:surfaceMember xlink:href="#poly-e4eb1339-90a5-419a-bb44-b742c0124ce4"/>
							<gml:surfaceMember xlink:href="#poly-09c3d4c9-a931-4934-ab7b-dc5878ad8036"/>
							<gml:surfaceMember xlink:href="#poly-fcbd5010-77c6-4605-a16d-8aa4384998d7"/>
							<gml:surfaceMember xlink:href="#poly-c1349c69-d68c-4d6f-80a0-6fa54056bec2"/>
							<gml:surfaceMember xlink:href="#poly-f40bcdd0-16a0-47ed-9ee3-dd37d40f51c9"/>
							<gml:surfaceMember xlink:href="#poly-88d46843-0c3e-45b6-bed3-f9c27c88978c"/>
							<gml:surfaceMember xlink:href="#poly-63ba7db5-6dc5-4d8a-9d64-1c4f9e225d34"/>
							<gml:surfaceMember xlink:href="#poly-aaa996c6-e13a-4951-aa7f-4a3718e77a20"/>
							<gml:surfaceMember xlink:href="#poly-3ca7620a-7aab-4b6f-82aa-2a8f84f606a7"/>
							<gml:surfaceMember xlink:href="#poly-4ae4f9fb-d46d-4baa-9125-29a844805c8c"/>
							<gml:surfaceMember xlink:href="#poly-36a4d79b-131d-4cac-b907-44a42fa14fce"/>
							<gml:surfaceMember xlink:href="#poly-788111c3-a4e2-475b-afa1-96abc4f28a3f"/>
							<gml:surfaceMember xlink:href="#poly-eb3171b5-dbae-4290-8230-0baf6ed8af47"/>
							<gml:surfaceMember xlink:href="#poly-1acb436b-1f36-4852-b950-6083e50753d4"/>
							<gml:surfaceMember xlink:href="#poly-9559d685-0666-4d9f-9e9d-56cc37ae8920"/>
							<gml:surfaceMember xlink:href="#poly-a4aed16a-da1e-42ea-966f-b4e413165861"/>
							<gml:surfaceMember xlink:href="#poly-90537cf9-2b3f-443e-ac6e-1e125e6ccdb7"/>
							<gml:surfaceMember xlink:href="#poly-410c7566-ee2e-47a0-a21d-efbc2ddaa49e"/>
							<gml:surfaceMember xlink:href="#poly-572c20e8-4aee-416d-89ec-2ef6a6b4870c"/>
							<gml:surfaceMember xlink:href="#poly-a3a88f70-fa6d-4705-8fdc-d02e6a3005ba"/>
							<gml:surfaceMember xlink:href="#poly-80451b6e-b693-47dc-9c5e-6bed3d0b284f"/>
							<gml:surfaceMember xlink:href="#poly-ca665374-f812-4d4f-9dd9-75d2e236fdcb"/>
							<gml:surfaceMember xlink:href="#poly-18c26b51-8840-449c-ad4c-245d9103c4a7"/>
							<gml:surfaceMember xlink:href="#poly-c61111aa-0680-4e7e-8d37-81f7b3d58eaa"/>
							<gml:surfaceMember xlink:href="#poly-618f9986-897f-46c6-9c7f-f89fabe98524"/>
							<gml:surfaceMember xlink:href="#poly-85c54b42-9a0c-4131-adcf-e8abe4a2f7bd"/>
							<gml:surfaceMember xlink:href="#poly-d13f79f7-1847-4b5a-9dc1-e9e55ad94548"/>
							<gml:surfaceMember xlink:href="#poly-3358eb8d-1b2d-41cc-88eb-5438bd441892"/>
							<gml:surfaceMember xlink:href="#poly-e24d5e4c-fd48-4534-999f-332bee7c7d14"/>
							<gml:surfaceMember xlink:href="#poly-4f2bfdd4-16cf-4d92-8bd8-939cfcbce511"/>
							<gml:surfaceMember xlink:href="#poly-0b1ae22a-9ba6-4993-be12-0d9db14ea756"/>
							<gml:surfaceMember xlink:href="#poly-45a31e74-b420-421d-9a7e-20d84dcf859b"/>
							<gml:surfaceMember xlink:href="#poly-ca131735-d436-42ea-8fc4-8efb46b9b018"/>
							<gml:surfaceMember xlink:href="#poly-9e2321e3-8027-42f0-b3ea-840ca0dddce1"/>
							<gml:surfaceMember xlink:href="#poly-520e92f2-9813-432a-af33-6f0df6e5f369"/>
							<gml:surfaceMember xlink:href="#poly-9683cff5-55d4-4e8d-9e98-5008a65bd99c"/>
							<gml:surfaceMember xlink:href="#poly-98317b40-368c-4680-babc-f4b55d0ead64"/>
							<gml:surfaceMember xlink:href="#poly-bf751557-5c6a-482e-807d-85a7cb120d60"/>
							<gml:surfaceMember xlink:href="#poly-ecebfe73-eb2c-4216-90e7-c9dd894ea358"/>
							<gml:surfaceMember xlink:href="#poly-6d3aae3a-fc25-4026-b526-96d4383bf63e"/>
							<gml:surfaceMember xlink:href="#poly-de795e19-1b57-4280-8a55-8dc18526ab20"/>
							<gml:surfaceMember xlink:href="#poly-0e2e01d8-0b73-4c3b-8f10-49b4d5f774c8"/>
							<gml:surfaceMember xlink:href="#poly-486a232a-9ab2-4205-ae51-1c8c900e69e1"/>
							<gml:surfaceMember xlink:href="#poly-a79ce051-648f-4565-9fe5-ac6d2a890511"/>
							<gml:surfaceMember xlink:href="#poly-8f9c8ce7-b934-419b-984a-8a54d2b41623"/>
							<gml:surfaceMember xlink:href="#poly-489e778b-b21f-4cc8-b3eb-bead934d9a9a"/>
							<gml:surfaceMember xlink:href="#poly-c8e275b1-09bf-4704-bfc0-79fea8de0321"/>
							<gml:surfaceMember xlink:href="#poly-e5703b47-44db-4990-8948-d0878239a700"/>
							<gml:surfaceMember xlink:href="#poly-2a444b7d-22be-40e6-a315-a833979db1d2"/>
							<gml:surfaceMember xlink:href="#poly-1d12d993-2974-41ce-a0a7-3c04549cd948"/>
							<gml:surfaceMember xlink:href="#poly-88529f80-4d23-406f-9b01-af9971cb2964"/>
							<gml:surfaceMember xlink:href="#poly-f3f04fb5-841f-4c13-89d7-088786e10be6"/>
							<gml:surfaceMember xlink:href="#poly-359e235c-7a8d-4531-9923-439dc71a7ca5"/>
							<gml:surfaceMember xlink:href="#poly-2e9c50ed-bb59-40e7-95ec-af493a8aaeee"/>
							<gml:surfaceMember xlink:href="#poly-9cf53969-576f-437c-91f1-f0a6fa621d86"/>
							<gml:surfaceMember xlink:href="#poly-bf0f8795-25bd-4a89-b799-c3ccd11e8b15"/>
							<gml:surfaceMember xlink:href="#poly-0257418b-7b93-40ff-a277-b34d3949decc"/>
							<gml:surfaceMember xlink:href="#poly-2e4c7c9d-740e-488d-8fb2-f92f496a25bd"/>
							<gml:surfaceMember xlink:href="#poly-f257f652-4ca3-4412-bf18-c2abca720ce7"/>
							<gml:surfaceMember xlink:href="#poly-e19a6749-a77f-44e9-80b4-3c9cbdcaf985"/>
							<gml:surfaceMember xlink:href="#poly-6ad55ac3-709b-498e-806e-75f65add82f7"/>
							<gml:surfaceMember xlink:href="#poly-23703003-0eb7-4019-810a-ddccfaa8f3bd"/>
							<gml:surfaceMember xlink:href="#poly-2e0bc04a-8f49-45c0-885f-ceace7e1e057"/>
							<gml:surfaceMember xlink:href="#poly-f7280399-637f-422d-b7e2-a9c9a648407e"/>
							<gml:surfaceMember xlink:href="#poly-6864f657-fc90-4bd8-9e40-8f658d6974f8"/>
							<gml:surfaceMember xlink:href="#poly-96e6501c-3640-4fd3-ae6c-df8c670d5314"/>
							<gml:surfaceMember xlink:href="#poly-85f1480a-7e38-4000-939d-08f12dc8c134"/>
							<gml:surfaceMember xlink:href="#poly-07866816-39fa-4ba2-ab07-fea35fdf805f"/>
							<gml:surfaceMember xlink:href="#poly-db5a9366-ddcf-427a-a4db-68ec275231bc"/>
							<gml:surfaceMember xlink:href="#poly-d0fe7265-c171-4bcd-b42c-09110371ff24"/>
							<gml:surfaceMember xlink:href="#poly-826e842c-8227-46fd-8392-9ef24b5a436b"/>
							<gml:surfaceMember xlink:href="#poly-7861fdfd-b6e2-4daa-8352-cbc03a4f4c91"/>
							<gml:surfaceMember xlink:href="#poly-4db38e42-1acf-474c-bcee-f6c100847456"/>
							<gml:surfaceMember xlink:href="#poly-9c59ef3b-25f0-48fe-8691-be4f6c146223"/>
							<gml:surfaceMember xlink:href="#poly-4bb21f36-c772-4a1c-9e3f-fb510d0061d5"/>
							<gml:surfaceMember xlink:href="#poly-66733861-9642-4ec4-b509-813fcd9366a5"/>
							<gml:surfaceMember xlink:href="#poly-bd8052cf-e2bc-481c-8eff-dd31c75b43ce"/>
							<gml:surfaceMember xlink:href="#poly-bfd6d48a-4ed9-4932-b04b-e5aef9d4fac5"/>
							<gml:surfaceMember xlink:href="#poly-b11c7518-f7d7-4cff-a60f-3be70b0e07b2"/>
							<gml:surfaceMember xlink:href="#poly-6c03eb54-80fa-4477-9b89-4b27d1e0cd1a"/>
							<gml:surfaceMember xlink:href="#poly-1635f2c1-14d0-4531-b428-a05895a8ee20"/>
							<gml:surfaceMember xlink:href="#poly-270d9cf2-bd53-4af2-8e24-ada9bc92f18a"/>
							<gml:surfaceMember xlink:href="#poly-52cbb6ad-fd7e-4b8b-b8bf-6f87f509ad84"/>
							<gml:surfaceMember xlink:href="#poly-61df6678-6131-4215-8604-c4e7a68c0e40"/>
							<gml:surfaceMember xlink:href="#poly-723d3aea-0dba-4969-ada4-f22d4697189b"/>
							<gml:surfaceMember xlink:href="#poly-e07f7d76-f7df-44b2-9722-44dc8ce04f86"/>
							<gml:surfaceMember xlink:href="#poly-d016a379-cd60-464d-90fa-00ccc7255efe"/>
							<gml:surfaceMember xlink:href="#poly-19eed9fa-58f4-4554-8e26-d21f4b8a0175"/>
							<gml:surfaceMember xlink:href="#poly-de939b13-efcb-4027-ada9-c4f3da6bfd1a"/>
							<gml:surfaceMember xlink:href="#poly-3bf14e1c-8e50-4a75-b892-58c1bdc5c9a6"/>
							<gml:surfaceMember xlink:href="#poly-ad698738-00f2-471e-8745-902fa784d604"/>
							<gml:surfaceMember xlink:href="#poly-dd6e6df6-01f7-4c0f-b329-43793e5d08bc"/>
							<gml:surfaceMember xlink:href="#poly-0b158369-a21b-48c2-b4f5-996d8979b794"/>
							<gml:surfaceMember xlink:href="#poly-d0feca2b-c277-41bf-a848-9a3fa0943dbe"/>
							<gml:surfaceMember xlink:href="#poly-5f7d712c-09e7-47dc-832d-427e032ccc7f"/>
							<gml:surfaceMember xlink:href="#poly-06600a3c-9acd-413d-bb18-0ee7885ffb24"/>
							<gml:surfaceMember xlink:href="#poly-feae90e6-7c4b-4a64-a542-a2cc4663a482"/>
							<gml:surfaceMember xlink:href="#poly-7f86b5f8-170e-459f-8b72-39afde0a34a9"/>
							<gml:surfaceMember xlink:href="#poly-3fa0b790-8263-4058-a0cd-901834b86368"/>
							<gml:surfaceMember xlink:href="#poly-2b7df7a0-3d93-46c9-91a3-c2b423e9838f"/>
							<gml:surfaceMember xlink:href="#poly-34531c06-5190-43bd-9ea6-9ae69fca8939"/>
							<gml:surfaceMember xlink:href="#poly-acbe1f8e-011a-4404-bb71-c30e435e989e"/>
							<gml:surfaceMember xlink:href="#poly-8c89681e-5bb1-458b-b147-288c2431bd77"/>
							<gml:surfaceMember xlink:href="#poly-946752f8-6b01-4639-a771-8c038f582fb8"/>
							<gml:surfaceMember xlink:href="#poly-6aa4ba8f-1b76-423f-9de6-9352fe0c7d15"/>
							<gml:surfaceMember xlink:href="#poly-95f9b1d1-800f-4685-a470-e975034897b3"/>
							<gml:surfaceMember xlink:href="#poly-ffa4276b-1e2d-4fb0-a4ad-02d403131f06"/>
							<gml:surfaceMember xlink:href="#poly-f49c863f-f273-418b-aad2-dd2fb06a5b26"/>
							<gml:surfaceMember xlink:href="#poly-5b3cea46-9443-4a6d-ab02-663162a6b4c3"/>
							<gml:surfaceMember xlink:href="#poly-63f167ee-0c73-4d6a-8e73-d4c0c2fc264f"/>
							<gml:surfaceMember xlink:href="#poly-583b78ad-8058-4bd8-b227-63342afc1f4e"/>
							<gml:surfaceMember xlink:href="#poly-8b46d2f7-4cc2-437a-96db-752d36959402"/>
							<gml:surfaceMember xlink:href="#poly-b9605fea-b8a8-46e4-bae3-93629ba6a9ed"/>
							<gml:surfaceMember xlink:href="#poly-7f5c6b9e-e63a-4887-9eb2-f600c7e963e1"/>
							<gml:surfaceMember xlink:href="#poly-75245b11-5c48-4188-bad5-f692587bb8ac"/>
							<gml:surfaceMember xlink:href="#poly-558fe88e-772c-4a16-a554-5fceedc1fd8d"/>
							<gml:surfaceMember xlink:href="#poly-ea59d71b-1b23-419e-9758-71cfca2b28b6"/>
							<gml:surfaceMember xlink:href="#poly-187671ac-f1ff-43b3-a4d7-9ec2c27944d3"/>
							<gml:surfaceMember xlink:href="#poly-4b10848b-6cf6-4bd3-bf3e-e890258742b3"/>
							<gml:surfaceMember xlink:href="#poly-2b1ae345-4b5d-4a72-835e-e390d109fc33"/>
							<gml:surfaceMember xlink:href="#poly-17eb0a51-81ed-4d9d-be80-4183965c8f13"/>
							<gml:surfaceMember xlink:href="#poly-ee38426e-f166-440e-9311-1ffc84f040ad"/>
							<gml:surfaceMember xlink:href="#poly-64ee7b6f-c2b4-48c9-9155-f9ab8081fb67"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_8905a809-d174-4b44-a8c1-f0f10a16bbf7_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3df6aef2-4691-46eb-8766-8c7baef9620a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67107192533911 139.74129660371307 32.003 35.67105678192328 139.74129614610362 32.003 35.67105717289015 139.74127698023273 32.003 35.67107231630604 139.74127743783853 32.003 35.67107192533911 139.74129660371307 32.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e5300fc-3b39-469f-912a-f548371053b0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67110945525498 139.74130413843383 29.966 35.67108749730515 139.7413034787641 29.966 35.671087966170845 139.74128009308805 29.966 35.67110992412923 139.74128076379776 29.966 35.67110945525498 139.74130413843383 29.966</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f07804d9-8e6f-4a95-aede-5d2141aa08c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f07804d9-8e6f-4a95-aede-5d2141aa08c1_0">
											<gml:posList>35.67107231630604 139.74127743783853 32.003 35.67105717289015 139.74127698023273 32.003 35.67105717289015 139.74127698023273 33.607 35.67107231630604 139.74127743783853 33.607 35.67107231630604 139.74127743783853 32.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-49557313-440d-4ba8-b1e2-36133fc38f83">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-49557313-440d-4ba8-b1e2-36133fc38f83_0">
											<gml:posList>35.671087966170845 139.74128009308805 29.966 35.671087966170845 139.74128009308805 32.289 35.67110992412923 139.74128076379776 32.289 35.67110992412923 139.74128076379776 29.966 35.671087966170845 139.74128009308805 29.966</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d3d20b95-9847-4000-9e49-1c1e166eaa20">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d3d20b95-9847-4000-9e49-1c1e166eaa20_0">
											<gml:posList>35.67105717289015 139.74127698023273 32.003 35.67105678192328 139.74129614610362 32.003 35.67105678192328 139.74129614610362 33.607 35.67105717289015 139.74127698023273 33.607 35.67105717289015 139.74127698023273 32.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5788bc77-4192-42ab-807f-be60c44186ff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5788bc77-4192-42ab-807f-be60c44186ff_0">
											<gml:posList>35.67105717289015 139.74127698023273 33.607 35.67105678192328 139.74129614610362 33.607 35.67107192533911 139.74129660371307 33.607 35.67107231630604 139.74127743783853 33.607 35.67105717289015 139.74127698023273 33.607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43e46766-519d-4069-9156-78c528aa1147">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-43e46766-519d-4069-9156-78c528aa1147_0">
											<gml:posList>35.67107192533911 139.74129660371307 32.003 35.67107231630604 139.74127743783853 32.003 35.67107231630604 139.74127743783853 33.607 35.67107192533911 139.74129660371307 33.607 35.67107192533911 139.74129660371307 32.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b1cc6724-4b70-42f5-bb87-9c3b43937b22">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b1cc6724-4b70-42f5-bb87-9c3b43937b22_0">
											<gml:posList>35.67108749730515 139.7413034787641 29.966 35.67108749730515 139.7413034787641 32.289 35.671087966170845 139.74128009308805 32.289 35.671087966170845 139.74128009308805 29.966 35.67108749730515 139.7413034787641 29.966</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d2f24053-d1d7-4461-9cf7-472dc400d6a1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d2f24053-d1d7-4461-9cf7-472dc400d6a1_0">
											<gml:posList>35.67110945525498 139.74130413843383 32.289 35.67110992412923 139.74128076379776 32.289 35.671087966170845 139.74128009308805 32.289 35.67108749730515 139.7413034787641 32.289 35.67110945525498 139.74130413843383 32.289</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b44a39e-e7ac-4fae-aa6d-a5b6da9ee262">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0b44a39e-e7ac-4fae-aa6d-a5b6da9ee262_0">
											<gml:posList>35.67110945525498 139.74130413843383 29.966 35.67110992412923 139.74128076379776 29.966 35.67110992412923 139.74128076379776 32.289 35.67110945525498 139.74130413843383 32.289 35.67110945525498 139.74130413843383 29.966</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5065157-8540-4df1-82b1-08893bf2f97d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c5065157-8540-4df1-82b1-08893bf2f97d_0">
											<gml:posList>35.67107192533911 139.74129660371307 32.003 35.67107192533911 139.74129660371307 33.607 35.67105678192328 139.74129614610362 33.607 35.67105678192328 139.74129614610362 32.003 35.67107192533911 139.74129660371307 32.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d25fc47b-5ed6-499d-acd6-55a72af80f58">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d25fc47b-5ed6-499d-acd6-55a72af80f58_0">
											<gml:posList>35.67110945525498 139.74130413843383 32.289 35.67108749730515 139.7413034787641 32.289 35.67108749730515 139.7413034787641 29.966 35.67110945525498 139.74130413843383 29.966 35.67110945525498 139.74130413843383 32.289</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-e637c15f-579a-44f4-8e87-80f8bb8d03a4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e637c15f-579a-44f4-8e87-80f8bb8d03a4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e637c15f-579a-44f4-8e87-80f8bb8d03a4">
											<gml:posList>35.671159533049 139.74132447254533 8.307 35.671150528695804 139.7413367443446 8.307 35.671138282219886 139.74135270934633 8.307 35.67104887347582 139.74135066892754 8.307 35.67104905103168 139.74124097845166 8.307 35.67106543699416 139.74121610533382 8.307 35.67105830990015 139.74120793922128 8.307 35.6710977506919 139.74115652833547 8.307 35.67109666786142 139.74115498309024 8.307 35.67112791426552 139.74111418608823 8.307 35.67112385453745 139.74110955128577 8.307 35.67116185393767 139.74105924660515 8.307 35.67127363021508 139.74118482579493 8.307 35.67123391925437 139.74123656848147 8.307 35.67120294347437 139.74127769657034 8.307 35.67116350263157 139.7413291074642 8.307 35.671159533049 139.74132447254533 8.307</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bb635282-0999-4c61-8ff9-5198dbf47bda">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb635282-0999-4c61-8ff9-5198dbf47bda">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb635282-0999-4c61-8ff9-5198dbf47bda">
											<gml:posList>35.67116185393767 139.74105924660515 21.475 35.67112385453745 139.74110955128577 21.475 35.67112772129716 139.7411093811425 21.475 35.67116201080235 139.74106398531617 21.475 35.67116185393767 139.74105924660515 21.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-98dc81d2-284d-4eed-a04b-89f4f8db6655">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-98dc81d2-284d-4eed-a04b-89f4f8db6655">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-98dc81d2-284d-4eed-a04b-89f4f8db6655">
											<gml:posList>35.67116201080235 139.74106398531617 21.475 35.67124770596771 139.7411602773974 21.475 35.67125159073796 139.74116008514287 21.475 35.67116185393767 139.74105924660515 21.475 35.67116201080235 139.74106398531617 21.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-702b7c17-e3a8-4d83-bd5a-3753b94bd4b7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-702b7c17-e3a8-4d83-bd5a-3753b94bd4b7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-702b7c17-e3a8-4d83-bd5a-3753b94bd4b7">
											<gml:posList>35.67109666786142 139.74115498309024 20.544 35.67110101247532 139.7411549780952 20.544 35.67112806267263 139.74111965386697 20.544 35.67112791426552 139.74111418608823 20.544 35.67109666786142 139.74115498309024 20.544</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2398f44f-1152-49ed-94d5-d99e6c32895c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2398f44f-1152-49ed-94d5-d99e6c32895c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2398f44f-1152-49ed-94d5-d99e6c32895c">
											<gml:posList>35.67124770596771 139.7411602773974 21.261 35.67116201080235 139.74106398531617 21.261 35.67112772129716 139.7411093811425 21.261 35.67121248918817 139.74120720974275 21.261 35.67121584791721 139.7412027762871 21.261 35.67120584308692 139.74119153152947 21.261 35.67123026334255 139.74115889456047 21.261 35.67124030426454 139.74117018346146 21.261 35.67124770596771 139.7411602773974 21.261</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5bcb81ac-ad95-4963-a5d7-0f453c4cdaf5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5bcb81ac-ad95-4963-a5d7-0f453c4cdaf5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5bcb81ac-ad95-4963-a5d7-0f453c4cdaf5">
											<gml:posList>35.67112385453745 139.74110955128577 21.475 35.67121261903121 139.7412119816272 21.475 35.67121248918817 139.74120720974275 21.475 35.67112772129716 139.7411093811425 21.475 35.67112385453745 139.74110955128577 21.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b1b052c0-70a7-48dd-b6af-74ccbd3a881f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b1b052c0-70a7-48dd-b6af-74ccbd3a881f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b1b052c0-70a7-48dd-b6af-74ccbd3a881f">
											<gml:posList>35.671205486929374 139.74120905148672 20.544 35.67120994860328 139.74120889171084 20.544 35.67112791426552 139.74111418608823 20.544 35.67112806267263 139.74111965386697 20.544 35.671205486929374 139.74120905148672 20.544</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7be1b634-9865-46e7-93d4-d001654c5971">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7be1b634-9865-46e7-93d4-d001654c5971">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7be1b634-9865-46e7-93d4-d001654c5971">
											<gml:posList>35.67124233409359 139.74117245668208 23.621 35.67123026334255 139.74115889456047 23.621 35.67123035542459 139.74116143512126 23.621 35.671240261030626 139.7411725805752 23.621 35.67124233409359 139.74117245668208 23.621</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-675a93ad-a9f9-41d9-95cc-c53577c73f14">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-675a93ad-a9f9-41d9-95cc-c53577c73f14">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-675a93ad-a9f9-41d9-95cc-c53577c73f14">
											<gml:posList>35.67124770596771 139.7411602773974 21.475 35.67124030426454 139.74117018346146 21.475 35.67124233409359 139.74117245668208 21.475 35.67125159073796 139.74116008514287 21.475 35.67124770596771 139.7411602773974 21.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-02fdf5b7-0a90-46ec-9c2b-03c222de5442">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-02fdf5b7-0a90-46ec-9c2b-03c222de5442">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-02fdf5b7-0a90-46ec-9c2b-03c222de5442">
											<gml:posList>35.67120584308692 139.74119153152947 23.621 35.671207907144655 139.7411914186936 23.621 35.67123035542459 139.74116143512126 23.621 35.67123026334255 139.74115889456047 23.621 35.67120584308692 139.74119153152947 23.621</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-46ae3a51-612d-4fdb-a1a6-f7aceb5338d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-46ae3a51-612d-4fdb-a1a6-f7aceb5338d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-46ae3a51-612d-4fdb-a1a6-f7aceb5338d5">
											<gml:posList>35.671171210176006 139.74123583413018 20.048 35.671178499683975 139.74124422099752 20.048 35.671205486929374 139.74120905148672 20.048 35.67112806267263 139.74111965386697 20.048 35.67110101247532 139.7411549780952 20.048 35.671171210176006 139.74123583413018 20.048</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b0ed6f0c-b86d-4f56-9fcc-94e78b671e3a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b0ed6f0c-b86d-4f56-9fcc-94e78b671e3a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b0ed6f0c-b86d-4f56-9fcc-94e78b671e3a">
											<gml:posList>35.67123035542459 139.74116143512126 23.277 35.671207907144655 139.7411914186936 23.277 35.67121783077538 139.74120256412746 23.277 35.671240261030626 139.7411725805752 23.277 35.67123035542459 139.74116143512126 23.277</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4c0d9981-7d09-4cc3-aecd-c8c5a47cfa2c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c0d9981-7d09-4cc3-aecd-c8c5a47cfa2c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c0d9981-7d09-4cc3-aecd-c8c5a47cfa2c">
											<gml:posList>35.67121791383433 139.74120509365187 23.621 35.67124233409359 139.74117245668208 23.621 35.671240261030626 139.7411725805752 23.621 35.67121783077538 139.74120256412746 23.621 35.67121791383433 139.74120509365187 23.621</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cf8094e6-4edf-4876-b251-d35081c1d6f5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cf8094e6-4edf-4876-b251-d35081c1d6f5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cf8094e6-4edf-4876-b251-d35081c1d6f5">
											<gml:posList>35.67121783077538 139.74120256412746 23.621 35.671207907144655 139.7411914186936 23.621 35.67120584308692 139.74119153152947 23.621 35.67121791383433 139.74120509365187 23.621 35.67121783077538 139.74120256412746 23.621</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3229870e-ebcb-43c5-950d-9180d23b9549">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3229870e-ebcb-43c5-950d-9180d23b9549">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3229870e-ebcb-43c5-950d-9180d23b9549">
											<gml:posList>35.67121261903121 139.7412119816272 20.625 35.67123391925437 139.74123656848147 16.239 35.67127363021508 139.74118482579493 16.243 35.67125159073796 139.74116008514287 20.625 35.67121261903121 139.7412119816272 20.625</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e4eb1339-90a5-419a-bb44-b742c0124ce4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e4eb1339-90a5-419a-bb44-b742c0124ce4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e4eb1339-90a5-419a-bb44-b742c0124ce4">
											<gml:posList>35.671169058059405 139.74123866447258 20.544 35.671178648093644 139.74124969982634 20.544 35.671178499683975 139.74124422099752 20.544 35.671171210176006 139.74123583413018 20.544 35.67110101247532 139.7411549780952 20.544 35.67109666786142 139.74115498309024 20.544 35.6710977506919 139.74115652833547 20.544 35.671169058059405 139.74123866447258 20.544</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-09c3d4c9-a931-4934-ab7b-dc5878ad8036">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-09c3d4c9-a931-4934-ab7b-dc5878ad8036">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-09c3d4c9-a931-4934-ab7b-dc5878ad8036">
											<gml:posList>35.67121261903121 139.7412119816272 21.475 35.67121791383433 139.74120509365187 21.475 35.67121584791721 139.7412027762871 21.475 35.67121248918817 139.74120720974275 21.475 35.67121261903121 139.7412119816272 21.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fcbd5010-77c6-4605-a16d-8aa4384998d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fcbd5010-77c6-4605-a16d-8aa4384998d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fcbd5010-77c6-4605-a16d-8aa4384998d7">
											<gml:posList>35.6710677061788 139.74121313125735 18.675 35.67112742064148 139.741281892531 18.675 35.67116455624132 139.7412334778509 18.675 35.67110017752242 139.74115932027414 18.675 35.67106300590556 139.74120774603733 18.675 35.6710677061788 139.74121313125735 18.675</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c1349c69-d68c-4d6f-80a0-6fa54056bec2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c1349c69-d68c-4d6f-80a0-6fa54056bec2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c1349c69-d68c-4d6f-80a0-6fa54056bec2">
											<gml:posList>35.67106300590556 139.74120774603733 19.66 35.67110017752242 139.74115932027414 19.66 35.6710977506919 139.74115652833547 19.66 35.67105830990015 139.74120793922128 19.66 35.67106543699416 139.74121610533382 19.66 35.671127569268975 139.74128765856156 19.66 35.67116698307003 139.7412362697942 19.66 35.67116455624132 139.7412334778509 19.66 35.67112742064148 139.741281892531 19.66 35.6710677061788 139.74121313125735 19.66 35.67106300590556 139.74120774603733 19.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f40bcdd0-16a0-47ed-9ee3-dd37d40f51c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f40bcdd0-16a0-47ed-9ee3-dd37d40f51c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f40bcdd0-16a0-47ed-9ee3-dd37d40f51c9">
											<gml:posList>35.67106543699416 139.74121610533382 27.299 35.67104905103168 139.74124097845166 27.299 35.67105190934463 139.74124223445264 27.299 35.67106573838486 139.74122125258847 27.299 35.67106543699416 139.74121610533382 27.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-88d46843-0c3e-45b6-bed3-f9c27c88978c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-88d46843-0c3e-45b6-bed3-f9c27c88978c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-88d46843-0c3e-45b6-bed3-f9c27c88978c">
											<gml:posList>35.671178499683975 139.74124422099752 20.544 35.671178648093644 139.74124969982634 20.544 35.67120994860328 139.74120889171084 20.544 35.671205486929374 139.74120905148672 20.544 35.671178499683975 139.74124422099752 20.544</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-63ba7db5-6dc5-4d8a-9d64-1c4f9e225d34">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-63ba7db5-6dc5-4d8a-9d64-1c4f9e225d34">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-63ba7db5-6dc5-4d8a-9d64-1c4f9e225d34">
											<gml:posList>35.67120994860328 139.74120889171084 20.359 35.671178648093644 139.74124969982634 20.359 35.67120294347437 139.74127769657034 16.239 35.67123391925437 139.74123656848147 16.239 35.67120994860328 139.74120889171084 20.359</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-aaa996c6-e13a-4951-aa7f-4a3718e77a20">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aaa996c6-e13a-4951-aa7f-4a3718e77a20">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aaa996c6-e13a-4951-aa7f-4a3718e77a20">
											<gml:posList>35.67117762864764 139.74124853008203 22.412 35.671169058059405 139.74123866447258 22.412 35.67116915117045 139.7412425526872 22.412 35.67117446494114 139.74124867731848 22.412 35.67117762864764 139.74124853008203 22.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3ca7620a-7aab-4b6f-82aa-2a8f84f606a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ca7620a-7aab-4b6f-82aa-2a8f84f606a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ca7620a-7aab-4b6f-82aa-2a8f84f606a7">
											<gml:posList>35.67106573838486 139.74122125258847 26.864 35.67105190934463 139.74124223445264 26.864 35.671051893672356 139.74126888931815 26.864 35.67110859134256 139.74127060267688 26.864 35.67106573838486 139.74122125258847 26.864</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4ae4f9fb-d46d-4baa-9125-29a844805c8c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ae4f9fb-d46d-4baa-9125-29a844805c8c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ae4f9fb-d46d-4baa-9125-29a844805c8c">
											<gml:posList>35.671110538357155 139.74127066671934 27.299 35.67113848728779 139.74130258071122 27.299 35.67113949592126 139.74130139759248 27.299 35.67106543699416 139.74121610533382 27.299 35.67106573838486 139.74122125258847 27.299 35.67110859134256 139.74127060267688 27.299 35.671110538357155 139.74127066671934 27.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-36a4d79b-131d-4cac-b907-44a42fa14fce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36a4d79b-131d-4cac-b907-44a42fa14fce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36a4d79b-131d-4cac-b907-44a42fa14fce">
											<gml:posList>35.67112982468375 139.7412902518675 17.198 35.671169058059405 139.74123866447258 17.198 35.67116698307003 139.7412362697942 17.198 35.671127569268975 139.74128765856156 17.198 35.67112982468375 139.7412902518675 17.198</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-788111c3-a4e2-475b-afa1-96abc4f28a3f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-788111c3-a4e2-475b-afa1-96abc4f28a3f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-788111c3-a4e2-475b-afa1-96abc4f28a3f">
											<gml:posList>35.67116915117045 139.7412425526872 22.412 35.671169058059405 139.74123866447258 22.412 35.67112982468375 139.7412902518675 22.412 35.6711329793935 139.7412901267358 22.412 35.67116915117045 139.7412425526872 22.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-eb3171b5-dbae-4290-8230-0baf6ed8af47">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eb3171b5-dbae-4290-8230-0baf6ed8af47">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eb3171b5-dbae-4290-8230-0baf6ed8af47">
											<gml:posList>35.67116915117045 139.7412425526872 21.816 35.6711329793935 139.7412901267358 21.816 35.671138248042524 139.7412961851411 21.816 35.67117446494114 139.74124867731848 21.816 35.67116915117045 139.7412425526872 21.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1acb436b-1f36-4852-b950-6083e50753d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1acb436b-1f36-4852-b950-6083e50753d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1acb436b-1f36-4852-b950-6083e50753d4">
											<gml:posList>35.67107894450203 139.74126970882546 32.111 35.671051893672356 139.74126888931815 32.111 35.67105371623467 139.74127122905205 32.111 35.671077044304276 139.7412719313249 32.111 35.67107894450203 139.74126970882546 32.111</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9559d685-0666-4d9f-9e9d-56cc37ae8920">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9559d685-0666-4d9f-9e9d-56cc37ae8920">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9559d685-0666-4d9f-9e9d-56cc37ae8920">
											<gml:posList>35.671110538357155 139.74127066671934 30.346 35.67107894450203 139.74126970882546 30.346 35.671078892480416 139.741272404196 30.346 35.6711096480425 139.74127334096082 30.346 35.671110538357155 139.74127066671934 30.346</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a4aed16a-da1e-42ea-966f-b4e413165861">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4aed16a-da1e-42ea-966f-b4e413165861">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4aed16a-da1e-42ea-966f-b4e413165861">
											<gml:posList>35.671138341143276 139.74130006230797 22.412 35.67117762864764 139.74124853008203 22.412 35.67117446494114 139.74124867731848 22.412 35.671138248042524 139.7412961851411 22.412 35.671138341143276 139.74130006230797 22.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-90537cf9-2b3f-443e-ac6e-1e125e6ccdb7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-90537cf9-2b3f-443e-ac6e-1e125e6ccdb7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-90537cf9-2b3f-443e-ac6e-1e125e6ccdb7">
											<gml:posList>35.67105100293399 139.7413181791634 27.299 35.671051893672356 139.74126888931815 27.299 35.67105190934463 139.74124223445264 27.299 35.67104905103168 139.74124097845166 27.299 35.67104911001863 139.74131813715044 27.299 35.67105100293399 139.7413181791634 27.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-410c7566-ee2e-47a0-a21d-efbc2ddaa49e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-410c7566-ee2e-47a0-a21d-efbc2ddaa49e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-410c7566-ee2e-47a0-a21d-efbc2ddaa49e">
											<gml:posList>35.6710512093779 139.7413052436483 32.111 35.671053118589995 139.74130302114003 32.111 35.67105371623467 139.74127122905205 32.111 35.671051893672356 139.74126888931815 32.111 35.6710512093779 139.7413052436483 32.111</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-572c20e8-4aee-416d-89ec-2ef6a6b4870c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-572c20e8-4aee-416d-89ec-2ef6a6b4870c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-572c20e8-4aee-416d-89ec-2ef6a6b4870c">
											<gml:posList>35.67105371623467 139.74127122905205 32.003 35.671053118589995 139.74130302114003 32.003 35.67107639257712 139.7413037234842 32.003 35.671077044304276 139.7412719313249 32.003 35.67105371623467 139.74127122905205 32.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a3a88f70-fa6d-4705-8fdc-d02e6a3005ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a3a88f70-fa6d-4705-8fdc-d02e6a3005ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a3a88f70-fa6d-4705-8fdc-d02e6a3005ba">
											<gml:posList>35.671077044304276 139.7412719313249 32.111 35.67107639257712 139.7413037234842 32.111 35.67107820612502 139.74130606322993 32.111 35.67107894450203 139.74126970882546 32.111 35.671077044304276 139.7412719313249 32.111</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-80451b6e-b693-47dc-9c5e-6bed3d0b284f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-80451b6e-b693-47dc-9c5e-6bed3d0b284f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-80451b6e-b693-47dc-9c5e-6bed3d0b284f">
											<gml:posList>35.67120294347437 139.74127769657034 17.198 35.67117762864764 139.74124853008203 22.412 35.671138341143276 139.74130006230797 22.412 35.671159533049 139.74132447254533 18.022 35.67116350263157 139.7413291074642 17.198 35.67120294347437 139.74127769657034 17.198</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ca665374-f812-4d4f-9dd9-75d2e236fdcb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca665374-f812-4d4f-9dd9-75d2e236fdcb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca665374-f812-4d4f-9dd9-75d2e236fdcb">
											<gml:posList>35.67113848728779 139.74130258071122 30.346 35.671110538357155 139.74127066671934 30.346 35.6711096480425 139.74127334096082 30.346 35.67113544982397 139.74130279407873 30.346 35.671134288320246 139.7413044523665 30.346 35.67110947294472 139.74130369655916 30.346 35.67111161129896 139.74130644464836 30.346 35.671135290920205 139.74130716862112 30.346 35.67113848728779 139.74130258071122 30.346</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-18c26b51-8840-449c-ad4c-245d9103c4a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18c26b51-8840-449c-ad4c-245d9103c4a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18c26b51-8840-449c-ad4c-245d9103c4a7">
											<gml:posList>35.67113544982397 139.74130279407873 29.966 35.6711096480425 139.74127334096082 29.966 35.671078892480416 139.741272404196 29.966 35.67107820612502 139.74130606322993 29.966 35.671053417790425 139.74130530739154 29.966 35.67105323633641 139.7413155586147 29.966 35.67110920387764 139.74131725075168 29.966 35.67110947294472 139.74130369655916 29.966 35.671134288320246 139.7413044523665 29.966 35.67113544982397 139.74130279407873 29.966</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c61111aa-0680-4e7e-8d37-81f7b3d58eaa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c61111aa-0680-4e7e-8d37-81f7b3d58eaa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c61111aa-0680-4e7e-8d37-81f7b3d58eaa">
											<gml:posList>35.671138248042524 139.7412961851411 22.412 35.6711329793935 139.7412901267358 22.412 35.67112982468375 139.7412902518675 22.412 35.671138341143276 139.74130006230797 22.412 35.671138248042524 139.7412961851411 22.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-618f9986-897f-46c6-9c7f-f89fabe98524">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-618f9986-897f-46c6-9c7f-f89fabe98524">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-618f9986-897f-46c6-9c7f-f89fabe98524">
											<gml:posList>35.67107639257712 139.7413037234842 32.111 35.671053118589995 139.74130302114003 32.111 35.6710512093779 139.7413052436483 32.111 35.67107820612502 139.74130606322993 32.111 35.67107639257712 139.7413037234842 32.111</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-85c54b42-9a0c-4131-adcf-e8abe4a2f7bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85c54b42-9a0c-4131-adcf-e8abe4a2f7bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85c54b42-9a0c-4131-adcf-e8abe4a2f7bd">
											<gml:posList>35.671053417790425 139.74130530739154 30.346 35.6710512093779 139.7413052436483 30.346 35.67105100293399 139.7413181791634 30.346 35.67105323633641 139.7413155586147 30.346 35.671053417790425 139.74130530739154 30.346</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d13f79f7-1847-4b5a-9dc1-e9e55ad94548">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d13f79f7-1847-4b5a-9dc1-e9e55ad94548">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d13f79f7-1847-4b5a-9dc1-e9e55ad94548">
											<gml:posList>35.67110947294472 139.74130369655916 30.346 35.67110920387764 139.74131725075168 30.346 35.67111134223158 139.74131999884122 30.346 35.67111161129896 139.74130644464836 30.346 35.67110947294472 139.74130369655916 30.346</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3358eb8d-1b2d-41cc-88eb-5438bd441892">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3358eb8d-1b2d-41cc-88eb-5438bd441892">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3358eb8d-1b2d-41cc-88eb-5438bd441892">
											<gml:posList>35.67113811813046 139.74130311136042 27.299 35.671156910157265 139.74132460811177 27.299 35.671159533049 139.74132447254533 27.299 35.67113949592126 139.74130139759248 27.299 35.67113848728779 139.74130258071122 27.299 35.67113811813046 139.74130311136042 27.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e24d5e4c-fd48-4534-999f-332bee7c7d14">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e24d5e4c-fd48-4534-999f-332bee7c7d14">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e24d5e4c-fd48-4534-999f-332bee7c7d14">
											<gml:posList>35.67110920387764 139.74131725075168 30.346 35.67105323633641 139.7413155586147 30.346 35.67105100293399 139.7413181791634 30.346 35.67111134223158 139.74131999884122 30.346 35.67110920387764 139.74131725075168 30.346</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4f2bfdd4-16cf-4d92-8bd8-939cfcbce511">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f2bfdd4-16cf-4d92-8bd8-939cfcbce511">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f2bfdd4-16cf-4d92-8bd8-939cfcbce511">
											<gml:posList>35.67111134223158 139.74131999884122 26.812 35.67107677378108 139.74131895597088 26.812 35.67107655898873 139.7413327641617 26.812 35.67114969766951 139.74133443660776 26.812 35.671156910157265 139.74132460811177 26.812 35.67113811813046 139.74130311136042 26.812 35.671135290920205 139.74130716862112 26.812 35.67111161129896 139.74130644464836 26.812 35.67111134223158 139.74131999884122 26.812</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0b1ae22a-9ba6-4993-be12-0d9db14ea756">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b1ae22a-9ba6-4993-be12-0d9db14ea756">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b1ae22a-9ba6-4993-be12-0d9db14ea756">
											<gml:posList>35.67107652468089 139.74133505079666 27.299 35.67105100293399 139.7413181791634 29.497 35.67104911001863 139.74131813715044 29.497 35.67107652468089 139.74133505079666 27.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-45a31e74-b420-421d-9a7e-20d84dcf859b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45a31e74-b420-421d-9a7e-20d84dcf859b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45a31e74-b420-421d-9a7e-20d84dcf859b">
											<gml:posList>35.67107652468089 139.74133505079666 27.299 35.67107677378108 139.74131895597088 29.497 35.67105100293399 139.7413181791634 29.497 35.67107652468089 139.74133505079666 27.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ca131735-d436-42ea-8fc4-8efb46b9b018">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca131735-d436-42ea-8fc4-8efb46b9b018">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca131735-d436-42ea-8fc4-8efb46b9b018">
											<gml:posList>35.671150528695804 139.7413367443446 27.299 35.671159533049 139.74132447254533 27.299 35.671156910157265 139.74132460811177 27.299 35.67114969766951 139.74133443660776 27.299 35.671150528695804 139.7413367443446 27.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9e2321e3-8027-42f0-b3ea-840ca0dddce1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e2321e3-8027-42f0-b3ea-840ca0dddce1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e2321e3-8027-42f0-b3ea-840ca0dddce1">
											<gml:posList>35.67107652468089 139.74133505079666 27.299 35.67104911001863 139.74131813715044 29.497 35.67104887347582 139.74135066892754 25.346 35.67107652468089 139.74133505079666 27.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-520e92f2-9813-432a-af33-6f0df6e5f369">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-520e92f2-9813-432a-af33-6f0df6e5f369">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-520e92f2-9813-432a-af33-6f0df6e5f369">
											<gml:posList>35.67114969766951 139.74133443660776 27.299 35.67107655898873 139.7413327641617 27.299 35.67107652468089 139.74133505079666 27.299 35.671150528695804 139.7413367443446 27.299 35.67114969766951 139.74133443660776 27.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9683cff5-55d4-4e8d-9e98-5008a65bd99c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9683cff5-55d4-4e8d-9e98-5008a65bd99c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9683cff5-55d4-4e8d-9e98-5008a65bd99c">
											<gml:posList>35.671150528695804 139.7413367443446 27.299 35.67107652468089 139.74133505079666 27.299 35.671138282219886 139.74135270934633 25.346 35.671150528695804 139.7413367443446 27.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-98317b40-368c-4680-babc-f4b55d0ead64">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-98317b40-368c-4680-babc-f4b55d0ead64">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-98317b40-368c-4680-babc-f4b55d0ead64">
											<gml:posList>35.67107652468089 139.74133505079666 27.299 35.67104887347582 139.74135066892754 25.346 35.671138282219886 139.74135270934633 25.346 35.67107652468089 139.74133505079666 27.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bf751557-5c6a-482e-807d-85a7cb120d60">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf751557-5c6a-482e-807d-85a7cb120d60">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf751557-5c6a-482e-807d-85a7cb120d60">
											<gml:posList>35.67112385453745 139.74110955128577 8.307 35.67112385453745 139.74110955128577 21.475 35.67116185393767 139.74105924660515 21.475 35.67116185393767 139.74105924660515 8.307 35.67112385453745 139.74110955128577 8.307</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ecebfe73-eb2c-4216-90e7-c9dd894ea358">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ecebfe73-eb2c-4216-90e7-c9dd894ea358">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ecebfe73-eb2c-4216-90e7-c9dd894ea358">
											<gml:posList>35.67124770596771 139.7411602773974 21.475 35.67116201080235 139.74106398531617 21.475 35.67116201080235 139.74106398531617 21.261 35.67124770596771 139.7411602773974 21.261 35.67124770596771 139.7411602773974 21.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6d3aae3a-fc25-4026-b526-96d4383bf63e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d3aae3a-fc25-4026-b526-96d4383bf63e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d3aae3a-fc25-4026-b526-96d4383bf63e">
											<gml:posList>35.67112791426552 139.74111418608823 20.544 35.67112791426552 139.74111418608823 8.307 35.67109666786142 139.74115498309024 8.307 35.67109666786142 139.74115498309024 20.544 35.67112791426552 139.74111418608823 20.544</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-de795e19-1b57-4280-8a55-8dc18526ab20">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de795e19-1b57-4280-8a55-8dc18526ab20">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de795e19-1b57-4280-8a55-8dc18526ab20">
											<gml:posList>35.67112772129716 139.7411093811425 21.475 35.67121248918817 139.74120720974275 21.475 35.67121248918817 139.74120720974275 21.261 35.67112772129716 139.7411093811425 21.261 35.67112772129716 139.7411093811425 21.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0e2e01d8-0b73-4c3b-8f10-49b4d5f774c8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e2e01d8-0b73-4c3b-8f10-49b4d5f774c8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e2e01d8-0b73-4c3b-8f10-49b4d5f774c8">
											<gml:posList>35.671207907144655 139.7411914186936 23.277 35.67123035542459 139.74116143512126 23.277 35.67123035542459 139.74116143512126 23.621 35.671207907144655 139.7411914186936 23.621 35.671207907144655 139.7411914186936 23.277</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-486a232a-9ab2-4205-ae51-1c8c900e69e1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-486a232a-9ab2-4205-ae51-1c8c900e69e1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-486a232a-9ab2-4205-ae51-1c8c900e69e1">
											<gml:posList>35.67121783077538 139.74120256412746 23.621 35.671240261030626 139.7411725805752 23.621 35.671240261030626 139.7411725805752 23.277 35.67121783077538 139.74120256412746 23.277 35.67121783077538 139.74120256412746 23.621</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a79ce051-648f-4565-9fe5-ac6d2a890511">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a79ce051-648f-4565-9fe5-ac6d2a890511">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a79ce051-648f-4565-9fe5-ac6d2a890511">
											<gml:posList>35.671171210176006 139.74123583413018 20.048 35.67110101247532 139.7411549780952 20.048 35.67110101247532 139.7411549780952 20.544 35.671171210176006 139.74123583413018 20.544 35.671171210176006 139.74123583413018 20.048</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8f9c8ce7-b934-419b-984a-8a54d2b41623">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f9c8ce7-b934-419b-984a-8a54d2b41623">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f9c8ce7-b934-419b-984a-8a54d2b41623">
											<gml:posList>35.67116698307003 139.7412362697942 17.198 35.67116698307003 139.7412362697942 19.66 35.671127569268975 139.74128765856156 19.66 35.671127569268975 139.74128765856156 17.198 35.67116698307003 139.7412362697942 17.198</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-489e778b-b21f-4cc8-b3eb-bead934d9a9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-489e778b-b21f-4cc8-b3eb-bead934d9a9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-489e778b-b21f-4cc8-b3eb-bead934d9a9a">
											<gml:posList>35.671138248042524 139.7412961851411 22.412 35.67117446494114 139.74124867731848 22.412 35.67117446494114 139.74124867731848 21.816 35.671138248042524 139.7412961851411 21.816 35.671138248042524 139.7412961851411 22.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c8e275b1-09bf-4704-bfc0-79fea8de0321">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8e275b1-09bf-4704-bfc0-79fea8de0321">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8e275b1-09bf-4704-bfc0-79fea8de0321">
											<gml:posList>35.671134288320246 139.7413044523665 29.966 35.67110947294472 139.74130369655916 29.966 35.67110947294472 139.74130369655916 30.346 35.671134288320246 139.7413044523665 30.346 35.671134288320246 139.7413044523665 29.966</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e5703b47-44db-4990-8948-d0878239a700">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5703b47-44db-4990-8948-d0878239a700">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5703b47-44db-4990-8948-d0878239a700">
											<gml:posList>35.67104887347582 139.74135066892754 25.346 35.67104911001863 139.74131813715044 29.497 35.67104911001863 139.74131813715044 27.299 35.67104905103168 139.74124097845166 27.299 35.67104905103168 139.74124097845166 8.307 35.67104887347582 139.74135066892754 8.307 35.67104887347582 139.74135066892754 25.346</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2a444b7d-22be-40e6-a315-a833979db1d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a444b7d-22be-40e6-a315-a833979db1d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a444b7d-22be-40e6-a315-a833979db1d2">
											<gml:posList>35.67104911001863 139.74131813715044 27.299 35.67104911001863 139.74131813715044 29.497 35.67105100293399 139.7413181791634 29.497 35.67105100293399 139.7413181791634 27.299 35.67104911001863 139.74131813715044 27.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1d12d993-2974-41ce-a0a7-3c04549cd948">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d12d993-2974-41ce-a0a7-3c04549cd948">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d12d993-2974-41ce-a0a7-3c04549cd948">
											<gml:posList>35.67105100293399 139.7413181791634 29.497 35.67105100293399 139.7413181791634 30.346 35.6710512093779 139.7413052436483 30.346 35.6710512093779 139.7413052436483 32.111 35.671051893672356 139.74126888931815 32.111 35.671051893672356 139.74126888931815 27.299 35.67105100293399 139.7413181791634 27.299 35.67105100293399 139.7413181791634 29.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-88529f80-4d23-406f-9b01-af9971cb2964">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-88529f80-4d23-406f-9b01-af9971cb2964">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-88529f80-4d23-406f-9b01-af9971cb2964">
											<gml:posList>35.67105190934463 139.74124223445264 26.864 35.67105190934463 139.74124223445264 27.299 35.671051893672356 139.74126888931815 27.299 35.671051893672356 139.74126888931815 26.864 35.67105190934463 139.74124223445264 26.864</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f3f04fb5-841f-4c13-89d7-088786e10be6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f3f04fb5-841f-4c13-89d7-088786e10be6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f3f04fb5-841f-4c13-89d7-088786e10be6">
											<gml:posList>35.67105323633641 139.7413155586147 29.966 35.671053417790425 139.74130530739154 29.966 35.671053417790425 139.74130530739154 30.346 35.67105323633641 139.7413155586147 30.346 35.67105323633641 139.7413155586147 29.966</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-359e235c-7a8d-4531-9923-439dc71a7ca5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-359e235c-7a8d-4531-9923-439dc71a7ca5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-359e235c-7a8d-4531-9923-439dc71a7ca5">
											<gml:posList>35.671053118589995 139.74130302114003 32.003 35.67105371623467 139.74127122905205 32.003 35.67105371623467 139.74127122905205 32.111 35.671053118589995 139.74130302114003 32.111 35.671053118589995 139.74130302114003 32.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2e9c50ed-bb59-40e7-95ec-af493a8aaeee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2e9c50ed-bb59-40e7-95ec-af493a8aaeee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2e9c50ed-bb59-40e7-95ec-af493a8aaeee">
											<gml:posList>35.67106543699416 139.74121610533382 19.66 35.67106543699416 139.74121610533382 8.307 35.67104905103168 139.74124097845166 8.307 35.67104905103168 139.74124097845166 27.299 35.67106543699416 139.74121610533382 27.299 35.67106543699416 139.74121610533382 19.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9cf53969-576f-437c-91f1-f0a6fa621d86">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9cf53969-576f-437c-91f1-f0a6fa621d86">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9cf53969-576f-437c-91f1-f0a6fa621d86">
											<gml:posList>35.67105190934463 139.74124223445264 26.864 35.67106573838486 139.74122125258847 26.864 35.67106573838486 139.74122125258847 27.299 35.67105190934463 139.74124223445264 27.299 35.67105190934463 139.74124223445264 26.864</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bf0f8795-25bd-4a89-b799-c3ccd11e8b15">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf0f8795-25bd-4a89-b799-c3ccd11e8b15">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf0f8795-25bd-4a89-b799-c3ccd11e8b15">
											<gml:posList>35.67106543699416 139.74121610533382 8.307 35.67106543699416 139.74121610533382 19.66 35.67105830990015 139.74120793922128 19.66 35.67105830990015 139.74120793922128 8.307 35.67106543699416 139.74121610533382 8.307</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0257418b-7b93-40ff-a277-b34d3949decc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0257418b-7b93-40ff-a277-b34d3949decc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0257418b-7b93-40ff-a277-b34d3949decc">
											<gml:posList>35.671053417790425 139.74130530739154 30.346 35.671053417790425 139.74130530739154 29.966 35.67107820612502 139.74130606322993 29.966 35.67107820612502 139.74130606322993 32.111 35.6710512093779 139.7413052436483 32.111 35.6710512093779 139.7413052436483 30.346 35.671053417790425 139.74130530739154 30.346</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2e4c7c9d-740e-488d-8fb2-f92f496a25bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2e4c7c9d-740e-488d-8fb2-f92f496a25bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2e4c7c9d-740e-488d-8fb2-f92f496a25bd">
											<gml:posList>35.67107639257712 139.7413037234842 32.003 35.671053118589995 139.74130302114003 32.003 35.671053118589995 139.74130302114003 32.111 35.67107639257712 139.7413037234842 32.111 35.67107639257712 139.7413037234842 32.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f257f652-4ca3-4412-bf18-c2abca720ce7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f257f652-4ca3-4412-bf18-c2abca720ce7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f257f652-4ca3-4412-bf18-c2abca720ce7">
											<gml:posList>35.67105371623467 139.74127122905205 32.003 35.671077044304276 139.7412719313249 32.003 35.671077044304276 139.7412719313249 32.111 35.67105371623467 139.74127122905205 32.111 35.67105371623467 139.74127122905205 32.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e19a6749-a77f-44e9-80b4-3c9cbdcaf985">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e19a6749-a77f-44e9-80b4-3c9cbdcaf985">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e19a6749-a77f-44e9-80b4-3c9cbdcaf985">
											<gml:posList>35.67106300590556 139.74120774603733 19.66 35.6710677061788 139.74121313125735 19.66 35.6710677061788 139.74121313125735 18.675 35.67106300590556 139.74120774603733 18.675 35.67106300590556 139.74120774603733 19.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6ad55ac3-709b-498e-806e-75f65add82f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ad55ac3-709b-498e-806e-75f65add82f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ad55ac3-709b-498e-806e-75f65add82f7">
											<gml:posList>35.67107655898873 139.7413327641617 27.299 35.67107677378108 139.74131895597088 29.497 35.67107652468089 139.74133505079666 27.299 35.67107655898873 139.7413327641617 27.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-23703003-0eb7-4019-810a-ddccfaa8f3bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-23703003-0eb7-4019-810a-ddccfaa8f3bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-23703003-0eb7-4019-810a-ddccfaa8f3bd">
											<gml:posList>35.67107655898873 139.7413327641617 27.299 35.67107655898873 139.7413327641617 26.812 35.67107677378108 139.74131895597088 26.812 35.67107655898873 139.7413327641617 27.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2e0bc04a-8f49-45c0-885f-ceace7e1e057">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2e0bc04a-8f49-45c0-885f-ceace7e1e057">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2e0bc04a-8f49-45c0-885f-ceace7e1e057">
											<gml:posList>35.67107655898873 139.7413327641617 27.299 35.67107677378108 139.74131895597088 26.812 35.67107677378108 139.74131895597088 29.497 35.67107655898873 139.7413327641617 27.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f7280399-637f-422d-b7e2-a9c9a648407e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f7280399-637f-422d-b7e2-a9c9a648407e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f7280399-637f-422d-b7e2-a9c9a648407e">
											<gml:posList>35.671077044304276 139.7412719313249 32.003 35.67107639257712 139.7413037234842 32.003 35.67107639257712 139.7413037234842 32.111 35.671077044304276 139.7412719313249 32.111 35.671077044304276 139.7412719313249 32.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6864f657-fc90-4bd8-9e40-8f658d6974f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6864f657-fc90-4bd8-9e40-8f658d6974f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6864f657-fc90-4bd8-9e40-8f658d6974f8">
											<gml:posList>35.67105830990015 139.74120793922128 8.307 35.67105830990015 139.74120793922128 19.66 35.6710977506919 139.74115652833547 19.66 35.6710977506919 139.74115652833547 8.307 35.67105830990015 139.74120793922128 8.307</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-96e6501c-3640-4fd3-ae6c-df8c670d5314">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96e6501c-3640-4fd3-ae6c-df8c670d5314">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96e6501c-3640-4fd3-ae6c-df8c670d5314">
											<gml:posList>35.67107820612502 139.74130606322993 29.966 35.671078892480416 139.741272404196 29.966 35.671078892480416 139.741272404196 30.346 35.67107894450203 139.74126970882546 30.346 35.67107894450203 139.74126970882546 32.111 35.67107820612502 139.74130606322993 32.111 35.67107820612502 139.74130606322993 29.966</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-85f1480a-7e38-4000-939d-08f12dc8c134">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85f1480a-7e38-4000-939d-08f12dc8c134">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85f1480a-7e38-4000-939d-08f12dc8c134">
											<gml:posList>35.67107677378108 139.74131895597088 29.497 35.67107677378108 139.74131895597088 26.812 35.67111134223158 139.74131999884122 26.812 35.67111134223158 139.74131999884122 30.346 35.67105100293399 139.7413181791634 30.346 35.67105100293399 139.7413181791634 29.497 35.67107677378108 139.74131895597088 29.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-07866816-39fa-4ba2-ab07-fea35fdf805f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-07866816-39fa-4ba2-ab07-fea35fdf805f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-07866816-39fa-4ba2-ab07-fea35fdf805f">
											<gml:posList>35.67110920387764 139.74131725075168 29.966 35.67105323633641 139.7413155586147 29.966 35.67105323633641 139.7413155586147 30.346 35.67110920387764 139.74131725075168 30.346 35.67110920387764 139.74131725075168 29.966</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-db5a9366-ddcf-427a-a4db-68ec275231bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db5a9366-ddcf-427a-a4db-68ec275231bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db5a9366-ddcf-427a-a4db-68ec275231bc">
											<gml:posList>35.67110859134256 139.74127060267688 27.299 35.67110859134256 139.74127060267688 26.864 35.671051893672356 139.74126888931815 26.864 35.671051893672356 139.74126888931815 27.299 35.671051893672356 139.74126888931815 32.111 35.67107894450203 139.74126970882546 32.111 35.67107894450203 139.74126970882546 30.346 35.671110538357155 139.74127066671934 30.346 35.671110538357155 139.74127066671934 27.299 35.67110859134256 139.74127060267688 27.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d0fe7265-c171-4bcd-b42c-09110371ff24">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d0fe7265-c171-4bcd-b42c-09110371ff24">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d0fe7265-c171-4bcd-b42c-09110371ff24">
											<gml:posList>35.67110017752242 139.74115932027414 19.66 35.67106300590556 139.74120774603733 19.66 35.67106300590556 139.74120774603733 18.675 35.67110017752242 139.74115932027414 18.675 35.67110017752242 139.74115932027414 19.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-826e842c-8227-46fd-8392-9ef24b5a436b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-826e842c-8227-46fd-8392-9ef24b5a436b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-826e842c-8227-46fd-8392-9ef24b5a436b">
											<gml:posList>35.67106573838486 139.74122125258847 26.864 35.67110859134256 139.74127060267688 26.864 35.67110859134256 139.74127060267688 27.299 35.67106573838486 139.74122125258847 27.299 35.67106573838486 139.74122125258847 26.864</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7861fdfd-b6e2-4daa-8352-cbc03a4f4c91">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7861fdfd-b6e2-4daa-8352-cbc03a4f4c91">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7861fdfd-b6e2-4daa-8352-cbc03a4f4c91">
											<gml:posList>35.67104887347582 139.74135066892754 8.307 35.671138282219886 139.74135270934633 8.307 35.671138282219886 139.74135270934633 25.346 35.67104887347582 139.74135066892754 25.346 35.67104887347582 139.74135066892754 8.307</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4db38e42-1acf-474c-bcee-f6c100847456">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4db38e42-1acf-474c-bcee-f6c100847456">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4db38e42-1acf-474c-bcee-f6c100847456">
											<gml:posList>35.671078892480416 139.741272404196 29.966 35.6711096480425 139.74127334096082 29.966 35.6711096480425 139.74127334096082 30.346 35.671078892480416 139.741272404196 30.346 35.671078892480416 139.741272404196 29.966</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9c59ef3b-25f0-48fe-8691-be4f6c146223">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c59ef3b-25f0-48fe-8691-be4f6c146223">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c59ef3b-25f0-48fe-8691-be4f6c146223">
											<gml:posList>35.67109666786142 139.74115498309024 20.544 35.67109666786142 139.74115498309024 8.307 35.6710977506919 139.74115652833547 8.307 35.6710977506919 139.74115652833547 19.66 35.6710977506919 139.74115652833547 20.544 35.67109666786142 139.74115498309024 20.544</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4bb21f36-c772-4a1c-9e3f-fb510d0061d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4bb21f36-c772-4a1c-9e3f-fb510d0061d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4bb21f36-c772-4a1c-9e3f-fb510d0061d5">
											<gml:posList>35.67112742064148 139.741281892531 18.675 35.6710677061788 139.74121313125735 18.675 35.6710677061788 139.74121313125735 19.66 35.67112742064148 139.741281892531 19.66 35.67112742064148 139.741281892531 18.675</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-66733861-9642-4ec4-b509-813fcd9366a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66733861-9642-4ec4-b509-813fcd9366a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66733861-9642-4ec4-b509-813fcd9366a5">
											<gml:posList>35.67110947294472 139.74130369655916 29.966 35.67110920387764 139.74131725075168 29.966 35.67110920387764 139.74131725075168 30.346 35.67110947294472 139.74130369655916 30.346 35.67110947294472 139.74130369655916 29.966</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bd8052cf-e2bc-481c-8eff-dd31c75b43ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd8052cf-e2bc-481c-8eff-dd31c75b43ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd8052cf-e2bc-481c-8eff-dd31c75b43ce">
											<gml:posList>35.67111134223158 139.74131999884122 26.812 35.67111161129896 139.74130644464836 26.812 35.67111161129896 139.74130644464836 30.346 35.67111134223158 139.74131999884122 30.346 35.67111134223158 139.74131999884122 26.812</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bfd6d48a-4ed9-4932-b04b-e5aef9d4fac5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bfd6d48a-4ed9-4932-b04b-e5aef9d4fac5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bfd6d48a-4ed9-4932-b04b-e5aef9d4fac5">
											<gml:posList>35.67112982468375 139.7412902518675 22.412 35.67112982468375 139.7412902518675 17.198 35.671127569268975 139.74128765856156 17.198 35.671127569268975 139.74128765856156 19.66 35.67106543699416 139.74121610533382 19.66 35.67106543699416 139.74121610533382 27.299 35.67113949592126 139.74130139759248 27.299 35.671159533049 139.74132447254533 27.299 35.671159533049 139.74132447254533 18.022 35.671138341143276 139.74130006230797 22.412 35.67112982468375 139.7412902518675 22.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b11c7518-f7d7-4cff-a60f-3be70b0e07b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b11c7518-f7d7-4cff-a60f-3be70b0e07b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b11c7518-f7d7-4cff-a60f-3be70b0e07b2">
											<gml:posList>35.67114969766951 139.74133443660776 27.299 35.67114969766951 139.74133443660776 26.812 35.67107655898873 139.7413327641617 26.812 35.67107655898873 139.7413327641617 27.299 35.67114969766951 139.74133443660776 27.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6c03eb54-80fa-4477-9b89-4b27d1e0cd1a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c03eb54-80fa-4477-9b89-4b27d1e0cd1a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c03eb54-80fa-4477-9b89-4b27d1e0cd1a">
											<gml:posList>35.67110101247532 139.7411549780952 20.048 35.67112806267263 139.74111965386697 20.048 35.67112806267263 139.74111965386697 20.544 35.67110101247532 139.7411549780952 20.544 35.67110101247532 139.7411549780952 20.048</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1635f2c1-14d0-4531-b428-a05895a8ee20">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1635f2c1-14d0-4531-b428-a05895a8ee20">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1635f2c1-14d0-4531-b428-a05895a8ee20">
											<gml:posList>35.6711096480425 139.74127334096082 29.966 35.67113544982397 139.74130279407873 29.966 35.67113544982397 139.74130279407873 30.346 35.6711096480425 139.74127334096082 30.346 35.6711096480425 139.74127334096082 29.966</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-270d9cf2-bd53-4af2-8e24-ada9bc92f18a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-270d9cf2-bd53-4af2-8e24-ada9bc92f18a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-270d9cf2-bd53-4af2-8e24-ada9bc92f18a">
											<gml:posList>35.67111161129896 139.74130644464836 26.812 35.671135290920205 139.74130716862112 26.812 35.671135290920205 139.74130716862112 30.346 35.67111161129896 139.74130644464836 30.346 35.67111161129896 139.74130644464836 26.812</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-52cbb6ad-fd7e-4b8b-b8bf-6f87f509ad84">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-52cbb6ad-fd7e-4b8b-b8bf-6f87f509ad84">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-52cbb6ad-fd7e-4b8b-b8bf-6f87f509ad84">
											<gml:posList>35.671110538357155 139.74127066671934 30.346 35.67113848728779 139.74130258071122 30.346 35.67113848728779 139.74130258071122 27.299 35.671110538357155 139.74127066671934 27.299 35.671110538357155 139.74127066671934 30.346</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-61df6678-6131-4215-8604-c4e7a68c0e40">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61df6678-6131-4215-8604-c4e7a68c0e40">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61df6678-6131-4215-8604-c4e7a68c0e40">
											<gml:posList>35.67112385453745 139.74110955128577 21.475 35.67112385453745 139.74110955128577 8.307 35.67112791426552 139.74111418608823 20.544 35.67112385453745 139.74110955128577 21.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-723d3aea-0dba-4969-ada4-f22d4697189b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-723d3aea-0dba-4969-ada4-f22d4697189b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-723d3aea-0dba-4969-ada4-f22d4697189b">
											<gml:posList>35.67112385453745 139.74110955128577 8.307 35.67112791426552 139.74111418608823 8.307 35.67112791426552 139.74111418608823 20.544 35.67112385453745 139.74110955128577 8.307</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e07f7d76-f7df-44b2-9722-44dc8ce04f86">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e07f7d76-f7df-44b2-9722-44dc8ce04f86">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e07f7d76-f7df-44b2-9722-44dc8ce04f86">
											<gml:posList>35.671169058059405 139.74123866447258 20.544 35.6710977506919 139.74115652833547 20.544 35.6710977506919 139.74115652833547 19.66 35.67110017752242 139.74115932027414 19.66 35.67110017752242 139.74115932027414 18.675 35.67116455624132 139.7412334778509 18.675 35.67116455624132 139.7412334778509 19.66 35.67116698307003 139.7412362697942 19.66 35.67116698307003 139.7412362697942 17.198 35.671169058059405 139.74123866447258 17.198 35.671169058059405 139.74123866447258 20.544</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d016a379-cd60-464d-90fa-00ccc7255efe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d016a379-cd60-464d-90fa-00ccc7255efe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d016a379-cd60-464d-90fa-00ccc7255efe">
											<gml:posList>35.67113544982397 139.74130279407873 29.966 35.671134288320246 139.7413044523665 29.966 35.671134288320246 139.7413044523665 30.346 35.67113544982397 139.74130279407873 30.346 35.67113544982397 139.74130279407873 29.966</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-19eed9fa-58f4-4554-8e26-d21f4b8a0175">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-19eed9fa-58f4-4554-8e26-d21f4b8a0175">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-19eed9fa-58f4-4554-8e26-d21f4b8a0175">
											<gml:posList>35.671138248042524 139.7412961851411 21.816 35.6711329793935 139.7412901267358 21.816 35.6711329793935 139.7412901267358 22.412 35.671138248042524 139.7412961851411 22.412 35.671138248042524 139.7412961851411 21.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-de939b13-efcb-4027-ada9-c4f3da6bfd1a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de939b13-efcb-4027-ada9-c4f3da6bfd1a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de939b13-efcb-4027-ada9-c4f3da6bfd1a">
											<gml:posList>35.67113848728779 139.74130258071122 30.346 35.671135290920205 139.74130716862112 30.346 35.671135290920205 139.74130716862112 26.812 35.67113811813046 139.74130311136042 26.812 35.67113811813046 139.74130311136042 27.299 35.67113848728779 139.74130258071122 27.299 35.67113848728779 139.74130258071122 30.346</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3bf14e1c-8e50-4a75-b892-58c1bdc5c9a6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3bf14e1c-8e50-4a75-b892-58c1bdc5c9a6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3bf14e1c-8e50-4a75-b892-58c1bdc5c9a6">
											<gml:posList>35.671150528695804 139.7413367443446 8.307 35.671150528695804 139.7413367443446 27.299 35.671138282219886 139.74135270934633 25.346 35.671138282219886 139.74135270934633 8.307 35.671150528695804 139.7413367443446 8.307</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ad698738-00f2-471e-8745-902fa784d604">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad698738-00f2-471e-8745-902fa784d604">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad698738-00f2-471e-8745-902fa784d604">
											<gml:posList>35.67116201080235 139.74106398531617 21.475 35.67112772129716 139.7411093811425 21.475 35.67112772129716 139.7411093811425 21.261 35.67116201080235 139.74106398531617 21.261 35.67116201080235 139.74106398531617 21.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dd6e6df6-01f7-4c0f-b329-43793e5d08bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd6e6df6-01f7-4c0f-b329-43793e5d08bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd6e6df6-01f7-4c0f-b329-43793e5d08bc">
											<gml:posList>35.67112742064148 139.741281892531 19.66 35.67116455624132 139.7412334778509 19.66 35.67116455624132 139.7412334778509 18.675 35.67112742064148 139.741281892531 18.675 35.67112742064148 139.741281892531 19.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0b158369-a21b-48c2-b4f5-996d8979b794">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b158369-a21b-48c2-b4f5-996d8979b794">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b158369-a21b-48c2-b4f5-996d8979b794">
											<gml:posList>35.67113811813046 139.74130311136042 27.299 35.67113811813046 139.74130311136042 26.812 35.671156910157265 139.74132460811177 26.812 35.671156910157265 139.74132460811177 27.299 35.67113811813046 139.74130311136042 27.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d0feca2b-c277-41bf-a848-9a3fa0943dbe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d0feca2b-c277-41bf-a848-9a3fa0943dbe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d0feca2b-c277-41bf-a848-9a3fa0943dbe">
											<gml:posList>35.671169058059405 139.74123866447258 20.544 35.671169058059405 139.74123866447258 17.198 35.67112982468375 139.7412902518675 17.198 35.67112982468375 139.7412902518675 22.412 35.671169058059405 139.74123866447258 22.412 35.671169058059405 139.74123866447258 20.544</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5f7d712c-09e7-47dc-832d-427e032ccc7f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f7d712c-09e7-47dc-832d-427e032ccc7f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f7d712c-09e7-47dc-832d-427e032ccc7f">
											<gml:posList>35.6711329793935 139.7412901267358 21.816 35.67116915117045 139.7412425526872 21.816 35.67116915117045 139.7412425526872 22.412 35.6711329793935 139.7412901267358 22.412 35.6711329793935 139.7412901267358 21.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-06600a3c-9acd-413d-bb18-0ee7885ffb24">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-06600a3c-9acd-413d-bb18-0ee7885ffb24">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-06600a3c-9acd-413d-bb18-0ee7885ffb24">
											<gml:posList>35.671156910157265 139.74132460811177 27.299 35.671156910157265 139.74132460811177 26.812 35.67114969766951 139.74133443660776 26.812 35.67114969766951 139.74133443660776 27.299 35.671156910157265 139.74132460811177 27.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-feae90e6-7c4b-4a64-a542-a2cc4663a482">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-feae90e6-7c4b-4a64-a542-a2cc4663a482">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-feae90e6-7c4b-4a64-a542-a2cc4663a482">
											<gml:posList>35.671150528695804 139.7413367443446 27.299 35.671150528695804 139.7413367443446 8.307 35.671159533049 139.74132447254533 8.307 35.671159533049 139.74132447254533 18.022 35.671159533049 139.74132447254533 27.299 35.671150528695804 139.7413367443446 27.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7f86b5f8-170e-459f-8b72-39afde0a34a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f86b5f8-170e-459f-8b72-39afde0a34a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f86b5f8-170e-459f-8b72-39afde0a34a9">
											<gml:posList>35.671159533049 139.74132447254533 8.307 35.67116350263157 139.7413291074642 8.307 35.67116350263157 139.7413291074642 17.198 35.671159533049 139.74132447254533 18.022 35.671159533049 139.74132447254533 8.307</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3fa0b790-8263-4058-a0cd-901834b86368">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3fa0b790-8263-4058-a0cd-901834b86368">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3fa0b790-8263-4058-a0cd-901834b86368">
											<gml:posList>35.671205486929374 139.74120905148672 20.544 35.67112806267263 139.74111965386697 20.544 35.67112806267263 139.74111965386697 20.048 35.671205486929374 139.74120905148672 20.048 35.671205486929374 139.74120905148672 20.544</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2b7df7a0-3d93-46c9-91a3-c2b423e9838f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b7df7a0-3d93-46c9-91a3-c2b423e9838f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b7df7a0-3d93-46c9-91a3-c2b423e9838f">
											<gml:posList>35.67120994860328 139.74120889171084 20.544 35.67112385453745 139.74110955128577 21.475 35.67112791426552 139.74111418608823 20.544 35.67120994860328 139.74120889171084 20.544</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-34531c06-5190-43bd-9ea6-9ae69fca8939">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-34531c06-5190-43bd-9ea6-9ae69fca8939">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-34531c06-5190-43bd-9ea6-9ae69fca8939">
											<gml:posList>35.67120994860328 139.74120889171084 20.544 35.67121261903121 139.7412119816272 20.625 35.67112385453745 139.74110955128577 21.475 35.67120994860328 139.74120889171084 20.544</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-acbe1f8e-011a-4404-bb71-c30e435e989e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-acbe1f8e-011a-4404-bb71-c30e435e989e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-acbe1f8e-011a-4404-bb71-c30e435e989e">
											<gml:posList>35.67121261903121 139.7412119816272 20.625 35.67121261903121 139.7412119816272 21.475 35.67112385453745 139.74110955128577 21.475 35.67121261903121 139.7412119816272 20.625</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8c89681e-5bb1-458b-b147-288c2431bd77">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c89681e-5bb1-458b-b147-288c2431bd77">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c89681e-5bb1-458b-b147-288c2431bd77">
											<gml:posList>35.67117446494114 139.74124867731848 22.412 35.67116915117045 139.7412425526872 22.412 35.67116915117045 139.7412425526872 21.816 35.67117446494114 139.74124867731848 21.816 35.67117446494114 139.74124867731848 22.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-946752f8-6b01-4639-a771-8c038f582fb8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-946752f8-6b01-4639-a771-8c038f582fb8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-946752f8-6b01-4639-a771-8c038f582fb8">
											<gml:posList>35.671171210176006 139.74123583413018 20.544 35.671178499683975 139.74124422099752 20.544 35.671178499683975 139.74124422099752 20.048 35.671171210176006 139.74123583413018 20.048 35.671171210176006 139.74123583413018 20.544</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6aa4ba8f-1b76-423f-9de6-9352fe0c7d15">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6aa4ba8f-1b76-423f-9de6-9352fe0c7d15">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6aa4ba8f-1b76-423f-9de6-9352fe0c7d15">
											<gml:posList>35.67116350263157 139.7413291074642 17.198 35.67116350263157 139.7413291074642 8.307 35.67120294347437 139.74127769657034 8.307 35.67120294347437 139.74127769657034 16.239 35.67120294347437 139.74127769657034 17.198 35.67116350263157 139.7413291074642 17.198</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-95f9b1d1-800f-4685-a470-e975034897b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-95f9b1d1-800f-4685-a470-e975034897b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-95f9b1d1-800f-4685-a470-e975034897b3">
											<gml:posList>35.67120294347437 139.74127769657034 17.198 35.67120294347437 139.74127769657034 16.239 35.671178648093644 139.74124969982634 20.359 35.671178648093644 139.74124969982634 20.544 35.671169058059405 139.74123866447258 20.544 35.671169058059405 139.74123866447258 22.412 35.67117762864764 139.74124853008203 22.412 35.67120294347437 139.74127769657034 17.198</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ffa4276b-1e2d-4fb0-a4ad-02d403131f06">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ffa4276b-1e2d-4fb0-a4ad-02d403131f06">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ffa4276b-1e2d-4fb0-a4ad-02d403131f06">
											<gml:posList>35.671178499683975 139.74124422099752 20.544 35.671205486929374 139.74120905148672 20.544 35.671205486929374 139.74120905148672 20.048 35.671178499683975 139.74124422099752 20.048 35.671178499683975 139.74124422099752 20.544</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f49c863f-f273-418b-aad2-dd2fb06a5b26">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f49c863f-f273-418b-aad2-dd2fb06a5b26">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f49c863f-f273-418b-aad2-dd2fb06a5b26">
											<gml:posList>35.67120994860328 139.74120889171084 20.544 35.671178648093644 139.74124969982634 20.544 35.671178648093644 139.74124969982634 20.359 35.67120994860328 139.74120889171084 20.359 35.67120994860328 139.74120889171084 20.544</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5b3cea46-9443-4a6d-ab02-663162a6b4c3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b3cea46-9443-4a6d-ab02-663162a6b4c3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b3cea46-9443-4a6d-ab02-663162a6b4c3">
											<gml:posList>35.67120994860328 139.74120889171084 20.544 35.67120994860328 139.74120889171084 20.359 35.67121261903121 139.7412119816272 20.625 35.67120994860328 139.74120889171084 20.544</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-63f167ee-0c73-4d6a-8e73-d4c0c2fc264f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-63f167ee-0c73-4d6a-8e73-d4c0c2fc264f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-63f167ee-0c73-4d6a-8e73-d4c0c2fc264f">
											<gml:posList>35.67121791383433 139.74120509365187 23.621 35.67120584308692 139.74119153152947 23.621 35.67120584308692 139.74119153152947 21.261 35.67121584791721 139.7412027762871 21.261 35.67121584791721 139.7412027762871 21.475 35.67121791383433 139.74120509365187 21.475 35.67121791383433 139.74120509365187 23.621</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-583b78ad-8058-4bd8-b227-63342afc1f4e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-583b78ad-8058-4bd8-b227-63342afc1f4e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-583b78ad-8058-4bd8-b227-63342afc1f4e">
											<gml:posList>35.67121783077538 139.74120256412746 23.277 35.671207907144655 139.7411914186936 23.277 35.671207907144655 139.7411914186936 23.621 35.67121783077538 139.74120256412746 23.621 35.67121783077538 139.74120256412746 23.277</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8b46d2f7-4cc2-437a-96db-752d36959402">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b46d2f7-4cc2-437a-96db-752d36959402">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b46d2f7-4cc2-437a-96db-752d36959402">
											<gml:posList>35.67121584791721 139.7412027762871 21.261 35.67121248918817 139.74120720974275 21.261 35.67121248918817 139.74120720974275 21.475 35.67121584791721 139.7412027762871 21.475 35.67121584791721 139.7412027762871 21.261</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b9605fea-b8a8-46e4-bae3-93629ba6a9ed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b9605fea-b8a8-46e4-bae3-93629ba6a9ed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b9605fea-b8a8-46e4-bae3-93629ba6a9ed">
											<gml:posList>35.67127363021508 139.74118482579493 8.307 35.67116185393767 139.74105924660515 8.307 35.67116185393767 139.74105924660515 21.475 35.67125159073796 139.74116008514287 21.475 35.67125159073796 139.74116008514287 20.625 35.67127363021508 139.74118482579493 16.243 35.67127363021508 139.74118482579493 8.307</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7f5c6b9e-e63a-4887-9eb2-f600c7e963e1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f5c6b9e-e63a-4887-9eb2-f600c7e963e1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f5c6b9e-e63a-4887-9eb2-f600c7e963e1">
											<gml:posList>35.67123026334255 139.74115889456047 23.621 35.67123026334255 139.74115889456047 21.261 35.67120584308692 139.74119153152947 21.261 35.67120584308692 139.74119153152947 23.621 35.67123026334255 139.74115889456047 23.621</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-75245b11-5c48-4188-bad5-f692587bb8ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-75245b11-5c48-4188-bad5-f692587bb8ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-75245b11-5c48-4188-bad5-f692587bb8ac">
											<gml:posList>35.67120294347437 139.74127769657034 16.239 35.67120294347437 139.74127769657034 8.307 35.67123391925437 139.74123656848147 8.307 35.67123391925437 139.74123656848147 16.239 35.67120294347437 139.74127769657034 16.239</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-558fe88e-772c-4a16-a554-5fceedc1fd8d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-558fe88e-772c-4a16-a554-5fceedc1fd8d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-558fe88e-772c-4a16-a554-5fceedc1fd8d">
											<gml:posList>35.67120994860328 139.74120889171084 20.359 35.67123391925437 139.74123656848147 16.239 35.67121261903121 139.7412119816272 20.625 35.67120994860328 139.74120889171084 20.359</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ea59d71b-1b23-419e-9758-71cfca2b28b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea59d71b-1b23-419e-9758-71cfca2b28b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea59d71b-1b23-419e-9758-71cfca2b28b6">
											<gml:posList>35.67124233409359 139.74117245668208 21.475 35.67124233409359 139.74117245668208 23.621 35.67121791383433 139.74120509365187 21.475 35.67124233409359 139.74117245668208 21.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-187671ac-f1ff-43b3-a4d7-9ec2c27944d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-187671ac-f1ff-43b3-a4d7-9ec2c27944d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-187671ac-f1ff-43b3-a4d7-9ec2c27944d3">
											<gml:posList>35.67124233409359 139.74117245668208 23.621 35.67121791383433 139.74120509365187 23.621 35.67121791383433 139.74120509365187 21.475 35.67124233409359 139.74117245668208 23.621</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4b10848b-6cf6-4bd3-bf3e-e890258742b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b10848b-6cf6-4bd3-bf3e-e890258742b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b10848b-6cf6-4bd3-bf3e-e890258742b3">
											<gml:posList>35.67121791383433 139.74120509365187 21.475 35.67121261903121 139.7412119816272 21.475 35.67121261903121 139.7412119816272 20.625 35.67125159073796 139.74116008514287 20.625 35.67125159073796 139.74116008514287 21.475 35.67124233409359 139.74117245668208 21.475 35.67121791383433 139.74120509365187 21.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2b1ae345-4b5d-4a72-835e-e390d109fc33">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b1ae345-4b5d-4a72-835e-e390d109fc33">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b1ae345-4b5d-4a72-835e-e390d109fc33">
											<gml:posList>35.671240261030626 139.7411725805752 23.621 35.67123035542459 139.74116143512126 23.621 35.67123035542459 139.74116143512126 23.277 35.671240261030626 139.7411725805752 23.277 35.671240261030626 139.7411725805752 23.621</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-17eb0a51-81ed-4d9d-be80-4183965c8f13">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17eb0a51-81ed-4d9d-be80-4183965c8f13">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17eb0a51-81ed-4d9d-be80-4183965c8f13">
											<gml:posList>35.67124233409359 139.74117245668208 23.621 35.67124233409359 139.74117245668208 21.475 35.67124030426454 139.74117018346146 21.475 35.67124030426454 139.74117018346146 21.261 35.67123026334255 139.74115889456047 21.261 35.67123026334255 139.74115889456047 23.621 35.67124233409359 139.74117245668208 23.621</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ee38426e-f166-440e-9311-1ffc84f040ad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee38426e-f166-440e-9311-1ffc84f040ad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee38426e-f166-440e-9311-1ffc84f040ad">
											<gml:posList>35.67124770596771 139.7411602773974 21.261 35.67124030426454 139.74117018346146 21.261 35.67124030426454 139.74117018346146 21.475 35.67124770596771 139.7411602773974 21.475 35.67124770596771 139.7411602773974 21.261</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-64ee7b6f-c2b4-48c9-9155-f9ab8081fb67">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-64ee7b6f-c2b4-48c9-9155-f9ab8081fb67">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-64ee7b6f-c2b4-48c9-9155-f9ab8081fb67">
											<gml:posList>35.67123391925437 139.74123656848147 8.307 35.67127363021508 139.74118482579493 8.307 35.67127363021508 139.74118482579493 16.243 35.67123391925437 139.74123656848147 16.239 35.67123391925437 139.74123656848147 8.307</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8308</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">102.68274</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1242</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>