<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_8913c429-092d-466f-8d3f-f938accf2ae9">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">16.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.673213242807435 139.73864377803804 0 35.67319932553485 139.73859784042168 0 35.67307658167207 139.73866158092036 0 35.67309248185174 139.73870740567077 0 35.673213242807435 139.73864377803804 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673213242807435 139.73864377803804 7.97 35.67309248185174 139.73870740567077 7.97 35.67307658167207 139.73866158092036 7.97 35.67319932553485 139.73859784042168 7.97 35.673213242807435 139.73864377803804 7.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673213242807435 139.73864377803804 7.97 35.67319932553485 139.73859784042168 7.97 35.67319932553485 139.73859784042168 24.11 35.673213242807435 139.73864377803804 24.11 35.673213242807435 139.73864377803804 7.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67319932553485 139.73859784042168 7.97 35.67307658167207 139.73866158092036 7.97 35.67307658167207 139.73866158092036 24.11 35.67319932553485 139.73859784042168 24.11 35.67319932553485 139.73859784042168 7.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67307658167207 139.73866158092036 7.97 35.67309248185174 139.73870740567077 7.97 35.67309248185174 139.73870740567077 24.11 35.67307658167207 139.73866158092036 24.11 35.67307658167207 139.73866158092036 7.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67309248185174 139.73870740567077 7.97 35.673213242807435 139.73864377803804 7.97 35.673213242807435 139.73864377803804 24.11 35.67309248185174 139.73870740567077 24.11 35.67309248185174 139.73870740567077 7.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673213242807435 139.73864377803804 24.11 35.67319932553485 139.73859784042168 24.11 35.67307658167207 139.73866158092036 24.11 35.67309248185174 139.73870740567077 24.11 35.673213242807435 139.73864377803804 24.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-fda48746-7aef-4959-886a-844430f4a0e0"/>
							<gml:surfaceMember xlink:href="#poly-82de88f8-1c2e-4d98-bb29-134960473787"/>
							<gml:surfaceMember xlink:href="#poly-35016694-5cdd-4e56-8fec-e97f021b8c99"/>
							<gml:surfaceMember xlink:href="#poly-934e7549-61c8-43ae-b63f-f43e0c09055f"/>
							<gml:surfaceMember xlink:href="#poly-b635badc-bc68-415e-92ce-3cea8808a4dd"/>
							<gml:surfaceMember xlink:href="#poly-6662c527-4c63-46c6-9751-663606502b6a"/>
							<gml:surfaceMember xlink:href="#poly-78196e35-d513-4303-994c-b499aea2aa81"/>
							<gml:surfaceMember xlink:href="#poly-b8f85343-4b24-4ec6-8b9d-b38ecf074594"/>
							<gml:surfaceMember xlink:href="#poly-1f58bccb-6764-45ac-a0e8-24ab4496cbfc"/>
							<gml:surfaceMember xlink:href="#poly-5f72fa64-5af5-49ad-b158-a9302c2369e7"/>
							<gml:surfaceMember xlink:href="#poly-6fa23c34-7cf3-4145-ad98-9064b4e37db7"/>
							<gml:surfaceMember xlink:href="#poly-1c4d2fd7-872c-4b3c-aea7-5bdaa2daa903"/>
							<gml:surfaceMember xlink:href="#poly-4fb78dd3-832e-466d-a460-84ca7d7a8e72"/>
							<gml:surfaceMember xlink:href="#poly-0c7f277c-78d6-438a-b711-8dc82cac589a"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_8913c429-092d-466f-8d3f-f938accf2ae9_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0993a7d5-4a4a-42c0-b868-b5f425646452">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0993a7d5-4a4a-42c0-b868-b5f425646452_0">
											<gml:posList>35.67311645738038 139.73869468478676 25.598 35.67311645738038 139.73869468478676 26.179 35.67311519262934 139.7386910850764 25.598 35.67311645738038 139.73869468478676 25.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d2440c31-0ad8-4e72-af5c-3fa5847fc8ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d2440c31-0ad8-4e72-af5c-3fa5847fc8ea_0">
											<gml:posList>35.67311519262934 139.7386910850764 24.867 35.67311519262934 139.7386910850764 25.598 35.673110088538124 139.73867666419608 24.867 35.67311519262934 139.7386910850764 24.867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-733dfacb-fc26-48cb-ba8b-151e2c510039">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-733dfacb-fc26-48cb-ba8b-151e2c510039_0">
											<gml:posList>35.673110088538124 139.73867666419608 24.867 35.67311519262934 139.7386910850764 25.598 35.673110088538124 139.73867666419608 26.179 35.673110088538124 139.73867666419608 24.867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9c9d9f1f-ab25-4440-9311-418c0d43eb36">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9c9d9f1f-ab25-4440-9311-418c0d43eb36_0">
											<gml:posList>35.67311519262934 139.7386910850764 25.598 35.67311645738038 139.73869468478676 26.179 35.673110088538124 139.73867666419608 26.179 35.67311519262934 139.7386910850764 25.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4bf5dd32-818b-41d2-adfa-a71c33ec05b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4bf5dd32-818b-41d2-adfa-a71c33ec05b3_0">
											<gml:posList>35.67312398191638 139.73866930177826 24.867 35.673110088538124 139.73867666419608 26.179 35.67312398191638 139.73866930177826 26.179 35.67312398191638 139.73866930177826 24.867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-acad9e35-2305-4c84-8a77-523991aa2430">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-acad9e35-2305-4c84-8a77-523991aa2430_0">
											<gml:posList>35.67312398191638 139.73866930177826 24.867 35.673110088538124 139.73867666419608 24.867 35.673110088538124 139.73867666419608 26.179 35.67312398191638 139.73866930177826 24.867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-02d7d90f-72fd-4050-bbc1-c3054e1d1861">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-02d7d90f-72fd-4050-bbc1-c3054e1d1861_0">
											<gml:posList>35.673116742845444 139.7386450408662 25.598 35.673116742845444 139.7386450408662 24.867 35.67312350935562 139.738664408676 25.472 35.673116742845444 139.7386450408662 25.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd163df7-5264-4b62-91c3-d7fdf85c51b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cd163df7-5264-4b62-91c3-d7fdf85c51b8_0">
											<gml:posList>35.673115604545586 139.73864177240634 25.598 35.673116742845444 139.7386450408662 25.598 35.673115604545586 139.73864177240634 27.142 35.673115604545586 139.73864177240634 25.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa6cdf33-5ec7-44f8-bc51-610ad5e0701d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fa6cdf33-5ec7-44f8-bc51-610ad5e0701d_0">
											<gml:posList>35.673116742845444 139.7386450408662 24.867 35.67312350935562 139.738664408676 24.867 35.67312350935562 139.738664408676 25.472 35.673116742845444 139.7386450408662 24.867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d88764c5-744d-4e88-a3b0-144b113bebf9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d88764c5-744d-4e88-a3b0-144b113bebf9_0">
											<gml:posList>35.673115604545586 139.73864177240634 27.142 35.673116742845444 139.7386450408662 25.598 35.67312350935562 139.738664408676 27.142 35.673115604545586 139.73864177240634 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-30fec962-df71-47fd-af66-bc02ffa63e0b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-30fec962-df71-47fd-af66-bc02ffa63e0b_0">
											<gml:posList>35.673116742845444 139.7386450408662 25.598 35.67312350935562 139.738664408676 25.472 35.67312350935562 139.738664408676 27.142 35.673116742845444 139.7386450408662 25.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f0fc708-a13c-4e80-827a-d4c375fbd881">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1f0fc708-a13c-4e80-827a-d4c375fbd881_0">
											<gml:posList>35.67312398191638 139.73866930177826 26.179 35.673110088538124 139.73867666419608 26.179 35.67311645738038 139.73869468478676 26.179 35.67312398191638 139.73866930177826 26.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da89e8cd-f00b-468a-bc18-9bee1bfac4ad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da89e8cd-f00b-468a-bc18-9bee1bfac4ad_0">
											<gml:posList>35.673130350751045 139.73868731132484 26.179 35.67312398191638 139.73866930177826 26.179 35.67311645738038 139.73869468478676 26.179 35.673130350751045 139.73868731132484 26.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d86c956-adb5-4487-9845-f6be494f330c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4d86c956-adb5-4487-9845-f6be494f330c_0">
											<gml:posList>35.67312909505692 139.73868376683646 25.598 35.67311519262934 139.7386910850764 24.867 35.67312909505692 139.73868376683646 24.867 35.67312909505692 139.73868376683646 25.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-329a338d-66c9-4131-a05a-3127527ccb2b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-329a338d-66c9-4131-a05a-3127527ccb2b_0">
											<gml:posList>35.67312909505692 139.73868376683646 25.598 35.67311519262934 139.7386910850764 25.598 35.67311519262934 139.7386910850764 24.867 35.67312909505692 139.73868376683646 25.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ab7a8e5-7747-47bb-b440-c9b180aacd6f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6ab7a8e5-7747-47bb-b440-c9b180aacd6f_0">
											<gml:posList>35.67311645738038 139.73869468478676 25.598 35.673130350751045 139.73868731132484 26.179 35.67311645738038 139.73869468478676 26.179 35.67311645738038 139.73869468478676 25.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7411053-03aa-438c-9a2a-9a941e6fefaf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c7411053-03aa-438c-9a2a-9a941e6fefaf_0">
											<gml:posList>35.67311645738038 139.73869468478676 25.598 35.673130350751045 139.73868731132484 25.598 35.673130350751045 139.73868731132484 26.179 35.67311645738038 139.73869468478676 25.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-180a97a6-7d73-44c7-8e19-fe5730072431">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-180a97a6-7d73-44c7-8e19-fe5730072431_0">
											<gml:posList>35.67312387557179 139.73864868887867 27.142 35.6731238023241 139.7386472418557 29.038 35.6731238023241 139.7386472418557 27.142 35.67312387557179 139.73864868887867 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc1eacab-1427-4804-8397-0f723b05be7e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cc1eacab-1427-4804-8397-0f723b05be7e_0">
											<gml:posList>35.67312387557179 139.73864868887867 27.142 35.67312387557179 139.73864868887867 29.038 35.6731238023241 139.7386472418557 29.038 35.67312387557179 139.73864868887867 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-28855375-b181-472a-a7f8-b6b3b4d6eb00">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-28855375-b181-472a-a7f8-b6b3b4d6eb00_0">
											<gml:posList>35.6731238023241 139.7386472418557 29.038 35.673123981469175 139.73864580558123 27.142 35.6731238023241 139.7386472418557 27.142 35.6731238023241 139.7386472418557 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d5c67b3-82c7-43a5-8969-2a15a721748b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4d5c67b3-82c7-43a5-8969-2a15a721748b_0">
											<gml:posList>35.6731238023241 139.7386472418557 29.038 35.673123981469175 139.73864580558123 29.038 35.673123981469175 139.73864580558123 27.142 35.6731238023241 139.7386472418557 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9491c584-4170-4cdf-aa6b-ae6cfd5f4466">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9491c584-4170-4cdf-aa6b-ae6cfd5f4466_0">
											<gml:posList>35.673124192155115 139.7386500914277 27.142 35.67312387557179 139.73864868887867 29.038 35.67312387557179 139.73864868887867 27.142 35.673124192155115 139.7386500914277 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fbc036c2-89a1-48ed-ad46-d0e5646a5345">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fbc036c2-89a1-48ed-ad46-d0e5646a5345_0">
											<gml:posList>35.673124192155115 139.7386500914277 27.142 35.673124192155115 139.7386500914277 29.038 35.67312387557179 139.73864868887867 29.038 35.673124192155115 139.7386500914277 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25a84fbe-9c88-44e4-b7b0-bb0ac7052f60">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-25a84fbe-9c88-44e4-b7b0-bb0ac7052f60_0">
											<gml:posList>35.673123981469175 139.73864580558123 27.142 35.67312439503172 139.7386444463564 29.038 35.67312439503172 139.7386444463564 27.142 35.673123981469175 139.73864580558123 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1fcfae2e-9ec8-42b4-9b46-d727066eb9b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1fcfae2e-9ec8-42b4-9b46-d727066eb9b8_0">
											<gml:posList>35.673123981469175 139.73864580558123 27.142 35.673123981469175 139.73864580558123 29.038 35.67312439503172 139.7386444463564 29.038 35.673123981469175 139.73864580558123 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c407ae2-8539-4c99-8798-ed76324a87a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8c407ae2-8539-4c99-8798-ed76324a87a6_0">
											<gml:posList>35.67312474299955 139.73865137218706 27.142 35.673124192155115 139.7386500914277 29.038 35.673124192155115 139.7386500914277 27.142 35.67312474299955 139.73865137218706 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac11cc59-2b74-4683-90e0-da7312ea5818">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ac11cc59-2b74-4683-90e0-da7312ea5818_0">
											<gml:posList>35.67312474299955 139.73865137218706 27.142 35.67312474299955 139.73865137218706 29.038 35.673124192155115 139.7386500914277 29.038 35.67312474299955 139.73865137218706 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f2346bb-6cec-4b43-bc8c-db47f4ec2d14">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f2346bb-6cec-4b43-bc8c-db47f4ec2d14_0">
											<gml:posList>35.67312439503172 139.7386444463564 29.038 35.67312503404143 139.73864321942492 27.142 35.67312439503172 139.7386444463564 27.142 35.67312439503172 139.7386444463564 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3bed1ab2-9ecf-4f2d-8067-170731209dd1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3bed1ab2-9ecf-4f2d-8067-170731209dd1_0">
											<gml:posList>35.67312439503172 139.7386444463564 29.038 35.67312503404143 139.73864321942492 29.038 35.67312503404143 139.73864321942492 27.142 35.67312439503172 139.7386444463564 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-349d8a17-b99f-492d-8f7f-16548576eef7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-349d8a17-b99f-492d-8f7f-16548576eef7_0">
											<gml:posList>35.67312549202415 139.73865249805948 29.038 35.67312474299955 139.73865137218706 27.142 35.67312549202415 139.73865249805948 27.142 35.67312549202415 139.73865249805948 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d47b08c0-4dd3-470b-a315-f9a7d9f18b4b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d47b08c0-4dd3-470b-a315-f9a7d9f18b4b_0">
											<gml:posList>35.67312549202415 139.73865249805948 29.038 35.67312474299955 139.73865137218706 29.038 35.67312474299955 139.73865137218706 27.142 35.67312549202415 139.73865249805948 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7db9090f-cbc0-4a4d-8cf9-31f48f28e761">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7db9090f-cbc0-4a4d-8cf9-31f48f28e761_0">
											<gml:posList>35.673115604545586 139.73864177240634 25.598 35.67313475985662 139.7386317636197 27.142 35.67313475985662 139.7386317636197 25.598 35.673115604545586 139.73864177240634 25.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73dfa2c1-48d0-4497-9fe8-1c0d3c3aab4a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73dfa2c1-48d0-4497-9fe8-1c0d3c3aab4a_0">
											<gml:posList>35.673115604545586 139.73864177240634 25.598 35.673115604545586 139.73864177240634 27.142 35.67313475985662 139.7386317636197 27.142 35.673115604545586 139.73864177240634 25.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-69aec582-47bf-47bf-b883-6feb86ad4ef1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-69aec582-47bf-47bf-b883-6feb86ad4ef1_0">
											<gml:posList>35.67312503404143 139.73864321942492 29.038 35.67312586248692 139.73864218006247 27.142 35.67312503404143 139.73864321942492 27.142 35.67312503404143 139.73864321942492 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1f58407-fddb-433c-9bae-b48090e96f52">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c1f58407-fddb-433c-9bae-b48090e96f52_0">
											<gml:posList>35.67312503404143 139.73864321942492 29.038 35.67312586248692 139.73864218006247 29.038 35.67312586248692 139.73864218006247 27.142 35.67312503404143 139.73864321942492 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c4dc819e-6f70-40e9-8044-4e15d4abed1b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c4dc819e-6f70-40e9-8044-4e15d4abed1b_0">
											<gml:posList>35.673126421149384 139.73865340278647 27.142 35.67312549202415 139.73865249805948 29.038 35.67312549202415 139.73865249805948 27.142 35.673126421149384 139.73865340278647 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16afb56b-4bf5-44ad-b0a4-6475f689e0fb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16afb56b-4bf5-44ad-b0a4-6475f689e0fb_0">
											<gml:posList>35.673126421149384 139.73865340278647 27.142 35.673126421149384 139.73865340278647 29.038 35.67312549202415 139.73865249805948 29.038 35.673126421149384 139.73865340278647 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11d91347-9ea1-4186-af38-5257b6bf97af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-11d91347-9ea1-4186-af38-5257b6bf97af_0">
											<gml:posList>35.67313592524135 139.7386350872814 24.867 35.673116742845444 139.7386450408662 25.598 35.67313592524135 139.7386350872814 25.598 35.67313592524135 139.7386350872814 24.867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c295fc1a-a178-4f0c-9e9d-a2fc5c2635fa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c295fc1a-a178-4f0c-9e9d-a2fc5c2635fa_0">
											<gml:posList>35.67313592524135 139.7386350872814 24.867 35.673116742845444 139.7386450408662 24.867 35.673116742845444 139.7386450408662 25.598 35.67313592524135 139.7386350872814 24.867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a893e14-865b-459f-bdbb-e01bc7280747">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a893e14-865b-459f-bdbb-e01bc7280747_0">
											<gml:posList>35.67312586248692 139.73864218006247 29.038 35.673126853370434 139.7386413835342 27.142 35.67312586248692 139.73864218006247 27.142 35.67312586248692 139.73864218006247 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-10852069-4073-4227-ac30-6cb3bc15f30d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-10852069-4073-4227-ac30-6cb3bc15f30d_0">
											<gml:posList>35.67312586248692 139.73864218006247 29.038 35.673126853370434 139.7386413835342 29.038 35.673126853370434 139.7386413835342 27.142 35.67312586248692 139.73864218006247 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9325c4d-46e9-4294-ac79-99ccb59addf9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e9325c4d-46e9-4294-ac79-99ccb59addf9_0">
											<gml:posList>35.6731301582328 139.7386832022027 25.472 35.67312350935562 139.738664408676 24.867 35.6731301582328 139.7386832022027 24.867 35.6731301582328 139.7386832022027 25.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-665fc4b5-1a95-4280-84cc-05b5f50e150b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-665fc4b5-1a95-4280-84cc-05b5f50e150b_0">
											<gml:posList>35.6731301582328 139.7386832022027 25.472 35.67312350935562 139.738664408676 25.472 35.67312350935562 139.738664408676 24.867 35.6731301582328 139.7386832022027 25.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-235a3dcc-652f-4f87-ae87-4f760b2b5d3a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-235a3dcc-652f-4f87-ae87-4f760b2b5d3a_0">
											<gml:posList>35.6731274852806 139.73865405328135 29.038 35.673126421149384 139.73865340278647 27.142 35.6731274852806 139.73865405328135 27.142 35.6731274852806 139.73865405328135 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b709e82a-2bd0-4628-acfe-71c64718865b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b709e82a-2bd0-4628-acfe-71c64718865b_0">
											<gml:posList>35.6731274852806 139.73865405328135 29.038 35.673126421149384 139.73865340278647 29.038 35.673126421149384 139.73865340278647 27.142 35.6731274852806 139.73865405328135 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1bc854d8-cbc9-4c9c-843d-aeb89dc6ce44">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1bc854d8-cbc9-4c9c-843d-aeb89dc6ce44_0">
											<gml:posList>35.67312909505692 139.73868376683646 24.867 35.67312398191638 139.73866930177826 24.867 35.67312909505692 139.73868376683646 25.598 35.67312909505692 139.73868376683646 24.867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d13aa01-1f50-48b5-99e6-ba9a640136ae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6d13aa01-1f50-48b5-99e6-ba9a640136ae_0">
											<gml:posList>35.673130350751045 139.73868731132484 25.598 35.67312909505692 139.73868376683646 25.598 35.673130350751045 139.73868731132484 26.179 35.673130350751045 139.73868731132484 25.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c4dc6aca-2b97-4f7e-b800-398500419f83">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c4dc6aca-2b97-4f7e-b800-398500419f83_0">
											<gml:posList>35.673130350751045 139.73868731132484 26.179 35.67312909505692 139.73868376683646 25.598 35.67312398191638 139.73866930177826 26.179 35.673130350751045 139.73868731132484 26.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-90f3e10c-d62c-4de7-8cef-e469e423ef96">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-90f3e10c-d62c-4de7-8cef-e469e423ef96_0">
											<gml:posList>35.67312909505692 139.73868376683646 25.598 35.67312398191638 139.73866930177826 24.867 35.67312398191638 139.73866930177826 26.179 35.67312909505692 139.73868376683646 25.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da2dc298-a8b5-4985-8731-dad52bbc5dc9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da2dc298-a8b5-4985-8731-dad52bbc5dc9_0">
											<gml:posList>35.673126853370434 139.7386413835342 27.142 35.673127952618366 139.73864084095058 29.038 35.673127952618366 139.73864084095058 27.142 35.673126853370434 139.7386413835342 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b6aed48e-5852-49e5-83d1-baf5f202b8e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b6aed48e-5852-49e5-83d1-baf5f202b8e4_0">
											<gml:posList>35.673126853370434 139.7386413835342 27.142 35.673126853370434 139.7386413835342 29.038 35.673127952618366 139.73864084095058 29.038 35.673126853370434 139.7386413835342 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bac118e8-edbd-44b2-b4d8-81c7e93e9dc4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bac118e8-edbd-44b2-b4d8-81c7e93e9dc4_0">
											<gml:posList>35.67312863030944 139.7386544164681 27.142 35.6731274852806 139.73865405328135 29.038 35.6731274852806 139.73865405328135 27.142 35.67312863030944 139.7386544164681 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16479ff5-caba-423d-acf6-39ac6a03502f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16479ff5-caba-423d-acf6-39ac6a03502f_0">
											<gml:posList>35.67312863030944 139.7386544164681 27.142 35.67312863030944 139.7386544164681 29.038 35.6731274852806 139.73865405328135 29.038 35.67312863030944 139.7386544164681 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da8ffcce-de94-4594-ae15-f39b51af5ad5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da8ffcce-de94-4594-ae15-f39b51af5ad5_0">
											<gml:posList>35.673127952618366 139.73864084095058 29.038 35.67312911520557 139.73864060759794 27.142 35.673127952618366 139.73864084095058 27.142 35.673127952618366 139.73864084095058 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bdbb3ef4-a9e3-44a1-8b04-71b36597d659">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bdbb3ef4-a9e3-44a1-8b04-71b36597d659_0">
											<gml:posList>35.673127952618366 139.73864084095058 29.038 35.67312911520557 139.73864060759794 29.038 35.67312911520557 139.73864060759794 27.142 35.673127952618366 139.73864084095058 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e33e255-092b-491c-9987-4a53c7e4176d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1e33e255-092b-491c-9987-4a53c7e4176d_0">
											<gml:posList>35.67313209102129 139.73865370539622 27.142 35.67312350935562 139.738664408676 27.142 35.67314266465983 139.73865438884712 27.142 35.67313209102129 139.73865370539622 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d2d3c8c3-bb57-43e9-88bd-821a1df27728">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d2d3c8c3-bb57-43e9-88bd-821a1df27728_0">
											<gml:posList>35.67313474321445 139.738644986466 27.142 35.67314266465983 139.73865438884712 27.142 35.67313475985662 139.7386317636197 27.142 35.67313474321445 139.738644986466 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60dd7cad-4e4a-4d45-8e30-b77e02104ebd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-60dd7cad-4e4a-4d45-8e30-b77e02104ebd_0">
											<gml:posList>35.673124192155115 139.7386500914277 27.142 35.673115604545586 139.73864177240634 27.142 35.67312350935562 139.738664408676 27.142 35.673124192155115 139.7386500914277 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c6998b2-c5a7-48cb-8311-248f51b72cca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c6998b2-c5a7-48cb-8311-248f51b72cca_0">
											<gml:posList>35.673126853370434 139.7386413835342 27.142 35.67313475985662 139.7386317636197 27.142 35.673115604545586 139.73864177240634 27.142 35.673126853370434 139.7386413835342 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04a6551b-b945-4780-9cde-c68d9b57249c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-04a6551b-b945-4780-9cde-c68d9b57249c_0">
											<gml:posList>35.67313098275089 139.73865423694372 27.142 35.67312350935562 139.738664408676 27.142 35.67313209102129 139.73865370539622 27.142 35.67313098275089 139.73865423694372 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-673e215b-573c-421e-94b4-e76f17a58b85">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-673e215b-573c-421e-94b4-e76f17a58b85_0">
											<gml:posList>35.67313474321445 139.738644986466 27.142 35.67313475985662 139.7386317636197 27.142 35.67313419236996 139.7386437057065 27.142 35.67313474321445 139.738644986466 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a23a7e71-c9b8-45cd-96f9-8b65776bf4f3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a23a7e71-c9b8-45cd-96f9-8b65776bf4f3_0">
											<gml:posList>35.673135059797815 139.7386463890152 27.142 35.67314266465983 139.73865438884712 27.142 35.67313474321445 139.738644986466 27.142 35.673135059797815 139.7386463890152 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f5dba4f-3957-4685-910a-77c321da71be">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f5dba4f-3957-4685-910a-77c321da71be_0">
											<gml:posList>35.67312474299955 139.73865137218706 27.142 35.673124192155115 139.7386500914277 27.142 35.67312350935562 139.738664408676 27.142 35.67312474299955 139.73865137218706 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af3bc6eb-aab1-4a8d-8355-a44cfadcae5a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-af3bc6eb-aab1-4a8d-8355-a44cfadcae5a_0">
											<gml:posList>35.67312387557179 139.73864868887867 27.142 35.673115604545586 139.73864177240634 27.142 35.673124192155115 139.7386500914277 27.142 35.67312387557179 139.73864868887867 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ae9f7ca9-b45a-4064-beaf-c824745a3a70">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ae9f7ca9-b45a-4064-beaf-c824745a3a70_0">
											<gml:posList>35.67312586248692 139.73864218006247 27.142 35.673126853370434 139.7386413835342 27.142 35.673115604545586 139.73864177240634 27.142 35.67312586248692 139.73864218006247 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb1b2278-09e4-4cfc-ba36-1d51a05a0e6f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb1b2278-09e4-4cfc-ba36-1d51a05a0e6f_0">
											<gml:posList>35.673127952618366 139.73864084095058 27.142 35.67313475985662 139.7386317636197 27.142 35.673126853370434 139.7386413835342 27.142 35.673127952618366 139.73864084095058 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b3e28d4-c1e5-4a31-a4ab-aa506ecb54a3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1b3e28d4-c1e5-4a31-a4ab-aa506ecb54a3_0">
											<gml:posList>35.673129820163666 139.73865447029613 27.142 35.67312350935562 139.738664408676 27.142 35.67313098275089 139.73865423694372 27.142 35.673129820163666 139.73865447029613 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40d61433-d9d4-485a-94f8-101a3464707c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40d61433-d9d4-485a-94f8-101a3464707c_0">
											<gml:posList>35.67313419236996 139.7386437057065 27.142 35.67313475985662 139.7386317636197 27.142 35.673133434331554 139.7386425798447 27.142 35.67313419236996 139.7386437057065 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a8ef6b5-956d-4b79-b211-be7e4c221de6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2a8ef6b5-956d-4b79-b211-be7e4c221de6_0">
											<gml:posList>35.67313513304552 139.73864783603838 27.142 35.67314266465983 139.73865438884712 27.142 35.673135059797815 139.7386463890152 27.142 35.67313513304552 139.73864783603838 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-54339d3a-ec16-45df-a21f-9236eb9c9388">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-54339d3a-ec16-45df-a21f-9236eb9c9388_0">
											<gml:posList>35.67312474299955 139.73865137218706 27.142 35.67312350935562 139.738664408676 27.142 35.67312549202415 139.73865249805948 27.142 35.67312474299955 139.73865137218706 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e021b74-83e4-4078-bba2-cdfb65f1ceb4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e021b74-83e4-4078-bba2-cdfb65f1ceb4_0">
											<gml:posList>35.6731238023241 139.7386472418557 27.142 35.673115604545586 139.73864177240634 27.142 35.67312387557179 139.73864868887867 27.142 35.6731238023241 139.7386472418557 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd0c07da-1b3f-4e84-927c-f2ddc60dce0f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dd0c07da-1b3f-4e84-927c-f2ddc60dce0f_0">
											<gml:posList>35.67312503404143 139.73864321942492 27.142 35.67312586248692 139.73864218006247 27.142 35.673115604545586 139.73864177240634 27.142 35.67312503404143 139.73864321942492 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38f695c7-c0d4-4e8b-bded-6e95439a36fb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-38f695c7-c0d4-4e8b-bded-6e95439a36fb_0">
											<gml:posList>35.67312911520557 139.73864060759794 27.142 35.67313475985662 139.7386317636197 27.142 35.673127952618366 139.73864084095058 27.142 35.67312911520557 139.73864060759794 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a2dcfb7-6a86-4432-b778-af4f94196c38">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6a2dcfb7-6a86-4432-b778-af4f94196c38_0">
											<gml:posList>35.67312863030944 139.7386544164681 27.142 35.67312350935562 139.738664408676 27.142 35.673129820163666 139.73865447029613 27.142 35.67312863030944 139.7386544164681 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb0e1dd7-d8c0-47d5-b177-da31099a45c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb0e1dd7-d8c0-47d5-b177-da31099a45c7_0">
											<gml:posList>35.67313251421995 139.73864167510712 27.142 35.673133434331554 139.7386425798447 27.142 35.67313475985662 139.7386317636197 27.142 35.67313251421995 139.73864167510712 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-52d4cbd5-9755-49c4-a44c-5043d3c01a21">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-52d4cbd5-9755-49c4-a44c-5043d3c01a21_0">
											<gml:posList>35.67313495390042 139.73864927231298 27.142 35.67314266465983 139.73865438884712 27.142 35.67313513304552 139.73864783603838 27.142 35.67313495390042 139.73864927231298 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24118951-704a-417f-9abf-bacb76301d4f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-24118951-704a-417f-9abf-bacb76301d4f_0">
											<gml:posList>35.67312549202415 139.73865249805948 27.142 35.67312350935562 139.738664408676 27.142 35.673126421149384 139.73865340278647 27.142 35.67312549202415 139.73865249805948 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5221e58c-198d-4037-bcf1-6382ceec306a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5221e58c-198d-4037-bcf1-6382ceec306a_0">
											<gml:posList>35.673123981469175 139.73864580558123 27.142 35.673115604545586 139.73864177240634 27.142 35.6731238023241 139.7386472418557 27.142 35.673123981469175 139.73864580558123 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f187fafe-87f4-4668-b26a-d45935d65db7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f187fafe-87f4-4668-b26a-d45935d65db7_0">
											<gml:posList>35.67312439503172 139.7386444463564 27.142 35.67312503404143 139.73864321942492 27.142 35.673115604545586 139.73864177240634 27.142 35.67312439503172 139.7386444463564 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-644b8d6c-226b-4e1d-b612-1a9c539951e3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-644b8d6c-226b-4e1d-b612-1a9c539951e3_0">
											<gml:posList>35.67313030506848 139.73864067247237 27.142 35.67313475985662 139.7386317636197 27.142 35.67312911520557 139.73864060759794 27.142 35.67313030506848 139.73864067247237 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a9a0b04-eeda-4aee-9612-616dddf93408">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0a9a0b04-eeda-4aee-9612-616dddf93408_0">
											<gml:posList>35.6731274852806 139.73865405328135 27.142 35.67312350935562 139.738664408676 27.142 35.67312863030944 139.7386544164681 27.142 35.6731274852806 139.73865405328135 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b806ba5-5b55-43b9-8a02-e171233822f3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0b806ba5-5b55-43b9-8a02-e171233822f3_0">
											<gml:posList>35.67313251421995 139.73864167510712 27.142 35.67313475985662 139.7386317636197 27.142 35.67313145009736 139.738641035659 27.142 35.67313251421995 139.73864167510712 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c8cd28d-b0f1-40b8-90a1-78c8550a0c7d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6c8cd28d-b0f1-40b8-90a1-78c8550a0c7d_0">
											<gml:posList>35.67313454033782 139.738650631538 27.142 35.67314266465983 139.73865438884712 27.142 35.67313495390042 139.73864927231298 27.142 35.67313454033782 139.738650631538 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25f8274f-ed65-40d3-95ec-355558560c76">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-25f8274f-ed65-40d3-95ec-355558560c76_0">
											<gml:posList>35.673126421149384 139.73865340278647 27.142 35.67312350935562 139.738664408676 27.142 35.6731274852806 139.73865405328135 27.142 35.673126421149384 139.73865340278647 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-697b0f2a-5be2-45e2-86ab-b619ac9b73bf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-697b0f2a-5be2-45e2-86ab-b619ac9b73bf_0">
											<gml:posList>35.673123981469175 139.73864580558123 27.142 35.67312439503172 139.7386444463564 27.142 35.673115604545586 139.73864177240634 27.142 35.673123981469175 139.73864580558123 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-92817f57-78be-4aa7-8f89-51b5315403e8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-92817f57-78be-4aa7-8f89-51b5315403e8_0">
											<gml:posList>35.67313145009736 139.738641035659 27.142 35.67313475985662 139.7386317636197 27.142 35.67313030506848 139.73864067247237 27.142 35.67313145009736 139.738641035659 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dcc3e106-be94-4094-9245-b8b2d64a7b34">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dcc3e106-be94-4094-9245-b8b2d64a7b34_0">
											<gml:posList>35.67313390132802 139.73865185846958 27.142 35.67314266465983 139.73865438884712 27.142 35.67313454033782 139.738650631538 27.142 35.67313390132802 139.73865185846958 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-36146f1e-c486-4cc0-8f8f-05d0ddcc088c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-36146f1e-c486-4cc0-8f8f-05d0ddcc088c_0">
											<gml:posList>35.673133072882464 139.73865289783203 27.142 35.67314266465983 139.73865438884712 27.142 35.67313390132802 139.73865185846958 27.142 35.673133072882464 139.73865289783203 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25587952-dfe8-455c-91e0-3c4810a65fe0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-25587952-dfe8-455c-91e0-3c4810a65fe0_0">
											<gml:posList>35.67313209102129 139.73865370539622 27.142 35.67314266465983 139.73865438884712 27.142 35.673133072882464 139.73865289783203 27.142 35.67313209102129 139.73865370539622 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c744f15-e168-4811-ba2a-0da0ec6fc557">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2c744f15-e168-4811-ba2a-0da0ec6fc557_0">
											<gml:posList>35.673129820163666 139.73865447029613 27.142 35.67312863030944 139.7386544164681 29.038 35.67312863030944 139.7386544164681 27.142 35.673129820163666 139.73865447029613 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ef0ec70-21cc-4e29-aa6e-3c7867f7c2fc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2ef0ec70-21cc-4e29-aa6e-3c7867f7c2fc_0">
											<gml:posList>35.673129820163666 139.73865447029613 27.142 35.673129820163666 139.73865447029613 29.038 35.67312863030944 139.7386544164681 29.038 35.673129820163666 139.73865447029613 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43e6a935-0c40-4168-b236-b27a24a4bc88">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-43e6a935-0c40-4168-b236-b27a24a4bc88_0">
											<gml:posList>35.67313495390042 139.73864927231298 29.038 35.67313513304552 139.73864783603838 29.038 35.673135059797815 139.7386463890152 29.038 35.67313495390042 139.73864927231298 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61b77c90-fc1a-4991-a67e-01ba8fab2804">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-61b77c90-fc1a-4991-a67e-01ba8fab2804_0">
											<gml:posList>35.673135059797815 139.7386463890152 29.038 35.67313474321445 139.738644986466 29.038 35.67313419236996 139.7386437057065 29.038 35.673135059797815 139.7386463890152 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef276557-c358-42f3-8adc-a65debe6e52e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef276557-c358-42f3-8adc-a65debe6e52e_0">
											<gml:posList>35.67313390132802 139.73865185846958 29.038 35.67313454033782 139.738650631538 29.038 35.67313495390042 139.73864927231298 29.038 35.67313390132802 139.73865185846958 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af946df1-89d3-4a33-babb-a6da1d7640d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-af946df1-89d3-4a33-babb-a6da1d7640d1_0">
											<gml:posList>35.673133434331554 139.7386425798447 29.038 35.67313145009736 139.738641035659 29.038 35.67313419236996 139.7386437057065 29.038 35.673133434331554 139.7386425798447 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-958beeff-9ef1-4961-85d6-5403c2d8c0b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-958beeff-9ef1-4961-85d6-5403c2d8c0b1_0">
											<gml:posList>35.67313390132802 139.73865185846958 29.038 35.673129820163666 139.73865447029613 29.038 35.673133072882464 139.73865289783203 29.038 35.67313390132802 139.73865185846958 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5773c2d8-b451-4f1c-8c27-571db19e37a9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5773c2d8-b451-4f1c-8c27-571db19e37a9_0">
											<gml:posList>35.67313251421995 139.73864167510712 29.038 35.67313145009736 139.738641035659 29.038 35.673133434331554 139.7386425798447 29.038 35.67313251421995 139.73864167510712 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf94dca8-3a7b-4681-83f3-7a8c7ed2e61d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bf94dca8-3a7b-4681-83f3-7a8c7ed2e61d_0">
											<gml:posList>35.673133072882464 139.73865289783203 29.038 35.67313098275089 139.73865423694372 29.038 35.67313209102129 139.73865370539622 29.038 35.673133072882464 139.73865289783203 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-49023551-2d13-41ef-b71b-4b82fb687a06">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-49023551-2d13-41ef-b71b-4b82fb687a06_0">
											<gml:posList>35.67313145009736 139.738641035659 29.038 35.67313030506848 139.73864067247237 29.038 35.673126853370434 139.7386413835342 29.038 35.67313145009736 139.738641035659 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-310f5cf9-a557-4356-a64b-8b92ba284a0a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-310f5cf9-a557-4356-a64b-8b92ba284a0a_0">
											<gml:posList>35.673129820163666 139.73865447029613 29.038 35.67313098275089 139.73865423694372 29.038 35.673133072882464 139.73865289783203 29.038 35.673129820163666 139.73865447029613 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d53df5e9-4aaf-4fb3-b4c0-6c14d53d4cb2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d53df5e9-4aaf-4fb3-b4c0-6c14d53d4cb2_0">
											<gml:posList>35.67313030506848 139.73864067247237 29.038 35.67312911520557 139.73864060759794 29.038 35.673126853370434 139.7386413835342 29.038 35.67313030506848 139.73864067247237 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f1ef932e-e61b-41ee-aaab-ecd6b3ba1f9e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f1ef932e-e61b-41ee-aaab-ecd6b3ba1f9e_0">
											<gml:posList>35.673129820163666 139.73865447029613 29.038 35.6731274852806 139.73865405328135 29.038 35.67312863030944 139.7386544164681 29.038 35.673129820163666 139.73865447029613 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-22f3bf54-eb7a-4c0e-9f4c-6ea35e1a2318">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-22f3bf54-eb7a-4c0e-9f4c-6ea35e1a2318_0">
											<gml:posList>35.67312911520557 139.73864060759794 29.038 35.673127952618366 139.73864084095058 29.038 35.673126853370434 139.7386413835342 29.038 35.67312911520557 139.73864060759794 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-51ecf29a-8497-4265-b1c5-caa33f0b3fdf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-51ecf29a-8497-4265-b1c5-caa33f0b3fdf_0">
											<gml:posList>35.673129820163666 139.73865447029613 29.038 35.673126421149384 139.73865340278647 29.038 35.6731274852806 139.73865405328135 29.038 35.673129820163666 139.73865447029613 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78257d09-3812-4da3-9d9e-27e3d06ac1bb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78257d09-3812-4da3-9d9e-27e3d06ac1bb_0">
											<gml:posList>35.67312586248692 139.73864218006247 29.038 35.67312503404143 139.73864321942492 29.038 35.673126853370434 139.7386413835342 29.038 35.67312586248692 139.73864218006247 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ae8aa788-7f9e-4b86-a8c0-b436a67da3da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ae8aa788-7f9e-4b86-a8c0-b436a67da3da_0">
											<gml:posList>35.67312549202415 139.73865249805948 29.038 35.673126421149384 139.73865340278647 29.038 35.67312474299955 139.73865137218706 29.038 35.67312549202415 139.73865249805948 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3d01b97-a0a1-4488-9f47-acb55b2a040f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b3d01b97-a0a1-4488-9f47-acb55b2a040f_0">
											<gml:posList>35.67312503404143 139.73864321942492 29.038 35.67312439503172 139.7386444463564 29.038 35.673123981469175 139.73864580558123 29.038 35.67312503404143 139.73864321942492 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-56226f64-0b55-4137-aa32-63d4de62eee7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-56226f64-0b55-4137-aa32-63d4de62eee7_0">
											<gml:posList>35.67312474299955 139.73865137218706 29.038 35.67312387557179 139.73864868887867 29.038 35.673124192155115 139.7386500914277 29.038 35.67312474299955 139.73865137218706 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b636f9df-1fa0-4003-8f32-bd25fb9219f7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b636f9df-1fa0-4003-8f32-bd25fb9219f7_0">
											<gml:posList>35.673123981469175 139.73864580558123 29.038 35.6731238023241 139.7386472418557 29.038 35.67312387557179 139.73864868887867 29.038 35.673123981469175 139.73864580558123 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a38aacd8-480c-4849-b55a-e2a08fffeb67">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a38aacd8-480c-4849-b55a-e2a08fffeb67_0">
											<gml:posList>35.67313495390042 139.73864927231298 29.038 35.673135059797815 139.7386463890152 29.038 35.67313419236996 139.7386437057065 29.038 35.67313495390042 139.73864927231298 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-36ab9815-b969-4378-b2a1-30051a14419e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-36ab9815-b969-4378-b2a1-30051a14419e_0">
											<gml:posList>35.67313390132802 139.73865185846958 29.038 35.67313495390042 139.73864927231298 29.038 35.67313419236996 139.7386437057065 29.038 35.67313390132802 139.73865185846958 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7230d544-b564-48c5-95c1-51cbb3dc6865">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7230d544-b564-48c5-95c1-51cbb3dc6865_0">
											<gml:posList>35.67313145009736 139.738641035659 29.038 35.67313390132802 139.73865185846958 29.038 35.67313419236996 139.7386437057065 29.038 35.67313145009736 139.738641035659 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b827b2d-25b9-4f44-94a7-cb0c1811b5b9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4b827b2d-25b9-4f44-94a7-cb0c1811b5b9_0">
											<gml:posList>35.67313390132802 139.73865185846958 29.038 35.67312474299955 139.73865137218706 29.038 35.673129820163666 139.73865447029613 29.038 35.67313390132802 139.73865185846958 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff929b31-8e2a-49e2-9c2b-c5fabdefca03">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ff929b31-8e2a-49e2-9c2b-c5fabdefca03_0">
											<gml:posList>35.67313145009736 139.738641035659 29.038 35.673126853370434 139.7386413835342 29.038 35.67313390132802 139.73865185846958 29.038 35.67313145009736 139.738641035659 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b598aef-6f6c-48d5-82a5-61217e5aa27f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0b598aef-6f6c-48d5-82a5-61217e5aa27f_0">
											<gml:posList>35.67312474299955 139.73865137218706 29.038 35.673126421149384 139.73865340278647 29.038 35.673129820163666 139.73865447029613 29.038 35.67312474299955 139.73865137218706 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f1936c2-97f0-4b81-b884-0d23b877cd9c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1f1936c2-97f0-4b81-b884-0d23b877cd9c_0">
											<gml:posList>35.673126853370434 139.7386413835342 29.038 35.67312503404143 139.73864321942492 29.038 35.67312474299955 139.73865137218706 29.038 35.673126853370434 139.7386413835342 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84e87541-9ae2-4e7b-b235-6cb9e2168077">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-84e87541-9ae2-4e7b-b235-6cb9e2168077_0">
											<gml:posList>35.67312474299955 139.73865137218706 29.038 35.67312503404143 139.73864321942492 29.038 35.673123981469175 139.73864580558123 29.038 35.67312474299955 139.73865137218706 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a899fa38-66da-43da-a5a1-b9dec514142a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a899fa38-66da-43da-a5a1-b9dec514142a_0">
											<gml:posList>35.673123981469175 139.73864580558123 29.038 35.67312387557179 139.73864868887867 29.038 35.67312474299955 139.73865137218706 29.038 35.673123981469175 139.73864580558123 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9110b311-411a-4dd7-8d0c-42f64637a490">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9110b311-411a-4dd7-8d0c-42f64637a490_0">
											<gml:posList>35.673126853370434 139.7386413835342 29.038 35.67312474299955 139.73865137218706 29.038 35.67313390132802 139.73865185846958 29.038 35.673126853370434 139.7386413835342 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef0b117e-a64a-4b06-99bb-02e568e5ee87">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef0b117e-a64a-4b06-99bb-02e568e5ee87_0">
											<gml:posList>35.67312911520557 139.73864060759794 27.142 35.67313030506848 139.73864067247237 29.038 35.67313030506848 139.73864067247237 27.142 35.67312911520557 139.73864060759794 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b3e81fc-f973-476d-8578-4dc3a34c107f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6b3e81fc-f973-476d-8578-4dc3a34c107f_0">
											<gml:posList>35.67312911520557 139.73864060759794 27.142 35.67312911520557 139.73864060759794 29.038 35.67313030506848 139.73864067247237 29.038 35.67312911520557 139.73864060759794 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ee623404-8d74-4575-a68e-3655d1eb456d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ee623404-8d74-4575-a68e-3655d1eb456d_0">
											<gml:posList>35.67313098275089 139.73865423694372 27.142 35.673129820163666 139.73865447029613 29.038 35.673129820163666 139.73865447029613 27.142 35.67313098275089 139.73865423694372 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-be99c51e-5935-4829-90fc-d4f0ea733cf9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-be99c51e-5935-4829-90fc-d4f0ea733cf9_0">
											<gml:posList>35.67313098275089 139.73865423694372 27.142 35.67313098275089 139.73865423694372 29.038 35.673129820163666 139.73865447029613 29.038 35.67313098275089 139.73865423694372 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0688c024-4fba-4438-a5a6-971cb8018d4c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0688c024-4fba-4438-a5a6-971cb8018d4c_0">
											<gml:posList>35.67313030506848 139.73864067247237 27.142 35.67313145009736 139.738641035659 29.038 35.67313145009736 139.738641035659 27.142 35.67313030506848 139.73864067247237 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-389a7a7b-283f-4dd7-855b-336e88180282">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-389a7a7b-283f-4dd7-855b-336e88180282_0">
											<gml:posList>35.67313030506848 139.73864067247237 27.142 35.67313030506848 139.73864067247237 29.038 35.67313145009736 139.738641035659 29.038 35.67313030506848 139.73864067247237 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27e56efd-fd6a-46b7-a6a7-4d56d01a412a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-27e56efd-fd6a-46b7-a6a7-4d56d01a412a_0">
											<gml:posList>35.67313209102129 139.73865370539622 29.038 35.67313098275089 139.73865423694372 27.142 35.67313209102129 139.73865370539622 27.142 35.67313209102129 139.73865370539622 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b677f11c-a461-45c1-b3c7-cd0e69302ae7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b677f11c-a461-45c1-b3c7-cd0e69302ae7_0">
											<gml:posList>35.67313209102129 139.73865370539622 29.038 35.67313098275089 139.73865423694372 29.038 35.67313098275089 139.73865423694372 27.142 35.67313209102129 139.73865370539622 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04ec2d60-cb27-4a1c-a178-42e6f2666b5d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-04ec2d60-cb27-4a1c-a178-42e6f2666b5d_0">
											<gml:posList>35.67313145009736 139.738641035659 27.142 35.67313251421995 139.73864167510712 29.038 35.67313251421995 139.73864167510712 27.142 35.67313145009736 139.738641035659 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4880665a-360e-4d7b-bbf7-112046b8fa3d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4880665a-360e-4d7b-bbf7-112046b8fa3d_0">
											<gml:posList>35.67313145009736 139.738641035659 27.142 35.67313145009736 139.738641035659 29.038 35.67313251421995 139.73864167510712 29.038 35.67313145009736 139.738641035659 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e52c47da-8b6a-401a-b0cd-025ee7145799">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e52c47da-8b6a-401a-b0cd-025ee7145799_0">
											<gml:posList>35.673133072882464 139.73865289783203 27.142 35.67313209102129 139.73865370539622 29.038 35.67313209102129 139.73865370539622 27.142 35.673133072882464 139.73865289783203 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de71b4d6-b3d6-45b2-80f8-537eee79ba53">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de71b4d6-b3d6-45b2-80f8-537eee79ba53_0">
											<gml:posList>35.673133072882464 139.73865289783203 27.142 35.673133072882464 139.73865289783203 29.038 35.67313209102129 139.73865370539622 29.038 35.673133072882464 139.73865289783203 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c476f257-e37b-4beb-b776-357096b4c58f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c476f257-e37b-4beb-b776-357096b4c58f_0">
											<gml:posList>35.67313251421995 139.73864167510712 27.142 35.673133434331554 139.7386425798447 29.038 35.673133434331554 139.7386425798447 27.142 35.67313251421995 139.73864167510712 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-486c8184-0996-4b1a-b6d0-4dd39508323d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-486c8184-0996-4b1a-b6d0-4dd39508323d_0">
											<gml:posList>35.67313251421995 139.73864167510712 27.142 35.67313251421995 139.73864167510712 29.038 35.673133434331554 139.7386425798447 29.038 35.67313251421995 139.73864167510712 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-51870c76-2ce6-449e-b30b-3317c7a22cdc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-51870c76-2ce6-449e-b30b-3317c7a22cdc_0">
											<gml:posList>35.67314266465983 139.73865438884712 25.472 35.67312350935562 139.738664408676 27.142 35.67312350935562 139.738664408676 25.472 35.67314266465983 139.73865438884712 25.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-39e8cfcc-8e69-4d57-86ca-9a4da311b0a1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-39e8cfcc-8e69-4d57-86ca-9a4da311b0a1_0">
											<gml:posList>35.67314266465983 139.73865438884712 25.472 35.67314266465983 139.73865438884712 27.142 35.67312350935562 139.738664408676 27.142 35.67314266465983 139.73865438884712 25.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7137e57d-13e5-4571-9171-4e2cab24ff5b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7137e57d-13e5-4571-9171-4e2cab24ff5b_0">
											<gml:posList>35.67313390132802 139.73865185846958 29.038 35.673133072882464 139.73865289783203 27.142 35.67313390132802 139.73865185846958 27.142 35.67313390132802 139.73865185846958 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e730917c-b8c7-4488-9af0-eba5679204e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e730917c-b8c7-4488-9af0-eba5679204e4_0">
											<gml:posList>35.67313390132802 139.73865185846958 29.038 35.673133072882464 139.73865289783203 29.038 35.673133072882464 139.73865289783203 27.142 35.67313390132802 139.73865185846958 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-193cf1f4-d6e1-4d49-b376-fdfd52f663e6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-193cf1f4-d6e1-4d49-b376-fdfd52f663e6_0">
											<gml:posList>35.673133434331554 139.7386425798447 29.038 35.67313419236996 139.7386437057065 27.142 35.673133434331554 139.7386425798447 27.142 35.673133434331554 139.7386425798447 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25a95829-b1a1-49ba-b328-cf30191fc8ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-25a95829-b1a1-49ba-b328-cf30191fc8ca_0">
											<gml:posList>35.673133434331554 139.7386425798447 29.038 35.67313419236996 139.7386437057065 29.038 35.67313419236996 139.7386437057065 27.142 35.673133434331554 139.7386425798447 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb3c3ffa-b4dc-48ba-8861-da310fff747d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb3c3ffa-b4dc-48ba-8861-da310fff747d_0">
											<gml:posList>35.67313454033782 139.738650631538 29.038 35.67313390132802 139.73865185846958 27.142 35.67313454033782 139.738650631538 27.142 35.67313454033782 139.738650631538 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c49af009-9529-4199-8fa3-6dd72f640b6e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c49af009-9529-4199-8fa3-6dd72f640b6e_0">
											<gml:posList>35.67313454033782 139.738650631538 29.038 35.67313390132802 139.73865185846958 29.038 35.67313390132802 139.73865185846958 27.142 35.67313454033782 139.738650631538 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff132482-1f98-4456-a426-42d49ecfaecb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ff132482-1f98-4456-a426-42d49ecfaecb_0">
											<gml:posList>35.67313419236996 139.7386437057065 27.142 35.67313474321445 139.738644986466 29.038 35.67313474321445 139.738644986466 27.142 35.67313419236996 139.7386437057065 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f8f821d-e71c-4f49-947f-810591e561a0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0f8f821d-e71c-4f49-947f-810591e561a0_0">
											<gml:posList>35.67313419236996 139.7386437057065 27.142 35.67313419236996 139.7386437057065 29.038 35.67313474321445 139.738644986466 29.038 35.67313419236996 139.7386437057065 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60ff0163-71d8-4e5b-b61b-d1c9f472d8a7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-60ff0163-71d8-4e5b-b61b-d1c9f472d8a7_0">
											<gml:posList>35.67313495390042 139.73864927231298 29.038 35.67313454033782 139.738650631538 27.142 35.67313495390042 139.73864927231298 27.142 35.67313495390042 139.73864927231298 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-849d583d-d85f-473d-b9f3-737bcdca7769">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-849d583d-d85f-473d-b9f3-737bcdca7769_0">
											<gml:posList>35.67313495390042 139.73864927231298 29.038 35.67313454033782 139.738650631538 29.038 35.67313454033782 139.738650631538 27.142 35.67313495390042 139.73864927231298 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9b3e3bc8-e10a-4054-a8cf-59c42d650874">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9b3e3bc8-e10a-4054-a8cf-59c42d650874_0">
											<gml:posList>35.67313474321445 139.738644986466 29.038 35.673135059797815 139.7386463890152 27.142 35.67313474321445 139.738644986466 27.142 35.67313474321445 139.738644986466 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61278fbd-4177-45d3-b40f-8ee262ca3487">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-61278fbd-4177-45d3-b40f-8ee262ca3487_0">
											<gml:posList>35.67313474321445 139.738644986466 29.038 35.673135059797815 139.7386463890152 29.038 35.673135059797815 139.7386463890152 27.142 35.67313474321445 139.738644986466 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea96bd91-e83c-4a8c-a967-2eb7fbaddee0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea96bd91-e83c-4a8c-a967-2eb7fbaddee0_0">
											<gml:posList>35.67313513304552 139.73864783603838 27.142 35.67313495390042 139.73864927231298 29.038 35.67313495390042 139.73864927231298 27.142 35.67313513304552 139.73864783603838 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-47f4ba86-042b-419f-9b47-a676d8bf93f7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-47f4ba86-042b-419f-9b47-a676d8bf93f7_0">
											<gml:posList>35.67313513304552 139.73864783603838 27.142 35.67313513304552 139.73864783603838 29.038 35.67313495390042 139.73864927231298 29.038 35.67313513304552 139.73864783603838 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-90cd72d6-727a-4ec2-8f4e-a8602e20d2be">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-90cd72d6-727a-4ec2-8f4e-a8602e20d2be_0">
											<gml:posList>35.673135059797815 139.7386463890152 27.142 35.67313513304552 139.73864783603838 29.038 35.67313513304552 139.73864783603838 27.142 35.673135059797815 139.7386463890152 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff30af1a-e5b8-4fe2-b647-8c5283fa5466">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ff30af1a-e5b8-4fe2-b647-8c5283fa5466_0">
											<gml:posList>35.673135059797815 139.7386463890152 27.142 35.673135059797815 139.7386463890152 29.038 35.67313513304552 139.73864783603838 29.038 35.673135059797815 139.7386463890152 27.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8ac074c9-b4af-4aa4-aaf2-917b4eaa1db9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8ac074c9-b4af-4aa4-aaf2-917b4eaa1db9_0">
											<gml:posList>35.6731301582328 139.7386832022027 25.472 35.67314266465983 139.73865438884712 25.472 35.67312350935562 139.738664408676 25.472 35.6731301582328 139.7386832022027 25.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-707fbee7-fed3-483e-8a9d-334270b47b90">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-707fbee7-fed3-483e-8a9d-334270b47b90_0">
											<gml:posList>35.6731301582328 139.7386832022027 25.472 35.673149286453985 139.7386731271763 25.472 35.67314266465983 139.73865438884712 25.472 35.6731301582328 139.7386832022027 25.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-354d1766-6d42-43cc-96f3-3ddcb78e204d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-354d1766-6d42-43cc-96f3-3ddcb78e204d_0">
											<gml:posList>35.67313475985662 139.7386317636197 25.598 35.67313475985662 139.7386317636197 27.142 35.67313592524135 139.7386350872814 25.598 35.67313475985662 139.7386317636197 25.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fdcf2516-5535-4a6b-b51a-3ffc73fe6350">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fdcf2516-5535-4a6b-b51a-3ffc73fe6350_0">
											<gml:posList>35.67313592524135 139.7386350872814 24.867 35.67313592524135 139.7386350872814 25.598 35.67314266465983 139.73865438884712 25.472 35.67313592524135 139.7386350872814 24.867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-49c70b4b-0e2f-48cc-9985-c5900f499aae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-49c70b4b-0e2f-48cc-9985-c5900f499aae_0">
											<gml:posList>35.67314266465983 139.73865438884712 24.867 35.67313592524135 139.7386350872814 24.867 35.67314266465983 139.73865438884712 25.472 35.67314266465983 139.73865438884712 24.867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b01ba4b1-5871-4af4-980e-e135a4802616">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b01ba4b1-5871-4af4-980e-e135a4802616_0">
											<gml:posList>35.67313592524135 139.7386350872814 25.598 35.67313475985662 139.7386317636197 27.142 35.67314266465983 139.73865438884712 27.142 35.67313592524135 139.7386350872814 25.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48d57b8b-767d-4c86-8fdc-879ca04afa83">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-48d57b8b-767d-4c86-8fdc-879ca04afa83_0">
											<gml:posList>35.67313592524135 139.7386350872814 25.598 35.67314266465983 139.73865438884712 27.142 35.67314266465983 139.73865438884712 25.472 35.67313592524135 139.7386350872814 25.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-920a0d05-82da-4107-a215-08f4095aef92">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-920a0d05-82da-4107-a215-08f4095aef92_0">
											<gml:posList>35.673149286453985 139.7386731271763 25.472 35.6731301582328 139.7386832022027 24.867 35.673149286453985 139.7386731271763 24.867 35.673149286453985 139.7386731271763 25.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d40218c-c98a-40b9-916e-bb781fde326f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6d40218c-c98a-40b9-916e-bb781fde326f_0">
											<gml:posList>35.673149286453985 139.7386731271763 25.472 35.6731301582328 139.7386832022027 25.472 35.6731301582328 139.7386832022027 24.867 35.673149286453985 139.7386731271763 25.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b67291a-4783-432a-ae37-f0046a51f4ed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0b67291a-4783-432a-ae37-f0046a51f4ed_0">
											<gml:posList>35.673149286453985 139.7386731271763 25.472 35.67314266465983 139.73865438884712 24.867 35.67314266465983 139.73865438884712 25.472 35.673149286453985 139.7386731271763 25.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b038dd58-fb04-482d-8948-bb7a7a8a73a3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b038dd58-fb04-482d-8948-bb7a7a8a73a3_0">
											<gml:posList>35.673149286453985 139.7386731271763 25.472 35.673149286453985 139.7386731271763 24.867 35.67314266465983 139.73865438884712 24.867 35.673149286453985 139.7386731271763 25.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e3a08815-f86a-48e9-a856-b3da9ee8d41a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673116742845444 139.7386450408662 25.598 35.67313475985662 139.7386317636197 25.598 35.67313592524135 139.7386350872814 25.598 35.673116742845444 139.7386450408662 25.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2fbd77a5-8f6e-4b01-a90f-54ededf57d28">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673116742845444 139.7386450408662 25.598 35.673115604545586 139.73864177240634 25.598 35.67313475985662 139.7386317636197 25.598 35.673116742845444 139.7386450408662 25.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-899a8f9c-d678-49a9-a09e-94c6c7f7ba94">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67313592524135 139.7386350872814 24.867 35.67314266465983 139.73865438884712 24.867 35.67312350935562 139.738664408676 24.867 35.67313592524135 139.7386350872814 24.867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aee27bf0-aad8-42e1-8b9e-7638f2e7d592">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673149286453985 139.7386731271763 24.867 35.6731301582328 139.7386832022027 24.867 35.67314266465983 139.73865438884712 24.867 35.673149286453985 139.7386731271763 24.867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-299bd317-5536-49b1-80f2-40f65a24b085">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67313592524135 139.7386350872814 24.867 35.67312350935562 139.738664408676 24.867 35.673116742845444 139.7386450408662 24.867 35.67313592524135 139.7386350872814 24.867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f61de2ac-7ac1-400c-a248-a8d89557103c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67314266465983 139.73865438884712 24.867 35.6731301582328 139.7386832022027 24.867 35.67312350935562 139.738664408676 24.867 35.67314266465983 139.73865438884712 24.867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fdaec79a-9e16-4ef4-8d82-18def172e435">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67312398191638 139.73866930177826 24.867 35.67311519262934 139.7386910850764 24.867 35.673110088538124 139.73867666419608 24.867 35.67312398191638 139.73866930177826 24.867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8fdfab53-81d1-4318-aca9-efea2c18b243">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67312398191638 139.73866930177826 24.867 35.67312909505692 139.73868376683646 24.867 35.67311519262934 139.7386910850764 24.867 35.67312398191638 139.73866930177826 24.867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2dc542d4-5b55-4f8c-b041-9bbe130f5070">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67312909505692 139.73868376683646 25.598 35.67311645738038 139.73869468478676 25.598 35.67311519262934 139.7386910850764 25.598 35.67312909505692 139.73868376683646 25.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-09482025-c52b-4863-bb4b-4764471c9819">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67312909505692 139.73868376683646 25.598 35.673130350751045 139.73868731132484 25.598 35.67311645738038 139.73869468478676 25.598 35.67312909505692 139.73868376683646 25.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-fda48746-7aef-4959-886a-844430f4a0e0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fda48746-7aef-4959-886a-844430f4a0e0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fda48746-7aef-4959-886a-844430f4a0e0">
											<gml:posList>35.673213242807435 139.73864377803804 7.97 35.67309248185174 139.73870740567074 7.97 35.67307658167207 139.73866158092036 7.97 35.67319932553483 139.73859784042168 7.97 35.673213242807435 139.73864377803804 7.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-82de88f8-1c2e-4d98-bb29-134960473787">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-82de88f8-1c2e-4d98-bb29-134960473787">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-82de88f8-1c2e-4d98-bb29-134960473787">
											<gml:posList>35.67307658167207 139.73866158092036 25.598 35.67308084681097 139.73866367474363 25.598 35.67319745485318 139.738603145023 25.598 35.67319932553483 139.73859784042168 25.598 35.67307658167207 139.73866158092036 25.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-35016694-5cdd-4e56-8fec-e97f021b8c99">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-35016694-5cdd-4e56-8fec-e97f021b8c99">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-35016694-5cdd-4e56-8fec-e97f021b8c99">
											<gml:posList>35.67320911282192 139.73864161777283 24.867 35.67319745485318 139.738603145023 24.867 35.67308084681097 139.73866367474363 24.867 35.673094199339545 139.73870214544613 24.867 35.67320911282192 139.73864161777283 24.867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-934e7549-61c8-43ae-b63f-f43e0c09055f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-934e7549-61c8-43ae-b63f-f43e0c09055f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-934e7549-61c8-43ae-b63f-f43e0c09055f">
											<gml:posList>35.673213242807435 139.73864377803804 25.598 35.67319932553483 139.73859784042168 25.598 35.67319745485318 139.738603145023 25.598 35.67320911282192 139.73864161777283 25.598 35.673213242807435 139.73864377803804 25.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b635badc-bc68-415e-92ce-3cea8808a4dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b635badc-bc68-415e-92ce-3cea8808a4dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b635badc-bc68-415e-92ce-3cea8808a4dd">
											<gml:posList>35.67309248185174 139.73870740567074 25.598 35.673094199339545 139.73870214544613 25.598 35.67308084681097 139.73866367474363 25.598 35.67307658167207 139.73866158092036 25.598 35.67309248185174 139.73870740567074 25.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6662c527-4c63-46c6-9751-663606502b6a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6662c527-4c63-46c6-9751-663606502b6a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6662c527-4c63-46c6-9751-663606502b6a">
											<gml:posList>35.673213242807435 139.73864377803804 25.598 35.67320911282192 139.73864161777283 25.598 35.673094199339545 139.73870214544613 25.598 35.67309248185174 139.73870740567074 25.598 35.673213242807435 139.73864377803804 25.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-78196e35-d513-4303-994c-b499aea2aa81">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78196e35-d513-4303-994c-b499aea2aa81">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78196e35-d513-4303-994c-b499aea2aa81">
											<gml:posList>35.67308084681097 139.73866367474363 25.598 35.67308084681097 139.73866367474363 24.867 35.67319745485318 139.738603145023 24.867 35.67319745485318 139.738603145023 25.598 35.67308084681097 139.73866367474363 25.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b8f85343-4b24-4ec6-8b9d-b38ecf074594">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8f85343-4b24-4ec6-8b9d-b38ecf074594">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8f85343-4b24-4ec6-8b9d-b38ecf074594">
											<gml:posList>35.67320911282192 139.73864161777283 25.598 35.67320911282192 139.73864161777283 24.867 35.673094199339545 139.73870214544613 24.867 35.673094199339545 139.73870214544613 25.598 35.67320911282192 139.73864161777283 25.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1f58bccb-6764-45ac-a0e8-24ab4496cbfc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f58bccb-6764-45ac-a0e8-24ab4496cbfc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f58bccb-6764-45ac-a0e8-24ab4496cbfc">
											<gml:posList>35.67307658167207 139.73866158092036 7.97 35.67309248185174 139.73870740567074 7.97 35.67309248185174 139.73870740567074 25.598 35.67307658167207 139.73866158092036 25.598 35.67307658167207 139.73866158092036 7.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5f72fa64-5af5-49ad-b158-a9302c2369e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f72fa64-5af5-49ad-b158-a9302c2369e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f72fa64-5af5-49ad-b158-a9302c2369e7">
											<gml:posList>35.673094199339545 139.73870214544613 25.598 35.673094199339545 139.73870214544613 24.867 35.67308084681097 139.73866367474363 24.867 35.67308084681097 139.73866367474363 25.598 35.673094199339545 139.73870214544613 25.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6fa23c34-7cf3-4145-ad98-9064b4e37db7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6fa23c34-7cf3-4145-ad98-9064b4e37db7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6fa23c34-7cf3-4145-ad98-9064b4e37db7">
											<gml:posList>35.67319932553483 139.73859784042168 7.97 35.67307658167207 139.73866158092036 7.97 35.67307658167207 139.73866158092036 25.598 35.67319932553483 139.73859784042168 25.598 35.67319932553483 139.73859784042168 7.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1c4d2fd7-872c-4b3c-aea7-5bdaa2daa903">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c4d2fd7-872c-4b3c-aea7-5bdaa2daa903">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c4d2fd7-872c-4b3c-aea7-5bdaa2daa903">
											<gml:posList>35.67309248185174 139.73870740567074 7.97 35.673213242807435 139.73864377803804 7.97 35.673213242807435 139.73864377803804 25.598 35.67309248185174 139.73870740567074 25.598 35.67309248185174 139.73870740567074 7.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4fb78dd3-832e-466d-a460-84ca7d7a8e72">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4fb78dd3-832e-466d-a460-84ca7d7a8e72">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4fb78dd3-832e-466d-a460-84ca7d7a8e72">
											<gml:posList>35.67319745485318 139.738603145023 25.598 35.67319745485318 139.738603145023 24.867 35.67320911282192 139.73864161777283 24.867 35.67320911282192 139.73864161777283 25.598 35.67319745485318 139.738603145023 25.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0c7f277c-78d6-438a-b711-8dc82cac589a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c7f277c-78d6-438a-b711-8dc82cac589a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c7f277c-78d6-438a-b711-8dc82cac589a">
											<gml:posList>35.673213242807435 139.73864377803804 7.97 35.67319932553483 139.73859784042168 7.97 35.67319932553483 139.73859784042168 25.598 35.673213242807435 139.73864377803804 25.598 35.673213242807435 139.73864377803804 7.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4487</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">62.33385</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.08</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>