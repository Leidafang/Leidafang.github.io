<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_8aa4a2ae-a597-45da-beec-761b68d98bd3">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">35</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67355533631934 139.73859230510132 0 35.673515330970524 139.73861212595605 0 35.673535750620346 139.73867396331622 0 35.6735968398257 139.73864362321967 0 35.67362322274893 139.73872357020988 0 35.673902595283764 139.73854163202643 0 35.67385497915778 139.73839719699572 0 35.67355948714813 139.7385407783997 0 35.67357347443947 139.73858403178173 0 35.67355533631934 139.73859230510132 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67355533631934 139.73859230510132 7.689 35.67357347443947 139.73858403178173 7.689 35.67355948714813 139.7385407783997 7.689 35.67385497915778 139.73839719699572 7.689 35.673902595283764 139.73854163202643 7.689 35.67362322274893 139.73872357020988 7.689 35.6735968398257 139.73864362321967 7.689 35.673535750620346 139.73867396331622 7.689 35.673515330970524 139.73861212595605 7.689 35.67355533631934 139.73859230510132 7.689</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67355533631934 139.73859230510132 7.689 35.673515330970524 139.73861212595605 7.689 35.673515330970524 139.73861212595605 38.5 35.67355533631934 139.73859230510132 38.5 35.67355533631934 139.73859230510132 7.689</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673515330970524 139.73861212595605 7.689 35.673535750620346 139.73867396331622 7.689 35.673535750620346 139.73867396331622 38.5 35.673515330970524 139.73861212595605 38.5 35.673515330970524 139.73861212595605 7.689</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673535750620346 139.73867396331622 7.689 35.6735968398257 139.73864362321967 7.689 35.6735968398257 139.73864362321967 38.5 35.673535750620346 139.73867396331622 38.5 35.673535750620346 139.73867396331622 7.689</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6735968398257 139.73864362321967 7.689 35.67362322274893 139.73872357020988 7.689 35.67362322274893 139.73872357020988 38.5 35.6735968398257 139.73864362321967 38.5 35.6735968398257 139.73864362321967 7.689</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67362322274893 139.73872357020988 7.689 35.673902595283764 139.73854163202643 7.689 35.673902595283764 139.73854163202643 38.5 35.67362322274893 139.73872357020988 38.5 35.67362322274893 139.73872357020988 7.689</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673902595283764 139.73854163202643 7.689 35.67385497915778 139.73839719699572 7.689 35.67385497915778 139.73839719699572 38.5 35.673902595283764 139.73854163202643 38.5 35.673902595283764 139.73854163202643 7.689</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67385497915778 139.73839719699572 7.689 35.67355948714813 139.7385407783997 7.689 35.67355948714813 139.7385407783997 38.5 35.67385497915778 139.73839719699572 38.5 35.67385497915778 139.73839719699572 7.689</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67355948714813 139.7385407783997 7.689 35.67357347443947 139.73858403178173 7.689 35.67357347443947 139.73858403178173 38.5 35.67355948714813 139.7385407783997 38.5 35.67355948714813 139.7385407783997 7.689</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67357347443947 139.73858403178173 7.689 35.67355533631934 139.73859230510132 7.689 35.67355533631934 139.73859230510132 38.5 35.67357347443947 139.73858403178173 38.5 35.67357347443947 139.73858403178173 7.689</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67355533631934 139.73859230510132 38.5 35.673515330970524 139.73861212595605 38.5 35.673535750620346 139.73867396331622 38.5 35.6735968398257 139.73864362321967 38.5 35.67362322274893 139.73872357020988 38.5 35.673902595283764 139.73854163202643 38.5 35.67385497915778 139.73839719699572 38.5 35.67355948714813 139.7385407783997 38.5 35.67357347443947 139.73858403178173 38.5 35.67355533631934 139.73859230510132 38.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-1d46261e-2ae8-462c-9349-bdce7a1ab55d"/>
							<gml:surfaceMember xlink:href="#poly-076de7ef-fb41-4df4-875a-961d9d0bb247"/>
							<gml:surfaceMember xlink:href="#poly-8fe8c77f-dfb5-474f-b606-533ab0026d49"/>
							<gml:surfaceMember xlink:href="#poly-af5949eb-6840-4352-aa70-db306b41e182"/>
							<gml:surfaceMember xlink:href="#poly-94e6170a-f1be-4d28-9dca-fa251b4067be"/>
							<gml:surfaceMember xlink:href="#poly-632e24b5-21ec-4711-9367-bc800ff16d1b"/>
							<gml:surfaceMember xlink:href="#poly-b39075e6-15f6-4f1a-ac6a-65f49734bb40"/>
							<gml:surfaceMember xlink:href="#poly-779939be-5da3-48be-b1f2-69423455491a"/>
							<gml:surfaceMember xlink:href="#poly-3e0770af-2056-432b-8c65-490b197a7c03"/>
							<gml:surfaceMember xlink:href="#poly-6755ca96-41b1-480e-befd-8d5a60cdbc44"/>
							<gml:surfaceMember xlink:href="#poly-1c556ed2-3075-483c-b873-c225d6267570"/>
							<gml:surfaceMember xlink:href="#poly-f27d44e7-096a-42b1-814b-c82c9ac89aa4"/>
							<gml:surfaceMember xlink:href="#poly-f5223bf5-7f98-447e-b478-824b835003f2"/>
							<gml:surfaceMember xlink:href="#poly-ceca5d46-414b-468b-aa4f-dc2f4482ea29"/>
							<gml:surfaceMember xlink:href="#poly-b457f63e-5e74-4f80-adb9-52fe1636e79a"/>
							<gml:surfaceMember xlink:href="#poly-961fe5d2-e7a1-494a-8557-3e002ae10c6a"/>
							<gml:surfaceMember xlink:href="#poly-f7cef137-f3c1-40c2-9088-a28aa34ca196"/>
							<gml:surfaceMember xlink:href="#poly-c32f7c3d-c498-4da7-a0f1-38bb02a67d1d"/>
							<gml:surfaceMember xlink:href="#poly-cc7bbd80-ebc1-4911-9e61-61da6e0d9757"/>
							<gml:surfaceMember xlink:href="#poly-36f9bdca-cc98-4395-96fb-df03a15384cf"/>
							<gml:surfaceMember xlink:href="#poly-11589c5d-fc0d-4886-af0b-1e962cf9d0eb"/>
							<gml:surfaceMember xlink:href="#poly-384db635-20af-4686-ae81-6b3d5076087a"/>
							<gml:surfaceMember xlink:href="#poly-e04ecee7-c773-43db-b158-f14274e2cc38"/>
							<gml:surfaceMember xlink:href="#poly-837ffc56-eecd-4418-92df-bab8b0c27b7b"/>
							<gml:surfaceMember xlink:href="#poly-54514f25-6d91-4a37-9907-253d29266273"/>
							<gml:surfaceMember xlink:href="#poly-27bf9109-ad4b-49e8-a895-730fb7623573"/>
							<gml:surfaceMember xlink:href="#poly-069c1d1a-c9c7-4e13-b710-3fafd12ef6cd"/>
							<gml:surfaceMember xlink:href="#poly-a9c10bdf-b47c-416b-9ed2-4d2e3b7dfb32"/>
							<gml:surfaceMember xlink:href="#poly-7cbec245-52e6-49eb-8ad9-4dae5094226d"/>
							<gml:surfaceMember xlink:href="#poly-b5af5645-fdcb-4dcd-8f69-03cbc08bcdca"/>
							<gml:surfaceMember xlink:href="#poly-cc8820a2-2b74-4c7c-975b-41b3dab6bd8d"/>
							<gml:surfaceMember xlink:href="#poly-7c55341e-3a2d-4651-9a28-d54de0b53af3"/>
							<gml:surfaceMember xlink:href="#poly-7c554bbf-2bab-4f38-bdd4-2b5e34ab233f"/>
							<gml:surfaceMember xlink:href="#poly-6b45b8b8-8265-4f0e-b150-e396cb525823"/>
							<gml:surfaceMember xlink:href="#poly-48e7526a-9736-4055-9b44-ecb4c36c0def"/>
							<gml:surfaceMember xlink:href="#poly-6b02d319-36b5-430d-8f6a-bc6bfffefd96"/>
							<gml:surfaceMember xlink:href="#poly-02640a3d-1202-45a9-bee3-6cc192a61df6"/>
							<gml:surfaceMember xlink:href="#poly-61019ae6-ead5-411c-8bd5-e5cdd0bb8a37"/>
							<gml:surfaceMember xlink:href="#poly-7eca84fd-104c-4e9b-992d-a9912e6db5b8"/>
							<gml:surfaceMember xlink:href="#poly-963bf567-e631-40d9-893e-42f937e62d68"/>
							<gml:surfaceMember xlink:href="#poly-8af4cb4b-359a-47b2-b74a-51d27e997504"/>
							<gml:surfaceMember xlink:href="#poly-a5f1d596-1ea6-40e4-9928-e967b686a0e6"/>
							<gml:surfaceMember xlink:href="#poly-676352f7-d1f4-477d-a846-efc62be9e060"/>
							<gml:surfaceMember xlink:href="#poly-9b60a484-6348-4270-91c0-e0117f6f4de0"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_8aa4a2ae-a597-45da-beec-761b68d98bd3_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-21ee374d-ee13-4391-a844-33e3b8f16edc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67360038534077 139.7385444859197 38.776 35.67364312873423 139.73852197742178 38.776 35.673649515774514 139.73854018589236 38.776 35.673606763355274 139.73856268334637 38.776 35.67360038534077 139.7385444859197 38.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f05d763c-682e-42bc-9405-cb977d9e4d7c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f05d763c-682e-42bc-9405-cb977d9e4d7c_0">
											<gml:posList>35.67360038534077 139.7385444859197 41.483 35.67360038534077 139.7385444859197 38.776 35.673606763355274 139.73856268334637 38.776 35.673606763355274 139.73856268334637 41.483 35.67360038534077 139.7385444859197 41.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37dbee31-e7f2-4ed8-a502-f7a90e2ba25d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-37dbee31-e7f2-4ed8-a502-f7a90e2ba25d_0">
											<gml:posList>35.67364312873423 139.73852197742178 41.483 35.67364312873423 139.73852197742178 38.776 35.67360038534077 139.7385444859197 38.776 35.67360038534077 139.7385444859197 41.483 35.67364312873423 139.73852197742178 41.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f144b1c3-7567-4d39-b5cb-6b5a3562c0b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f144b1c3-7567-4d39-b5cb-6b5a3562c0b0_0">
											<gml:posList>35.67360038534077 139.7385444859197 41.483 35.673606763355274 139.73856268334637 41.483 35.673649515774514 139.73854018589236 41.483 35.67364312873423 139.73852197742178 41.483 35.67360038534077 139.7385444859197 41.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f9be8e56-1b96-4865-8023-401eb9849110">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f9be8e56-1b96-4865-8023-401eb9849110_0">
											<gml:posList>35.673606763355274 139.73856268334637 41.483 35.673606763355274 139.73856268334637 38.776 35.673649515774514 139.73854018589236 38.776 35.673649515774514 139.73854018589236 41.483 35.673606763355274 139.73856268334637 41.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9238cc5-d9f0-400b-9f21-f251e5d132b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b9238cc5-d9f0-400b-9f21-f251e5d132b0_0">
											<gml:posList>35.673649515774514 139.73854018589236 38.776 35.67364312873423 139.73852197742178 38.776 35.67364312873423 139.73852197742178 41.483 35.673649515774514 139.73854018589236 41.483 35.673649515774514 139.73854018589236 38.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_8aa4a2ae-a597-45da-beec-761b68d98bd3_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19fb0afb-fd43-40da-bfe9-72da62508769">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673555336319346 139.7385923051013 8.25 35.6735407007129 139.73854990308962 8.25 35.67355948714815 139.7385407783997 8.25 35.67357347443945 139.7385840317817 8.25 35.673555336319346 139.7385923051013 8.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc0a7d3e-f051-4886-9493-a124fccc909d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc0a7d3e-f051-4886-9493-a124fccc909d_0">
											<gml:posList>35.673555336319346 139.7385923051013 37.16 35.6735407007129 139.73854990308962 37.16 35.6735407007129 139.73854990308962 8.25 35.673555336319346 139.7385923051013 8.25 35.673555336319346 139.7385923051013 37.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf219e25-0d58-4add-ad0e-94dbdb00f262">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cf219e25-0d58-4add-ad0e-94dbdb00f262_0">
											<gml:posList>35.6735407007129 139.73854990308962 37.16 35.67355948714815 139.7385407783997 37.16 35.67355948714815 139.7385407783997 8.25 35.6735407007129 139.73854990308962 8.25 35.6735407007129 139.73854990308962 37.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19b9e74a-6db8-4989-8e24-e76fb4be4112">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19b9e74a-6db8-4989-8e24-e76fb4be4112_0">
											<gml:posList>35.6735407007129 139.73854990308962 37.16 35.673555336319346 139.7385923051013 37.16 35.67357347443945 139.7385840317817 37.16 35.67355948714815 139.7385407783997 37.16 35.6735407007129 139.73854990308962 37.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-487eb854-8f07-4999-8e0d-cfdbfef3980d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-487eb854-8f07-4999-8e0d-cfdbfef3980d_0">
											<gml:posList>35.67357347443945 139.7385840317817 37.16 35.673555336319346 139.7385923051013 37.16 35.673555336319346 139.7385923051013 8.25 35.67357347443945 139.7385840317817 8.25 35.67357347443945 139.7385840317817 37.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef92cd36-7078-4428-b71c-6693a72872bb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef92cd36-7078-4428-b71c-6693a72872bb_0">
											<gml:posList>35.67355948714815 139.7385407783997 37.16 35.67357347443945 139.7385840317817 37.16 35.67357347443945 139.7385840317817 8.25 35.67355948714815 139.7385407783997 8.25 35.67355948714815 139.7385407783997 37.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_8aa4a2ae-a597-45da-beec-761b68d98bd3_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-be603733-70ef-4f81-bdb7-f27e24a7a53a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673626429052 139.73868587506325 38.776 35.67361191775074 139.73864103152837 38.776 35.673618819625936 139.73863767622427 38.776 35.67363332191471 139.73868251977305 38.776 35.673626429052 139.73868587506325 38.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b931824a-f294-4df4-93a5-930a9c76cf6d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673688466498454 139.73850891077217 42.656 35.673687978165695 139.73850688980093 42.656 35.67368785032068 139.7385047910763 42.656 35.67368807401932 139.73850270298257 42.656 35.6736886583449 139.73850071388264 42.656 35.67368955830717 139.7384989232502 42.656 35.673690746917174 139.7384973973974 42.656 35.67369216113111 139.73849620267916 42.656 35.673693755932604 139.73849540542898 42.656 35.67369544120189 139.73849502784697 42.656 35.67369716287408 139.73849509209055 42.656 35.6736988308033 139.7384955872196 42.656 35.67370038187612 139.7384964912155 42.656 35.67370174396539 139.73849778207006 42.656 35.6737028629366 139.73849939356703 42.656 35.6737036756241 139.73850123740743 42.656 35.673704163956955 139.738503258379 42.656 35.67370429181069 139.73850536815078 42.656 35.67370405909829 139.7385074562556 42.656 35.673703483777615 139.73850943429846 42.656 35.67370258382389 139.73851123597785 42.656 35.67370139520502 139.73851275078397 42.656 35.673699980990925 139.73851394550204 42.656 35.67369838618931 139.7385147427519 42.656 35.673696691914934 139.7385151313909 42.656 35.673694979256474 139.73851506713623 42.656 35.673693302313616 139.73851457201744 42.656 35.67369176024594 139.73851365696393 42.656 35.67369039816554 139.73851237715596 42.656 35.67368927919451 139.73851076565904 42.656 35.673688466498454 139.73850891077217 42.656</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eb8fc52d-c2ee-4ba7-bd45-b005c431bba2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67380715065809 139.7384293775304 38.776 35.67381065656476 139.73844026545765 38.776 35.6737954111534 139.73844764062548 38.776 35.67379190524739 139.73843675269998 38.776 35.67380715065809 139.7384293775304 38.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7fae0fe5-6b22-4c36-862d-009083bfef06">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67380265607454 139.7384678365211 38.776 35.67379914115664 139.73845694860435 38.776 35.673814386568566 139.73844957343795 38.776 35.67381789248211 139.7384604724138 38.776 35.67380265607454 139.7384678365211 38.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f997fca5-81f7-47bb-8161-40abd42a0a1a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67382456035786 139.73848045911103 38.776 35.67380931493536 139.7384878232258 38.776 35.67380580903299 139.7384769352966 38.776 35.67382105444612 139.73846956013338 38.776 35.67382456035786 139.73848045911103 38.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a82cd843-06c4-47a7-809d-c9e3d1c51440">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67382528823497 139.7384204302977 38.776 35.67382879414245 139.73843131822704 38.776 35.6738135577454 139.7384386933876 38.776 35.673810051838586 139.73842780545996 38.776 35.67382528823497 139.7384204302977 38.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b16c97f-037b-4613-b26d-18ae09603743">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67381562260587 139.73850825221854 38.776 35.67381211670534 139.73849736428758 38.776 35.673827362119724 139.73848998912766 38.776 35.67383086802091 139.73850087706035 38.776 35.67381562260587 139.73850825221854 38.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b690cf6-0b0d-407b-910c-bd4c52f0eb61">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67382105444612 139.73846956013338 41.391 35.67382456035786 139.73848045911103 41.391 35.67382456035786 139.73848045911103 38.776 35.67382105444612 139.73846956013338 38.776 35.67382105444612 139.73846956013338 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aedfb15b-301a-4d9c-88f8-5980966a3916">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67382688518326 139.73847955052813 41.391 35.67382337927145 139.7384686515502 41.391 35.67382337927145 139.7384686515502 38.776 35.67382688518326 139.73847955052813 38.776 35.67382688518326 139.73847955052813 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e268370b-1218-488e-8a4f-75801afe3a84">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67383159600396 139.73844096975643 38.776 35.673835101909575 139.73845185768752 38.776 35.67381986550258 139.73845922179802 38.776 35.67381635959763 139.73844833386866 38.776 35.67383159600396 139.73844096975643 38.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f2b4459-fd36-4a66-8d54-667e8c5ea6b3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67382528823497 139.7384204302977 41.391 35.67382879414245 139.73843131822704 41.391 35.67382879414245 139.73843131822704 38.776 35.67382528823497 139.7384204302977 38.776 35.67382528823497 139.7384204302977 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-079c613b-91e8-4dd8-8cba-637fa8722b30">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67382265145726 139.73852879082895 38.776 35.6738191455586 139.73851790289615 38.776 35.6738343819605 139.73851052775015 38.776 35.67383788786853 139.7385214267314 38.776 35.67382265145726 139.73852879082895 38.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4532d6b7-da68-4b6c-8f00-c7af4b7448d7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673827362119724 139.73848998912766 41.391 35.67383086802091 139.73850087706035 41.391 35.67383086802091 139.73850087706035 38.776 35.673827362119724 139.73848998912766 38.776 35.673827362119724 139.73848998912766 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f769263-62ef-40c3-bb23-3398610b8557">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673827802173825 139.73841930055448 41.391 35.673827802173825 139.73841930055448 38.776 35.67383130809011 139.73843019953082 38.776 35.67383130809011 139.73843019953082 41.391 35.673827802173825 139.73841930055448 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7178f563-c817-4734-b4c8-847b11a0b091">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67383346309267 139.7384997582703 41.391 35.673829957191394 139.73848887033733 41.391 35.673829957191394 139.73848887033733 38.776 35.67383346309267 139.7384997582703 38.776 35.67383346309267 139.7384997582703 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9d0ac93-1399-42aa-8cbb-d3f375954e8f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67382688518326 139.73847955052813 38.776 35.67382337927145 139.7384686515502 38.776 35.67383862469273 139.7384612874305 38.776 35.673842130596505 139.73847217536346 38.776 35.67382688518326 139.73847955052813 38.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7505baf6-3f73-4b10-8630-77241d26d7ce">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673843038578354 139.73841193643563 38.776 35.6738465535003 139.73842282435638 38.776 35.67383130809011 139.73843019953082 38.776 35.673827802173825 139.73841930055448 38.776 35.673843038578354 139.73841193643563 38.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-91933245-351d-43f5-9060-93a404787868">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67383346309267 139.7384997582703 38.776 35.673829957191394 139.73848887033733 38.776 35.673845202605186 139.7384814951741 38.776 35.673848708507144 139.73849238310885 38.776 35.67383346309267 139.7384997582703 38.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-779f1017-c5bd-4983-8294-9d473246321a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67383743531323 139.73845039675672 38.776 35.673833929407486 139.73843950882537 38.776 35.673849174826955 139.73843214469915 38.776 35.67385268073336 139.73844303263226 38.776 35.67383743531323 139.73845039675672 38.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ade41d5-caeb-4726-a690-8ccf787c3f4d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673839860985304 139.73852029763077 38.776 35.67383635507718 139.73850939864928 38.776 35.67385160050093 139.73850203453614 38.776 35.6738550973873 139.7385129224833 38.776 35.673839860985304 139.73852029763077 38.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f4212348-21e6-4546-87e3-73e410001bc3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673845202605186 139.7384814951741 41.391 35.673848708507144 139.73849238310885 41.391 35.673848708507144 139.73849238310885 38.776 35.673845202605186 139.7384814951741 38.776 35.673845202605186 139.7384814951741 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26c3223d-10c6-48c3-a1c6-c9b5a8a3de61">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673851393715985 139.73849126421166 41.391 35.673847887813935 139.73848037627658 41.391 35.673847887813935 139.73848037627658 38.776 35.673851393715985 139.73849126421166 38.776 35.673851393715985 139.73849126421166 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7598d17e-e8e7-44bb-b808-fbe62acc4592">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673844365023584 139.738470935485 38.776 35.673840859119686 139.73846004755177 38.776 35.673856104540405 139.73845268342882 38.776 35.67385961044496 139.73846357136375 38.776 35.673844365023584 139.738470935485 38.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1e95eca-117d-4650-a5fb-6e1b3cbdd2ef">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673851393715985 139.73849126421166 38.776 35.673847887813935 139.73848037627658 38.776 35.67386313322717 139.73847300111015 38.776 35.67386663913859 139.73848390009366 38.776 35.673851393715985 139.73849126421166 38.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8376662d-dd29-4e3b-9c3c-f0f80783e412">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673873118496644 139.73850487018788 38.776 35.67385788209519 139.73851224533854 38.776 35.673854376195045 139.7385013574017 38.776 35.673869612595844 139.73849398224928 38.776 35.673873118496644 139.73850487018788 38.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-450b7f6d-b32d-458f-b999-91ed6291c1f3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-450b7f6d-b32d-458f-b999-91ed6291c1f3_0">
											<gml:posList>35.67361191775074 139.73864103152837 40.439 35.673618819625936 139.73863767622427 40.439 35.673618819625936 139.73863767622427 38.776 35.67361191775074 139.73864103152837 38.776 35.67361191775074 139.73864103152837 40.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-892e31d1-0045-4be3-b274-02eea734a823">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-892e31d1-0045-4be3-b274-02eea734a823_0">
											<gml:posList>35.673626429052 139.73868587506325 40.439 35.67361191775074 139.73864103152837 40.439 35.67361191775074 139.73864103152837 38.776 35.673626429052 139.73868587506325 38.776 35.673626429052 139.73868587506325 40.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf68e4f3-8030-478f-bd3a-e35301cb13f2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bf68e4f3-8030-478f-bd3a-e35301cb13f2_0">
											<gml:posList>35.673618819625936 139.73863767622427 40.439 35.67361191775074 139.73864103152837 40.439 35.673626429052 139.73868587506325 40.439 35.67363332191471 139.73868251977305 40.439 35.673618819625936 139.73863767622427 40.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-265ba6c6-3d88-4595-b76d-640e735c95d2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-265ba6c6-3d88-4595-b76d-640e735c95d2_0">
											<gml:posList>35.673618819625936 139.73863767622427 40.439 35.67363332191471 139.73868251977305 40.439 35.67363332191471 139.73868251977305 38.776 35.673618819625936 139.73863767622427 38.776 35.673618819625936 139.73863767622427 40.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-07f17128-ca2f-4148-b8d9-726f88eeb277">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-07f17128-ca2f-4148-b8d9-726f88eeb277_0">
											<gml:posList>35.673687978165695 139.73850688980093 45.001 35.67368785032068 139.7385047910763 45.001 35.67368785032068 139.7385047910763 42.656 35.673687978165695 139.73850688980093 42.656 35.673687978165695 139.73850688980093 45.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-91958e99-5d09-4673-8d65-0e3bc81d9236">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-91958e99-5d09-4673-8d65-0e3bc81d9236_0">
											<gml:posList>35.67368785032068 139.7385047910763 45.001 35.67368807401932 139.73850270298257 45.001 35.67368807401932 139.73850270298257 42.656 35.67368785032068 139.7385047910763 42.656 35.67368785032068 139.7385047910763 45.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0cd31b75-f894-41d1-ab21-fc2e1a9426af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0cd31b75-f894-41d1-ab21-fc2e1a9426af_0">
											<gml:posList>35.673688466498454 139.73850891077217 45.001 35.673687978165695 139.73850688980093 45.001 35.673687978165695 139.73850688980093 42.656 35.673688466498454 139.73850891077217 42.656 35.673688466498454 139.73850891077217 45.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c882a10-6b40-4f38-ace0-fce45c9f1fa4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c882a10-6b40-4f38-ace0-fce45c9f1fa4_0">
											<gml:posList>35.67368807401932 139.73850270298257 45.001 35.6736886583449 139.73850071388264 45.001 35.6736886583449 139.73850071388264 42.656 35.67368807401932 139.73850270298257 42.656 35.67368807401932 139.73850270298257 45.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d39bd3c-7e47-4261-9fa0-f168ec548223">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d39bd3c-7e47-4261-9fa0-f168ec548223_0">
											<gml:posList>35.67368927919451 139.73851076565904 45.001 35.673688466498454 139.73850891077217 45.001 35.673688466498454 139.73850891077217 42.656 35.67368927919451 139.73851076565904 42.656 35.67368927919451 139.73851076565904 45.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e5bd9d8-e421-4a6f-9102-672e0f90cee6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7e5bd9d8-e421-4a6f-9102-672e0f90cee6_0">
											<gml:posList>35.6736886583449 139.73850071388264 45.001 35.67368955830717 139.7384989232502 45.001 35.67368955830717 139.7384989232502 42.656 35.6736886583449 139.73850071388264 42.656 35.6736886583449 139.73850071388264 45.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-06d54d2b-4a00-4a37-975c-a8eba25fbb97">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-06d54d2b-4a00-4a37-975c-a8eba25fbb97_0">
											<gml:posList>35.67369039816554 139.73851237715596 45.001 35.67368927919451 139.73851076565904 45.001 35.67368927919451 139.73851076565904 42.656 35.67369039816554 139.73851237715596 42.656 35.67369039816554 139.73851237715596 45.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-092ee293-1503-4500-bb4d-ec88f6480aca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-092ee293-1503-4500-bb4d-ec88f6480aca_0">
											<gml:posList>35.673690746917174 139.7384973973974 45.001 35.673690746917174 139.7384973973974 42.656 35.67368955830717 139.7384989232502 42.656 35.67368955830717 139.7384989232502 45.001 35.673690746917174 139.7384973973974 45.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a1af3fe-f2ad-4819-8d0d-ae746cddae8c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4a1af3fe-f2ad-4819-8d0d-ae746cddae8c_0">
											<gml:posList>35.67369176024594 139.73851365696393 45.001 35.67369039816554 139.73851237715596 45.001 35.67369039816554 139.73851237715596 42.656 35.67369176024594 139.73851365696393 42.656 35.67369176024594 139.73851365696393 45.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-501a00e1-4b03-410c-94d9-375ae1f86d8c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-501a00e1-4b03-410c-94d9-375ae1f86d8c_0">
											<gml:posList>35.673690746917174 139.7384973973974 45.001 35.67369216113111 139.73849620267916 45.001 35.67369216113111 139.73849620267916 42.656 35.673690746917174 139.7384973973974 42.656 35.673690746917174 139.7384973973974 45.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7938904a-87a4-4cf0-8d96-7dc32f6fc032">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7938904a-87a4-4cf0-8d96-7dc32f6fc032_0">
											<gml:posList>35.673693302313616 139.73851457201744 45.001 35.67369176024594 139.73851365696393 45.001 35.67369176024594 139.73851365696393 42.656 35.673693302313616 139.73851457201744 42.656 35.673693302313616 139.73851457201744 45.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d5697138-5077-43ec-9b79-5dd63253d028">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d5697138-5077-43ec-9b79-5dd63253d028_0">
											<gml:posList>35.67369216113111 139.73849620267916 45.001 35.673693755932604 139.73849540542898 45.001 35.673693755932604 139.73849540542898 42.656 35.67369216113111 139.73849620267916 42.656 35.67369216113111 139.73849620267916 45.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3be72c31-5ca8-450d-80a0-5f859085b470">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3be72c31-5ca8-450d-80a0-5f859085b470_0">
											<gml:posList>35.673693302313616 139.73851457201744 45.001 35.673693302313616 139.73851457201744 42.656 35.673694979256474 139.73851506713623 42.656 35.673694979256474 139.73851506713623 45.001 35.673693302313616 139.73851457201744 45.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6bd09863-0522-4550-904c-306056375a73">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6bd09863-0522-4550-904c-306056375a73_0">
											<gml:posList>35.67369544120189 139.73849502784697 45.001 35.67369544120189 139.73849502784697 42.656 35.673693755932604 139.73849540542898 42.656 35.673693755932604 139.73849540542898 45.001 35.67369544120189 139.73849502784697 45.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bcb3c77d-da16-4ad1-bf9e-42fceefb3ba4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bcb3c77d-da16-4ad1-bf9e-42fceefb3ba4_0">
											<gml:posList>35.673696691914934 139.7385151313909 45.001 35.673694979256474 139.73851506713623 45.001 35.673694979256474 139.73851506713623 42.656 35.673696691914934 139.7385151313909 42.656 35.673696691914934 139.7385151313909 45.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-79956257-1392-4e5d-a6f2-b3d28c269d54">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-79956257-1392-4e5d-a6f2-b3d28c269d54_0">
											<gml:posList>35.67368785032068 139.7385047910763 45.001 35.673687978165695 139.73850688980093 45.001 35.673688466498454 139.73850891077217 45.001 35.67368927919451 139.73851076565904 45.001 35.67369039816554 139.73851237715596 45.001 35.67369176024594 139.73851365696393 45.001 35.673693302313616 139.73851457201744 45.001 35.673694979256474 139.73851506713623 45.001 35.673696691914934 139.7385151313909 45.001 35.67369838618931 139.7385147427519 45.001 35.673699980990925 139.73851394550204 45.001 35.67370139520502 139.73851275078397 45.001 35.67370258382389 139.73851123597785 45.001 35.673703483777615 139.73850943429846 45.001 35.67370405909829 139.7385074562556 45.001 35.67370429181069 139.73850536815078 45.001 35.673704163956955 139.738503258379 45.001 35.6737036756241 139.73850123740743 45.001 35.6737028629366 139.73849939356703 45.001 35.67370174396539 139.73849778207006 45.001 35.67370038187612 139.7384964912155 45.001 35.6736988308033 139.7384955872196 45.001 35.67369716287408 139.73849509209055 45.001 35.67369544120189 139.73849502784697 45.001 35.673693755932604 139.73849540542898 45.001 35.67369216113111 139.73849620267916 45.001 35.673690746917174 139.7384973973974 45.001 35.67368955830717 139.7384989232502 45.001 35.6736886583449 139.73850071388264 45.001 35.67368807401932 139.73850270298257 45.001 35.67368785032068 139.7385047910763 45.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ae779d8d-df38-4bac-bf65-ee14e2d8bc3d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ae779d8d-df38-4bac-bf65-ee14e2d8bc3d_0">
											<gml:posList>35.67369544120189 139.73849502784697 45.001 35.67369716287408 139.73849509209055 45.001 35.67369716287408 139.73849509209055 42.656 35.67369544120189 139.73849502784697 42.656 35.67369544120189 139.73849502784697 45.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3925b1ad-2137-4898-a5c7-0202732bba82">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3925b1ad-2137-4898-a5c7-0202732bba82_0">
											<gml:posList>35.673696691914934 139.7385151313909 45.001 35.673696691914934 139.7385151313909 42.656 35.67369838618931 139.7385147427519 42.656 35.67369838618931 139.7385147427519 45.001 35.673696691914934 139.7385151313909 45.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6bcda22c-97de-41cf-857e-7f6fb95ef79d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6bcda22c-97de-41cf-857e-7f6fb95ef79d_0">
											<gml:posList>35.67369716287408 139.73849509209055 45.001 35.6736988308033 139.7384955872196 45.001 35.6736988308033 139.7384955872196 42.656 35.67369716287408 139.73849509209055 42.656 35.67369716287408 139.73849509209055 45.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-233c9d65-64df-4a12-94bb-ab9591c41d64">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-233c9d65-64df-4a12-94bb-ab9591c41d64_0">
											<gml:posList>35.673699980990925 139.73851394550204 45.001 35.67369838618931 139.7385147427519 45.001 35.67369838618931 139.7385147427519 42.656 35.673699980990925 139.73851394550204 42.656 35.673699980990925 139.73851394550204 45.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c0cde3c-4221-490e-b44e-1cf7653122be">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c0cde3c-4221-490e-b44e-1cf7653122be_0">
											<gml:posList>35.67370038187612 139.7384964912155 45.001 35.67370038187612 139.7384964912155 42.656 35.6736988308033 139.7384955872196 42.656 35.6736988308033 139.7384955872196 45.001 35.67370038187612 139.7384964912155 45.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca15e9f1-c0a8-4a24-9596-e15fb15bb1bf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ca15e9f1-c0a8-4a24-9596-e15fb15bb1bf_0">
											<gml:posList>35.67370139520502 139.73851275078397 45.001 35.673699980990925 139.73851394550204 45.001 35.673699980990925 139.73851394550204 42.656 35.67370139520502 139.73851275078397 42.656 35.67370139520502 139.73851275078397 45.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8827e189-55a5-4f23-ae5f-8dcc027e6d68">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8827e189-55a5-4f23-ae5f-8dcc027e6d68_0">
											<gml:posList>35.67370038187612 139.7384964912155 45.001 35.67370174396539 139.73849778207006 45.001 35.67370174396539 139.73849778207006 42.656 35.67370038187612 139.7384964912155 42.656 35.67370038187612 139.7384964912155 45.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f9aef69-7da2-4823-ba44-5593989bf235">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9f9aef69-7da2-4823-ba44-5593989bf235_0">
											<gml:posList>35.67370139520502 139.73851275078397 45.001 35.67370139520502 139.73851275078397 42.656 35.67370258382389 139.73851123597785 42.656 35.67370258382389 139.73851123597785 45.001 35.67370139520502 139.73851275078397 45.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-32384b2c-0d1c-460f-859e-405ed642858e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-32384b2c-0d1c-460f-859e-405ed642858e_0">
											<gml:posList>35.67370174396539 139.73849778207006 45.001 35.6737028629366 139.73849939356703 45.001 35.6737028629366 139.73849939356703 42.656 35.67370174396539 139.73849778207006 42.656 35.67370174396539 139.73849778207006 45.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6aaf56b7-ec59-4dee-9489-fbf357d07876">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6aaf56b7-ec59-4dee-9489-fbf357d07876_0">
											<gml:posList>35.673703483777615 139.73850943429846 45.001 35.67370258382389 139.73851123597785 45.001 35.67370258382389 139.73851123597785 42.656 35.673703483777615 139.73850943429846 42.656 35.673703483777615 139.73850943429846 45.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-806bf1e0-9270-4d48-8597-df34930b1b17">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-806bf1e0-9270-4d48-8597-df34930b1b17_0">
											<gml:posList>35.6737028629366 139.73849939356703 45.001 35.6737036756241 139.73850123740743 45.001 35.6737036756241 139.73850123740743 42.656 35.6737028629366 139.73849939356703 42.656 35.6737028629366 139.73849939356703 45.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-994db9e1-2ede-48db-89be-d348531795b7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-994db9e1-2ede-48db-89be-d348531795b7_0">
											<gml:posList>35.67370405909829 139.7385074562556 45.001 35.673703483777615 139.73850943429846 45.001 35.673703483777615 139.73850943429846 42.656 35.67370405909829 139.7385074562556 42.656 35.67370405909829 139.7385074562556 45.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-306fdda1-89d6-4281-931d-6be3b1446add">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-306fdda1-89d6-4281-931d-6be3b1446add_0">
											<gml:posList>35.6737036756241 139.73850123740743 45.001 35.673704163956955 139.738503258379 45.001 35.673704163956955 139.738503258379 42.656 35.6737036756241 139.73850123740743 42.656 35.6737036756241 139.73850123740743 45.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1af8fc2d-e9d7-49d0-8a63-d29da6ce814e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1af8fc2d-e9d7-49d0-8a63-d29da6ce814e_0">
											<gml:posList>35.67370429181069 139.73850536815078 45.001 35.67370405909829 139.7385074562556 45.001 35.67370405909829 139.7385074562556 42.656 35.67370429181069 139.73850536815078 42.656 35.67370429181069 139.73850536815078 45.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1cc9558e-5ca3-4499-90cc-f226123de9ba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1cc9558e-5ca3-4499-90cc-f226123de9ba_0">
											<gml:posList>35.673704163956955 139.738503258379 45.001 35.67370429181069 139.73850536815078 45.001 35.67370429181069 139.73850536815078 42.656 35.673704163956955 139.738503258379 42.656 35.673704163956955 139.738503258379 45.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1169d00e-f9dc-4260-992c-a3a87748023e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1169d00e-f9dc-4260-992c-a3a87748023e_0">
											<gml:posList>35.6737954111534 139.73844764062548 41.391 35.67379190524739 139.73843675269998 41.391 35.67379190524739 139.73843675269998 38.776 35.6737954111534 139.73844764062548 38.776 35.6737954111534 139.73844764062548 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-87818ad4-bab2-4792-935c-c38f8fea7499">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-87818ad4-bab2-4792-935c-c38f8fea7499_0">
											<gml:posList>35.67379190524739 139.73843675269998 41.391 35.67380715065809 139.7384293775304 41.391 35.67380715065809 139.7384293775304 38.776 35.67379190524739 139.73843675269998 38.776 35.67379190524739 139.73843675269998 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-66bfcb0f-9a5c-4c4e-9c7a-e2488d189cc8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-66bfcb0f-9a5c-4c4e-9c7a-e2488d189cc8_0">
											<gml:posList>35.67380265607454 139.7384678365211 41.391 35.67379914115664 139.73845694860435 41.391 35.67379914115664 139.73845694860435 38.776 35.67380265607454 139.7384678365211 38.776 35.67380265607454 139.7384678365211 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f308271-e77c-4e75-810a-840cc06d8943">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f308271-e77c-4e75-810a-840cc06d8943_0">
											<gml:posList>35.67380715065809 139.7384293775304 41.391 35.67379190524739 139.73843675269998 41.391 35.6737954111534 139.73844764062548 41.391 35.67381065656476 139.73844026545765 41.391 35.67380715065809 139.7384293775304 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc8a19f9-ae7f-4827-803d-9ebe8783b813">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bc8a19f9-ae7f-4827-803d-9ebe8783b813_0">
											<gml:posList>35.6737954111534 139.73844764062548 41.391 35.6737954111534 139.73844764062548 38.776 35.67381065656476 139.73844026545765 38.776 35.67381065656476 139.73844026545765 41.391 35.6737954111534 139.73844764062548 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48ce4c66-8d95-481d-afe9-77de5cb9c58b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-48ce4c66-8d95-481d-afe9-77de5cb9c58b_0">
											<gml:posList>35.67379914115664 139.73845694860435 41.391 35.673814386568566 139.73844957343795 41.391 35.673814386568566 139.73844957343795 38.776 35.67379914115664 139.73845694860435 38.776 35.67379914115664 139.73845694860435 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4ab2bfb6-1169-4ccb-8a51-22d165388395">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4ab2bfb6-1169-4ccb-8a51-22d165388395_0">
											<gml:posList>35.67380580903299 139.7384769352966 38.776 35.67380931493536 139.7384878232258 38.776 35.67380931493536 139.7384878232258 41.391 35.67380580903299 139.7384769352966 41.391 35.67380580903299 139.7384769352966 38.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8fabc56-aa77-4396-bd0c-e865a48d14f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8fabc56-aa77-4396-bd0c-e865a48d14f0_0">
											<gml:posList>35.673814386568566 139.73844957343795 41.391 35.67379914115664 139.73845694860435 41.391 35.67380265607454 139.7384678365211 41.391 35.67381789248211 139.7384604724138 41.391 35.673814386568566 139.73844957343795 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e81bce3a-b5cf-419a-b6cd-a5bbc2724742">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e81bce3a-b5cf-419a-b6cd-a5bbc2724742_0">
											<gml:posList>35.67380715065809 139.7384293775304 41.391 35.67381065656476 139.73844026545765 41.391 35.67381065656476 139.73844026545765 38.776 35.67380715065809 139.7384293775304 38.776 35.67380715065809 139.7384293775304 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-097d3e8d-af41-4b71-a6d5-52f7d5b3b181">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-097d3e8d-af41-4b71-a6d5-52f7d5b3b181_0">
											<gml:posList>35.67381789248211 139.7384604724138 41.391 35.67380265607454 139.7384678365211 41.391 35.67380265607454 139.7384678365211 38.776 35.67381789248211 139.7384604724138 38.776 35.67381789248211 139.7384604724138 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a507ebfe-fae9-4053-8a71-628d221ac4ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a507ebfe-fae9-4053-8a71-628d221ac4ca_0">
											<gml:posList>35.673810051838586 139.73842780545996 41.391 35.673810051838586 139.73842780545996 38.776 35.6738135577454 139.7384386933876 38.776 35.6738135577454 139.7384386933876 41.391 35.673810051838586 139.73842780545996 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5697f9d-988f-445b-9a2d-a9060b861c51">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c5697f9d-988f-445b-9a2d-a9060b861c51_0">
											<gml:posList>35.67380580903299 139.7384769352966 41.391 35.67382105444612 139.73846956013338 41.391 35.67382105444612 139.73846956013338 38.776 35.67380580903299 139.7384769352966 38.776 35.67380580903299 139.7384769352966 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46881035-59b7-4234-bf99-aaa77b46b723">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46881035-59b7-4234-bf99-aaa77b46b723_0">
											<gml:posList>35.67381562260587 139.73850825221854 41.391 35.67381211670534 139.73849736428758 41.391 35.67381211670534 139.73849736428758 38.776 35.67381562260587 139.73850825221854 38.776 35.67381562260587 139.73850825221854 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e1b45aa-78dc-418a-b378-ea55448448b6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7e1b45aa-78dc-418a-b378-ea55448448b6_0">
											<gml:posList>35.67380580903299 139.7384769352966 41.391 35.67380931493536 139.7384878232258 41.391 35.67382456035786 139.73848045911103 41.391 35.67382105444612 139.73846956013338 41.391 35.67380580903299 139.7384769352966 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27c356f2-40f9-45dc-88fc-4cfb6fe1c8c2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-27c356f2-40f9-45dc-88fc-4cfb6fe1c8c2_0">
											<gml:posList>35.673814386568566 139.73844957343795 41.391 35.67381789248211 139.7384604724138 41.391 35.67381789248211 139.7384604724138 38.776 35.673814386568566 139.73844957343795 38.776 35.673814386568566 139.73844957343795 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2bdc125c-7bba-41a0-9c6a-5688e82282cd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2bdc125c-7bba-41a0-9c6a-5688e82282cd_0">
											<gml:posList>35.67382456035786 139.73848045911103 41.391 35.67380931493536 139.7384878232258 41.391 35.67380931493536 139.7384878232258 38.776 35.67382456035786 139.73848045911103 38.776 35.67382456035786 139.73848045911103 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9b09ed15-e51d-4fde-b9b2-c6f0660c57de">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9b09ed15-e51d-4fde-b9b2-c6f0660c57de_0">
											<gml:posList>35.673810051838586 139.73842780545996 41.391 35.67382528823497 139.7384204302977 41.391 35.67382528823497 139.7384204302977 38.776 35.673810051838586 139.73842780545996 38.776 35.673810051838586 139.73842780545996 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-67951c6e-b862-4d7b-aa84-b9684e8a8b27">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-67951c6e-b862-4d7b-aa84-b9684e8a8b27_0">
											<gml:posList>35.67381986550258 139.73845922179802 41.391 35.67381635959763 139.73844833386866 41.391 35.67381635959763 139.73844833386866 38.776 35.67381986550258 139.73845922179802 38.776 35.67381986550258 139.73845922179802 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f01cc9b-f32f-449a-9d6c-90705431526f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5f01cc9b-f32f-449a-9d6c-90705431526f_0">
											<gml:posList>35.67382528823497 139.7384204302977 41.391 35.673810051838586 139.73842780545996 41.391 35.6738135577454 139.7384386933876 41.391 35.67382879414245 139.73843131822704 41.391 35.67382528823497 139.7384204302977 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-98eee422-3ea2-44e1-9eae-534a87541abc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-98eee422-3ea2-44e1-9eae-534a87541abc_0">
											<gml:posList>35.67381211670534 139.73849736428758 41.391 35.673827362119724 139.73848998912766 41.391 35.673827362119724 139.73848998912766 38.776 35.67381211670534 139.73849736428758 38.776 35.67381211670534 139.73849736428758 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e7fcd2d-b1fe-4ca5-b9bc-b804115c8111">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6e7fcd2d-b1fe-4ca5-b9bc-b804115c8111_0">
											<gml:posList>35.67382265145726 139.73852879082895 41.391 35.6738191455586 139.73851790289615 41.391 35.6738191455586 139.73851790289615 38.776 35.67382265145726 139.73852879082895 38.776 35.67382265145726 139.73852879082895 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c82a0a1e-6639-40a2-bffd-0b47582c467f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c82a0a1e-6639-40a2-bffd-0b47582c467f_0">
											<gml:posList>35.6738135577454 139.7384386933876 41.391 35.6738135577454 139.7384386933876 38.776 35.67382879414245 139.73843131822704 38.776 35.67382879414245 139.73843131822704 41.391 35.6738135577454 139.7384386933876 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-17226b5c-8161-4793-9b70-802e5c0621e7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-17226b5c-8161-4793-9b70-802e5c0621e7_0">
											<gml:posList>35.673827362119724 139.73848998912766 41.391 35.67381211670534 139.73849736428758 41.391 35.67381562260587 139.73850825221854 41.391 35.67383086802091 139.73850087706035 41.391 35.673827362119724 139.73848998912766 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-abc1155e-457f-4a21-90cf-180dc4beeba2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-abc1155e-457f-4a21-90cf-180dc4beeba2_0">
											<gml:posList>35.67383086802091 139.73850087706035 41.391 35.67381562260587 139.73850825221854 41.391 35.67381562260587 139.73850825221854 38.776 35.67383086802091 139.73850087706035 38.776 35.67383086802091 139.73850087706035 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e600bfc1-0c79-478f-8882-da5075a062a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e600bfc1-0c79-478f-8882-da5075a062a8_0">
											<gml:posList>35.67381635959763 139.73844833386866 41.391 35.67383159600396 139.73844096975643 41.391 35.67383159600396 139.73844096975643 38.776 35.67381635959763 139.73844833386866 38.776 35.67381635959763 139.73844833386866 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d252f57-be0c-4f8c-a149-d1fefa22528f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5d252f57-be0c-4f8c-a149-d1fefa22528f_0">
											<gml:posList>35.67383159600396 139.73844096975643 41.391 35.67381635959763 139.73844833386866 41.391 35.67381986550258 139.73845922179802 41.391 35.673835101909575 139.73845185768752 41.391 35.67383159600396 139.73844096975643 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1da343ef-e281-4b45-9c25-050be3631f7c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1da343ef-e281-4b45-9c25-050be3631f7c_0">
											<gml:posList>35.6738191455586 139.73851790289615 41.391 35.6738343819605 139.73851052775015 41.391 35.6738343819605 139.73851052775015 38.776 35.6738191455586 139.73851790289615 38.776 35.6738191455586 139.73851790289615 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e7a91711-9f03-416b-be02-529ee329a6ac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e7a91711-9f03-416b-be02-529ee329a6ac_0">
											<gml:posList>35.67381986550258 139.73845922179802 41.391 35.67381986550258 139.73845922179802 38.776 35.673835101909575 139.73845185768752 38.776 35.673835101909575 139.73845185768752 41.391 35.67381986550258 139.73845922179802 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c097589-ed7f-48ac-a2b9-e7b11b9c0a73">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4c097589-ed7f-48ac-a2b9-e7b11b9c0a73_0">
											<gml:posList>35.6738343819605 139.73851052775015 41.391 35.6738191455586 139.73851790289615 41.391 35.67382265145726 139.73852879082895 41.391 35.67383788786853 139.7385214267314 41.391 35.6738343819605 139.73851052775015 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46763f3f-efba-42d4-96b6-930b7f02c7b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46763f3f-efba-42d4-96b6-930b7f02c7b0_0">
											<gml:posList>35.67383788786853 139.7385214267314 41.391 35.67382265145726 139.73852879082895 41.391 35.67382265145726 139.73852879082895 38.776 35.67383788786853 139.7385214267314 38.776 35.67383788786853 139.7385214267314 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ac17bfc-52cc-47ef-9c2e-9efa337dbe16">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6ac17bfc-52cc-47ef-9c2e-9efa337dbe16_0">
											<gml:posList>35.67382337927145 139.7384686515502 41.391 35.67383862469273 139.7384612874305 41.391 35.67383862469273 139.7384612874305 38.776 35.67382337927145 139.7384686515502 38.776 35.67382337927145 139.7384686515502 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e022bbdc-4cfd-4425-a766-ff040db2416f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e022bbdc-4cfd-4425-a766-ff040db2416f_0">
											<gml:posList>35.67383862469273 139.7384612874305 41.391 35.67382337927145 139.7384686515502 41.391 35.67382688518326 139.73847955052813 41.391 35.673842130596505 139.73847217536346 41.391 35.67383862469273 139.7384612874305 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8941c2a5-a548-4997-91fc-03c8732aef38">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8941c2a5-a548-4997-91fc-03c8732aef38_0">
											<gml:posList>35.67383159600396 139.73844096975643 41.391 35.673835101909575 139.73845185768752 41.391 35.673835101909575 139.73845185768752 38.776 35.67383159600396 139.73844096975643 38.776 35.67383159600396 139.73844096975643 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2f83f39-534b-44fb-9c62-648f7038b3e0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a2f83f39-534b-44fb-9c62-648f7038b3e0_0">
											<gml:posList>35.673842130596505 139.73847217536346 41.391 35.67382688518326 139.73847955052813 41.391 35.67382688518326 139.73847955052813 38.776 35.673842130596505 139.73847217536346 38.776 35.673842130596505 139.73847217536346 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7aaea26d-2388-4da8-8e82-cf05b03b70e8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7aaea26d-2388-4da8-8e82-cf05b03b70e8_0">
											<gml:posList>35.673827802173825 139.73841930055448 41.391 35.673843038578354 139.73841193643563 41.391 35.673843038578354 139.73841193643563 38.776 35.673827802173825 139.73841930055448 38.776 35.673827802173825 139.73841930055448 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-62dc9dfa-ce8d-4696-b40d-cd715799462d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-62dc9dfa-ce8d-4696-b40d-cd715799462d_0">
											<gml:posList>35.67383743531323 139.73845039675672 41.391 35.673833929407486 139.73843950882537 41.391 35.673833929407486 139.73843950882537 38.776 35.67383743531323 139.73845039675672 38.776 35.67383743531323 139.73845039675672 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-946a4618-e95b-46c6-9246-752a9615b8f1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-946a4618-e95b-46c6-9246-752a9615b8f1_0">
											<gml:posList>35.6738343819605 139.73851052775015 41.391 35.67383788786853 139.7385214267314 41.391 35.67383788786853 139.7385214267314 38.776 35.6738343819605 139.73851052775015 38.776 35.6738343819605 139.73851052775015 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-21978085-5a37-4c29-be15-c1afd9325d66">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-21978085-5a37-4c29-be15-c1afd9325d66_0">
											<gml:posList>35.673843038578354 139.73841193643563 41.391 35.673827802173825 139.73841930055448 41.391 35.67383130809011 139.73843019953082 41.391 35.6738465535003 139.73842282435638 41.391 35.673843038578354 139.73841193643563 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b74ce5ee-d864-42b9-847b-1ced3f0e8cce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b74ce5ee-d864-42b9-847b-1ced3f0e8cce_0">
											<gml:posList>35.673829957191394 139.73848887033733 41.391 35.673845202605186 139.7384814951741 41.391 35.673845202605186 139.7384814951741 38.776 35.673829957191394 139.73848887033733 38.776 35.673829957191394 139.73848887033733 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-741c640b-8595-43e5-ab9f-c959bd76ae73">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-741c640b-8595-43e5-ab9f-c959bd76ae73_0">
											<gml:posList>35.673839860985304 139.73852029763077 41.391 35.67383635507718 139.73850939864928 41.391 35.67383635507718 139.73850939864928 38.776 35.673839860985304 139.73852029763077 38.776 35.673839860985304 139.73852029763077 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f6659229-6a23-48e6-bfaf-f6784ece8e95">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f6659229-6a23-48e6-bfaf-f6784ece8e95_0">
											<gml:posList>35.67383130809011 139.73843019953082 38.776 35.6738465535003 139.73842282435638 38.776 35.6738465535003 139.73842282435638 41.391 35.67383130809011 139.73843019953082 41.391 35.67383130809011 139.73843019953082 38.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ee113a6-28e2-466e-947e-191f4e9cd7f3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7ee113a6-28e2-466e-947e-191f4e9cd7f3_0">
											<gml:posList>35.673845202605186 139.7384814951741 41.391 35.673829957191394 139.73848887033733 41.391 35.67383346309267 139.7384997582703 41.391 35.673848708507144 139.73849238310885 41.391 35.673845202605186 139.7384814951741 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fd613004-0e3c-4471-b170-20ebbcd67717">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fd613004-0e3c-4471-b170-20ebbcd67717_0">
											<gml:posList>35.67383862469273 139.7384612874305 41.391 35.673842130596505 139.73847217536346 41.391 35.673842130596505 139.73847217536346 38.776 35.67383862469273 139.7384612874305 38.776 35.67383862469273 139.7384612874305 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b32a925-2363-417a-84cd-0621c8ef1734">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b32a925-2363-417a-84cd-0621c8ef1734_0">
											<gml:posList>35.673848708507144 139.73849238310885 41.391 35.67383346309267 139.7384997582703 41.391 35.67383346309267 139.7384997582703 38.776 35.673848708507144 139.73849238310885 38.776 35.673848708507144 139.73849238310885 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf8fc415-adfe-4bb7-be05-61dcd5a5a2aa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bf8fc415-adfe-4bb7-be05-61dcd5a5a2aa_0">
											<gml:posList>35.673833929407486 139.73843950882537 41.391 35.673849174826955 139.73843214469915 41.391 35.673849174826955 139.73843214469915 38.776 35.673833929407486 139.73843950882537 38.776 35.673833929407486 139.73843950882537 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a5cf36ff-569c-463f-a83b-cb9c6f08f889">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a5cf36ff-569c-463f-a83b-cb9c6f08f889_0">
											<gml:posList>35.673844365023584 139.738470935485 41.391 35.673840859119686 139.73846004755177 41.391 35.673840859119686 139.73846004755177 38.776 35.673844365023584 139.738470935485 38.776 35.673844365023584 139.738470935485 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-746c03e5-4869-4462-b74f-5188ceba21e0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-746c03e5-4869-4462-b74f-5188ceba21e0_0">
											<gml:posList>35.673849174826955 139.73843214469915 41.391 35.673833929407486 139.73843950882537 41.391 35.67383743531323 139.73845039675672 41.391 35.67385268073336 139.73844303263226 41.391 35.673849174826955 139.73843214469915 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e6694de7-d587-4d49-a479-57ffdfdf60b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e6694de7-d587-4d49-a479-57ffdfdf60b0_0">
											<gml:posList>35.67383635507718 139.73850939864928 41.391 35.67385160050093 139.73850203453614 41.391 35.67385160050093 139.73850203453614 38.776 35.67383635507718 139.73850939864928 38.776 35.67383635507718 139.73850939864928 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b94d865-cb98-4946-88c5-6d434968f0f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7b94d865-cb98-4946-88c5-6d434968f0f0_0">
											<gml:posList>35.673843038578354 139.73841193643563 41.391 35.6738465535003 139.73842282435638 41.391 35.6738465535003 139.73842282435638 38.776 35.673843038578354 139.73841193643563 38.776 35.673843038578354 139.73841193643563 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e4829c7-ddd4-4b39-a353-4134b31841a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3e4829c7-ddd4-4b39-a353-4134b31841a6_0">
											<gml:posList>35.67385268073336 139.73844303263226 41.391 35.67383743531323 139.73845039675672 41.391 35.67383743531323 139.73845039675672 38.776 35.67385268073336 139.73844303263226 38.776 35.67385268073336 139.73844303263226 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-883d0899-d034-4379-8ad3-e42938ca301c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-883d0899-d034-4379-8ad3-e42938ca301c_0">
											<gml:posList>35.67385160050093 139.73850203453614 41.391 35.67383635507718 139.73850939864928 41.391 35.673839860985304 139.73852029763077 41.391 35.6738550973873 139.7385129224833 41.391 35.67385160050093 139.73850203453614 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0b59106-5e50-40b5-9ff8-928f0f4723d5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0b59106-5e50-40b5-9ff8-928f0f4723d5_0">
											<gml:posList>35.6738550973873 139.7385129224833 41.391 35.673839860985304 139.73852029763077 41.391 35.673839860985304 139.73852029763077 38.776 35.6738550973873 139.7385129224833 38.776 35.6738550973873 139.7385129224833 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b34470e-5167-48ae-8ff8-d9e6bc8b5f88">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b34470e-5167-48ae-8ff8-d9e6bc8b5f88_0">
											<gml:posList>35.673840859119686 139.73846004755177 41.391 35.673856104540405 139.73845268342882 41.391 35.673856104540405 139.73845268342882 38.776 35.673840859119686 139.73846004755177 38.776 35.673840859119686 139.73846004755177 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43006770-705d-41b2-ba43-dce05b5b9f03">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-43006770-705d-41b2-ba43-dce05b5b9f03_0">
											<gml:posList>35.673856104540405 139.73845268342882 41.391 35.673840859119686 139.73846004755177 41.391 35.673844365023584 139.738470935485 41.391 35.67385961044496 139.73846357136375 41.391 35.673856104540405 139.73845268342882 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-56ceec93-72f6-4ac3-9d0e-8d05929c4444">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-56ceec93-72f6-4ac3-9d0e-8d05929c4444_0">
											<gml:posList>35.673849174826955 139.73843214469915 41.391 35.67385268073336 139.73844303263226 41.391 35.67385268073336 139.73844303263226 38.776 35.673849174826955 139.73843214469915 38.776 35.673849174826955 139.73843214469915 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9619766-5495-4544-8d13-6489679db520">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b9619766-5495-4544-8d13-6489679db520_0">
											<gml:posList>35.67385961044496 139.73846357136375 41.391 35.673844365023584 139.738470935485 41.391 35.673844365023584 139.738470935485 38.776 35.67385961044496 139.73846357136375 38.776 35.67385961044496 139.73846357136375 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00420a27-85b6-419d-bc6e-6efa205871a4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-00420a27-85b6-419d-bc6e-6efa205871a4_0">
											<gml:posList>35.67385160050093 139.73850203453614 41.391 35.6738550973873 139.7385129224833 41.391 35.6738550973873 139.7385129224833 38.776 35.67385160050093 139.73850203453614 38.776 35.67385160050093 139.73850203453614 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f4eba58-3232-45fd-8923-ac76dea34ec3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f4eba58-3232-45fd-8923-ac76dea34ec3_0">
											<gml:posList>35.673847887813935 139.73848037627658 41.391 35.67386313322717 139.73847300111015 41.391 35.67386313322717 139.73847300111015 38.776 35.673847887813935 139.73848037627658 38.776 35.673847887813935 139.73848037627658 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd5ec55b-a7fd-46eb-8100-05dd57ca7f22">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dd5ec55b-a7fd-46eb-8100-05dd57ca7f22_0">
											<gml:posList>35.67385788209519 139.73851224533854 41.391 35.673854376195045 139.7385013574017 41.391 35.673854376195045 139.7385013574017 38.776 35.67385788209519 139.73851224533854 38.776 35.67385788209519 139.73851224533854 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b267c875-6a9f-4864-9468-07cdeae224a0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b267c875-6a9f-4864-9468-07cdeae224a0_0">
											<gml:posList>35.67386313322717 139.73847300111015 41.391 35.673847887813935 139.73848037627658 41.391 35.673851393715985 139.73849126421166 41.391 35.67386663913859 139.73848390009366 41.391 35.67386313322717 139.73847300111015 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1ab8403a-7ae1-4353-aaab-bcb9d6aab41b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1ab8403a-7ae1-4353-aaab-bcb9d6aab41b_0">
											<gml:posList>35.673856104540405 139.73845268342882 41.391 35.67385961044496 139.73846357136375 41.391 35.67385961044496 139.73846357136375 38.776 35.673856104540405 139.73845268342882 38.776 35.673856104540405 139.73845268342882 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7abe26ba-2891-40be-9597-40c0238e9ce6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7abe26ba-2891-40be-9597-40c0238e9ce6_0">
											<gml:posList>35.67386663913859 139.73848390009366 41.391 35.673851393715985 139.73849126421166 41.391 35.673851393715985 139.73849126421166 38.776 35.67386663913859 139.73848390009366 38.776 35.67386663913859 139.73848390009366 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fde557a1-1016-46df-ac5e-298637efb27e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fde557a1-1016-46df-ac5e-298637efb27e_0">
											<gml:posList>35.673854376195045 139.7385013574017 41.391 35.673869612595844 139.73849398224928 41.391 35.673869612595844 139.73849398224928 38.776 35.673854376195045 139.7385013574017 38.776 35.673854376195045 139.7385013574017 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8d55b2e-cef1-41a0-8d99-aa5da25bbb91">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b8d55b2e-cef1-41a0-8d99-aa5da25bbb91_0">
											<gml:posList>35.673854376195045 139.7385013574017 41.391 35.67385788209519 139.73851224533854 41.391 35.673873118496644 139.73850487018788 41.391 35.673869612595844 139.73849398224928 41.391 35.673854376195045 139.7385013574017 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca085e59-b6d7-4ebf-8274-03a1691469fa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ca085e59-b6d7-4ebf-8274-03a1691469fa_0">
											<gml:posList>35.67386313322717 139.73847300111015 41.391 35.67386663913859 139.73848390009366 41.391 35.67386663913859 139.73848390009366 38.776 35.67386313322717 139.73847300111015 38.776 35.67386313322717 139.73847300111015 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c338904e-7103-4c43-aabc-497acda5fa65">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c338904e-7103-4c43-aabc-497acda5fa65_0">
											<gml:posList>35.673873118496644 139.73850487018788 41.391 35.67385788209519 139.73851224533854 41.391 35.67385788209519 139.73851224533854 38.776 35.673873118496644 139.73850487018788 38.776 35.673873118496644 139.73850487018788 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9bccaad3-6994-4442-a472-65b364bd6e1f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9bccaad3-6994-4442-a472-65b364bd6e1f_0">
											<gml:posList>35.673869612595844 139.73849398224928 41.391 35.673873118496644 139.73850487018788 41.391 35.673873118496644 139.73850487018788 38.776 35.673869612595844 139.73849398224928 38.776 35.673869612595844 139.73849398224928 41.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44e2d6b7-0e6e-482f-b332-2eb97c5150e5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-44e2d6b7-0e6e-482f-b332-2eb97c5150e5_0">
											<gml:posList>35.67363332191471 139.73868251977305 40.439 35.673626429052 139.73868587506325 40.439 35.673626429052 139.73868587506325 38.776 35.67363332191471 139.73868251977305 38.776 35.67363332191471 139.73868251977305 40.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_8aa4a2ae-a597-45da-beec-761b68d98bd3_BuildingInstallation_1051">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c6828a4a-cde7-412f-b800-b76917da9a57">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673650894775264 139.73862023976847 38.776 35.6738367494817 139.73857530300683 38.776 35.673837039311586 139.73857707014196 38.776 35.67382725541338 139.7385834335785 38.776 35.67365180057841 139.73862587252043 38.776 35.673650894775264 139.73862023976847 38.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc19fee2-5178-488a-b387-3dcd5a539e07">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67383765527825 139.7385809247246 39.886 35.67382725541338 139.7385834335785 39.886 35.673837039311586 139.73857707014196 39.886 35.67383765527825 139.7385809247246 39.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1047f841-4776-409f-ab0e-60aa8f3a2fa6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1047f841-4776-409f-ab0e-60aa8f3a2fa6_0">
											<gml:posList>35.673650894775264 139.73862023976847 50.395 35.673650894775264 139.73862023976847 38.776 35.67365180057841 139.73862587252043 38.776 35.67365180057841 139.73862587252043 50.395 35.673650894775264 139.73862023976847 50.395</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9adfc56f-caaf-4154-a177-fbba8b2cc4e5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9adfc56f-caaf-4154-a177-fbba8b2cc4e5_0">
											<gml:posList>35.6738367494817 139.73857530300683 50.395 35.6738367494817 139.73857530300683 38.776 35.673650894775264 139.73862023976847 38.776 35.673650894775264 139.73862023976847 50.395 35.6738367494817 139.73857530300683 50.395</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b58a4fd-9301-4575-b956-af85ea03cdd0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1b58a4fd-9301-4575-b956-af85ea03cdd0_0">
											<gml:posList>35.67383765527825 139.7385809247246 50.395 35.6738367494817 139.73857530300683 50.395 35.673650894775264 139.73862023976847 50.395 35.67365180057841 139.73862587252043 50.395 35.67383765527825 139.7385809247246 50.395</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c78cf589-e964-4e4b-b16c-3c03effea24e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c78cf589-e964-4e4b-b16c-3c03effea24e_0">
											<gml:posList>35.67382725541338 139.7385834335785 39.886 35.67383765527825 139.7385809247246 39.886 35.67383765527825 139.7385809247246 50.395 35.67365180057841 139.73862587252043 50.395 35.67365180057841 139.73862587252043 38.776 35.67382725541338 139.7385834335785 38.776 35.67382725541338 139.7385834335785 39.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a87fdd9-c472-4684-a953-6aae5fbec318">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9a87fdd9-c472-4684-a953-6aae5fbec318_0">
											<gml:posList>35.67382725541338 139.7385834335785 38.776 35.673837039311586 139.73857707014196 38.776 35.673837039311586 139.73857707014196 39.886 35.67382725541338 139.7385834335785 39.886 35.67382725541338 139.7385834335785 38.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-89008b59-b15f-4cf4-bf9f-05ec05a6099e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-89008b59-b15f-4cf4-bf9f-05ec05a6099e_0">
											<gml:posList>35.673837039311586 139.73857707014196 39.886 35.673837039311586 139.73857707014196 38.776 35.6738367494817 139.73857530300683 38.776 35.6738367494817 139.73857530300683 50.395 35.67383765527825 139.7385809247246 50.395 35.67383765527825 139.7385809247246 39.886 35.673837039311586 139.73857707014196 39.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-1d46261e-2ae8-462c-9349-bdce7a1ab55d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d46261e-2ae8-462c-9349-bdce7a1ab55d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d46261e-2ae8-462c-9349-bdce7a1ab55d">
											<gml:posList>35.673902595283764 139.73854163202643 7.689 35.673623222748915 139.73872357020988 7.689 35.673596839825684 139.73864362321967 7.689 35.67353575062033 139.73867396331622 7.689 35.6735153309705 139.73861212595605 7.689 35.673555336319346 139.7385923051013 7.689 35.67357347443945 139.7385840317817 7.689 35.67355948714815 139.7385407783997 7.689 35.67385497915776 139.73839719699572 7.689 35.673902595283764 139.73854163202643 7.689</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-076de7ef-fb41-4df4-875a-961d9d0bb247">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-076de7ef-fb41-4df4-875a-961d9d0bb247">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-076de7ef-fb41-4df4-875a-961d9d0bb247">
											<gml:posList>35.6735153309705 139.73861212595605 39.886 35.67353575062033 139.73867396331622 39.886 35.67353863746667 139.73866561965323 39.886 35.67352213910799 139.7386156528535 39.886 35.6735153309705 139.73861212595605 39.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8fe8c77f-dfb5-474f-b606-533ab0026d49">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8fe8c77f-dfb5-474f-b606-533ab0026d49">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8fe8c77f-dfb5-474f-b606-533ab0026d49">
											<gml:posList>35.673555336319346 139.7385923051013 39.886 35.6735153309705 139.73861212595605 39.886 35.67352213910799 139.7386156528535 39.886 35.673557296963416 139.73859823486055 39.886 35.673555336319346 139.7385923051013 39.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-af5949eb-6840-4352-aa70-db306b41e182">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af5949eb-6840-4352-aa70-db306b41e182">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af5949eb-6840-4352-aa70-db306b41e182">
											<gml:posList>35.673596839825684 139.73864362321967 39.886 35.673599726661195 139.73863526850255 39.886 35.67353863746667 139.73866561965323 39.886 35.67353575062033 139.73867396331622 39.886 35.673596839825684 139.73864362321967 39.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-94e6170a-f1be-4d28-9dca-fa251b4067be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-94e6170a-f1be-4d28-9dca-fa251b4067be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-94e6170a-f1be-4d28-9dca-fa251b4067be">
											<gml:posList>35.67357347443945 139.7385840317817 39.886 35.673555336319346 139.7385923051013 39.886 35.673557296963416 139.73859823486055 39.886 35.673580300761586 139.73858775749844 39.886 35.67357347443945 139.7385840317817 39.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-632e24b5-21ec-4711-9367-bc800ff16d1b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-632e24b5-21ec-4711-9367-bc800ff16d1b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-632e24b5-21ec-4711-9367-bc800ff16d1b">
											<gml:posList>35.67357347443945 139.7385840317817 39.886 35.673580300761586 139.73858775749844 39.886 35.67356626829868 139.73854437160512 39.886 35.67355948714815 139.7385407783997 39.886 35.67357347443945 139.7385840317817 39.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b39075e6-15f6-4f1a-ac6a-65f49734bb40">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b39075e6-15f6-4f1a-ac6a-65f49734bb40">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b39075e6-15f6-4f1a-ac6a-65f49734bb40">
											<gml:posList>35.67362589274859 139.7387145639931 39.886 35.673599726661195 139.73863526850255 39.886 35.673596839825684 139.73864362321967 39.886 35.673623222748915 139.73872357020988 39.886 35.67362589274859 139.7387145639931 39.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-779939be-5da3-48be-b1f2-69423455491a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-779939be-5da3-48be-b1f2-69423455491a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-779939be-5da3-48be-b1f2-69423455491a">
											<gml:posList>35.67371196418219 139.73859912362042 38.776 35.67368988424836 139.73853510085715 38.776 35.673580300761586 139.73858775749844 38.776 35.673557296963416 139.73859823486055 38.776 35.67352213910799 139.7386156528535 38.776 35.67353863746667 139.73866561965323 38.776 35.673599726661195 139.73863526850255 38.776 35.67362589274859 139.7387145639931 38.776 35.67371196418219 139.73859912362042 38.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3e0770af-2056-432b-8c65-490b197a7c03">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e0770af-2056-432b-8c65-490b197a7c03">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e0770af-2056-432b-8c65-490b197a7c03">
											<gml:posList>35.67368988424836 139.73853510085715 38.776 35.673694091949656 139.73853293072523 38.776 35.67368031454861 139.73849296895958 38.776 35.67356626829868 139.73854437160512 38.776 35.673580300761586 139.73858775749844 38.776 35.67368988424836 139.73853510085715 38.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6755ca96-41b1-480e-befd-8d5a60cdbc44">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6755ca96-41b1-480e-befd-8d5a60cdbc44">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6755ca96-41b1-480e-befd-8d5a60cdbc44">
											<gml:posList>35.673694091949656 139.73853293072523 42.656 35.67372892480234 139.73851488337976 42.656 35.6737255369333 139.73850507789928 42.656 35.67371278770844 139.73851167682417 42.656 35.67370238916713 139.73848153158607 42.656 35.67368031454861 139.73849296895958 42.656 35.673694091949656 139.73853293072523 42.656</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1c556ed2-3075-483c-b873-c225d6267570">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c556ed2-3075-483c-b873-c225d6267570">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c556ed2-3075-483c-b873-c225d6267570">
											<gml:posList>35.67385497915776 139.73839719699572 39.886 35.67355948714815 139.7385407783997 39.886 35.67356626829868 139.73854437160512 39.886 35.673852065254245 139.7384054965464 39.886 35.67385497915776 139.73839719699572 39.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f27d44e7-096a-42b1-814b-c82c9ac89aa4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f27d44e7-096a-42b1-814b-c82c9ac89aa4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f27d44e7-096a-42b1-814b-c82c9ac89aa4">
											<gml:posList>35.67356626829868 139.73854437160512 38.776 35.67368031454861 139.73849296895958 38.776 35.67370238916713 139.73848153158607 38.776 35.67371278770844 139.73851167682417 38.776 35.6737255369333 139.73850507789928 38.776 35.67372892480234 139.73851488337976 38.776 35.67373314150826 139.73851270218836 38.776 35.673852065254245 139.7384054965464 38.776 35.67356626829868 139.73854437160512 38.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f5223bf5-7f98-447e-b478-824b835003f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f5223bf5-7f98-447e-b478-824b835003f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f5223bf5-7f98-447e-b478-824b835003f2">
											<gml:posList>35.67368988424836 139.73853510085715 44.617 35.67371196418219 139.73859912362042 44.617 35.67375521244015 139.73857672499062 44.617 35.67373314150826 139.73851270218836 44.617 35.67368988424836 139.73853510085715 44.617</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ceca5d46-414b-468b-aa4f-dc2f4482ea29">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ceca5d46-414b-468b-aa4f-dc2f4482ea29">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ceca5d46-414b-468b-aa4f-dc2f4482ea29">
											<gml:posList>35.67371196418219 139.73859912362042 38.776 35.67362589274859 139.7387145639931 38.776 35.67389597689352 139.73853869037163 38.776 35.67375521244015 139.73857672499062 38.776 35.67371196418219 139.73859912362042 38.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b457f63e-5e74-4f80-adb9-52fe1636e79a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b457f63e-5e74-4f80-adb9-52fe1636e79a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b457f63e-5e74-4f80-adb9-52fe1636e79a">
											<gml:posList>35.67389597689352 139.73853869037163 39.886 35.67362589274859 139.7387145639931 39.886 35.673623222748915 139.73872357020988 39.886 35.673902595283764 139.73854163202643 39.886 35.67389597689352 139.73853869037163 39.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-961fe5d2-e7a1-494a-8557-3e002ae10c6a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-961fe5d2-e7a1-494a-8557-3e002ae10c6a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-961fe5d2-e7a1-494a-8557-3e002ae10c6a">
											<gml:posList>35.67375521244015 139.73857672499062 38.776 35.67389597689352 139.73853869037163 38.776 35.673852065254245 139.7384054965464 38.776 35.67373314150826 139.73851270218836 38.776 35.67375521244015 139.73857672499062 38.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f7cef137-f3c1-40c2-9088-a28aa34ca196">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f7cef137-f3c1-40c2-9088-a28aa34ca196">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f7cef137-f3c1-40c2-9088-a28aa34ca196">
											<gml:posList>35.673902595283764 139.73854163202643 39.886 35.67385497915776 139.73839719699572 39.886 35.673852065254245 139.7384054965464 39.886 35.67389597689352 139.73853869037163 39.886 35.673902595283764 139.73854163202643 39.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c32f7c3d-c498-4da7-a0f1-38bb02a67d1d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c32f7c3d-c498-4da7-a0f1-38bb02a67d1d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c32f7c3d-c498-4da7-a0f1-38bb02a67d1d">
											<gml:posList>35.67356626829868 139.73854437160512 39.886 35.67356626829868 139.73854437160512 38.776 35.673852065254245 139.7384054965464 38.776 35.673852065254245 139.7384054965464 39.886 35.67356626829868 139.73854437160512 39.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cc7bbd80-ebc1-4911-9e61-61da6e0d9757">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc7bbd80-ebc1-4911-9e61-61da6e0d9757">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc7bbd80-ebc1-4911-9e61-61da6e0d9757">
											<gml:posList>35.67385497915776 139.73839719699572 7.689 35.67355948714815 139.7385407783997 7.689 35.67355948714815 139.7385407783997 39.886 35.67385497915776 139.73839719699572 39.886 35.67385497915776 139.73839719699572 7.689</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-36f9bdca-cc98-4395-96fb-df03a15384cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36f9bdca-cc98-4395-96fb-df03a15384cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36f9bdca-cc98-4395-96fb-df03a15384cf">
											<gml:posList>35.673902595283764 139.73854163202643 7.689 35.67385497915776 139.73839719699572 7.689 35.67385497915776 139.73839719699572 39.886 35.673902595283764 139.73854163202643 39.886 35.673902595283764 139.73854163202643 7.689</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-11589c5d-fc0d-4886-af0b-1e962cf9d0eb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11589c5d-fc0d-4886-af0b-1e962cf9d0eb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11589c5d-fc0d-4886-af0b-1e962cf9d0eb">
											<gml:posList>35.673852065254245 139.7384054965464 39.886 35.673852065254245 139.7384054965464 38.776 35.67389597689352 139.73853869037163 38.776 35.67389597689352 139.73853869037163 39.886 35.673852065254245 139.7384054965464 39.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-384db635-20af-4686-ae81-6b3d5076087a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-384db635-20af-4686-ae81-6b3d5076087a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-384db635-20af-4686-ae81-6b3d5076087a">
											<gml:posList>35.67370238916713 139.73848153158607 42.656 35.67370238916713 139.73848153158607 38.776 35.67368031454861 139.73849296895958 38.776 35.67368031454861 139.73849296895958 42.656 35.67370238916713 139.73848153158607 42.656</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e04ecee7-c773-43db-b158-f14274e2cc38">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e04ecee7-c773-43db-b158-f14274e2cc38">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e04ecee7-c773-43db-b158-f14274e2cc38">
											<gml:posList>35.67371278770844 139.73851167682417 42.656 35.67371278770844 139.73851167682417 38.776 35.67370238916713 139.73848153158607 38.776 35.67370238916713 139.73848153158607 42.656 35.67371278770844 139.73851167682417 42.656</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-837ffc56-eecd-4418-92df-bab8b0c27b7b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-837ffc56-eecd-4418-92df-bab8b0c27b7b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-837ffc56-eecd-4418-92df-bab8b0c27b7b">
											<gml:posList>35.6737255369333 139.73850507789928 42.656 35.6737255369333 139.73850507789928 38.776 35.67371278770844 139.73851167682417 38.776 35.67371278770844 139.73851167682417 42.656 35.6737255369333 139.73850507789928 42.656</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-54514f25-6d91-4a37-9907-253d29266273">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-54514f25-6d91-4a37-9907-253d29266273">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-54514f25-6d91-4a37-9907-253d29266273">
											<gml:posList>35.67372892480234 139.73851488337976 42.656 35.67372892480234 139.73851488337976 38.776 35.6737255369333 139.73850507789928 38.776 35.6737255369333 139.73850507789928 42.656 35.67372892480234 139.73851488337976 42.656</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-27bf9109-ad4b-49e8-a895-730fb7623573">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-27bf9109-ad4b-49e8-a895-730fb7623573">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-27bf9109-ad4b-49e8-a895-730fb7623573">
											<gml:posList>35.67368031454861 139.73849296895958 42.656 35.67368031454861 139.73849296895958 38.776 35.673694091949656 139.73853293072523 38.776 35.673694091949656 139.73853293072523 42.656 35.67368031454861 139.73849296895958 42.656</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-069c1d1a-c9c7-4e13-b710-3fafd12ef6cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-069c1d1a-c9c7-4e13-b710-3fafd12ef6cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-069c1d1a-c9c7-4e13-b710-3fafd12ef6cd">
											<gml:posList>35.67373314150826 139.73851270218836 38.776 35.67372892480234 139.73851488337976 38.776 35.67372892480234 139.73851488337976 42.656 35.673694091949656 139.73853293072523 42.656 35.673694091949656 139.73853293072523 38.776 35.67368988424836 139.73853510085715 38.776 35.67368988424836 139.73853510085715 44.617 35.67373314150826 139.73851270218836 44.617 35.67373314150826 139.73851270218836 38.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a9c10bdf-b47c-416b-9ed2-4d2e3b7dfb32">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9c10bdf-b47c-416b-9ed2-4d2e3b7dfb32">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9c10bdf-b47c-416b-9ed2-4d2e3b7dfb32">
											<gml:posList>35.67375521244015 139.73857672499062 38.776 35.67373314150826 139.73851270218836 38.776 35.67373314150826 139.73851270218836 44.617 35.67375521244015 139.73857672499062 44.617 35.67375521244015 139.73857672499062 38.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7cbec245-52e6-49eb-8ad9-4dae5094226d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7cbec245-52e6-49eb-8ad9-4dae5094226d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7cbec245-52e6-49eb-8ad9-4dae5094226d">
											<gml:posList>35.67355948714815 139.7385407783997 7.689 35.67357347443945 139.7385840317817 7.689 35.67357347443945 139.7385840317817 39.886 35.67355948714815 139.7385407783997 39.886 35.67355948714815 139.7385407783997 7.689</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b5af5645-fdcb-4dcd-8f69-03cbc08bcdca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b5af5645-fdcb-4dcd-8f69-03cbc08bcdca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b5af5645-fdcb-4dcd-8f69-03cbc08bcdca">
											<gml:posList>35.673580300761586 139.73858775749844 39.886 35.673580300761586 139.73858775749844 38.776 35.67356626829868 139.73854437160512 38.776 35.67356626829868 139.73854437160512 39.886 35.673580300761586 139.73858775749844 39.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cc8820a2-2b74-4c7c-975b-41b3dab6bd8d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc8820a2-2b74-4c7c-975b-41b3dab6bd8d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc8820a2-2b74-4c7c-975b-41b3dab6bd8d">
											<gml:posList>35.67368988424836 139.73853510085715 44.617 35.67368988424836 139.73853510085715 38.776 35.67371196418219 139.73859912362042 38.776 35.67371196418219 139.73859912362042 44.617 35.67368988424836 139.73853510085715 44.617</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7c55341e-3a2d-4651-9a28-d54de0b53af3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c55341e-3a2d-4651-9a28-d54de0b53af3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c55341e-3a2d-4651-9a28-d54de0b53af3">
											<gml:posList>35.67371196418219 139.73859912362042 44.617 35.67371196418219 139.73859912362042 38.776 35.67375521244015 139.73857672499062 38.776 35.67375521244015 139.73857672499062 44.617 35.67371196418219 139.73859912362042 44.617</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7c554bbf-2bab-4f38-bdd4-2b5e34ab233f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c554bbf-2bab-4f38-bdd4-2b5e34ab233f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c554bbf-2bab-4f38-bdd4-2b5e34ab233f">
											<gml:posList>35.67357347443945 139.7385840317817 7.689 35.673555336319346 139.7385923051013 7.689 35.673555336319346 139.7385923051013 39.886 35.67357347443945 139.7385840317817 39.886 35.67357347443945 139.7385840317817 7.689</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6b45b8b8-8265-4f0e-b150-e396cb525823">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b45b8b8-8265-4f0e-b150-e396cb525823">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b45b8b8-8265-4f0e-b150-e396cb525823">
											<gml:posList>35.673557296963416 139.73859823486055 39.886 35.673557296963416 139.73859823486055 38.776 35.673580300761586 139.73858775749844 38.776 35.673580300761586 139.73858775749844 39.886 35.673557296963416 139.73859823486055 39.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-48e7526a-9736-4055-9b44-ecb4c36c0def">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-48e7526a-9736-4055-9b44-ecb4c36c0def">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-48e7526a-9736-4055-9b44-ecb4c36c0def">
											<gml:posList>35.673555336319346 139.7385923051013 7.689 35.6735153309705 139.73861212595605 7.689 35.6735153309705 139.73861212595605 39.886 35.673555336319346 139.7385923051013 39.886 35.673555336319346 139.7385923051013 7.689</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6b02d319-36b5-430d-8f6a-bc6bfffefd96">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b02d319-36b5-430d-8f6a-bc6bfffefd96">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b02d319-36b5-430d-8f6a-bc6bfffefd96">
											<gml:posList>35.67352213910799 139.7386156528535 39.886 35.67352213910799 139.7386156528535 38.776 35.673557296963416 139.73859823486055 38.776 35.673557296963416 139.73859823486055 39.886 35.67352213910799 139.7386156528535 39.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-02640a3d-1202-45a9-bee3-6cc192a61df6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-02640a3d-1202-45a9-bee3-6cc192a61df6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-02640a3d-1202-45a9-bee3-6cc192a61df6">
											<gml:posList>35.67362589274859 139.7387145639931 38.776 35.67362589274859 139.7387145639931 39.886 35.67389597689352 139.73853869037163 39.886 35.67389597689352 139.73853869037163 38.776 35.67362589274859 139.7387145639931 38.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-61019ae6-ead5-411c-8bd5-e5cdd0bb8a37">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61019ae6-ead5-411c-8bd5-e5cdd0bb8a37">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61019ae6-ead5-411c-8bd5-e5cdd0bb8a37">
											<gml:posList>35.673623222748915 139.73872357020988 7.689 35.673902595283764 139.73854163202643 7.689 35.673902595283764 139.73854163202643 39.886 35.673623222748915 139.73872357020988 39.886 35.673623222748915 139.73872357020988 7.689</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7eca84fd-104c-4e9b-992d-a9912e6db5b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7eca84fd-104c-4e9b-992d-a9912e6db5b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7eca84fd-104c-4e9b-992d-a9912e6db5b8">
											<gml:posList>35.67352213910799 139.7386156528535 38.776 35.67352213910799 139.7386156528535 39.886 35.67353863746667 139.73866561965323 39.886 35.67353863746667 139.73866561965323 38.776 35.67352213910799 139.7386156528535 38.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-963bf567-e631-40d9-893e-42f937e62d68">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-963bf567-e631-40d9-893e-42f937e62d68">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-963bf567-e631-40d9-893e-42f937e62d68">
											<gml:posList>35.6735153309705 139.73861212595605 7.689 35.67353575062033 139.73867396331622 7.689 35.67353575062033 139.73867396331622 39.886 35.6735153309705 139.73861212595605 39.886 35.6735153309705 139.73861212595605 7.689</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8af4cb4b-359a-47b2-b74a-51d27e997504">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8af4cb4b-359a-47b2-b74a-51d27e997504">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8af4cb4b-359a-47b2-b74a-51d27e997504">
											<gml:posList>35.673599726661195 139.73863526850255 39.886 35.673599726661195 139.73863526850255 38.776 35.67353863746667 139.73866561965323 38.776 35.67353863746667 139.73866561965323 39.886 35.673599726661195 139.73863526850255 39.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a5f1d596-1ea6-40e4-9928-e967b686a0e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5f1d596-1ea6-40e4-9928-e967b686a0e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5f1d596-1ea6-40e4-9928-e967b686a0e6">
											<gml:posList>35.67353575062033 139.73867396331622 7.689 35.673596839825684 139.73864362321967 7.689 35.673596839825684 139.73864362321967 39.886 35.67353575062033 139.73867396331622 39.886 35.67353575062033 139.73867396331622 7.689</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-676352f7-d1f4-477d-a846-efc62be9e060">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-676352f7-d1f4-477d-a846-efc62be9e060">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-676352f7-d1f4-477d-a846-efc62be9e060">
											<gml:posList>35.673599726661195 139.73863526850255 38.776 35.673599726661195 139.73863526850255 39.886 35.67362589274859 139.7387145639931 39.886 35.67362589274859 139.7387145639931 38.776 35.673599726661195 139.73863526850255 38.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9b60a484-6348-4270-91c0-e0117f6f4de0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b60a484-6348-4270-91c0-e0117f6f4de0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b60a484-6348-4270-91c0-e0117f6f4de0">
											<gml:posList>35.673596839825684 139.73864362321967 7.689 35.673623222748915 139.73872357020988 7.689 35.673623222748915 139.73872357020988 39.886 35.673596839825684 139.73864362321967 39.886 35.673596839825684 139.73864362321967 7.689</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4203</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">614.941</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.37</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>