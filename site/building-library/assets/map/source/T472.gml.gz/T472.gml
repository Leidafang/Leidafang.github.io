<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_8ad206dc-103d-46b6-aae4-9f410def7b42">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>8</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13101008003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">36.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67185194709694 139.74576943722707 0 35.67193760232648 139.74592763965586 0 35.67197895092781 139.745894013277 0 35.67192851848947 139.74570716195223 0 35.67185194709694 139.74576943722707 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67185194709694 139.74576943722707 7.84 35.67192851848947 139.74570716195223 7.84 35.67197895092781 139.745894013277 7.84 35.67193760232648 139.74592763965586 7.84 35.67185194709694 139.74576943722707 7.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67185194709694 139.74576943722707 7.84 35.67193760232648 139.74592763965586 7.84 35.67193760232648 139.74592763965586 44.71000000000001 35.67185194709694 139.74576943722707 44.71000000000001 35.67185194709694 139.74576943722707 7.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67193760232648 139.74592763965586 7.84 35.67197895092781 139.745894013277 7.84 35.67197895092781 139.745894013277 44.71000000000001 35.67193760232648 139.74592763965586 44.71000000000001 35.67193760232648 139.74592763965586 7.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67197895092781 139.745894013277 7.84 35.67192851848947 139.74570716195223 7.84 35.67192851848947 139.74570716195223 44.71000000000001 35.67197895092781 139.745894013277 44.71000000000001 35.67197895092781 139.745894013277 7.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67192851848947 139.74570716195223 7.84 35.67185194709694 139.74576943722707 7.84 35.67185194709694 139.74576943722707 44.71000000000001 35.67192851848947 139.74570716195223 44.71000000000001 35.67192851848947 139.74570716195223 7.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67185194709694 139.74576943722707 44.71000000000001 35.67193760232648 139.74592763965586 44.71000000000001 35.67197895092781 139.745894013277 44.71000000000001 35.67192851848947 139.74570716195223 44.71000000000001 35.67185194709694 139.74576943722707 44.71000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-143205f5-5d03-4fcf-8177-14abd43295b7"/>
							<gml:surfaceMember xlink:href="#poly-24d4f2d1-9b76-47c1-a052-50f3c0ca689f"/>
							<gml:surfaceMember xlink:href="#poly-043b8ae1-db70-40f7-b6fe-101fcec5c02f"/>
							<gml:surfaceMember xlink:href="#poly-976f9b8a-c83b-431c-b9cf-b62d9c2ec8a2"/>
							<gml:surfaceMember xlink:href="#poly-d803adda-47ef-4222-941b-5995a0598a9f"/>
							<gml:surfaceMember xlink:href="#poly-f408cbfc-4100-43d3-a727-48a6d3b16a05"/>
							<gml:surfaceMember xlink:href="#poly-16a5140b-46a9-485a-9957-f32e7d120d80"/>
							<gml:surfaceMember xlink:href="#poly-8edb9f94-f7ae-4840-a7a5-323404100196"/>
							<gml:surfaceMember xlink:href="#poly-c750b0da-996f-485f-aa3c-cf44929c7a3c"/>
							<gml:surfaceMember xlink:href="#poly-7bdf5efe-77ad-4dec-bbd3-33f9a726c85e"/>
							<gml:surfaceMember xlink:href="#poly-e6ac2b4a-f13b-432d-a1d8-dfde7f300c2e"/>
							<gml:surfaceMember xlink:href="#poly-b4e64902-d9d3-4be3-ae4e-bb4e9162c743"/>
							<gml:surfaceMember xlink:href="#poly-9ab7bb3d-9e6b-4819-a5df-716b213d4554"/>
							<gml:surfaceMember xlink:href="#poly-a36fb01c-e72b-4ae3-ab99-257240251665"/>
							<gml:surfaceMember xlink:href="#poly-dd2032d3-3d99-49cb-82af-7aa3dd017b6b"/>
							<gml:surfaceMember xlink:href="#poly-24fd75bc-ef64-46f2-b2e5-dfd0682b220b"/>
							<gml:surfaceMember xlink:href="#poly-5edef2e6-8dca-4d97-917e-46b203aa79f2"/>
							<gml:surfaceMember xlink:href="#poly-d955aeda-db33-44d7-a5f9-2a7c24eeee32"/>
							<gml:surfaceMember xlink:href="#poly-c8826af2-a6a2-4ef7-839f-a800584c4a7d"/>
							<gml:surfaceMember xlink:href="#poly-8b2d6b48-bd2a-485f-a60e-1b78b8bb7aca"/>
							<gml:surfaceMember xlink:href="#poly-3a623fb0-173f-49da-9d17-95fa8a131053"/>
							<gml:surfaceMember xlink:href="#poly-96c392ee-72e5-44bd-b9f8-eb28bab4ccd5"/>
							<gml:surfaceMember xlink:href="#poly-1c14f043-11d0-433e-9ece-06fc96dea271"/>
							<gml:surfaceMember xlink:href="#poly-67cd0548-0bb3-475e-bb15-6dc19b28b08f"/>
							<gml:surfaceMember xlink:href="#poly-86c0a341-28ae-4ed5-9946-8666cc022983"/>
							<gml:surfaceMember xlink:href="#poly-8cb18348-eb4e-499c-b003-1ff5889a102b"/>
							<gml:surfaceMember xlink:href="#poly-c6a32468-768c-4249-bd88-52aaa131544f"/>
							<gml:surfaceMember xlink:href="#poly-d6fd3a78-ca00-4f04-a959-6f16ae92fcfe"/>
							<gml:surfaceMember xlink:href="#poly-120ccbb4-7417-4b9c-8c59-3ec126791330"/>
							<gml:surfaceMember xlink:href="#poly-8fd7f0cf-32d8-486b-a0d5-f56cd1054077"/>
							<gml:surfaceMember xlink:href="#poly-3f524b35-16f9-4c08-9482-61751011d6d5"/>
							<gml:surfaceMember xlink:href="#poly-31f7fa8f-9e55-4173-a5d8-cb667776cefa"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_8ad206dc-103d-46b6-aae4-9f410def7b42_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a508e46-a690-42f8-a119-1c225190a329">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67189725726784 139.74577929642263 45.043 35.6718913276377 139.74576883084634 45.043 35.67190063306028 139.74576091141088 45.043 35.671906562691106 139.7457713769878 45.043 35.67189725726784 139.74577929642263 45.043</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40ddae3a-4a8e-4c7e-bff1-759b86bbf3b7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67192456281221 139.74577097070218 45.043 35.67193785766216 139.74579521424016 45.043 35.671927164766636 139.74580401890796 45.043 35.67191386991843 139.74577977537177 45.043 35.67192456281221 139.74577097070218 45.043</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fd5d9fcf-4809-424c-a614-d3b72367d1e6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671906007070284 139.74582541692678 45.043 35.67190022111774 139.7458142000292 45.043 35.671913770135276 139.74580370213747 45.043 35.67191955608075 139.74581490798977 45.043 35.671906007070284 139.74582541692678 45.043</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-95cb70d2-de84-4784-aafa-dd27925c4b07">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67192389082403 139.7458261264741 45.043 35.671935110829516 139.7458480635719 45.043 35.671921021209535 139.74585887134998 45.043 35.67190981021973 139.74583693424466 45.043 35.67192389082403 139.7458261264741 45.043</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eb145217-1db8-4bd2-bf15-cc84b9307825">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eb145217-1db8-4bd2-bf15-cc84b9307825_0">
											<gml:posList>35.67190063306028 139.74576091141088 45.043 35.6718913276377 139.74576883084634 45.043 35.6718913276377 139.74576883084634 46.59 35.67190063306028 139.74576091141088 46.59 35.67190063306028 139.74576091141088 45.043</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a1aff06-3e23-427b-8880-980e1437a03c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1a1aff06-3e23-427b-8880-980e1437a03c_0">
											<gml:posList>35.67190063306028 139.74576091141088 45.043 35.67190063306028 139.74576091141088 46.59 35.671906562691106 139.7457713769878 46.59 35.671906562691106 139.7457713769878 45.043 35.67190063306028 139.74576091141088 45.043</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-709791a4-3b75-43fa-a579-49025008704f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-709791a4-3b75-43fa-a579-49025008704f_0">
											<gml:posList>35.67190063306028 139.74576091141088 46.59 35.6718913276377 139.74576883084634 46.59 35.67189725726784 139.74577929642263 46.59 35.671906562691106 139.7457713769878 46.59 35.67190063306028 139.74576091141088 46.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b98de67f-4eaf-4c63-b49c-02afad6b6be9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b98de67f-4eaf-4c63-b49c-02afad6b6be9_0">
											<gml:posList>35.6718913276377 139.74576883084634 45.043 35.67189725726784 139.74577929642263 45.043 35.67189725726784 139.74577929642263 46.59 35.6718913276377 139.74576883084634 46.59 35.6718913276377 139.74576883084634 45.043</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0dfb6996-a0be-4764-b071-3d5717139d97">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0dfb6996-a0be-4764-b071-3d5717139d97_0">
											<gml:posList>35.671906562691106 139.7457713769878 45.043 35.671906562691106 139.7457713769878 46.59 35.67189725726784 139.74577929642263 46.59 35.67189725726784 139.74577929642263 45.043 35.671906562691106 139.7457713769878 45.043</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c929bad-db50-452b-b393-5fdfd5d7fa91">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c929bad-db50-452b-b393-5fdfd5d7fa91_0">
											<gml:posList>35.67192456281221 139.74577097070218 45.043 35.67191386991843 139.74577977537177 45.043 35.67191386991843 139.74577977537177 45.926 35.67192456281221 139.74577097070218 45.926 35.67192456281221 139.74577097070218 45.043</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-878ed440-5c50-4aff-abd9-c5835c6b814a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-878ed440-5c50-4aff-abd9-c5835c6b814a_0">
											<gml:posList>35.67192456281221 139.74577097070218 45.043 35.67192456281221 139.74577097070218 45.926 35.67193785766216 139.74579521424016 45.926 35.67193785766216 139.74579521424016 45.043 35.67192456281221 139.74577097070218 45.043</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7010c7d6-8c06-40c6-8b2f-005348079e57">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7010c7d6-8c06-40c6-8b2f-005348079e57_0">
											<gml:posList>35.671906007070284 139.74582541692678 45.043 35.671906007070284 139.74582541692678 46.921 35.67190022111774 139.7458142000292 46.921 35.67190022111774 139.7458142000292 45.043 35.671906007070284 139.74582541692678 45.043</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94d92002-458a-4580-86d0-8812f55024e1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-94d92002-458a-4580-86d0-8812f55024e1_0">
											<gml:posList>35.671913770135276 139.74580370213747 45.043 35.67190022111774 139.7458142000292 45.043 35.67190022111774 139.7458142000292 46.921 35.671913770135276 139.74580370213747 46.921 35.671913770135276 139.74580370213747 45.043</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-425fc3e5-6a16-47ac-ad03-7938f43cd361">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-425fc3e5-6a16-47ac-ad03-7938f43cd361_0">
											<gml:posList>35.671913770135276 139.74580370213747 46.921 35.67190022111774 139.7458142000292 46.921 35.671906007070284 139.74582541692678 46.921 35.67191955608075 139.74581490798977 46.921 35.671913770135276 139.74580370213747 46.921</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0be374d4-ff4e-46a5-9fa9-5254eef47a03">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0be374d4-ff4e-46a5-9fa9-5254eef47a03_0">
											<gml:posList>35.67191955608075 139.74581490798977 45.043 35.67191955608075 139.74581490798977 46.921 35.671906007070284 139.74582541692678 46.921 35.671906007070284 139.74582541692678 45.043 35.67191955608075 139.74581490798977 45.043</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4fbf13b9-56e6-4efc-84a2-e9425bd6115b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4fbf13b9-56e6-4efc-84a2-e9425bd6115b_0">
											<gml:posList>35.671921021209535 139.74585887134998 45.043 35.671921021209535 139.74585887134998 46.921 35.67190981021973 139.74583693424466 46.921 35.67190981021973 139.74583693424466 45.043 35.671921021209535 139.74585887134998 45.043</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2e7e1374-d6ba-4ab6-a7c2-2e5a90af14e6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2e7e1374-d6ba-4ab6-a7c2-2e5a90af14e6_0">
											<gml:posList>35.67191955608075 139.74581490798977 45.043 35.671913770135276 139.74580370213747 45.043 35.671913770135276 139.74580370213747 46.921 35.67191955608075 139.74581490798977 46.921 35.67191955608075 139.74581490798977 45.043</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-08d550a3-7726-4e23-86e5-b5eba5340e98">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-08d550a3-7726-4e23-86e5-b5eba5340e98_0">
											<gml:posList>35.67192389082403 139.7458261264741 45.043 35.67190981021973 139.74583693424466 45.043 35.67190981021973 139.74583693424466 46.921 35.67192389082403 139.7458261264741 46.921 35.67192389082403 139.7458261264741 45.043</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4858617b-b1a8-40fb-be01-50587d4adbc0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4858617b-b1a8-40fb-be01-50587d4adbc0_0">
											<gml:posList>35.671927164766636 139.74580401890796 45.043 35.671927164766636 139.74580401890796 45.926 35.67191386991843 139.74577977537177 45.926 35.67191386991843 139.74577977537177 45.043 35.671927164766636 139.74580401890796 45.043</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fdbb8ec6-22d2-41cd-ac94-bdbb6c1716fc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fdbb8ec6-22d2-41cd-ac94-bdbb6c1716fc_0">
											<gml:posList>35.67192389082403 139.7458261264741 46.921 35.67190981021973 139.74583693424466 46.921 35.671921021209535 139.74585887134998 46.921 35.671935110829516 139.7458480635719 46.921 35.67192389082403 139.7458261264741 46.921</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-03f408c4-5d55-42dd-a74a-e116e89df93c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-03f408c4-5d55-42dd-a74a-e116e89df93c_0">
											<gml:posList>35.671927164766636 139.74580401890796 45.926 35.67193785766216 139.74579521424016 45.926 35.67192456281221 139.74577097070218 45.926 35.67191386991843 139.74577977537177 45.926 35.671927164766636 139.74580401890796 45.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44990a0d-c6e4-4a76-95a4-ac21427cbea9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-44990a0d-c6e4-4a76-95a4-ac21427cbea9_0">
											<gml:posList>35.671921021209535 139.74585887134998 45.043 35.671935110829516 139.7458480635719 45.043 35.671935110829516 139.7458480635719 46.921 35.671921021209535 139.74585887134998 46.921 35.671921021209535 139.74585887134998 45.043</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea466426-16a3-493d-80d9-4c5ad28833b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea466426-16a3-493d-80d9-4c5ad28833b8_0">
											<gml:posList>35.671935110829516 139.7458480635719 45.043 35.67192389082403 139.7458261264741 45.043 35.67192389082403 139.7458261264741 46.921 35.671935110829516 139.7458480635719 46.921 35.671935110829516 139.7458480635719 45.043</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2ce5876-eb18-4ca0-a58f-abd89b7ff6be">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a2ce5876-eb18-4ca0-a58f-abd89b7ff6be_0">
											<gml:posList>35.67193785766216 139.74579521424016 45.043 35.67193785766216 139.74579521424016 45.926 35.671927164766636 139.74580401890796 45.926 35.671927164766636 139.74580401890796 45.043 35.67193785766216 139.74579521424016 45.043</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-143205f5-5d03-4fcf-8177-14abd43295b7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-143205f5-5d03-4fcf-8177-14abd43295b7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-143205f5-5d03-4fcf-8177-14abd43295b7">
											<gml:posList>35.67185194709694 139.74576943722707 7.84 35.671928518489466 139.74570716195223 7.84 35.671978950927816 139.745894013277 7.84 35.671937602326445 139.74592763965583 7.84 35.67185194709694 139.74576943722707 7.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-24d4f2d1-9b76-47c1-a052-50f3c0ca689f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-24d4f2d1-9b76-47c1-a052-50f3c0ca689f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-24d4f2d1-9b76-47c1-a052-50f3c0ca689f">
											<gml:posList>35.67185194709694 139.74576943722707 42.6 35.67185781389607 139.7457802674002 47.4 35.671922269096186 139.74572798033662 47.4 35.671928518489466 139.74570716195223 42.6 35.67185194709694 139.74576943722707 42.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-043b8ae1-db70-40f7-b6fe-101fcec5c02f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-043b8ae1-db70-40f7-b6fe-101fcec5c02f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-043b8ae1-db70-40f7-b6fe-101fcec5c02f">
											<gml:posList>35.67185781389607 139.7457802674002 47.4 35.67186090617292 139.74578104832221 47.4 35.671921163454314 139.74573216815776 47.4 35.671922269096186 139.74572798033662 47.4 35.67185781389607 139.7457802674002 47.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-976f9b8a-c83b-431c-b9cf-b62d9c2ec8a2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-976f9b8a-c83b-431c-b9cf-b62d9c2ec8a2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-976f9b8a-c83b-431c-b9cf-b62d9c2ec8a2">
											<gml:posList>35.671978950927816 139.745894013277 42.6 35.671928518489466 139.74570716195223 42.6 35.671922269096186 139.74572798033662 47.4 35.671978950927816 139.745894013277 42.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d803adda-47ef-4222-941b-5995a0598a9f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d803adda-47ef-4222-941b-5995a0598a9f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d803adda-47ef-4222-941b-5995a0598a9f">
											<gml:posList>35.67197362695471 139.745898338257 47.4 35.671922269096186 139.74572798033662 47.4 35.671921163454314 139.74573216815776 47.4 35.67197093106584 139.74589725864212 47.4 35.67197362695471 139.745898338257 47.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f408cbfc-4100-43d3-a727-48a6d3b16a05">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f408cbfc-4100-43d3-a727-48a6d3b16a05">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f408cbfc-4100-43d3-a727-48a6d3b16a05">
											<gml:posList>35.671922269096186 139.74572798033662 47.4 35.67197362695471 139.745898338257 47.4 35.671978950927816 139.745894013277 42.6 35.671922269096186 139.74572798033662 47.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-16a5140b-46a9-485a-9957-f32e7d120d80">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16a5140b-46a9-485a-9957-f32e7d120d80">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16a5140b-46a9-485a-9957-f32e7d120d80">
											<gml:posList>35.67191805779085 139.74588657913472 45.043 35.67191928530156 139.7458888423226 45.043 35.671945815066934 139.74586727275906 45.043 35.6719647693138 139.74590226941677 45.043 35.67196662504961 139.74590076507195 45.043 35.67197093106584 139.74589725864212 45.043 35.671921163454314 139.74573216815776 45.043 35.67186090617292 139.74578104832221 45.043 35.67191805779085 139.74588657913472 45.043</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8edb9f94-f7ae-4840-a7a5-323404100196">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8edb9f94-f7ae-4840-a7a5-323404100196">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8edb9f94-f7ae-4840-a7a5-323404100196">
											<gml:posList>35.671917420560185 139.7458903577231 47.4 35.67191805779085 139.74588657913472 47.4 35.67186090617292 139.74578104832221 47.4 35.67185781389607 139.7457802674002 47.4 35.671917420560185 139.7458903577231 47.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c750b0da-996f-485f-aa3c-cf44929c7a3c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c750b0da-996f-485f-aa3c-cf44929c7a3c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c750b0da-996f-485f-aa3c-cf44929c7a3c">
											<gml:posList>35.671917420560185 139.7458903577231 49.154 35.67191926871006 139.74589081965922 49.154 35.67194543813554 139.74586953769776 49.154 35.671945815066934 139.74586727275906 49.154 35.671917420560185 139.7458903577231 49.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7bdf5efe-77ad-4dec-bbd3-33f9a726c85e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7bdf5efe-77ad-4dec-bbd3-33f9a726c85e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7bdf5efe-77ad-4dec-bbd3-33f9a726c85e">
											<gml:posList>35.671945815066934 139.74586727275906 49.154 35.67194543813554 139.74586953769776 49.154 35.67196415770416 139.74590409275265 49.154 35.671965996832235 139.7459045436527 49.154 35.671945815066934 139.74586727275906 49.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e6ac2b4a-f13b-432d-a1d8-dfde7f300c2e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e6ac2b4a-f13b-432d-a1d8-dfde7f300c2e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e6ac2b4a-f13b-432d-a1d8-dfde7f300c2e">
											<gml:posList>35.67191805779085 139.74588657913472 47.4 35.671917420560185 139.7458903577231 47.4 35.67191928530156 139.7458888423226 47.4 35.67191805779085 139.74588657913472 47.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b4e64902-d9d3-4be3-ae4e-bb4e9162c743">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b4e64902-d9d3-4be3-ae4e-bb4e9162c743">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b4e64902-d9d3-4be3-ae4e-bb4e9162c743">
											<gml:posList>35.67196415770416 139.74590409275265 48.918 35.67194543813554 139.74586953769776 48.918 35.67191926871006 139.74589081965922 48.918 35.671937970253225 139.74592538577392 48.918 35.67196415770416 139.74590409275265 48.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9ab7bb3d-9e6b-4819-a5df-716b213d4554">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ab7bb3d-9e6b-4819-a5df-716b213d4554">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ab7bb3d-9e6b-4819-a5df-716b213d4554">
											<gml:posList>35.67197362695471 139.745898338257 47.4 35.67197093106584 139.74589725864212 47.4 35.67196662504961 139.74590076507195 47.4 35.671965996832235 139.7459045436527 47.4 35.67197362695471 139.745898338257 47.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a36fb01c-e72b-4ae3-ab99-257240251665">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a36fb01c-e72b-4ae3-ab99-257240251665">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a36fb01c-e72b-4ae3-ab99-257240251665">
											<gml:posList>35.6719647693138 139.74590226941677 47.4 35.671965996832235 139.7459045436527 47.4 35.67196662504961 139.74590076507195 47.4 35.6719647693138 139.74590226941677 47.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dd2032d3-3d99-49cb-82af-7aa3dd017b6b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd2032d3-3d99-49cb-82af-7aa3dd017b6b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd2032d3-3d99-49cb-82af-7aa3dd017b6b">
											<gml:posList>35.671937602326445 139.74592763965583 49.154 35.671937970253225 139.74592538577392 49.154 35.67191926871006 139.74589081965922 49.154 35.671917420560185 139.7458903577231 49.154 35.671937602326445 139.74592763965583 49.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-24fd75bc-ef64-46f2-b2e5-dfd0682b220b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-24fd75bc-ef64-46f2-b2e5-dfd0682b220b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-24fd75bc-ef64-46f2-b2e5-dfd0682b220b">
											<gml:posList>35.671965996832235 139.7459045436527 49.154 35.67196415770416 139.74590409275265 49.154 35.671937970253225 139.74592538577392 49.154 35.671937602326445 139.74592763965583 49.154 35.671965996832235 139.7459045436527 49.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5edef2e6-8dca-4d97-917e-46b203aa79f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5edef2e6-8dca-4d97-917e-46b203aa79f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5edef2e6-8dca-4d97-917e-46b203aa79f2">
											<gml:posList>35.67191926871006 139.74589081965922 49.154 35.67191926871006 139.74589081965922 48.918 35.67194543813554 139.74586953769776 48.918 35.67194543813554 139.74586953769776 49.154 35.67191926871006 139.74589081965922 49.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d955aeda-db33-44d7-a5f9-2a7c24eeee32">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d955aeda-db33-44d7-a5f9-2a7c24eeee32">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d955aeda-db33-44d7-a5f9-2a7c24eeee32">
											<gml:posList>35.671928518489466 139.74570716195223 7.84 35.67185194709694 139.74576943722707 7.84 35.67185194709694 139.74576943722707 42.6 35.671928518489466 139.74570716195223 42.6 35.671928518489466 139.74570716195223 7.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c8826af2-a6a2-4ef7-839f-a800584c4a7d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8826af2-a6a2-4ef7-839f-a800584c4a7d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8826af2-a6a2-4ef7-839f-a800584c4a7d">
											<gml:posList>35.67186090617292 139.74578104832221 47.4 35.67186090617292 139.74578104832221 45.043 35.671921163454314 139.74573216815776 45.043 35.671921163454314 139.74573216815776 47.4 35.67186090617292 139.74578104832221 47.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8b2d6b48-bd2a-485f-a60e-1b78b8bb7aca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b2d6b48-bd2a-485f-a60e-1b78b8bb7aca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b2d6b48-bd2a-485f-a60e-1b78b8bb7aca">
											<gml:posList>35.671978950927816 139.745894013277 7.84 35.671928518489466 139.74570716195223 7.84 35.671928518489466 139.74570716195223 42.6 35.671978950927816 139.745894013277 42.6 35.671978950927816 139.745894013277 7.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3a623fb0-173f-49da-9d17-95fa8a131053">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a623fb0-173f-49da-9d17-95fa8a131053">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a623fb0-173f-49da-9d17-95fa8a131053">
											<gml:posList>35.671921163454314 139.74573216815776 47.4 35.671921163454314 139.74573216815776 45.043 35.67197093106584 139.74589725864212 45.043 35.67197093106584 139.74589725864212 47.4 35.671921163454314 139.74573216815776 47.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-96c392ee-72e5-44bd-b9f8-eb28bab4ccd5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96c392ee-72e5-44bd-b9f8-eb28bab4ccd5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96c392ee-72e5-44bd-b9f8-eb28bab4ccd5">
											<gml:posList>35.67191805779085 139.74588657913472 47.4 35.67191805779085 139.74588657913472 45.043 35.67186090617292 139.74578104832221 45.043 35.67186090617292 139.74578104832221 47.4 35.67191805779085 139.74588657913472 47.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1c14f043-11d0-433e-9ece-06fc96dea271">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c14f043-11d0-433e-9ece-06fc96dea271">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c14f043-11d0-433e-9ece-06fc96dea271">
											<gml:posList>35.671917420560185 139.7458903577231 47.4 35.67185781389607 139.7457802674002 47.4 35.67185194709694 139.74576943722707 42.6 35.67185194709694 139.74576943722707 7.84 35.671937602326445 139.74592763965583 7.84 35.671937602326445 139.74592763965583 49.154 35.671917420560185 139.7458903577231 49.154 35.671917420560185 139.7458903577231 47.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-67cd0548-0bb3-475e-bb15-6dc19b28b08f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67cd0548-0bb3-475e-bb15-6dc19b28b08f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67cd0548-0bb3-475e-bb15-6dc19b28b08f">
											<gml:posList>35.67191928530156 139.7458888423226 47.4 35.671917420560185 139.7458903577231 47.4 35.671917420560185 139.7458903577231 49.154 35.671945815066934 139.74586727275906 49.154 35.671945815066934 139.74586727275906 45.043 35.67191928530156 139.7458888423226 45.043 35.67191928530156 139.7458888423226 47.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-86c0a341-28ae-4ed5-9946-8666cc022983">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-86c0a341-28ae-4ed5-9946-8666cc022983">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-86c0a341-28ae-4ed5-9946-8666cc022983">
											<gml:posList>35.671945815066934 139.74586727275906 45.043 35.671945815066934 139.74586727275906 49.154 35.671965996832235 139.7459045436527 49.154 35.671965996832235 139.7459045436527 47.4 35.6719647693138 139.74590226941677 47.4 35.6719647693138 139.74590226941677 45.043 35.671945815066934 139.74586727275906 45.043</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8cb18348-eb4e-499c-b003-1ff5889a102b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8cb18348-eb4e-499c-b003-1ff5889a102b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8cb18348-eb4e-499c-b003-1ff5889a102b">
											<gml:posList>35.67194543813554 139.74586953769776 49.154 35.67194543813554 139.74586953769776 48.918 35.67196415770416 139.74590409275265 48.918 35.67196415770416 139.74590409275265 49.154 35.67194543813554 139.74586953769776 49.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c6a32468-768c-4249-bd88-52aaa131544f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6a32468-768c-4249-bd88-52aaa131544f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6a32468-768c-4249-bd88-52aaa131544f">
											<gml:posList>35.67191928530156 139.7458888423226 47.4 35.67191928530156 139.7458888423226 45.043 35.67191805779085 139.74588657913472 45.043 35.67191805779085 139.74588657913472 47.4 35.67191928530156 139.7458888423226 47.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d6fd3a78-ca00-4f04-a959-6f16ae92fcfe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d6fd3a78-ca00-4f04-a959-6f16ae92fcfe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d6fd3a78-ca00-4f04-a959-6f16ae92fcfe">
											<gml:posList>35.67197093106584 139.74589725864212 47.4 35.67197093106584 139.74589725864212 45.043 35.67196662504961 139.74590076507195 45.043 35.67196662504961 139.74590076507195 47.4 35.67197093106584 139.74589725864212 47.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-120ccbb4-7417-4b9c-8c59-3ec126791330">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-120ccbb4-7417-4b9c-8c59-3ec126791330">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-120ccbb4-7417-4b9c-8c59-3ec126791330">
											<gml:posList>35.67196662504961 139.74590076507195 47.4 35.67196662504961 139.74590076507195 45.043 35.6719647693138 139.74590226941677 45.043 35.6719647693138 139.74590226941677 47.4 35.67196662504961 139.74590076507195 47.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8fd7f0cf-32d8-486b-a0d5-f56cd1054077">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8fd7f0cf-32d8-486b-a0d5-f56cd1054077">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8fd7f0cf-32d8-486b-a0d5-f56cd1054077">
											<gml:posList>35.671937970253225 139.74592538577392 49.154 35.671937970253225 139.74592538577392 48.918 35.67191926871006 139.74589081965922 48.918 35.67191926871006 139.74589081965922 49.154 35.671937970253225 139.74592538577392 49.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3f524b35-16f9-4c08-9482-61751011d6d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f524b35-16f9-4c08-9482-61751011d6d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f524b35-16f9-4c08-9482-61751011d6d5">
											<gml:posList>35.671978950927816 139.745894013277 7.84 35.671978950927816 139.745894013277 42.6 35.67197362695471 139.745898338257 47.4 35.671965996832235 139.7459045436527 47.4 35.671965996832235 139.7459045436527 49.154 35.671937602326445 139.74592763965583 49.154 35.671937602326445 139.74592763965583 7.84 35.671978950927816 139.745894013277 7.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-31f7fa8f-9e55-4173-a5d8-cb667776cefa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31f7fa8f-9e55-4173-a5d8-cb667776cefa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31f7fa8f-9e55-4173-a5d8-cb667776cefa">
											<gml:posList>35.67196415770416 139.74590409275265 49.154 35.67196415770416 139.74590409275265 48.918 35.671937970253225 139.74592538577392 48.918 35.671937970253225 139.74592538577392 49.154 35.67196415770416 139.74590409275265 49.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都千代田区霞が関三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-3590</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">134.92985</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.03</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>