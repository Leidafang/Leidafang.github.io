<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_8cd071fb-042f-4724-be0a-28146f614781">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">18.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66848368595062 139.73907051433642 0 35.66842021187232 139.73916348572598 0 35.66854334797862 139.73928970742224 0 35.66860682215298 139.7391967359894 0 35.66848368595062 139.73907051433642 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66848368595062 139.73907051433642 12.15 35.66860682215298 139.7391967359894 12.15 35.66854334797862 139.73928970742224 12.15 35.66842021187232 139.73916348572598 12.15 35.66848368595062 139.73907051433642 12.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66848368595062 139.73907051433642 12.15 35.66842021187232 139.73916348572598 12.15 35.66842021187232 139.73916348572598 30.36 35.66848368595062 139.73907051433642 30.36 35.66848368595062 139.73907051433642 12.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66842021187232 139.73916348572598 12.15 35.66854334797862 139.73928970742224 12.15 35.66854334797862 139.73928970742224 30.36 35.66842021187232 139.73916348572598 30.36 35.66842021187232 139.73916348572598 12.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66854334797862 139.73928970742224 12.15 35.66860682215298 139.7391967359894 12.15 35.66860682215298 139.7391967359894 30.36 35.66854334797862 139.73928970742224 30.36 35.66854334797862 139.73928970742224 12.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66860682215298 139.7391967359894 12.15 35.66848368595062 139.73907051433642 12.15 35.66848368595062 139.73907051433642 30.36 35.66860682215298 139.7391967359894 30.36 35.66860682215298 139.7391967359894 12.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66848368595062 139.73907051433642 30.36 35.66842021187232 139.73916348572598 30.36 35.66854334797862 139.73928970742224 30.36 35.66860682215298 139.7391967359894 30.36 35.66848368595062 139.73907051433642 30.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-89006d2c-598a-4e76-a2ae-5bfb4f08c0fa"/>
							<gml:surfaceMember xlink:href="#poly-35f5bb5a-c0f1-4660-89b1-419a5f662aa3"/>
							<gml:surfaceMember xlink:href="#poly-29a8561a-69b3-4275-afb4-d4d02c311d36"/>
							<gml:surfaceMember xlink:href="#poly-c2920dd6-2c22-4bff-be17-86fa89d113be"/>
							<gml:surfaceMember xlink:href="#poly-a8d0fb6e-3874-4a7e-a13d-b6cb9e2aceee"/>
							<gml:surfaceMember xlink:href="#poly-80df07bc-61e4-444f-9b62-1f8c8710b71e"/>
							<gml:surfaceMember xlink:href="#poly-465c269f-a5e4-4f15-a82f-93f946143c25"/>
							<gml:surfaceMember xlink:href="#poly-56087564-b809-41f1-ae85-8da776d334eb"/>
							<gml:surfaceMember xlink:href="#poly-6214f25f-5b7e-4cff-b87f-8a922bc07aed"/>
							<gml:surfaceMember xlink:href="#poly-1b676525-2b6c-45bc-bedb-6930a6a5efcb"/>
							<gml:surfaceMember xlink:href="#poly-a91341ce-2516-403a-a26e-9c634aed79f6"/>
							<gml:surfaceMember xlink:href="#poly-5cce0554-a00f-4b85-8ed2-0ea3028582fd"/>
							<gml:surfaceMember xlink:href="#poly-dcb151b2-54a3-43f5-ba53-68a92ebd1ee9"/>
							<gml:surfaceMember xlink:href="#poly-8d6feace-f16a-4742-9215-2918cee13786"/>
							<gml:surfaceMember xlink:href="#poly-e3c8a8d8-ddf1-4725-9e6c-a43d2bd0a4d0"/>
							<gml:surfaceMember xlink:href="#poly-a3bef502-6e88-4737-800c-1dcf2525c9a4"/>
							<gml:surfaceMember xlink:href="#poly-e87c1cde-fae1-454f-9bf3-9f7908a3ff24"/>
							<gml:surfaceMember xlink:href="#poly-37f25fa4-1cf2-40b6-b339-55627734e1d1"/>
							<gml:surfaceMember xlink:href="#poly-8ce71cb2-8f6e-4b11-b3bb-e42d5b29bd76"/>
							<gml:surfaceMember xlink:href="#poly-1f714acc-d736-4f21-9548-b13d053426a4"/>
							<gml:surfaceMember xlink:href="#poly-91050073-44f7-460b-855f-fa3d6b69b1d6"/>
							<gml:surfaceMember xlink:href="#poly-357e449e-2652-4622-9fd2-bd6f6254f102"/>
							<gml:surfaceMember xlink:href="#poly-20f11f2f-030b-42cf-8b5c-bce2781a4322"/>
							<gml:surfaceMember xlink:href="#poly-8522bbdb-5a8b-428c-88b9-b55fa73d3de1"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_8cd071fb-042f-4724-be0a-28146f614781_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00cc3245-25af-48fa-b15b-b47bec1d341b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66847811006984 139.73912121097283 34.812 35.66846980194694 139.73911293623746 34.812 35.66848166804237 139.73909503882368 34.812 35.668489985180216 139.73910331354782 34.812 35.66847811006984 139.73912121097283 34.812</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7fb82d0-da80-4093-86f4-206d4ea349a5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66845839592903 139.7391313191292 34.812 35.668465864789205 139.73913833560772 34.812 35.668460679363704 139.73914662619543 34.812 35.668453210495365 139.73913959867062 34.812 35.66845839592903 139.7391313191292 34.812</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-208f4522-4a83-4c98-8501-ed26327a3f5b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668449514248216 139.73918491367735 30.562 35.66849210941349 139.73912250899807 30.562 35.668501518281715 139.73913215214756 30.562 35.66848462787851 139.73915690398076 30.562 35.66849432541643 139.73916684503635 30.562 35.66848741980125 139.73917697128095 30.562 35.668478741627084 139.73916806735156 30.562 35.6684599515052 139.73919561603722 30.562 35.668449514248216 139.73918491367735 30.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e07e8cf-9b5d-425c-a055-0c076af7ec03">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668535706219295 139.73916524999825 30.562 35.66852384006172 139.73918308113778 30.562 35.66851857192645 139.73917781838026 30.562 35.668530438083266 139.73915998724112 30.562 35.668535706219295 139.73916524999825 30.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a7f386a-b906-4c69-92eb-bc2a93ce3471">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66853130925562 139.73919052842066 30.562 35.66852543673473 139.73918466988755 30.562 35.66853729387882 139.73916683875848 30.562 35.66854316640055 139.7391726972911 30.562 35.66853130925562 139.73919052842066 30.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aca7f029-2ed8-4c23-b300-d67026a178b5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668514601546164 139.73918379892976 30.562 35.66851986968118 139.73918906168743 30.562 35.66850817459085 139.73920664960707 30.562 35.6685029064566 139.73920138684898 30.562 35.668514601546164 139.73918379892976 30.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f0e4b1ce-d56b-4ebc-8b7f-f525a83ee68f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668527528309745 139.73919669653012 30.562 35.668515833218315 139.73921428445036 30.562 35.6685098434338 139.73920831559428 30.562 35.66852153852436 139.73919072767453 30.562 35.668527528309745 139.73919669653012 30.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e235270-9315-4ae4-82ca-9fa8bc661438">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668503225235455 139.73920560604702 30.562 35.66851050500161 139.7392128768164 30.562 35.66850602143293 139.73921962013998 30.562 35.66849874166718 139.73921234937043 30.562 35.668503225235455 139.73920560604702 30.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-32038a67-4517-4eaf-9a5d-1c6a7504b4de">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-32038a67-4517-4eaf-9a5d-1c6a7504b4de_0">
											<gml:posList>35.66853729387882 139.73916683875848 30.562 35.66852543673473 139.73918466988755 30.562 35.66852543673473 139.73918466988755 32.176 35.66853729387882 139.73916683875848 32.176 35.66853729387882 139.73916683875848 30.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a6e80617-d124-4916-90cc-f1090f65e68f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a6e80617-d124-4916-90cc-f1090f65e68f_0">
											<gml:posList>35.66852153852436 139.73919072767453 30.562 35.6685098434338 139.73920831559428 30.562 35.6685098434338 139.73920831559428 32.176 35.66852153852436 139.73919072767453 32.176 35.66852153852436 139.73919072767453 30.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46383b33-4b3a-4e70-b56f-e9f2725ac744">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46383b33-4b3a-4e70-b56f-e9f2725ac744_0">
											<gml:posList>35.6684599515052 139.73919561603722 30.562 35.6684599515052 139.73919561603722 32.131 35.668449514248216 139.73918491367735 32.131 35.668449514248216 139.73918491367735 30.562 35.6684599515052 139.73919561603722 30.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c8ec4111-b5cc-42ee-bb39-82d50c9da0cf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c8ec4111-b5cc-42ee-bb39-82d50c9da0cf_0">
											<gml:posList>35.668453210495365 139.73913959867062 34.812 35.668453210495365 139.73913959867062 35.612 35.66845839592903 139.7391313191292 35.612 35.66845839592903 139.7391313191292 34.812 35.668453210495365 139.73913959867062 34.812</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2e56045-fbd6-4907-85ac-fc453a6cc690">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b2e56045-fbd6-4907-85ac-fc453a6cc690_0">
											<gml:posList>35.668453210495365 139.73913959867062 34.812 35.668460679363704 139.73914662619543 34.812 35.668460679363704 139.73914662619543 35.612 35.668453210495365 139.73913959867062 35.612 35.668453210495365 139.73913959867062 34.812</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77546c45-d4ca-44d9-814a-8879716d6506">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77546c45-d4ca-44d9-814a-8879716d6506_0">
											<gml:posList>35.66845839592903 139.7391313191292 35.612 35.668453210495365 139.73913959867062 35.612 35.668460679363704 139.73914662619543 35.612 35.668465864789205 139.73913833560772 35.612 35.66845839592903 139.7391313191292 35.612</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a752240-a974-4800-b142-3cd8fe85742f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1a752240-a974-4800-b142-3cd8fe85742f_0">
											<gml:posList>35.668465864789205 139.73913833560772 34.812 35.66845839592903 139.7391313191292 34.812 35.66845839592903 139.7391313191292 35.612 35.668465864789205 139.73913833560772 35.612 35.668465864789205 139.73913833560772 34.812</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-994ea34a-62c8-45fb-9211-1304c831053e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-994ea34a-62c8-45fb-9211-1304c831053e_0">
											<gml:posList>35.668460679363704 139.73914662619543 34.812 35.668465864789205 139.73913833560772 34.812 35.668465864789205 139.73913833560772 35.612 35.668460679363704 139.73914662619543 35.612 35.668460679363704 139.73914662619543 34.812</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af1b711d-ca9b-455e-acba-5b97677cb30c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-af1b711d-ca9b-455e-acba-5b97677cb30c_0">
											<gml:posList>35.668478741627084 139.73916806735156 30.562 35.668478741627084 139.73916806735156 32.131 35.6684599515052 139.73919561603722 32.131 35.6684599515052 139.73919561603722 30.562 35.668478741627084 139.73916806735156 30.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-719c7457-9699-4168-9300-e7170e4eefd1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-719c7457-9699-4168-9300-e7170e4eefd1_0">
											<gml:posList>35.66849210941349 139.73912250899807 30.562 35.668449514248216 139.73918491367735 30.562 35.668449514248216 139.73918491367735 32.131 35.66849210941349 139.73912250899807 32.131 35.66849210941349 139.73912250899807 30.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8adace76-000b-405b-a764-ac5de4567cf5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8adace76-000b-405b-a764-ac5de4567cf5_0">
											<gml:posList>35.66847811006984 139.73912121097283 34.812 35.66847811006984 139.73912121097283 36.341 35.66846980194694 139.73911293623746 36.341 35.66846980194694 139.73911293623746 34.812 35.66847811006984 139.73912121097283 34.812</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-49040a88-7ab7-43d2-a511-bcecd57f9929">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-49040a88-7ab7-43d2-a511-bcecd57f9929_0">
											<gml:posList>35.668478741627084 139.73916806735156 32.131 35.66848741980125 139.73917697128095 32.131 35.66849432541643 139.73916684503635 32.131 35.66848462787851 139.73915690398076 32.131 35.668501518281715 139.73913215214756 32.131 35.66849210941349 139.73912250899807 32.131 35.668449514248216 139.73918491367735 32.131 35.6684599515052 139.73919561603722 32.131 35.668478741627084 139.73916806735156 32.131</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-401936e6-081d-4aa3-9ac8-36107bb720f7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-401936e6-081d-4aa3-9ac8-36107bb720f7_0">
											<gml:posList>35.66846980194694 139.73911293623746 34.812 35.66846980194694 139.73911293623746 36.341 35.66848166804237 139.73909503882368 36.341 35.66848166804237 139.73909503882368 34.812 35.66846980194694 139.73911293623746 34.812</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8177e9c-d978-48a5-9da9-e766c020be08">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b8177e9c-d978-48a5-9da9-e766c020be08_0">
											<gml:posList>35.66848166804237 139.73909503882368 36.341 35.66846980194694 139.73911293623746 36.341 35.66847811006984 139.73912121097283 36.341 35.668489985180216 139.73910331354782 36.341 35.66848166804237 139.73909503882368 36.341</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1569662-22a8-4220-b21f-f963ae82056b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a1569662-22a8-4220-b21f-f963ae82056b_0">
											<gml:posList>35.66848741980125 139.73917697128095 30.562 35.66848741980125 139.73917697128095 32.131 35.668478741627084 139.73916806735156 32.131 35.668478741627084 139.73916806735156 30.562 35.66848741980125 139.73917697128095 30.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3cd44e1a-7138-447a-acbe-150b15a3f366">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3cd44e1a-7138-447a-acbe-150b15a3f366_0">
											<gml:posList>35.66847811006984 139.73912121097283 34.812 35.668489985180216 139.73910331354782 34.812 35.668489985180216 139.73910331354782 36.341 35.66847811006984 139.73912121097283 36.341 35.66847811006984 139.73912121097283 34.812</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-47a6f160-a209-4b54-9ffd-4fafd9c6349d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-47a6f160-a209-4b54-9ffd-4fafd9c6349d_0">
											<gml:posList>35.668489985180216 139.73910331354782 34.812 35.66848166804237 139.73909503882368 34.812 35.66848166804237 139.73909503882368 36.341 35.668489985180216 139.73910331354782 36.341 35.668489985180216 139.73910331354782 34.812</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc1e87fa-23c8-473b-acd0-abadb11edf9a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cc1e87fa-23c8-473b-acd0-abadb11edf9a_0">
											<gml:posList>35.66849432541643 139.73916684503635 30.562 35.66848462787851 139.73915690398076 30.562 35.66848462787851 139.73915690398076 32.131 35.66849432541643 139.73916684503635 32.131 35.66849432541643 139.73916684503635 30.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2e249fdd-bdab-43a4-8cdc-e334c82d3893">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2e249fdd-bdab-43a4-8cdc-e334c82d3893_0">
											<gml:posList>35.66848741980125 139.73917697128095 30.562 35.66849432541643 139.73916684503635 30.562 35.66849432541643 139.73916684503635 32.131 35.66848741980125 139.73917697128095 32.131 35.66848741980125 139.73917697128095 30.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80f15819-859f-48a3-98b6-6d62d9e22261">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-80f15819-859f-48a3-98b6-6d62d9e22261_0">
											<gml:posList>35.66848462787851 139.73915690398076 30.562 35.668501518281715 139.73913215214756 30.562 35.668501518281715 139.73913215214756 32.131 35.66848462787851 139.73915690398076 32.131 35.66848462787851 139.73915690398076 30.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5743eed7-21c0-45d0-aa4f-9cbccbcea68c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5743eed7-21c0-45d0-aa4f-9cbccbcea68c_0">
											<gml:posList>35.668501518281715 139.73913215214756 30.562 35.66849210941349 139.73912250899807 30.562 35.66849210941349 139.73912250899807 32.131 35.668501518281715 139.73913215214756 32.131 35.668501518281715 139.73913215214756 30.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2401dcd-bf0e-4e75-b9a0-6f698d921acf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b2401dcd-bf0e-4e75-b9a0-6f698d921acf_0">
											<gml:posList>35.66849874166718 139.73921234937043 30.562 35.66849874166718 139.73921234937043 32.176 35.668503225235455 139.73920560604702 32.176 35.668503225235455 139.73920560604702 30.562 35.66849874166718 139.73921234937043 30.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f0a7a985-e568-4b8f-b78f-446b43651c73">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f0a7a985-e568-4b8f-b78f-446b43651c73_0">
											<gml:posList>35.66849874166718 139.73921234937043 30.562 35.66850602143293 139.73921962013998 30.562 35.66850602143293 139.73921962013998 32.176 35.66849874166718 139.73921234937043 32.176 35.66849874166718 139.73921234937043 30.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e101c3ce-82aa-4367-9740-0370c1d09098">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e101c3ce-82aa-4367-9740-0370c1d09098_0">
											<gml:posList>35.66850602143293 139.73921962013998 32.176 35.66851050500161 139.7392128768164 32.176 35.668503225235455 139.73920560604702 32.176 35.66849874166718 139.73921234937043 32.176 35.66850602143293 139.73921962013998 32.176</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-379a96f7-eb92-41b2-8533-67f807bf54b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-379a96f7-eb92-41b2-8533-67f807bf54b8_0">
											<gml:posList>35.6685029064566 139.73920138684898 30.562 35.66850817459085 139.73920664960707 30.562 35.66850817459085 139.73920664960707 32.176 35.6685029064566 139.73920138684898 32.176 35.6685029064566 139.73920138684898 30.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9971bc0-db59-4a74-b92c-30d67c97e2be">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b9971bc0-db59-4a74-b92c-30d67c97e2be_0">
											<gml:posList>35.66851050500161 139.7392128768164 30.562 35.668503225235455 139.73920560604702 30.562 35.668503225235455 139.73920560604702 32.176 35.66851050500161 139.7392128768164 32.176 35.66851050500161 139.7392128768164 30.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1469aed7-ede0-4b7f-ac56-74511caac7b7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1469aed7-ede0-4b7f-ac56-74511caac7b7_0">
											<gml:posList>35.66851050500161 139.7392128768164 30.562 35.66851050500161 139.7392128768164 32.176 35.66850602143293 139.73921962013998 32.176 35.66850602143293 139.73921962013998 30.562 35.66851050500161 139.7392128768164 30.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46a630cb-ec49-447d-add4-f416048bde90">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46a630cb-ec49-447d-add4-f416048bde90_0">
											<gml:posList>35.668514601546164 139.73918379892976 30.562 35.6685029064566 139.73920138684898 30.562 35.6685029064566 139.73920138684898 32.176 35.668514601546164 139.73918379892976 32.176 35.668514601546164 139.73918379892976 30.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-be96a0a1-5390-453f-afa7-328bc8beb089">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-be96a0a1-5390-453f-afa7-328bc8beb089_0">
											<gml:posList>35.668514601546164 139.73918379892976 32.176 35.6685029064566 139.73920138684898 32.176 35.66850817459085 139.73920664960707 32.176 35.66851986968118 139.73918906168743 32.176 35.668514601546164 139.73918379892976 32.176</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-28059911-36bc-4f37-8e6b-dae7a99fc421">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-28059911-36bc-4f37-8e6b-dae7a99fc421_0">
											<gml:posList>35.6685098434338 139.73920831559428 30.562 35.668515833218315 139.73921428445036 30.562 35.668515833218315 139.73921428445036 32.176 35.6685098434338 139.73920831559428 32.176 35.6685098434338 139.73920831559428 30.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b95a321-3aec-4ff3-92f9-7f8593a8aa2b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6b95a321-3aec-4ff3-92f9-7f8593a8aa2b_0">
											<gml:posList>35.66850817459085 139.73920664960707 30.562 35.66851986968118 139.73918906168743 30.562 35.66851986968118 139.73918906168743 32.176 35.66850817459085 139.73920664960707 32.176 35.66850817459085 139.73920664960707 30.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fde46490-0ee2-4bd4-9872-ee1534a63039">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fde46490-0ee2-4bd4-9872-ee1534a63039_0">
											<gml:posList>35.668514601546164 139.73918379892976 30.562 35.668514601546164 139.73918379892976 32.176 35.66851986968118 139.73918906168743 32.176 35.66851986968118 139.73918906168743 30.562 35.668514601546164 139.73918379892976 30.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ccc89779-87ea-4a1f-8569-208dd55f670a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ccc89779-87ea-4a1f-8569-208dd55f670a_0">
											<gml:posList>35.6685098434338 139.73920831559428 32.176 35.668515833218315 139.73921428445036 32.176 35.668527528309745 139.73919669653012 32.176 35.66852153852436 139.73919072767453 32.176 35.6685098434338 139.73920831559428 32.176</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4380cbbe-2df7-4d90-904e-d2e04fd8e82a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4380cbbe-2df7-4d90-904e-d2e04fd8e82a_0">
											<gml:posList>35.66851857192645 139.73917781838026 30.562 35.66852384006172 139.73918308113778 30.562 35.66852384006172 139.73918308113778 32.176 35.66851857192645 139.73917781838026 32.176 35.66851857192645 139.73917781838026 30.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c8423b40-9625-445b-a160-4fcccd0c6b10">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c8423b40-9625-445b-a160-4fcccd0c6b10_0">
											<gml:posList>35.668515833218315 139.73921428445036 30.562 35.668527528309745 139.73919669653012 30.562 35.668527528309745 139.73919669653012 32.176 35.668515833218315 139.73921428445036 32.176 35.668515833218315 139.73921428445036 30.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba9b01dd-f7c8-4276-8393-c550b2562e61">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba9b01dd-f7c8-4276-8393-c550b2562e61_0">
											<gml:posList>35.668530438083266 139.73915998724112 30.562 35.66851857192645 139.73917781838026 30.562 35.66851857192645 139.73917781838026 32.176 35.668530438083266 139.73915998724112 32.176 35.668530438083266 139.73915998724112 30.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7493d96-f777-463b-b418-daabcd6422a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c7493d96-f777-463b-b418-daabcd6422a6_0">
											<gml:posList>35.66852153852436 139.73919072767453 30.562 35.66852153852436 139.73919072767453 32.176 35.668527528309745 139.73919669653012 32.176 35.668527528309745 139.73919669653012 30.562 35.66852153852436 139.73919072767453 30.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04690d53-03d5-4680-8c01-20dc1f5ed82b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-04690d53-03d5-4680-8c01-20dc1f5ed82b_0">
											<gml:posList>35.66851857192645 139.73917781838026 32.176 35.66852384006172 139.73918308113778 32.176 35.668535706219295 139.73916524999825 32.176 35.668530438083266 139.73915998724112 32.176 35.66851857192645 139.73917781838026 32.176</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-67fb244b-e07f-4e12-a507-9a817aee4fc0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-67fb244b-e07f-4e12-a507-9a817aee4fc0_0">
											<gml:posList>35.66852543673473 139.73918466988755 30.562 35.66853130925562 139.73919052842066 30.562 35.66853130925562 139.73919052842066 32.176 35.66852543673473 139.73918466988755 32.176 35.66852543673473 139.73918466988755 30.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ee6a333d-9521-469c-a626-152207a68e31">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ee6a333d-9521-469c-a626-152207a68e31_0">
											<gml:posList>35.66852384006172 139.73918308113778 30.562 35.668535706219295 139.73916524999825 30.562 35.668535706219295 139.73916524999825 32.176 35.66852384006172 139.73918308113778 32.176 35.66852384006172 139.73918308113778 30.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c139c048-c6c6-4b41-aeec-4a44c34f4587">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c139c048-c6c6-4b41-aeec-4a44c34f4587_0">
											<gml:posList>35.668535706219295 139.73916524999825 30.562 35.668530438083266 139.73915998724112 30.562 35.668530438083266 139.73915998724112 32.176 35.668535706219295 139.73916524999825 32.176 35.668535706219295 139.73916524999825 30.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d15d0b65-4342-4be8-87d9-8c56bd154959">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d15d0b65-4342-4be8-87d9-8c56bd154959_0">
											<gml:posList>35.66853729387882 139.73916683875848 32.176 35.66852543673473 139.73918466988755 32.176 35.66853130925562 139.73919052842066 32.176 35.66854316640055 139.7391726972911 32.176 35.66853729387882 139.73916683875848 32.176</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-518d3fb5-728c-4265-b83c-bc0e82b54570">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-518d3fb5-728c-4265-b83c-bc0e82b54570_0">
											<gml:posList>35.66854316640055 139.7391726972911 30.562 35.66854316640055 139.7391726972911 32.176 35.66853130925562 139.73919052842066 32.176 35.66853130925562 139.73919052842066 30.562 35.66854316640055 139.7391726972911 30.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1381c84-121e-4068-9a24-35f8a0619b0a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c1381c84-121e-4068-9a24-35f8a0619b0a_0">
											<gml:posList>35.66854316640055 139.7391726972911 30.562 35.66853729387882 139.73916683875848 30.562 35.66853729387882 139.73916683875848 32.176 35.66854316640055 139.7391726972911 32.176 35.66854316640055 139.7391726972911 30.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_8cd071fb-042f-4724-be0a-28146f614781_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bbe49cd6-2061-4aa6-9cfa-f41880dcd2a5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66849344578975 139.7391600748718 30.562 35.668506886969745 139.73913920423507 30.562 35.66851850544339 139.7391504354173 30.562 35.66850505525637 139.73917131711173 30.562 35.66849344578975 139.7391600748718 30.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cac8f36f-ac54-43cf-b75c-9e02d68f72c0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cac8f36f-ac54-43cf-b75c-9e02d68f72c0_0">
											<gml:posList>35.668506886969745 139.73913920423507 30.562 35.668506886969745 139.73913920423507 33.174 35.66851850544339 139.7391504354173 33.174 35.66851850544339 139.7391504354173 30.562 35.668506886969745 139.73913920423507 30.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c6cd9149-a736-4671-b41e-69dcab86f69f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c6cd9149-a736-4671-b41e-69dcab86f69f_0">
											<gml:posList>35.66849344578975 139.7391600748718 30.562 35.66849344578975 139.7391600748718 33.174 35.668506886969745 139.73913920423507 33.174 35.668506886969745 139.73913920423507 30.562 35.66849344578975 139.7391600748718 30.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61e82ab3-0334-4db1-bf42-d675a0787834">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-61e82ab3-0334-4db1-bf42-d675a0787834_0">
											<gml:posList>35.66851850544339 139.7391504354173 33.174 35.668506886969745 139.73913920423507 33.174 35.66849344578975 139.7391600748718 33.174 35.66850505525637 139.73917131711173 33.174 35.66851850544339 139.7391504354173 33.174</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-be72c0f0-b4a8-4e85-92b9-34a4b9c01f5c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-be72c0f0-b4a8-4e85-92b9-34a4b9c01f5c_0">
											<gml:posList>35.66851850544339 139.7391504354173 30.562 35.66851850544339 139.7391504354173 33.174 35.66850505525637 139.73917131711173 33.174 35.66850505525637 139.73917131711173 30.562 35.66851850544339 139.7391504354173 30.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19f194f9-fba2-419f-9dc7-0be4fc0607f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19f194f9-fba2-419f-9dc7-0be4fc0607f8_0">
											<gml:posList>35.66850505525637 139.73917131711173 30.562 35.66850505525637 139.73917131711173 33.174 35.66849344578975 139.7391600748718 33.174 35.66849344578975 139.7391600748718 30.562 35.66850505525637 139.73917131711173 30.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_8cd071fb-042f-4724-be0a-28146f614781_BuildingInstallation_1061">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-392714e0-00ca-4faa-bbfa-7a95e63d3e29">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66844676822288 139.73918895973506 31.17 35.66844754251373 139.73918782108868 31.17 35.66848921034223 139.73923054227257 31.17 35.66844676822288 139.73918895973506 31.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9d2b7fa-c555-46e2-98a0-c2862b87fdff">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668506433862895 139.73910154894938 30.562 35.66856431909505 139.7391579260288 30.562 35.66850637653798 139.73924725681812 30.562 35.66848470887635 139.73922591928223 30.562 35.66844754251373 139.73918782108868 30.562 35.66844780360949 139.73918743417235 30.562 35.66850595942093 139.73924407605924 30.562 35.66856167824637 139.73915815005068 30.562 35.66850529043369 139.7391032292853 30.562 35.668506433862895 139.73910154894938 30.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e568871-4117-446a-a77c-62d36f6c38a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4e568871-4117-446a-a77c-62d36f6c38a5_0">
											<gml:posList>35.66850529043369 139.7391032292853 31.544 35.668506433862895 139.73910154894938 31.544 35.668506433862895 139.73910154894938 30.562 35.66850529043369 139.7391032292853 30.562 35.66850529043369 139.7391032292853 31.544</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-078bd27e-b5fd-4a5d-a208-360a6db26e87">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-078bd27e-b5fd-4a5d-a208-360a6db26e87_0">
											<gml:posList>35.66856431909505 139.7391579260288 31.544 35.66856431909505 139.7391579260288 30.562 35.668506433862895 139.73910154894938 30.562 35.668506433862895 139.73910154894938 31.544 35.66856431909505 139.7391579260288 31.544</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f733863a-974b-4df8-8806-ef038746dce1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f733863a-974b-4df8-8806-ef038746dce1_0">
											<gml:posList>35.66850529043369 139.7391032292853 30.562 35.66856167824637 139.73915815005068 30.562 35.66856167824637 139.73915815005068 31.544 35.66850529043369 139.7391032292853 31.544 35.66850529043369 139.7391032292853 30.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-878092f2-62eb-4435-bd3a-4d3eb7c800b7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-878092f2-62eb-4435-bd3a-4d3eb7c800b7_0">
											<gml:posList>35.66856167824637 139.73915815005068 31.544 35.66850595942093 139.73924407605924 31.544 35.66844780360949 139.73918743417235 31.544 35.66844666918417 139.73918910344926 31.544 35.66850637653798 139.73924725681812 31.544 35.66856431909505 139.7391579260288 31.544 35.668506433862895 139.73910154894938 31.544 35.66850529043369 139.7391032292853 31.544 35.66856167824637 139.73915815005068 31.544</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e1006e7e-2eb9-4d93-8cfd-3c8ee9679894">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e1006e7e-2eb9-4d93-8cfd-3c8ee9679894_0">
											<gml:posList>35.66844780360949 139.73918743417235 30.562 35.66844754251373 139.73918782108868 30.562 35.66844754251373 139.73918782108868 31.17 35.66844676822288 139.73918895973506 31.17 35.66844666918417 139.73918910344926 31.544 35.66844780360949 139.73918743417235 31.544 35.66844780360949 139.73918743417235 30.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4226262b-3578-4cc5-9e24-cb1d4129e28e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4226262b-3578-4cc5-9e24-cb1d4129e28e_0">
											<gml:posList>35.66850595942093 139.73924407605924 31.544 35.66856167824637 139.73915815005068 31.544 35.66856167824637 139.73915815005068 30.562 35.66850595942093 139.73924407605924 30.562 35.66850595942093 139.73924407605924 31.544</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3eef7949-131c-4cfd-9fc1-9e7c71b18981">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3eef7949-131c-4cfd-9fc1-9e7c71b18981_0">
											<gml:posList>35.66856431909505 139.7391579260288 31.544 35.66850637653798 139.73924725681812 31.544 35.66850637653798 139.73924725681812 30.562 35.66856431909505 139.7391579260288 30.562 35.66856431909505 139.7391579260288 31.544</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7bb1f62e-8083-42dc-abc8-143dbaa52033">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7bb1f62e-8083-42dc-abc8-143dbaa52033_0">
											<gml:posList>35.66844754251373 139.73918782108868 31.17 35.66844754251373 139.73918782108868 30.562 35.66848470887635 139.73922591928223 30.562 35.66848921034223 139.73923054227257 30.844 35.66848921034223 139.73923054227257 31.17 35.66844754251373 139.73918782108868 31.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc913552-e40b-4513-89a1-2c854aa33fbf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cc913552-e40b-4513-89a1-2c854aa33fbf_0">
											<gml:posList>35.66850595942093 139.73924407605924 31.544 35.66850595942093 139.73924407605924 30.562 35.66844780360949 139.73918743417235 30.562 35.66844780360949 139.73918743417235 31.544 35.66850595942093 139.73924407605924 31.544</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4f105266-ff4d-405b-8002-a099b55a39d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4f105266-ff4d-405b-8002-a099b55a39d7_0">
											<gml:posList>35.66844676822288 139.73918895973506 31.17 35.66848921034223 139.73923054227257 31.17 35.66848921034223 139.73923054227257 30.844 35.66848470887635 139.73922591928223 30.562 35.66850637653798 139.73924725681812 30.562 35.66850637653798 139.73924725681812 31.544 35.66844666918417 139.73918910344926 31.544 35.66844676822288 139.73918895973506 31.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-89006d2c-598a-4e76-a2ae-5bfb4f08c0fa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-89006d2c-598a-4e76-a2ae-5bfb4f08c0fa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-89006d2c-598a-4e76-a2ae-5bfb4f08c0fa">
											<gml:posList>35.668483685950605 139.73907051433642 12.15 35.668606822152974 139.7391967359894 12.15 35.668543347978606 139.73928970742222 12.15 35.668420211872316 139.73916348572598 12.15 35.668483685950605 139.73907051433642 12.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-35f5bb5a-c0f1-4660-89b1-419a5f662aa3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-35f5bb5a-c0f1-4660-89b1-419a5f662aa3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-35f5bb5a-c0f1-4660-89b1-419a5f662aa3">
											<gml:posList>35.66844606595546 139.73918998783694 35.746 35.66844573780824 139.73918531576726 35.746 35.66842403337222 139.73916307253626 35.746 35.668420211872316 139.73916348572598 35.746 35.66844606595546 139.73918998783694 35.746</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-29a8561a-69b3-4275-afb4-d4d02c311d36">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-29a8561a-69b3-4275-afb4-d4d02c311d36">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-29a8561a-69b3-4275-afb4-d4d02c311d36">
											<gml:posList>35.668420211872316 139.73916348572598 35.746 35.66842403337222 139.73916307253626 35.746 35.66848402312464 139.73907519744324 35.746 35.668483685950605 139.73907051433642 35.746 35.668420211872316 139.73916348572598 35.746</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c2920dd6-2c22-4bff-be17-86fa89d113be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c2920dd6-2c22-4bff-be17-86fa89d113be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c2920dd6-2c22-4bff-be17-86fa89d113be">
											<gml:posList>35.6685057185543 139.7390974296316 34.812 35.66848402312464 139.73907519744324 34.812 35.66842403337222 139.73916307253626 34.812 35.66844573780824 139.73918531576726 34.812 35.6685057185543 139.7390974296316 34.812</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a8d0fb6e-3874-4a7e-a13d-b6cb9e2aceee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a8d0fb6e-3874-4a7e-a13d-b6cb9e2aceee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a8d0fb6e-3874-4a7e-a13d-b6cb9e2aceee">
											<gml:posList>35.668509531031546 139.7390970054029 35.746 35.6685057185543 139.7390974296316 35.746 35.66844573780824 139.73918531576726 35.746 35.66844606595546 139.73918998783694 35.746 35.668509531031546 139.7390970054029 35.746</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-80df07bc-61e4-444f-9b62-1f8c8710b71e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-80df07bc-61e4-444f-9b62-1f8c8710b71e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-80df07bc-61e4-444f-9b62-1f8c8710b71e">
											<gml:posList>35.66853866322955 139.7392812295845 31.17 35.66844754251373 139.73918782108868 31.17 35.66844606595546 139.73918998783694 31.17 35.66853899987777 139.73928524993568 31.17 35.66853866322955 139.7392812295845 31.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-465c269f-a5e4-4f15-a82f-93f946143c25">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-465c269f-a5e4-4f15-a82f-93f946143c25">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-465c269f-a5e4-4f15-a82f-93f946143c25">
											<gml:posList>35.668483685950605 139.73907051433642 35.746 35.66848402312464 139.73907519744324 35.746 35.6685057185543 139.7390974296316 35.746 35.668509531031546 139.7390970054029 35.746 35.668483685950605 139.73907051433642 35.746</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-56087564-b809-41f1-ae85-8da776d334eb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56087564-b809-41f1-ae85-8da776d334eb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56087564-b809-41f1-ae85-8da776d334eb">
											<gml:posList>35.66844754251373 139.73918782108868 30.562 35.66853866322955 139.7392812295845 30.562 35.66859761464056 139.7391909918261 30.562 35.66850805447493 139.73909917215454 30.562 35.66844754251373 139.73918782108868 30.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6214f25f-5b7e-4cff-b87f-8a922bc07aed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6214f25f-5b7e-4cff-b87f-8a922bc07aed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6214f25f-5b7e-4cff-b87f-8a922bc07aed">
											<gml:posList>35.66859761464056 139.7391909918261 31.17 35.66860082321578 139.73919059040242 31.17 35.668509531031546 139.7390970054029 31.17 35.66850805447493 139.73909917215454 31.17 35.66859761464056 139.7391909918261 31.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1b676525-2b6c-45bc-bedb-6930a6a5efcb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b676525-2b6c-45bc-bedb-6930a6a5efcb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b676525-2b6c-45bc-bedb-6930a6a5efcb">
											<gml:posList>35.66860082321578 139.73919059040242 31.17 35.66859761464056 139.7391909918261 31.17 35.66853866322955 139.7392812295845 31.17 35.66853899987777 139.73928524993568 31.17 35.66860082321578 139.73919059040242 31.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a91341ce-2516-403a-a26e-9c634aed79f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a91341ce-2516-403a-a26e-9c634aed79f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a91341ce-2516-403a-a26e-9c634aed79f6">
											<gml:posList>35.66853899987777 139.73928524993568 29.605 35.668543347978606 139.73928970742222 29.605 35.668606822152974 139.7391967359894 29.605 35.66860082321578 139.73919059040242 29.605 35.66853899987777 139.73928524993568 29.605</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5cce0554-a00f-4b85-8ed2-0ea3028582fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5cce0554-a00f-4b85-8ed2-0ea3028582fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5cce0554-a00f-4b85-8ed2-0ea3028582fd">
											<gml:posList>35.66842403337222 139.73916307253626 35.746 35.66842403337222 139.73916307253626 34.812 35.66848402312464 139.73907519744324 34.812 35.66848402312464 139.73907519744324 35.746 35.66842403337222 139.73916307253626 35.746</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dcb151b2-54a3-43f5-ba53-68a92ebd1ee9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dcb151b2-54a3-43f5-ba53-68a92ebd1ee9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dcb151b2-54a3-43f5-ba53-68a92ebd1ee9">
											<gml:posList>35.6685057185543 139.7390974296316 35.746 35.6685057185543 139.7390974296316 34.812 35.66844573780824 139.73918531576726 34.812 35.66844573780824 139.73918531576726 35.746 35.6685057185543 139.7390974296316 35.746</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8d6feace-f16a-4742-9215-2918cee13786">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d6feace-f16a-4742-9215-2918cee13786">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d6feace-f16a-4742-9215-2918cee13786">
											<gml:posList>35.66850805447493 139.73909917215454 31.17 35.66850805447493 139.73909917215454 30.562 35.66859761464056 139.7391909918261 30.562 35.66859761464056 139.7391909918261 31.17 35.66850805447493 139.73909917215454 31.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e3c8a8d8-ddf1-4725-9e6c-a43d2bd0a4d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e3c8a8d8-ddf1-4725-9e6c-a43d2bd0a4d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e3c8a8d8-ddf1-4725-9e6c-a43d2bd0a4d0">
											<gml:posList>35.66853866322955 139.7392812295845 31.17 35.66853866322955 139.7392812295845 30.562 35.66844754251373 139.73918782108868 30.562 35.66844754251373 139.73918782108868 31.17 35.66853866322955 139.7392812295845 31.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a3bef502-6e88-4737-800c-1dcf2525c9a4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a3bef502-6e88-4737-800c-1dcf2525c9a4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a3bef502-6e88-4737-800c-1dcf2525c9a4">
											<gml:posList>35.66844573780824 139.73918531576726 35.746 35.66844573780824 139.73918531576726 34.812 35.66842403337222 139.73916307253626 34.812 35.66842403337222 139.73916307253626 35.746 35.66844573780824 139.73918531576726 35.746</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e87c1cde-fae1-454f-9bf3-9f7908a3ff24">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e87c1cde-fae1-454f-9bf3-9f7908a3ff24">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e87c1cde-fae1-454f-9bf3-9f7908a3ff24">
											<gml:posList>35.668483685950605 139.73907051433642 35.746 35.668483685950605 139.73907051433642 12.15 35.668420211872316 139.73916348572598 12.15 35.668420211872316 139.73916348572598 35.746 35.668483685950605 139.73907051433642 35.746</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-37f25fa4-1cf2-40b6-b339-55627734e1d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37f25fa4-1cf2-40b6-b339-55627734e1d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37f25fa4-1cf2-40b6-b339-55627734e1d1">
											<gml:posList>35.66844754251373 139.73918782108868 31.17 35.66844754251373 139.73918782108868 30.562 35.66850805447493 139.73909917215454 30.562 35.66850805447493 139.73909917215454 31.17 35.668509531031546 139.7390970054029 31.17 35.668509531031546 139.7390970054029 35.746 35.66844606595546 139.73918998783694 35.746 35.66844606595546 139.73918998783694 31.17 35.66844754251373 139.73918782108868 31.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8ce71cb2-8f6e-4b11-b3bb-e42d5b29bd76">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ce71cb2-8f6e-4b11-b3bb-e42d5b29bd76">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ce71cb2-8f6e-4b11-b3bb-e42d5b29bd76">
											<gml:posList>35.668420211872316 139.73916348572598 35.746 35.668420211872316 139.73916348572598 12.15 35.668543347978606 139.73928970742222 12.15 35.668543347978606 139.73928970742222 29.605 35.66853899987777 139.73928524993568 29.605 35.66853899987777 139.73928524993568 31.17 35.66844606595546 139.73918998783694 31.17 35.66844606595546 139.73918998783694 35.746 35.668420211872316 139.73916348572598 35.746</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1f714acc-d736-4f21-9548-b13d053426a4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f714acc-d736-4f21-9548-b13d053426a4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f714acc-d736-4f21-9548-b13d053426a4">
											<gml:posList>35.66848402312464 139.73907519744324 35.746 35.66848402312464 139.73907519744324 34.812 35.6685057185543 139.7390974296316 34.812 35.6685057185543 139.7390974296316 35.746 35.66848402312464 139.73907519744324 35.746</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-91050073-44f7-460b-855f-fa3d6b69b1d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-91050073-44f7-460b-855f-fa3d6b69b1d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-91050073-44f7-460b-855f-fa3d6b69b1d6">
											<gml:posList>35.668606822152974 139.7391967359894 12.15 35.668483685950605 139.73907051433642 12.15 35.668483685950605 139.73907051433642 35.746 35.668509531031546 139.7390970054029 35.746 35.668509531031546 139.7390970054029 31.17 35.66860082321578 139.73919059040242 31.17 35.66860082321578 139.73919059040242 29.605 35.668606822152974 139.7391967359894 29.605 35.668606822152974 139.7391967359894 12.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-357e449e-2652-4622-9fd2-bd6f6254f102">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-357e449e-2652-4622-9fd2-bd6f6254f102">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-357e449e-2652-4622-9fd2-bd6f6254f102">
											<gml:posList>35.66859761464056 139.7391909918261 31.17 35.66859761464056 139.7391909918261 30.562 35.66853866322955 139.7392812295845 30.562 35.66853866322955 139.7392812295845 31.17 35.66859761464056 139.7391909918261 31.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-20f11f2f-030b-42cf-8b5c-bce2781a4322">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20f11f2f-030b-42cf-8b5c-bce2781a4322">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20f11f2f-030b-42cf-8b5c-bce2781a4322">
											<gml:posList>35.66860082321578 139.73919059040242 29.605 35.66860082321578 139.73919059040242 31.17 35.66853899987777 139.73928524993568 31.17 35.66853899987777 139.73928524993568 29.605 35.66860082321578 139.73919059040242 29.605</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8522bbdb-5a8b-428c-88b9-b55fa73d3de1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8522bbdb-5a8b-428c-88b9-b55fa73d3de1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8522bbdb-5a8b-428c-88b9-b55fa73d3de1">
											<gml:posList>35.668543347978606 139.73928970742222 12.15 35.668606822152974 139.7391967359894 12.15 35.668606822152974 139.7391967359894 29.605 35.668543347978606 139.73928970742222 29.605 35.668543347978606 139.73928970742222 12.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2895</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">195.4485</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1002</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">12</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>