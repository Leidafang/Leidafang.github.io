<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_8da2f3f8-ef60-4103-8c51-7bc79e714f1c">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">15.3</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.6709182460669 139.74059800010846 0 35.670896071152725 139.74063163974085 0 35.670985555530336 139.74072023840955 0 35.671007739482576 139.74068659875365 0 35.6709182460669 139.74059800010846 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6709182460669 139.74059800010846 9.716 35.671007739482576 139.74068659875365 9.716 35.670985555530336 139.74072023840955 9.716 35.670896071152725 139.74063163974085 9.716 35.6709182460669 139.74059800010846 9.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6709182460669 139.74059800010846 9.716 35.670896071152725 139.74063163974085 9.716 35.670896071152725 139.74063163974085 25.04 35.6709182460669 139.74059800010846 25.04 35.6709182460669 139.74059800010846 9.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670896071152725 139.74063163974085 9.716 35.670985555530336 139.74072023840955 9.716 35.670985555530336 139.74072023840955 25.04 35.670896071152725 139.74063163974085 25.04 35.670896071152725 139.74063163974085 9.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670985555530336 139.74072023840955 9.716 35.671007739482576 139.74068659875365 9.716 35.671007739482576 139.74068659875365 25.04 35.670985555530336 139.74072023840955 25.04 35.670985555530336 139.74072023840955 9.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671007739482576 139.74068659875365 9.716 35.6709182460669 139.74059800010846 9.716 35.6709182460669 139.74059800010846 25.04 35.671007739482576 139.74068659875365 25.04 35.671007739482576 139.74068659875365 9.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6709182460669 139.74059800010846 25.04 35.670896071152725 139.74063163974085 25.04 35.670985555530336 139.74072023840955 25.04 35.671007739482576 139.74068659875365 25.04 35.6709182460669 139.74059800010846 25.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-ec6e01bb-bada-4964-aa31-5b7c8c589952"/>
							<gml:surfaceMember xlink:href="#poly-dfcaf3de-24f3-49bf-bc95-824cc7d1454d"/>
							<gml:surfaceMember xlink:href="#poly-b5f4a314-28d3-455f-86f4-ab13b3306331"/>
							<gml:surfaceMember xlink:href="#poly-8037985e-34af-4cd0-9abd-d091d8f503c3"/>
							<gml:surfaceMember xlink:href="#poly-56c72473-310b-455a-b0e0-7484842921e5"/>
							<gml:surfaceMember xlink:href="#poly-da26bb0e-e419-4dde-8652-b6609c25f234"/>
							<gml:surfaceMember xlink:href="#poly-c2f79fca-13a5-45ac-a1dc-a60b8e32fe06"/>
							<gml:surfaceMember xlink:href="#poly-870a6b01-e000-4cfa-809a-7457aa572145"/>
							<gml:surfaceMember xlink:href="#poly-441aa641-593a-4730-8fca-15122a30ab58"/>
							<gml:surfaceMember xlink:href="#poly-c3164506-980c-4e81-bbdc-58b4d08a6b3a"/>
							<gml:surfaceMember xlink:href="#poly-5cebcb12-1683-4000-be86-a2e379f35104"/>
							<gml:surfaceMember xlink:href="#poly-d4871799-5d92-435a-92fc-fd9796774382"/>
							<gml:surfaceMember xlink:href="#poly-f59b64c9-04c6-436e-8549-5e82bad62548"/>
							<gml:surfaceMember xlink:href="#poly-5204ea78-4829-421f-ba1c-525b37d1711b"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-ec6e01bb-bada-4964-aa31-5b7c8c589952">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec6e01bb-bada-4964-aa31-5b7c8c589952">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec6e01bb-bada-4964-aa31-5b7c8c589952">
											<gml:posList>35.67091824606686 139.74059800010846 9.716 35.671007739482576 139.74068659875363 9.716 35.67098555553031 139.74072023840955 9.716 35.67089607115272 139.74063163974083 9.716 35.67091824606686 139.74059800010846 9.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dfcaf3de-24f3-49bf-bc95-824cc7d1454d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dfcaf3de-24f3-49bf-bc95-824cc7d1454d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dfcaf3de-24f3-49bf-bc95-824cc7d1454d">
											<gml:posList>35.67089607115272 139.74063163974083 25.346 35.67089986556399 139.7406311603614 25.346 35.67091865526582 139.7406026501416 25.346 35.67091824606686 139.74059800010846 25.346 35.67089607115272 139.74063163974083 25.346</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b5f4a314-28d3-455f-86f4-ab13b3306331">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b5f4a314-28d3-455f-86f4-ab13b3306331">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b5f4a314-28d3-455f-86f4-ab13b3306331">
											<gml:posList>35.67091824606686 139.74059800010846 25.346 35.67091865526582 139.7406026501416 25.346 35.671003954093386 139.740687089167 25.346 35.671007739482576 139.74068659875363 25.346 35.67091824606686 139.74059800010846 25.346</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8037985e-34af-4cd0-9abd-d091d8f503c3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8037985e-34af-4cd0-9abd-d091d8f503c3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8037985e-34af-4cd0-9abd-d091d8f503c3">
											<gml:posList>35.671003954093386 139.740687089167 24.682 35.67091865526582 139.7406026501416 24.682 35.67089986556399 139.7406311603614 24.682 35.670985155358096 139.7407155994078 24.682 35.671003954093386 139.740687089167 24.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-56c72473-310b-455a-b0e0-7484842921e5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56c72473-310b-455a-b0e0-7484842921e5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56c72473-310b-455a-b0e0-7484842921e5">
											<gml:posList>35.67098555553031 139.74072023840955 25.346 35.670985155358096 139.7407155994078 25.346 35.67089986556399 139.7406311603614 25.346 35.67089607115272 139.74063163974083 25.346 35.67098555553031 139.74072023840955 25.346</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-da26bb0e-e419-4dde-8652-b6609c25f234">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da26bb0e-e419-4dde-8652-b6609c25f234">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da26bb0e-e419-4dde-8652-b6609c25f234">
											<gml:posList>35.671007739482576 139.74068659875363 25.346 35.671003954093386 139.740687089167 25.346 35.670985155358096 139.7407155994078 25.346 35.67098555553031 139.74072023840955 25.346 35.671007739482576 139.74068659875363 25.346</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c2f79fca-13a5-45ac-a1dc-a60b8e32fe06">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c2f79fca-13a5-45ac-a1dc-a60b8e32fe06">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c2f79fca-13a5-45ac-a1dc-a60b8e32fe06">
											<gml:posList>35.67091865526582 139.7406026501416 25.346 35.67091865526582 139.7406026501416 24.682 35.671003954093386 139.740687089167 24.682 35.671003954093386 139.740687089167 25.346 35.67091865526582 139.7406026501416 25.346</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-870a6b01-e000-4cfa-809a-7457aa572145">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-870a6b01-e000-4cfa-809a-7457aa572145">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-870a6b01-e000-4cfa-809a-7457aa572145">
											<gml:posList>35.670985155358096 139.7407155994078 25.346 35.670985155358096 139.7407155994078 24.682 35.67089986556399 139.7406311603614 24.682 35.67089986556399 139.7406311603614 25.346 35.670985155358096 139.7407155994078 25.346</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-441aa641-593a-4730-8fca-15122a30ab58">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-441aa641-593a-4730-8fca-15122a30ab58">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-441aa641-593a-4730-8fca-15122a30ab58">
											<gml:posList>35.67091824606686 139.74059800010846 9.716 35.67089607115272 139.74063163974083 9.716 35.67089607115272 139.74063163974083 25.346 35.67091824606686 139.74059800010846 25.346 35.67091824606686 139.74059800010846 9.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c3164506-980c-4e81-bbdc-58b4d08a6b3a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3164506-980c-4e81-bbdc-58b4d08a6b3a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3164506-980c-4e81-bbdc-58b4d08a6b3a">
											<gml:posList>35.67089986556399 139.7406311603614 25.346 35.67089986556399 139.7406311603614 24.682 35.67091865526582 139.7406026501416 24.682 35.67091865526582 139.7406026501416 25.346 35.67089986556399 139.7406311603614 25.346</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5cebcb12-1683-4000-be86-a2e379f35104">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5cebcb12-1683-4000-be86-a2e379f35104">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5cebcb12-1683-4000-be86-a2e379f35104">
											<gml:posList>35.67089607115272 139.74063163974083 9.716 35.67098555553031 139.74072023840955 9.716 35.67098555553031 139.74072023840955 25.346 35.67089607115272 139.74063163974083 25.346 35.67089607115272 139.74063163974083 9.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d4871799-5d92-435a-92fc-fd9796774382">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4871799-5d92-435a-92fc-fd9796774382">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4871799-5d92-435a-92fc-fd9796774382">
											<gml:posList>35.671007739482576 139.74068659875363 9.716 35.67091824606686 139.74059800010846 9.716 35.67091824606686 139.74059800010846 25.346 35.671007739482576 139.74068659875363 25.346 35.671007739482576 139.74068659875363 9.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f59b64c9-04c6-436e-8549-5e82bad62548">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f59b64c9-04c6-436e-8549-5e82bad62548">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f59b64c9-04c6-436e-8549-5e82bad62548">
											<gml:posList>35.671003954093386 139.740687089167 25.346 35.671003954093386 139.740687089167 24.682 35.670985155358096 139.7407155994078 24.682 35.670985155358096 139.7407155994078 25.346 35.671003954093386 139.740687089167 25.346</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5204ea78-4829-421f-ba1c-525b37d1711b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5204ea78-4829-421f-ba1c-525b37d1711b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5204ea78-4829-421f-ba1c-525b37d1711b">
											<gml:posList>35.67098555553031 139.74072023840955 9.716 35.671007739482576 139.74068659875363 9.716 35.671007739482576 139.74068659875363 25.346 35.67098555553031 139.74072023840955 25.346 35.67098555553031 139.74072023840955 9.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5909</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>