<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_8e672b9c-42be-413d-9d21-fb6033b80005">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">18.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>7</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67025834557738 139.74156764036377 0 35.67028505489815 139.7416052774946 0 35.67030634389872 139.7415797363027 0 35.670309447153876 139.74144121277885 0 35.67030944639519 139.74144021861724 0 35.670217052951266 139.74143667925253 0 35.67021345142708 139.74156006984302 0 35.670258521558424 139.7415620065785 0 35.67025834557738 139.74156764036377 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67025834557738 139.74156764036377 8.42 35.670258521558424 139.7415620065785 8.42 35.67021345142708 139.74156006984302 8.42 35.670217052951266 139.74143667925253 8.42 35.67030944639519 139.74144021861724 8.42 35.670309447153876 139.74144121277885 8.42 35.67030634389872 139.7415797363027 8.42 35.67028505489815 139.7416052774946 8.42 35.67025834557738 139.74156764036377 8.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67025834557738 139.74156764036377 8.42 35.67028505489815 139.7416052774946 8.42 35.67028505489815 139.7416052774946 24.700000000000003 35.67025834557738 139.74156764036377 24.700000000000003 35.67025834557738 139.74156764036377 8.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67028505489815 139.7416052774946 8.42 35.67030634389872 139.7415797363027 8.42 35.67030634389872 139.7415797363027 24.700000000000003 35.67028505489815 139.7416052774946 24.700000000000003 35.67028505489815 139.7416052774946 8.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67030634389872 139.7415797363027 8.42 35.670309447153876 139.74144121277885 8.42 35.670309447153876 139.74144121277885 24.700000000000003 35.67030634389872 139.7415797363027 24.700000000000003 35.67030634389872 139.7415797363027 8.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670309447153876 139.74144121277885 8.42 35.67030944639519 139.74144021861724 8.42 35.67030944639519 139.74144021861724 24.700000000000003 35.670309447153876 139.74144121277885 24.700000000000003 35.670309447153876 139.74144121277885 8.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67030944639519 139.74144021861724 8.42 35.670217052951266 139.74143667925253 8.42 35.670217052951266 139.74143667925253 24.700000000000003 35.67030944639519 139.74144021861724 24.700000000000003 35.67030944639519 139.74144021861724 8.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670217052951266 139.74143667925253 8.42 35.67021345142708 139.74156006984302 8.42 35.67021345142708 139.74156006984302 24.700000000000003 35.670217052951266 139.74143667925253 24.700000000000003 35.670217052951266 139.74143667925253 8.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67021345142708 139.74156006984302 8.42 35.670258521558424 139.7415620065785 8.42 35.670258521558424 139.7415620065785 24.700000000000003 35.67021345142708 139.74156006984302 24.700000000000003 35.67021345142708 139.74156006984302 8.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670258521558424 139.7415620065785 8.42 35.67025834557738 139.74156764036377 8.42 35.67025834557738 139.74156764036377 24.700000000000003 35.670258521558424 139.7415620065785 24.700000000000003 35.670258521558424 139.7415620065785 8.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67025834557738 139.74156764036377 24.700000000000003 35.67028505489815 139.7416052774946 24.700000000000003 35.67030634389872 139.7415797363027 24.700000000000003 35.670309447153876 139.74144121277885 24.700000000000003 35.67030944639519 139.74144021861724 24.700000000000003 35.670217052951266 139.74143667925253 24.700000000000003 35.67021345142708 139.74156006984302 24.700000000000003 35.670258521558424 139.7415620065785 24.700000000000003 35.67025834557738 139.74156764036377 24.700000000000003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-b2808274-34e6-45c8-b6e0-db954333599c"/>
							<gml:surfaceMember xlink:href="#poly-526ec4f8-e63e-4e26-98c8-5557b36b0a72"/>
							<gml:surfaceMember xlink:href="#poly-3acfc0fd-7023-47f7-bb09-c0571635dcbc"/>
							<gml:surfaceMember xlink:href="#poly-d91ea122-f437-4a7e-8823-a62c99f0a976"/>
							<gml:surfaceMember xlink:href="#poly-4ec2e539-5afd-4dd1-9240-31949a21fdbc"/>
							<gml:surfaceMember xlink:href="#poly-71bda7e8-8827-42a4-85f5-615ebe615e3d"/>
							<gml:surfaceMember xlink:href="#poly-9a3a5116-d613-4d18-aa5a-dbe864c6c603"/>
							<gml:surfaceMember xlink:href="#poly-7fcdefd6-c0d2-4d55-a397-af7c50beaa29"/>
							<gml:surfaceMember xlink:href="#poly-42c8ff0b-5c24-43b3-b9c1-b2ba7a7ac27e"/>
							<gml:surfaceMember xlink:href="#poly-f07ec91d-64d4-4774-a3c7-f61bcc7ef49c"/>
							<gml:surfaceMember xlink:href="#poly-36469de4-6167-4309-a869-f372a1df1e3f"/>
							<gml:surfaceMember xlink:href="#poly-df7d2cf8-b7ca-4813-99bb-278ccc503353"/>
							<gml:surfaceMember xlink:href="#poly-9282a740-8f53-4a9e-8ae0-e23e2f81dc6f"/>
							<gml:surfaceMember xlink:href="#poly-ed70ba9e-3c39-42b5-bd18-fb04966c8273"/>
							<gml:surfaceMember xlink:href="#poly-4466d246-c036-4097-8ee7-34b31929a0cf"/>
							<gml:surfaceMember xlink:href="#poly-1295c337-4918-4a79-8d74-c6f66f5daa69"/>
							<gml:surfaceMember xlink:href="#poly-9e88ac56-f170-4f41-abd5-2f7d10d0a78a"/>
							<gml:surfaceMember xlink:href="#poly-0358aaaa-89b1-4945-9dd5-f575bd061744"/>
							<gml:surfaceMember xlink:href="#poly-85d54c33-4d52-44cb-af2a-a2c74c891547"/>
							<gml:surfaceMember xlink:href="#poly-3c6734cc-a1f1-4a71-a639-c922358b2c4a"/>
							<gml:surfaceMember xlink:href="#poly-fa0b2deb-6e39-47c1-9ac8-dd99e1afccbe"/>
							<gml:surfaceMember xlink:href="#poly-12aa78ef-0444-4742-9b26-e364a0c1bfff"/>
							<gml:surfaceMember xlink:href="#poly-8cb9db70-aa5a-4902-af28-9289279abedd"/>
							<gml:surfaceMember xlink:href="#poly-1af2032b-1680-4320-86ba-720fdf1ede71"/>
							<gml:surfaceMember xlink:href="#poly-5e00e29a-79a7-4389-b2dd-461138598a1c"/>
							<gml:surfaceMember xlink:href="#poly-94315012-9186-436b-b5cc-a23878f3b5d0"/>
							<gml:surfaceMember xlink:href="#poly-1e6d79e2-763e-4eaf-9ec1-32bd8be19f89"/>
							<gml:surfaceMember xlink:href="#poly-b94adae9-8231-4699-9929-6288884a9e91"/>
							<gml:surfaceMember xlink:href="#poly-b980b6b1-0b5f-4b74-877e-071ee8823f49"/>
							<gml:surfaceMember xlink:href="#poly-3ac4530f-f228-46ff-9bed-453e6a39128f"/>
							<gml:surfaceMember xlink:href="#poly-1f39dd1d-f897-4ec7-a6bf-d5d211316edd"/>
							<gml:surfaceMember xlink:href="#poly-b55864f4-d1c6-44cd-af74-8a24fc85cf6c"/>
							<gml:surfaceMember xlink:href="#poly-7fa12a35-ddb0-42ad-8b6e-c6fc66717c5f"/>
							<gml:surfaceMember xlink:href="#poly-ac32b90b-da3e-40d9-81a3-a35d4e8510c5"/>
							<gml:surfaceMember xlink:href="#poly-557eecf2-c9e0-442b-9388-594ca0c7b9ae"/>
							<gml:surfaceMember xlink:href="#poly-16e04dd3-2e5d-43ed-8f1a-c098a4aafe91"/>
							<gml:surfaceMember xlink:href="#poly-dca14963-c4f8-4adf-a140-362e09fcb1d6"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_8e672b9c-42be-413d-9d21-fb6033b80005_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7aa0e740-203d-4950-8fa7-cbb678a1e988">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670235561551294 139.74155933757598 24.631 35.67022067037543 139.7415586918466 24.631 35.67022074080138 139.74155648251843 24.631 35.67023563196043 139.74155710615497 24.631 35.670235561551294 139.74155933757598 24.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-948fbad3-99f6-4572-8947-4fe4bc2d1a04">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67022118958909 139.74154216608076 24.107 35.67023608977877 139.74154281179676 24.107 35.67023563196043 139.74155710615497 24.107 35.67022074080138 139.74155648251843 24.107 35.67022118958909 139.74154216608076 24.107</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-39dcbc3f-47f0-4c0d-aa58-7d230e38688d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670264828785875 139.74151158430323 33.476 35.6702719679073 139.74151190751468 33.476 35.67027144068627 139.7415297478034 33.476 35.67026429255116 139.7415294246007 33.476 35.670264828785875 139.74151158430323 33.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a3697405-7502-421c-bab4-5e02a74c5c88">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670288878241486 139.74151266138585 33.476 35.67028835964668 139.74152999354115 33.476 35.67028077883604 139.74152964874128 33.476 35.67028129743081 139.74151231658763 33.476 35.670288878241486 139.74151266138585 33.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b469ad4-9c56-491a-932b-63bdb05cfb38">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670289010010556 139.7415081543662 33.476 35.670281780751914 139.74150783125825 33.476 35.670282325719114 139.7414896264206 33.476 35.6702895549778 139.74148994952688 33.476 35.670289010010556 139.7415081543662 33.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a4ecf51-69cb-4943-95f6-3ed322c06764">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5a4ecf51-69cb-4943-95f6-3ed322c06764_0">
											<gml:posList>35.670289010010556 139.7415081543662 33.476 35.670289010010556 139.7415081543662 35.08 35.670281780751914 139.74150783125825 35.08 35.670281780751914 139.74150783125825 33.476 35.670289010010556 139.7415081543662 33.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2725f44b-45fd-4e90-a846-5b48b6ba9250">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2725f44b-45fd-4e90-a846-5b48b6ba9250_0">
											<gml:posList>35.670264828785875 139.74151158430323 33.476 35.67026429255116 139.7415294246007 33.476 35.67026429255116 139.7415294246007 35.08 35.670264828785875 139.74151158430323 35.08 35.670264828785875 139.74151158430323 33.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-725f5e86-3d38-407b-ae6f-e03c1699340d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-725f5e86-3d38-407b-ae6f-e03c1699340d_0">
											<gml:posList>35.67023608977877 139.74154281179676 24.107 35.67022118958909 139.74154216608076 24.107 35.67022118958909 139.74154216608076 25.614 35.67023608977877 139.74154281179676 25.614 35.67023608977877 139.74154281179676 24.107</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38eb2a61-d3c8-44bb-86ca-1d3df5bbfa84">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-38eb2a61-d3c8-44bb-86ca-1d3df5bbfa84_0">
											<gml:posList>35.67022067037543 139.7415586918466 25.614 35.67022118958909 139.74154216608076 25.614 35.67022118958909 139.74154216608076 24.107 35.67022074080138 139.74155648251843 24.107 35.67022074080138 139.74155648251843 24.631 35.67022067037543 139.7415586918466 24.631 35.67022067037543 139.7415586918466 25.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-28f26951-8a82-4d2a-a76a-e80df02e5cf3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-28f26951-8a82-4d2a-a76a-e80df02e5cf3_0">
											<gml:posList>35.67022118958909 139.74154216608076 25.614 35.67022067037543 139.7415586918466 25.614 35.670235561551294 139.74155933757598 25.614 35.67023608977877 139.74154281179676 25.614 35.67022118958909 139.74154216608076 25.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48c667b2-88b6-4a37-a8e2-d2b1fa03d3b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-48c667b2-88b6-4a37-a8e2-d2b1fa03d3b8_0">
											<gml:posList>35.67023608977877 139.74154281179676 24.107 35.67023608977877 139.74154281179676 25.614 35.670235561551294 139.74155933757598 25.614 35.670235561551294 139.74155933757598 24.631 35.67023563196043 139.74155710615497 24.631 35.67023563196043 139.74155710615497 24.107 35.67023608977877 139.74154281179676 24.107</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bce804df-87c4-4363-83f3-30f80a370c68">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bce804df-87c4-4363-83f3-30f80a370c68_0">
											<gml:posList>35.67023563196043 139.74155710615497 24.631 35.67022074080138 139.74155648251843 24.631 35.67022074080138 139.74155648251843 24.107 35.67023563196043 139.74155710615497 24.107 35.67023563196043 139.74155710615497 24.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-06f582b0-e60b-4a6f-b4cd-aff41da7f782">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-06f582b0-e60b-4a6f-b4cd-aff41da7f782_0">
											<gml:posList>35.670235561551294 139.74155933757598 24.631 35.670235561551294 139.74155933757598 25.614 35.67022067037543 139.7415586918466 25.614 35.67022067037543 139.7415586918466 24.631 35.670235561551294 139.74155933757598 24.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-835647b6-c91e-4cf7-8672-55907f440fdd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-835647b6-c91e-4cf7-8672-55907f440fdd_0">
											<gml:posList>35.6702895549778 139.74148994952688 33.476 35.670282325719114 139.7414896264206 33.476 35.670282325719114 139.7414896264206 35.08 35.6702895549778 139.74148994952688 35.08 35.6702895549778 139.74148994952688 33.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3875b956-284a-4861-ae8c-f4ed1b6011d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3875b956-284a-4861-ae8c-f4ed1b6011d8_0">
											<gml:posList>35.670281780751914 139.74150783125825 33.476 35.670281780751914 139.74150783125825 35.08 35.670282325719114 139.7414896264206 35.08 35.670282325719114 139.7414896264206 33.476 35.670281780751914 139.74150783125825 33.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3cfa2f9-60b5-47e0-9628-6068ed05a91f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3cfa2f9-60b5-47e0-9628-6068ed05a91f_0">
											<gml:posList>35.670282325719114 139.7414896264206 35.08 35.670281780751914 139.74150783125825 35.08 35.670289010010556 139.7415081543662 35.08 35.6702895549778 139.74148994952688 35.08 35.670282325719114 139.7414896264206 35.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9967415d-87a7-41d7-bf00-d908f8e9b413">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9967415d-87a7-41d7-bf00-d908f8e9b413_0">
											<gml:posList>35.6702895549778 139.74148994952688 33.476 35.6702895549778 139.74148994952688 35.08 35.670289010010556 139.7415081543662 35.08 35.670289010010556 139.7415081543662 33.476 35.6702895549778 139.74148994952688 33.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c4510946-3424-4f5a-afd8-5fa8ad67bd8a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c4510946-3424-4f5a-afd8-5fa8ad67bd8a_0">
											<gml:posList>35.6702719679073 139.74151190751468 33.476 35.670264828785875 139.74151158430323 33.476 35.670264828785875 139.74151158430323 35.08 35.6702719679073 139.74151190751468 35.08 35.6702719679073 139.74151190751468 33.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6feed49f-eea1-458a-a60b-5faf8bec6b12">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6feed49f-eea1-458a-a60b-5faf8bec6b12_0">
											<gml:posList>35.670288878241486 139.74151266138585 33.476 35.67028129743081 139.74151231658763 33.476 35.67028129743081 139.74151231658763 35.08 35.670288878241486 139.74151266138585 35.08 35.670288878241486 139.74151266138585 33.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1e6bed3-ae59-43a0-84be-72f8fcc82a9b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c1e6bed3-ae59-43a0-84be-72f8fcc82a9b_0">
											<gml:posList>35.670264828785875 139.74151158430323 35.08 35.67026429255116 139.7415294246007 35.08 35.67027144068627 139.7415297478034 35.08 35.6702719679073 139.74151190751468 35.08 35.670264828785875 139.74151158430323 35.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-42610f41-f29e-43ee-8bc2-9e4327f6dd90">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-42610f41-f29e-43ee-8bc2-9e4327f6dd90_0">
											<gml:posList>35.67027144068627 139.7415297478034 33.476 35.6702719679073 139.74151190751468 33.476 35.6702719679073 139.74151190751468 35.08 35.67027144068627 139.7415297478034 35.08 35.67027144068627 139.7415297478034 33.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e0e82f26-b8b4-4f98-b7e0-5b63581e369f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e0e82f26-b8b4-4f98-b7e0-5b63581e369f_0">
											<gml:posList>35.67028129743081 139.74151231658763 33.476 35.67028077883604 139.74152964874128 33.476 35.67028077883604 139.74152964874128 35.08 35.67028129743081 139.74151231658763 35.08 35.67028129743081 139.74151231658763 33.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29d91667-ecda-43b6-8154-64abeded14e6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29d91667-ecda-43b6-8154-64abeded14e6_0">
											<gml:posList>35.67028077883604 139.74152964874128 35.08 35.67028835964668 139.74152999354115 35.08 35.670288878241486 139.74151266138585 35.08 35.67028129743081 139.74151231658763 35.08 35.67028077883604 139.74152964874128 35.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94950434-3bb4-48be-869e-e84ae0c45e06">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-94950434-3bb4-48be-869e-e84ae0c45e06_0">
											<gml:posList>35.670288878241486 139.74151266138585 33.476 35.670288878241486 139.74151266138585 35.08 35.67028835964668 139.74152999354115 35.08 35.67028835964668 139.74152999354115 33.476 35.670288878241486 139.74151266138585 33.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1a4294f-abd0-4319-9dbd-03f375d13e15">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a1a4294f-abd0-4319-9dbd-03f375d13e15_0">
											<gml:posList>35.67027144068627 139.7415297478034 33.476 35.67027144068627 139.7415297478034 35.08 35.67026429255116 139.7415294246007 35.08 35.67026429255116 139.7415294246007 33.476 35.67027144068627 139.7415297478034 33.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4bde03f6-0e67-4a60-8b98-b51c6208cf13">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4bde03f6-0e67-4a60-8b98-b51c6208cf13_0">
											<gml:posList>35.67028077883604 139.74152964874128 33.476 35.67028835964668 139.74152999354115 33.476 35.67028835964668 139.74152999354115 35.08 35.67028077883604 139.74152964874128 35.08 35.67028077883604 139.74152964874128 33.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-b2808274-34e6-45c8-b6e0-db954333599c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b2808274-34e6-45c8-b6e0-db954333599c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b2808274-34e6-45c8-b6e0-db954333599c">
											<gml:posList>35.67028505489812 139.7416052774946 8.42 35.67025834557738 139.74156764036377 8.42 35.670258521558424 139.7415620065785 8.42 35.670213451427074 139.741560069843 8.42 35.670217052951266 139.7414366792525 8.42 35.67030944639517 139.74144021861724 8.42 35.67030944715386 139.74144121277885 8.42 35.67030634389873 139.74157973630267 8.42 35.67028505489812 139.7416052774946 8.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-526ec4f8-e63e-4e26-98c8-5557b36b0a72">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-526ec4f8-e63e-4e26-98c8-5557b36b0a72">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-526ec4f8-e63e-4e26-98c8-5557b36b0a72">
											<gml:posList>35.67030944715386 139.74144121277885 34.262 35.67030944639517 139.74144021861724 34.262 35.67030655557801 139.74144361312904 34.262 35.67030944715386 139.74144121277885 34.262</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3acfc0fd-7023-47f7-bb09-c0571635dcbc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3acfc0fd-7023-47f7-bb09-c0571635dcbc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3acfc0fd-7023-47f7-bb09-c0571635dcbc">
											<gml:posList>35.6702200665612 139.7414406413977 23.586 35.67026174742484 139.74144243834948 23.586 35.67026185267277 139.7414386162287 23.586 35.670217052951266 139.7414366792525 23.586 35.6702200665612 139.7414406413977 23.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d91ea122-f437-4a7e-8823-a62c99f0a976">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d91ea122-f437-4a7e-8823-a62c99f0a976">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d91ea122-f437-4a7e-8823-a62c99f0a976">
											<gml:posList>35.67026185267277 139.7414386162287 34.262 35.67026460459804 139.7414422031038 34.262 35.67030655557801 139.74144361312904 34.262 35.67030944639517 139.74144021861724 34.262 35.67026185267277 139.7414386162287 34.262</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4ec2e539-5afd-4dd1-9240-31949a21fdbc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ec2e539-5afd-4dd1-9240-31949a21fdbc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ec2e539-5afd-4dd1-9240-31949a21fdbc">
											<gml:posList>35.6702200665612 139.7414406413977 23.586 35.670217052951266 139.7414366792525 23.586 35.670215313767756 139.7414963640635 23.586 35.67021845064453 139.74149649302532 23.586 35.6702200665612 139.7414406413977 23.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-71bda7e8-8827-42a4-85f5-615ebe615e3d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-71bda7e8-8827-42a4-85f5-615ebe615e3d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-71bda7e8-8827-42a4-85f5-615ebe615e3d">
											<gml:posList>35.67026024860997 139.74149819045576 22.934 35.67026174742484 139.74144243834948 22.934 35.6702200665612 139.7414406413977 22.934 35.67021845064453 139.74149649302532 22.934 35.67026024860997 139.74149819045576 22.934</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9a3a5116-d613-4d18-aa5a-dbe864c6c603">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a3a5116-d613-4d18-aa5a-dbe864c6c603">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a3a5116-d613-4d18-aa5a-dbe864c6c603">
											<gml:posList>35.67021838151704 139.7415004034725 24.631 35.67026014341911 139.74150208990005 24.631 35.67026024860997 139.74149819045576 24.631 35.670215313767756 139.7414963640635 24.631 35.67021838151704 139.7415004034725 24.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7fcdefd6-c0d2-4d55-a397-af7c50beaa29">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7fcdefd6-c0d2-4d55-a397-af7c50beaa29">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7fcdefd6-c0d2-4d55-a397-af7c50beaa29">
											<gml:posList>35.67025834557738 139.74156764036377 34.262 35.67026122901752 139.7415663888381 34.262 35.67026460459804 139.7414422031038 34.262 35.67026185267277 139.7414386162287 34.262 35.67025834557738 139.74156764036377 34.262</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-42c8ff0b-5c24-43b3-b9c1-b2ba7a7ac27e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-42c8ff0b-5c24-43b3-b9c1-b2ba7a7ac27e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-42c8ff0b-5c24-43b3-b9c1-b2ba7a7ac27e">
											<gml:posList>35.67030634389873 139.74157973630267 34.262 35.67030944715386 139.74144121277885 34.262 35.67030655557801 139.74144361312904 34.262 35.670303539486106 139.74157823722211 34.262 35.67030634389873 139.74157973630267 34.262</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f07ec91d-64d4-4774-a3c7-f61bcc7ef49c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f07ec91d-64d4-4774-a3c7-f61bcc7ef49c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f07ec91d-64d4-4774-a3c7-f61bcc7ef49c">
											<gml:posList>35.67026122901752 139.7415663888381 33.476 35.6702852313101 139.74160020706566 33.476 35.670303539486106 139.74157823722211 33.476 35.67030655557801 139.74144361312904 33.476 35.67026460459804 139.7414422031038 33.476 35.67026122901752 139.7415663888381 33.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-36469de4-6167-4309-a869-f372a1df1e3f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36469de4-6167-4309-a869-f372a1df1e3f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36469de4-6167-4309-a869-f372a1df1e3f">
											<gml:posList>35.670213451427074 139.741560069843 24.631 35.67021674758729 139.74155631034955 24.631 35.67021838151704 139.7415004034725 24.631 35.670215313767756 139.7414963640635 24.631 35.670213451427074 139.741560069843 24.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-df7d2cf8-b7ca-4813-99bb-278ccc503353">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df7d2cf8-b7ca-4813-99bb-278ccc503353">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df7d2cf8-b7ca-4813-99bb-278ccc503353">
											<gml:posList>35.670258626734395 139.74155808504193 24.107 35.67026014341911 139.74150208990005 24.107 35.67021838151704 139.7415004034725 24.107 35.67021674758729 139.74155631034955 24.107 35.670258626734395 139.74155808504193 24.107</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9282a740-8f53-4a9e-8ae0-e23e2f81dc6f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9282a740-8f53-4a9e-8ae0-e23e2f81dc6f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9282a740-8f53-4a9e-8ae0-e23e2f81dc6f">
											<gml:posList>35.67021674758729 139.74155631034955 24.631 35.670213451427074 139.741560069843 24.631 35.670258521558424 139.7415620065785 24.631 35.670258626734395 139.74155808504193 24.631 35.67021674758729 139.74155631034955 24.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ed70ba9e-3c39-42b5-bd18-fb04966c8273">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed70ba9e-3c39-42b5-bd18-fb04966c8273">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed70ba9e-3c39-42b5-bd18-fb04966c8273">
											<gml:posList>35.67025834557738 139.74156764036377 34.262 35.67028505489812 139.7416052774946 34.262 35.6702852313101 139.74160020706566 34.262 35.67026122901752 139.7415663888381 34.262 35.67025834557738 139.74156764036377 34.262</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4466d246-c036-4097-8ee7-34b31929a0cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4466d246-c036-4097-8ee7-34b31929a0cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4466d246-c036-4097-8ee7-34b31929a0cf">
											<gml:posList>35.67030634389873 139.74157973630267 34.262 35.670303539486106 139.74157823722211 34.262 35.6702852313101 139.74160020706566 34.262 35.67028505489812 139.7416052774946 34.262 35.67030634389873 139.74157973630267 34.262</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1295c337-4918-4a79-8d74-c6f66f5daa69">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1295c337-4918-4a79-8d74-c6f66f5daa69">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1295c337-4918-4a79-8d74-c6f66f5daa69">
											<gml:posList>35.670217052951266 139.7414366792525 8.42 35.670213451427074 139.741560069843 8.42 35.670213451427074 139.741560069843 24.631 35.670215313767756 139.7414963640635 24.631 35.670215313767756 139.7414963640635 23.586 35.670217052951266 139.7414366792525 23.586 35.670217052951266 139.7414366792525 8.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9e88ac56-f170-4f41-abd5-2f7d10d0a78a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e88ac56-f170-4f41-abd5-2f7d10d0a78a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e88ac56-f170-4f41-abd5-2f7d10d0a78a">
											<gml:posList>35.67021674758729 139.74155631034955 24.631 35.67021674758729 139.74155631034955 24.107 35.67021838151704 139.7415004034725 24.107 35.67021838151704 139.7415004034725 24.631 35.67021674758729 139.74155631034955 24.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0358aaaa-89b1-4945-9dd5-f575bd061744">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0358aaaa-89b1-4945-9dd5-f575bd061744">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0358aaaa-89b1-4945-9dd5-f575bd061744">
											<gml:posList>35.67021845064453 139.74149649302532 23.586 35.67021845064453 139.74149649302532 22.934 35.6702200665612 139.7414406413977 22.934 35.6702200665612 139.7414406413977 23.586 35.67021845064453 139.74149649302532 23.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-85d54c33-4d52-44cb-af2a-a2c74c891547">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85d54c33-4d52-44cb-af2a-a2c74c891547">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85d54c33-4d52-44cb-af2a-a2c74c891547">
											<gml:posList>35.670213451427074 139.741560069843 8.42 35.670258521558424 139.7415620065785 8.42 35.670258521558424 139.7415620065785 24.631 35.670213451427074 139.741560069843 24.631 35.670213451427074 139.741560069843 8.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3c6734cc-a1f1-4a71-a639-c922358b2c4a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c6734cc-a1f1-4a71-a639-c922358b2c4a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c6734cc-a1f1-4a71-a639-c922358b2c4a">
											<gml:posList>35.670258626734395 139.74155808504193 24.631 35.670258626734395 139.74155808504193 24.107 35.67021674758729 139.74155631034955 24.107 35.67021674758729 139.74155631034955 24.631 35.670258626734395 139.74155808504193 24.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fa0b2deb-6e39-47c1-9ac8-dd99e1afccbe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa0b2deb-6e39-47c1-9ac8-dd99e1afccbe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa0b2deb-6e39-47c1-9ac8-dd99e1afccbe">
											<gml:posList>35.67021845064453 139.74149649302532 23.586 35.670215313767756 139.7414963640635 23.586 35.670215313767756 139.7414963640635 24.631 35.67026024860997 139.74149819045576 24.631 35.67026024860997 139.74149819045576 22.934 35.67021845064453 139.74149649302532 22.934 35.67021845064453 139.74149649302532 23.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-12aa78ef-0444-4742-9b26-e364a0c1bfff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-12aa78ef-0444-4742-9b26-e364a0c1bfff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-12aa78ef-0444-4742-9b26-e364a0c1bfff">
											<gml:posList>35.67021838151704 139.7415004034725 24.631 35.67021838151704 139.7415004034725 24.107 35.67026014341911 139.74150208990005 24.107 35.67026014341911 139.74150208990005 24.631 35.67021838151704 139.7415004034725 24.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8cb9db70-aa5a-4902-af28-9289279abedd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8cb9db70-aa5a-4902-af28-9289279abedd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8cb9db70-aa5a-4902-af28-9289279abedd">
											<gml:posList>35.670217052951266 139.7414366792525 8.42 35.670217052951266 139.7414366792525 23.586 35.67026185267277 139.7414386162287 23.586 35.670217052951266 139.7414366792525 8.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1af2032b-1680-4320-86ba-720fdf1ede71">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1af2032b-1680-4320-86ba-720fdf1ede71">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1af2032b-1680-4320-86ba-720fdf1ede71">
											<gml:posList>35.6702200665612 139.7414406413977 23.586 35.6702200665612 139.7414406413977 22.934 35.67026174742484 139.74144243834948 22.934 35.67026174742484 139.74144243834948 23.586 35.6702200665612 139.7414406413977 23.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5e00e29a-79a7-4389-b2dd-461138598a1c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e00e29a-79a7-4389-b2dd-461138598a1c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e00e29a-79a7-4389-b2dd-461138598a1c">
											<gml:posList>35.67026014341911 139.74150208990005 24.631 35.67026014341911 139.74150208990005 24.107 35.670258626734395 139.74155808504193 24.107 35.670258626734395 139.74155808504193 24.631 35.670258521558424 139.7415620065785 24.631 35.670258521558424 139.7415620065785 8.42 35.67025834557738 139.74156764036377 8.42 35.67025834557738 139.74156764036377 34.262 35.67026185267277 139.7414386162287 34.262 35.67026185267277 139.7414386162287 23.586 35.67026174742484 139.74144243834948 23.586 35.67026174742484 139.74144243834948 22.934 35.67026024860997 139.74149819045576 22.934 35.67026024860997 139.74149819045576 24.631 35.67026014341911 139.74150208990005 24.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-94315012-9186-436b-b5cc-a23878f3b5d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-94315012-9186-436b-b5cc-a23878f3b5d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-94315012-9186-436b-b5cc-a23878f3b5d0">
											<gml:posList>35.67026122901752 139.7415663888381 34.262 35.67026122901752 139.7415663888381 33.476 35.67026460459804 139.7414422031038 33.476 35.67026460459804 139.7414422031038 34.262 35.67026122901752 139.7415663888381 34.262</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1e6d79e2-763e-4eaf-9ec1-32bd8be19f89">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e6d79e2-763e-4eaf-9ec1-32bd8be19f89">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e6d79e2-763e-4eaf-9ec1-32bd8be19f89">
											<gml:posList>35.670217052951266 139.7414366792525 8.42 35.67026185267277 139.7414386162287 23.586 35.67030944639517 139.74144021861724 34.262 35.670217052951266 139.7414366792525 8.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b94adae9-8231-4699-9929-6288884a9e91">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b94adae9-8231-4699-9929-6288884a9e91">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b94adae9-8231-4699-9929-6288884a9e91">
											<gml:posList>35.670217052951266 139.7414366792525 8.42 35.67030944639517 139.74144021861724 34.262 35.67030944639517 139.74144021861724 8.42 35.670217052951266 139.7414366792525 8.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b980b6b1-0b5f-4b74-877e-071ee8823f49">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b980b6b1-0b5f-4b74-877e-071ee8823f49">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b980b6b1-0b5f-4b74-877e-071ee8823f49">
											<gml:posList>35.67025834557738 139.74156764036377 8.42 35.67028505489812 139.7416052774946 8.42 35.67028505489812 139.7416052774946 34.262 35.67025834557738 139.74156764036377 34.262 35.67025834557738 139.74156764036377 8.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3ac4530f-f228-46ff-9bed-453e6a39128f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ac4530f-f228-46ff-9bed-453e6a39128f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ac4530f-f228-46ff-9bed-453e6a39128f">
											<gml:posList>35.6702852313101 139.74160020706566 34.262 35.6702852313101 139.74160020706566 33.476 35.67026122901752 139.7415663888381 33.476 35.67026122901752 139.7415663888381 34.262 35.6702852313101 139.74160020706566 34.262</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1f39dd1d-f897-4ec7-a6bf-d5d211316edd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f39dd1d-f897-4ec7-a6bf-d5d211316edd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f39dd1d-f897-4ec7-a6bf-d5d211316edd">
											<gml:posList>35.67026460459804 139.7414422031038 34.262 35.67026460459804 139.7414422031038 33.476 35.67030655557801 139.74144361312904 33.476 35.67030655557801 139.74144361312904 34.262 35.67026460459804 139.7414422031038 34.262</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b55864f4-d1c6-44cd-af74-8a24fc85cf6c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b55864f4-d1c6-44cd-af74-8a24fc85cf6c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b55864f4-d1c6-44cd-af74-8a24fc85cf6c">
											<gml:posList>35.67026185267277 139.7414386162287 23.586 35.67026185267277 139.7414386162287 34.262 35.67030944639517 139.74144021861724 34.262 35.67026185267277 139.7414386162287 23.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7fa12a35-ddb0-42ad-8b6e-c6fc66717c5f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7fa12a35-ddb0-42ad-8b6e-c6fc66717c5f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7fa12a35-ddb0-42ad-8b6e-c6fc66717c5f">
											<gml:posList>35.670303539486106 139.74157823722211 34.262 35.670303539486106 139.74157823722211 33.476 35.6702852313101 139.74160020706566 33.476 35.6702852313101 139.74160020706566 34.262 35.670303539486106 139.74157823722211 34.262</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ac32b90b-da3e-40d9-81a3-a35d4e8510c5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ac32b90b-da3e-40d9-81a3-a35d4e8510c5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ac32b90b-da3e-40d9-81a3-a35d4e8510c5">
											<gml:posList>35.67030634389873 139.74157973630267 8.42 35.67030634389873 139.74157973630267 34.262 35.67028505489812 139.7416052774946 34.262 35.67028505489812 139.7416052774946 8.42 35.67030634389873 139.74157973630267 8.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-557eecf2-c9e0-442b-9388-594ca0c7b9ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-557eecf2-c9e0-442b-9388-594ca0c7b9ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-557eecf2-c9e0-442b-9388-594ca0c7b9ae">
											<gml:posList>35.67030655557801 139.74144361312904 34.262 35.67030655557801 139.74144361312904 33.476 35.670303539486106 139.74157823722211 33.476 35.670303539486106 139.74157823722211 34.262 35.67030655557801 139.74144361312904 34.262</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-16e04dd3-2e5d-43ed-8f1a-c098a4aafe91">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16e04dd3-2e5d-43ed-8f1a-c098a4aafe91">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16e04dd3-2e5d-43ed-8f1a-c098a4aafe91">
											<gml:posList>35.67030634389873 139.74157973630267 8.42 35.67030944715386 139.74144121277885 8.42 35.67030944715386 139.74144121277885 34.262 35.67030634389873 139.74157973630267 34.262 35.67030634389873 139.74157973630267 8.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dca14963-c4f8-4adf-a140-362e09fcb1d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dca14963-c4f8-4adf-a140-362e09fcb1d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dca14963-c4f8-4adf-a140-362e09fcb1d6">
											<gml:posList>35.67030944715386 139.74144121277885 8.42 35.67030944639517 139.74144021861724 8.42 35.67030944639517 139.74144021861724 34.262 35.67030944715386 139.74144121277885 34.262 35.67030944715386 139.74144121277885 8.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10191</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">71.38898</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.13</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>