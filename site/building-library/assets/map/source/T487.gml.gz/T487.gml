<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_8ec2d5da-c710-40ae-a3fc-26ac93fd837f">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>永田町二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:measuredHeight uom="m">4.8</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.672479910870535 139.7411735747543 0 35.67257864662053 139.74101979252404 0 35.67254920404596 139.74099140363128 0 35.67254450448382 139.74099871081893 0 35.672528078335205 139.74098286688363 0 35.67244807785758 139.74110747568596 0 35.67246454909247 139.74112336376538 0 35.67245051343412 139.74114522997417 0 35.672479910870535 139.7411735747543 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672479910870535 139.7411735747543 7.46 35.67245051343412 139.74114522997417 7.46 35.67246454909247 139.74112336376538 7.46 35.67244807785758 139.74110747568596 7.46 35.672528078335205 139.74098286688363 7.46 35.67254450448382 139.74099871081893 7.46 35.67254920404596 139.74099140363128 7.46 35.67257864662053 139.74101979252404 7.46 35.672479910870535 139.7411735747543 7.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672479910870535 139.7411735747543 7.46 35.67257864662053 139.74101979252404 7.46 35.67257864662053 139.74101979252404 12.25 35.672479910870535 139.7411735747543 12.25 35.672479910870535 139.7411735747543 7.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67257864662053 139.74101979252404 7.46 35.67254920404596 139.74099140363128 7.46 35.67254920404596 139.74099140363128 12.25 35.67257864662053 139.74101979252404 12.25 35.67257864662053 139.74101979252404 7.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67254920404596 139.74099140363128 7.46 35.67254450448382 139.74099871081893 7.46 35.67254450448382 139.74099871081893 12.25 35.67254920404596 139.74099140363128 12.25 35.67254920404596 139.74099140363128 7.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67254450448382 139.74099871081893 7.46 35.672528078335205 139.74098286688363 7.46 35.672528078335205 139.74098286688363 12.25 35.67254450448382 139.74099871081893 12.25 35.67254450448382 139.74099871081893 7.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672528078335205 139.74098286688363 7.46 35.67244807785758 139.74110747568596 7.46 35.67244807785758 139.74110747568596 12.25 35.672528078335205 139.74098286688363 12.25 35.672528078335205 139.74098286688363 7.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67244807785758 139.74110747568596 7.46 35.67246454909247 139.74112336376538 7.46 35.67246454909247 139.74112336376538 12.25 35.67244807785758 139.74110747568596 12.25 35.67244807785758 139.74110747568596 7.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67246454909247 139.74112336376538 7.46 35.67245051343412 139.74114522997417 7.46 35.67245051343412 139.74114522997417 12.25 35.67246454909247 139.74112336376538 12.25 35.67246454909247 139.74112336376538 7.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67245051343412 139.74114522997417 7.46 35.672479910870535 139.7411735747543 7.46 35.672479910870535 139.7411735747543 12.25 35.67245051343412 139.74114522997417 12.25 35.67245051343412 139.74114522997417 7.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672479910870535 139.7411735747543 12.25 35.67257864662053 139.74101979252404 12.25 35.67254920404596 139.74099140363128 12.25 35.67254450448382 139.74099871081893 12.25 35.672528078335205 139.74098286688363 12.25 35.67244807785758 139.74110747568596 12.25 35.67246454909247 139.74112336376538 12.25 35.67245051343412 139.74114522997417 12.25 35.672479910870535 139.7411735747543 12.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-251f2d92-9d12-478f-a6bd-f106b934a724"/>
							<gml:surfaceMember xlink:href="#poly-8a11adbe-2c8d-4c52-b402-c87be2872e20"/>
							<gml:surfaceMember xlink:href="#poly-8c47a3b3-74f2-4879-bea4-245aefb38105"/>
							<gml:surfaceMember xlink:href="#poly-30001916-872f-4a3f-90ff-65c5ba970797"/>
							<gml:surfaceMember xlink:href="#poly-15d92838-6301-4fbe-a137-8df9dfc7ca9e"/>
							<gml:surfaceMember xlink:href="#poly-ea64c065-9b9c-43e1-849e-777a13d62739"/>
							<gml:surfaceMember xlink:href="#poly-d3d56890-3ef5-4d8e-be08-0592491007a3"/>
							<gml:surfaceMember xlink:href="#poly-022a7811-2991-432c-9428-1de3a1c8717f"/>
							<gml:surfaceMember xlink:href="#poly-80769601-a885-4d11-a449-e818ba54cd4c"/>
							<gml:surfaceMember xlink:href="#poly-fd75ae37-b931-4415-ac0c-1b2ad0a8ec90"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-251f2d92-9d12-478f-a6bd-f106b934a724">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-251f2d92-9d12-478f-a6bd-f106b934a724">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-251f2d92-9d12-478f-a6bd-f106b934a724">
											<gml:posList>35.67247991087052 139.7411735747543 7.46 35.672450513434114 139.74114522997417 7.46 35.67246454909246 139.74112336376535 7.46 35.672448077857595 139.74110747568596 7.46 35.6725280783352 139.74098286688363 7.46 35.67254450448379 139.74099871081893 7.46 35.67254920404594 139.74099140363128 7.46 35.67257864662052 139.74101979252404 7.46 35.67247991087052 139.7411735747543 7.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8a11adbe-2c8d-4c52-b402-c87be2872e20">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a11adbe-2c8d-4c52-b402-c87be2872e20">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a11adbe-2c8d-4c52-b402-c87be2872e20">
											<gml:posList>35.67254450448379 139.74099871081893 11.3 35.6725280783352 139.74098286688363 11.3 35.672448077857595 139.74110747568596 11.3 35.67246454909246 139.74112336376535 11.3 35.672450513434114 139.74114522997417 11.3 35.67247991087052 139.7411735747543 11.3 35.67257864662052 139.74101979252404 11.3 35.67254920404594 139.74099140363128 11.3 35.67254450448379 139.74099871081893 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8c47a3b3-74f2-4879-bea4-245aefb38105">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c47a3b3-74f2-4879-bea4-245aefb38105">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c47a3b3-74f2-4879-bea4-245aefb38105">
											<gml:posList>35.672448077857595 139.74110747568596 7.46 35.67246454909246 139.74112336376535 7.46 35.67246454909246 139.74112336376535 11.3 35.672448077857595 139.74110747568596 11.3 35.672448077857595 139.74110747568596 7.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-30001916-872f-4a3f-90ff-65c5ba970797">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-30001916-872f-4a3f-90ff-65c5ba970797">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-30001916-872f-4a3f-90ff-65c5ba970797">
											<gml:posList>35.67246454909246 139.74112336376535 7.46 35.672450513434114 139.74114522997417 7.46 35.672450513434114 139.74114522997417 11.3 35.67246454909246 139.74112336376535 11.3 35.67246454909246 139.74112336376535 7.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-15d92838-6301-4fbe-a137-8df9dfc7ca9e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15d92838-6301-4fbe-a137-8df9dfc7ca9e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15d92838-6301-4fbe-a137-8df9dfc7ca9e">
											<gml:posList>35.672450513434114 139.74114522997417 7.46 35.67247991087052 139.7411735747543 7.46 35.67247991087052 139.7411735747543 11.3 35.672450513434114 139.74114522997417 11.3 35.672450513434114 139.74114522997417 7.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ea64c065-9b9c-43e1-849e-777a13d62739">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea64c065-9b9c-43e1-849e-777a13d62739">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea64c065-9b9c-43e1-849e-777a13d62739">
											<gml:posList>35.6725280783352 139.74098286688363 7.46 35.672448077857595 139.74110747568596 7.46 35.672448077857595 139.74110747568596 11.3 35.6725280783352 139.74098286688363 11.3 35.6725280783352 139.74098286688363 7.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d3d56890-3ef5-4d8e-be08-0592491007a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3d56890-3ef5-4d8e-be08-0592491007a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3d56890-3ef5-4d8e-be08-0592491007a3">
											<gml:posList>35.67247991087052 139.7411735747543 7.46 35.67257864662052 139.74101979252404 7.46 35.67257864662052 139.74101979252404 11.3 35.67247991087052 139.7411735747543 11.3 35.67247991087052 139.7411735747543 7.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-022a7811-2991-432c-9428-1de3a1c8717f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-022a7811-2991-432c-9428-1de3a1c8717f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-022a7811-2991-432c-9428-1de3a1c8717f">
											<gml:posList>35.67254450448379 139.74099871081893 7.46 35.6725280783352 139.74098286688363 7.46 35.6725280783352 139.74098286688363 11.3 35.67254450448379 139.74099871081893 11.3 35.67254450448379 139.74099871081893 7.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-80769601-a885-4d11-a449-e818ba54cd4c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-80769601-a885-4d11-a449-e818ba54cd4c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-80769601-a885-4d11-a449-e818ba54cd4c">
											<gml:posList>35.67254920404594 139.74099140363128 7.46 35.67254450448379 139.74099871081893 7.46 35.67254450448379 139.74099871081893 11.3 35.67254920404594 139.74099140363128 11.3 35.67254920404594 139.74099140363128 7.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fd75ae37-b931-4415-ac0c-1b2ad0a8ec90">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fd75ae37-b931-4415-ac0c-1b2ad0a8ec90">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fd75ae37-b931-4415-ac0c-1b2ad0a8ec90">
											<gml:posList>35.67257864662052 139.74101979252404 7.46 35.67254920404594 139.74099140363128 7.46 35.67254920404594 139.74099140363128 11.3 35.67257864662052 139.74101979252404 11.3 35.67257864662052 139.74101979252404 7.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4505</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.34</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>