<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_8edb2a23-53b0-4013-945b-bb1a012b605b">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">11.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67151681962475 139.74083084004147 0 35.67142561584775 139.74073329506234 0 35.6713914006507 139.740781386415 0 35.671482514252055 139.74087893151133 0 35.67151681962475 139.74083084004147 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67151681962475 139.74083084004147 8.04 35.671482514252055 139.74087893151133 8.04 35.6713914006507 139.740781386415 8.04 35.67142561584775 139.74073329506234 8.04 35.67151681962475 139.74083084004147 8.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67151681962475 139.74083084004147 8.04 35.67142561584775 139.74073329506234 8.04 35.67142561584775 139.74073329506234 19.3 35.67151681962475 139.74083084004147 19.3 35.67151681962475 139.74083084004147 8.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67142561584775 139.74073329506234 8.04 35.6713914006507 139.740781386415 8.04 35.6713914006507 139.740781386415 19.3 35.67142561584775 139.74073329506234 19.3 35.67142561584775 139.74073329506234 8.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6713914006507 139.740781386415 8.04 35.671482514252055 139.74087893151133 8.04 35.671482514252055 139.74087893151133 19.3 35.6713914006507 139.740781386415 19.3 35.6713914006507 139.740781386415 8.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671482514252055 139.74087893151133 8.04 35.67151681962475 139.74083084004147 8.04 35.67151681962475 139.74083084004147 19.3 35.671482514252055 139.74087893151133 19.3 35.671482514252055 139.74087893151133 8.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67151681962475 139.74083084004147 19.3 35.67142561584775 139.74073329506234 19.3 35.6713914006507 139.740781386415 19.3 35.671482514252055 139.74087893151133 19.3 35.67151681962475 139.74083084004147 19.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-4734ee96-47aa-4f18-86df-9a262d57390f"/>
							<gml:surfaceMember xlink:href="#poly-77e133f6-aa59-4dcb-8004-c2bbd83bee37"/>
							<gml:surfaceMember xlink:href="#poly-61f9714d-7c27-464f-9602-3caa25ff5478"/>
							<gml:surfaceMember xlink:href="#poly-86025603-0ab5-4c5a-a9c0-11e093bcb3a4"/>
							<gml:surfaceMember xlink:href="#poly-7b3c55a6-631c-46be-8a7c-9ea169b11c4b"/>
							<gml:surfaceMember xlink:href="#poly-ce50e58b-c201-4f76-9349-80c2d55cd8c0"/>
							<gml:surfaceMember xlink:href="#poly-0b1416fa-706e-43a2-b331-1ce093b5da74"/>
							<gml:surfaceMember xlink:href="#poly-3a0c18b4-ef44-4cad-8dc9-74336e0caefa"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_8edb2a23-53b0-4013-945b-bb1a012b605b_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3bf7b4f0-04fb-42e7-b874-de15104b38e1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67141559481542 139.74080655532896 23.023 35.671423662493524 139.740795333919 23.023 35.671440216295956 139.74081304429333 23.023 35.67144144943432 139.74083424092285 23.023 35.67141559481542 139.74080655532896 23.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-387e3187-9d2b-48a0-ba60-ecef8729c979">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-387e3187-9d2b-48a0-ba60-ecef8729c979_0">
											<gml:posList>35.67141559481542 139.74080655532896 23.023 35.67141559481542 139.74080655532896 24.106 35.671423662493524 139.740795333919 24.106 35.671423662493524 139.740795333919 23.023 35.67141559481542 139.74080655532896 23.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59e3c882-182c-45ae-9205-14b565a040ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-59e3c882-182c-45ae-9205-14b565a040ca_0">
											<gml:posList>35.671423662493524 139.740795333919 24.106 35.671440216295956 139.74081304429333 24.106 35.671440216295956 139.74081304429333 23.023 35.671423662493524 139.740795333919 23.023 35.671423662493524 139.740795333919 24.106</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f77a566-4aaf-46f2-a4b2-2e8157dc0bbd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9f77a566-4aaf-46f2-a4b2-2e8157dc0bbd_0">
											<gml:posList>35.671440216295956 139.74081304429333 24.106 35.671423662493524 139.740795333919 24.106 35.67141559481542 139.74080655532896 24.106 35.67144144943432 139.74083424092285 24.106 35.671440216295956 139.74081304429333 24.106</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e7365286-3bc4-484f-8772-a94dc04ea011">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e7365286-3bc4-484f-8772-a94dc04ea011_0">
											<gml:posList>35.67144144943432 139.74083424092285 23.023 35.67144144943432 139.74083424092285 24.106 35.67141559481542 139.74080655532896 24.106 35.67141559481542 139.74080655532896 23.023 35.67144144943432 139.74083424092285 23.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e7d76723-8eb5-49c2-ba68-9ae12df9b834">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e7d76723-8eb5-49c2-ba68-9ae12df9b834_0">
											<gml:posList>35.671440216295956 139.74081304429333 24.106 35.67144144943432 139.74083424092285 24.106 35.67144144943432 139.74083424092285 23.023 35.671440216295956 139.74081304429333 23.023 35.671440216295956 139.74081304429333 24.106</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-4734ee96-47aa-4f18-86df-9a262d57390f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4734ee96-47aa-4f18-86df-9a262d57390f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4734ee96-47aa-4f18-86df-9a262d57390f">
											<gml:posList>35.671516819624735 139.74083084004147 8.04 35.67148251425204 139.74087893151133 8.04 35.67139140065068 139.740781386415 8.04 35.67142561584773 139.74073329506234 8.04 35.671516819624735 139.74083084004147 8.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-77e133f6-aa59-4dcb-8004-c2bbd83bee37">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-77e133f6-aa59-4dcb-8004-c2bbd83bee37">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-77e133f6-aa59-4dcb-8004-c2bbd83bee37">
											<gml:posList>35.67146449033007 139.74083658931792 23.023 35.671516819624735 139.74083084004147 17.723 35.67142561584773 139.74073329506234 17.723 35.6714006567705 139.74076838516342 23.023 35.67146449033007 139.74083658931792 23.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-61f9714d-7c27-464f-9602-3caa25ff5478">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61f9714d-7c27-464f-9602-3caa25ff5478">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61f9714d-7c27-464f-9602-3caa25ff5478">
											<gml:posList>35.67139140065068 139.740781386415 23.023 35.671455171157824 139.74084965692313 23.023 35.67146449033007 139.74083658931792 23.023 35.6714006567705 139.74076838516342 23.023 35.67139140065068 139.740781386415 23.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-86025603-0ab5-4c5a-a9c0-11e093bcb3a4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-86025603-0ab5-4c5a-a9c0-11e093bcb3a4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-86025603-0ab5-4c5a-a9c0-11e093bcb3a4">
											<gml:posList>35.67148251425204 139.74087893151133 17.723 35.671516819624735 139.74083084004147 17.723 35.67146449033007 139.74083658931792 23.023 35.671455171157824 139.74084965692313 23.023 35.67148251425204 139.74087893151133 17.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7b3c55a6-631c-46be-8a7c-9ea169b11c4b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b3c55a6-631c-46be-8a7c-9ea169b11c4b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b3c55a6-631c-46be-8a7c-9ea169b11c4b">
											<gml:posList>35.6714006567705 139.74076838516342 23.023 35.67142561584773 139.74073329506234 17.723 35.67142561584773 139.74073329506234 8.04 35.67139140065068 139.740781386415 8.04 35.67139140065068 139.740781386415 23.023 35.6714006567705 139.74076838516342 23.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ce50e58b-c201-4f76-9349-80c2d55cd8c0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce50e58b-c201-4f76-9349-80c2d55cd8c0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce50e58b-c201-4f76-9349-80c2d55cd8c0">
											<gml:posList>35.67148251425204 139.74087893151133 17.723 35.671455171157824 139.74084965692313 23.023 35.67139140065068 139.740781386415 23.023 35.67139140065068 139.740781386415 8.04 35.67148251425204 139.74087893151133 8.04 35.67148251425204 139.74087893151133 17.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0b1416fa-706e-43a2-b331-1ce093b5da74">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b1416fa-706e-43a2-b331-1ce093b5da74">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b1416fa-706e-43a2-b331-1ce093b5da74">
											<gml:posList>35.671516819624735 139.74083084004147 8.04 35.67142561584773 139.74073329506234 8.04 35.67142561584773 139.74073329506234 17.723 35.671516819624735 139.74083084004147 17.723 35.671516819624735 139.74083084004147 8.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3a0c18b4-ef44-4cad-8dc9-74336e0caefa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a0c18b4-ef44-4cad-8dc9-74336e0caefa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a0c18b4-ef44-4cad-8dc9-74336e0caefa">
											<gml:posList>35.67148251425204 139.74087893151133 8.04 35.671516819624735 139.74083084004147 8.04 35.671516819624735 139.74083084004147 17.723 35.67148251425204 139.74087893151133 17.723 35.67148251425204 139.74087893151133 8.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10085</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">77.59295</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.05</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>