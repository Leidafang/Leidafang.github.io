<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_8f3cd207-dbff-4714-8ae8-24416fb87aeb">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">3.4</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67103734929414 139.7389798261509 0 35.67103996127466 139.7390002809176 0 35.67114591074328 139.73897994141157 0 35.67114329875935 139.7389594866185 0 35.67103734929414 139.7389798261509 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67103734929414 139.7389798261509 17.23 35.67114329875935 139.7389594866185 17.23 35.67114591074328 139.73897994141157 17.23 35.67103996127466 139.7390002809176 17.23 35.67103734929414 139.7389798261509 17.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67103734929414 139.7389798261509 17.23 35.67103996127466 139.7390002809176 17.23 35.67103996127466 139.7390002809176 20.59 35.67103734929414 139.7389798261509 20.59 35.67103734929414 139.7389798261509 17.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67103996127466 139.7390002809176 17.23 35.67114591074328 139.73897994141157 17.23 35.67114591074328 139.73897994141157 20.59 35.67103996127466 139.7390002809176 20.59 35.67103996127466 139.7390002809176 17.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67114591074328 139.73897994141157 17.23 35.67114329875935 139.7389594866185 17.23 35.67114329875935 139.7389594866185 20.59 35.67114591074328 139.73897994141157 20.59 35.67114591074328 139.73897994141157 17.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67114329875935 139.7389594866185 17.23 35.67103734929414 139.7389798261509 17.23 35.67103734929414 139.7389798261509 20.59 35.67114329875935 139.7389594866185 20.59 35.67114329875935 139.7389594866185 17.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67103734929414 139.7389798261509 20.59 35.67103996127466 139.7390002809176 20.59 35.67114591074328 139.73897994141157 20.59 35.67114329875935 139.7389594866185 20.59 35.67103734929414 139.7389798261509 20.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-38d93113-e719-48aa-9e95-183046af98fd"/>
							<gml:surfaceMember xlink:href="#poly-92070fe5-039c-4526-b805-196bb964c538"/>
							<gml:surfaceMember xlink:href="#poly-2d08cd35-eb02-43ee-a96f-93a4ed527a9b"/>
							<gml:surfaceMember xlink:href="#poly-e7b40ec8-20be-47ae-b993-63f7f0e48533"/>
							<gml:surfaceMember xlink:href="#poly-be9a9ba2-a1c1-439d-af03-b14f6794c4f6"/>
							<gml:surfaceMember xlink:href="#poly-2f0ee86c-4ee8-442b-871c-9f41bb40b404"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-38d93113-e719-48aa-9e95-183046af98fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38d93113-e719-48aa-9e95-183046af98fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38d93113-e719-48aa-9e95-183046af98fd">
											<gml:posList>35.67103734929414 139.7389798261509 17.23 35.67114329875932 139.7389594866185 17.23 35.67114591074326 139.73897994141157 17.23 35.67103996127463 139.7390002809176 17.23 35.67103734929414 139.7389798261509 17.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-92070fe5-039c-4526-b805-196bb964c538">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-92070fe5-039c-4526-b805-196bb964c538">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-92070fe5-039c-4526-b805-196bb964c538">
											<gml:posList>35.67114329875932 139.7389594866185 21.247 35.67103734929414 139.7389798261509 21.247 35.67103996127463 139.7390002809176 21.247 35.67114591074326 139.73897994141157 21.247 35.67114329875932 139.7389594866185 21.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2d08cd35-eb02-43ee-a96f-93a4ed527a9b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d08cd35-eb02-43ee-a96f-93a4ed527a9b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d08cd35-eb02-43ee-a96f-93a4ed527a9b">
											<gml:posList>35.67114329875932 139.7389594866185 17.23 35.67103734929414 139.7389798261509 17.23 35.67103734929414 139.7389798261509 21.247 35.67114329875932 139.7389594866185 21.247 35.67114329875932 139.7389594866185 17.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e7b40ec8-20be-47ae-b993-63f7f0e48533">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e7b40ec8-20be-47ae-b993-63f7f0e48533">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e7b40ec8-20be-47ae-b993-63f7f0e48533">
											<gml:posList>35.67114591074326 139.73897994141157 17.23 35.67114329875932 139.7389594866185 17.23 35.67114329875932 139.7389594866185 21.247 35.67114591074326 139.73897994141157 21.247 35.67114591074326 139.73897994141157 17.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-be9a9ba2-a1c1-439d-af03-b14f6794c4f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-be9a9ba2-a1c1-439d-af03-b14f6794c4f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-be9a9ba2-a1c1-439d-af03-b14f6794c4f6">
											<gml:posList>35.67103734929414 139.7389798261509 17.23 35.67103996127463 139.7390002809176 17.23 35.67103996127463 139.7390002809176 21.247 35.67103734929414 139.7389798261509 21.247 35.67103734929414 139.7389798261509 17.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2f0ee86c-4ee8-442b-871c-9f41bb40b404">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f0ee86c-4ee8-442b-871c-9f41bb40b404">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f0ee86c-4ee8-442b-871c-9f41bb40b404">
											<gml:posList>35.67103996127463 139.7390002809176 17.23 35.67114591074326 139.73897994141157 17.23 35.67114591074326 139.73897994141157 21.247 35.67103996127463 139.7390002809176 21.247 35.67103996127463 139.7390002809176 17.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8698</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>