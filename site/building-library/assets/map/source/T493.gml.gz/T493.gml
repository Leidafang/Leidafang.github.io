<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_8facafeb-aa6c-4e65-aadd-68a379901fd6">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">7.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67089733738537 139.74157872858336 0 35.67092410864529 139.74157936072598 0 35.67092916207494 139.74146867066423 0 35.67089121430467 139.74146871414433 0 35.670854305979134 139.74153161002184 0 35.67089733738537 139.74157872858336 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67089733738537 139.74157872858336 8.42 35.670854305979134 139.74153161002184 8.42 35.67089121430467 139.74146871414433 8.42 35.67092916207494 139.74146867066423 8.42 35.67092410864529 139.74157936072598 8.42 35.67089733738537 139.74157872858336 8.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67089733738537 139.74157872858336 8.42 35.67092410864529 139.74157936072598 8.42 35.67092410864529 139.74157936072598 15.62 35.67089733738537 139.74157872858336 15.62 35.67089733738537 139.74157872858336 8.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67092410864529 139.74157936072598 8.42 35.67092916207494 139.74146867066423 8.42 35.67092916207494 139.74146867066423 15.62 35.67092410864529 139.74157936072598 15.62 35.67092410864529 139.74157936072598 8.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67092916207494 139.74146867066423 8.42 35.67089121430467 139.74146871414433 8.42 35.67089121430467 139.74146871414433 15.62 35.67092916207494 139.74146867066423 15.62 35.67092916207494 139.74146867066423 8.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67089121430467 139.74146871414433 8.42 35.670854305979134 139.74153161002184 8.42 35.670854305979134 139.74153161002184 15.62 35.67089121430467 139.74146871414433 15.62 35.67089121430467 139.74146871414433 8.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670854305979134 139.74153161002184 8.42 35.67089733738537 139.74157872858336 8.42 35.67089733738537 139.74157872858336 15.62 35.670854305979134 139.74153161002184 15.62 35.670854305979134 139.74153161002184 8.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67089733738537 139.74157872858336 15.62 35.67092410864529 139.74157936072598 15.62 35.67092916207494 139.74146867066423 15.62 35.67089121430467 139.74146871414433 15.62 35.670854305979134 139.74153161002184 15.62 35.67089733738537 139.74157872858336 15.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-af4b87c5-90a1-4e19-a3ec-5e4cc984e3c9"/>
							<gml:surfaceMember xlink:href="#poly-1afe66b8-41bf-4930-a604-3146df96572b"/>
							<gml:surfaceMember xlink:href="#poly-7e434b87-68d8-498f-9c21-8d808d75715c"/>
							<gml:surfaceMember xlink:href="#poly-626211c1-30f6-4872-ac70-58cff6f65e43"/>
							<gml:surfaceMember xlink:href="#poly-6136f487-4122-4868-aac0-9fcdd3168c53"/>
							<gml:surfaceMember xlink:href="#poly-57fc4282-5109-407a-a018-84d4b873fa71"/>
							<gml:surfaceMember xlink:href="#poly-653abe71-29aa-474b-8291-49869a9d7672"/>
							<gml:surfaceMember xlink:href="#poly-c4269261-3e10-4ce4-a8ec-96804e92e99b"/>
							<gml:surfaceMember xlink:href="#poly-854f89de-f0d2-4f33-88fd-68a2d36010a7"/>
							<gml:surfaceMember xlink:href="#poly-893074f9-dc6d-4437-a258-bf6cae8d5b1b"/>
							<gml:surfaceMember xlink:href="#poly-2d9ae0e4-eba6-40ae-a780-73fef827cb29"/>
							<gml:surfaceMember xlink:href="#poly-57bedb41-9c05-4967-bef2-7dc5df768a63"/>
							<gml:surfaceMember xlink:href="#poly-9e336902-f993-42a0-a9c6-4ba83fbad196"/>
							<gml:surfaceMember xlink:href="#poly-31adc9ec-970c-4abc-a62c-1c3dcfc81b0e"/>
							<gml:surfaceMember xlink:href="#poly-f681dbfd-8ad5-4274-81c3-642a1e0528f8"/>
							<gml:surfaceMember xlink:href="#poly-3b42e4c4-8eb3-454c-a194-dca752924157"/>
							<gml:surfaceMember xlink:href="#poly-8ba161b6-41d9-4531-bc13-9a92a3c569a7"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-af4b87c5-90a1-4e19-a3ec-5e4cc984e3c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af4b87c5-90a1-4e19-a3ec-5e4cc984e3c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af4b87c5-90a1-4e19-a3ec-5e4cc984e3c9">
											<gml:posList>35.67089733738535 139.74157872858333 8.42 35.67085430597912 139.74153161002187 8.42 35.67089121430466 139.74146871414433 8.42 35.67092916207494 139.74146867066423 8.42 35.67092410864527 139.74157936072595 8.42 35.67089733738535 139.74157872858333 8.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1afe66b8-41bf-4930-a604-3146df96572b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1afe66b8-41bf-4930-a604-3146df96572b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1afe66b8-41bf-4930-a604-3146df96572b">
											<gml:posList>35.6708582355662 139.7415310863452 16.585 35.67089272234355 139.74147231352006 16.585 35.67089121430466 139.74146871414433 16.585 35.67085430597912 139.74153161002187 16.585 35.6708582355662 139.7415310863452 16.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7e434b87-68d8-498f-9c21-8d808d75715c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e434b87-68d8-498f-9c21-8d808d75715c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e434b87-68d8-498f-9c21-8d808d75715c">
											<gml:posList>35.6708582355662 139.7415310863452 16.585 35.67085430597912 139.74153161002187 16.585 35.67089733738535 139.74157872858333 16.585 35.670898479400805 139.74157514826518 16.585 35.6708582355662 139.7415310863452 16.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-626211c1-30f6-4872-ac70-58cff6f65e43">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-626211c1-30f6-4872-ac70-58cff6f65e43">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-626211c1-30f6-4872-ac70-58cff6f65e43">
											<gml:posList>35.670898479400805 139.74157514826518 16.242 35.670921347651706 139.74157569650276 16.242 35.67092606410181 139.74147227531896 16.242 35.67089272234355 139.74147231352006 16.242 35.6708582355662 139.7415310863452 16.242 35.670898479400805 139.74157514826518 16.242</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6136f487-4122-4868-aac0-9fcdd3168c53">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6136f487-4122-4868-aac0-9fcdd3168c53">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6136f487-4122-4868-aac0-9fcdd3168c53">
											<gml:posList>35.67092606410181 139.74147227531896 16.585 35.67092916207494 139.74146867066423 16.585 35.67089121430466 139.74146871414433 16.585 35.67089272234355 139.74147231352006 16.585 35.67092606410181 139.74147227531896 16.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-57fc4282-5109-407a-a018-84d4b873fa71">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-57fc4282-5109-407a-a018-84d4b873fa71">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-57fc4282-5109-407a-a018-84d4b873fa71">
											<gml:posList>35.670921347651706 139.74157569650276 16.585 35.670898479400805 139.74157514826518 16.585 35.67089733738535 139.74157872858333 16.585 35.67092410864527 139.74157936072595 16.585 35.670921347651706 139.74157569650276 16.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-653abe71-29aa-474b-8291-49869a9d7672">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-653abe71-29aa-474b-8291-49869a9d7672">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-653abe71-29aa-474b-8291-49869a9d7672">
											<gml:posList>35.67092410864527 139.74157936072595 16.585 35.67092916207494 139.74146867066423 16.585 35.67092606410181 139.74147227531896 16.585 35.670921347651706 139.74157569650276 16.585 35.67092410864527 139.74157936072595 16.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c4269261-3e10-4ce4-a8ec-96804e92e99b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4269261-3e10-4ce4-a8ec-96804e92e99b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4269261-3e10-4ce4-a8ec-96804e92e99b">
											<gml:posList>35.67092916207494 139.74146867066423 16.585 35.67092916207494 139.74146867066423 8.42 35.67089121430466 139.74146871414433 8.42 35.67089121430466 139.74146871414433 16.585 35.67092916207494 139.74146867066423 16.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-854f89de-f0d2-4f33-88fd-68a2d36010a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-854f89de-f0d2-4f33-88fd-68a2d36010a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-854f89de-f0d2-4f33-88fd-68a2d36010a7">
											<gml:posList>35.67092606410181 139.74147227531896 16.585 35.67089272234355 139.74147231352006 16.585 35.67089272234355 139.74147231352006 16.242 35.67092606410181 139.74147227531896 16.242 35.67092606410181 139.74147227531896 16.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-893074f9-dc6d-4437-a258-bf6cae8d5b1b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-893074f9-dc6d-4437-a258-bf6cae8d5b1b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-893074f9-dc6d-4437-a258-bf6cae8d5b1b">
											<gml:posList>35.67089121430466 139.74146871414433 16.585 35.67089121430466 139.74146871414433 8.42 35.67085430597912 139.74153161002187 8.42 35.67085430597912 139.74153161002187 16.585 35.67089121430466 139.74146871414433 16.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2d9ae0e4-eba6-40ae-a780-73fef827cb29">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d9ae0e4-eba6-40ae-a780-73fef827cb29">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d9ae0e4-eba6-40ae-a780-73fef827cb29">
											<gml:posList>35.67089272234355 139.74147231352006 16.585 35.6708582355662 139.7415310863452 16.585 35.6708582355662 139.7415310863452 16.242 35.67089272234355 139.74147231352006 16.242 35.67089272234355 139.74147231352006 16.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-57bedb41-9c05-4967-bef2-7dc5df768a63">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-57bedb41-9c05-4967-bef2-7dc5df768a63">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-57bedb41-9c05-4967-bef2-7dc5df768a63">
											<gml:posList>35.670921347651706 139.74157569650276 16.585 35.67092606410181 139.74147227531896 16.585 35.67092606410181 139.74147227531896 16.242 35.670921347651706 139.74157569650276 16.242 35.670921347651706 139.74157569650276 16.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9e336902-f993-42a0-a9c6-4ba83fbad196">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e336902-f993-42a0-a9c6-4ba83fbad196">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e336902-f993-42a0-a9c6-4ba83fbad196">
											<gml:posList>35.67092410864527 139.74157936072595 16.585 35.67092410864527 139.74157936072595 8.42 35.67092916207494 139.74146867066423 8.42 35.67092916207494 139.74146867066423 16.585 35.67092410864527 139.74157936072595 16.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-31adc9ec-970c-4abc-a62c-1c3dcfc81b0e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31adc9ec-970c-4abc-a62c-1c3dcfc81b0e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31adc9ec-970c-4abc-a62c-1c3dcfc81b0e">
											<gml:posList>35.6708582355662 139.7415310863452 16.585 35.670898479400805 139.74157514826518 16.585 35.670898479400805 139.74157514826518 16.242 35.6708582355662 139.7415310863452 16.242 35.6708582355662 139.7415310863452 16.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f681dbfd-8ad5-4274-81c3-642a1e0528f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f681dbfd-8ad5-4274-81c3-642a1e0528f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f681dbfd-8ad5-4274-81c3-642a1e0528f8">
											<gml:posList>35.67085430597912 139.74153161002187 16.585 35.67085430597912 139.74153161002187 8.42 35.67089733738535 139.74157872858333 8.42 35.67089733738535 139.74157872858333 16.585 35.67085430597912 139.74153161002187 16.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3b42e4c4-8eb3-454c-a194-dca752924157">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3b42e4c4-8eb3-454c-a194-dca752924157">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3b42e4c4-8eb3-454c-a194-dca752924157">
											<gml:posList>35.670898479400805 139.74157514826518 16.585 35.670921347651706 139.74157569650276 16.585 35.670921347651706 139.74157569650276 16.242 35.670898479400805 139.74157514826518 16.242 35.670898479400805 139.74157514826518 16.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8ba161b6-41d9-4531-bc13-9a92a3c569a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ba161b6-41d9-4531-bc13-9a92a3c569a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ba161b6-41d9-4531-bc13-9a92a3c569a7">
											<gml:posList>35.67089733738535 139.74157872858333 16.585 35.67089733738535 139.74157872858333 8.42 35.67092410864527 139.74157936072595 8.42 35.67092410864527 139.74157936072595 16.585 35.67089733738535 139.74157872858333 16.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-3735</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">58.18675</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1002</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">12</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>