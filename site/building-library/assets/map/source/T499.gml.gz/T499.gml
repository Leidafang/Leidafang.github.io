<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_916c1041-6337-4dc4-bb86-b71367ccc53e">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>0.80</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">32.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>10</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67041391306243 139.74094225480627 0 35.67039391346771 139.7409446969837 0 35.67039241498479 139.74090658910933 0 35.67039023159354 139.74088041198803 0 35.670354630696046 139.74088476107931 0 35.670337526839006 139.74091372198535 0 35.670344259874426 139.74099567743298 0 35.67041753466411 139.7409867560332 0 35.67041391306243 139.74094225480627 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67041391306243 139.74094225480627 8.9 35.67041753466411 139.7409867560332 8.9 35.670344259874426 139.74099567743298 8.9 35.670337526839006 139.74091372198535 8.9 35.670354630696046 139.74088476107931 8.9 35.67039023159354 139.74088041198803 8.9 35.67039241498479 139.74090658910933 8.9 35.67039391346771 139.7409446969837 8.9 35.67041391306243 139.74094225480627 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67041391306243 139.74094225480627 8.9 35.67039391346771 139.7409446969837 8.9 35.67039391346771 139.7409446969837 41.48 35.67041391306243 139.74094225480627 41.48 35.67041391306243 139.74094225480627 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67039391346771 139.7409446969837 8.9 35.67039241498479 139.74090658910933 8.9 35.67039241498479 139.74090658910933 41.48 35.67039391346771 139.7409446969837 41.48 35.67039391346771 139.7409446969837 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67039241498479 139.74090658910933 8.9 35.67039023159354 139.74088041198803 8.9 35.67039023159354 139.74088041198803 41.48 35.67039241498479 139.74090658910933 41.48 35.67039241498479 139.74090658910933 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67039023159354 139.74088041198803 8.9 35.670354630696046 139.74088476107931 8.9 35.670354630696046 139.74088476107931 41.48 35.67039023159354 139.74088041198803 41.48 35.67039023159354 139.74088041198803 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670354630696046 139.74088476107931 8.9 35.670337526839006 139.74091372198535 8.9 35.670337526839006 139.74091372198535 41.48 35.670354630696046 139.74088476107931 41.48 35.670354630696046 139.74088476107931 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670337526839006 139.74091372198535 8.9 35.670344259874426 139.74099567743298 8.9 35.670344259874426 139.74099567743298 41.48 35.670337526839006 139.74091372198535 41.48 35.670337526839006 139.74091372198535 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670344259874426 139.74099567743298 8.9 35.67041753466411 139.7409867560332 8.9 35.67041753466411 139.7409867560332 41.48 35.670344259874426 139.74099567743298 41.48 35.670344259874426 139.74099567743298 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67041753466411 139.7409867560332 8.9 35.67041391306243 139.74094225480627 8.9 35.67041391306243 139.74094225480627 41.48 35.67041753466411 139.7409867560332 41.48 35.67041753466411 139.7409867560332 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67041391306243 139.74094225480627 41.48 35.67039391346771 139.7409446969837 41.48 35.67039241498479 139.74090658910933 41.48 35.67039023159354 139.74088041198803 41.48 35.670354630696046 139.74088476107931 41.48 35.670337526839006 139.74091372198535 41.48 35.670344259874426 139.74099567743298 41.48 35.67041753466411 139.7409867560332 41.48 35.67041391306243 139.74094225480627 41.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-ef2ef431-27f9-4888-a20b-df30717edba1"/>
							<gml:surfaceMember xlink:href="#poly-9cd993df-32d0-4b4b-8082-346479cb8996"/>
							<gml:surfaceMember xlink:href="#poly-887fe63e-d6e0-4e32-a06e-5707eb3b4e93"/>
							<gml:surfaceMember xlink:href="#poly-8097852c-cde3-4237-b5c3-343950ef7e89"/>
							<gml:surfaceMember xlink:href="#poly-f1f15759-e75a-46d1-8d10-2fab200955c0"/>
							<gml:surfaceMember xlink:href="#poly-c3d6d850-66b5-4e24-a30d-72312ed219ae"/>
							<gml:surfaceMember xlink:href="#poly-30c34ee0-6903-4476-9df9-ffd0bdba143f"/>
							<gml:surfaceMember xlink:href="#poly-cb071a20-4c04-44a9-aab6-1c04a800784c"/>
							<gml:surfaceMember xlink:href="#poly-134bcd3e-a450-4801-a2ca-588825ae1ca0"/>
							<gml:surfaceMember xlink:href="#poly-60c94ec7-5c09-4713-8ef7-065ac4b2d1d0"/>
							<gml:surfaceMember xlink:href="#poly-10fcde5d-20f9-4c70-b0c2-3fc06d27c82a"/>
							<gml:surfaceMember xlink:href="#poly-8f7408f1-387b-441a-9ae6-d158fd5ffd47"/>
							<gml:surfaceMember xlink:href="#poly-8460eedf-6fe2-402a-9eb4-5e9273998d28"/>
							<gml:surfaceMember xlink:href="#poly-66d4ab85-db05-4fbe-a949-286a68714881"/>
							<gml:surfaceMember xlink:href="#poly-10a02f8c-c9ed-4eae-b515-be5fb30ea1b3"/>
							<gml:surfaceMember xlink:href="#poly-382415f4-8238-464a-b860-f2b307275a26"/>
							<gml:surfaceMember xlink:href="#poly-ee2a7957-29b4-4c42-a684-d9b370ff5bf6"/>
							<gml:surfaceMember xlink:href="#poly-9ae63a8d-bda6-4ee2-bb8e-0fc8f70bd8af"/>
							<gml:surfaceMember xlink:href="#poly-cb5017c8-4081-4320-9ce9-3dc2edba1368"/>
							<gml:surfaceMember xlink:href="#poly-197748b9-d288-4eeb-9110-6685014bf600"/>
							<gml:surfaceMember xlink:href="#poly-696511f9-f9f2-4f95-bb2d-f8736ed2cfb1"/>
							<gml:surfaceMember xlink:href="#poly-7e152471-f5d3-40e5-8993-3e476b56d4c6"/>
							<gml:surfaceMember xlink:href="#poly-b6490c5d-e6bb-47bc-8f4f-d143a820be66"/>
							<gml:surfaceMember xlink:href="#poly-d1ae12bc-3667-48e6-b733-857f2c10c492"/>
							<gml:surfaceMember xlink:href="#poly-d89555a4-1b18-4650-96f6-99c7cc89d96f"/>
							<gml:surfaceMember xlink:href="#poly-f041ab23-4914-47f8-a513-c2ef90eb956d"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_916c1041-6337-4dc4-bb86-b71367ccc53e_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-95964b65-8567-4ff0-887c-34ca27f9adb3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67038901621741 139.74096455275728 41.761 35.67038992868071 139.74097901126152 41.761 35.67037470559578 139.74098045376394 41.761 35.670373784118915 139.74096599527283 41.761 35.67038901621741 139.74096455275728 41.761</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3cb95fc3-4067-41cc-827d-bb1e215b7337">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3cb95fc3-4067-41cc-827d-bb1e215b7337_0">
											<gml:posList>35.670373784118915 139.74096599527283 41.761 35.670373784118915 139.74096599527283 44.314 35.67038901621741 139.74096455275728 44.314 35.67038901621741 139.74096455275728 41.761 35.670373784118915 139.74096599527283 41.761</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24294e28-7ea3-4fe7-849c-f4e72e6fac42">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-24294e28-7ea3-4fe7-849c-f4e72e6fac42_0">
											<gml:posList>35.67038901621741 139.74096455275728 41.761 35.67038901621741 139.74096455275728 44.314 35.67038992868071 139.74097901126152 44.314 35.67038992868071 139.74097901126152 41.761 35.67038901621741 139.74096455275728 41.761</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b5df3adf-7b56-42dc-b605-88feeaac2b1b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b5df3adf-7b56-42dc-b605-88feeaac2b1b_0">
											<gml:posList>35.67038901621741 139.74096455275728 44.314 35.670373784118915 139.74096599527283 44.314 35.67037470559578 139.74098045376394 44.314 35.67038992868071 139.74097901126152 44.314 35.67038901621741 139.74096455275728 44.314</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c8e111c3-35de-4e60-88a1-de6ed75976f5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c8e111c3-35de-4e60-88a1-de6ed75976f5_0">
											<gml:posList>35.67037470559578 139.74098045376394 41.761 35.67037470559578 139.74098045376394 44.314 35.670373784118915 139.74096599527283 44.314 35.670373784118915 139.74096599527283 41.761 35.67037470559578 139.74098045376394 41.761</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2db83b7e-6fd6-4fcb-8810-e55148a34df0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2db83b7e-6fd6-4fcb-8810-e55148a34df0_0">
											<gml:posList>35.67038992868071 139.74097901126152 41.761 35.67038992868071 139.74097901126152 44.314 35.67037470559578 139.74098045376394 44.314 35.67037470559578 139.74098045376394 41.761 35.67038992868071 139.74097901126152 41.761</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_916c1041-6337-4dc4-bb86-b71367ccc53e_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-068846b0-37a8-490c-a635-c7306ee1cf14">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-068846b0-37a8-490c-a635-c7306ee1cf14_0">
											<gml:posList>35.67040135173858 139.74091199147583 41.368 35.67040390876246 139.74094348142347 42.23 35.67040390876246 139.74094348142347 40.511 35.67040135173858 139.74091199147583 41.368</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-486b06a9-ea61-4069-9899-042b297a7f93">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-486b06a9-ea61-4069-9899-042b297a7f93_0">
											<gml:posList>35.670392414984775 139.74090658910933 41.368 35.67040082402502 139.740905585252 41.368 35.670392414984775 139.74090658910933 8.91 35.670392414984775 139.74090658910933 41.368</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fef46f0c-1bf6-443c-8c67-24e13d8ad228">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fef46f0c-1bf6-443c-8c67-24e13d8ad228_0">
											<gml:posList>35.670392414984775 139.74090658910933 8.91 35.67040082402502 139.740905585252 41.368 35.67040647512047 139.7409049159617 8.91 35.670392414984775 139.74090658910933 8.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33ac4a58-8d50-479f-94b7-cb1c7c8882a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-33ac4a58-8d50-479f-94b7-cb1c7c8882a5_0">
											<gml:posList>35.67040082402502 139.740905585252 41.368 35.67040647512047 139.7409049159617 41.368 35.67040647512047 139.7409049159617 8.91 35.67040082402502 139.740905585252 41.368</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-96264caf-95d5-4d1d-b6f9-531ec84ffc05">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-96264caf-95d5-4d1d-b6f9-531ec84ffc05_0">
											<gml:posList>35.67041134702451 139.74091076486516 41.368 35.67040647512047 139.7409049159617 8.91 35.67040647512047 139.7409049159617 41.368 35.67041134702451 139.74091076486516 41.368</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d883874-5aae-49a3-bdc0-826d3ccc78e6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d883874-5aae-49a3-bdc0-826d3ccc78e6_0">
											<gml:posList>35.67041134702451 139.74091076486516 41.368 35.67041134702451 139.74091076486516 8.91 35.67040647512047 139.7409049159617 8.91 35.67041134702451 139.74091076486516 41.368</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3f88cc9-d98e-42a3-9ede-ba2a4e0d4c6b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3f88cc9-d98e-42a3-9ede-ba2a4e0d4c6b_0">
											<gml:posList>35.67040647512047 139.7409049159617 41.368 35.67040082402502 139.740905585252 41.368 35.67040135173858 139.74091199147583 41.368 35.67040647512047 139.7409049159617 41.368</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5876ed4d-8f7c-4e1a-96a8-3929b25850af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5876ed4d-8f7c-4e1a-96a8-3929b25850af_0">
											<gml:posList>35.67041134702451 139.74091076486516 41.368 35.67040647512047 139.7409049159617 41.368 35.67040135173858 139.74091199147583 41.368 35.67041134702451 139.74091076486516 41.368</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc1ebf40-f983-4bc7-a7e8-244a4c834186">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cc1ebf40-f983-4bc7-a7e8-244a4c834186_0">
											<gml:posList>35.67040135173858 139.74091199147583 41.368 35.670392414984775 139.74090658910933 41.368 35.67039214056173 139.74091310671974 41.368 35.67040135173858 139.74091199147583 41.368</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc53c4ed-2dd5-4d34-adf9-b08a30af1264">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc53c4ed-2dd5-4d34-adf9-b08a30af1264_0">
											<gml:posList>35.67040135173858 139.74091199147583 41.368 35.67040082402502 139.740905585252 41.368 35.670392414984775 139.74090658910933 41.368 35.67040135173858 139.74091199147583 41.368</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff9ce795-fb8b-468d-a5f7-cc75125e2362">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ff9ce795-fb8b-468d-a5f7-cc75125e2362_0">
											<gml:posList>35.670392414984775 139.74090658910933 41.368 35.670392414984775 139.74090658910933 8.91 35.67039214056173 139.74091310671974 41.368 35.670392414984775 139.74090658910933 41.368</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b5183d1-cb9f-4981-b6ee-3a6c7aa74c79">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b5183d1-cb9f-4981-b6ee-3a6c7aa74c79_0">
											<gml:posList>35.67039214056173 139.74091310671974 41.368 35.670393913467706 139.7409446969837 8.91 35.670393913467706 139.7409446969837 42.23 35.67039214056173 139.74091310671974 41.368</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d498705c-5fe8-4438-bb7b-99e64145a03e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d498705c-5fe8-4438-bb7b-99e64145a03e_0">
											<gml:posList>35.67039214056173 139.74091310671974 41.368 35.670392414984775 139.74090658910933 8.91 35.670393913467706 139.7409446969837 8.91 35.67039214056173 139.74091310671974 41.368</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0b9cbf1-eab9-467a-9537-d71bd4db23b5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d0b9cbf1-eab9-467a-9537-d71bd4db23b5_0">
											<gml:posList>35.670413913062426 139.74094225480627 40.511 35.67041134702451 139.74091076486516 8.91 35.67041134702451 139.74091076486516 41.368 35.670413913062426 139.74094225480627 40.511</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14336f36-eb02-44fb-8052-ee69107e1a06">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-14336f36-eb02-44fb-8052-ee69107e1a06_0">
											<gml:posList>35.670413913062426 139.74094225480627 40.511 35.670413913062426 139.74094225480627 8.91 35.67041134702451 139.74091076486516 8.91 35.670413913062426 139.74094225480627 40.511</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1006944-a559-4bd0-bf30-823ae92fbac9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d1006944-a559-4bd0-bf30-823ae92fbac9_0">
											<gml:posList>35.67040135173858 139.74091199147583 41.368 35.670413913062426 139.74094225480627 40.511 35.67041134702451 139.74091076486516 41.368 35.67040135173858 139.74091199147583 41.368</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fbef5694-6c1f-422c-8262-4b578f3ccf7f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fbef5694-6c1f-422c-8262-4b578f3ccf7f_0">
											<gml:posList>35.67040135173858 139.74091199147583 41.368 35.67040390876246 139.74094348142347 40.511 35.670413913062426 139.74094225480627 40.511 35.67040135173858 139.74091199147583 41.368</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e1d4b4c6-494b-447b-a211-6edb42464869">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e1d4b4c6-494b-447b-a211-6edb42464869_0">
											<gml:posList>35.67040390876246 139.74094348142347 42.23 35.67040135173858 139.74091199147583 41.368 35.67039214056173 139.74091310671974 41.368 35.67040390876246 139.74094348142347 42.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-698162f9-b767-49df-b814-57bdb312ace3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-698162f9-b767-49df-b814-57bdb312ace3_0">
											<gml:posList>35.670393913467706 139.7409446969837 42.23 35.67040390876246 139.74094348142347 42.23 35.67039214056173 139.74091310671974 41.368 35.670393913467706 139.7409446969837 42.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b5b1b3aa-d280-46cf-b13a-0249f4e0df18">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b5b1b3aa-d280-46cf-b13a-0249f4e0df18_0">
											<gml:posList>35.67040390876246 139.74094348142347 42.23 35.670393913467706 139.7409446969837 42.23 35.67040390876246 139.74094348142347 40.511 35.67040390876246 139.74094348142347 42.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77321186-522d-44ce-ba88-fdbfd94031dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77321186-522d-44ce-ba88-fdbfd94031dd_0">
											<gml:posList>35.670393913467706 139.7409446969837 42.23 35.670393913467706 139.7409446969837 8.91 35.67040390876246 139.74094348142347 40.511 35.670393913467706 139.7409446969837 42.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a783e3d6-c190-4493-866c-3fc952893fce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a783e3d6-c190-4493-866c-3fc952893fce_0">
											<gml:posList>35.67040390876246 139.74094348142347 40.511 35.670413913062426 139.74094225480627 8.91 35.670413913062426 139.74094225480627 40.511 35.67040390876246 139.74094348142347 40.511</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a2cff32-ec7c-4a63-8443-50291ebddcfb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7a2cff32-ec7c-4a63-8443-50291ebddcfb_0">
											<gml:posList>35.67040390876246 139.74094348142347 40.511 35.670393913467706 139.7409446969837 8.91 35.670413913062426 139.74094225480627 8.91 35.67040390876246 139.74094348142347 40.511</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b0b6436-5f5f-4ecd-af6b-5cdc76ae3d79">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670393913467706 139.7409446969837 8.91 35.670392414984775 139.74090658910933 8.91 35.67040647512047 139.7409049159617 8.91 35.67041134702451 139.74091076486516 8.91 35.670413913062426 139.74094225480627 8.91 35.670393913467706 139.7409446969837 8.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-ef2ef431-27f9-4888-a20b-df30717edba1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef2ef431-27f9-4888-a20b-df30717edba1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef2ef431-27f9-4888-a20b-df30717edba1">
											<gml:posList>35.670393913467706 139.7409446969837 8.9 35.670413913062426 139.74094225480627 8.9 35.670417534664125 139.7409867560332 8.9 35.67034425987441 139.74099567743298 8.9 35.670337526838985 139.74091372198532 8.9 35.670354630696 139.74088476107931 8.9 35.67039023159351 139.74088041198803 8.9 35.670392414984775 139.74090658910933 8.9 35.670393913467706 139.7409446969837 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9cd993df-32d0-4b4b-8082-346479cb8996">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9cd993df-32d0-4b4b-8082-346479cb8996">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9cd993df-32d0-4b4b-8082-346479cb8996">
											<gml:posList>35.670354630696 139.74088476107931 42.23 35.670355948836686 139.740887543216 42.23 35.67038809780074 139.74088361786409 42.23 35.67039023159351 139.74088041198803 42.23 35.670354630696 139.74088476107931 42.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-887fe63e-d6e0-4e32-a06e-5707eb3b4e93">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-887fe63e-d6e0-4e32-a06e-5707eb3b4e93">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-887fe63e-d6e0-4e32-a06e-5707eb3b4e93">
											<gml:posList>35.670392414984775 139.74090658910933 42.23 35.67039023159351 139.74088041198803 42.23 35.67038809780074 139.74088361786409 42.23 35.670390026526285 139.74090682383417 42.23 35.670392414984775 139.74090658910933 42.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8097852c-cde3-4237-b5c3-343950ef7e89">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8097852c-cde3-4237-b5c3-343950ef7e89">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8097852c-cde3-4237-b5c3-343950ef7e89">
											<gml:posList>35.670337526838985 139.74091372198532 42.23 35.670340006248644 139.74091454759642 42.23 35.670355948836686 139.740887543216 42.23 35.670354630696 139.74088476107931 42.23 35.670337526838985 139.74091372198532 42.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f1f15759-e75a-46d1-8d10-2fab200955c0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f1f15759-e75a-46d1-8d10-2fab200955c0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f1f15759-e75a-46d1-8d10-2fab200955c0">
											<gml:posList>35.670393913467706 139.7409446969837 42.23 35.670392414984775 139.74090658910933 42.23 35.670390026526285 139.74090682383417 42.23 35.670391644475856 139.74094791406023 42.23 35.670393913467706 139.7409446969837 42.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c3d6d850-66b5-4e24-a30d-72312ed219ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3d6d850-66b5-4e24-a30d-72312ed219ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3d6d850-66b5-4e24-a30d-72312ed219ae">
											<gml:posList>35.670391644475856 139.74094791406023 41.761 35.670390026526285 139.74090682383417 41.761 35.67038809780074 139.74088361786409 41.761 35.670355948836686 139.740887543216 41.761 35.670340006248644 139.74091454759642 41.761 35.67034641168916 139.74099246049465 41.761 35.670414918659795 139.7409841189891 41.761 35.67041177024581 139.74094544964575 41.761 35.670391644475856 139.74094791406023 41.761</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-30c34ee0-6903-4476-9df9-ffd0bdba143f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-30c34ee0-6903-4476-9df9-ffd0bdba143f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-30c34ee0-6903-4476-9df9-ffd0bdba143f">
											<gml:posList>35.670393913467706 139.7409446969837 42.23 35.670391644475856 139.74094791406023 42.23 35.67041177024581 139.74094544964575 42.23 35.670413913062426 139.74094225480627 42.23 35.670393913467706 139.7409446969837 42.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cb071a20-4c04-44a9-aab6-1c04a800784c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb071a20-4c04-44a9-aab6-1c04a800784c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb071a20-4c04-44a9-aab6-1c04a800784c">
											<gml:posList>35.670337526838985 139.74091372198532 42.23 35.67034425987441 139.74099567743298 42.23 35.67034641168916 139.74099246049465 42.23 35.670340006248644 139.74091454759642 42.23 35.670337526838985 139.74091372198532 42.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-134bcd3e-a450-4801-a2ca-588825ae1ca0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-134bcd3e-a450-4801-a2ca-588825ae1ca0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-134bcd3e-a450-4801-a2ca-588825ae1ca0">
											<gml:posList>35.670413913062426 139.74094225480627 42.23 35.67041177024581 139.74094544964575 42.23 35.670414918659795 139.7409841189891 42.23 35.670417534664125 139.7409867560332 42.23 35.670413913062426 139.74094225480627 42.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-60c94ec7-5c09-4713-8ef7-065ac4b2d1d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-60c94ec7-5c09-4713-8ef7-065ac4b2d1d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-60c94ec7-5c09-4713-8ef7-065ac4b2d1d0">
											<gml:posList>35.670417534664125 139.7409867560332 42.23 35.670414918659795 139.7409841189891 42.23 35.67034641168916 139.74099246049465 42.23 35.67034425987441 139.74099567743298 42.23 35.670417534664125 139.7409867560332 42.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-10fcde5d-20f9-4c70-b0c2-3fc06d27c82a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-10fcde5d-20f9-4c70-b0c2-3fc06d27c82a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-10fcde5d-20f9-4c70-b0c2-3fc06d27c82a">
											<gml:posList>35.670337526838985 139.74091372198532 8.9 35.67034425987441 139.74099567743298 8.9 35.67034425987441 139.74099567743298 42.23 35.670337526838985 139.74091372198532 42.23 35.670337526838985 139.74091372198532 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8f7408f1-387b-441a-9ae6-d158fd5ffd47">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f7408f1-387b-441a-9ae6-d158fd5ffd47">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f7408f1-387b-441a-9ae6-d158fd5ffd47">
											<gml:posList>35.67034641168916 139.74099246049465 42.23 35.67034641168916 139.74099246049465 41.761 35.670340006248644 139.74091454759642 41.761 35.670340006248644 139.74091454759642 42.23 35.67034641168916 139.74099246049465 42.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8460eedf-6fe2-402a-9eb4-5e9273998d28">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8460eedf-6fe2-402a-9eb4-5e9273998d28">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8460eedf-6fe2-402a-9eb4-5e9273998d28">
											<gml:posList>35.670354630696 139.74088476107931 8.9 35.670337526838985 139.74091372198532 8.9 35.670337526838985 139.74091372198532 42.23 35.670354630696 139.74088476107931 42.23 35.670354630696 139.74088476107931 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-66d4ab85-db05-4fbe-a949-286a68714881">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66d4ab85-db05-4fbe-a949-286a68714881">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66d4ab85-db05-4fbe-a949-286a68714881">
											<gml:posList>35.670340006248644 139.74091454759642 42.23 35.670340006248644 139.74091454759642 41.761 35.670355948836686 139.740887543216 41.761 35.670355948836686 139.740887543216 42.23 35.670340006248644 139.74091454759642 42.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-10a02f8c-c9ed-4eae-b515-be5fb30ea1b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-10a02f8c-c9ed-4eae-b515-be5fb30ea1b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-10a02f8c-c9ed-4eae-b515-be5fb30ea1b3">
											<gml:posList>35.670355948836686 139.740887543216 42.23 35.670355948836686 139.740887543216 41.761 35.67038809780074 139.74088361786409 41.761 35.67038809780074 139.74088361786409 42.23 35.670355948836686 139.740887543216 42.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-382415f4-8238-464a-b860-f2b307275a26">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-382415f4-8238-464a-b860-f2b307275a26">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-382415f4-8238-464a-b860-f2b307275a26">
											<gml:posList>35.67039023159351 139.74088041198803 8.9 35.670354630696 139.74088476107931 8.9 35.670354630696 139.74088476107931 42.23 35.67039023159351 139.74088041198803 42.23 35.67039023159351 139.74088041198803 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ee2a7957-29b4-4c42-a684-d9b370ff5bf6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee2a7957-29b4-4c42-a684-d9b370ff5bf6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee2a7957-29b4-4c42-a684-d9b370ff5bf6">
											<gml:posList>35.670414918659795 139.7409841189891 42.23 35.670414918659795 139.7409841189891 41.761 35.67034641168916 139.74099246049465 41.761 35.67034641168916 139.74099246049465 42.23 35.670414918659795 139.7409841189891 42.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9ae63a8d-bda6-4ee2-bb8e-0fc8f70bd8af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ae63a8d-bda6-4ee2-bb8e-0fc8f70bd8af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ae63a8d-bda6-4ee2-bb8e-0fc8f70bd8af">
											<gml:posList>35.67034425987441 139.74099567743298 8.9 35.670417534664125 139.7409867560332 8.9 35.670417534664125 139.7409867560332 42.23 35.67034425987441 139.74099567743298 42.23 35.67034425987441 139.74099567743298 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cb5017c8-4081-4320-9ce9-3dc2edba1368">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb5017c8-4081-4320-9ce9-3dc2edba1368">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb5017c8-4081-4320-9ce9-3dc2edba1368">
											<gml:posList>35.67038809780074 139.74088361786409 42.23 35.67038809780074 139.74088361786409 41.761 35.670390026526285 139.74090682383417 41.761 35.670390026526285 139.74090682383417 42.23 35.67038809780074 139.74088361786409 42.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-197748b9-d288-4eeb-9110-6685014bf600">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-197748b9-d288-4eeb-9110-6685014bf600">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-197748b9-d288-4eeb-9110-6685014bf600">
											<gml:posList>35.670390026526285 139.74090682383417 42.23 35.670390026526285 139.74090682383417 41.761 35.670391644475856 139.74094791406023 41.761 35.670391644475856 139.74094791406023 42.23 35.670390026526285 139.74090682383417 42.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-696511f9-f9f2-4f95-bb2d-f8736ed2cfb1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-696511f9-f9f2-4f95-bb2d-f8736ed2cfb1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-696511f9-f9f2-4f95-bb2d-f8736ed2cfb1">
											<gml:posList>35.670392414984775 139.74090658910933 8.9 35.67039023159351 139.74088041198803 8.9 35.67039023159351 139.74088041198803 42.23 35.670392414984775 139.74090658910933 42.23 35.670392414984775 139.74090658910933 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7e152471-f5d3-40e5-8993-3e476b56d4c6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e152471-f5d3-40e5-8993-3e476b56d4c6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e152471-f5d3-40e5-8993-3e476b56d4c6">
											<gml:posList>35.670393913467706 139.7409446969837 8.9 35.670392414984775 139.74090658910933 8.9 35.670392414984775 139.74090658910933 42.23 35.670393913467706 139.7409446969837 42.23 35.670393913467706 139.7409446969837 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b6490c5d-e6bb-47bc-8f4f-d143a820be66">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6490c5d-e6bb-47bc-8f4f-d143a820be66">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6490c5d-e6bb-47bc-8f4f-d143a820be66">
											<gml:posList>35.670391644475856 139.74094791406023 42.23 35.670391644475856 139.74094791406023 41.761 35.67041177024581 139.74094544964575 41.761 35.67041177024581 139.74094544964575 42.23 35.670391644475856 139.74094791406023 42.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d1ae12bc-3667-48e6-b733-857f2c10c492">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1ae12bc-3667-48e6-b733-857f2c10c492">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1ae12bc-3667-48e6-b733-857f2c10c492">
											<gml:posList>35.670413913062426 139.74094225480627 8.9 35.670393913467706 139.7409446969837 8.9 35.670393913467706 139.7409446969837 42.23 35.670413913062426 139.74094225480627 42.23 35.670413913062426 139.74094225480627 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d89555a4-1b18-4650-96f6-99c7cc89d96f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d89555a4-1b18-4650-96f6-99c7cc89d96f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d89555a4-1b18-4650-96f6-99c7cc89d96f">
											<gml:posList>35.67041177024581 139.74094544964575 42.23 35.67041177024581 139.74094544964575 41.761 35.670414918659795 139.7409841189891 41.761 35.670414918659795 139.7409841189891 42.23 35.67041177024581 139.74094544964575 42.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f041ab23-4914-47f8-a513-c2ef90eb956d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f041ab23-4914-47f8-a513-c2ef90eb956d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f041ab23-4914-47f8-a513-c2ef90eb956d">
											<gml:posList>35.670417534664125 139.7409867560332 8.9 35.670413913062426 139.74094225480627 8.9 35.670413913062426 139.74094225480627 42.23 35.670417534664125 139.7409867560332 42.23 35.670417534664125 139.7409867560332 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1443</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">167.65994</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.08</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>