<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_91bf3ec4-ea79-45d5-8d59-cc33b38a3c71">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門駅南地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">7.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.668852936211486 139.74988460447716 0 35.668903610503214 139.7499092949058 0 35.66894417602533 139.74978465311492 0 35.668893501631814 139.74975985229216 0 35.668852936211486 139.74988460447716 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668852936211486 139.74988460447716 6.02 35.668893501631814 139.74975985229216 6.02 35.66894417602533 139.74978465311492 6.02 35.668903610503214 139.7499092949058 6.02 35.668852936211486 139.74988460447716 6.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668852936211486 139.74988460447716 6.02 35.668903610503214 139.7499092949058 6.02 35.668903610503214 139.7499092949058 13.23 35.668852936211486 139.74988460447716 13.23 35.668852936211486 139.74988460447716 6.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668903610503214 139.7499092949058 6.02 35.66894417602533 139.74978465311492 6.02 35.66894417602533 139.74978465311492 13.23 35.668903610503214 139.7499092949058 13.23 35.668903610503214 139.7499092949058 6.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66894417602533 139.74978465311492 6.02 35.668893501631814 139.74975985229216 6.02 35.668893501631814 139.74975985229216 13.23 35.66894417602533 139.74978465311492 13.23 35.66894417602533 139.74978465311492 6.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668893501631814 139.74975985229216 6.02 35.668852936211486 139.74988460447716 6.02 35.668852936211486 139.74988460447716 13.23 35.668893501631814 139.74975985229216 13.23 35.668893501631814 139.74975985229216 6.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668852936211486 139.74988460447716 13.23 35.668903610503214 139.7499092949058 13.23 35.66894417602533 139.74978465311492 13.23 35.668893501631814 139.74975985229216 13.23 35.668852936211486 139.74988460447716 13.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-0b9a8018-5e34-4c4d-a240-3929492219cf"/>
							<gml:surfaceMember xlink:href="#poly-5e273531-8ba4-491b-8af0-08922cd1e359"/>
							<gml:surfaceMember xlink:href="#poly-c83aa365-d09a-41f3-b0b3-3e2fd1e9561a"/>
							<gml:surfaceMember xlink:href="#poly-7d629fa7-40a7-473f-9389-54ad8ec94e3a"/>
							<gml:surfaceMember xlink:href="#poly-a3f3fa19-adb9-4cfe-88b9-1a3fb198e006"/>
							<gml:surfaceMember xlink:href="#poly-e25febf5-8e4d-4c63-aba8-9656b92791d9"/>
							<gml:surfaceMember xlink:href="#poly-9c3ae335-9e0c-42fb-977c-7a5acb8be1d7"/>
							<gml:surfaceMember xlink:href="#poly-a4a4f8ab-4f37-4b43-a313-7ad3e6e1553f"/>
							<gml:surfaceMember xlink:href="#poly-4785bf37-6bef-46ca-aa76-33ffe6aacd2e"/>
							<gml:surfaceMember xlink:href="#poly-4f609b5f-1d03-4a12-b39f-f722b730052a"/>
							<gml:surfaceMember xlink:href="#poly-c62706a5-9466-4e01-8a19-c7e350c3c0ff"/>
							<gml:surfaceMember xlink:href="#poly-73f12a32-f882-4670-b079-4e7f187685d2"/>
							<gml:surfaceMember xlink:href="#poly-bd86c44d-67f5-4529-8143-7e1bdffc8faf"/>
							<gml:surfaceMember xlink:href="#poly-97bdf652-1abc-4f30-b9af-845c3945b7b4"/>
							<gml:surfaceMember xlink:href="#poly-dd7a5340-fcda-4361-825f-b03657a8f715"/>
							<gml:surfaceMember xlink:href="#poly-7bbf4f27-faa0-42e4-ad04-a738abf69379"/>
							<gml:surfaceMember xlink:href="#poly-e0b192cb-aac9-40e2-a59b-54ce3a9b7321"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-0b9a8018-5e34-4c4d-a240-3929492219cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b9a8018-5e34-4c4d-a240-3929492219cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b9a8018-5e34-4c4d-a240-3929492219cf">
											<gml:posList>35.668852936211465 139.74988460447716 6.02 35.66889350163179 139.74975985229216 6.02 35.66894417602532 139.74978465311492 6.02 35.6689036105032 139.7499092949058 6.02 35.668852936211465 139.74988460447716 6.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5e273531-8ba4-491b-8af0-08922cd1e359">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e273531-8ba4-491b-8af0-08922cd1e359">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e273531-8ba4-491b-8af0-08922cd1e359">
											<gml:posList>35.668852936211465 139.74988460447716 14.1 35.6688559637215 139.74988301069504 14.1 35.668871407395365 139.7498355407804 14.1 35.66887009782361 139.7498318196245 14.1 35.668852936211465 139.74988460447716 14.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c83aa365-d09a-41f3-b0b3-3e2fd1e9561a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c83aa365-d09a-41f3-b0b3-3e2fd1e9561a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c83aa365-d09a-41f3-b0b3-3e2fd1e9561a">
											<gml:posList>35.6689036105032 139.7499092949058 14.1 35.668902300941376 139.74990558479323 14.1 35.6688559637215 139.74988301069504 14.1 35.668852936211465 139.74988460447716 14.1 35.6689036105032 139.7499092949058 14.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7d629fa7-40a7-473f-9389-54ad8ec94e3a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d629fa7-40a7-473f-9389-54ad8ec94e3a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d629fa7-40a7-473f-9389-54ad8ec94e3a">
											<gml:posList>35.66891774465462 139.74985815903966 13.361 35.668871407395365 139.7498355407804 13.361 35.6688559637215 139.74988301069504 13.361 35.668902300941376 139.74990558479323 13.361 35.66891774465462 139.74985815903966 13.361</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a3f3fa19-adb9-4cfe-88b9-1a3fb198e006">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a3f3fa19-adb9-4cfe-88b9-1a3fb198e006">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a3f3fa19-adb9-4cfe-88b9-1a3fb198e006">
											<gml:posList>35.66887009782361 139.7498318196245 14.1 35.668871407395365 139.7498355407804 14.1 35.66891774465462 139.74985815903966 14.1 35.66892077215661 139.74985655420923 14.1 35.66887009782361 139.7498318196245 14.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e25febf5-8e4d-4c63-aba8-9656b92791d9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e25febf5-8e4d-4c63-aba8-9656b92791d9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e25febf5-8e4d-4c63-aba8-9656b92791d9">
											<gml:posList>35.66889350163179 139.74975985229216 12.87 35.66887009782361 139.7498318196245 12.87 35.668897896573114 139.74984538836998 13.978 35.66892132746878 139.74977347621868 13.978 35.66889350163179 139.74975985229216 12.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9c3ae335-9e0c-42fb-977c-7a5acb8be1d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c3ae335-9e0c-42fb-977c-7a5acb8be1d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c3ae335-9e0c-42fb-977c-7a5acb8be1d7">
											<gml:posList>35.66892077215661 139.74985655420923 14.1 35.66891774465462 139.74985815903966 14.1 35.668902300941376 139.74990558479323 14.1 35.6689036105032 139.7499092949058 14.1 35.66892077215661 139.74985655420923 14.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a4a4f8ab-4f37-4b43-a313-7ad3e6e1553f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4a4f8ab-4f37-4b43-a313-7ad3e6e1553f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4a4f8ab-4f37-4b43-a313-7ad3e6e1553f">
											<gml:posList>35.66892077215661 139.74985655420923 12.87 35.66894417602532 139.74978465311492 12.87 35.66892132746878 139.74977347621868 13.978 35.668897896573114 139.74984538836998 13.978 35.66892077215661 139.74985655420923 12.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4785bf37-6bef-46ca-aa76-33ffe6aacd2e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4785bf37-6bef-46ca-aa76-33ffe6aacd2e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4785bf37-6bef-46ca-aa76-33ffe6aacd2e">
											<gml:posList>35.66892132746878 139.74977347621868 13.978 35.66894417602532 139.74978465311492 12.87 35.66894417602532 139.74978465311492 6.02 35.66889350163179 139.74975985229216 6.02 35.66889350163179 139.74975985229216 12.87 35.66892132746878 139.74977347621868 13.978</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4f609b5f-1d03-4a12-b39f-f722b730052a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f609b5f-1d03-4a12-b39f-f722b730052a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f609b5f-1d03-4a12-b39f-f722b730052a">
											<gml:posList>35.668852936211465 139.74988460447716 6.02 35.668852936211465 139.74988460447716 14.1 35.66887009782361 139.7498318196245 14.1 35.66887009782361 139.7498318196245 12.87 35.66889350163179 139.74975985229216 12.87 35.66889350163179 139.74975985229216 6.02 35.668852936211465 139.74988460447716 6.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c62706a5-9466-4e01-8a19-c7e350c3c0ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c62706a5-9466-4e01-8a19-c7e350c3c0ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c62706a5-9466-4e01-8a19-c7e350c3c0ff">
											<gml:posList>35.668897896573114 139.74984538836998 13.978 35.66887009782361 139.7498318196245 12.87 35.66887009782361 139.7498318196245 14.1 35.66892077215661 139.74985655420923 14.1 35.66892077215661 139.74985655420923 12.87 35.668897896573114 139.74984538836998 13.978</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-73f12a32-f882-4670-b079-4e7f187685d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73f12a32-f882-4670-b079-4e7f187685d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73f12a32-f882-4670-b079-4e7f187685d2">
											<gml:posList>35.668871407395365 139.7498355407804 14.1 35.668871407395365 139.7498355407804 13.361 35.66891774465462 139.74985815903966 13.361 35.66891774465462 139.74985815903966 14.1 35.668871407395365 139.7498355407804 14.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bd86c44d-67f5-4529-8143-7e1bdffc8faf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd86c44d-67f5-4529-8143-7e1bdffc8faf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd86c44d-67f5-4529-8143-7e1bdffc8faf">
											<gml:posList>35.6689036105032 139.7499092949058 6.02 35.66894417602532 139.74978465311492 6.02 35.66894417602532 139.74978465311492 12.87 35.66892077215661 139.74985655420923 12.87 35.66892077215661 139.74985655420923 14.1 35.6689036105032 139.7499092949058 14.1 35.6689036105032 139.7499092949058 6.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-97bdf652-1abc-4f30-b9af-845c3945b7b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-97bdf652-1abc-4f30-b9af-845c3945b7b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-97bdf652-1abc-4f30-b9af-845c3945b7b4">
											<gml:posList>35.6688559637215 139.74988301069504 14.1 35.6688559637215 139.74988301069504 13.361 35.668871407395365 139.7498355407804 13.361 35.668871407395365 139.7498355407804 14.1 35.6688559637215 139.74988301069504 14.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dd7a5340-fcda-4361-825f-b03657a8f715">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd7a5340-fcda-4361-825f-b03657a8f715">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd7a5340-fcda-4361-825f-b03657a8f715">
											<gml:posList>35.66891774465462 139.74985815903966 14.1 35.66891774465462 139.74985815903966 13.361 35.668902300941376 139.74990558479323 13.361 35.668902300941376 139.74990558479323 14.1 35.66891774465462 139.74985815903966 14.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7bbf4f27-faa0-42e4-ad04-a738abf69379">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7bbf4f27-faa0-42e4-ad04-a738abf69379">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7bbf4f27-faa0-42e4-ad04-a738abf69379">
											<gml:posList>35.668902300941376 139.74990558479323 14.1 35.668902300941376 139.74990558479323 13.361 35.6688559637215 139.74988301069504 13.361 35.6688559637215 139.74988301069504 14.1 35.668902300941376 139.74990558479323 14.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e0b192cb-aac9-40e2-a59b-54ce3a9b7321">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e0b192cb-aac9-40e2-a59b-54ce3a9b7321">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e0b192cb-aac9-40e2-a59b-54ce3a9b7321">
											<gml:posList>35.668852936211465 139.74988460447716 6.02 35.6689036105032 139.7499092949058 6.02 35.6689036105032 139.7499092949058 14.1 35.668852936211465 139.74988460447716 14.1 35.668852936211465 139.74988460447716 6.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-11013</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">73.54665</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1003</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">21</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>