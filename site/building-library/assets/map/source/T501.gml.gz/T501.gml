<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_92afccda-1b87-4bfc-9c76-d76b0929decd">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門駅南地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">36.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>10</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66846962113654 139.7486493981717 0 35.668491478799744 139.74858442460697 0 35.668495535987766 139.74858585629883 0 35.668540601089134 139.74845281474668 0 35.66841644389665 139.74839882082782 0 35.668313096948886 139.7487125255412 0 35.66847007963995 139.74878879817075 0 35.66847223897917 139.7487831624353 0 35.66849793678881 139.74879550685895 0 35.66853544418167 139.74868180391178 0 35.66846962113654 139.7486493981717 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66846962113654 139.7486493981717 5.48 35.66853544418167 139.74868180391178 5.48 35.66849793678881 139.74879550685895 5.48 35.66847223897917 139.7487831624353 5.48 35.66847007963995 139.74878879817075 5.48 35.668313096948886 139.7487125255412 5.48 35.66841644389665 139.74839882082782 5.48 35.668540601089134 139.74845281474668 5.48 35.668495535987766 139.74858585629883 5.48 35.668491478799744 139.74858442460697 5.48 35.66846962113654 139.7486493981717 5.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66846962113654 139.7486493981717 5.48 35.668491478799744 139.74858442460697 5.48 35.668491478799744 139.74858442460697 36.72 35.66846962113654 139.7486493981717 36.72 35.66846962113654 139.7486493981717 5.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668491478799744 139.74858442460697 5.48 35.668495535987766 139.74858585629883 5.48 35.668495535987766 139.74858585629883 36.72 35.668491478799744 139.74858442460697 36.72 35.668491478799744 139.74858442460697 5.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668495535987766 139.74858585629883 5.48 35.668540601089134 139.74845281474668 5.48 35.668540601089134 139.74845281474668 36.72 35.668495535987766 139.74858585629883 36.72 35.668495535987766 139.74858585629883 5.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668540601089134 139.74845281474668 5.48 35.66841644389665 139.74839882082782 5.48 35.66841644389665 139.74839882082782 36.72 35.668540601089134 139.74845281474668 36.72 35.668540601089134 139.74845281474668 5.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66841644389665 139.74839882082782 5.48 35.668313096948886 139.7487125255412 5.48 35.668313096948886 139.7487125255412 36.72 35.66841644389665 139.74839882082782 36.72 35.66841644389665 139.74839882082782 5.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668313096948886 139.7487125255412 5.48 35.66847007963995 139.74878879817075 5.48 35.66847007963995 139.74878879817075 36.72 35.668313096948886 139.7487125255412 36.72 35.668313096948886 139.7487125255412 5.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66847007963995 139.74878879817075 5.48 35.66847223897917 139.7487831624353 5.48 35.66847223897917 139.7487831624353 36.72 35.66847007963995 139.74878879817075 36.72 35.66847007963995 139.74878879817075 5.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66847223897917 139.7487831624353 5.48 35.66849793678881 139.74879550685895 5.48 35.66849793678881 139.74879550685895 36.72 35.66847223897917 139.7487831624353 36.72 35.66847223897917 139.7487831624353 5.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66849793678881 139.74879550685895 5.48 35.66853544418167 139.74868180391178 5.48 35.66853544418167 139.74868180391178 36.72 35.66849793678881 139.74879550685895 36.72 35.66849793678881 139.74879550685895 5.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66853544418167 139.74868180391178 5.48 35.66846962113654 139.7486493981717 5.48 35.66846962113654 139.7486493981717 36.72 35.66853544418167 139.74868180391178 36.72 35.66853544418167 139.74868180391178 5.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66846962113654 139.7486493981717 36.72 35.668491478799744 139.74858442460697 36.72 35.668495535987766 139.74858585629883 36.72 35.668540601089134 139.74845281474668 36.72 35.66841644389665 139.74839882082782 36.72 35.668313096948886 139.7487125255412 36.72 35.66847007963995 139.74878879817075 36.72 35.66847223897917 139.7487831624353 36.72 35.66849793678881 139.74879550685895 36.72 35.66853544418167 139.74868180391178 36.72 35.66846962113654 139.7486493981717 36.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-a7ad2200-d147-4065-90ad-d53766565d29"/>
							<gml:surfaceMember xlink:href="#poly-0ffbc0de-2ae7-42df-b1a8-f56eb079bcc1"/>
							<gml:surfaceMember xlink:href="#poly-25c409d3-7e7b-4990-9a9d-7f9fec65ad71"/>
							<gml:surfaceMember xlink:href="#poly-742189da-6bd3-40bf-a754-52a2f5cd2001"/>
							<gml:surfaceMember xlink:href="#poly-9a4162a1-e71b-4499-9940-c6d7c32c9edf"/>
							<gml:surfaceMember xlink:href="#poly-bcd6a733-1c69-44a3-83e4-96017b365bba"/>
							<gml:surfaceMember xlink:href="#poly-0e4dbcfc-9ec5-4af1-8861-4d7b701c4bf9"/>
							<gml:surfaceMember xlink:href="#poly-d1309e86-cde4-472f-99ed-fb11838249a9"/>
							<gml:surfaceMember xlink:href="#poly-b71a9651-6cad-41c4-98b8-45f7f170b0e0"/>
							<gml:surfaceMember xlink:href="#poly-63e617db-7950-4e17-8376-b6d5c73a406c"/>
							<gml:surfaceMember xlink:href="#poly-562de1ea-baad-4dcc-95a8-9e681afbe84e"/>
							<gml:surfaceMember xlink:href="#poly-e337f10d-0a09-4266-9957-7e7c2215e4b1"/>
							<gml:surfaceMember xlink:href="#poly-e870f68f-044d-46fb-8e34-201b21ed4b1c"/>
							<gml:surfaceMember xlink:href="#poly-604723da-761d-4217-9ff5-d8449fe86181"/>
							<gml:surfaceMember xlink:href="#poly-e7034595-a8e9-4caf-be81-455ddf53f878"/>
							<gml:surfaceMember xlink:href="#poly-47eb8091-20c9-4eee-8663-dc37195356da"/>
							<gml:surfaceMember xlink:href="#poly-6e344817-d0b7-4203-8048-36a823564ce1"/>
							<gml:surfaceMember xlink:href="#poly-081b0fb6-5961-4f37-aae2-7b4cb8191c73"/>
							<gml:surfaceMember xlink:href="#poly-358c53cb-60ed-4327-b023-bfd5af3ffe44"/>
							<gml:surfaceMember xlink:href="#poly-7e21a6c0-c270-47f7-a283-0bb2d1b74251"/>
							<gml:surfaceMember xlink:href="#poly-6d1d6b57-3c89-46d1-a6ee-dd26043d0dd3"/>
							<gml:surfaceMember xlink:href="#poly-3ac0def1-6505-4907-9e40-776be595cce4"/>
							<gml:surfaceMember xlink:href="#poly-0fb0ac09-f0fd-4162-af23-e321412b7dd3"/>
							<gml:surfaceMember xlink:href="#poly-bc0028de-a324-42d2-97c4-b5edc3dff512"/>
							<gml:surfaceMember xlink:href="#poly-72ec1a07-02f4-4069-a5b5-e8902693e36c"/>
							<gml:surfaceMember xlink:href="#poly-8e149592-0ec0-4886-ad51-0c69f2fe2ab9"/>
							<gml:surfaceMember xlink:href="#poly-c66f611f-0686-49d2-b74a-e9700c1bcfd3"/>
							<gml:surfaceMember xlink:href="#poly-66e74dab-5e0d-4f53-a71e-f621f684335b"/>
							<gml:surfaceMember xlink:href="#poly-68d98a13-0b83-452f-bab1-0dceb733d975"/>
							<gml:surfaceMember xlink:href="#poly-ba923cda-c580-48e2-9162-30fce9f5b596"/>
							<gml:surfaceMember xlink:href="#poly-cee0976b-8d9d-4889-8880-a5823b2dfe30"/>
							<gml:surfaceMember xlink:href="#poly-22bbd441-7258-40fc-8f42-473e40448835"/>
							<gml:surfaceMember xlink:href="#poly-22a395a3-0840-40a1-a437-3a55d2bcf7f5"/>
							<gml:surfaceMember xlink:href="#poly-b9d96e1b-e1b8-4570-ac0d-cf845cdc2d3f"/>
							<gml:surfaceMember xlink:href="#poly-aae509c8-d2af-4686-b38e-05b28eb0b970"/>
							<gml:surfaceMember xlink:href="#poly-d310e553-e601-44aa-a9f5-fcd4879993d4"/>
							<gml:surfaceMember xlink:href="#poly-cd04c5bc-0010-4301-ad5f-c5328430f2d5"/>
							<gml:surfaceMember xlink:href="#poly-41592396-652f-452d-88cd-efe558a55aae"/>
							<gml:surfaceMember xlink:href="#poly-7f363da6-af3f-4824-b49e-211db9959856"/>
							<gml:surfaceMember xlink:href="#poly-47028f44-032e-496c-8e18-196359be3a23"/>
							<gml:surfaceMember xlink:href="#poly-b13f4f79-8af0-4de9-b733-100236a379b6"/>
							<gml:surfaceMember xlink:href="#poly-5a038251-de43-41b9-903d-694628fbda35"/>
							<gml:surfaceMember xlink:href="#poly-304d797a-0044-4bf8-b0c1-5f558c3fb871"/>
							<gml:surfaceMember xlink:href="#poly-6a335f17-dad9-4283-b00d-fc40b2664679"/>
							<gml:surfaceMember xlink:href="#poly-a5a36394-035d-4aaa-bdac-e3a50e7d6ab6"/>
							<gml:surfaceMember xlink:href="#poly-e9b1ff57-c92a-478d-b2fc-1c71850b49a5"/>
							<gml:surfaceMember xlink:href="#poly-8f31d4b2-a961-4abb-afb0-8d7824fb1e0f"/>
							<gml:surfaceMember xlink:href="#poly-193b8bd2-493b-4271-bf72-f130a465d485"/>
							<gml:surfaceMember xlink:href="#poly-f451f924-ed9f-4e37-a344-cf1754a0fcf6"/>
							<gml:surfaceMember xlink:href="#poly-cdc96f8b-cbf0-46d9-a16d-2c3cea2ab619"/>
							<gml:surfaceMember xlink:href="#poly-5b37c617-c9d0-4eb9-83b8-a373e2dae8ab"/>
							<gml:surfaceMember xlink:href="#poly-ec31c56e-72b5-480a-8e6a-fa54db620b2c"/>
							<gml:surfaceMember xlink:href="#poly-63640590-fd63-455d-8b28-c7d39826cd89"/>
							<gml:surfaceMember xlink:href="#poly-8c5af23a-f25e-4812-896a-78734c956bbf"/>
							<gml:surfaceMember xlink:href="#poly-67acf4d8-48c6-426d-bcc6-e2ee8a5cc5a5"/>
							<gml:surfaceMember xlink:href="#poly-755a4938-6036-4048-971e-82cdf4eab15c"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_92afccda-1b87-4bfc-9c76-d76b0929decd_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c3ac059-6371-4440-a45e-37b5ae4bf91c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c3ac059-6371-4440-a45e-37b5ae4bf91c_0">
											<gml:posList>35.66850679150465 139.74851809927154 36.32 35.66846543032421 139.74849654809904 38.73 35.66850679150465 139.74851809927154 38.73 35.66850679150465 139.74851809927154 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2340f7cb-83b5-464e-9f07-002bb8efc08a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2340f7cb-83b5-464e-9f07-002bb8efc08a_0">
											<gml:posList>35.66850679150465 139.74851809927154 36.32 35.66846543032421 139.74849654809904 36.32 35.66846543032421 139.74849654809904 38.73 35.66850679150465 139.74851809927154 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14a3e61a-afe6-4ede-ba04-24456c37f672">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-14a3e61a-afe6-4ede-ba04-24456c37f672_0">
											<gml:posList>35.668431580265285 139.7485043934298 36.32 35.66841794437116 139.74854546580016 38.73 35.668431580265285 139.7485043934298 38.73 35.668431580265285 139.7485043934298 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77362dcf-ee7f-4a4f-9fdd-29a267665005">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77362dcf-ee7f-4a4f-9fdd-29a267665005_0">
											<gml:posList>35.668431580265285 139.7485043934298 36.32 35.66841794437116 139.74854546580016 36.32 35.66841794437116 139.74854546580016 38.73 35.668431580265285 139.7485043934298 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-535608b7-4fa7-44e7-b2b3-e80479c64b04">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-535608b7-4fa7-44e7-b2b3-e80479c64b04_0">
											<gml:posList>35.6684236538717 139.7485508722982 36.32 35.66841721580697 139.74854766472254 38.73 35.6684236538717 139.7485508722982 38.73 35.6684236538717 139.7485508722982 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f770f45-c8d9-43e7-8717-631300615def">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2f770f45-c8d9-43e7-8717-631300615def_0">
											<gml:posList>35.6684236538717 139.7485508722982 36.32 35.66841721580697 139.74854766472254 36.32 35.66841721580697 139.74854766472254 38.73 35.6684236538717 139.7485508722982 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f332d3d-fda4-4dc7-bec4-f4794921b8f7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1f332d3d-fda4-4dc7-bec4-f4794921b8f7_0">
											<gml:posList>35.66837447984304 139.748647510376 36.32 35.668403469685465 139.74856021645388 38.73 35.66837447984304 139.748647510376 38.73 35.66837447984304 139.748647510376 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c912057c-f4ef-420b-8b5c-49173220b345">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c912057c-f4ef-420b-8b5c-49173220b345_0">
											<gml:posList>35.66837447984304 139.748647510376 36.32 35.668403469685465 139.74856021645388 36.32 35.668403469685465 139.74856021645388 38.73 35.66837447984304 139.748647510376 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e85c20a2-fbe8-4736-9e4f-bcd3bb947678">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e85c20a2-fbe8-4736-9e4f-bcd3bb947678_0">
											<gml:posList>35.66847013993587 139.74847726785123 36.32 35.66846672165457 139.74848711345166 38.73 35.66847013993587 139.74847726785123 38.73 35.66847013993587 139.74847726785123 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b9d2f49-18c0-4fbb-aab7-f3dc6ae06005">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b9d2f49-18c0-4fbb-aab7-f3dc6ae06005_0">
											<gml:posList>35.66847013993587 139.74847726785123 36.32 35.66846672165457 139.74848711345166 36.32 35.66846672165457 139.74848711345166 38.73 35.66847013993587 139.74847726785123 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-39ecce7d-92b1-4f39-a034-d70af2844e8d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-39ecce7d-92b1-4f39-a034-d70af2844e8d_0">
											<gml:posList>35.66851317828781 139.74849968987476 36.32 35.66847013993587 139.74847726785123 38.73 35.66851317828781 139.74849968987476 38.73 35.66851317828781 139.74849968987476 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0105b84-7717-46a9-a059-ca0b8fb825c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0105b84-7717-46a9-a059-ca0b8fb825c3_0">
											<gml:posList>35.66851317828781 139.74849968987476 36.32 35.66847013993587 139.74847726785123 36.32 35.66847013993587 139.74847726785123 38.73 35.66851317828781 139.74849968987476 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e34369e-ec03-401f-8e25-a50fe2f0c2e5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e34369e-ec03-401f-8e25-a50fe2f0c2e5_0">
											<gml:posList>35.66846672165457 139.74848711345166 38.73 35.66851317828781 139.74849968987476 38.73 35.66847013993587 139.74847726785123 38.73 35.66846672165457 139.74848711345166 38.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa1cb984-7e35-447b-91ca-1385e1f17789">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fa1cb984-7e35-447b-91ca-1385e1f17789_0">
											<gml:posList>35.66846672165457 139.74848711345166 38.73 35.66850976902621 139.74850954651603 38.73 35.66851317828781 139.74849968987476 38.73 35.66846672165457 139.74848711345166 38.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a8ecf08a-370c-44ff-a1d6-638c5aafab94">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a8ecf08a-370c-44ff-a1d6-638c5aafab94_0">
											<gml:posList>35.66850976902621 139.74850954651603 36.32 35.66846672165457 139.74848711345166 38.73 35.66846672165457 139.74848711345166 36.32 35.66850976902621 139.74850954651603 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aeea0e81-0a96-4506-9da2-927ab2d9ed3f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aeea0e81-0a96-4506-9da2-927ab2d9ed3f_0">
											<gml:posList>35.66850976902621 139.74850954651603 36.32 35.66850976902621 139.74850954651603 38.73 35.66846672165457 139.74848711345166 38.73 35.66850976902621 139.74850954651603 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24fed3b6-d35b-4fc3-ba2c-3661e39633a2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-24fed3b6-d35b-4fc3-ba2c-3661e39633a2_0">
											<gml:posList>35.66842369052227 139.74850052463393 36.32 35.66841713523882 139.74849726195635 38.73 35.66842369052227 139.74850052463393 38.73 35.66842369052227 139.74850052463393 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-22955f22-22c7-434e-9b8c-5ef34a5d33b9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-22955f22-22c7-434e-9b8c-5ef34a5d33b9_0">
											<gml:posList>35.66842369052227 139.74850052463393 36.32 35.66841713523882 139.74849726195635 36.32 35.66841713523882 139.74849726195635 38.73 35.66842369052227 139.74850052463393 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1595baf1-ad8f-4b37-8d0d-24eed33e0f06">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1595baf1-ad8f-4b37-8d0d-24eed33e0f06_0">
											<gml:posList>35.66846209302481 139.74850619478454 36.32 35.66846543032421 139.74849654809904 38.73 35.66846543032421 139.74849654809904 36.32 35.66846209302481 139.74850619478454 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bdde931b-5ca6-4fdb-a8b7-1c076c6d420d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bdde931b-5ca6-4fdb-a8b7-1c076c6d420d_0">
											<gml:posList>35.66846209302481 139.74850619478454 36.32 35.66846209302481 139.74850619478454 38.73 35.66846543032421 139.74849654809904 38.73 35.66846209302481 139.74850619478454 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-49143f5d-e227-4e48-869f-234d3f777a99">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-49143f5d-e227-4e48-869f-234d3f777a99_0">
											<gml:posList>35.66850976902621 139.74850954651603 36.32 35.66851317828781 139.74849968987476 38.73 35.66850976902621 139.74850954651603 38.73 35.66850976902621 139.74850954651603 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b696611-1691-4406-bfb5-c1c35bbda0c8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1b696611-1691-4406-bfb5-c1c35bbda0c8_0">
											<gml:posList>35.66850976902621 139.74850954651603 36.32 35.66851317828781 139.74849968987476 36.32 35.66851317828781 139.74849968987476 38.73 35.66850976902621 139.74850954651603 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d64cc649-0f61-48da-a5b4-be4c289942f4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d64cc649-0f61-48da-a5b4-be4c289942f4_0">
											<gml:posList>35.66843802735267 139.74850761203905 36.32 35.668431580265285 139.7485043934298 38.73 35.66843802735267 139.74850761203905 38.73 35.66843802735267 139.74850761203905 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3248bbd0-4bba-43ed-b389-d7af82599269">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3248bbd0-4bba-43ed-b389-d7af82599269_0">
											<gml:posList>35.66843802735267 139.74850761203905 36.32 35.668431580265285 139.7485043934298 36.32 35.668431580265285 139.7485043934298 38.73 35.66843802735267 139.74850761203905 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a31abc12-f2a5-42ea-94bd-288d0928f9fc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a31abc12-f2a5-42ea-94bd-288d0928f9fc_0">
											<gml:posList>35.66846209302481 139.74850619478454 38.73 35.66850679150465 139.74851809927154 38.73 35.66846543032421 139.74849654809904 38.73 35.66846209302481 139.74850619478454 38.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fd8f047e-405f-4d89-bc38-cb8a3164253d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fd8f047e-405f-4d89-bc38-cb8a3164253d_0">
											<gml:posList>35.66846209302481 139.74850619478454 38.73 35.66850344518983 139.74852774597062 38.73 35.66850679150465 139.74851809927154 38.73 35.66846209302481 139.74850619478454 38.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c084d5bc-dd2a-4420-b6f0-b4d576972952">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c084d5bc-dd2a-4420-b6f0-b4d576972952_0">
											<gml:posList>35.66846209302481 139.74850619478454 36.32 35.66850344518983 139.74852774597062 38.73 35.66846209302481 139.74850619478454 38.73 35.66846209302481 139.74850619478454 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a57a876-25b1-45cf-9122-0ce652f9400e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6a57a876-25b1-45cf-9122-0ce652f9400e_0">
											<gml:posList>35.66846209302481 139.74850619478454 36.32 35.66850344518983 139.74852774597062 36.32 35.66850344518983 139.74852774597062 38.73 35.66846209302481 139.74850619478454 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b0fbcb6-e176-41a2-9645-cfbb62af3b5c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b0fbcb6-e176-41a2-9645-cfbb62af3b5c_0">
											<gml:posList>35.66841713523882 139.74849726195635 36.32 35.66840255490468 139.7485411741381 38.73 35.66841713523882 139.74849726195635 38.73 35.66841713523882 139.74849726195635 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f46fa828-3657-4b78-9a68-b13cdcf70d28">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f46fa828-3657-4b78-9a68-b13cdcf70d28_0">
											<gml:posList>35.66841713523882 139.74849726195635 36.32 35.66840255490468 139.7485411741381 36.32 35.66840255490468 139.7485411741381 38.73 35.66841713523882 139.74849726195635 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c760aa7-6f1b-4c47-be80-33ed6138d12d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c760aa7-6f1b-4c47-be80-33ed6138d12d_0">
											<gml:posList>35.66842369052227 139.74850052463393 38.73 35.66840255490468 139.7485411741381 38.73 35.66840910118101 139.74854444787422 38.73 35.66842369052227 139.74850052463393 38.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-930e3296-5c40-4859-b59c-ba2f690ea917">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-930e3296-5c40-4859-b59c-ba2f690ea917_0">
											<gml:posList>35.66842369052227 139.74850052463393 38.73 35.66841713523882 139.74849726195635 38.73 35.66840255490468 139.7485411741381 38.73 35.66842369052227 139.74850052463393 38.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1af3dbea-a510-4a61-bc4e-2aefecb485ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1af3dbea-a510-4a61-bc4e-2aefecb485ce_0">
											<gml:posList>35.66842369052227 139.74850052463393 36.32 35.66840910118101 139.74854444787422 38.73 35.66840910118101 139.74854444787422 36.32 35.66842369052227 139.74850052463393 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a708777-ce7e-4b38-be12-d8e0f935310f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6a708777-ce7e-4b38-be12-d8e0f935310f_0">
											<gml:posList>35.66842369052227 139.74850052463393 36.32 35.66842369052227 139.74850052463393 38.73 35.66840910118101 139.74854444787422 38.73 35.66842369052227 139.74850052463393 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48d2f18e-bb44-4ea6-9172-123acb4cc13e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-48d2f18e-bb44-4ea6-9172-123acb4cc13e_0">
											<gml:posList>35.66850679150465 139.74851809927154 36.32 35.66850344518983 139.74852774597062 38.73 35.66850344518983 139.74852774597062 36.32 35.66850679150465 139.74851809927154 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a40f0d98-98ca-4e9c-b0ce-dadd3450766c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a40f0d98-98ca-4e9c-b0ce-dadd3450766c_0">
											<gml:posList>35.66850679150465 139.74851809927154 36.32 35.66850679150465 139.74851809927154 38.73 35.66850344518983 139.74852774597062 38.73 35.66850679150465 139.74851809927154 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37e9e0e3-0171-44ef-8cad-a56d07aeef78">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-37e9e0e3-0171-44ef-8cad-a56d07aeef78_0">
											<gml:posList>35.66842438243595 139.7485486733757 38.73 35.668431580265285 139.7485043934298 38.73 35.66841794437116 139.74854546580016 38.73 35.66842438243595 139.7485486733757 38.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b56c9937-5849-4789-b463-2a7b68033a41">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b56c9937-5849-4789-b463-2a7b68033a41_0">
											<gml:posList>35.66842438243595 139.7485486733757 38.73 35.66843802735267 139.74850761203905 38.73 35.668431580265285 139.7485043934298 38.73 35.66842438243595 139.7485486733757 38.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-15e6fee8-733d-4921-bc5a-8964b8812ab2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-15e6fee8-733d-4921-bc5a-8964b8812ab2_0">
											<gml:posList>35.66842438243595 139.7485486733757 36.32 35.66843802735267 139.74850761203905 38.73 35.66842438243595 139.7485486733757 38.73 35.66842438243595 139.7485486733757 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1679fcd1-f92a-4c1b-9588-a93055e0b4b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1679fcd1-f92a-4c1b-9588-a93055e0b4b1_0">
											<gml:posList>35.66842438243595 139.7485486733757 36.32 35.66843802735267 139.74850761203905 36.32 35.66843802735267 139.74850761203905 38.73 35.66842438243595 139.7485486733757 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a67bef1-5836-4d75-84aa-b392a7f83098">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3a67bef1-5836-4d75-84aa-b392a7f83098_0">
											<gml:posList>35.66840255490468 139.7485411741381 36.32 35.66840910118101 139.74854444787422 38.73 35.66840255490468 139.7485411741381 38.73 35.66840255490468 139.7485411741381 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8ea5fdea-c69d-4311-b2ac-7f3a795029e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8ea5fdea-c69d-4311-b2ac-7f3a795029e2_0">
											<gml:posList>35.66840255490468 139.7485411741381 36.32 35.66840910118101 139.74854444787422 36.32 35.66840910118101 139.74854444787422 38.73 35.66840255490468 139.7485411741381 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e1a00cd2-ad2a-41cc-b3d8-a5de7311886e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e1a00cd2-ad2a-41cc-b3d8-a5de7311886e_0">
											<gml:posList>35.66841794437116 139.74854546580016 36.32 35.66842438243595 139.7485486733757 38.73 35.66841794437116 139.74854546580016 38.73 35.66841794437116 139.74854546580016 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f61be94e-4a4e-4e9a-8476-7f190f536011">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f61be94e-4a4e-4e9a-8476-7f190f536011_0">
											<gml:posList>35.66841794437116 139.74854546580016 36.32 35.66842438243595 139.7485486733757 36.32 35.66842438243595 139.7485486733757 38.73 35.66841794437116 139.74854546580016 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29c07a63-331a-4f38-9645-cbe405331b00">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29c07a63-331a-4f38-9645-cbe405331b00_0">
											<gml:posList>35.668403469685465 139.74856021645388 36.32 35.66839708571886 139.74855703091305 38.73 35.668403469685465 139.74856021645388 38.73 35.668403469685465 139.74856021645388 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9831a54-7475-46b5-a66c-b0b7102c6531">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e9831a54-7475-46b5-a66c-b0b7102c6531_0">
											<gml:posList>35.668403469685465 139.74856021645388 36.32 35.66839708571886 139.74855703091305 36.32 35.66839708571886 139.74855703091305 38.73 35.668403469685465 139.74856021645388 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35aa169b-011f-4922-9f35-884b3d8ef8dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-35aa169b-011f-4922-9f35-884b3d8ef8dd_0">
											<gml:posList>35.66841721580697 139.74854766472254 36.32 35.66838231647782 139.7486527710342 38.73 35.66841721580697 139.74854766472254 38.73 35.66841721580697 139.74854766472254 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b6ddcbc9-293c-491a-8e45-c1035a9c1ae6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b6ddcbc9-293c-491a-8e45-c1035a9c1ae6_0">
											<gml:posList>35.66841721580697 139.74854766472254 36.32 35.66838231647782 139.7486527710342 36.32 35.66838231647782 139.7486527710342 38.73 35.66841721580697 139.74854766472254 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d60e336-19de-4219-8be4-81a3f1fc0932">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5d60e336-19de-4219-8be4-81a3f1fc0932_0">
											<gml:posList>35.66839708571886 139.74855703091305 36.32 35.66836809587871 139.7486443248293 38.73 35.66839708571886 139.74855703091305 38.73 35.66839708571886 139.74855703091305 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac646b68-080b-4c43-8bf3-0a1351a69214">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ac646b68-080b-4c43-8bf3-0a1351a69214_0">
											<gml:posList>35.66839708571886 139.74855703091305 36.32 35.66836809587871 139.7486443248293 36.32 35.66836809587871 139.7486443248293 38.73 35.66839708571886 139.74855703091305 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f15a915b-aa19-4d95-9d82-92effeb23693">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f15a915b-aa19-4d95-9d82-92effeb23693_0">
											<gml:posList>35.66838875453979 139.7486559786169 38.73 35.66841721580697 139.74854766472254 38.73 35.66838231647782 139.7486527710342 38.73 35.66838875453979 139.7486559786169 38.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14a1f761-faf4-49dc-b5ca-0820c926d59e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-14a1f761-faf4-49dc-b5ca-0820c926d59e_0">
											<gml:posList>35.66838875453979 139.7486559786169 38.73 35.6684236538717 139.7485508722982 38.73 35.66841721580697 139.74854766472254 38.73 35.66838875453979 139.7486559786169 38.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-71fde75f-c69f-4f32-a0e8-cdf7398b32a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-71fde75f-c69f-4f32-a0e8-cdf7398b32a6_0">
											<gml:posList>35.668403469685465 139.74856021645388 38.73 35.66836809587871 139.7486443248293 38.73 35.66837447984304 139.748647510376 38.73 35.668403469685465 139.74856021645388 38.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-34307102-1488-4c72-8a95-6c057beb34a0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-34307102-1488-4c72-8a95-6c057beb34a0_0">
											<gml:posList>35.668403469685465 139.74856021645388 38.73 35.66839708571886 139.74855703091305 38.73 35.66836809587871 139.7486443248293 38.73 35.668403469685465 139.74856021645388 38.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3be81eb3-6056-4f6f-aca7-018b2cacfe02">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3be81eb3-6056-4f6f-aca7-018b2cacfe02_0">
											<gml:posList>35.6684236538717 139.7485508722982 36.32 35.66838875453979 139.7486559786169 38.73 35.66838875453979 139.7486559786169 36.32 35.6684236538717 139.7485508722982 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d3da9989-5883-4687-87f0-d71ce71163d3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d3da9989-5883-4687-87f0-d71ce71163d3_0">
											<gml:posList>35.6684236538717 139.7485508722982 36.32 35.6684236538717 139.7485508722982 38.73 35.66838875453979 139.7486559786169 38.73 35.6684236538717 139.7485508722982 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f400f0a-974f-4398-a26c-c00228598357">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f400f0a-974f-4398-a26c-c00228598357_0">
											<gml:posList>35.66842869946564 139.74859911585355 43.726 35.66845593877377 139.7486116463647 46.147 35.66845593877377 139.7486116463647 43.726 35.66842869946564 139.74859911585355 43.726</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7911374-d224-4346-b71e-f3975cd3bf82">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f7911374-d224-4346-b71e-f3975cd3bf82_0">
											<gml:posList>35.66842869946564 139.74859911585355 43.726 35.66842869946564 139.74859911585355 46.147 35.66845593877377 139.7486116463647 46.147 35.66842869946564 139.74859911585355 43.726</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf41de51-1dac-4513-ae3c-48e01c8665b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cf41de51-1dac-4513-ae3c-48e01c8665b1_0">
											<gml:posList>35.66842869946564 139.74859911585355 43.726 35.66842181075035 139.7486215796318 46.147 35.66842869946564 139.74859911585355 46.147 35.66842869946564 139.74859911585355 43.726</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-93477dce-64b6-4ad8-9f56-6f04e0548ccc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-93477dce-64b6-4ad8-9f56-6f04e0548ccc_0">
											<gml:posList>35.66842869946564 139.74859911585355 43.726 35.66842181075035 139.7486215796318 43.726 35.66842181075035 139.7486215796318 46.147 35.66842869946564 139.74859911585355 43.726</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9fd658b-e8a9-4b66-b604-e55deac1af85">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b9fd658b-e8a9-4b66-b604-e55deac1af85_0">
											<gml:posList>35.66842869946564 139.74859911585355 46.147 35.66842181075035 139.7486215796318 46.147 35.66844904105023 139.74863412120501 46.147 35.66842869946564 139.74859911585355 46.147</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d43c2d0-235e-4a28-8742-aeb45a5e7824">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d43c2d0-235e-4a28-8742-aeb45a5e7824_0">
											<gml:posList>35.66845593877377 139.7486116463647 46.147 35.66842869946564 139.74859911585355 46.147 35.66844904105023 139.74863412120501 46.147 35.66845593877377 139.7486116463647 46.147</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-be8601e2-c770-4ad4-a9de-7b378f66c3f2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-be8601e2-c770-4ad4-a9de-7b378f66c3f2_0">
											<gml:posList>35.66844904105023 139.74863412120501 43.726 35.66845593877377 139.7486116463647 46.147 35.66844904105023 139.74863412120501 46.147 35.66844904105023 139.74863412120501 43.726</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e3faaad-7d5a-4c6c-a390-bff3d9a82270">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e3faaad-7d5a-4c6c-a390-bff3d9a82270_0">
											<gml:posList>35.66844904105023 139.74863412120501 43.726 35.66845593877377 139.7486116463647 43.726 35.66845593877377 139.7486116463647 46.147 35.66844904105023 139.74863412120501 43.726</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-007b3056-a000-4da9-ae41-3c8103474b6e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-007b3056-a000-4da9-ae41-3c8103474b6e_0">
											<gml:posList>35.66842181075035 139.7486215796318 43.726 35.66844904105023 139.74863412120501 46.147 35.66842181075035 139.7486215796318 46.147 35.66842181075035 139.7486215796318 43.726</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8ea938d-e2c7-41ff-9370-88d51fe8f767">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8ea938d-e2c7-41ff-9370-88d51fe8f767_0">
											<gml:posList>35.66842181075035 139.7486215796318 43.726 35.66844904105023 139.74863412120501 43.726 35.66844904105023 139.74863412120501 46.147 35.66842181075035 139.7486215796318 43.726</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9a610ab-aa31-4921-8517-4f3d1b40c3d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e9a610ab-aa31-4921-8517-4f3d1b40c3d8_0">
											<gml:posList>35.66836809587871 139.7486443248293 36.32 35.66837447984304 139.748647510376 38.73 35.66836809587871 139.7486443248293 38.73 35.66836809587871 139.7486443248293 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c9506b85-bf6c-4a4c-89eb-6b2fcc8c0a27">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c9506b85-bf6c-4a4c-89eb-6b2fcc8c0a27_0">
											<gml:posList>35.66836809587871 139.7486443248293 36.32 35.66837447984304 139.748647510376 36.32 35.66837447984304 139.748647510376 38.73 35.66836809587871 139.7486443248293 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb658d3d-9071-4da5-a0f7-ebc0d426658e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fb658d3d-9071-4da5-a0f7-ebc0d426658e_0">
											<gml:posList>35.66838231647782 139.7486527710342 36.32 35.66838875453979 139.7486559786169 38.73 35.66838231647782 139.7486527710342 38.73 35.66838231647782 139.7486527710342 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bac53aca-fa4e-4e4a-98e3-892dd7c3f460">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bac53aca-fa4e-4e4a-98e3-892dd7c3f460_0">
											<gml:posList>35.66838231647782 139.7486527710342 36.32 35.66838875453979 139.7486559786169 36.32 35.66838875453979 139.7486559786169 38.73 35.66838231647782 139.7486527710342 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f14c7d79-afef-4a06-b6d4-f5428460a7a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f14c7d79-afef-4a06-b6d4-f5428460a7a6_0">
											<gml:posList>35.6684734600569 139.74866089300076 36.32 35.66846651720309 139.74865765280933 36.32 35.66846651720309 139.74865765280933 45.555 35.6684734600569 139.74866089300076 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7691244-49ac-451d-a596-508eb84fa323">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c7691244-49ac-451d-a596-508eb84fa323_0">
											<gml:posList>35.66846651720309 139.74865765280933 45.555 35.6684734600569 139.74866089300076 47.571 35.6684734600569 139.74866089300076 36.32 35.66846651720309 139.74865765280933 45.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-135fee63-9579-40ff-b741-dfb600250d0e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-135fee63-9579-40ff-b741-dfb600250d0e_0">
											<gml:posList>35.6684734600569 139.74866089300076 47.571 35.668464966329296 139.74865692541132 45.555 35.66845755460617 139.74865346479584 47.571 35.6684734600569 139.74866089300076 47.571</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cdfb4103-f46b-42c2-a9a7-d767c7f1712e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cdfb4103-f46b-42c2-a9a7-d767c7f1712e_0">
											<gml:posList>35.66845755460617 139.74865346479584 36.32 35.668464966329296 139.74865692541132 45.555 35.668464966329296 139.74865692541132 36.32 35.66845755460617 139.74865346479584 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-23e45c78-ecff-47ef-a199-3ae056dc0296">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-23e45c78-ecff-47ef-a199-3ae056dc0296_0">
											<gml:posList>35.66845755460617 139.74865346479584 47.571 35.668464966329296 139.74865692541132 45.555 35.66845755460617 139.74865346479584 36.32 35.66845755460617 139.74865346479584 47.571</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-480e1ebc-b068-4d06-9b87-7d1702d792bb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-480e1ebc-b068-4d06-9b87-7d1702d792bb_0">
											<gml:posList>35.6684734600569 139.74866089300076 47.571 35.66846651720309 139.74865765280933 45.555 35.668464966329296 139.74865692541132 45.555 35.6684734600569 139.74866089300076 47.571</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f8d82ab6-8c6a-458e-954c-791d5d922621">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f8d82ab6-8c6a-458e-954c-791d5d922621_0">
											<gml:posList>35.668464966329296 139.74865692541132 45.555 35.66846651720309 139.74865765280933 36.32 35.668464966329296 139.74865692541132 36.32 35.668464966329296 139.74865692541132 45.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44b50387-9328-48bb-98f7-db7c1731daee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-44b50387-9328-48bb-98f7-db7c1731daee_0">
											<gml:posList>35.668464966329296 139.74865692541132 45.555 35.66846651720309 139.74865765280933 45.555 35.66846651720309 139.74865765280933 36.32 35.668464966329296 139.74865692541132 45.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c085408a-0c5a-457c-8a86-d4f8e1b08916">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c085408a-0c5a-457c-8a86-d4f8e1b08916_0">
											<gml:posList>35.66845589084162 139.74865883490654 36.32 35.66845644842664 139.7486570338205 45.555 35.66845644842664 139.7486570338205 36.32 35.66845589084162 139.74865883490654 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7fd1bc23-0e06-40bc-8bbe-dc0be8486f81">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7fd1bc23-0e06-40bc-8bbe-dc0be8486f81_0">
											<gml:posList>35.66845589084162 139.74865883490654 36.32 35.66845589084162 139.74865883490654 45.555 35.66845644842664 139.7486570338205 45.555 35.66845589084162 139.74865883490654 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f241a57-d3c8-4e4b-b7c7-91b4dde92688">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f241a57-d3c8-4e4b-b7c7-91b4dde92688_0">
											<gml:posList>35.66845644842664 139.7486570338205 45.555 35.66845755460617 139.74865346479584 47.571 35.66845755460617 139.74865346479584 36.32 35.66845644842664 139.7486570338205 45.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c985d93e-94f6-4078-a2c8-4853203dedc3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c985d93e-94f6-4078-a2c8-4853203dedc3_0">
											<gml:posList>35.66845755460617 139.74865346479584 47.571 35.66845589084162 139.74865883490654 45.555 35.66845172689904 139.7486722270491 47.571 35.66845755460617 139.74865346479584 47.571</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa31fc80-2bca-4092-854e-26a98e62c964">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aa31fc80-2bca-4092-854e-26a98e62c964_0">
											<gml:posList>35.66845172689904 139.7486722270491 47.571 35.66845589084162 139.74865883490654 45.555 35.66845172689904 139.7486722270491 36.32 35.66845172689904 139.7486722270491 47.571</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9689c4c3-98b7-4cd9-967f-db4c26cc9078">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9689c4c3-98b7-4cd9-967f-db4c26cc9078_0">
											<gml:posList>35.66845755460617 139.74865346479584 36.32 35.66845644842664 139.7486570338205 36.32 35.66845644842664 139.7486570338205 45.555 35.66845755460617 139.74865346479584 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ccc922a7-53e7-42c7-adcc-07adfb227631">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ccc922a7-53e7-42c7-adcc-07adfb227631_0">
											<gml:posList>35.66845172689904 139.7486722270491 36.32 35.66845589084162 139.74865883490654 45.555 35.66845589084162 139.74865883490654 36.32 35.66845172689904 139.7486722270491 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ad207aa-4669-4f97-a6db-e7ea878d53c4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7ad207aa-4669-4f97-a6db-e7ea878d53c4_0">
											<gml:posList>35.66845755460617 139.74865346479584 47.571 35.66845644842664 139.7486570338205 45.555 35.66845589084162 139.74865883490654 45.555 35.66845755460617 139.74865346479584 47.571</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ae6a46a-014d-4db7-b45f-62e3b62d27a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9ae6a46a-014d-4db7-b45f-62e3b62d27a6_0">
											<gml:posList>35.66845172689904 139.7486722270491 47.571 35.66846762333492 139.74867965526673 47.571 35.6684734600569 139.74866089300076 47.571 35.66845172689904 139.7486722270491 47.571</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-919bb627-9387-4065-9f94-1c16cda097c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-919bb627-9387-4065-9f94-1c16cda097c3_0">
											<gml:posList>35.66845755460617 139.74865346479584 47.571 35.66845172689904 139.7486722270491 47.571 35.6684734600569 139.74866089300076 47.571 35.66845755460617 139.74865346479584 47.571</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5233975-a7d3-47ca-8e98-c3a5dafa65c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c5233975-a7d3-47ca-8e98-c3a5dafa65c7_0">
											<gml:posList>35.66846762333492 139.74867965526673 36.32 35.6684734600569 139.74866089300076 47.571 35.66846762333492 139.74867965526673 47.571 35.66846762333492 139.74867965526673 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18093243-7c2a-41f1-b198-abdb035e3755">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-18093243-7c2a-41f1-b198-abdb035e3755_0">
											<gml:posList>35.66846762333492 139.74867965526673 36.32 35.6684734600569 139.74866089300076 36.32 35.6684734600569 139.74866089300076 47.571 35.66846762333492 139.74867965526673 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fdef4eda-7d49-4f61-9d97-79962d73a132">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fdef4eda-7d49-4f61-9d97-79962d73a132_0">
											<gml:posList>35.66846762333492 139.74867965526673 36.32 35.66845172689904 139.7486722270491 47.571 35.66845172689904 139.7486722270491 36.32 35.66846762333492 139.74867965526673 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a8ee6ca-0b83-482c-9de5-81b07c2b4abd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4a8ee6ca-0b83-482c-9de5-81b07c2b4abd_0">
											<gml:posList>35.66846762333492 139.74867965526673 36.32 35.66846762333492 139.74867965526673 47.571 35.66845172689904 139.7486722270491 47.571 35.66846762333492 139.74867965526673 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f5b99b95-5c9d-43eb-a21c-7674a629b877">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f5b99b95-5c9d-43eb-a21c-7674a629b877_0">
											<gml:posList>35.668493759915535 139.748713505756 36.32 35.66849964794437 139.7487164377785 39.48 35.66849964794437 139.7487164377785 36.32 35.668493759915535 139.748713505756 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e05df753-46e5-4f37-a78e-ae5ac2da9e52">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e05df753-46e5-4f37-a78e-ae5ac2da9e52_0">
											<gml:posList>35.668493759915535 139.748713505756 36.32 35.668493759915535 139.748713505756 39.48 35.66849964794437 139.7487164377785 39.48 35.668493759915535 139.748713505756 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab924db7-12c5-4592-b6c6-642c684f1be6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ab924db7-12c5-4592-b6c6-642c684f1be6_0">
											<gml:posList>35.668493759915535 139.748713505756 36.32 35.66848576363901 139.74873760551912 39.48 35.668493759915535 139.748713505756 39.48 35.668493759915535 139.748713505756 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59eba209-f00c-455e-abc4-e3b51744ff41">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-59eba209-f00c-455e-abc4-e3b51744ff41_0">
											<gml:posList>35.668493759915535 139.748713505756 36.32 35.66848576363901 139.74873760551912 36.32 35.66848576363901 139.74873760551912 39.48 35.668493759915535 139.748713505756 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8937b8fd-0a1c-4bbf-b67d-522e28737bf9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8937b8fd-0a1c-4bbf-b67d-522e28737bf9_0">
											<gml:posList>35.668491660681 139.74874053753356 39.48 35.66849964794437 139.7487164377785 39.48 35.668493759915535 139.748713505756 39.48 35.668491660681 139.74874053753356 39.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4aa6b759-5c54-43ee-812c-27c8cfb058fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4aa6b759-5c54-43ee-812c-27c8cfb058fd_0">
											<gml:posList>35.66848576363901 139.74873760551912 39.48 35.668491660681 139.74874053753356 39.48 35.668493759915535 139.748713505756 39.48 35.66848576363901 139.74873760551912 39.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8f4baf8-c428-43e1-9544-2ae89aa5fa1b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b8f4baf8-c428-43e1-9544-2ae89aa5fa1b_0">
											<gml:posList>35.668491660681 139.74874053753356 36.32 35.66849964794437 139.7487164377785 39.48 35.668491660681 139.74874053753356 39.48 35.668491660681 139.74874053753356 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bdf3fd43-7d6e-42ff-8079-d037dd4b439f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bdf3fd43-7d6e-42ff-8079-d037dd4b439f_0">
											<gml:posList>35.668491660681 139.74874053753356 36.32 35.66849964794437 139.7487164377785 36.32 35.66849964794437 139.7487164377785 39.48 35.668491660681 139.74874053753356 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84fdb0aa-2b25-45fe-ae65-cae6acd85c9b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-84fdb0aa-2b25-45fe-ae65-cae6acd85c9b_0">
											<gml:posList>35.668491660681 139.74874053753356 36.32 35.66848576363901 139.74873760551912 39.48 35.66848576363901 139.74873760551912 36.32 35.668491660681 139.74874053753356 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f6b96fa-cce8-4707-9ab0-33c1826bc58c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9f6b96fa-cce8-4707-9ab0-33c1826bc58c_0">
											<gml:posList>35.668491660681 139.74874053753356 36.32 35.668491660681 139.74874053753356 39.48 35.66848576363901 139.74873760551912 39.48 35.668491660681 139.74874053753356 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c5278ad-3035-436f-9e5b-4944f3f89ad6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66851317828781 139.74849968987476 36.32 35.66846672165457 139.74848711345166 36.32 35.66847013993587 139.74847726785123 36.32 35.66851317828781 139.74849968987476 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7ee80bd-0791-44d4-915e-abb46296fd89">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66851317828781 139.74849968987476 36.32 35.66850976902621 139.74850954651603 36.32 35.66846672165457 139.74848711345166 36.32 35.66851317828781 139.74849968987476 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e2180a5d-2335-4151-b124-dcb7ff4d2280">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66850679150465 139.74851809927154 36.32 35.66846209302481 139.74850619478454 36.32 35.66846543032421 139.74849654809904 36.32 35.66850679150465 139.74851809927154 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-64fa1854-83ba-4722-a4d2-bb141c3b035e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66850679150465 139.74851809927154 36.32 35.66850344518983 139.74852774597062 36.32 35.66846209302481 139.74850619478454 36.32 35.66850679150465 139.74851809927154 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-095a17ce-7e2a-4b80-85aa-52972cf0b6db">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66840255490468 139.7485411741381 36.32 35.66842369052227 139.74850052463393 36.32 35.66840910118101 139.74854444787422 36.32 35.66840255490468 139.7485411741381 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bcc3f08f-fb4f-47b4-a162-26c64adedd5b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66840255490468 139.7485411741381 36.32 35.66841713523882 139.74849726195635 36.32 35.66842369052227 139.74850052463393 36.32 35.66840255490468 139.7485411741381 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-897d3d55-d707-4bc7-8368-3ca535a3629e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668431580265285 139.7485043934298 36.32 35.66842438243595 139.7485486733757 36.32 35.66841794437116 139.74854546580016 36.32 35.668431580265285 139.7485043934298 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-facb23e1-f013-481d-9b08-fe3851ebd6f4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668431580265285 139.7485043934298 36.32 35.66843802735267 139.74850761203905 36.32 35.66842438243595 139.7485486733757 36.32 35.668431580265285 139.7485043934298 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b678cded-0696-4069-bcf5-ce5681dfff43">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66841721580697 139.74854766472254 36.32 35.66838875453979 139.7486559786169 36.32 35.66838231647782 139.7486527710342 36.32 35.66841721580697 139.74854766472254 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d81280a-020e-4e78-bc2e-8558cf24db37">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66841721580697 139.74854766472254 36.32 35.6684236538717 139.7485508722982 36.32 35.66838875453979 139.7486559786169 36.32 35.66841721580697 139.74854766472254 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-caf9c788-d28e-42d5-bae3-932a148c0ece">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66836809587871 139.7486443248293 36.32 35.668403469685465 139.74856021645388 36.32 35.66837447984304 139.748647510376 36.32 35.66836809587871 139.7486443248293 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b3aa1a8-02c2-4e0b-9e51-ddcd8330aa5a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66836809587871 139.7486443248293 36.32 35.66839708571886 139.74855703091305 36.32 35.668403469685465 139.74856021645388 36.32 35.66836809587871 139.7486443248293 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-045db146-b96e-4905-bdce-19ae4887647f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66844904105023 139.74863412120501 43.726 35.66842181075035 139.7486215796318 43.726 35.66842869946564 139.74859911585355 43.726 35.66844904105023 139.74863412120501 43.726</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-64c0e214-4d4a-4344-9889-9095093376a6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66845593877377 139.7486116463647 43.726 35.66844904105023 139.74863412120501 43.726 35.66842869946564 139.74859911585355 43.726 35.66845593877377 139.7486116463647 43.726</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b6560698-d162-4b72-9e8a-f0b427d4f353">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66845172689904 139.7486722270491 36.32 35.66845589084162 139.74865883490654 36.32 35.66846762333492 139.74867965526673 36.32 35.66845172689904 139.7486722270491 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-510179f2-4efa-4e37-b898-a5eccd3169f0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6684734600569 139.74866089300076 36.32 35.66846762333492 139.74867965526673 36.32 35.66846651720309 139.74865765280933 36.32 35.6684734600569 139.74866089300076 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3763f7f9-6d1f-42a0-a22c-d14982a0113d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668464966329296 139.74865692541132 36.32 35.66845644842664 139.7486570338205 36.32 35.66845755460617 139.74865346479584 36.32 35.668464966329296 139.74865692541132 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6fea5c77-3346-41fc-92c2-a9beacc81c5d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66846651720309 139.74865765280933 36.32 35.66846762333492 139.74867965526673 36.32 35.668464966329296 139.74865692541132 36.32 35.66846651720309 139.74865765280933 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-afb2b2de-3e2f-4255-a384-ec69d9323641">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668464966329296 139.74865692541132 36.32 35.66845589084162 139.74865883490654 36.32 35.66845644842664 139.7486570338205 36.32 35.668464966329296 139.74865692541132 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba513c55-dce7-4551-bb16-41d4197be202">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66846762333492 139.74867965526673 36.32 35.66845589084162 139.74865883490654 36.32 35.668464966329296 139.74865692541132 36.32 35.66846762333492 139.74867965526673 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9322aa34-2964-49d1-b52c-be7246781bf6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668491660681 139.74874053753356 36.32 35.66848576363901 139.74873760551912 36.32 35.668493759915535 139.748713505756 36.32 35.668491660681 139.74874053753356 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a5cb8901-e014-45f5-a20c-375eed29c1e3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66849964794437 139.7487164377785 36.32 35.668491660681 139.74874053753356 36.32 35.668493759915535 139.748713505756 36.32 35.66849964794437 139.7487164377785 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_92afccda-1b87-4bfc-9c76-d76b0929decd_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df912730-d8ee-4cfb-81c6-452043b58863">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66841871063211 139.74867370893384 36.32 35.66848464213098 139.74870653430688 36.32 35.66847596227931 139.74873272248277 36.32 35.668410030779704 139.74869988604576 36.32 35.66841871063211 139.74867370893384 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b71fd70-8c25-4cc6-9aca-33fd4a9382c5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4b71fd70-8c25-4cc6-9aca-33fd4a9382c5_0">
											<gml:posList>35.668410030779704 139.74869988604576 36.32 35.668410030779704 139.74869988604576 39.48 35.66841871063211 139.74867370893384 39.48 35.66841871063211 139.74867370893384 36.32 35.668410030779704 139.74869988604576 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-96b5ee0c-a799-4e37-82e1-01a75f5d8733">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-96b5ee0c-a799-4e37-82e1-01a75f5d8733_0">
											<gml:posList>35.66847596227931 139.74873272248277 36.32 35.66847596227931 139.74873272248277 39.48 35.668410030779704 139.74869988604576 39.48 35.668410030779704 139.74869988604576 36.32 35.66847596227931 139.74873272248277 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-664d0818-8f50-423b-b188-ee1bcee1ef3a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-664d0818-8f50-423b-b188-ee1bcee1ef3a_0">
											<gml:posList>35.66847596227931 139.74873272248277 39.48 35.66848464213098 139.74870653430688 39.48 35.66841871063211 139.74867370893384 39.48 35.668410030779704 139.74869988604576 39.48 35.66847596227931 139.74873272248277 39.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19b9b5b1-bb6f-40b7-8dbb-62143e9c7ef9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19b9b5b1-bb6f-40b7-8dbb-62143e9c7ef9_0">
											<gml:posList>35.66841871063211 139.74867370893384 36.32 35.66841871063211 139.74867370893384 39.48 35.66848464213098 139.74870653430688 39.48 35.66848464213098 139.74870653430688 36.32 35.66841871063211 139.74867370893384 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-436d401e-77f6-4368-8d39-a6bf62d1bcf9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-436d401e-77f6-4368-8d39-a6bf62d1bcf9_0">
											<gml:posList>35.66848464213098 139.74870653430688 36.32 35.66848464213098 139.74870653430688 39.48 35.66847596227931 139.74873272248277 39.48 35.66847596227931 139.74873272248277 36.32 35.66848464213098 139.74870653430688 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-a7ad2200-d147-4065-90ad-d53766565d29">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a7ad2200-d147-4065-90ad-d53766565d29">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a7ad2200-d147-4065-90ad-d53766565d29">
											<gml:posList>35.668469621136516 139.74864939817172 5.48 35.66853544418164 139.74868180391178 5.48 35.6684979367888 139.74879550685895 5.48 35.66847223897917 139.7487831624353 5.48 35.66847007963996 139.74878879817075 5.48 35.66831309694887 139.7487125255412 5.48 35.66841644389665 139.7483988208278 5.48 35.66854060108913 139.74845281474666 5.48 35.66849553598775 139.74858585629883 5.48 35.66849147879974 139.74858442460697 5.48 35.668469621136516 139.74864939817172 5.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0ffbc0de-2ae7-42df-b1a8-f56eb079bcc1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ffbc0de-2ae7-42df-b1a8-f56eb079bcc1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ffbc0de-2ae7-42df-b1a8-f56eb079bcc1">
											<gml:posList>35.66841644389665 139.7483988208278 36.7 35.66841806949181 139.74840324854785 36.7 35.668536807765896 139.7484548843654 36.7 35.66854060108913 139.74845281474666 36.7 35.66841644389665 139.7483988208278 36.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-25c409d3-7e7b-4990-9a9d-7f9fec65ad71">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25c409d3-7e7b-4990-9a9d-7f9fec65ad71">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25c409d3-7e7b-4990-9a9d-7f9fec65ad71">
											<gml:posList>35.66854060108913 139.74845281474666 36.7 35.668536807765896 139.7484548843654 36.7 35.66851003857314 139.74853391371255 36.7 35.66849553598775 139.74858585629883 36.7 35.66854060108913 139.74845281474666 36.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-742189da-6bd3-40bf-a754-52a2f5cd2001">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-742189da-6bd3-40bf-a754-52a2f5cd2001">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-742189da-6bd3-40bf-a754-52a2f5cd2001">
											<gml:posList>35.66845209020719 139.748509640671 45.555 35.66845389646184 139.74851462050387 45.555 35.668502542123306 139.7485381412132 45.555 35.668506551707445 139.74853597195656 45.555 35.66845209020719 139.748509640671 45.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9a4162a1-e71b-4499-9940-c6d7c32c9edf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a4162a1-e71b-4499-9940-c6d7c32c9edf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a4162a1-e71b-4499-9940-c6d7c32c9edf">
											<gml:posList>35.66831309694887 139.7487125255412 36.7 35.66831681825226 139.7487105775222 36.7 35.66841806949181 139.74840324854785 36.7 35.66841644389665 139.7483988208278 36.7 35.66831309694887 139.7487125255412 36.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bcd6a733-1c69-44a3-83e4-96017b365bba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bcd6a733-1c69-44a3-83e4-96017b365bba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bcd6a733-1c69-44a3-83e4-96017b365bba">
											<gml:posList>35.668506551707445 139.74853597195656 36.7 35.66849147879974 139.74858442460697 36.7 35.66849553598775 139.74858585629883 36.7 35.66851003857314 139.74853391371255 36.7 35.668506551707445 139.74853597195656 36.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0e4dbcfc-9ec5-4af1-8861-4d7b701c4bf9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e4dbcfc-9ec5-4af1-8861-4d7b701c4bf9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e4dbcfc-9ec5-4af1-8861-4d7b701c4bf9">
											<gml:posList>35.66849147879974 139.74858442460697 45.555 35.668506551707445 139.74853597195656 45.555 35.668502542123306 139.7485381412132 45.555 35.66848859338074 139.74858296958473 45.555 35.66849147879974 139.74858442460697 45.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d1309e86-cde4-472f-99ed-fb11838249a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1309e86-cde4-472f-99ed-fb11838249a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1309e86-cde4-472f-99ed-fb11838249a9">
											<gml:posList>35.668412556604125 139.74863860023189 45.555 35.668416575165026 139.74863637574327 45.555 35.66845389646184 139.74851462050387 45.555 35.66845209020719 139.748509640671 45.555 35.668412556604125 139.74863860023189 45.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b71a9651-6cad-41c4-98b8-45f7f170b0e0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b71a9651-6cad-41c4-98b8-45f7f170b0e0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b71a9651-6cad-41c4-98b8-45f7f170b0e0">
											<gml:posList>35.66846672669679 139.74864793211106 43.726 35.66848859338074 139.74858296958473 43.726 35.668502542123306 139.7485381412132 43.726 35.66845389646184 139.74851462050387 43.726 35.668416575165026 139.74863637574327 43.726 35.66845408461623 139.74865388820822 43.726 35.66845573935906 139.7486485070611 43.726 35.668464900328075 139.7486527942784 43.726 35.66846672669679 139.74864793211106 43.726</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-63e617db-7950-4e17-8376-b6d5c73a406c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-63e617db-7950-4e17-8376-b6d5c73a406c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-63e617db-7950-4e17-8376-b6d5c73a406c">
											<gml:posList>35.668506551707445 139.74853597195656 36.32 35.66851003857314 139.74853391371255 36.32 35.668536807765896 139.7484548843654 36.32 35.66841806949181 139.74840324854785 36.32 35.66831681825226 139.7487105775222 36.32 35.668468625296526 139.74878433712146 36.32 35.66847078464329 139.74877871243197 36.32 35.66849633817946 139.7487909796841 36.32 35.66853171385737 139.74868374090096 36.32 35.66847106649451 139.7486538923661 36.32 35.668468478521575 139.74865242598162 36.32 35.66846651720309 139.74865765280933 36.32 35.66845755460617 139.74865346479584 36.32 35.66845589084162 139.74865883490654 36.32 35.668412556604125 139.74863860023189 36.32 35.66845209020719 139.748509640671 36.32 35.668506551707445 139.74853597195656 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-562de1ea-baad-4dcc-95a8-9e681afbe84e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-562de1ea-baad-4dcc-95a8-9e681afbe84e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-562de1ea-baad-4dcc-95a8-9e681afbe84e">
											<gml:posList>35.66849147879974 139.74858442460697 45.555 35.66848859338074 139.74858296958473 45.555 35.66846672669679 139.74864793211106 45.555 35.668469621136516 139.74864939817172 45.555 35.66849147879974 139.74858442460697 45.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e337f10d-0a09-4266-9957-7e7c2215e4b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e337f10d-0a09-4266-9957-7e7c2215e4b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e337f10d-0a09-4266-9957-7e7c2215e4b1">
											<gml:posList>35.66845589084162 139.74865883490654 45.555 35.66845408461623 139.74865388820822 45.555 35.668416575165026 139.74863637574327 45.555 35.668412556604125 139.74863860023189 45.555 35.66845589084162 139.74865883490654 45.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e870f68f-044d-46fb-8e34-201b21ed4b1c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e870f68f-044d-46fb-8e34-201b21ed4b1c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e870f68f-044d-46fb-8e34-201b21ed4b1c">
											<gml:posList>35.66847106649451 139.7486538923661 36.7 35.668469621136516 139.74864939817172 36.7 35.668468478521575 139.74865242598162 36.7 35.66847106649451 139.7486538923661 36.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-604723da-761d-4217-9ff5-d8449fe86181">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-604723da-761d-4217-9ff5-d8449fe86181">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-604723da-761d-4217-9ff5-d8449fe86181">
											<gml:posList>35.668469621136516 139.74864939817172 45.555 35.66846672669679 139.74864793211106 45.555 35.668464900328075 139.7486527942784 45.555 35.66846651720309 139.74865765280933 45.555 35.668469621136516 139.74864939817172 45.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e7034595-a8e9-4caf-be81-455ddf53f878">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e7034595-a8e9-4caf-be81-455ddf53f878">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e7034595-a8e9-4caf-be81-455ddf53f878">
											<gml:posList>35.66845755460617 139.74865346479584 45.555 35.66846651720309 139.74865765280933 45.555 35.668464900328075 139.7486527942784 45.555 35.66845573935906 139.7486485070611 45.555 35.66845755460617 139.74865346479584 45.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-47eb8091-20c9-4eee-8663-dc37195356da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47eb8091-20c9-4eee-8663-dc37195356da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47eb8091-20c9-4eee-8663-dc37195356da">
											<gml:posList>35.66845755460617 139.74865346479584 45.555 35.66845573935906 139.7486485070611 45.555 35.66845408461623 139.74865388820822 45.555 35.66845589084162 139.74865883490654 45.555 35.66845755460617 139.74865346479584 45.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6e344817-d0b7-4203-8048-36a823564ce1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e344817-d0b7-4203-8048-36a823564ce1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e344817-d0b7-4203-8048-36a823564ce1">
											<gml:posList>35.668469621136516 139.74864939817172 36.7 35.66847106649451 139.7486538923661 36.7 35.66853171385737 139.74868374090096 36.7 35.66853544418164 139.74868180391178 36.7 35.668469621136516 139.74864939817172 36.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-081b0fb6-5961-4f37-aae2-7b4cb8191c73">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-081b0fb6-5961-4f37-aae2-7b4cb8191c73">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-081b0fb6-5961-4f37-aae2-7b4cb8191c73">
											<gml:posList>35.66853544418164 139.74868180391178 36.7 35.66853171385737 139.74868374090096 36.7 35.66849633817946 139.7487909796841 36.7 35.6684979367888 139.74879550685895 36.7 35.66853544418164 139.74868180391178 36.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-358c53cb-60ed-4327-b023-bfd5af3ffe44">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-358c53cb-60ed-4327-b023-bfd5af3ffe44">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-358c53cb-60ed-4327-b023-bfd5af3ffe44">
											<gml:posList>35.66847007963996 139.74878879817075 36.7 35.668468625296526 139.74878433712146 36.7 35.66831681825226 139.7487105775222 36.7 35.66831309694887 139.7487125255412 36.7 35.66847007963996 139.74878879817075 36.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7e21a6c0-c270-47f7-a283-0bb2d1b74251">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e21a6c0-c270-47f7-a283-0bb2d1b74251">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e21a6c0-c270-47f7-a283-0bb2d1b74251">
											<gml:posList>35.66847223897917 139.7487831624353 36.7 35.66847078464329 139.74877871243197 36.7 35.668468625296526 139.74878433712146 36.7 35.66847007963996 139.74878879817075 36.7 35.66847223897917 139.7487831624353 36.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6d1d6b57-3c89-46d1-a6ee-dd26043d0dd3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d1d6b57-3c89-46d1-a6ee-dd26043d0dd3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d1d6b57-3c89-46d1-a6ee-dd26043d0dd3">
											<gml:posList>35.66847223897917 139.7487831624353 36.7 35.6684979367888 139.74879550685895 36.7 35.66849633817946 139.7487909796841 36.7 35.66847078464329 139.74877871243197 36.7 35.66847223897917 139.7487831624353 36.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3ac0def1-6505-4907-9e40-776be595cce4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ac0def1-6505-4907-9e40-776be595cce4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ac0def1-6505-4907-9e40-776be595cce4">
											<gml:posList>35.66854060108913 139.74845281474666 5.48 35.66841644389665 139.7483988208278 5.48 35.66841644389665 139.7483988208278 36.7 35.66854060108913 139.74845281474666 36.7 35.66854060108913 139.74845281474666 5.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0fb0ac09-f0fd-4162-af23-e321412b7dd3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0fb0ac09-f0fd-4162-af23-e321412b7dd3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0fb0ac09-f0fd-4162-af23-e321412b7dd3">
											<gml:posList>35.66841806949181 139.74840324854785 36.7 35.66841806949181 139.74840324854785 36.32 35.668536807765896 139.7484548843654 36.32 35.668536807765896 139.7484548843654 36.7 35.66841806949181 139.74840324854785 36.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bc0028de-a324-42d2-97c4-b5edc3dff512">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc0028de-a324-42d2-97c4-b5edc3dff512">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc0028de-a324-42d2-97c4-b5edc3dff512">
											<gml:posList>35.668536807765896 139.7484548843654 36.7 35.668536807765896 139.7484548843654 36.32 35.66851003857314 139.74853391371255 36.32 35.66851003857314 139.74853391371255 36.7 35.668536807765896 139.7484548843654 36.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-72ec1a07-02f4-4069-a5b5-e8902693e36c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-72ec1a07-02f4-4069-a5b5-e8902693e36c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-72ec1a07-02f4-4069-a5b5-e8902693e36c">
											<gml:posList>35.66849553598775 139.74858585629883 5.48 35.66854060108913 139.74845281474666 5.48 35.66854060108913 139.74845281474666 36.7 35.66849553598775 139.74858585629883 36.7 35.66849553598775 139.74858585629883 5.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8e149592-0ec0-4886-ad51-0c69f2fe2ab9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8e149592-0ec0-4886-ad51-0c69f2fe2ab9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8e149592-0ec0-4886-ad51-0c69f2fe2ab9">
											<gml:posList>35.66845209020719 139.748509640671 36.32 35.66845209020719 139.748509640671 45.555 35.668506551707445 139.74853597195656 45.555 35.668506551707445 139.74853597195656 36.7 35.668506551707445 139.74853597195656 36.32 35.66845209020719 139.748509640671 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c66f611f-0686-49d2-b74a-e9700c1bcfd3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c66f611f-0686-49d2-b74a-e9700c1bcfd3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c66f611f-0686-49d2-b74a-e9700c1bcfd3">
											<gml:posList>35.66845389646184 139.74851462050387 45.555 35.66845389646184 139.74851462050387 43.726 35.668502542123306 139.7485381412132 43.726 35.668502542123306 139.7485381412132 45.555 35.66845389646184 139.74851462050387 45.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-66e74dab-5e0d-4f53-a71e-f621f684335b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66e74dab-5e0d-4f53-a71e-f621f684335b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66e74dab-5e0d-4f53-a71e-f621f684335b">
											<gml:posList>35.66851003857314 139.74853391371255 36.7 35.66851003857314 139.74853391371255 36.32 35.668506551707445 139.74853597195656 36.32 35.668506551707445 139.74853597195656 36.7 35.66851003857314 139.74853391371255 36.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-68d98a13-0b83-452f-bab1-0dceb733d975">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-68d98a13-0b83-452f-bab1-0dceb733d975">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-68d98a13-0b83-452f-bab1-0dceb733d975">
											<gml:posList>35.66841644389665 139.7483988208278 5.48 35.66831309694887 139.7487125255412 5.48 35.66831309694887 139.7487125255412 36.7 35.66841644389665 139.7483988208278 36.7 35.66841644389665 139.7483988208278 5.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ba923cda-c580-48e2-9162-30fce9f5b596">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba923cda-c580-48e2-9162-30fce9f5b596">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba923cda-c580-48e2-9162-30fce9f5b596">
											<gml:posList>35.66831681825226 139.7487105775222 36.7 35.66831681825226 139.7487105775222 36.32 35.66841806949181 139.74840324854785 36.32 35.66841806949181 139.74840324854785 36.7 35.66831681825226 139.7487105775222 36.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cee0976b-8d9d-4889-8880-a5823b2dfe30">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cee0976b-8d9d-4889-8880-a5823b2dfe30">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cee0976b-8d9d-4889-8880-a5823b2dfe30">
											<gml:posList>35.668506551707445 139.74853597195656 45.555 35.66849147879974 139.74858442460697 45.555 35.66849147879974 139.74858442460697 36.7 35.668506551707445 139.74853597195656 36.7 35.668506551707445 139.74853597195656 45.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-22bbd441-7258-40fc-8f42-473e40448835">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22bbd441-7258-40fc-8f42-473e40448835">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22bbd441-7258-40fc-8f42-473e40448835">
											<gml:posList>35.668502542123306 139.7485381412132 45.555 35.668502542123306 139.7485381412132 43.726 35.66848859338074 139.74858296958473 43.726 35.66848859338074 139.74858296958473 45.555 35.668502542123306 139.7485381412132 45.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-22a395a3-0840-40a1-a437-3a55d2bcf7f5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22a395a3-0840-40a1-a437-3a55d2bcf7f5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22a395a3-0840-40a1-a437-3a55d2bcf7f5">
											<gml:posList>35.668412556604125 139.74863860023189 45.555 35.66845209020719 139.748509640671 45.555 35.66845209020719 139.748509640671 36.32 35.668412556604125 139.74863860023189 36.32 35.668412556604125 139.74863860023189 45.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b9d96e1b-e1b8-4570-ac0d-cf845cdc2d3f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b9d96e1b-e1b8-4570-ac0d-cf845cdc2d3f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b9d96e1b-e1b8-4570-ac0d-cf845cdc2d3f">
											<gml:posList>35.668416575165026 139.74863637574327 45.555 35.668416575165026 139.74863637574327 43.726 35.66845389646184 139.74851462050387 43.726 35.66845389646184 139.74851462050387 45.555 35.668416575165026 139.74863637574327 45.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aae509c8-d2af-4686-b38e-05b28eb0b970">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aae509c8-d2af-4686-b38e-05b28eb0b970">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aae509c8-d2af-4686-b38e-05b28eb0b970">
											<gml:posList>35.66849147879974 139.74858442460697 5.48 35.66849553598775 139.74858585629883 5.48 35.66849553598775 139.74858585629883 36.7 35.66849147879974 139.74858442460697 36.7 35.66849147879974 139.74858442460697 5.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d310e553-e601-44aa-a9f5-fcd4879993d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d310e553-e601-44aa-a9f5-fcd4879993d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d310e553-e601-44aa-a9f5-fcd4879993d4">
											<gml:posList>35.66848859338074 139.74858296958473 45.555 35.66848859338074 139.74858296958473 43.726 35.66846672669679 139.74864793211106 43.726 35.66846672669679 139.74864793211106 45.555 35.66848859338074 139.74858296958473 45.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cd04c5bc-0010-4301-ad5f-c5328430f2d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd04c5bc-0010-4301-ad5f-c5328430f2d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd04c5bc-0010-4301-ad5f-c5328430f2d5">
											<gml:posList>35.66849147879974 139.74858442460697 36.7 35.66849147879974 139.74858442460697 45.555 35.668469621136516 139.74864939817172 45.555 35.668469621136516 139.74864939817172 36.7 35.668469621136516 139.74864939817172 5.48 35.66849147879974 139.74858442460697 5.48 35.66849147879974 139.74858442460697 36.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-41592396-652f-452d-88cd-efe558a55aae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41592396-652f-452d-88cd-efe558a55aae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41592396-652f-452d-88cd-efe558a55aae">
											<gml:posList>35.66845408461623 139.74865388820822 45.555 35.66845408461623 139.74865388820822 43.726 35.668416575165026 139.74863637574327 43.726 35.668416575165026 139.74863637574327 45.555 35.66845408461623 139.74865388820822 45.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7f363da6-af3f-4824-b49e-211db9959856">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f363da6-af3f-4824-b49e-211db9959856">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f363da6-af3f-4824-b49e-211db9959856">
											<gml:posList>35.668412556604125 139.74863860023189 36.32 35.66845589084162 139.74865883490654 36.32 35.66845589084162 139.74865883490654 45.555 35.668412556604125 139.74863860023189 45.555 35.668412556604125 139.74863860023189 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-47028f44-032e-496c-8e18-196359be3a23">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47028f44-032e-496c-8e18-196359be3a23">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47028f44-032e-496c-8e18-196359be3a23">
											<gml:posList>35.66846672669679 139.74864793211106 45.555 35.66846672669679 139.74864793211106 43.726 35.668464900328075 139.7486527942784 43.726 35.668464900328075 139.7486527942784 45.555 35.66846672669679 139.74864793211106 45.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b13f4f79-8af0-4de9-b733-100236a379b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b13f4f79-8af0-4de9-b733-100236a379b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b13f4f79-8af0-4de9-b733-100236a379b6">
											<gml:posList>35.668464900328075 139.7486527942784 45.555 35.668464900328075 139.7486527942784 43.726 35.66845573935906 139.7486485070611 43.726 35.66845573935906 139.7486485070611 45.555 35.668464900328075 139.7486527942784 45.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5a038251-de43-41b9-903d-694628fbda35">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a038251-de43-41b9-903d-694628fbda35">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a038251-de43-41b9-903d-694628fbda35">
											<gml:posList>35.66845573935906 139.7486485070611 45.555 35.66845573935906 139.7486485070611 43.726 35.66845408461623 139.74865388820822 43.726 35.66845408461623 139.74865388820822 45.555 35.66845573935906 139.7486485070611 45.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-304d797a-0044-4bf8-b0c1-5f558c3fb871">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-304d797a-0044-4bf8-b0c1-5f558c3fb871">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-304d797a-0044-4bf8-b0c1-5f558c3fb871">
											<gml:posList>35.668468478521575 139.74865242598162 36.7 35.668468478521575 139.74865242598162 36.32 35.66847106649451 139.7486538923661 36.32 35.66847106649451 139.7486538923661 36.7 35.668468478521575 139.74865242598162 36.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6a335f17-dad9-4283-b00d-fc40b2664679">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a335f17-dad9-4283-b00d-fc40b2664679">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a335f17-dad9-4283-b00d-fc40b2664679">
											<gml:posList>35.668469621136516 139.74864939817172 45.555 35.66846651720309 139.74865765280933 45.555 35.66846651720309 139.74865765280933 36.32 35.668468478521575 139.74865242598162 36.32 35.668468478521575 139.74865242598162 36.7 35.668469621136516 139.74864939817172 36.7 35.668469621136516 139.74864939817172 45.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a5a36394-035d-4aaa-bdac-e3a50e7d6ab6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5a36394-035d-4aaa-bdac-e3a50e7d6ab6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5a36394-035d-4aaa-bdac-e3a50e7d6ab6">
											<gml:posList>35.66845755460617 139.74865346479584 36.32 35.66846651720309 139.74865765280933 36.32 35.66846651720309 139.74865765280933 45.555 35.66845755460617 139.74865346479584 45.555 35.66845755460617 139.74865346479584 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e9b1ff57-c92a-478d-b2fc-1c71850b49a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e9b1ff57-c92a-478d-b2fc-1c71850b49a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e9b1ff57-c92a-478d-b2fc-1c71850b49a5">
											<gml:posList>35.66845589084162 139.74865883490654 36.32 35.66845755460617 139.74865346479584 36.32 35.66845755460617 139.74865346479584 45.555 35.66845589084162 139.74865883490654 45.555 35.66845589084162 139.74865883490654 36.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8f31d4b2-a961-4abb-afb0-8d7824fb1e0f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f31d4b2-a961-4abb-afb0-8d7824fb1e0f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f31d4b2-a961-4abb-afb0-8d7824fb1e0f">
											<gml:posList>35.66853544418164 139.74868180391178 5.48 35.668469621136516 139.74864939817172 5.48 35.668469621136516 139.74864939817172 36.7 35.66853544418164 139.74868180391178 36.7 35.66853544418164 139.74868180391178 5.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-193b8bd2-493b-4271-bf72-f130a465d485">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-193b8bd2-493b-4271-bf72-f130a465d485">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-193b8bd2-493b-4271-bf72-f130a465d485">
											<gml:posList>35.66847106649451 139.7486538923661 36.7 35.66847106649451 139.7486538923661 36.32 35.66853171385737 139.74868374090096 36.32 35.66853171385737 139.74868374090096 36.7 35.66847106649451 139.7486538923661 36.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f451f924-ed9f-4e37-a344-cf1754a0fcf6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f451f924-ed9f-4e37-a344-cf1754a0fcf6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f451f924-ed9f-4e37-a344-cf1754a0fcf6">
											<gml:posList>35.66853171385737 139.74868374090096 36.7 35.66853171385737 139.74868374090096 36.32 35.66849633817946 139.7487909796841 36.32 35.66849633817946 139.7487909796841 36.7 35.66853171385737 139.74868374090096 36.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cdc96f8b-cbf0-46d9-a16d-2c3cea2ab619">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cdc96f8b-cbf0-46d9-a16d-2c3cea2ab619">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cdc96f8b-cbf0-46d9-a16d-2c3cea2ab619">
											<gml:posList>35.6684979367888 139.74879550685895 5.48 35.66853544418164 139.74868180391178 5.48 35.66853544418164 139.74868180391178 36.7 35.6684979367888 139.74879550685895 36.7 35.6684979367888 139.74879550685895 5.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5b37c617-c9d0-4eb9-83b8-a373e2dae8ab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b37c617-c9d0-4eb9-83b8-a373e2dae8ab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b37c617-c9d0-4eb9-83b8-a373e2dae8ab">
											<gml:posList>35.668468625296526 139.74878433712146 36.7 35.668468625296526 139.74878433712146 36.32 35.66831681825226 139.7487105775222 36.32 35.66831681825226 139.7487105775222 36.7 35.668468625296526 139.74878433712146 36.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ec31c56e-72b5-480a-8e6a-fa54db620b2c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec31c56e-72b5-480a-8e6a-fa54db620b2c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec31c56e-72b5-480a-8e6a-fa54db620b2c">
											<gml:posList>35.66831309694887 139.7487125255412 5.48 35.66847007963996 139.74878879817075 5.48 35.66847007963996 139.74878879817075 36.7 35.66831309694887 139.7487125255412 36.7 35.66831309694887 139.7487125255412 5.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-63640590-fd63-455d-8b28-c7d39826cd89">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-63640590-fd63-455d-8b28-c7d39826cd89">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-63640590-fd63-455d-8b28-c7d39826cd89">
											<gml:posList>35.66847078464329 139.74877871243197 36.7 35.66847078464329 139.74877871243197 36.32 35.668468625296526 139.74878433712146 36.32 35.668468625296526 139.74878433712146 36.7 35.66847078464329 139.74877871243197 36.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8c5af23a-f25e-4812-896a-78734c956bbf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c5af23a-f25e-4812-896a-78734c956bbf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c5af23a-f25e-4812-896a-78734c956bbf">
											<gml:posList>35.66849633817946 139.7487909796841 36.7 35.66849633817946 139.7487909796841 36.32 35.66847078464329 139.74877871243197 36.32 35.66847078464329 139.74877871243197 36.7 35.66849633817946 139.7487909796841 36.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-67acf4d8-48c6-426d-bcc6-e2ee8a5cc5a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67acf4d8-48c6-426d-bcc6-e2ee8a5cc5a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67acf4d8-48c6-426d-bcc6-e2ee8a5cc5a5">
											<gml:posList>35.66847007963996 139.74878879817075 5.48 35.66847223897917 139.7487831624353 5.48 35.66847223897917 139.7487831624353 36.7 35.66847007963996 139.74878879817075 36.7 35.66847007963996 139.74878879817075 5.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-755a4938-6036-4048-971e-82cdf4eab15c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-755a4938-6036-4048-971e-82cdf4eab15c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-755a4938-6036-4048-971e-82cdf4eab15c">
											<gml:posList>35.66847223897917 139.7487831624353 5.48 35.6684979367888 139.74879550685895 5.48 35.6684979367888 139.74879550685895 36.7 35.66847223897917 139.7487831624353 36.7 35.66847223897917 139.7487831624353 5.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-3351</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">529.11985</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.11</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>