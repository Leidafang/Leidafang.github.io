<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_939e7a0e-f09a-4cd2-a286-fc6acf8964d2">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門駅南地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">15.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.668869154217774 139.749744965499 0 35.668829479247215 139.74972401937072 0 35.66879323149173 139.7498358431098 0 35.66883263472952 139.74985491173888 0 35.668869154217774 139.749744965499 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668869154217774 139.749744965499 6.008 35.66883263472952 139.74985491173888 6.008 35.66879323149173 139.7498358431098 6.008 35.668829479247215 139.74972401937072 6.008 35.668869154217774 139.749744965499 6.008</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668869154217774 139.749744965499 6.008 35.668829479247215 139.74972401937072 6.008 35.668829479247215 139.74972401937072 21.82 35.668869154217774 139.749744965499 21.82 35.668869154217774 139.749744965499 6.008</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668829479247215 139.74972401937072 6.008 35.66879323149173 139.7498358431098 6.008 35.66879323149173 139.7498358431098 21.82 35.668829479247215 139.74972401937072 21.82 35.668829479247215 139.74972401937072 6.008</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66879323149173 139.7498358431098 6.008 35.66883263472952 139.74985491173888 6.008 35.66883263472952 139.74985491173888 21.82 35.66879323149173 139.7498358431098 21.82 35.66879323149173 139.7498358431098 6.008</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66883263472952 139.74985491173888 6.008 35.668869154217774 139.749744965499 6.008 35.668869154217774 139.749744965499 21.82 35.66883263472952 139.74985491173888 21.82 35.66883263472952 139.74985491173888 6.008</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668869154217774 139.749744965499 21.82 35.668829479247215 139.74972401937072 21.82 35.66879323149173 139.7498358431098 21.82 35.66883263472952 139.74985491173888 21.82 35.668869154217774 139.749744965499 21.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-20406739-8511-4e58-8e6d-026819e603ae"/>
							<gml:surfaceMember xlink:href="#poly-0d8c1fb2-f30f-44dd-90c9-92d72f4c68f6"/>
							<gml:surfaceMember xlink:href="#poly-c222f32e-42fa-4c2b-94ac-bde2e68baa38"/>
							<gml:surfaceMember xlink:href="#poly-0767d5a1-130b-4896-be6b-c5a84c464cdf"/>
							<gml:surfaceMember xlink:href="#poly-6d998625-d898-44d6-ac86-5c2f5a853a3b"/>
							<gml:surfaceMember xlink:href="#poly-11a00008-a1e1-45e5-b276-79c15c4eca27"/>
							<gml:surfaceMember xlink:href="#poly-2fd8d39c-e8c6-4073-8a23-776c5721c418"/>
							<gml:surfaceMember xlink:href="#poly-91e93497-3895-4738-a3dc-b3033a6b4d50"/>
							<gml:surfaceMember xlink:href="#poly-fbfbda3c-1085-4eb3-bd47-526479d64433"/>
							<gml:surfaceMember xlink:href="#poly-d5b61a83-1d1c-4d9d-9fb9-cb952e67a96f"/>
							<gml:surfaceMember xlink:href="#poly-45a8d866-3c23-4f8b-86e5-912a7def2c38"/>
							<gml:surfaceMember xlink:href="#poly-7a7e761d-67e6-493d-8943-480feab3ffbd"/>
							<gml:surfaceMember xlink:href="#poly-b12a00b6-2711-4fb7-93cc-1e3efdcb2a68"/>
							<gml:surfaceMember xlink:href="#poly-770259ec-a0a8-4f9b-b3cc-12c68cc44aff"/>
							<gml:surfaceMember xlink:href="#poly-37dba98e-5b06-4e8a-aaed-9298146160b0"/>
							<gml:surfaceMember xlink:href="#poly-38e96607-2cbf-4e2d-8cef-1a519abbbc3e"/>
							<gml:surfaceMember xlink:href="#poly-2373b3e0-ed94-46f0-ab89-56e78703de1a"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-20406739-8511-4e58-8e6d-026819e603ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20406739-8511-4e58-8e6d-026819e603ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20406739-8511-4e58-8e6d-026819e603ae">
											<gml:posList>35.66886915421773 139.749744965499 6.008 35.66883263472948 139.74985491173888 6.008 35.668793231491726 139.7498358431098 6.008 35.66882947924721 139.74972401937072 6.008 35.66886915421773 139.749744965499 6.008</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0d8c1fb2-f30f-44dd-90c9-92d72f4c68f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d8c1fb2-f30f-44dd-90c9-92d72f4c68f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d8c1fb2-f30f-44dd-90c9-92d72f4c68f6">
											<gml:posList>35.66881668408523 139.74984719611382 24.3 35.66881550997247 139.7498438393387 24.3 35.66879598868123 139.74983438216105 24.3 35.668793231491726 139.7498358431098 24.3 35.66881668408523 139.74984719611382 24.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c222f32e-42fa-4c2b-94ac-bde2e68baa38">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c222f32e-42fa-4c2b-94ac-bde2e68baa38">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c222f32e-42fa-4c2b-94ac-bde2e68baa38">
											<gml:posList>35.668793231491726 139.7498358431098 24.3 35.66879598868123 139.74983438216105 24.3 35.668825634478 139.7497429010727 24.3 35.66882446033933 139.74973951116064 24.3 35.668793231491726 139.7498358431098 24.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0767d5a1-130b-4896-be6b-c5a84c464cdf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0767d5a1-130b-4896-be6b-c5a84c464cdf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0767d5a1-130b-4896-be6b-c5a84c464cdf">
											<gml:posList>35.668845715018406 139.74975292099705 24.04 35.668825634478 139.7497429010727 24.04 35.66879598868123 139.74983438216105 24.04 35.66881550997247 139.7498438393387 24.04 35.668845715018406 139.74975292099705 24.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6d998625-d898-44d6-ac86-5c2f5a853a3b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d998625-d898-44d6-ac86-5c2f5a853a3b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d998625-d898-44d6-ac86-5c2f5a853a3b">
											<gml:posList>35.66884847222989 139.74975149318263 24.3 35.668845715018406 139.74975292099705 24.3 35.66881550997247 139.7498438393387 24.3 35.66881668408523 139.74984719611382 24.3 35.66884847222989 139.74975149318263 24.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-11a00008-a1e1-45e5-b276-79c15c4eca27">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11a00008-a1e1-45e5-b276-79c15c4eca27">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11a00008-a1e1-45e5-b276-79c15c4eca27">
											<gml:posList>35.66882947924721 139.74972401937072 22.2 35.66882446033933 139.74973951116064 24.3 35.66884847222989 139.74975149318263 24.3 35.66882947924721 139.74972401937072 22.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2fd8d39c-e8c6-4073-8a23-776c5721c418">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2fd8d39c-e8c6-4073-8a23-776c5721c418">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2fd8d39c-e8c6-4073-8a23-776c5721c418">
											<gml:posList>35.66882446033933 139.74973951116064 24.3 35.668825634478 139.7497429010727 24.3 35.668845715018406 139.74975292099705 24.3 35.66884847222989 139.74975149318263 24.3 35.66882446033933 139.74973951116064 24.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-91e93497-3895-4738-a3dc-b3033a6b4d50">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-91e93497-3895-4738-a3dc-b3033a6b4d50">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-91e93497-3895-4738-a3dc-b3033a6b4d50">
											<gml:posList>35.66884847222989 139.74975149318263 24.3 35.66881668408523 139.74984719611382 24.3 35.66883263472948 139.74985491173888 22.2 35.66886915421773 139.749744965499 22.2 35.66884847222989 139.74975149318263 24.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fbfbda3c-1085-4eb3-bd47-526479d64433">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fbfbda3c-1085-4eb3-bd47-526479d64433">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fbfbda3c-1085-4eb3-bd47-526479d64433">
											<gml:posList>35.66884847222989 139.74975149318263 24.3 35.66886915421773 139.749744965499 22.2 35.66882947924721 139.74972401937072 22.2 35.66884847222989 139.74975149318263 24.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d5b61a83-1d1c-4d9d-9fb9-cb952e67a96f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5b61a83-1d1c-4d9d-9fb9-cb952e67a96f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5b61a83-1d1c-4d9d-9fb9-cb952e67a96f">
											<gml:posList>35.668845715018406 139.74975292099705 24.3 35.668845715018406 139.74975292099705 24.04 35.66881550997247 139.7498438393387 24.04 35.66881550997247 139.7498438393387 24.3 35.668845715018406 139.74975292099705 24.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-45a8d866-3c23-4f8b-86e5-912a7def2c38">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45a8d866-3c23-4f8b-86e5-912a7def2c38">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45a8d866-3c23-4f8b-86e5-912a7def2c38">
											<gml:posList>35.66881550997247 139.7498438393387 24.3 35.66881550997247 139.7498438393387 24.04 35.66879598868123 139.74983438216105 24.04 35.66879598868123 139.74983438216105 24.3 35.66881550997247 139.7498438393387 24.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7a7e761d-67e6-493d-8943-480feab3ffbd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a7e761d-67e6-493d-8943-480feab3ffbd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a7e761d-67e6-493d-8943-480feab3ffbd">
											<gml:posList>35.66879598868123 139.74983438216105 24.3 35.66879598868123 139.74983438216105 24.04 35.668825634478 139.7497429010727 24.04 35.668825634478 139.7497429010727 24.3 35.66879598868123 139.74983438216105 24.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b12a00b6-2711-4fb7-93cc-1e3efdcb2a68">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b12a00b6-2711-4fb7-93cc-1e3efdcb2a68">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b12a00b6-2711-4fb7-93cc-1e3efdcb2a68">
											<gml:posList>35.66882947924721 139.74972401937072 22.2 35.66882947924721 139.74972401937072 6.008 35.668793231491726 139.7498358431098 6.008 35.668793231491726 139.7498358431098 24.3 35.66882446033933 139.74973951116064 24.3 35.66882947924721 139.74972401937072 22.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-770259ec-a0a8-4f9b-b3cc-12c68cc44aff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-770259ec-a0a8-4f9b-b3cc-12c68cc44aff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-770259ec-a0a8-4f9b-b3cc-12c68cc44aff">
											<gml:posList>35.668793231491726 139.7498358431098 24.3 35.668793231491726 139.7498358431098 6.008 35.66883263472948 139.74985491173888 6.008 35.66883263472948 139.74985491173888 22.2 35.66881668408523 139.74984719611382 24.3 35.668793231491726 139.7498358431098 24.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-37dba98e-5b06-4e8a-aaed-9298146160b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37dba98e-5b06-4e8a-aaed-9298146160b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37dba98e-5b06-4e8a-aaed-9298146160b0">
											<gml:posList>35.668825634478 139.7497429010727 24.3 35.668825634478 139.7497429010727 24.04 35.668845715018406 139.74975292099705 24.04 35.668845715018406 139.74975292099705 24.3 35.668825634478 139.7497429010727 24.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-38e96607-2cbf-4e2d-8cef-1a519abbbc3e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38e96607-2cbf-4e2d-8cef-1a519abbbc3e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38e96607-2cbf-4e2d-8cef-1a519abbbc3e">
											<gml:posList>35.66886915421773 139.749744965499 6.008 35.66882947924721 139.74972401937072 6.008 35.66882947924721 139.74972401937072 22.2 35.66886915421773 139.749744965499 22.2 35.66886915421773 139.749744965499 6.008</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2373b3e0-ed94-46f0-ab89-56e78703de1a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2373b3e0-ed94-46f0-ab89-56e78703de1a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2373b3e0-ed94-46f0-ab89-56e78703de1a">
											<gml:posList>35.66886915421773 139.749744965499 22.2 35.66883263472948 139.74985491173888 22.2 35.66883263472948 139.74985491173888 6.008 35.66886915421773 139.749744965499 6.008 35.66886915421773 139.749744965499 22.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-3885</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">51.34515</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>