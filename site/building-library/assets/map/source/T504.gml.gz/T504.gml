<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_940253de-d03b-4bc5-89f5-390afe602dd9">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">18.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67183989708729 139.73820262480203 0 35.67186050350461 139.73827241399843 0 35.67196745884988 139.7382247873266 0 35.671946762355304 139.73815510862116 0 35.67183989708729 139.73820262480203 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67183989708729 139.73820262480203 10.02 35.671946762355304 139.73815510862116 10.02 35.67196745884988 139.7382247873266 10.02 35.67186050350461 139.73827241399843 10.02 35.67183989708729 139.73820262480203 10.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67183989708729 139.73820262480203 10.02 35.67186050350461 139.73827241399843 10.02 35.67186050350461 139.73827241399843 28.2 35.67183989708729 139.73820262480203 28.2 35.67183989708729 139.73820262480203 10.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67186050350461 139.73827241399843 10.02 35.67196745884988 139.7382247873266 10.02 35.67196745884988 139.7382247873266 28.2 35.67186050350461 139.73827241399843 28.2 35.67186050350461 139.73827241399843 10.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67196745884988 139.7382247873266 10.02 35.671946762355304 139.73815510862116 10.02 35.671946762355304 139.73815510862116 28.2 35.67196745884988 139.7382247873266 28.2 35.67196745884988 139.7382247873266 10.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671946762355304 139.73815510862116 10.02 35.67183989708729 139.73820262480203 10.02 35.67183989708729 139.73820262480203 28.2 35.671946762355304 139.73815510862116 28.2 35.671946762355304 139.73815510862116 10.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67183989708729 139.73820262480203 28.2 35.67186050350461 139.73827241399843 28.2 35.67196745884988 139.7382247873266 28.2 35.671946762355304 139.73815510862116 28.2 35.67183989708729 139.73820262480203 28.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-1bd63482-a87e-49fa-addf-208f04fb83b7"/>
							<gml:surfaceMember xlink:href="#poly-08a16121-5d75-4005-ac77-e7de792325aa"/>
							<gml:surfaceMember xlink:href="#poly-c07442ae-2524-4090-a5c3-73a97c388172"/>
							<gml:surfaceMember xlink:href="#poly-9c8d8c72-22ae-4c13-8021-da91cb283475"/>
							<gml:surfaceMember xlink:href="#poly-504b58b8-dc2e-41f3-884f-bdb52610bd1d"/>
							<gml:surfaceMember xlink:href="#poly-28e88661-875b-4eac-844e-5453ff6ab2cf"/>
							<gml:surfaceMember xlink:href="#poly-6d502593-e0cb-4a33-8a28-268154af8aff"/>
							<gml:surfaceMember xlink:href="#poly-53d6d428-33b9-4328-9296-58fe7f881afb"/>
							<gml:surfaceMember xlink:href="#poly-f8a722a3-4a27-4922-b878-bc03d8fdb7c7"/>
							<gml:surfaceMember xlink:href="#poly-395d0a7b-bb81-421a-af19-879f107a4742"/>
							<gml:surfaceMember xlink:href="#poly-9fcce2ab-6b43-4ca8-86c3-d0ffbed911dc"/>
							<gml:surfaceMember xlink:href="#poly-c8a09c2c-f80d-444c-8590-3716c9c04a41"/>
							<gml:surfaceMember xlink:href="#poly-50bc2da4-c3ab-4d08-a21f-cedcdecc11b8"/>
							<gml:surfaceMember xlink:href="#poly-ccc4caf2-4766-43ac-b5f7-923f7a9d08e6"/>
							<gml:surfaceMember xlink:href="#poly-5cce6459-2ded-4444-9aa8-39a5e212c2ee"/>
							<gml:surfaceMember xlink:href="#poly-c057f147-3558-4c3c-86c0-e5024bd8220f"/>
							<gml:surfaceMember xlink:href="#poly-51e3e297-5072-4199-965d-76ca07b88d43"/>
							<gml:surfaceMember xlink:href="#poly-fd297ef3-7e4b-466e-8a17-bcc46cd605b2"/>
							<gml:surfaceMember xlink:href="#poly-105f2e2d-39e7-479e-a486-f0f1cbf2edb0"/>
							<gml:surfaceMember xlink:href="#poly-ec30459e-60e5-4908-a468-00c79a142707"/>
							<gml:surfaceMember xlink:href="#poly-6097bb53-f753-40cf-ba40-f2c89123cb65"/>
							<gml:surfaceMember xlink:href="#poly-554b1bf0-2247-4c7b-bb5b-916e369b24c1"/>
							<gml:surfaceMember xlink:href="#poly-f1e4ee63-6fd1-4c79-b9a2-e6449c79b37e"/>
							<gml:surfaceMember xlink:href="#poly-2816a8f5-1c95-413c-9b9e-d20925bb2655"/>
							<gml:surfaceMember xlink:href="#poly-69fc33aa-f597-4065-ba94-96eedaa35ab0"/>
							<gml:surfaceMember xlink:href="#poly-8078a50d-fdce-4b03-ad2b-36ed87178382"/>
							<gml:surfaceMember xlink:href="#poly-d3dc1c11-d2e3-4d1c-9855-f689770b16db"/>
							<gml:surfaceMember xlink:href="#poly-f91b34d3-148d-48d3-a40e-706b413f101e"/>
							<gml:surfaceMember xlink:href="#poly-599658cf-a4b1-451a-9544-4e81fabe1366"/>
							<gml:surfaceMember xlink:href="#poly-cda32901-4fdf-4319-a6e4-83deab57ecfa"/>
							<gml:surfaceMember xlink:href="#poly-a0e6cb5a-0023-4998-bb0a-44121be75b00"/>
							<gml:surfaceMember xlink:href="#poly-add19bb0-598a-464a-96de-8f83fae4c5f7"/>
							<gml:surfaceMember xlink:href="#poly-bda39c75-4d7d-4ed1-a7c2-1ebabcee3ba4"/>
							<gml:surfaceMember xlink:href="#poly-25f8aff4-b90f-4aaf-b7e4-a6a2da633217"/>
							<gml:surfaceMember xlink:href="#poly-6395d8ba-206d-4aae-a06e-ec1d24b1ab2c"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_940253de-d03b-4bc5-89f5-390afe602dd9_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60aab5d6-9ab7-485e-ba50-a4a45a913b7e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67194176560802 139.73818534875343 28.26 35.67192690718631 139.73819195008465 28.26 35.67192216232642 139.7381759383315 28.26 35.67193702074725 139.7381693369977 28.26 35.67194176560802 139.73818534875343 28.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5bc47ac2-161b-4bda-81a5-3f59f8d26775">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67189791551336 139.73819889957826 32.365 35.671894038267176 139.73818579202182 32.365 35.67190356243456 139.73818156096755 32.365 35.671907448694924 139.73819466851467 32.365 35.67189791551336 139.73819889957826 32.365</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-424d9a24-b95f-4756-a61b-76a9d45fd135">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-424d9a24-b95f-4756-a61b-76a9d45fd135_0">
											<gml:posList>35.67189791551336 139.73819889957826 32.365 35.67189791551336 139.73819889957826 33.881 35.671894038267176 139.73818579202182 33.881 35.671894038267176 139.73818579202182 32.365 35.67189791551336 139.73819889957826 32.365</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eba28583-c298-4660-b646-23f77499614e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eba28583-c298-4660-b646-23f77499614e_0">
											<gml:posList>35.67190356243456 139.73818156096755 32.365 35.671894038267176 139.73818579202182 32.365 35.671894038267176 139.73818579202182 33.881 35.67190356243456 139.73818156096755 33.881 35.67190356243456 139.73818156096755 32.365</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f91af47-3e79-4659-b8fa-6d7f3ba91571">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f91af47-3e79-4659-b8fa-6d7f3ba91571_0">
											<gml:posList>35.67189791551336 139.73819889957826 33.881 35.671907448694924 139.73819466851467 33.881 35.67190356243456 139.73818156096755 33.881 35.671894038267176 139.73818579202182 33.881 35.67189791551336 139.73819889957826 33.881</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c87b0185-f337-48f0-8863-88e3542f9cbe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c87b0185-f337-48f0-8863-88e3542f9cbe_0">
											<gml:posList>35.67189791551336 139.73819889957826 32.365 35.671907448694924 139.73819466851467 32.365 35.671907448694924 139.73819466851467 33.881 35.67189791551336 139.73819889957826 33.881 35.67189791551336 139.73819889957826 32.365</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f413643c-2971-4604-86a0-b85eb1a1b427">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f413643c-2971-4604-86a0-b85eb1a1b427_0">
											<gml:posList>35.671907448694924 139.73819466851467 32.365 35.67190356243456 139.73818156096755 32.365 35.67190356243456 139.73818156096755 33.881 35.671907448694924 139.73819466851467 33.881 35.671907448694924 139.73819466851467 32.365</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f0f3558-072f-49f2-a095-1280ce9ad44b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f0f3558-072f-49f2-a095-1280ce9ad44b_0">
											<gml:posList>35.67192216232642 139.7381759383315 28.26 35.67192690718631 139.73819195008465 28.26 35.67192690718631 139.73819195008465 30.765 35.67192216232642 139.7381759383315 30.765 35.67192216232642 139.7381759383315 28.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-921a510c-2741-466f-a5b8-4f9c9e3e8139">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-921a510c-2741-466f-a5b8-4f9c9e3e8139_0">
											<gml:posList>35.67192216232642 139.7381759383315 28.26 35.67192216232642 139.7381759383315 30.765 35.67193702074725 139.7381693369977 30.765 35.67193702074725 139.7381693369977 28.26 35.67192216232642 139.7381759383315 28.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59b28eec-111e-4fe4-897c-5d9670276261">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-59b28eec-111e-4fe4-897c-5d9670276261_0">
											<gml:posList>35.67194176560802 139.73818534875343 30.765 35.67193702074725 139.7381693369977 30.765 35.67192216232642 139.7381759383315 30.765 35.67192690718631 139.73819195008465 30.765 35.67194176560802 139.73818534875343 30.765</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3bd7972-ec24-4b74-b75a-621688a9622b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3bd7972-ec24-4b74-b75a-621688a9622b_0">
											<gml:posList>35.67192690718631 139.73819195008465 28.26 35.67194176560802 139.73818534875343 28.26 35.67194176560802 139.73818534875343 30.765 35.67192690718631 139.73819195008465 30.765 35.67192690718631 139.73819195008465 28.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ed347187-8174-4d0d-ba39-c0f0a1626bec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ed347187-8174-4d0d-ba39-c0f0a1626bec_0">
											<gml:posList>35.67194176560802 139.73818534875343 28.26 35.67193702074725 139.7381693369977 28.26 35.67193702074725 139.7381693369977 30.765 35.67194176560802 139.73818534875343 30.765 35.67194176560802 139.73818534875343 28.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-1bd63482-a87e-49fa-addf-208f04fb83b7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1bd63482-a87e-49fa-addf-208f04fb83b7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1bd63482-a87e-49fa-addf-208f04fb83b7">
											<gml:posList>35.67183989708728 139.73820262480203 10.02 35.671946762355276 139.73815510862116 10.02 35.671967458849856 139.7382247873266 10.02 35.67186050350462 139.7382724139984 10.02 35.67183989708728 139.73820262480203 10.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-08a16121-5d75-4005-ac77-e7de792325aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-08a16121-5d75-4005-ac77-e7de792325aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-08a16121-5d75-4005-ac77-e7de792325aa">
											<gml:posList>35.67185924928305 139.73822509243803 28.528 35.671847995073115 139.7382300766964 26.543 35.67186050350462 139.7382724139984 26.543 35.67187159550422 139.7382674741234 28.528 35.67185924928305 139.73822509243803 28.528</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c07442ae-2524-4090-a5c3-73a97c388172">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c07442ae-2524-4090-a5c3-73a97c388172">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c07442ae-2524-4090-a5c3-73a97c388172">
											<gml:posList>35.671847995073115 139.7382300766964 26.524 35.671881307138406 139.7382152791022 26.524 35.671873182108065 139.73818782723004 26.524 35.67183989708728 139.73820262480203 26.524 35.671847995073115 139.7382300766964 26.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9c8d8c72-22ae-4c13-8021-da91cb283475">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c8d8c72-22ae-4c13-8021-da91cb283475">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c8d8c72-22ae-4c13-8021-da91cb283475">
											<gml:posList>35.67187159550422 139.7382674741234 28.603 35.67187373635646 139.7382618820736 28.603 35.67186377622955 139.7382276940332 28.603 35.67185924928305 139.73822509243803 28.603 35.67187159550422 139.7382674741234 28.603</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-504b58b8-dc2e-41f3-884f-bdb52610bd1d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-504b58b8-dc2e-41f3-884f-bdb52610bd1d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-504b58b8-dc2e-41f3-884f-bdb52610bd1d">
											<gml:posList>35.67185924928305 139.73822509243803 28.603 35.67186377622955 139.7382276940332 28.603 35.67187918428961 139.73822083799303 28.603 35.671881307138406 139.7382152791022 28.603 35.67185924928305 139.73822509243803 28.603</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-28e88661-875b-4eac-844e-5453ff6ab2cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28e88661-875b-4eac-844e-5453ff6ab2cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28e88661-875b-4eac-844e-5453ff6ab2cf">
											<gml:posList>35.67188228321176 139.73821855874462 32.476 35.6718839383069 139.73821421551978 32.476 35.67187672612347 139.73818987766674 32.476 35.671873182108065 139.73818782723004 32.476 35.67188228321176 139.73821855874462 32.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6d502593-e0cb-4a33-8a28-268154af8aff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d502593-e0cb-4a33-8a28-268154af8aff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d502593-e0cb-4a33-8a28-268154af8aff">
											<gml:posList>35.671881307138406 139.7382152791022 28.603 35.67187918428961 139.73822083799303 28.603 35.67188251819673 139.73821935381142 28.603 35.67188228321176 139.73821855874462 28.603 35.671881307138406 139.7382152791022 28.603</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-53d6d428-33b9-4328-9296-58fe7f881afb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-53d6d428-33b9-4328-9296-58fe7f881afb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-53d6d428-33b9-4328-9296-58fe7f881afb">
											<gml:posList>35.671873182108065 139.73818782723004 32.476 35.67187672612347 139.73818987766674 32.476 35.67190442458291 139.738177550076 32.476 35.67190608867282 139.73817318474548 32.476 35.671873182108065 139.73818782723004 32.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f8a722a3-4a27-4922-b878-bc03d8fdb7c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f8a722a3-4a27-4922-b878-bc03d8fdb7c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f8a722a3-4a27-4922-b878-bc03d8fdb7c7">
											<gml:posList>35.67191163677753 139.73820189898282 32.365 35.67190442458291 139.738177550076 32.365 35.67187672612347 139.73818987766674 32.365 35.6718839383069 139.73821421551978 32.365 35.67191163677753 139.73820189898282 32.365</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-395d0a7b-bb81-421a-af19-879f107a4742">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-395d0a7b-bb81-421a-af19-879f107a4742">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-395d0a7b-bb81-421a-af19-879f107a4742">
											<gml:posList>35.67191518978894 139.7382039273175 32.476 35.67191163677753 139.73820189898282 32.476 35.6718839383069 139.73821421551978 32.476 35.67188228321176 139.73821855874462 32.476 35.67191518978894 139.7382039273175 32.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9fcce2ab-6b43-4ca8-86c3-d0ffbed911dc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9fcce2ab-6b43-4ca8-86c3-d0ffbed911dc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9fcce2ab-6b43-4ca8-86c3-d0ffbed911dc">
											<gml:posList>35.67190608867282 139.73817318474548 32.476 35.67190442458291 139.738177550076 32.476 35.67191163677753 139.73820189898282 32.476 35.67191518978894 139.7382039273175 32.476 35.67190608867282 139.73817318474548 32.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c8a09c2c-f80d-444c-8590-3716c9c04a41">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8a09c2c-f80d-444c-8590-3716c9c04a41">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8a09c2c-f80d-444c-8590-3716c9c04a41">
											<gml:posList>35.67196290485348 139.73822217471388 28.26 35.6719446305043 139.73816067857527 28.26 35.671907299741285 139.73817727050178 28.26 35.67191518978894 139.7382039273175 28.26 35.67188228321176 139.73821855874462 28.26 35.67188251819673 139.73821935381142 28.26 35.67187918428961 139.73822083799303 28.26 35.67186377622955 139.7382276940332 28.26 35.67187373635646 139.7382618820736 28.26 35.67196290485348 139.73822217471388 28.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-50bc2da4-c3ab-4d08-a21f-cedcdecc11b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50bc2da4-c3ab-4d08-a21f-cedcdecc11b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50bc2da4-c3ab-4d08-a21f-cedcdecc11b8">
											<gml:posList>35.671967458849856 139.7382247873266 28.603 35.67196290485348 139.73822217471388 28.603 35.67187373635646 139.7382618820736 28.603 35.67187159550422 139.7382674741234 28.603 35.671967458849856 139.7382247873266 28.603</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ccc4caf2-4766-43ac-b5f7-923f7a9d08e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ccc4caf2-4766-43ac-b5f7-923f7a9d08e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ccc4caf2-4766-43ac-b5f7-923f7a9d08e6">
											<gml:posList>35.6719446305043 139.73816067857527 28.603 35.671946762355276 139.73815510862116 28.603 35.67190608867282 139.73817318474548 28.603 35.671907299741285 139.73817727050178 28.603 35.6719446305043 139.73816067857527 28.603</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5cce6459-2ded-4444-9aa8-39a5e212c2ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5cce6459-2ded-4444-9aa8-39a5e212c2ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5cce6459-2ded-4444-9aa8-39a5e212c2ee">
											<gml:posList>35.671946762355276 139.73815510862116 28.603 35.6719446305043 139.73816067857527 28.603 35.67196290485348 139.73822217471388 28.603 35.671967458849856 139.7382247873266 28.603 35.671946762355276 139.73815510862116 28.603</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c057f147-3558-4c3c-86c0-e5024bd8220f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c057f147-3558-4c3c-86c0-e5024bd8220f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c057f147-3558-4c3c-86c0-e5024bd8220f">
											<gml:posList>35.67191163677753 139.73820189898282 32.476 35.67191163677753 139.73820189898282 32.365 35.6718839383069 139.73821421551978 32.365 35.6718839383069 139.73821421551978 32.476 35.67191163677753 139.73820189898282 32.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-51e3e297-5072-4199-965d-76ca07b88d43">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-51e3e297-5072-4199-965d-76ca07b88d43">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-51e3e297-5072-4199-965d-76ca07b88d43">
											<gml:posList>35.67188251819673 139.73821935381142 28.603 35.67188251819673 139.73821935381142 28.26 35.67188228321176 139.73821855874462 28.26 35.67188228321176 139.73821855874462 28.603 35.67188251819673 139.73821935381142 28.603</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fd297ef3-7e4b-466e-8a17-bcc46cd605b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fd297ef3-7e4b-466e-8a17-bcc46cd605b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fd297ef3-7e4b-466e-8a17-bcc46cd605b2">
											<gml:posList>35.67187918428961 139.73822083799303 28.603 35.67187918428961 139.73822083799303 28.26 35.67188251819673 139.73821935381142 28.26 35.67188251819673 139.73821935381142 28.603 35.67187918428961 139.73822083799303 28.603</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-105f2e2d-39e7-479e-a486-f0f1cbf2edb0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-105f2e2d-39e7-479e-a486-f0f1cbf2edb0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-105f2e2d-39e7-479e-a486-f0f1cbf2edb0">
											<gml:posList>35.67186377622955 139.7382276940332 28.603 35.67186377622955 139.7382276940332 28.26 35.67187918428961 139.73822083799303 28.26 35.67187918428961 139.73822083799303 28.603 35.67186377622955 139.7382276940332 28.603</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ec30459e-60e5-4908-a468-00c79a142707">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec30459e-60e5-4908-a468-00c79a142707">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec30459e-60e5-4908-a468-00c79a142707">
											<gml:posList>35.671847995073115 139.7382300766964 26.524 35.67183989708728 139.73820262480203 26.524 35.67183989708728 139.73820262480203 10.02 35.67186050350462 139.7382724139984 10.02 35.67186050350462 139.7382724139984 26.543 35.671847995073115 139.7382300766964 26.543 35.671847995073115 139.7382300766964 26.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6097bb53-f753-40cf-ba40-f2c89123cb65">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6097bb53-f753-40cf-ba40-f2c89123cb65">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6097bb53-f753-40cf-ba40-f2c89123cb65">
											<gml:posList>35.671881307138406 139.7382152791022 28.603 35.671881307138406 139.7382152791022 26.524 35.671847995073115 139.7382300766964 26.524 35.671847995073115 139.7382300766964 26.543 35.67185924928305 139.73822509243803 28.528 35.67185924928305 139.73822509243803 28.603 35.671881307138406 139.7382152791022 28.603</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-554b1bf0-2247-4c7b-bb5b-916e369b24c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-554b1bf0-2247-4c7b-bb5b-916e369b24c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-554b1bf0-2247-4c7b-bb5b-916e369b24c1">
											<gml:posList>35.67187159550422 139.7382674741234 28.603 35.67185924928305 139.73822509243803 28.603 35.67185924928305 139.73822509243803 28.528 35.67187159550422 139.7382674741234 28.528 35.67187159550422 139.7382674741234 28.603</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f1e4ee63-6fd1-4c79-b9a2-e6449c79b37e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f1e4ee63-6fd1-4c79-b9a2-e6449c79b37e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f1e4ee63-6fd1-4c79-b9a2-e6449c79b37e">
											<gml:posList>35.67187373635646 139.7382618820736 28.603 35.67187373635646 139.7382618820736 28.26 35.67186377622955 139.7382276940332 28.26 35.67186377622955 139.7382276940332 28.603 35.67187373635646 139.7382618820736 28.603</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2816a8f5-1c95-413c-9b9e-d20925bb2655">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2816a8f5-1c95-413c-9b9e-d20925bb2655">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2816a8f5-1c95-413c-9b9e-d20925bb2655">
											<gml:posList>35.671873182108065 139.73818782723004 32.476 35.671873182108065 139.73818782723004 26.524 35.671881307138406 139.7382152791022 26.524 35.671881307138406 139.7382152791022 28.603 35.67188228321176 139.73821855874462 28.603 35.67188228321176 139.73821855874462 32.476 35.671873182108065 139.73818782723004 32.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-69fc33aa-f597-4065-ba94-96eedaa35ab0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69fc33aa-f597-4065-ba94-96eedaa35ab0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69fc33aa-f597-4065-ba94-96eedaa35ab0">
											<gml:posList>35.6718839383069 139.73821421551978 32.476 35.6718839383069 139.73821421551978 32.365 35.67187672612347 139.73818987766674 32.365 35.67187672612347 139.73818987766674 32.476 35.6718839383069 139.73821421551978 32.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8078a50d-fdce-4b03-ad2b-36ed87178382">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8078a50d-fdce-4b03-ad2b-36ed87178382">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8078a50d-fdce-4b03-ad2b-36ed87178382">
											<gml:posList>35.67187672612347 139.73818987766674 32.476 35.67187672612347 139.73818987766674 32.365 35.67190442458291 139.738177550076 32.365 35.67190442458291 139.738177550076 32.476 35.67187672612347 139.73818987766674 32.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d3dc1c11-d2e3-4d1c-9855-f689770b16db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3dc1c11-d2e3-4d1c-9855-f689770b16db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3dc1c11-d2e3-4d1c-9855-f689770b16db">
											<gml:posList>35.67190608867282 139.73817318474548 28.603 35.671946762355276 139.73815510862116 28.603 35.671946762355276 139.73815510862116 10.02 35.67183989708728 139.73820262480203 10.02 35.67183989708728 139.73820262480203 26.524 35.671873182108065 139.73818782723004 26.524 35.671873182108065 139.73818782723004 32.476 35.67190608867282 139.73817318474548 32.476 35.67190608867282 139.73817318474548 28.603</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f91b34d3-148d-48d3-a40e-706b413f101e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f91b34d3-148d-48d3-a40e-706b413f101e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f91b34d3-148d-48d3-a40e-706b413f101e">
											<gml:posList>35.67191518978894 139.7382039273175 28.26 35.67191518978894 139.7382039273175 32.476 35.67188228321176 139.73821855874462 32.476 35.67188228321176 139.73821855874462 28.603 35.67188228321176 139.73821855874462 28.26 35.67191518978894 139.7382039273175 28.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-599658cf-a4b1-451a-9544-4e81fabe1366">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-599658cf-a4b1-451a-9544-4e81fabe1366">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-599658cf-a4b1-451a-9544-4e81fabe1366">
											<gml:posList>35.67190442458291 139.738177550076 32.476 35.67190442458291 139.738177550076 32.365 35.67191163677753 139.73820189898282 32.365 35.67191163677753 139.73820189898282 32.476 35.67190442458291 139.738177550076 32.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cda32901-4fdf-4319-a6e4-83deab57ecfa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cda32901-4fdf-4319-a6e4-83deab57ecfa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cda32901-4fdf-4319-a6e4-83deab57ecfa">
											<gml:posList>35.671907299741285 139.73817727050178 28.603 35.67190608867282 139.73817318474548 28.603 35.67190608867282 139.73817318474548 32.476 35.67191518978894 139.7382039273175 32.476 35.67191518978894 139.7382039273175 28.26 35.671907299741285 139.73817727050178 28.26 35.671907299741285 139.73817727050178 28.603</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a0e6cb5a-0023-4998-bb0a-44121be75b00">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a0e6cb5a-0023-4998-bb0a-44121be75b00">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a0e6cb5a-0023-4998-bb0a-44121be75b00">
											<gml:posList>35.67186050350462 139.7382724139984 10.02 35.671967458849856 139.7382247873266 10.02 35.671967458849856 139.7382247873266 28.603 35.67187159550422 139.7382674741234 28.603 35.67187159550422 139.7382674741234 28.528 35.67186050350462 139.7382724139984 26.543 35.67186050350462 139.7382724139984 10.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-add19bb0-598a-464a-96de-8f83fae4c5f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-add19bb0-598a-464a-96de-8f83fae4c5f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-add19bb0-598a-464a-96de-8f83fae4c5f7">
											<gml:posList>35.67196290485348 139.73822217471388 28.603 35.67196290485348 139.73822217471388 28.26 35.67187373635646 139.7382618820736 28.26 35.67187373635646 139.7382618820736 28.603 35.67196290485348 139.73822217471388 28.603</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bda39c75-4d7d-4ed1-a7c2-1ebabcee3ba4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bda39c75-4d7d-4ed1-a7c2-1ebabcee3ba4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bda39c75-4d7d-4ed1-a7c2-1ebabcee3ba4">
											<gml:posList>35.671907299741285 139.73817727050178 28.603 35.671907299741285 139.73817727050178 28.26 35.6719446305043 139.73816067857527 28.26 35.6719446305043 139.73816067857527 28.603 35.671907299741285 139.73817727050178 28.603</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-25f8aff4-b90f-4aaf-b7e4-a6a2da633217">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25f8aff4-b90f-4aaf-b7e4-a6a2da633217">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25f8aff4-b90f-4aaf-b7e4-a6a2da633217">
											<gml:posList>35.6719446305043 139.73816067857527 28.603 35.6719446305043 139.73816067857527 28.26 35.67196290485348 139.73822217471388 28.26 35.67196290485348 139.73822217471388 28.603 35.6719446305043 139.73816067857527 28.603</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6395d8ba-206d-4aae-a06e-ec1d24b1ab2c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6395d8ba-206d-4aae-a06e-ec1d24b1ab2c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6395d8ba-206d-4aae-a06e-ec1d24b1ab2c">
											<gml:posList>35.671967458849856 139.7382247873266 10.02 35.671946762355276 139.73815510862116 10.02 35.671946762355276 139.73815510862116 28.603 35.671967458849856 139.7382247873266 28.603 35.671967458849856 139.7382247873266 10.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8636</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">84.74155</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.05</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>