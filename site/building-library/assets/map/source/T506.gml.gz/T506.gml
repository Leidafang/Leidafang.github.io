<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_94940952-882a-4247-b89f-680fc99d8f51">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">36.1</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67093324981179 139.741498225975 0 35.67093279140025 139.7415708561572 0 35.670955217726124 139.7415710735094 0 35.670954709214215 139.7415898197282 0 35.67102456082975 139.74150076146253 0 35.67101113027117 139.74147699406183 0 35.670948817904986 139.741476402672 0 35.67093324981179 139.741498225975 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67093324981179 139.741498225975 8.29 35.670948817904986 139.741476402672 8.29 35.67101113027117 139.74147699406183 8.29 35.67102456082975 139.74150076146253 8.29 35.670954709214215 139.7415898197282 8.29 35.670955217726124 139.7415710735094 8.29 35.67093279140025 139.7415708561572 8.29 35.67093324981179 139.741498225975 8.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67093324981179 139.741498225975 8.29 35.67093279140025 139.7415708561572 8.29 35.67093279140025 139.7415708561572 44.37 35.67093324981179 139.741498225975 44.37 35.67093324981179 139.741498225975 8.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67093279140025 139.7415708561572 8.29 35.670955217726124 139.7415710735094 8.29 35.670955217726124 139.7415710735094 44.37 35.67093279140025 139.7415708561572 44.37 35.67093279140025 139.7415708561572 8.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670955217726124 139.7415710735094 8.29 35.670954709214215 139.7415898197282 8.29 35.670954709214215 139.7415898197282 44.37 35.670955217726124 139.7415710735094 44.37 35.670955217726124 139.7415710735094 8.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670954709214215 139.7415898197282 8.29 35.67102456082975 139.74150076146253 8.29 35.67102456082975 139.74150076146253 44.37 35.670954709214215 139.7415898197282 44.37 35.670954709214215 139.7415898197282 8.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67102456082975 139.74150076146253 8.29 35.67101113027117 139.74147699406183 8.29 35.67101113027117 139.74147699406183 44.37 35.67102456082975 139.74150076146253 44.37 35.67102456082975 139.74150076146253 8.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67101113027117 139.74147699406183 8.29 35.670948817904986 139.741476402672 8.29 35.670948817904986 139.741476402672 44.37 35.67101113027117 139.74147699406183 44.37 35.67101113027117 139.74147699406183 8.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670948817904986 139.741476402672 8.29 35.67093324981179 139.741498225975 8.29 35.67093324981179 139.741498225975 44.37 35.670948817904986 139.741476402672 44.37 35.670948817904986 139.741476402672 8.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67093324981179 139.741498225975 44.37 35.67093279140025 139.7415708561572 44.37 35.670955217726124 139.7415710735094 44.37 35.670954709214215 139.7415898197282 44.37 35.67102456082975 139.74150076146253 44.37 35.67101113027117 139.74147699406183 44.37 35.670948817904986 139.741476402672 44.37 35.67093324981179 139.741498225975 44.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-23160269-ad81-4c47-b400-b287e5c9e71b"/>
							<gml:surfaceMember xlink:href="#poly-e2afd39d-47da-46e5-b12d-417d3c710a15"/>
							<gml:surfaceMember xlink:href="#poly-943a301b-f52c-4d2b-a3f3-3c0949dd3349"/>
							<gml:surfaceMember xlink:href="#poly-b7dd86b7-2bed-4112-bc7a-a64afb669a0f"/>
							<gml:surfaceMember xlink:href="#poly-41bb085c-deec-4be0-87cb-5b907d769787"/>
							<gml:surfaceMember xlink:href="#poly-d94b6a87-892e-4f0d-8728-15596daeaa55"/>
							<gml:surfaceMember xlink:href="#poly-7511bc80-25fd-49cc-a4ef-33ef633d6fdd"/>
							<gml:surfaceMember xlink:href="#poly-36350a85-0c8f-4719-b58d-690f9692d098"/>
							<gml:surfaceMember xlink:href="#poly-c73ea725-bc66-4192-88d5-e2d86d020db8"/>
							<gml:surfaceMember xlink:href="#poly-b33aabe1-a3dd-4e27-b2df-e9597591e293"/>
							<gml:surfaceMember xlink:href="#poly-c4837f13-6a8c-4e4b-95b3-8acc97f05fd8"/>
							<gml:surfaceMember xlink:href="#poly-6fa5ffb7-2e55-495a-ace4-cd3e361660ef"/>
							<gml:surfaceMember xlink:href="#poly-0caba67f-2a50-474e-94c5-240426fdde3a"/>
							<gml:surfaceMember xlink:href="#poly-b0926d49-8e66-474d-9330-b56c7617fb12"/>
							<gml:surfaceMember xlink:href="#poly-ce9330a5-1223-4b0d-8111-1f5931e1f677"/>
							<gml:surfaceMember xlink:href="#poly-701b1973-011b-41de-9e32-2933ff4ba6f3"/>
							<gml:surfaceMember xlink:href="#poly-c2ce8175-e685-4c21-a696-d352af579e9a"/>
							<gml:surfaceMember xlink:href="#poly-3f9c6c93-fb0a-4318-b022-63ff35e18714"/>
							<gml:surfaceMember xlink:href="#poly-5d25fa42-ef9a-4e08-82cc-e00dfb6242aa"/>
							<gml:surfaceMember xlink:href="#poly-b24c7443-2cf3-44b8-bfcc-b590fe425a1e"/>
							<gml:surfaceMember xlink:href="#poly-9f8cf861-441f-42ac-b3b2-9846d6b63b8d"/>
							<gml:surfaceMember xlink:href="#poly-e95ebba5-33c5-4457-abcc-0930e13f149a"/>
							<gml:surfaceMember xlink:href="#poly-02c2cc1f-8eb3-4a52-ba3b-be54bd3f74b6"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_94940952-882a-4247-b89f-680fc99d8f51_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d9c1998-162c-48dc-a904-cae005e183db">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670940540616904 139.74156745606274 45.037 35.67095730626633 139.74156760256855 45.037 35.67095726297398 139.74156993339565 45.037 35.67094050606046 139.7415694223502 45.037 35.670940540616904 139.74156745606274 45.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58a686b3-f3c4-4fa7-933c-bf89cb5bdd55">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67095730626633 139.74156760256855 44.674 35.670940540616904 139.74156745606274 44.674 35.67094121825914 139.74153409534983 44.674 35.670957975164356 139.74153459534156 44.674 35.67095730626633 139.74156760256855 44.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-674f0371-f8f6-4aab-88ae-af8c6281f216">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67097118025539 139.74154638876067 44.674 35.6709618599236 139.741546211643 44.674 35.67096205506236 139.74153023841237 44.674 35.67097138440789 139.74153041551784 44.674 35.67097118025539 139.74154638876067 44.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-23463ab6-2007-47ba-b896-6b8720d1a15d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6709682218838 139.74156759007502 44.674 35.67096138376615 139.74156009743703 44.674 35.67096574185278 139.74155411637847 44.674 35.67097276038837 139.74156179659767 44.674 35.6709682218838 139.74156759007502 44.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-66b22681-72c0-4323-a685-0496fc23cd8a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670969475835044 139.74156895838607 45.037 35.6709682218838 139.74156759007502 45.037 35.67097276038837 139.74156179659767 45.037 35.67097383392212 139.7415629773274 45.037 35.670969475835044 139.74156895838607 45.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-052c1a65-c3c3-4e8b-8a8f-a14221e8625f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670984162199694 139.74153741531467 44.674 35.670988221936675 139.74154208326976 44.674 35.670976065216706 139.7415575841587 44.674 35.67097216788729 139.74155312589806 44.674 35.670984162199694 139.74153741531467 44.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-83c486d8-4291-4d3e-9a38-f8862dd0edf4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670977219983435 139.74155890839785 45.037 35.670976065216706 139.7415575841587 45.037 35.670988221936675 139.74154208326976 45.037 35.67098920529128 139.74154320887098 45.037 35.670977219983435 139.74155890839785 45.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b868619d-0a85-473d-8797-c6e5a0308e0d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67097851013526 139.74152499465117 44.674 35.67097871153812 139.74149360071655 44.674 35.670989194589545 139.7414937102182 44.674 35.67098899317824 139.7415250931106 44.674 35.67097851013526 139.74152499465117 44.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-888860c4-39f9-4e07-b2ff-7565eb8d211d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-888860c4-39f9-4e07-b2ff-7565eb8d211d_0">
											<gml:posList>35.670976065216706 139.7415575841587 45.037 35.670977219983435 139.74155890839785 45.037 35.670977219983435 139.74155890839785 46.417 35.67097216788729 139.74155312589806 46.417 35.67097216788729 139.74155312589806 44.674 35.670976065216706 139.7415575841587 44.674 35.670976065216706 139.7415575841587 45.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc346527-83df-40db-8e01-50f9d6dac337">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc346527-83df-40db-8e01-50f9d6dac337_0">
											<gml:posList>35.670989194589545 139.7414937102182 44.674 35.67097871153812 139.74149360071655 44.674 35.67097871153812 139.74149360071655 46.785 35.670989194589545 139.7414937102182 46.785 35.670989194589545 139.7414937102182 44.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dbb14d24-4dbb-48d1-9c33-74eaae6527b6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dbb14d24-4dbb-48d1-9c33-74eaae6527b6_0">
											<gml:posList>35.67097871153812 139.74149360071655 44.674 35.67097851013526 139.74152499465117 44.674 35.67097851013526 139.74152499465117 46.785 35.67097871153812 139.74149360071655 46.785 35.67097871153812 139.74149360071655 44.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf58932d-98a4-42b9-9165-1cef8f5db0db">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bf58932d-98a4-42b9-9165-1cef8f5db0db_0">
											<gml:posList>35.67097851013526 139.74152499465117 46.785 35.67098899317824 139.7415250931106 46.785 35.670989194589545 139.7414937102182 46.785 35.67097871153812 139.74149360071655 46.785 35.67097851013526 139.74152499465117 46.785</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c94348c-3a7f-4cf1-b3a9-0155c895807c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6c94348c-3a7f-4cf1-b3a9-0155c895807c_0">
											<gml:posList>35.67098899317824 139.7415250931106 44.674 35.670989194589545 139.7414937102182 44.674 35.670989194589545 139.7414937102182 46.785 35.67098899317824 139.7415250931106 46.785 35.67098899317824 139.7415250931106 44.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4ca48871-a312-4522-8f73-d1f13250292d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4ca48871-a312-4522-8f73-d1f13250292d_0">
											<gml:posList>35.67097851013526 139.74152499465117 44.674 35.67098899317824 139.7415250931106 44.674 35.67098899317824 139.7415250931106 46.785 35.67097851013526 139.74152499465117 46.785 35.67097851013526 139.74152499465117 44.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1756cc26-b140-4fd8-8bfb-0f7ed8f60495">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1756cc26-b140-4fd8-8bfb-0f7ed8f60495_0">
											<gml:posList>35.67097138440789 139.74153041551784 44.674 35.67096205506236 139.74153023841237 44.674 35.67096205506236 139.74153023841237 45.52 35.67097138440789 139.74153041551784 45.52 35.67097138440789 139.74153041551784 44.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b5cc6d3-e4b2-4841-95fb-85117d56ae02">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7b5cc6d3-e4b2-4841-95fb-85117d56ae02_0">
											<gml:posList>35.67094121825914 139.74153409534983 45.681 35.670957975164356 139.74153459534156 45.681 35.670957975164356 139.74153459534156 44.674 35.67094121825914 139.74153409534983 44.674 35.67094121825914 139.74153409534983 45.681</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff24c353-f980-404b-9f95-8e0b96242781">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ff24c353-f980-404b-9f95-8e0b96242781_0">
											<gml:posList>35.67096205506236 139.74153023841237 44.674 35.6709618599236 139.741546211643 44.674 35.6709618599236 139.741546211643 45.52 35.67096205506236 139.74153023841237 45.52 35.67096205506236 139.74153023841237 44.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-494d3d37-65ad-4c4f-9751-d36169e7c620">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-494d3d37-65ad-4c4f-9751-d36169e7c620_0">
											<gml:posList>35.67096205506236 139.74153023841237 45.52 35.6709618599236 139.741546211643 45.52 35.67097118025539 139.74154638876067 45.52 35.67097138440789 139.74153041551784 45.52 35.67096205506236 139.74153023841237 45.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d9204be-2e27-4748-b609-411a75191792">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d9204be-2e27-4748-b609-411a75191792_0">
											<gml:posList>35.67097118025539 139.74154638876067 44.674 35.67097138440789 139.74153041551784 44.674 35.67097138440789 139.74153041551784 45.52 35.67097118025539 139.74154638876067 45.52 35.67097118025539 139.74154638876067 44.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd644c04-c10b-4d6d-856f-7ef41441d882">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dd644c04-c10b-4d6d-856f-7ef41441d882_0">
											<gml:posList>35.670984162199694 139.74153741531467 44.674 35.670984162199694 139.74153741531467 46.417 35.67098920529128 139.74154320887098 46.417 35.67098920529128 139.74154320887098 45.037 35.670988221936675 139.74154208326976 45.037 35.670988221936675 139.74154208326976 44.674 35.670984162199694 139.74153741531467 44.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b7ece977-fe28-4d00-abd5-0947881f21cc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b7ece977-fe28-4d00-abd5-0947881f21cc_0">
											<gml:posList>35.670984162199694 139.74153741531467 44.674 35.67097216788729 139.74155312589806 44.674 35.67097216788729 139.74155312589806 46.417 35.670984162199694 139.74153741531467 46.417 35.670984162199694 139.74153741531467 44.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd094fe6-109c-41e4-8ede-1f578f03a1a7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bd094fe6-109c-41e4-8ede-1f578f03a1a7_0">
											<gml:posList>35.67097118025539 139.74154638876067 44.674 35.67097118025539 139.74154638876067 45.52 35.6709618599236 139.741546211643 45.52 35.6709618599236 139.741546211643 44.674 35.67097118025539 139.74154638876067 44.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d3ecdb9-1937-4bab-86e9-eb7382809ce3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6d3ecdb9-1937-4bab-86e9-eb7382809ce3_0">
											<gml:posList>35.670984162199694 139.74153741531467 46.417 35.67097216788729 139.74155312589806 46.417 35.670977219983435 139.74155890839785 46.417 35.67098920529128 139.74154320887098 46.417 35.670984162199694 139.74153741531467 46.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df31849d-3b3f-4aa5-a2e1-6582a05f5e8f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-df31849d-3b3f-4aa5-a2e1-6582a05f5e8f_0">
											<gml:posList>35.670988221936675 139.74154208326976 45.037 35.670976065216706 139.7415575841587 45.037 35.670976065216706 139.7415575841587 44.674 35.670988221936675 139.74154208326976 44.674 35.670988221936675 139.74154208326976 45.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-be24a095-ae9e-4e4f-bbd4-10e60eb969fe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-be24a095-ae9e-4e4f-bbd4-10e60eb969fe_0">
											<gml:posList>35.670977219983435 139.74155890839785 45.037 35.67098920529128 139.74154320887098 45.037 35.67098920529128 139.74154320887098 46.417 35.670977219983435 139.74155890839785 46.417 35.670977219983435 139.74155890839785 45.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-49d32ad3-c27b-45d3-93d8-07359c5b8721">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-49d32ad3-c27b-45d3-93d8-07359c5b8721_0">
											<gml:posList>35.67094050606046 139.7415694223502 45.681 35.67094121825914 139.74153409534983 45.681 35.67094121825914 139.74153409534983 44.674 35.670940540616904 139.74156745606274 44.674 35.670940540616904 139.74156745606274 45.037 35.67094050606046 139.7415694223502 45.037 35.67094050606046 139.7415694223502 45.681</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-79ad9fa8-8c5a-4c38-bfff-37ea57d149af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-79ad9fa8-8c5a-4c38-bfff-37ea57d149af_0">
											<gml:posList>35.67094050606046 139.7415694223502 45.681 35.67095726297398 139.74156993339565 45.681 35.670957975164356 139.74153459534156 45.681 35.67094121825914 139.74153409534983 45.681 35.67094050606046 139.7415694223502 45.681</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb4da067-52e8-4b98-a8a3-65b5a7a90444">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb4da067-52e8-4b98-a8a3-65b5a7a90444_0">
											<gml:posList>35.67095730626633 139.74156760256855 45.037 35.67095730626633 139.74156760256855 44.674 35.670957975164356 139.74153459534156 44.674 35.670957975164356 139.74153459534156 45.681 35.67095726297398 139.74156993339565 45.681 35.67095726297398 139.74156993339565 45.037 35.67095730626633 139.74156760256855 45.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a135e831-e016-42d2-92ed-01be3e356051">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a135e831-e016-42d2-92ed-01be3e356051_0">
											<gml:posList>35.67096574185278 139.74155411637847 44.674 35.67096138376615 139.74156009743703 44.674 35.67096138376615 139.74156009743703 46.417 35.67096574185278 139.74155411637847 46.417 35.67096574185278 139.74155411637847 44.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f6174dcd-5a39-48a6-a2a5-39f37c53cfbb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f6174dcd-5a39-48a6-a2a5-39f37c53cfbb_0">
											<gml:posList>35.67096574185278 139.74155411637847 44.674 35.67096574185278 139.74155411637847 46.417 35.67097383392212 139.7415629773274 46.417 35.67097383392212 139.7415629773274 45.037 35.67097276038837 139.74156179659767 45.037 35.67097276038837 139.74156179659767 44.674 35.67096574185278 139.74155411637847 44.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f689b21d-ccc0-4854-be39-e711fc993829">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f689b21d-ccc0-4854-be39-e711fc993829_0">
											<gml:posList>35.67096574185278 139.74155411637847 46.417 35.67096138376615 139.74156009743703 46.417 35.670969475835044 139.74156895838607 46.417 35.67097383392212 139.7415629773274 46.417 35.67096574185278 139.74155411637847 46.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb52f676-6c41-4e73-a9c5-fdbe73640904">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fb52f676-6c41-4e73-a9c5-fdbe73640904_0">
											<gml:posList>35.6709682218838 139.74156759007502 45.037 35.670969475835044 139.74156895838607 45.037 35.670969475835044 139.74156895838607 46.417 35.67096138376615 139.74156009743703 46.417 35.67096138376615 139.74156009743703 44.674 35.6709682218838 139.74156759007502 44.674 35.6709682218838 139.74156759007502 45.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c49273d-629d-4a89-a2cd-2289476a8921">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c49273d-629d-4a89-a2cd-2289476a8921_0">
											<gml:posList>35.67097276038837 139.74156179659767 45.037 35.6709682218838 139.74156759007502 45.037 35.6709682218838 139.74156759007502 44.674 35.67097276038837 139.74156179659767 44.674 35.67097276038837 139.74156179659767 45.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c97a174f-ca87-4abb-a040-d8e07f3273ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c97a174f-ca87-4abb-a040-d8e07f3273ce_0">
											<gml:posList>35.670969475835044 139.74156895838607 45.037 35.67097383392212 139.7415629773274 45.037 35.67097383392212 139.7415629773274 46.417 35.670969475835044 139.74156895838607 46.417 35.670969475835044 139.74156895838607 45.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-833d4354-c5e6-413d-bdda-43d7fe3ef0fe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-833d4354-c5e6-413d-bdda-43d7fe3ef0fe_0">
											<gml:posList>35.670940540616904 139.74156745606274 45.037 35.670940540616904 139.74156745606274 44.674 35.67095730626633 139.74156760256855 44.674 35.67095730626633 139.74156760256855 45.037 35.670940540616904 139.74156745606274 45.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-178dc5c2-6c5a-43ff-a2cd-4fd0c67adefa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-178dc5c2-6c5a-43ff-a2cd-4fd0c67adefa_0">
											<gml:posList>35.67094050606046 139.7415694223502 45.037 35.67095726297398 139.74156993339565 45.037 35.67095726297398 139.74156993339565 45.681 35.67094050606046 139.7415694223502 45.681 35.67094050606046 139.7415694223502 45.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_94940952-882a-4247-b89f-680fc99d8f51_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-05aefa7c-a549-4e51-a53f-60e04909c0d6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67095232828092 139.7414935094283 44.674 35.67097105006815 139.74149386355847 44.674 35.67097058217821 139.74153040539008 44.674 35.670951860391064 139.7415300512514 44.674 35.67095232828092 139.7414935094283 44.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7aa9d6d-f411-4222-87c1-c2f9277921f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f7aa9d6d-f411-4222-87c1-c2f9277921f0_0">
											<gml:posList>35.67095232828092 139.7414935094283 44.674 35.67095232828092 139.7414935094283 47.628 35.67097105006815 139.74149386355847 47.628 35.67097105006815 139.74149386355847 44.674 35.67095232828092 139.7414935094283 44.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-564d2bbd-da8f-4bd4-8e6a-6d7f9a601b2b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-564d2bbd-da8f-4bd4-8e6a-6d7f9a601b2b_0">
											<gml:posList>35.670951860391064 139.7415300512514 44.674 35.670951860391064 139.7415300512514 47.628 35.67095232828092 139.7414935094283 47.628 35.67095232828092 139.7414935094283 44.674 35.670951860391064 139.7415300512514 44.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-afa33ffb-838b-4840-b8e8-cdc0b80573be">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-afa33ffb-838b-4840-b8e8-cdc0b80573be_0">
											<gml:posList>35.67097058217821 139.74153040539008 47.628 35.67097105006815 139.74149386355847 47.628 35.67095232828092 139.7414935094283 47.628 35.670951860391064 139.7415300512514 47.628 35.67097058217821 139.74153040539008 47.628</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-62bfe753-0b86-4d5e-9041-d41d7f5f9957">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-62bfe753-0b86-4d5e-9041-d41d7f5f9957_0">
											<gml:posList>35.67097105006815 139.74149386355847 44.674 35.67097105006815 139.74149386355847 47.628 35.67097058217821 139.74153040539008 47.628 35.67097058217821 139.74153040539008 44.674 35.67097105006815 139.74149386355847 44.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-466b6d0d-18ae-444b-8d0b-f4e0e16650c8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-466b6d0d-18ae-444b-8d0b-f4e0e16650c8_0">
											<gml:posList>35.670951860391064 139.7415300512514 47.628 35.670951860391064 139.7415300512514 44.674 35.67097058217821 139.74153040539008 44.674 35.67097058217821 139.74153040539008 47.628 35.670951860391064 139.7415300512514 47.628</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_94940952-882a-4247-b89f-680fc99d8f51_BuildingInstallation_1061">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a88cb80-a39f-475f-bed4-013ee0a687f6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670937885998896 139.74150232990175 44.674 35.67095173472167 139.74148345794038 44.674 35.6710112620162 139.7414842734532 44.674 35.6710112661364 139.74148967511192 44.674 35.671019693116605 139.74150036936942 44.674 35.67101096850753 139.741513082661 44.674 35.67099231020021 139.74153687576123 44.674 35.6709920846719 139.7415366329999 44.674 35.671016889849064 139.74150037258028 44.674 35.67100870639101 139.7414898768784 44.674 35.67100887510718 139.7414865406886 44.674 35.67095260186743 139.7414858540024 44.674 35.670939644281255 139.7415031232241 44.674 35.67093906911088 139.74152900544942 44.674 35.67093719428195 139.74152904073517 44.674 35.670937885998896 139.74150232990175 44.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e5a1cd3-0d75-444c-ba90-fdb7c9fecb7f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67099231020021 139.74153687576123 45.037 35.67101096850753 139.741513082661 45.037 35.67099368137229 139.7415382991697 45.037 35.67099231020021 139.74153687576123 45.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9da0a818-8bf9-413e-8e16-78ad772b319d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9da0a818-8bf9-413e-8e16-78ad772b319d_0">
											<gml:posList>35.67095173472167 139.74148345794038 44.674 35.67095173472167 139.74148345794038 47.891 35.6710112620162 139.7414842734532 47.891 35.6710112620162 139.7414842734532 44.674 35.67095173472167 139.74148345794038 44.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb3713ba-71c6-42a6-910e-dc7e003caa5f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb3713ba-71c6-42a6-910e-dc7e003caa5f_0">
											<gml:posList>35.67100887510718 139.7414865406886 44.674 35.67100887510718 139.7414865406886 47.891 35.67095260186743 139.7414858540024 47.891 35.67095260186743 139.7414858540024 44.674 35.67100887510718 139.7414865406886 44.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ece0f6f-613a-42b2-a57a-47942ae2bd19">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2ece0f6f-613a-42b2-a57a-47942ae2bd19_0">
											<gml:posList>35.6710112620162 139.7414842734532 44.674 35.6710112620162 139.7414842734532 47.891 35.6710112661364 139.74148967511192 47.891 35.6710112661364 139.74148967511192 44.674 35.6710112620162 139.7414842734532 44.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c513d3aa-9d7b-40fc-bc6f-0b677b72fb97">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c513d3aa-9d7b-40fc-bc6f-0b677b72fb97_0">
											<gml:posList>35.67100870639101 139.7414898768784 44.674 35.67100870639101 139.7414898768784 47.891 35.67100887510718 139.7414865406886 47.891 35.67100887510718 139.7414865406886 44.674 35.67100870639101 139.7414898768784 44.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b150047f-f59e-4e2f-accd-3f6a38b3813d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b150047f-f59e-4e2f-accd-3f6a38b3813d_0">
											<gml:posList>35.670937885998896 139.74150232990175 44.674 35.670937885998896 139.74150232990175 47.891 35.67095173472167 139.74148345794038 47.891 35.67095173472167 139.74148345794038 44.674 35.670937885998896 139.74150232990175 44.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-edb0f9ad-d2df-47fb-b873-e166e2ed4e28">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-edb0f9ad-d2df-47fb-b873-e166e2ed4e28_0">
											<gml:posList>35.67095260186743 139.7414858540024 44.674 35.67095260186743 139.7414858540024 47.891 35.670939644281255 139.7415031232241 47.891 35.670939644281255 139.7415031232241 44.674 35.67095260186743 139.7414858540024 44.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa1cfba4-747d-4782-acff-2a17953b693d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aa1cfba4-747d-4782-acff-2a17953b693d_0">
											<gml:posList>35.6710112661364 139.74148967511192 44.674 35.6710112661364 139.74148967511192 47.891 35.671019693116605 139.74150036936942 47.891 35.671019693116605 139.74150036936942 44.674 35.6710112661364 139.74148967511192 44.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-092f340c-2d2a-47c4-b70e-e88ba7b277ab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-092f340c-2d2a-47c4-b70e-e88ba7b277ab_0">
											<gml:posList>35.671016889849064 139.74150037258028 44.674 35.671016889849064 139.74150037258028 47.891 35.67100870639101 139.7414898768784 47.891 35.67100870639101 139.7414898768784 44.674 35.671016889849064 139.74150037258028 44.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe5e389c-99ed-4f73-8416-7d289c97e9b9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe5e389c-99ed-4f73-8416-7d289c97e9b9_0">
											<gml:posList>35.67093906911088 139.74152900544942 47.891 35.670939644281255 139.7415031232241 47.891 35.67095260186743 139.7414858540024 47.891 35.67100887510718 139.7414865406886 47.891 35.67100870639101 139.7414898768784 47.891 35.671016889849064 139.74150037258028 47.891 35.6709920846719 139.7415366329999 47.891 35.67099368137229 139.7415382991697 47.891 35.671019693116605 139.74150036936942 47.891 35.6710112661364 139.74148967511192 47.891 35.6710112620162 139.7414842734532 47.891 35.67095173472167 139.74148345794038 47.891 35.670937885998896 139.74150232990175 47.891 35.67093719428195 139.74152904073517 47.891 35.67093906911088 139.74152900544942 47.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-413be1bf-6abf-4114-9b7d-bc779270503e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-413be1bf-6abf-4114-9b7d-bc779270503e_0">
											<gml:posList>35.67093719428195 139.74152904073517 44.674 35.67093719428195 139.74152904073517 47.891 35.670937885998896 139.74150232990175 47.891 35.670937885998896 139.74150232990175 44.674 35.67093719428195 139.74152904073517 44.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9229ca83-6a2a-41da-8c60-2f45b0c9b510">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9229ca83-6a2a-41da-8c60-2f45b0c9b510_0">
											<gml:posList>35.670939644281255 139.7415031232241 44.674 35.670939644281255 139.7415031232241 47.891 35.67093906911088 139.74152900544942 47.891 35.67093906911088 139.74152900544942 44.674 35.670939644281255 139.7415031232241 44.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2e601559-8568-4422-a0ad-7608b416eda1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2e601559-8568-4422-a0ad-7608b416eda1_0">
											<gml:posList>35.6709920846719 139.7415366329999 44.674 35.6709920846719 139.7415366329999 47.891 35.671016889849064 139.74150037258028 47.891 35.671016889849064 139.74150037258028 44.674 35.6709920846719 139.7415366329999 44.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eafde39e-a8c1-47a1-a54c-957f853d5a79">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eafde39e-a8c1-47a1-a54c-957f853d5a79_0">
											<gml:posList>35.671019693116605 139.74150036936942 44.674 35.671019693116605 139.74150036936942 47.891 35.67099368137229 139.7415382991697 47.891 35.67099368137229 139.7415382991697 45.037 35.67101096850753 139.741513082661 45.037 35.67101096850753 139.741513082661 44.674 35.671019693116605 139.74150036936942 44.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6c06b71-2a82-4388-a547-a2f04d0faf8c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d6c06b71-2a82-4388-a547-a2f04d0faf8c_0">
											<gml:posList>35.67099231020021 139.74153687576123 44.674 35.67101096850753 139.741513082661 44.674 35.67101096850753 139.741513082661 45.037 35.67099231020021 139.74153687576123 45.037 35.67099231020021 139.74153687576123 44.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4eedf564-63d0-4973-8773-c5a822ae9190">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4eedf564-63d0-4973-8773-c5a822ae9190_0">
											<gml:posList>35.67093906911088 139.74152900544942 44.674 35.67093906911088 139.74152900544942 47.891 35.67093719428195 139.74152904073517 47.891 35.67093719428195 139.74152904073517 44.674 35.67093906911088 139.74152900544942 44.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ca6b964-97b6-4a73-ab91-875d4ff5dc81">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9ca6b964-97b6-4a73-ab91-875d4ff5dc81_0">
											<gml:posList>35.67099231020021 139.74153687576123 45.037 35.67099368137229 139.7415382991697 45.037 35.67099368137229 139.7415382991697 47.891 35.6709920846719 139.7415366329999 47.891 35.6709920846719 139.7415366329999 44.674 35.67099231020021 139.74153687576123 44.674 35.67099231020021 139.74153687576123 45.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_94940952-882a-4247-b89f-680fc99d8f51_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce2215b5-a491-49c8-b974-82717b1708dd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67093279140025 139.7415708561572 8.31 35.67095521772612 139.7415710735094 8.31 35.670954709214186 139.74158981972818 8.31 35.67094020217849 139.74160830580325 8.31 35.67093259899094 139.74160225006338 8.31 35.67093279140025 139.7415708561572 8.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-abfbfaea-b28e-4635-9827-e3c0b43551ae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-abfbfaea-b28e-4635-9827-e3c0b43551ae_0">
											<gml:posList>35.67095521772612 139.7415710735094 45.037 35.67095521772612 139.7415710735094 8.31 35.67093279140025 139.7415708561572 8.31 35.67093279140025 139.7415708561572 45.037 35.67095521772612 139.7415710735094 45.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6469174d-356c-4bb4-bcc9-4141944f4288">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6469174d-356c-4bb4-bcc9-4141944f4288_0">
											<gml:posList>35.670954709214186 139.74158981972818 45.037 35.670954709214186 139.74158981972818 8.31 35.67095521772612 139.7415710735094 8.31 35.67095521772612 139.7415710735094 45.037 35.670954709214186 139.74158981972818 45.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1e40105-11b4-4a59-88f4-0f58aab0ed05">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a1e40105-11b4-4a59-88f4-0f58aab0ed05_0">
											<gml:posList>35.67093279140025 139.7415708561572 45.037 35.67093279140025 139.7415708561572 8.31 35.67093259899094 139.74160225006338 8.31 35.67093259899094 139.74160225006338 45.037 35.67093279140025 139.7415708561572 45.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-52362c20-9ed5-4306-a79a-e86dd7861595">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-52362c20-9ed5-4306-a79a-e86dd7861595_0">
											<gml:posList>35.67093279140025 139.7415708561572 45.037 35.67093259899094 139.74160225006338 45.037 35.67094020217849 139.74160830580325 45.037 35.670954709214186 139.74158981972818 45.037 35.67095521772612 139.7415710735094 45.037 35.67093279140025 139.7415708561572 45.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-acb0d1e1-d7e7-401d-b633-eaa75d22eb8c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-acb0d1e1-d7e7-401d-b633-eaa75d22eb8c_0">
											<gml:posList>35.67094020217849 139.74160830580325 45.037 35.67094020217849 139.74160830580325 8.31 35.670954709214186 139.74158981972818 8.31 35.670954709214186 139.74158981972818 45.037 35.67094020217849 139.74160830580325 45.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76ddb1f7-f8ef-4d93-b060-a76c521ac18a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-76ddb1f7-f8ef-4d93-b060-a76c521ac18a_0">
											<gml:posList>35.67093259899094 139.74160225006338 45.037 35.67093259899094 139.74160225006338 8.31 35.67094020217849 139.74160830580325 8.31 35.67094020217849 139.74160830580325 45.037 35.67093259899094 139.74160225006338 45.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-23160269-ad81-4c47-b400-b287e5c9e71b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-23160269-ad81-4c47-b400-b287e5c9e71b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-23160269-ad81-4c47-b400-b287e5c9e71b">
											<gml:posList>35.670933249811796 139.741498225975 8.29 35.67094881790496 139.741476402672 8.29 35.671011130271125 139.7414769940618 8.29 35.67102456082977 139.7415007614625 8.29 35.670954709214186 139.74158981972818 8.29 35.67095521772612 139.7415710735094 8.29 35.67093279140025 139.7415708561572 8.29 35.670933249811796 139.741498225975 8.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e2afd39d-47da-46e5-b12d-417d3c710a15">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e2afd39d-47da-46e5-b12d-417d3c710a15">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e2afd39d-47da-46e5-b12d-417d3c710a15">
											<gml:posList>35.67094881790496 139.741476402672 45.037 35.670950109521584 139.74147988078866 45.037 35.67100962761705 139.74148045328977 45.037 35.671011130271125 139.7414769940618 45.037 35.67094881790496 139.741476402672 45.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-943a301b-f52c-4d2b-a3f3-3c0949dd3349">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-943a301b-f52c-4d2b-a3f3-3c0949dd3349">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-943a301b-f52c-4d2b-a3f3-3c0949dd3349">
											<gml:posList>35.670933249811796 139.741498225975 45.037 35.6709360811315 139.7414995482923 45.037 35.670950109521584 139.74147988078866 45.037 35.67094881790496 139.741476402672 45.037 35.670933249811796 139.741498225975 45.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b7dd86b7-2bed-4112-bc7a-a64afb669a0f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b7dd86b7-2bed-4112-bc7a-a64afb669a0f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b7dd86b7-2bed-4112-bc7a-a64afb669a0f">
											<gml:posList>35.671011130271125 139.7414769940618 45.037 35.67100962761705 139.74148045328977 45.037 35.671020910002774 139.741500412161 45.037 35.67102456082977 139.7415007614625 45.037 35.671011130271125 139.7414769940618 45.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-41bb085c-deec-4be0-87cb-5b907d769787">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41bb085c-deec-4be0-87cb-5b907d769787">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41bb085c-deec-4be0-87cb-5b907d769787">
											<gml:posList>35.671020910002774 139.741500412161 44.674 35.67100962761705 139.74148045328977 44.674 35.670950109521584 139.74147988078866 44.674 35.6709360811315 139.7414995482923 44.674 35.67093565513741 139.74156740642275 44.674 35.67095815356463 139.74156761264513 44.674 35.67095779411174 139.74158087970986 44.674 35.671020910002774 139.741500412161 44.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d94b6a87-892e-4f0d-8728-15596daeaa55">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d94b6a87-892e-4f0d-8728-15596daeaa55">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d94b6a87-892e-4f0d-8728-15596daeaa55">
											<gml:posList>35.670933249811796 139.741498225975 45.037 35.67093279140025 139.7415708561572 45.037 35.67093565513741 139.74156740642275 45.037 35.6709360811315 139.7414995482923 45.037 35.670933249811796 139.741498225975 45.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7511bc80-25fd-49cc-a4ef-33ef633d6fdd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7511bc80-25fd-49cc-a4ef-33ef633d6fdd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7511bc80-25fd-49cc-a4ef-33ef633d6fdd">
											<gml:posList>35.67102456082977 139.7415007614625 45.037 35.671020910002774 139.741500412161 45.037 35.67095779411174 139.74158087970986 45.037 35.670954709214186 139.74158981972818 45.037 35.67102456082977 139.7415007614625 45.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-36350a85-0c8f-4719-b58d-690f9692d098">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36350a85-0c8f-4719-b58d-690f9692d098">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36350a85-0c8f-4719-b58d-690f9692d098">
											<gml:posList>35.67095521772612 139.7415710735094 45.037 35.67095815356463 139.74156761264513 45.037 35.67093565513741 139.74156740642275 45.037 35.67093279140025 139.7415708561572 45.037 35.67095521772612 139.7415710735094 45.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c73ea725-bc66-4192-88d5-e2d86d020db8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c73ea725-bc66-4192-88d5-e2d86d020db8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c73ea725-bc66-4192-88d5-e2d86d020db8">
											<gml:posList>35.67095521772612 139.7415710735094 45.037 35.670954709214186 139.74158981972818 45.037 35.67095779411174 139.74158087970986 45.037 35.67095815356463 139.74156761264513 45.037 35.67095521772612 139.7415710735094 45.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b33aabe1-a3dd-4e27-b2df-e9597591e293">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b33aabe1-a3dd-4e27-b2df-e9597591e293">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b33aabe1-a3dd-4e27-b2df-e9597591e293">
											<gml:posList>35.67095779411174 139.74158087970986 45.037 35.67095779411174 139.74158087970986 44.674 35.67095815356463 139.74156761264513 44.674 35.67095815356463 139.74156761264513 45.037 35.67095779411174 139.74158087970986 45.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c4837f13-6a8c-4e4b-95b3-8acc97f05fd8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4837f13-6a8c-4e4b-95b3-8acc97f05fd8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4837f13-6a8c-4e4b-95b3-8acc97f05fd8">
											<gml:posList>35.670933249811796 139.741498225975 8.29 35.67093279140025 139.7415708561572 8.29 35.67093279140025 139.7415708561572 45.037 35.670933249811796 139.741498225975 45.037 35.670933249811796 139.741498225975 8.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6fa5ffb7-2e55-495a-ace4-cd3e361660ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6fa5ffb7-2e55-495a-ace4-cd3e361660ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6fa5ffb7-2e55-495a-ace4-cd3e361660ef">
											<gml:posList>35.67093565513741 139.74156740642275 45.037 35.67093565513741 139.74156740642275 44.674 35.6709360811315 139.7414995482923 44.674 35.6709360811315 139.7414995482923 45.037 35.67093565513741 139.74156740642275 45.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0caba67f-2a50-474e-94c5-240426fdde3a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0caba67f-2a50-474e-94c5-240426fdde3a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0caba67f-2a50-474e-94c5-240426fdde3a">
											<gml:posList>35.67094881790496 139.741476402672 8.29 35.670933249811796 139.741498225975 8.29 35.670933249811796 139.741498225975 45.037 35.67094881790496 139.741476402672 45.037 35.67094881790496 139.741476402672 8.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b0926d49-8e66-474d-9330-b56c7617fb12">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b0926d49-8e66-474d-9330-b56c7617fb12">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b0926d49-8e66-474d-9330-b56c7617fb12">
											<gml:posList>35.6709360811315 139.7414995482923 45.037 35.6709360811315 139.7414995482923 44.674 35.670950109521584 139.74147988078866 44.674 35.670950109521584 139.74147988078866 45.037 35.6709360811315 139.7414995482923 45.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ce9330a5-1223-4b0d-8111-1f5931e1f677">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce9330a5-1223-4b0d-8111-1f5931e1f677">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce9330a5-1223-4b0d-8111-1f5931e1f677">
											<gml:posList>35.67093279140025 139.7415708561572 8.29 35.67095521772612 139.7415710735094 8.29 35.67095521772612 139.7415710735094 45.037 35.67093279140025 139.7415708561572 45.037 35.67093279140025 139.7415708561572 8.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-701b1973-011b-41de-9e32-2933ff4ba6f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-701b1973-011b-41de-9e32-2933ff4ba6f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-701b1973-011b-41de-9e32-2933ff4ba6f3">
											<gml:posList>35.67095815356463 139.74156761264513 45.037 35.67095815356463 139.74156761264513 44.674 35.67093565513741 139.74156740642275 44.674 35.67093565513741 139.74156740642275 45.037 35.67095815356463 139.74156761264513 45.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c2ce8175-e685-4c21-a696-d352af579e9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c2ce8175-e685-4c21-a696-d352af579e9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c2ce8175-e685-4c21-a696-d352af579e9a">
											<gml:posList>35.67095521772612 139.7415710735094 8.29 35.670954709214186 139.74158981972818 8.29 35.670954709214186 139.74158981972818 45.037 35.67095521772612 139.7415710735094 45.037 35.67095521772612 139.7415710735094 8.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3f9c6c93-fb0a-4318-b022-63ff35e18714">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f9c6c93-fb0a-4318-b022-63ff35e18714">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f9c6c93-fb0a-4318-b022-63ff35e18714">
											<gml:posList>35.670950109521584 139.74147988078866 45.037 35.670950109521584 139.74147988078866 44.674 35.67100962761705 139.74148045328977 44.674 35.67100962761705 139.74148045328977 45.037 35.670950109521584 139.74147988078866 45.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5d25fa42-ef9a-4e08-82cc-e00dfb6242aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d25fa42-ef9a-4e08-82cc-e00dfb6242aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d25fa42-ef9a-4e08-82cc-e00dfb6242aa">
											<gml:posList>35.671011130271125 139.7414769940618 8.29 35.67094881790496 139.741476402672 8.29 35.67094881790496 139.741476402672 45.037 35.671011130271125 139.7414769940618 45.037 35.671011130271125 139.7414769940618 8.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b24c7443-2cf3-44b8-bfcc-b590fe425a1e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b24c7443-2cf3-44b8-bfcc-b590fe425a1e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b24c7443-2cf3-44b8-bfcc-b590fe425a1e">
											<gml:posList>35.671020910002774 139.741500412161 45.037 35.671020910002774 139.741500412161 44.674 35.67095779411174 139.74158087970986 44.674 35.67095779411174 139.74158087970986 45.037 35.671020910002774 139.741500412161 45.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9f8cf861-441f-42ac-b3b2-9846d6b63b8d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f8cf861-441f-42ac-b3b2-9846d6b63b8d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f8cf861-441f-42ac-b3b2-9846d6b63b8d">
											<gml:posList>35.670954709214186 139.74158981972818 8.29 35.67102456082977 139.7415007614625 8.29 35.67102456082977 139.7415007614625 45.037 35.670954709214186 139.74158981972818 45.037 35.670954709214186 139.74158981972818 8.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e95ebba5-33c5-4457-abcc-0930e13f149a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e95ebba5-33c5-4457-abcc-0930e13f149a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e95ebba5-33c5-4457-abcc-0930e13f149a">
											<gml:posList>35.67100962761705 139.74148045328977 45.037 35.67100962761705 139.74148045328977 44.674 35.671020910002774 139.741500412161 44.674 35.671020910002774 139.741500412161 45.037 35.67100962761705 139.74148045328977 45.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-02c2cc1f-8eb3-4a52-ba3b-be54bd3f74b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-02c2cc1f-8eb3-4a52-ba3b-be54bd3f74b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-02c2cc1f-8eb3-4a52-ba3b-be54bd3f74b6">
											<gml:posList>35.67102456082977 139.7415007614625 8.29 35.671011130271125 139.7414769940618 8.29 35.671011130271125 139.7414769940618 45.037 35.67102456082977 139.7415007614625 45.037 35.67102456082977 139.7415007614625 8.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1166</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>