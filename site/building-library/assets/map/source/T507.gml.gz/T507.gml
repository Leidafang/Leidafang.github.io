<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_94af6cdd-7232-4934-aac4-f21524e789d3">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">8.1</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66882808150217 139.7394613272569 0 35.66882600188062 139.73946459932097 0 35.66881532648962 139.73948371042823 0 35.66880619764368 139.7394747959108 0 35.66879968898569 139.73948540772955 0 35.66879856364746 139.7394871764133 0 35.668860001661784 139.73954554915557 0 35.66888130193235 139.73951188900998 0 35.66882808150217 139.7394613272569 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66882808150217 139.7394613272569 11.682 35.66888130193235 139.73951188900998 11.682 35.668860001661784 139.73954554915557 11.682 35.66879856364746 139.7394871764133 11.682 35.66879968898569 139.73948540772955 11.682 35.66880619764368 139.7394747959108 11.682 35.66881532648962 139.73948371042823 11.682 35.66882600188062 139.73946459932097 11.682 35.66882808150217 139.7394613272569 11.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66882808150217 139.7394613272569 11.682 35.66882600188062 139.73946459932097 11.682 35.66882600188062 139.73946459932097 19.76 35.66882808150217 139.7394613272569 19.76 35.66882808150217 139.7394613272569 11.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66882600188062 139.73946459932097 11.682 35.66881532648962 139.73948371042823 11.682 35.66881532648962 139.73948371042823 19.76 35.66882600188062 139.73946459932097 19.76 35.66882600188062 139.73946459932097 11.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66881532648962 139.73948371042823 11.682 35.66880619764368 139.7394747959108 11.682 35.66880619764368 139.7394747959108 19.76 35.66881532648962 139.73948371042823 19.76 35.66881532648962 139.73948371042823 11.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66880619764368 139.7394747959108 11.682 35.66879968898569 139.73948540772955 11.682 35.66879968898569 139.73948540772955 19.76 35.66880619764368 139.7394747959108 19.76 35.66880619764368 139.7394747959108 11.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66879968898569 139.73948540772955 11.682 35.66879856364746 139.7394871764133 11.682 35.66879856364746 139.7394871764133 19.76 35.66879968898569 139.73948540772955 19.76 35.66879968898569 139.73948540772955 11.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66879856364746 139.7394871764133 11.682 35.668860001661784 139.73954554915557 11.682 35.668860001661784 139.73954554915557 19.76 35.66879856364746 139.7394871764133 19.76 35.66879856364746 139.7394871764133 11.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668860001661784 139.73954554915557 11.682 35.66888130193235 139.73951188900998 11.682 35.66888130193235 139.73951188900998 19.76 35.668860001661784 139.73954554915557 19.76 35.668860001661784 139.73954554915557 11.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66888130193235 139.73951188900998 11.682 35.66882808150217 139.7394613272569 11.682 35.66882808150217 139.7394613272569 19.76 35.66888130193235 139.73951188900998 19.76 35.66888130193235 139.73951188900998 11.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66882808150217 139.7394613272569 19.76 35.66882600188062 139.73946459932097 19.76 35.66881532648962 139.73948371042823 19.76 35.66880619764368 139.7394747959108 19.76 35.66879968898569 139.73948540772955 19.76 35.66879856364746 139.7394871764133 19.76 35.668860001661784 139.73954554915557 19.76 35.66888130193235 139.73951188900998 19.76 35.66882808150217 139.7394613272569 19.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-7264a987-b3df-4a16-aaa1-9a7aba71e566"/>
							<gml:surfaceMember xlink:href="#poly-ecacdf70-ee7e-4113-be0f-2d8c1c8e75d3"/>
							<gml:surfaceMember xlink:href="#poly-1d389619-c53e-4012-9dd5-761fe500e73b"/>
							<gml:surfaceMember xlink:href="#poly-cc8bf522-5d91-4125-a70f-41b5192caeff"/>
							<gml:surfaceMember xlink:href="#poly-fbeaa218-87ad-4064-8bee-b13153926a9d"/>
							<gml:surfaceMember xlink:href="#poly-fec1aa55-5a5c-4a21-bb37-d22bb552c298"/>
							<gml:surfaceMember xlink:href="#poly-e9c46a83-40a7-4070-a954-994b2f577cf8"/>
							<gml:surfaceMember xlink:href="#poly-e184eb21-c3e4-46c8-9fe9-789d4bf5d219"/>
							<gml:surfaceMember xlink:href="#poly-d4253916-b42a-4e3d-ad99-051d45b8204f"/>
							<gml:surfaceMember xlink:href="#poly-49a789e6-181d-4cc5-83c8-0d58c3ff1ad9"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_94af6cdd-7232-4934-aac4-f21524e789d3_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-380dfb68-0272-4fb6-85e6-412dc2a97168">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-380dfb68-0272-4fb6-85e6-412dc2a97168_0">
											<gml:posList>35.6688086530932 139.73945643451333 11.66 35.66881595314243 139.73945505625701 19.304 35.66881595314243 139.73945505625701 11.66 35.6688086530932 139.73945643451333 11.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e77ff8cc-5d67-4525-a5a6-d0630ca56b3b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e77ff8cc-5d67-4525-a5a6-d0630ca56b3b_0">
											<gml:posList>35.6688086530932 139.73945643451333 11.66 35.6688086530932 139.73945643451333 19.304 35.66881595314243 139.73945505625701 19.304 35.6688086530932 139.73945643451333 11.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e64a5c50-6752-4992-b8bc-306eb74d280b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e64a5c50-6752-4992-b8bc-306eb74d280b_0">
											<gml:posList>35.66881595314243 139.73945505625701 19.304 35.66882600188058 139.73946459932097 19.304 35.66882600188058 139.73946459932097 11.675 35.66881595314243 139.73945505625701 19.304</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75d9e21d-1823-4ee2-a90d-04a7578e1a36">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-75d9e21d-1823-4ee2-a90d-04a7578e1a36_0">
											<gml:posList>35.66881595314243 139.73945505625701 11.66 35.66881595314243 139.73945505625701 19.304 35.66882600188058 139.73946459932097 11.675 35.66881595314243 139.73945505625701 11.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3dbeb59a-72bf-4299-bc80-d10616733539">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3dbeb59a-72bf-4299-bc80-d10616733539_0">
											<gml:posList>35.6688086530932 139.73945643451333 11.66 35.66879383474783 139.73947985842298 19.304 35.6688086530932 139.73945643451333 19.304 35.6688086530932 139.73945643451333 11.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63d5f0cd-7d38-4605-9258-081c01d0af73">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-63d5f0cd-7d38-4605-9258-081c01d0af73_0">
											<gml:posList>35.6688086530932 139.73945643451333 11.66 35.66879383474783 139.73947985842298 11.66 35.66879383474783 139.73947985842298 19.304 35.6688086530932 139.73945643451333 11.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f2f42b90-197e-4dac-a7e0-14b9bd17a4ff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f2f42b90-197e-4dac-a7e0-14b9bd17a4ff_0">
											<gml:posList>35.6688086530932 139.73945643451333 19.304 35.66879383474783 139.73947985842298 19.304 35.668806197643654 139.73947479591078 19.304 35.6688086530932 139.73945643451333 19.304</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc604c43-ec6a-4177-aad6-e34fc6d59f29">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bc604c43-ec6a-4177-aad6-e34fc6d59f29_0">
											<gml:posList>35.6688086530932 139.73945643451333 19.304 35.668806197643654 139.73947479591078 19.304 35.66881595314243 139.73945505625701 19.304 35.6688086530932 139.73945643451333 19.304</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db622e99-8fa2-4159-b341-ac76151265bb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-db622e99-8fa2-4159-b341-ac76151265bb_0">
											<gml:posList>35.66879383474783 139.73947985842298 19.304 35.66879968898565 139.73948540772955 19.304 35.668806197643654 139.73947479591078 19.304 35.66879383474783 139.73947985842298 19.304</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-410b038f-837f-497a-bfe4-71091682b185">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-410b038f-837f-497a-bfe4-71091682b185_0">
											<gml:posList>35.66881595314243 139.73945505625701 19.304 35.668806197643654 139.73947479591078 19.304 35.66882600188058 139.73946459932097 19.304 35.66881595314243 139.73945505625701 19.304</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53221f8b-8afa-489b-bda1-c0a83011b9f4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-53221f8b-8afa-489b-bda1-c0a83011b9f4_0">
											<gml:posList>35.66882600188058 139.73946459932097 19.304 35.668806197643654 139.73947479591078 19.304 35.66881532648962 139.7394837104282 19.304 35.66882600188058 139.73946459932097 19.304</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a870aea1-be94-4bd8-9a94-01ece7aef054">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a870aea1-be94-4bd8-9a94-01ece7aef054_0">
											<gml:posList>35.66882600188058 139.73946459932097 19.304 35.66881532648962 139.7394837104282 11.682 35.66882600188058 139.73946459932097 11.675 35.66882600188058 139.73946459932097 19.304</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-138cb0ab-de2b-428f-8459-3a2185cd2ecb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-138cb0ab-de2b-428f-8459-3a2185cd2ecb_0">
											<gml:posList>35.66882600188058 139.73946459932097 19.304 35.66881532648962 139.7394837104282 19.304 35.66881532648962 139.7394837104282 11.682 35.66882600188058 139.73946459932097 19.304</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-989372f2-20e6-42f6-878b-0ef4d3bb08c4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-989372f2-20e6-42f6-878b-0ef4d3bb08c4_0">
											<gml:posList>35.66881532648962 139.7394837104282 19.304 35.668806197643654 139.73947479591078 11.682 35.66881532648962 139.7394837104282 11.682 35.66881532648962 139.7394837104282 19.304</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0dd4b71f-0898-420b-9ac8-0bd33c65c079">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0dd4b71f-0898-420b-9ac8-0bd33c65c079_0">
											<gml:posList>35.66881532648962 139.7394837104282 19.304 35.668806197643654 139.73947479591078 19.304 35.668806197643654 139.73947479591078 11.682 35.66881532648962 139.7394837104282 19.304</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-34459b2b-052f-4e0e-9e38-630cf34f38a9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-34459b2b-052f-4e0e-9e38-630cf34f38a9_0">
											<gml:posList>35.66879968898565 139.73948540772955 19.304 35.668806197643654 139.73947479591078 11.682 35.668806197643654 139.73947479591078 19.304 35.66879968898565 139.73948540772955 19.304</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-414a48d4-a8a6-40a6-aef8-a4fba5f00a24">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-414a48d4-a8a6-40a6-aef8-a4fba5f00a24_0">
											<gml:posList>35.66879968898565 139.73948540772955 19.304 35.66879968898565 139.73948540772955 11.675 35.668806197643654 139.73947479591078 11.682 35.66879968898565 139.73948540772955 19.304</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e8bebf9-f66d-41d0-86aa-994841c07c90">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e8bebf9-f66d-41d0-86aa-994841c07c90_0">
											<gml:posList>35.66879383474783 139.73947985842298 19.304 35.66879383474783 139.73947985842298 11.66 35.66879968898565 139.73948540772955 11.675 35.66879383474783 139.73947985842298 19.304</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e45eac93-8311-42af-8101-88d972cff69e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e45eac93-8311-42af-8101-88d972cff69e_0">
											<gml:posList>35.66879968898565 139.73948540772955 19.304 35.66879383474783 139.73947985842298 19.304 35.66879968898565 139.73948540772955 11.675 35.66879968898565 139.73948540772955 19.304</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-22e19257-4a51-441f-9a38-42193199c4de">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66881532648962 139.7394837104282 11.671 35.668806197643654 139.73947479591078 11.671 35.66882600188058 139.73946459932097 11.675 35.66881532648962 139.7394837104282 11.671</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1b727c2-a0cf-4016-b915-e025d684e196">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66882600188058 139.73946459932097 11.675 35.668806197643654 139.73947479591078 11.671 35.66881595314243 139.73945505625701 11.66 35.66882600188058 139.73946459932097 11.675</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f9883d07-b89f-4a42-b758-68a23e0dcc82">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66881595314243 139.73945505625701 11.66 35.668806197643654 139.73947479591078 11.671 35.6688086530932 139.73945643451333 11.66 35.66881595314243 139.73945505625701 11.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3484c45a-3638-4212-8e56-745150407283">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668806197643654 139.73947479591078 11.671 35.66879968898565 139.73948540772955 11.675 35.66879383474783 139.73947985842298 11.66 35.668806197643654 139.73947479591078 11.671</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a7b8f1a3-542d-4bd0-8848-c6cfc2d01071">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6688086530932 139.73945643451333 11.66 35.668806197643654 139.73947479591078 11.671 35.66879383474783 139.73947985842298 11.66 35.6688086530932 139.73945643451333 11.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e6d63b2-1f16-4afc-9512-742ef925c584">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66882600188058 139.73946459932097 11.675 35.66881532648962 139.7394837104282 11.682 35.66881532648962 139.7394837104282 11.671 35.66882600188058 139.73946459932097 11.675</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b58af2c7-d7cf-45c7-9ceb-6de39eae2c84">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668806197643654 139.73947479591078 11.671 35.66881532648962 139.7394837104282 11.671 35.668806197643654 139.73947479591078 11.682 35.668806197643654 139.73947479591078 11.671</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dca7a81d-a4a6-4b24-987f-6e662e511858">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668806197643654 139.73947479591078 11.671 35.668806197643654 139.73947479591078 11.682 35.66879968898565 139.73948540772955 11.675 35.668806197643654 139.73947479591078 11.671</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e4c2abc8-fbe2-48c7-b1cd-c401881cee0b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66881532648962 139.7394837104282 11.671 35.66881532648962 139.7394837104282 11.682 35.668806197643654 139.73947479591078 11.682 35.66881532648962 139.7394837104282 11.671</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_94af6cdd-7232-4934-aac4-f21524e789d3_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-52485a81-5d90-4fc7-bec2-36960ad8436e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668852353949944 139.73952875706064 20.158 35.668811385210155 139.7394923530471 20.158 35.66881217739354 139.7394910376408 20.158 35.668852081782774 139.7395265039851 20.158 35.66886281279483 139.7395093590066 20.158 35.66886387718894 139.73951035190566 20.158 35.668852353949944 139.73952875706064 20.158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f90c7d89-224a-4372-b19a-05f1ae4292b5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f90c7d89-224a-4372-b19a-05f1ae4292b5_0">
											<gml:posList>35.668811385210155 139.7394923530471 21.563 35.66881217739354 139.7394910376408 21.563 35.66881217739354 139.7394910376408 20.158 35.668811385210155 139.7394923530471 20.158 35.668811385210155 139.7394923530471 21.563</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9a7dd34-f1d5-4695-bade-fa3548b651f7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b9a7dd34-f1d5-4695-bade-fa3548b651f7_0">
											<gml:posList>35.66881217739354 139.7394910376408 20.158 35.66881217739354 139.7394910376408 21.563 35.668852081782774 139.7395265039851 21.563 35.668852081782774 139.7395265039851 20.158 35.66881217739354 139.7394910376408 20.158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b463e8e-bfc3-4a1f-ab13-3eedb24d1634">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5b463e8e-bfc3-4a1f-ab13-3eedb24d1634_0">
											<gml:posList>35.66886281279483 139.7395093590066 21.563 35.66886387718894 139.73951035190566 21.563 35.66886387718894 139.73951035190566 20.158 35.66886281279483 139.7395093590066 20.158 35.66886281279483 139.7395093590066 21.563</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c8818558-a10b-413b-a0a2-3bcbc9ac050e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c8818558-a10b-413b-a0a2-3bcbc9ac050e_0">
											<gml:posList>35.66886281279483 139.7395093590066 21.563 35.668852081782774 139.7395265039851 21.563 35.66881217739354 139.7394910376408 21.563 35.668811385210155 139.7394923530471 21.563 35.668852353949944 139.73952875706064 21.563 35.66886387718894 139.73951035190566 21.563 35.66886281279483 139.7395093590066 21.563</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a15a208-22c0-455d-b98f-d3a8a4aee9b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a15a208-22c0-455d-b98f-d3a8a4aee9b0_0">
											<gml:posList>35.668852353949944 139.73952875706064 21.563 35.668811385210155 139.7394923530471 21.563 35.668811385210155 139.7394923530471 20.158 35.668852353949944 139.73952875706064 20.158 35.668852353949944 139.73952875706064 21.563</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a7703456-1560-4e01-b173-c6f14097f330">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a7703456-1560-4e01-b173-c6f14097f330_0">
											<gml:posList>35.668852081782774 139.7395265039851 20.158 35.668852081782774 139.7395265039851 21.563 35.66886281279483 139.7395093590066 21.563 35.66886281279483 139.7395093590066 20.158 35.668852081782774 139.7395265039851 20.158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c8ccf6bc-eb29-4b76-8990-611f24d922e9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c8ccf6bc-eb29-4b76-8990-611f24d922e9_0">
											<gml:posList>35.66886387718894 139.73951035190566 20.158 35.66886387718894 139.73951035190566 21.563 35.668852353949944 139.73952875706064 21.563 35.668852353949944 139.73952875706064 20.158 35.66886387718894 139.73951035190566 20.158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-7264a987-b3df-4a16-aaa1-9a7aba71e566">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7264a987-b3df-4a16-aaa1-9a7aba71e566">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7264a987-b3df-4a16-aaa1-9a7aba71e566">
											<gml:posList>35.66881532648962 139.7394837104282 11.682 35.66882600188058 139.73946459932097 11.682 35.668828081502156 139.7394613272569 11.682 35.668881301932345 139.73951188900998 11.682 35.66886000166178 139.73954554915557 11.682 35.66879856364747 139.7394871764133 11.682 35.66879968898565 139.73948540772955 11.682 35.668806197643654 139.73947479591078 11.682 35.66881532648962 139.7394837104282 11.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ecacdf70-ee7e-4113-be0f-2d8c1c8e75d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ecacdf70-ee7e-4113-be0f-2d8c1c8e75d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ecacdf70-ee7e-4113-be0f-2d8c1c8e75d3">
											<gml:posList>35.66881532648962 139.7394837104282 20.158 35.668806197643654 139.73947479591078 20.158 35.66879968898565 139.73948540772955 20.158 35.66879856364747 139.7394871764133 20.158 35.66886000166178 139.73954554915557 20.158 35.668881301932345 139.73951188900998 20.158 35.668828081502156 139.7394613272569 20.158 35.66882600188058 139.73946459932097 20.158 35.66881532648962 139.7394837104282 20.158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1d389619-c53e-4012-9dd5-761fe500e73b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d389619-c53e-4012-9dd5-761fe500e73b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d389619-c53e-4012-9dd5-761fe500e73b">
											<gml:posList>35.668828081502156 139.7394613272569 11.682 35.66882600188058 139.73946459932097 11.682 35.66882600188058 139.73946459932097 20.158 35.668828081502156 139.7394613272569 20.158 35.668828081502156 139.7394613272569 11.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cc8bf522-5d91-4125-a70f-41b5192caeff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc8bf522-5d91-4125-a70f-41b5192caeff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc8bf522-5d91-4125-a70f-41b5192caeff">
											<gml:posList>35.66882600188058 139.73946459932097 11.682 35.66881532648962 139.7394837104282 11.682 35.66881532648962 139.7394837104282 20.158 35.66882600188058 139.73946459932097 20.158 35.66882600188058 139.73946459932097 11.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fbeaa218-87ad-4064-8bee-b13153926a9d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fbeaa218-87ad-4064-8bee-b13153926a9d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fbeaa218-87ad-4064-8bee-b13153926a9d">
											<gml:posList>35.66881532648962 139.7394837104282 11.682 35.668806197643654 139.73947479591078 11.682 35.668806197643654 139.73947479591078 20.158 35.66881532648962 139.7394837104282 20.158 35.66881532648962 139.7394837104282 11.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fec1aa55-5a5c-4a21-bb37-d22bb552c298">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fec1aa55-5a5c-4a21-bb37-d22bb552c298">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fec1aa55-5a5c-4a21-bb37-d22bb552c298">
											<gml:posList>35.668806197643654 139.73947479591078 11.682 35.66879968898565 139.73948540772955 11.682 35.66879968898565 139.73948540772955 20.158 35.668806197643654 139.73947479591078 20.158 35.668806197643654 139.73947479591078 11.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e9c46a83-40a7-4070-a954-994b2f577cf8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e9c46a83-40a7-4070-a954-994b2f577cf8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e9c46a83-40a7-4070-a954-994b2f577cf8">
											<gml:posList>35.66879968898565 139.73948540772955 11.682 35.66879856364747 139.7394871764133 11.682 35.66879856364747 139.7394871764133 20.158 35.66879968898565 139.73948540772955 20.158 35.66879968898565 139.73948540772955 11.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e184eb21-c3e4-46c8-9fe9-789d4bf5d219">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e184eb21-c3e4-46c8-9fe9-789d4bf5d219">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e184eb21-c3e4-46c8-9fe9-789d4bf5d219">
											<gml:posList>35.668881301932345 139.73951188900998 11.682 35.668828081502156 139.7394613272569 11.682 35.668828081502156 139.7394613272569 20.158 35.668881301932345 139.73951188900998 20.158 35.668881301932345 139.73951188900998 11.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d4253916-b42a-4e3d-ad99-051d45b8204f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4253916-b42a-4e3d-ad99-051d45b8204f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4253916-b42a-4e3d-ad99-051d45b8204f">
											<gml:posList>35.66879856364747 139.7394871764133 11.682 35.66886000166178 139.73954554915557 11.682 35.66886000166178 139.73954554915557 20.158 35.66879856364747 139.7394871764133 20.158 35.66879856364747 139.7394871764133 11.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-49a789e6-181d-4cc5-83c8-0d58c3ff1ad9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-49a789e6-181d-4cc5-83c8-0d58c3ff1ad9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-49a789e6-181d-4cc5-83c8-0d58c3ff1ad9">
											<gml:posList>35.66886000166178 139.73954554915557 11.682 35.668881301932345 139.73951188900998 11.682 35.668881301932345 139.73951188900998 20.158 35.66886000166178 139.73954554915557 20.158 35.66886000166178 139.73954554915557 11.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6499</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.08</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>