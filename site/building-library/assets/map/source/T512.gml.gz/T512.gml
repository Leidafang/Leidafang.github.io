<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_9592de47-c80f-465b-8ddd-84e862ade0bd">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">20.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67064132568465 139.74334145803144 0 35.670663860579445 139.74322169085877 0 35.67057631889194 139.7431971560284 0 35.67055279201599 139.7433162614138 0 35.67064132568465 139.74334145803144 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67064132568465 139.74334145803144 7.24 35.67055279201599 139.7433162614138 7.24 35.67057631889194 139.7431971560284 7.24 35.670663860579445 139.74322169085877 7.24 35.67064132568465 139.74334145803144 7.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67064132568465 139.74334145803144 7.24 35.670663860579445 139.74322169085877 7.24 35.670663860579445 139.74322169085877 28.010000000000005 35.67064132568465 139.74334145803144 28.010000000000005 35.67064132568465 139.74334145803144 7.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670663860579445 139.74322169085877 7.24 35.67057631889194 139.7431971560284 7.24 35.67057631889194 139.7431971560284 28.010000000000005 35.670663860579445 139.74322169085877 28.010000000000005 35.670663860579445 139.74322169085877 7.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67057631889194 139.7431971560284 7.24 35.67055279201599 139.7433162614138 7.24 35.67055279201599 139.7433162614138 28.010000000000005 35.67057631889194 139.7431971560284 28.010000000000005 35.67057631889194 139.7431971560284 7.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67055279201599 139.7433162614138 7.24 35.67064132568465 139.74334145803144 7.24 35.67064132568465 139.74334145803144 28.010000000000005 35.67055279201599 139.7433162614138 28.010000000000005 35.67055279201599 139.7433162614138 7.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67064132568465 139.74334145803144 28.010000000000005 35.670663860579445 139.74322169085877 28.010000000000005 35.67057631889194 139.7431971560284 28.010000000000005 35.67055279201599 139.7433162614138 28.010000000000005 35.67064132568465 139.74334145803144 28.010000000000005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-9cd9cacb-22e0-44c2-8394-10923c8af2c0"/>
							<gml:surfaceMember xlink:href="#poly-d5f37396-3455-4ebd-800a-7257dbeef4ba"/>
							<gml:surfaceMember xlink:href="#poly-c42112f6-3f15-467b-a4d1-633e8d0988b4"/>
							<gml:surfaceMember xlink:href="#poly-1ab70e80-e92c-40da-b31c-752ba5331921"/>
							<gml:surfaceMember xlink:href="#poly-950401a0-c99f-4e39-98a3-47fe7a0518a9"/>
							<gml:surfaceMember xlink:href="#poly-d1e3307c-2594-4fe4-ba9d-be376c5d52ca"/>
							<gml:surfaceMember xlink:href="#poly-92c8f842-f504-4d78-b539-b5846fad6ad4"/>
							<gml:surfaceMember xlink:href="#poly-71007910-3621-4eb1-a4e5-aeeaf2fb454c"/>
							<gml:surfaceMember xlink:href="#poly-5a2a0d57-daff-40cd-b6ee-07e3cfd61ffd"/>
							<gml:surfaceMember xlink:href="#poly-7b08530b-3e8c-42d0-9c3c-e03b32c38d5c"/>
							<gml:surfaceMember xlink:href="#poly-a31b99cc-7e1d-41a3-a37a-30d7c2f03533"/>
							<gml:surfaceMember xlink:href="#poly-df80cb58-2144-4e1d-9101-20f3a23b17de"/>
							<gml:surfaceMember xlink:href="#poly-6425ae3c-422a-45ab-af0a-1611c4d48f41"/>
							<gml:surfaceMember xlink:href="#poly-e0e18119-68e9-4947-8953-9df72f882747"/>
							<gml:surfaceMember xlink:href="#poly-d4ee7099-4fd7-4abf-a0ed-a15ab8a1327d"/>
							<gml:surfaceMember xlink:href="#poly-1ccd7520-1d3d-4420-b0fa-92197803cb6a"/>
							<gml:surfaceMember xlink:href="#poly-3992188f-8eed-4764-9a45-90635e7886e9"/>
							<gml:surfaceMember xlink:href="#poly-a77ad187-17d7-434e-bbd3-0c4e92a1bf16"/>
							<gml:surfaceMember xlink:href="#poly-2a40dee0-bfeb-476f-8b5c-742f442f503c"/>
							<gml:surfaceMember xlink:href="#poly-14b3f0e1-e92a-4047-9a1f-2ce4c3fe86d1"/>
							<gml:surfaceMember xlink:href="#poly-0e1fe1ad-a2fe-49d8-be9e-acb9acea2972"/>
							<gml:surfaceMember xlink:href="#poly-80bad706-c067-4352-a5d4-04859eccced1"/>
							<gml:surfaceMember xlink:href="#poly-d447d950-c0ad-404e-9e16-e6566f5b4f5b"/>
							<gml:surfaceMember xlink:href="#poly-ffe0dae3-fb76-41c7-a6b5-69ddfd684784"/>
							<gml:surfaceMember xlink:href="#poly-c207c1c1-b3e2-4a7c-bcc3-a5610fb5e6d4"/>
							<gml:surfaceMember xlink:href="#poly-dd5328d4-4e92-4a4d-9dd6-67f799d76e56"/>
							<gml:surfaceMember xlink:href="#poly-8871b674-b442-4d4c-b302-3cf155fe63c8"/>
							<gml:surfaceMember xlink:href="#poly-6b7ff42a-2a9e-4c0b-bf65-59164098bbe7"/>
							<gml:surfaceMember xlink:href="#poly-89ff61f2-abe5-4d42-81fa-93d8fb70b1db"/>
							<gml:surfaceMember xlink:href="#poly-64d209db-98ae-4c08-8cf9-12a5a0653c37"/>
							<gml:surfaceMember xlink:href="#poly-b9df8fcd-7fbb-4e40-8633-525f46bf2edd"/>
							<gml:surfaceMember xlink:href="#poly-b1b83ba4-64c8-408d-b9a9-91fe2a2740f9"/>
							<gml:surfaceMember xlink:href="#poly-afa065bf-3ae3-4356-ad82-845819e8bfa2"/>
							<gml:surfaceMember xlink:href="#poly-a6d9c5b7-e399-4985-b86c-571d3404d24f"/>
							<gml:surfaceMember xlink:href="#poly-7ccff302-72e0-4585-bb58-6eeea01a4c04"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_9592de47-c80f-465b-8ddd-84e862ade0bd_BuildingInstallation_1061">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c3a0f14-7959-4043-a4b4-e3471b0d3c8a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670559976077215 139.74331641904232 28.4 35.67062981128835 139.74333629024343 28.4 35.67062963174042 139.74333726251888 28.4 35.670559778444186 139.74331731401324 28.4 35.670559976077215 139.74331641904232 28.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d47a0d9-ab49-466b-a3ab-ea37b5c3d372">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67056222881433 139.74331548862517 27.721 35.67062804342627 139.7433347236541 27.721 35.67064994186183 139.74321966293726 27.721 35.670652222813224 139.74322030105887 27.721 35.67062981128835 139.74333629024343 27.721 35.670559976077215 139.74331641904232 27.721 35.67057547329179 139.74324759432375 27.721 35.670577808441095 139.74324838703268 27.721 35.67056222881433 139.74331548862517 27.721</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd0e681e-c06f-44d0-9b8e-68b20afb6863">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67065027403863 139.74321788411012 28.4 35.670652564003746 139.74321852222153 28.4 35.670652222813224 139.74322030105887 28.4 35.67064994186183 139.74321966293726 28.4 35.67065027403863 139.74321788411012 28.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-132ef71f-0d29-4296-9170-626e4a7fa504">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-132ef71f-0d29-4296-9170-626e4a7fa504_0">
											<gml:posList>35.670652564003746 139.74321852222153 28.4 35.67065027403863 139.74321788411012 28.4 35.67065027403863 139.74321788411012 29.023 35.670652564003746 139.74321852222153 29.023 35.670652564003746 139.74321852222153 28.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf9669cd-a789-4573-9e32-21a840344c3b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cf9669cd-a789-4573-9e32-21a840344c3b_0">
											<gml:posList>35.67064994186183 139.74321966293726 28.4 35.670652222813224 139.74322030105887 28.4 35.670652222813224 139.74322030105887 27.721 35.67064994186183 139.74321966293726 27.721 35.67064994186183 139.74321966293726 28.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b63cb95-0920-4645-bdca-78a209020b9a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2b63cb95-0920-4645-bdca-78a209020b9a_0">
											<gml:posList>35.67057547329179 139.74324759432375 27.721 35.67057547329179 139.74324759432375 29.023 35.670577808441095 139.74324838703268 29.023 35.670577808441095 139.74324838703268 27.721 35.67057547329179 139.74324759432375 27.721</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-825a1cc7-9d82-437b-b281-f0af1e5df534">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-825a1cc7-9d82-437b-b281-f0af1e5df534_0">
											<gml:posList>35.67065027403863 139.74321788411012 29.023 35.67065027403863 139.74321788411012 28.4 35.67064994186183 139.74321966293726 28.4 35.67064994186183 139.74321966293726 27.721 35.67062804342627 139.7433347236541 27.721 35.67062804342627 139.7433347236541 29.023 35.67065027403863 139.74321788411012 29.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-927922cf-24ee-4684-8aef-f1dc7e703ce1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-927922cf-24ee-4684-8aef-f1dc7e703ce1_0">
											<gml:posList>35.67057547329179 139.74324759432375 29.023 35.670559778444186 139.74331731401324 29.023 35.67062963174042 139.74333726251888 29.023 35.670652564003746 139.74321852222153 29.023 35.67065027403863 139.74321788411012 29.023 35.67062804342627 139.7433347236541 29.023 35.67056222881433 139.74331548862517 29.023 35.670577808441095 139.74324838703268 29.023 35.67057547329179 139.74324759432375 29.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-34e95e84-766d-4eed-9d13-6600ad5ab52c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-34e95e84-766d-4eed-9d13-6600ad5ab52c_0">
											<gml:posList>35.67062963174042 139.74333726251888 28.4 35.67062981128835 139.74333629024343 28.4 35.67062981128835 139.74333629024343 27.721 35.670652222813224 139.74322030105887 27.721 35.670652222813224 139.74322030105887 28.4 35.670652564003746 139.74321852222153 28.4 35.670652564003746 139.74321852222153 29.023 35.67062963174042 139.74333726251888 29.023 35.67062963174042 139.74333726251888 28.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-214b3911-88a9-436f-a7f5-b9091d2bb546">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-214b3911-88a9-436f-a7f5-b9091d2bb546_0">
											<gml:posList>35.670577808441095 139.74324838703268 27.721 35.670577808441095 139.74324838703268 29.023 35.67056222881433 139.74331548862517 29.023 35.67056222881433 139.74331548862517 27.721 35.670577808441095 139.74324838703268 27.721</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3377de5d-8c4d-440a-901d-ebf9c742a967">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3377de5d-8c4d-440a-901d-ebf9c742a967_0">
											<gml:posList>35.670559778444186 139.74331731401324 29.023 35.67057547329179 139.74324759432375 29.023 35.67057547329179 139.74324759432375 27.721 35.670559976077215 139.74331641904232 27.721 35.670559976077215 139.74331641904232 28.4 35.670559778444186 139.74331731401324 28.4 35.670559778444186 139.74331731401324 29.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d2179b96-e087-442d-ab5c-348584c48684">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d2179b96-e087-442d-ab5c-348584c48684_0">
											<gml:posList>35.67056222881433 139.74331548862517 27.721 35.67056222881433 139.74331548862517 29.023 35.67062804342627 139.7433347236541 29.023 35.67062804342627 139.7433347236541 27.721 35.67056222881433 139.74331548862517 27.721</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19231da1-a360-4798-b52e-5011d71efc71">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19231da1-a360-4798-b52e-5011d71efc71_0">
											<gml:posList>35.670559976077215 139.74331641904232 27.721 35.67062981128835 139.74333629024343 27.721 35.67062981128835 139.74333629024343 28.4 35.670559976077215 139.74331641904232 28.4 35.670559976077215 139.74331641904232 27.721</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58073584-fb9f-4377-ad0b-9375bda658cd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-58073584-fb9f-4377-ad0b-9375bda658cd_0">
											<gml:posList>35.67062963174042 139.74333726251888 28.4 35.67062963174042 139.74333726251888 29.023 35.670559778444186 139.74331731401324 29.023 35.670559778444186 139.74331731401324 28.4 35.67062963174042 139.74333726251888 28.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_9592de47-c80f-465b-8ddd-84e862ade0bd_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4af2e6b-d8a0-42b3-a97e-377370da7f71">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67058793876747 139.74322281453925 30.49 35.670588398905466 139.7432233994754 30.49 35.67058881401618 139.74322403969356 30.49 35.67058918408306 139.74322471310126 30.49 35.67058950010068 139.74322543075485 30.49 35.670589771066204 139.74322617055165 30.49 35.670589978960464 139.74322694355823 30.49 35.670590141794364 139.74322772766172 30.49 35.67059024154874 139.74322853392866 30.49 35.67059028722903 139.7432293513027 30.49 35.67059026980498 139.74323015770136 30.49 35.6705901982986 139.74323096416077 30.49 35.670590063696146 139.74323177069112 30.49 35.67058988400027 139.74323254413326 30.49 35.670589641200074 139.74323330660002 30.49 35.67058934429272 139.7432340359887 30.49 35.67058900229197 139.74323473228924 30.49 35.670588606175805 139.74323538446538 30.49 35.67058817397995 139.7432360035432 30.49 35.67058768766042 139.7432365674504 30.49 35.67058717425016 139.7432370651103 30.49 35.67058662475191 139.74323751862562 30.49 35.670586039157456 139.74323791695 30.49 35.6705854354777 139.74323823797073 30.49 35.67058480471544 139.74323850379042 30.49 35.67058415586787 139.74323869230642 30.49 35.67058350697073 139.74323881454475 30.49 35.67058283999655 139.74323887052566 30.49 35.67058217296451 139.74323884918263 30.49 35.670581514896604 139.7432387615518 30.49 35.67058086579283 139.74323860763317 30.49 35.67058022564492 139.74323837638048 30.49 35.6705796124886 139.74323807881973 30.49 35.670579017318396 139.74323772600735 30.49 35.67057844913149 139.7432372958406 30.49 35.67057790795271 139.7432368214584 30.49 35.670577411792955 139.7432362807479 30.49 35.670576951655015 139.74323569581176 30.49 35.67057653654437 139.7432350555936 30.49 35.670576166477524 139.743234382186 30.49 35.67057585046823 139.74323367557875 30.49 35.67057557949449 139.74323292473576 30.49 35.67057537160028 139.74323215172933 30.49 35.670575208766394 139.74323136762595 30.49 35.67057510901205 139.74323056135916 30.49 35.670575072345486 139.74322974397515 30.49 35.67057508075581 139.7432289375868 30.49 35.670575152262174 139.7432281311275 30.49 35.67057528686461 139.7432273245973 30.49 35.67057546656044 139.7432265511553 30.49 35.67057570936061 139.74322578868865 30.49 35.6705760062679 139.74322505930004 30.49 35.67057634826861 139.74322436299963 30.49 35.670576744384704 139.7432237108235 30.49 35.670577176588765 139.74322310279197 30.49 35.67057766290822 139.74322253888477 30.49 35.67057817631018 139.74322203017854 30.49 35.67057873482208 139.7432215766531 30.49 35.67057931140277 139.7432211783387 30.49 35.67057992409621 139.74322085730776 30.49 35.6705805458447 139.74322059149807 30.49 35.67058119469223 139.74322040298193 30.49 35.67058185260308 139.74322028073334 30.49 35.670582510563534 139.74322022476238 30.49 35.670583177595574 139.74322024610527 30.49 35.670583835663486 139.74322033373596 30.49 35.67058448476728 139.74322048765444 30.49 35.67058512491522 139.743220718907 30.49 35.67058574708532 139.7432210164575 30.49 35.670586342263846 139.7432213803161 30.49 35.6705869014288 139.7432217994466 30.49 35.67058744260764 139.74322227382874 30.49 35.67058793876747 139.74322281453925 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-634f3875-f6ef-477e-ae63-5201fc1afd9a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670592895490906 139.74326989929853 27.721 35.67058844830382 139.74328943413198 27.721 35.67057359888548 139.74328434742455 27.721 35.670578055085485 139.74326481258427 27.721 35.670592895490906 139.74326989929853 27.721</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f1b7203f-739a-41c1-b353-c3606f92c2e8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f1b7203f-739a-41c1-b353-c3606f92c2e8_0">
											<gml:posList>35.670583177595574 139.74322024610527 30.49 35.670582510563534 139.74322022476238 30.49 35.670582510563534 139.74322022476238 32.464 35.670583177595574 139.74322024610527 32.464 35.670583177595574 139.74322024610527 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59a77c93-89be-4ea7-a25f-0cb72768618f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-59a77c93-89be-4ea7-a25f-0cb72768618f_0">
											<gml:posList>35.67058185260308 139.74322028073334 30.49 35.67058185260308 139.74322028073334 32.464 35.670582510563534 139.74322022476238 32.464 35.670582510563534 139.74322022476238 30.49 35.67058185260308 139.74322028073334 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-add136c7-94fc-4fa1-9120-dea24466a39f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-add136c7-94fc-4fa1-9120-dea24466a39f_0">
											<gml:posList>35.670583835663486 139.74322033373596 30.49 35.670583177595574 139.74322024610527 30.49 35.670583177595574 139.74322024610527 32.464 35.670583835663486 139.74322033373596 32.464 35.670583835663486 139.74322033373596 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e573e9d-cbd7-4c3c-b484-dce1c339d208">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e573e9d-cbd7-4c3c-b484-dce1c339d208_0">
											<gml:posList>35.67058185260308 139.74322028073334 30.49 35.67058119469223 139.74322040298193 30.49 35.67058119469223 139.74322040298193 32.464 35.67058185260308 139.74322028073334 32.464 35.67058185260308 139.74322028073334 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27a6354f-88b9-4593-84ff-6e9750a7f6cb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-27a6354f-88b9-4593-84ff-6e9750a7f6cb_0">
											<gml:posList>35.670583835663486 139.74322033373596 30.49 35.670583835663486 139.74322033373596 32.464 35.67058448476728 139.74322048765444 32.464 35.67058448476728 139.74322048765444 30.49 35.670583835663486 139.74322033373596 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-630f8b26-e845-43e1-a938-62a730a5885f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-630f8b26-e845-43e1-a938-62a730a5885f_0">
											<gml:posList>35.67058119469223 139.74322040298193 30.49 35.6705805458447 139.74322059149807 30.49 35.6705805458447 139.74322059149807 32.464 35.67058119469223 139.74322040298193 32.464 35.67058119469223 139.74322040298193 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-784667b9-0abf-4b41-bd5e-8a1c147d824c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-784667b9-0abf-4b41-bd5e-8a1c147d824c_0">
											<gml:posList>35.67058512491522 139.743220718907 30.49 35.67058448476728 139.74322048765444 30.49 35.67058448476728 139.74322048765444 32.464 35.67058512491522 139.743220718907 32.464 35.67058512491522 139.743220718907 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9634452f-4a43-4602-99c0-3093a44b9870">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9634452f-4a43-4602-99c0-3093a44b9870_0">
											<gml:posList>35.6705805458447 139.74322059149807 30.49 35.67057992409621 139.74322085730776 30.49 35.67057992409621 139.74322085730776 32.464 35.6705805458447 139.74322059149807 32.464 35.6705805458447 139.74322059149807 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aefb4a17-3706-48e6-aad7-1d072d56308d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aefb4a17-3706-48e6-aad7-1d072d56308d_0">
											<gml:posList>35.67058574708532 139.7432210164575 30.49 35.67058512491522 139.743220718907 30.49 35.67058512491522 139.743220718907 32.464 35.67058574708532 139.7432210164575 32.464 35.67058574708532 139.7432210164575 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1997ac27-975e-48d1-ae1e-fc403b2ee0dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1997ac27-975e-48d1-ae1e-fc403b2ee0dc_0">
											<gml:posList>35.67057931140277 139.7432211783387 30.49 35.67057931140277 139.7432211783387 32.464 35.67057992409621 139.74322085730776 32.464 35.67057992409621 139.74322085730776 30.49 35.67057931140277 139.7432211783387 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c4eacf60-a88e-42f0-813f-b6e4158d4f85">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c4eacf60-a88e-42f0-813f-b6e4158d4f85_0">
											<gml:posList>35.670586342263846 139.7432213803161 30.49 35.67058574708532 139.7432210164575 30.49 35.67058574708532 139.7432210164575 32.464 35.670586342263846 139.7432213803161 32.464 35.670586342263846 139.7432213803161 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5442b0dc-a874-4c70-b1ef-b48661dcea57">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5442b0dc-a874-4c70-b1ef-b48661dcea57_0">
											<gml:posList>35.67057931140277 139.7432211783387 30.49 35.67057873482208 139.7432215766531 30.49 35.67057873482208 139.7432215766531 32.464 35.67057931140277 139.7432211783387 32.464 35.67057931140277 139.7432211783387 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce5c5348-17b5-47d9-9cd6-b24a96ed708f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce5c5348-17b5-47d9-9cd6-b24a96ed708f_0">
											<gml:posList>35.6705869014288 139.7432217994466 30.49 35.670586342263846 139.7432213803161 30.49 35.670586342263846 139.7432213803161 32.464 35.6705869014288 139.7432217994466 32.464 35.6705869014288 139.7432217994466 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b1e0b078-6c0b-41c5-87b6-ab5ddf2af83f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b1e0b078-6c0b-41c5-87b6-ab5ddf2af83f_0">
											<gml:posList>35.67057873482208 139.7432215766531 30.49 35.67057817631018 139.74322203017854 30.49 35.67057817631018 139.74322203017854 32.464 35.67057873482208 139.7432215766531 32.464 35.67057873482208 139.7432215766531 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e4577ee-672a-470e-8571-88dbe9901b53">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4e4577ee-672a-470e-8571-88dbe9901b53_0">
											<gml:posList>35.67058744260764 139.74322227382874 30.49 35.6705869014288 139.7432217994466 30.49 35.6705869014288 139.7432217994466 32.464 35.67058744260764 139.74322227382874 32.464 35.67058744260764 139.74322227382874 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e6643648-19d7-44cf-8dcf-c8fe0074b132">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e6643648-19d7-44cf-8dcf-c8fe0074b132_0">
											<gml:posList>35.67057817631018 139.74322203017854 30.49 35.67057766290822 139.74322253888477 30.49 35.67057766290822 139.74322253888477 32.464 35.67057817631018 139.74322203017854 32.464 35.67057817631018 139.74322203017854 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-948b850a-5beb-4ce4-aae2-fbd268fad3fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-948b850a-5beb-4ce4-aae2-fbd268fad3fd_0">
											<gml:posList>35.67058744260764 139.74322227382874 30.49 35.67058744260764 139.74322227382874 32.464 35.67058793876747 139.74322281453925 32.464 35.67058793876747 139.74322281453925 30.49 35.67058744260764 139.74322227382874 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf55e294-8aa1-4d61-b1d7-ab51585c865a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bf55e294-8aa1-4d61-b1d7-ab51585c865a_0">
											<gml:posList>35.67057766290822 139.74322253888477 30.49 35.670577176588765 139.74322310279197 30.49 35.670577176588765 139.74322310279197 32.464 35.67057766290822 139.74322253888477 32.464 35.67057766290822 139.74322253888477 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19da3109-76ec-401b-9ed4-a4d5db8b35c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19da3109-76ec-401b-9ed4-a4d5db8b35c6_0">
											<gml:posList>35.670588398905466 139.7432233994754 30.49 35.67058793876747 139.74322281453925 30.49 35.67058793876747 139.74322281453925 32.464 35.670588398905466 139.7432233994754 32.464 35.670588398905466 139.7432233994754 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b0dd71e9-a53b-4285-a48d-0e988867b41f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b0dd71e9-a53b-4285-a48d-0e988867b41f_0">
											<gml:posList>35.670577176588765 139.74322310279197 30.49 35.670576744384704 139.7432237108235 30.49 35.670576744384704 139.7432237108235 32.464 35.670577176588765 139.74322310279197 32.464 35.670577176588765 139.74322310279197 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73bcfa7d-651e-445a-a511-2605140a5312">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73bcfa7d-651e-445a-a511-2605140a5312_0">
											<gml:posList>35.67058881401618 139.74322403969356 30.49 35.670588398905466 139.7432233994754 30.49 35.670588398905466 139.7432233994754 32.464 35.67058881401618 139.74322403969356 32.464 35.67058881401618 139.74322403969356 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-527f5730-a011-4a51-b00b-28265721d53d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-527f5730-a011-4a51-b00b-28265721d53d_0">
											<gml:posList>35.670576744384704 139.7432237108235 30.49 35.67057634826861 139.74322436299963 30.49 35.67057634826861 139.74322436299963 32.464 35.670576744384704 139.7432237108235 32.464 35.670576744384704 139.7432237108235 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a3a7ad7-6b69-471d-911b-196638bbc338">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3a3a7ad7-6b69-471d-911b-196638bbc338_0">
											<gml:posList>35.67058918408306 139.74322471310126 30.49 35.67058881401618 139.74322403969356 30.49 35.67058881401618 139.74322403969356 32.464 35.67058918408306 139.74322471310126 32.464 35.67058918408306 139.74322471310126 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f185062d-ca71-4623-b4bb-f24e17e48ecc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f185062d-ca71-4623-b4bb-f24e17e48ecc_0">
											<gml:posList>35.67057634826861 139.74322436299963 30.49 35.6705760062679 139.74322505930004 30.49 35.6705760062679 139.74322505930004 32.464 35.67057634826861 139.74322436299963 32.464 35.67057634826861 139.74322436299963 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ecb5a66-8cdc-4f4b-a69a-2abe18c25b22">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3ecb5a66-8cdc-4f4b-a69a-2abe18c25b22_0">
											<gml:posList>35.67058950010068 139.74322543075485 30.49 35.67058918408306 139.74322471310126 30.49 35.67058918408306 139.74322471310126 32.464 35.67058950010068 139.74322543075485 32.464 35.67058950010068 139.74322543075485 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5fb39f3c-d709-48a0-9427-0cd0cf112dd7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5fb39f3c-d709-48a0-9427-0cd0cf112dd7_0">
											<gml:posList>35.6705760062679 139.74322505930004 30.49 35.67057570936061 139.74322578868865 30.49 35.67057570936061 139.74322578868865 32.464 35.6705760062679 139.74322505930004 32.464 35.6705760062679 139.74322505930004 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad7617bb-4fb0-470d-bc7b-ccd52cdcb362">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ad7617bb-4fb0-470d-bc7b-ccd52cdcb362_0">
											<gml:posList>35.670589771066204 139.74322617055165 30.49 35.67058950010068 139.74322543075485 30.49 35.67058950010068 139.74322543075485 32.464 35.670589771066204 139.74322617055165 32.464 35.670589771066204 139.74322617055165 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18040aa8-1938-4e72-bab4-a16a5afdddad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-18040aa8-1938-4e72-bab4-a16a5afdddad_0">
											<gml:posList>35.67057570936061 139.74322578868865 30.49 35.67057546656044 139.7432265511553 30.49 35.67057546656044 139.7432265511553 32.464 35.67057570936061 139.74322578868865 32.464 35.67057570936061 139.74322578868865 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4839021-900b-49e9-a3e3-4af2ab875567">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b4839021-900b-49e9-a3e3-4af2ab875567_0">
											<gml:posList>35.670589978960464 139.74322694355823 30.49 35.670589771066204 139.74322617055165 30.49 35.670589771066204 139.74322617055165 32.464 35.670589978960464 139.74322694355823 32.464 35.670589978960464 139.74322694355823 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b0b128c-1908-4347-98f2-28069f53cf9f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1b0b128c-1908-4347-98f2-28069f53cf9f_0">
											<gml:posList>35.67057546656044 139.7432265511553 30.49 35.67057528686461 139.7432273245973 30.49 35.67057528686461 139.7432273245973 32.464 35.67057546656044 139.7432265511553 32.464 35.67057546656044 139.7432265511553 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-28a786d7-8085-4739-b4d3-410d14649be7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-28a786d7-8085-4739-b4d3-410d14649be7_0">
											<gml:posList>35.670590141794364 139.74322772766172 30.49 35.670589978960464 139.74322694355823 30.49 35.670589978960464 139.74322694355823 32.464 35.670590141794364 139.74322772766172 32.464 35.670590141794364 139.74322772766172 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-619df12c-7ac5-444a-b330-efaacf7652ed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-619df12c-7ac5-444a-b330-efaacf7652ed_0">
											<gml:posList>35.67057528686461 139.7432273245973 30.49 35.670575152262174 139.7432281311275 30.49 35.670575152262174 139.7432281311275 32.464 35.67057528686461 139.7432273245973 32.464 35.67057528686461 139.7432273245973 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1385513e-faf0-4fa0-898b-6b54e53c4b30">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1385513e-faf0-4fa0-898b-6b54e53c4b30_0">
											<gml:posList>35.670590141794364 139.74322772766172 30.49 35.670590141794364 139.74322772766172 32.464 35.67059024154874 139.74322853392866 32.464 35.67059024154874 139.74322853392866 30.49 35.670590141794364 139.74322772766172 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f72249ed-7764-428f-b25a-eeb4827d00e0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f72249ed-7764-428f-b25a-eeb4827d00e0_0">
											<gml:posList>35.670575152262174 139.7432281311275 30.49 35.67057508075581 139.7432289375868 30.49 35.67057508075581 139.7432289375868 32.464 35.670575152262174 139.7432281311275 32.464 35.670575152262174 139.7432281311275 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d17595e-3817-4e68-a675-b99dd6c30b8e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d17595e-3817-4e68-a675-b99dd6c30b8e_0">
											<gml:posList>35.67059028722903 139.7432293513027 30.49 35.67059024154874 139.74322853392866 30.49 35.67059024154874 139.74322853392866 32.464 35.67059028722903 139.7432293513027 32.464 35.67059028722903 139.7432293513027 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b064bbc9-7d0e-48d2-8837-709af31cf251">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b064bbc9-7d0e-48d2-8837-709af31cf251_0">
											<gml:posList>35.67057508075581 139.7432289375868 30.49 35.670575072345486 139.74322974397515 30.49 35.670575072345486 139.74322974397515 32.464 35.67057508075581 139.7432289375868 32.464 35.67057508075581 139.7432289375868 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a4784cf-aea2-400d-95af-0426a1a88974">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a4784cf-aea2-400d-95af-0426a1a88974_0">
											<gml:posList>35.6705869014288 139.7432217994466 32.464 35.670586342263846 139.7432213803161 32.464 35.67058574708532 139.7432210164575 32.464 35.67058512491522 139.743220718907 32.464 35.67058448476728 139.74322048765444 32.464 35.670583835663486 139.74322033373596 32.464 35.670583177595574 139.74322024610527 32.464 35.670582510563534 139.74322022476238 32.464 35.67058185260308 139.74322028073334 32.464 35.67058119469223 139.74322040298193 32.464 35.6705805458447 139.74322059149807 32.464 35.67057992409621 139.74322085730776 32.464 35.67057931140277 139.7432211783387 32.464 35.67057873482208 139.7432215766531 32.464 35.67057817631018 139.74322203017854 32.464 35.67057766290822 139.74322253888477 32.464 35.670577176588765 139.74322310279197 32.464 35.670576744384704 139.7432237108235 32.464 35.67057634826861 139.74322436299963 32.464 35.6705760062679 139.74322505930004 32.464 35.67057570936061 139.74322578868865 32.464 35.67057546656044 139.7432265511553 32.464 35.67057528686461 139.7432273245973 32.464 35.670575152262174 139.7432281311275 32.464 35.67057508075581 139.7432289375868 32.464 35.670575072345486 139.74322974397515 32.464 35.67057510901205 139.74323056135916 32.464 35.670575208766394 139.74323136762595 32.464 35.67057537160028 139.74323215172933 32.464 35.67057557949449 139.74323292473576 32.464 35.67057585046823 139.74323367557875 32.464 35.670576166477524 139.743234382186 32.464 35.67057653654437 139.7432350555936 32.464 35.670576951655015 139.74323569581176 32.464 35.670577411792955 139.7432362807479 32.464 35.67057790795271 139.7432368214584 32.464 35.67057844913149 139.7432372958406 32.464 35.670579017318396 139.74323772600735 32.464 35.6705796124886 139.74323807881973 32.464 35.67058022564492 139.74323837638048 32.464 35.67058086579283 139.74323860763317 32.464 35.670581514896604 139.7432387615518 32.464 35.67058217296451 139.74323884918263 32.464 35.67058283999655 139.74323887052566 32.464 35.67058350697073 139.74323881454475 32.464 35.67058415586787 139.74323869230642 32.464 35.67058480471544 139.74323850379042 32.464 35.6705854354777 139.74323823797073 32.464 35.670586039157456 139.74323791695 32.464 35.67058662475191 139.74323751862562 32.464 35.67058717425016 139.7432370651103 32.464 35.67058768766042 139.7432365674504 32.464 35.67058817397995 139.7432360035432 32.464 35.670588606175805 139.74323538446538 32.464 35.67058900229197 139.74323473228924 32.464 35.67058934429272 139.7432340359887 32.464 35.670589641200074 139.74323330660002 32.464 35.67058988400027 139.74323254413326 32.464 35.670590063696146 139.74323177069112 32.464 35.6705901982986 139.74323096416077 32.464 35.67059026980498 139.74323015770136 32.464 35.67059028722903 139.7432293513027 32.464 35.67059024154874 139.74322853392866 32.464 35.670590141794364 139.74322772766172 32.464 35.670589978960464 139.74322694355823 32.464 35.670589771066204 139.74322617055165 32.464 35.67058950010068 139.74322543075485 32.464 35.67058918408306 139.74322471310126 32.464 35.67058881401618 139.74322403969356 32.464 35.670588398905466 139.7432233994754 32.464 35.67058793876747 139.74322281453925 32.464 35.67058744260764 139.74322227382874 32.464 35.6705869014288 139.7432217994466 32.464</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-66fa09ba-38ed-4663-af17-2a1f22e831b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-66fa09ba-38ed-4663-af17-2a1f22e831b8_0">
											<gml:posList>35.67059026980498 139.74323015770136 30.49 35.67059028722903 139.7432293513027 30.49 35.67059028722903 139.7432293513027 32.464 35.67059026980498 139.74323015770136 32.464 35.67059026980498 139.74323015770136 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4cee8439-797e-4fe7-9d1b-51f960747a4d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4cee8439-797e-4fe7-9d1b-51f960747a4d_0">
											<gml:posList>35.670575072345486 139.74322974397515 30.49 35.67057510901205 139.74323056135916 30.49 35.67057510901205 139.74323056135916 32.464 35.670575072345486 139.74322974397515 32.464 35.670575072345486 139.74322974397515 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40068d96-6e67-489d-a90f-59fdb63df8fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40068d96-6e67-489d-a90f-59fdb63df8fd_0">
											<gml:posList>35.6705901982986 139.74323096416077 30.49 35.67059026980498 139.74323015770136 30.49 35.67059026980498 139.74323015770136 32.464 35.6705901982986 139.74323096416077 32.464 35.6705901982986 139.74323096416077 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2efbb517-08f5-4bba-b486-29546f709721">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2efbb517-08f5-4bba-b486-29546f709721_0">
											<gml:posList>35.67057510901205 139.74323056135916 30.49 35.670575208766394 139.74323136762595 30.49 35.670575208766394 139.74323136762595 32.464 35.67057510901205 139.74323056135916 32.464 35.67057510901205 139.74323056135916 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-219908bb-084a-404a-b962-2665956de474">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-219908bb-084a-404a-b962-2665956de474_0">
											<gml:posList>35.670590063696146 139.74323177069112 30.49 35.6705901982986 139.74323096416077 30.49 35.6705901982986 139.74323096416077 32.464 35.670590063696146 139.74323177069112 32.464 35.670590063696146 139.74323177069112 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-90492cb0-357d-4c0a-8e01-e83489b9b5a7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-90492cb0-357d-4c0a-8e01-e83489b9b5a7_0">
											<gml:posList>35.670575208766394 139.74323136762595 30.49 35.67057537160028 139.74323215172933 30.49 35.67057537160028 139.74323215172933 32.464 35.670575208766394 139.74323136762595 32.464 35.670575208766394 139.74323136762595 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b6c0a6e-8c7b-45c0-886a-1720975d0fbd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2b6c0a6e-8c7b-45c0-886a-1720975d0fbd_0">
											<gml:posList>35.67058988400027 139.74323254413326 30.49 35.670590063696146 139.74323177069112 30.49 35.670590063696146 139.74323177069112 32.464 35.67058988400027 139.74323254413326 32.464 35.67058988400027 139.74323254413326 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ead7345-4219-40e5-97d8-e27e5bbf8ac7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6ead7345-4219-40e5-97d8-e27e5bbf8ac7_0">
											<gml:posList>35.67057557949449 139.74323292473576 30.49 35.67057557949449 139.74323292473576 32.464 35.67057537160028 139.74323215172933 32.464 35.67057537160028 139.74323215172933 30.49 35.67057557949449 139.74323292473576 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63dac134-dbe2-49d6-a8a7-155a7f91a3fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-63dac134-dbe2-49d6-a8a7-155a7f91a3fd_0">
											<gml:posList>35.670589641200074 139.74323330660002 30.49 35.67058988400027 139.74323254413326 30.49 35.67058988400027 139.74323254413326 32.464 35.670589641200074 139.74323330660002 32.464 35.670589641200074 139.74323330660002 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f900a5e7-9332-42b6-a1e8-abf493a73add">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f900a5e7-9332-42b6-a1e8-abf493a73add_0">
											<gml:posList>35.67057557949449 139.74323292473576 30.49 35.67057585046823 139.74323367557875 30.49 35.67057585046823 139.74323367557875 32.464 35.67057557949449 139.74323292473576 32.464 35.67057557949449 139.74323292473576 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-714591ae-f066-41cf-bfb5-e2ac9f4d6fdb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-714591ae-f066-41cf-bfb5-e2ac9f4d6fdb_0">
											<gml:posList>35.670589641200074 139.74323330660002 30.49 35.670589641200074 139.74323330660002 32.464 35.67058934429272 139.7432340359887 32.464 35.67058934429272 139.7432340359887 30.49 35.670589641200074 139.74323330660002 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b118b9f7-ec81-4d92-867a-c713044da612">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b118b9f7-ec81-4d92-867a-c713044da612_0">
											<gml:posList>35.67057585046823 139.74323367557875 30.49 35.670576166477524 139.743234382186 30.49 35.670576166477524 139.743234382186 32.464 35.67057585046823 139.74323367557875 32.464 35.67057585046823 139.74323367557875 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f7fe60f-d43f-49c1-9ef3-c9d5f787f3f2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f7fe60f-d43f-49c1-9ef3-c9d5f787f3f2_0">
											<gml:posList>35.67058900229197 139.74323473228924 30.49 35.67058934429272 139.7432340359887 30.49 35.67058934429272 139.7432340359887 32.464 35.67058900229197 139.74323473228924 32.464 35.67058900229197 139.74323473228924 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef64a4d4-da23-4289-9c38-323cb4f745a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef64a4d4-da23-4289-9c38-323cb4f745a8_0">
											<gml:posList>35.670576166477524 139.743234382186 30.49 35.67057653654437 139.7432350555936 30.49 35.67057653654437 139.7432350555936 32.464 35.670576166477524 139.743234382186 32.464 35.670576166477524 139.743234382186 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3bf7b324-66b8-434a-aed8-14a8c7def9a9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3bf7b324-66b8-434a-aed8-14a8c7def9a9_0">
											<gml:posList>35.670588606175805 139.74323538446538 30.49 35.67058900229197 139.74323473228924 30.49 35.67058900229197 139.74323473228924 32.464 35.670588606175805 139.74323538446538 32.464 35.670588606175805 139.74323538446538 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bcc17c9d-79ac-404e-87f4-24a204384d06">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bcc17c9d-79ac-404e-87f4-24a204384d06_0">
											<gml:posList>35.67057653654437 139.7432350555936 30.49 35.670576951655015 139.74323569581176 30.49 35.670576951655015 139.74323569581176 32.464 35.67057653654437 139.7432350555936 32.464 35.67057653654437 139.7432350555936 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82c0103b-b355-408f-8336-d3fcaadd3b88">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-82c0103b-b355-408f-8336-d3fcaadd3b88_0">
											<gml:posList>35.67058817397995 139.7432360035432 30.49 35.670588606175805 139.74323538446538 30.49 35.670588606175805 139.74323538446538 32.464 35.67058817397995 139.7432360035432 32.464 35.67058817397995 139.7432360035432 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d223bfd-5181-4b53-b5db-9935545d005f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3d223bfd-5181-4b53-b5db-9935545d005f_0">
											<gml:posList>35.670576951655015 139.74323569581176 30.49 35.670577411792955 139.7432362807479 30.49 35.670577411792955 139.7432362807479 32.464 35.670576951655015 139.74323569581176 32.464 35.670576951655015 139.74323569581176 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ebcca9b-da28-4b52-92d9-dfc62ec393ad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3ebcca9b-da28-4b52-92d9-dfc62ec393ad_0">
											<gml:posList>35.67058817397995 139.7432360035432 30.49 35.67058817397995 139.7432360035432 32.464 35.67058768766042 139.7432365674504 32.464 35.67058768766042 139.7432365674504 30.49 35.67058817397995 139.7432360035432 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca2d6d52-c821-4a61-a51e-7f323348cb80">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ca2d6d52-c821-4a61-a51e-7f323348cb80_0">
											<gml:posList>35.670577411792955 139.7432362807479 30.49 35.67057790795271 139.7432368214584 30.49 35.67057790795271 139.7432368214584 32.464 35.670577411792955 139.7432362807479 32.464 35.670577411792955 139.7432362807479 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-52313017-6d59-4627-8d6b-04cf85b505da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-52313017-6d59-4627-8d6b-04cf85b505da_0">
											<gml:posList>35.67058717425016 139.7432370651103 30.49 35.67058768766042 139.7432365674504 30.49 35.67058768766042 139.7432365674504 32.464 35.67058717425016 139.7432370651103 32.464 35.67058717425016 139.7432370651103 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9cf8bbba-a123-408b-a652-a326160d7df0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9cf8bbba-a123-408b-a652-a326160d7df0_0">
											<gml:posList>35.67057790795271 139.7432368214584 30.49 35.67057844913149 139.7432372958406 30.49 35.67057844913149 139.7432372958406 32.464 35.67057790795271 139.7432368214584 32.464 35.67057790795271 139.7432368214584 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61c8218a-7588-44db-bbc5-32de20f15747">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-61c8218a-7588-44db-bbc5-32de20f15747_0">
											<gml:posList>35.67058662475191 139.74323751862562 30.49 35.67058717425016 139.7432370651103 30.49 35.67058717425016 139.7432370651103 32.464 35.67058662475191 139.74323751862562 32.464 35.67058662475191 139.74323751862562 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04cd5bda-1612-4664-bc13-68bec9069e6e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-04cd5bda-1612-4664-bc13-68bec9069e6e_0">
											<gml:posList>35.67057844913149 139.7432372958406 30.49 35.670579017318396 139.74323772600735 30.49 35.670579017318396 139.74323772600735 32.464 35.67057844913149 139.7432372958406 32.464 35.67057844913149 139.7432372958406 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8131e300-cb41-4ae0-95e3-e5c9bd2a69ac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8131e300-cb41-4ae0-95e3-e5c9bd2a69ac_0">
											<gml:posList>35.67058662475191 139.74323751862562 30.49 35.67058662475191 139.74323751862562 32.464 35.670586039157456 139.74323791695 32.464 35.670586039157456 139.74323791695 30.49 35.67058662475191 139.74323751862562 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9440967a-3dd6-4dec-98dc-3605e1a6ee33">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9440967a-3dd6-4dec-98dc-3605e1a6ee33_0">
											<gml:posList>35.670579017318396 139.74323772600735 30.49 35.6705796124886 139.74323807881973 30.49 35.6705796124886 139.74323807881973 32.464 35.670579017318396 139.74323772600735 32.464 35.670579017318396 139.74323772600735 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-65d1e79b-d957-43ad-982e-ec9540e7a01e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-65d1e79b-d957-43ad-982e-ec9540e7a01e_0">
											<gml:posList>35.670586039157456 139.74323791695 30.49 35.670586039157456 139.74323791695 32.464 35.6705854354777 139.74323823797073 32.464 35.6705854354777 139.74323823797073 30.49 35.670586039157456 139.74323791695 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5abe440c-a2a9-488a-b9e5-15b39f10ac10">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5abe440c-a2a9-488a-b9e5-15b39f10ac10_0">
											<gml:posList>35.6705796124886 139.74323807881973 30.49 35.67058022564492 139.74323837638048 30.49 35.67058022564492 139.74323837638048 32.464 35.6705796124886 139.74323807881973 32.464 35.6705796124886 139.74323807881973 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-23ed7c48-0b99-4d62-8b61-fc27df5d4efd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-23ed7c48-0b99-4d62-8b61-fc27df5d4efd_0">
											<gml:posList>35.67058480471544 139.74323850379042 30.49 35.6705854354777 139.74323823797073 30.49 35.6705854354777 139.74323823797073 32.464 35.67058480471544 139.74323850379042 32.464 35.67058480471544 139.74323850379042 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-06ab13b1-f639-4225-a792-7d6c37422886">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-06ab13b1-f639-4225-a792-7d6c37422886_0">
											<gml:posList>35.67058022564492 139.74323837638048 30.49 35.67058086579283 139.74323860763317 30.49 35.67058086579283 139.74323860763317 32.464 35.67058022564492 139.74323837638048 32.464 35.67058022564492 139.74323837638048 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-17bab32a-a287-4f54-8090-4ba67c634ef5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-17bab32a-a287-4f54-8090-4ba67c634ef5_0">
											<gml:posList>35.67058415586787 139.74323869230642 30.49 35.67058480471544 139.74323850379042 30.49 35.67058480471544 139.74323850379042 32.464 35.67058415586787 139.74323869230642 32.464 35.67058415586787 139.74323869230642 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35941393-cd45-448d-ab49-008452d57a76">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-35941393-cd45-448d-ab49-008452d57a76_0">
											<gml:posList>35.67058086579283 139.74323860763317 30.49 35.670581514896604 139.7432387615518 30.49 35.670581514896604 139.7432387615518 32.464 35.67058086579283 139.74323860763317 32.464 35.67058086579283 139.74323860763317 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ae85aa8-64f9-47e2-bfc7-4cc6569f7c3b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7ae85aa8-64f9-47e2-bfc7-4cc6569f7c3b_0">
											<gml:posList>35.67058415586787 139.74323869230642 30.49 35.67058415586787 139.74323869230642 32.464 35.67058350697073 139.74323881454475 32.464 35.67058350697073 139.74323881454475 30.49 35.67058415586787 139.74323869230642 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b3e8344-2e00-4755-a8ab-9596ac8a5f4b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b3e8344-2e00-4755-a8ab-9596ac8a5f4b_0">
											<gml:posList>35.67058217296451 139.74323884918263 30.49 35.67058217296451 139.74323884918263 32.464 35.670581514896604 139.7432387615518 32.464 35.670581514896604 139.7432387615518 30.49 35.67058217296451 139.74323884918263 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0298eff-b281-4d99-9808-ec3a45c2280d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d0298eff-b281-4d99-9808-ec3a45c2280d_0">
											<gml:posList>35.67058283999655 139.74323887052566 30.49 35.67058350697073 139.74323881454475 30.49 35.67058350697073 139.74323881454475 32.464 35.67058283999655 139.74323887052566 32.464 35.67058283999655 139.74323887052566 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b45b63d2-d05d-4398-9c81-ad39902212e7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b45b63d2-d05d-4398-9c81-ad39902212e7_0">
											<gml:posList>35.67058217296451 139.74323884918263 30.49 35.67058283999655 139.74323887052566 30.49 35.67058283999655 139.74323887052566 32.464 35.67058217296451 139.74323884918263 32.464 35.67058217296451 139.74323884918263 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27bf1c97-09c0-404f-b400-196d7efee7fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-27bf1c97-09c0-404f-b400-196d7efee7fd_0">
											<gml:posList>35.670592895490906 139.74326989929853 27.721 35.670578055085485 139.74326481258427 27.721 35.670578055085485 139.74326481258427 30.861 35.670592895490906 139.74326989929853 30.861 35.670592895490906 139.74326989929853 27.721</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd0d8d77-383d-4a5b-9a72-98377506d427">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cd0d8d77-383d-4a5b-9a72-98377506d427_0">
											<gml:posList>35.670578055085485 139.74326481258427 27.721 35.67057359888548 139.74328434742455 27.721 35.67057359888548 139.74328434742455 30.861 35.670578055085485 139.74326481258427 30.861 35.670578055085485 139.74326481258427 27.721</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c01a629-006f-48d8-9944-4839f7012af1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4c01a629-006f-48d8-9944-4839f7012af1_0">
											<gml:posList>35.67057359888548 139.74328434742455 30.861 35.67058844830382 139.74328943413198 30.861 35.670592895490906 139.74326989929853 30.861 35.670578055085485 139.74326481258427 30.861 35.67057359888548 139.74328434742455 30.861</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8ea56b69-2bc8-4827-af25-77e99315678d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8ea56b69-2bc8-4827-af25-77e99315678d_0">
											<gml:posList>35.670592895490906 139.74326989929853 27.721 35.670592895490906 139.74326989929853 30.861 35.67058844830382 139.74328943413198 30.861 35.67058844830382 139.74328943413198 27.721 35.670592895490906 139.74326989929853 27.721</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dce7902a-498d-4412-ab4c-112bf74ab0f3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dce7902a-498d-4412-ab4c-112bf74ab0f3_0">
											<gml:posList>35.67057359888548 139.74328434742455 27.721 35.67058844830382 139.74328943413198 27.721 35.67058844830382 139.74328943413198 30.861 35.67057359888548 139.74328434742455 30.861 35.67057359888548 139.74328434742455 27.721</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-9cd9cacb-22e0-44c2-8394-10923c8af2c0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9cd9cacb-22e0-44c2-8394-10923c8af2c0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9cd9cacb-22e0-44c2-8394-10923c8af2c0">
											<gml:posList>35.670641325684635 139.74334145803144 7.24 35.670552792016 139.7433162614138 7.24 35.67057631889192 139.74319715602837 7.24 35.670663860579445 139.74322169085877 7.24 35.670641325684635 139.74334145803144 7.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d5f37396-3455-4ebd-800a-7257dbeef4ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5f37396-3455-4ebd-800a-7257dbeef4ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5f37396-3455-4ebd-800a-7257dbeef4ba">
											<gml:posList>35.67056846759592 139.74324488480897 28.4 35.6705669889817 139.7432444004338 28.4 35.67056807230614 139.74324664161256 28.4 35.67056846759592 139.74324488480897 28.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c42112f6-3f15-467b-a4d1-633e8d0988b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c42112f6-3f15-467b-a4d1-633e8d0988b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c42112f6-3f15-467b-a4d1-633e8d0988b4">
											<gml:posList>35.670552792016 139.7433162614138 28.4 35.67055458472292 139.7433148896619 28.4 35.67056807230614 139.74324664161256 28.4 35.6705669889817 139.7432444004338 28.4 35.670552792016 139.7433162614138 28.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1ab70e80-e92c-40da-b31c-752ba5331921">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ab70e80-e92c-40da-b31c-752ba5331921">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ab70e80-e92c-40da-b31c-752ba5331921">
											<gml:posList>35.6705669889817 139.7432444004338 31.065 35.670568574529185 139.74324323879227 31.065 35.67057730282649 139.74319907697614 31.065 35.67057631889192 139.74319715602837 31.065 35.6705669889817 139.7432444004338 31.065</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-950401a0-c99f-4e39-98a3-47fe7a0518a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-950401a0-c99f-4e39-98a3-47fe7a0518a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-950401a0-c99f-4e39-98a3-47fe7a0518a9">
											<gml:posList>35.670589934609225 139.74325199659063 31.065 35.67058899568627 139.74324999826734 31.065 35.670568574529185 139.74324323879227 31.065 35.6705669889817 139.7432444004338 31.065 35.670589934609225 139.74325199659063 31.065</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d1e3307c-2594-4fe4-ba9d-be376c5d52ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1e3307c-2594-4fe4-ba9d-be376c5d52ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1e3307c-2594-4fe4-ba9d-be376c5d52ca">
											<gml:posList>35.67057730282649 139.74319907697614 30.49 35.670568574529185 139.74324323879227 30.49 35.67058899568627 139.74324999826734 30.49 35.670593270936685 139.74322956887534 30.49 35.670598823122795 139.74320511719634 30.49 35.67057730282649 139.74319907697614 30.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-92c8f842-f504-4d78-b539-b5846fad6ad4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-92c8f842-f504-4d78-b539-b5846fad6ad4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-92c8f842-f504-4d78-b539-b5846fad6ad4">
											<gml:posList>35.67057631889192 139.74319715602837 31.065 35.67057730282649 139.74319907697614 31.065 35.670598823122795 139.74320511719634 31.065 35.670600453713696 139.74320392236402 31.065 35.67057631889192 139.74319715602837 31.065</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-71007910-3621-4eb1-a4e5-aeeaf2fb454c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-71007910-3621-4eb1-a4e5-aeeaf2fb454c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-71007910-3621-4eb1-a4e5-aeeaf2fb454c">
											<gml:posList>35.670594542194 139.74322999825196 31.065 35.670593270936685 139.74322956887534 31.065 35.67058899568627 139.74324999826734 31.065 35.670589934609225 139.74325199659063 31.065 35.670594542194 139.74322999825196 31.065</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5a2a0d57-daff-40cd-b6ee-07e3cfd61ffd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a2a0d57-daff-40cd-b6ee-07e3cfd61ffd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a2a0d57-daff-40cd-b6ee-07e3cfd61ffd">
											<gml:posList>35.670594542194 139.74322999825196 31.065 35.670600453713696 139.74320392236402 31.065 35.670598823122795 139.74320511719634 31.065 35.670593270936685 139.74322956887534 31.065 35.670594542194 139.74322999825196 31.065</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7b08530b-3e8c-42d0-9c3c-e03b32c38d5c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b08530b-3e8c-42d0-9c3c-e03b32c38d5c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b08530b-3e8c-42d0-9c3c-e03b32c38d5c">
											<gml:posList>35.670641325684635 139.74334145803144 28.4 35.670640197318136 139.74333925003884 28.4 35.67055458472292 139.7433148896619 28.4 35.670552792016 139.7433162614138 28.4 35.670641325684635 139.74334145803144 28.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a31b99cc-7e1d-41a3-a37a-30d7c2f03533">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a31b99cc-7e1d-41a3-a37a-30d7c2f03533">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a31b99cc-7e1d-41a3-a37a-30d7c2f03533">
											<gml:posList>35.67063398710921 139.74324315424562 27.721 35.670594542194 139.74322999825196 27.721 35.670589934609225 139.74325199659063 27.721 35.67056846759592 139.74324488480897 27.721 35.67056807230614 139.74324664161256 27.721 35.67055458472292 139.7433148896619 27.721 35.670640197318136 139.74333925003884 27.721 35.670662067873614 139.74322306261465 27.721 35.6706414220997 139.74321727546678 27.721 35.67063999756772 139.7432167910309 27.721 35.67063398710921 139.74324315424562 27.721</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-df80cb58-2144-4e1d-9101-20f3a23b17de">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df80cb58-2144-4e1d-9101-20f3a23b17de">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df80cb58-2144-4e1d-9101-20f3a23b17de">
											<gml:posList>35.67063398710921 139.74324315424562 31.938 35.67064037488749 139.7432151115699 31.938 35.670600453713696 139.74320392236402 31.938 35.670594542194 139.74322999825196 31.938 35.67063398710921 139.74324315424562 31.938</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6425ae3c-422a-45ab-af0a-1611c4d48f41">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6425ae3c-422a-45ab-af0a-1611c4d48f41">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6425ae3c-422a-45ab-af0a-1611c4d48f41">
											<gml:posList>35.6706414220997 139.74321727546678 28.4 35.67064037488749 139.7432151115699 28.4 35.67063999756772 139.7432167910309 28.4 35.6706414220997 139.74321727546678 28.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e0e18119-68e9-4947-8953-9df72f882747">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e0e18119-68e9-4947-8953-9df72f882747">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e0e18119-68e9-4947-8953-9df72f882747">
											<gml:posList>35.670663860579445 139.74322169085877 28.4 35.670662067873614 139.74322306261465 28.4 35.670640197318136 139.74333925003884 28.4 35.670641325684635 139.74334145803144 28.4 35.670663860579445 139.74322169085877 28.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d4ee7099-4fd7-4abf-a0ed-a15ab8a1327d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4ee7099-4fd7-4abf-a0ed-a15ab8a1327d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4ee7099-4fd7-4abf-a0ed-a15ab8a1327d">
											<gml:posList>35.67064037488749 139.7432151115699 28.4 35.6706414220997 139.74321727546678 28.4 35.670662067873614 139.74322306261465 28.4 35.670663860579445 139.74322169085877 28.4 35.67064037488749 139.7432151115699 28.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1ccd7520-1d3d-4420-b0fa-92197803cb6a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ccd7520-1d3d-4420-b0fa-92197803cb6a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ccd7520-1d3d-4420-b0fa-92197803cb6a">
											<gml:posList>35.67057730282649 139.74319907697614 31.065 35.67057730282649 139.74319907697614 30.49 35.670598823122795 139.74320511719634 30.49 35.670598823122795 139.74320511719634 31.065 35.67057730282649 139.74319907697614 31.065</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3992188f-8eed-4764-9a45-90635e7886e9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3992188f-8eed-4764-9a45-90635e7886e9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3992188f-8eed-4764-9a45-90635e7886e9">
											<gml:posList>35.670600453713696 139.74320392236402 31.065 35.670600453713696 139.74320392236402 31.938 35.67064037488749 139.7432151115699 31.938 35.67064037488749 139.7432151115699 28.4 35.670663860579445 139.74322169085877 28.4 35.670663860579445 139.74322169085877 7.24 35.67057631889192 139.74319715602837 7.24 35.67057631889192 139.74319715602837 31.065 35.670600453713696 139.74320392236402 31.065</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a77ad187-17d7-434e-bbd3-0c4e92a1bf16">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a77ad187-17d7-434e-bbd3-0c4e92a1bf16">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a77ad187-17d7-434e-bbd3-0c4e92a1bf16">
											<gml:posList>35.670594542194 139.74322999825196 31.065 35.670594542194 139.74322999825196 31.938 35.670600453713696 139.74320392236402 31.938 35.670600453713696 139.74320392236402 31.065 35.670594542194 139.74322999825196 31.065</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2a40dee0-bfeb-476f-8b5c-742f442f503c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a40dee0-bfeb-476f-8b5c-742f442f503c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a40dee0-bfeb-476f-8b5c-742f442f503c">
											<gml:posList>35.67063999756772 139.7432167910309 28.4 35.67063999756772 139.7432167910309 27.721 35.6706414220997 139.74321727546678 27.721 35.6706414220997 139.74321727546678 28.4 35.67063999756772 139.7432167910309 28.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-14b3f0e1-e92a-4047-9a1f-2ce4c3fe86d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-14b3f0e1-e92a-4047-9a1f-2ce4c3fe86d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-14b3f0e1-e92a-4047-9a1f-2ce4c3fe86d1">
											<gml:posList>35.670598823122795 139.74320511719634 31.065 35.670598823122795 139.74320511719634 30.49 35.670593270936685 139.74322956887534 30.49 35.670593270936685 139.74322956887534 31.065 35.670598823122795 139.74320511719634 31.065</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0e1fe1ad-a2fe-49d8-be9e-acb9acea2972">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e1fe1ad-a2fe-49d8-be9e-acb9acea2972">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e1fe1ad-a2fe-49d8-be9e-acb9acea2972">
											<gml:posList>35.6706414220997 139.74321727546678 28.4 35.6706414220997 139.74321727546678 27.721 35.670662067873614 139.74322306261465 27.721 35.670662067873614 139.74322306261465 28.4 35.6706414220997 139.74321727546678 28.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-80bad706-c067-4352-a5d4-04859eccced1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-80bad706-c067-4352-a5d4-04859eccced1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-80bad706-c067-4352-a5d4-04859eccced1">
											<gml:posList>35.670568574529185 139.74324323879227 31.065 35.670568574529185 139.74324323879227 30.49 35.67057730282649 139.74319907697614 30.49 35.67057730282649 139.74319907697614 31.065 35.670568574529185 139.74324323879227 31.065</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d447d950-c0ad-404e-9e16-e6566f5b4f5b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d447d950-c0ad-404e-9e16-e6566f5b4f5b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d447d950-c0ad-404e-9e16-e6566f5b4f5b">
											<gml:posList>35.67063999756772 139.7432167910309 28.4 35.67064037488749 139.7432151115699 28.4 35.67064037488749 139.7432151115699 31.938 35.67063398710921 139.74324315424562 31.938 35.67063398710921 139.74324315424562 27.721 35.67063999756772 139.7432167910309 27.721 35.67063999756772 139.7432167910309 28.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ffe0dae3-fb76-41c7-a6b5-69ddfd684784">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ffe0dae3-fb76-41c7-a6b5-69ddfd684784">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ffe0dae3-fb76-41c7-a6b5-69ddfd684784">
											<gml:posList>35.67063398710921 139.74324315424562 27.721 35.67063398710921 139.74324315424562 31.938 35.670594542194 139.74322999825196 31.938 35.670594542194 139.74322999825196 31.065 35.670594542194 139.74322999825196 27.721 35.67063398710921 139.74324315424562 27.721</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c207c1c1-b3e2-4a7c-bcc3-a5610fb5e6d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c207c1c1-b3e2-4a7c-bcc3-a5610fb5e6d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c207c1c1-b3e2-4a7c-bcc3-a5610fb5e6d4">
											<gml:posList>35.670593270936685 139.74322956887534 31.065 35.670593270936685 139.74322956887534 30.49 35.67058899568627 139.74324999826734 30.49 35.67058899568627 139.74324999826734 31.065 35.670593270936685 139.74322956887534 31.065</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dd5328d4-4e92-4a4d-9dd6-67f799d76e56">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd5328d4-4e92-4a4d-9dd6-67f799d76e56">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd5328d4-4e92-4a4d-9dd6-67f799d76e56">
											<gml:posList>35.670589934609225 139.74325199659063 27.721 35.670594542194 139.74322999825196 27.721 35.670594542194 139.74322999825196 31.065 35.670589934609225 139.74325199659063 31.065 35.670589934609225 139.74325199659063 27.721</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8871b674-b442-4d4c-b302-3cf155fe63c8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8871b674-b442-4d4c-b302-3cf155fe63c8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8871b674-b442-4d4c-b302-3cf155fe63c8">
											<gml:posList>35.67056807230614 139.74324664161256 28.4 35.67056807230614 139.74324664161256 27.721 35.67056846759592 139.74324488480897 27.721 35.67056846759592 139.74324488480897 28.4 35.67056807230614 139.74324664161256 28.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6b7ff42a-2a9e-4c0b-bf65-59164098bbe7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b7ff42a-2a9e-4c0b-bf65-59164098bbe7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b7ff42a-2a9e-4c0b-bf65-59164098bbe7">
											<gml:posList>35.67058899568627 139.74324999826734 31.065 35.67058899568627 139.74324999826734 30.49 35.670568574529185 139.74324323879227 30.49 35.670568574529185 139.74324323879227 31.065 35.67058899568627 139.74324999826734 31.065</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-89ff61f2-abe5-4d42-81fa-93d8fb70b1db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-89ff61f2-abe5-4d42-81fa-93d8fb70b1db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-89ff61f2-abe5-4d42-81fa-93d8fb70b1db">
											<gml:posList>35.670589934609225 139.74325199659063 27.721 35.670589934609225 139.74325199659063 31.065 35.6705669889817 139.7432444004338 31.065 35.6705669889817 139.7432444004338 28.4 35.67056846759592 139.74324488480897 28.4 35.67056846759592 139.74324488480897 27.721 35.670589934609225 139.74325199659063 27.721</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-64d209db-98ae-4c08-8cf9-12a5a0653c37">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-64d209db-98ae-4c08-8cf9-12a5a0653c37">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-64d209db-98ae-4c08-8cf9-12a5a0653c37">
											<gml:posList>35.67057631889192 139.74319715602837 7.24 35.670552792016 139.7433162614138 7.24 35.670552792016 139.7433162614138 28.4 35.6705669889817 139.7432444004338 28.4 35.6705669889817 139.7432444004338 31.065 35.67057631889192 139.74319715602837 31.065 35.67057631889192 139.74319715602837 7.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b9df8fcd-7fbb-4e40-8633-525f46bf2edd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b9df8fcd-7fbb-4e40-8633-525f46bf2edd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b9df8fcd-7fbb-4e40-8633-525f46bf2edd">
											<gml:posList>35.67055458472292 139.7433148896619 28.4 35.67055458472292 139.7433148896619 27.721 35.67056807230614 139.74324664161256 27.721 35.67056807230614 139.74324664161256 28.4 35.67055458472292 139.7433148896619 28.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b1b83ba4-64c8-408d-b9a9-91fe2a2740f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b1b83ba4-64c8-408d-b9a9-91fe2a2740f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b1b83ba4-64c8-408d-b9a9-91fe2a2740f9">
											<gml:posList>35.670662067873614 139.74322306261465 28.4 35.670662067873614 139.74322306261465 27.721 35.670640197318136 139.74333925003884 27.721 35.670640197318136 139.74333925003884 28.4 35.670662067873614 139.74322306261465 28.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-afa065bf-3ae3-4356-ad82-845819e8bfa2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-afa065bf-3ae3-4356-ad82-845819e8bfa2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-afa065bf-3ae3-4356-ad82-845819e8bfa2">
											<gml:posList>35.670641325684635 139.74334145803144 7.24 35.670663860579445 139.74322169085877 7.24 35.670663860579445 139.74322169085877 28.4 35.670641325684635 139.74334145803144 28.4 35.670641325684635 139.74334145803144 7.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a6d9c5b7-e399-4985-b86c-571d3404d24f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a6d9c5b7-e399-4985-b86c-571d3404d24f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a6d9c5b7-e399-4985-b86c-571d3404d24f">
											<gml:posList>35.670640197318136 139.74333925003884 28.4 35.670640197318136 139.74333925003884 27.721 35.67055458472292 139.7433148896619 27.721 35.67055458472292 139.7433148896619 28.4 35.670640197318136 139.74333925003884 28.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7ccff302-72e0-4585-bb58-6eeea01a4c04">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ccff302-72e0-4585-bb58-6eeea01a4c04">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ccff302-72e0-4585-bb58-6eeea01a4c04">
											<gml:posList>35.670552792016 139.7433162614138 7.24 35.670641325684635 139.74334145803144 7.24 35.670641325684635 139.74334145803144 28.4 35.670552792016 139.7433162614138 28.4 35.670552792016 139.7433162614138 7.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7635</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">111.35655</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">2</uro:rank>
					<uro:depth uom="m">0.62</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>