<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_95930e6d-930f-4a09-9376-3bd56dcd5069">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">11.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67192733668533 139.74020562208958 0 35.67177013304042 139.74004879044105 0 35.67170936125089 139.74014032569522 0 35.67181538140865 139.7402460827499 0 35.671829011227985 139.74022413970346 0 35.67186177333229 139.74025549570456 0 35.67184704401269 139.74027767200653 0 35.67186656477827 139.7402971574049 0 35.67192733668533 139.74020562208958 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67192733668533 139.74020562208958 8.136 35.67186656477827 139.7402971574049 8.136 35.67184704401269 139.74027767200653 8.136 35.67186177333229 139.74025549570456 8.136 35.671829011227985 139.74022413970346 8.136 35.67181538140865 139.7402460827499 8.136 35.67170936125089 139.74014032569522 8.136 35.67177013304042 139.74004879044105 8.136 35.67192733668533 139.74020562208958 8.136</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67192733668533 139.74020562208958 8.136 35.67177013304042 139.74004879044105 8.136 35.67177013304042 139.74004879044105 19.56 35.67192733668533 139.74020562208958 19.56 35.67192733668533 139.74020562208958 8.136</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67177013304042 139.74004879044105 8.136 35.67170936125089 139.74014032569522 8.136 35.67170936125089 139.74014032569522 19.56 35.67177013304042 139.74004879044105 19.56 35.67177013304042 139.74004879044105 8.136</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67170936125089 139.74014032569522 8.136 35.67181538140865 139.7402460827499 8.136 35.67181538140865 139.7402460827499 19.56 35.67170936125089 139.74014032569522 19.56 35.67170936125089 139.74014032569522 8.136</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67181538140865 139.7402460827499 8.136 35.671829011227985 139.74022413970346 8.136 35.671829011227985 139.74022413970346 19.56 35.67181538140865 139.7402460827499 19.56 35.67181538140865 139.7402460827499 8.136</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671829011227985 139.74022413970346 8.136 35.67186177333229 139.74025549570456 8.136 35.67186177333229 139.74025549570456 19.56 35.671829011227985 139.74022413970346 19.56 35.671829011227985 139.74022413970346 8.136</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67186177333229 139.74025549570456 8.136 35.67184704401269 139.74027767200653 8.136 35.67184704401269 139.74027767200653 19.56 35.67186177333229 139.74025549570456 19.56 35.67186177333229 139.74025549570456 8.136</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67184704401269 139.74027767200653 8.136 35.67186656477827 139.7402971574049 8.136 35.67186656477827 139.7402971574049 19.56 35.67184704401269 139.74027767200653 19.56 35.67184704401269 139.74027767200653 8.136</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67186656477827 139.7402971574049 8.136 35.67192733668533 139.74020562208958 8.136 35.67192733668533 139.74020562208958 19.56 35.67186656477827 139.7402971574049 19.56 35.67186656477827 139.7402971574049 8.136</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67192733668533 139.74020562208958 19.56 35.67177013304042 139.74004879044105 19.56 35.67170936125089 139.74014032569522 19.56 35.67181538140865 139.7402460827499 19.56 35.671829011227985 139.74022413970346 19.56 35.67186177333229 139.74025549570456 19.56 35.67184704401269 139.74027767200653 19.56 35.67186656477827 139.7402971574049 19.56 35.67192733668533 139.74020562208958 19.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-f371d909-9bac-42e1-8883-82e39c652bd6"/>
							<gml:surfaceMember xlink:href="#poly-abc76644-2684-485f-a705-62fa4d03bffa"/>
							<gml:surfaceMember xlink:href="#poly-16abed3d-3358-42a5-be1d-4ee499bc5ccc"/>
							<gml:surfaceMember xlink:href="#poly-9c263a33-3f82-4b55-a090-b11479eba1f6"/>
							<gml:surfaceMember xlink:href="#poly-3c51eca9-9ddd-4452-a730-5d0446cdc299"/>
							<gml:surfaceMember xlink:href="#poly-7c7a135c-a5b3-4db2-83fc-e86d474b0e84"/>
							<gml:surfaceMember xlink:href="#poly-29401b49-2065-42eb-97bf-ce23d0fa4cb3"/>
							<gml:surfaceMember xlink:href="#poly-dab8ce1d-f2d4-421f-9c81-8d07898c6c43"/>
							<gml:surfaceMember xlink:href="#poly-5d24831b-6207-466c-a755-c5b774b69660"/>
							<gml:surfaceMember xlink:href="#poly-b589a214-bf86-4b8b-9a17-8a9ee1cba561"/>
							<gml:surfaceMember xlink:href="#poly-9e66c031-a38a-4fe4-9975-76b5bb14cccf"/>
							<gml:surfaceMember xlink:href="#poly-29aa493c-c358-4d23-8654-95c35432f39a"/>
							<gml:surfaceMember xlink:href="#poly-7d98b951-4844-4369-9096-573bf63c5044"/>
							<gml:surfaceMember xlink:href="#poly-331c3cfe-3147-4dd0-bc0b-4e35eaaeb7c1"/>
							<gml:surfaceMember xlink:href="#poly-30c9b296-b319-40c1-af31-52e57fcf541e"/>
							<gml:surfaceMember xlink:href="#poly-8873b940-f8a3-4c9a-b4f6-bb913520d09a"/>
							<gml:surfaceMember xlink:href="#poly-7579a0f6-7efd-449a-a0dd-64bc85cb62d5"/>
							<gml:surfaceMember xlink:href="#poly-dde4b903-d1c5-4c39-afd6-77b613d30923"/>
							<gml:surfaceMember xlink:href="#poly-ce6d5357-dc41-4dbc-b6df-7b47adbaa773"/>
							<gml:surfaceMember xlink:href="#poly-115ca745-3fcc-428c-8faa-478c15410143"/>
							<gml:surfaceMember xlink:href="#poly-25c5f465-7683-4b29-bec4-6a64a088ea33"/>
							<gml:surfaceMember xlink:href="#poly-d7be5b60-1059-4c22-9e7e-a62268dd9220"/>
							<gml:surfaceMember xlink:href="#poly-9f803c13-fc86-418c-a46c-18e5ffe1f1c3"/>
							<gml:surfaceMember xlink:href="#poly-ccb85046-dd0a-460a-8888-90f359047022"/>
							<gml:surfaceMember xlink:href="#poly-2b9af7ac-ddd2-4707-b2bf-e53481942fe2"/>
							<gml:surfaceMember xlink:href="#poly-2de81598-1e03-44f5-8eb9-f77e72146434"/>
							<gml:surfaceMember xlink:href="#poly-e0e2bf58-f608-416e-9b94-9f48019aa182"/>
							<gml:surfaceMember xlink:href="#poly-bff6eda1-c118-4954-98ab-d730ce0c5912"/>
							<gml:surfaceMember xlink:href="#poly-cf4dfdcd-5706-4ac4-ba63-26bc7d8ad33a"/>
							<gml:surfaceMember xlink:href="#poly-effc1bd4-e56e-49d7-9c0c-b71c1af618c4"/>
							<gml:surfaceMember xlink:href="#poly-56a8370c-c486-44ab-9159-c3f5500613f6"/>
							<gml:surfaceMember xlink:href="#poly-df5bfcbe-602e-43f4-9d5d-187c14cfc060"/>
							<gml:surfaceMember xlink:href="#poly-061a7429-a882-4819-b616-e7469bd0ead0"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_95930e6d-930f-4a09-9376-3bd56dcd5069_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-85eb8977-2af6-4264-aa2b-1cc7ac8efed1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67181538141715 139.74024609379634 8.136 35.67182900221424 139.74022413971392 8.136 35.671861764318564 139.74025549571502 8.136 35.67184703499895 139.740277672017 8.136 35.67181538141715 139.74024609379634 8.136</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-92af4bec-19ab-4ca8-960b-fb6a3de0766a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-92af4bec-19ab-4ca8-960b-fb6a3de0766a_0">
											<gml:posList>35.67182900221424 139.74022413971392 20.479 35.67182900221424 139.74022413971392 8.136 35.67181538141715 139.74024609379634 8.136 35.67181538141715 139.74024609379634 20.479 35.67182900221424 139.74022413971392 20.479</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f6d0dc44-c0ed-4843-895c-839e66890c06">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f6d0dc44-c0ed-4843-895c-839e66890c06_0">
											<gml:posList>35.671861764318564 139.74025549571502 20.479 35.671861764318564 139.74025549571502 8.136 35.67182900221424 139.74022413971392 8.136 35.67182900221424 139.74022413971392 20.479 35.671861764318564 139.74025549571502 20.479</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-55242983-716f-4df0-8e47-237093ed59a1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-55242983-716f-4df0-8e47-237093ed59a1_0">
											<gml:posList>35.67184703499895 139.740277672017 20.479 35.671861764318564 139.74025549571502 20.479 35.67182900221424 139.74022413971392 20.479 35.67181538141715 139.74024609379634 20.479 35.67184703499895 139.740277672017 20.479</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4dc5c077-93f7-475a-9452-e0d38c8decd1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4dc5c077-93f7-475a-9452-e0d38c8decd1_0">
											<gml:posList>35.67181538141715 139.74024609379634 20.479 35.67181538141715 139.74024609379634 8.136 35.67184703499895 139.740277672017 8.136 35.67184703499895 139.740277672017 20.479 35.67181538141715 139.74024609379634 20.479</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0123f3eb-baf9-4ec8-9ebe-8a0bf38d4275">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0123f3eb-baf9-4ec8-9ebe-8a0bf38d4275_0">
											<gml:posList>35.67184703499895 139.740277672017 20.479 35.67184703499895 139.740277672017 8.136 35.671861764318564 139.74025549571502 8.136 35.671861764318564 139.74025549571502 20.479 35.67184703499895 139.740277672017 20.479</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_95930e6d-930f-4a09-9376-3bd56dcd5069_BuildingInstallation_1031">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aae56231-89b5-468e-a7e2-ef21521c986e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671761763487936 139.7400774878093 20.074 35.67176843487772 139.74006743882563 20.074 35.67177674293969 139.74007572504615 20.074 35.67177011657506 139.74008571874555 20.074 35.67177357149895 139.74008916122006 20.074 35.6717710325809 139.74009297519848 20.074 35.67176181343286 139.74008378422758 20.074 35.67174401405793 139.74011060361116 20.074 35.67174173508324 139.74011253938926 20.074 35.671740167251734 139.7401132592313 20.074 35.67173787776672 139.74011326189333 20.074 35.671735623096524 139.74011166278024 20.074 35.6717343782367 139.7401104159793 20.074 35.671738024542954 139.7401049216556 20.074 35.671738222998755 139.74010512026086 20.074 35.671739052423554 139.74010532917885 20.074 35.67173983628369 139.74010489745592 20.074 35.67175951733479 139.74007524799273 20.074 35.671761763487936 139.7400774878093 20.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a922c21-2fc7-477f-b2bc-c03dd8f34250">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671738024542954 139.7401049216556 20.479 35.6717343782367 139.7401104159793 20.479 35.671731672016655 139.74010770170037 20.479 35.67173532732796 139.74010219631978 20.479 35.671738024542954 139.7401049216556 20.479</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1fc0d8dc-2cbd-418b-b403-326de663ccc4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671732388513504 139.74011340083322 20.479 35.671728571142836 139.74011914942326 20.479 35.67172586493155 139.74011644619065 20.479 35.67172968230208 139.7401106976007 20.479 35.671732388513504 139.74011340083322 20.479</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9eb74fce-5517-49fc-87f4-a77e88e0a3b8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67176454605614 139.74010895590914 20.074 35.671749133028705 139.74013282311242 20.074 35.671745898488126 139.74013461639703 20.074 35.67174262540461 139.74013319521018 20.074 35.671728571142836 139.74011914942326 20.074 35.671732388513504 139.74011340083322 20.074 35.67174443116002 139.74012543850498 20.074 35.67175902539143 139.74010345015023 20.074 35.67176454605614 139.74010895590914 20.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d9c7c2ab-6433-42b0-860a-06ea12ba1fa7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d9c7c2ab-6433-42b0-860a-06ea12ba1fa7_0">
											<gml:posList>35.671735623096524 139.74011166278024 20.074 35.67173787776672 139.74011326189333 20.074 35.67173787776672 139.74011326189333 21.219 35.671735623096524 139.74011166278024 21.219 35.671735623096524 139.74011166278024 20.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f47e69e-10c4-44da-b6f6-683e74c912a2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f47e69e-10c4-44da-b6f6-683e74c912a2_0">
											<gml:posList>35.67173787776672 139.74011326189333 20.074 35.671740167251734 139.7401132592313 20.074 35.671740167251734 139.7401132592313 21.219 35.67173787776672 139.74011326189333 21.219 35.67173787776672 139.74011326189333 20.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-69ce4aef-c184-460f-bc77-0f642b2b3b2e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-69ce4aef-c184-460f-bc77-0f642b2b3b2e_0">
											<gml:posList>35.67177674293969 139.74007572504615 20.074 35.67176843487772 139.74006743882563 20.074 35.67176843487772 139.74006743882563 21.219 35.67177674293969 139.74007572504615 21.219 35.67177674293969 139.74007572504615 20.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b1ca3c9c-b5ad-476c-b0e8-369598e531ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b1ca3c9c-b5ad-476c-b0e8-369598e531ce_0">
											<gml:posList>35.67176843487772 139.74006743882563 20.074 35.671761763487936 139.7400774878093 20.074 35.671761763487936 139.7400774878093 21.219 35.67176843487772 139.74006743882563 21.219 35.67176843487772 139.74006743882563 20.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77dc7c1b-873b-4a44-8f48-c84bdbd98c06">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77dc7c1b-873b-4a44-8f48-c84bdbd98c06_0">
											<gml:posList>35.671761763487936 139.7400774878093 20.074 35.67175951733479 139.74007524799273 20.074 35.67175951733479 139.74007524799273 21.219 35.671761763487936 139.7400774878093 21.219 35.671761763487936 139.7400774878093 20.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53698eac-02fa-41ce-a0a0-96af1143e000">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-53698eac-02fa-41ce-a0a0-96af1143e000_0">
											<gml:posList>35.67177011657506 139.74008571874555 20.074 35.67177674293969 139.74007572504615 20.074 35.67177674293969 139.74007572504615 21.219 35.67177011657506 139.74008571874555 21.219 35.67177011657506 139.74008571874555 20.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fd510ece-54aa-42fe-a4f7-0a8fddaaa880">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fd510ece-54aa-42fe-a4f7-0a8fddaaa880_0">
											<gml:posList>35.67177357149895 139.74008916122006 20.074 35.67177011657506 139.74008571874555 20.074 35.67177011657506 139.74008571874555 21.219 35.67177357149895 139.74008916122006 21.219 35.67177357149895 139.74008916122006 20.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-217a55df-f8a4-4801-8571-54f7daf4d9dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-217a55df-f8a4-4801-8571-54f7daf4d9dc_0">
											<gml:posList>35.67176181343286 139.74008378422758 20.074 35.6717710325809 139.74009297519848 20.074 35.6717710325809 139.74009297519848 21.219 35.67176181343286 139.74008378422758 21.219 35.67176181343286 139.74008378422758 20.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9c74aa9-77ff-4c0f-b546-e726a51828b5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b9c74aa9-77ff-4c0f-b546-e726a51828b5_0">
											<gml:posList>35.67175951733479 139.74007524799273 20.074 35.67173983628369 139.74010489745592 20.074 35.67173983628369 139.74010489745592 21.219 35.67175951733479 139.74007524799273 21.219 35.67175951733479 139.74007524799273 20.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-786be622-cae2-424e-854c-fc2075bd6523">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-786be622-cae2-424e-854c-fc2075bd6523_0">
											<gml:posList>35.67173983628369 139.74010489745592 21.219 35.671739052423554 139.74010532917885 21.219 35.671738222998755 139.74010512026086 21.219 35.67173532732796 139.74010219631978 21.219 35.671731672016655 139.74010770170037 21.219 35.671735623096524 139.74011166278024 21.219 35.67173787776672 139.74011326189333 21.219 35.671740167251734 139.7401132592313 21.219 35.67174173508324 139.74011253938926 21.219 35.67174401405793 139.74011060361116 21.219 35.67176181343286 139.74008378422758 21.219 35.6717710325809 139.74009297519848 21.219 35.67177357149895 139.74008916122006 21.219 35.67177011657506 139.74008571874555 21.219 35.67177674293969 139.74007572504615 21.219 35.67176843487772 139.74006743882563 21.219 35.671761763487936 139.7400774878093 21.219 35.67175951733479 139.74007524799273 21.219 35.67173983628369 139.74010489745592 21.219</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-617c53c8-2d2e-492a-a2e5-822f8cfdcc63">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-617c53c8-2d2e-492a-a2e5-822f8cfdcc63_0">
											<gml:posList>35.6717710325809 139.74009297519848 20.074 35.67177357149895 139.74008916122006 20.074 35.67177357149895 139.74008916122006 21.219 35.6717710325809 139.74009297519848 21.219 35.6717710325809 139.74009297519848 20.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8bbbf725-7390-4ae2-af98-d26cc51bf042">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8bbbf725-7390-4ae2-af98-d26cc51bf042_0">
											<gml:posList>35.67176181343286 139.74008378422758 20.074 35.67176181343286 139.74008378422758 21.219 35.67174401405793 139.74011060361116 21.219 35.67174401405793 139.74011060361116 20.074 35.67176181343286 139.74008378422758 20.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba4fd634-e467-4f2c-b56e-92971157680d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba4fd634-e467-4f2c-b56e-92971157680d_0">
											<gml:posList>35.671738024542954 139.7401049216556 20.479 35.67173532732796 139.74010219631978 20.479 35.67173532732796 139.74010219631978 21.219 35.671738222998755 139.74010512026086 21.219 35.671738222998755 139.74010512026086 20.074 35.671738024542954 139.7401049216556 20.074 35.671738024542954 139.7401049216556 20.479</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab689ac9-cff9-4492-83f9-eb5539bc770d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ab689ac9-cff9-4492-83f9-eb5539bc770d_0">
											<gml:posList>35.67173532732796 139.74010219631978 20.479 35.671731672016655 139.74010770170037 20.479 35.671731672016655 139.74010770170037 21.219 35.67173532732796 139.74010219631978 21.219 35.67173532732796 139.74010219631978 20.479</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b71b55d3-366b-4b05-be5e-af34d05523b9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b71b55d3-366b-4b05-be5e-af34d05523b9_0">
											<gml:posList>35.67173983628369 139.74010489745592 20.074 35.671739052423554 139.74010532917885 20.074 35.671739052423554 139.74010532917885 21.219 35.67173983628369 139.74010489745592 21.219 35.67173983628369 139.74010489745592 20.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1baedd7-7da3-46f8-a616-20286a8181ed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d1baedd7-7da3-46f8-a616-20286a8181ed_0">
											<gml:posList>35.671739052423554 139.74010532917885 20.074 35.671738222998755 139.74010512026086 20.074 35.671738222998755 139.74010512026086 21.219 35.671739052423554 139.74010532917885 21.219 35.671739052423554 139.74010532917885 20.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0fe8717e-b1ef-41a4-981c-2bafc011c5d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0fe8717e-b1ef-41a4-981c-2bafc011c5d6_0">
											<gml:posList>35.67175902539143 139.74010345015023 20.074 35.67175902539143 139.74010345015023 21.219 35.67176454605614 139.74010895590914 21.219 35.67176454605614 139.74010895590914 20.074 35.67175902539143 139.74010345015023 20.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27b6b76f-3e27-45f9-820d-fe82a76098a7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-27b6b76f-3e27-45f9-820d-fe82a76098a7_0">
											<gml:posList>35.6717343782367 139.7401104159793 20.479 35.671738024542954 139.7401049216556 20.479 35.671738024542954 139.7401049216556 20.074 35.6717343782367 139.7401104159793 20.074 35.6717343782367 139.7401104159793 20.479</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ee4b879c-1122-46b4-8e09-50d0df7480d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ee4b879c-1122-46b4-8e09-50d0df7480d1_0">
											<gml:posList>35.671735623096524 139.74011166278024 20.074 35.671735623096524 139.74011166278024 21.219 35.671731672016655 139.74010770170037 21.219 35.671731672016655 139.74010770170037 20.479 35.6717343782367 139.7401104159793 20.479 35.6717343782367 139.7401104159793 20.074 35.671735623096524 139.74011166278024 20.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25df0620-ce77-47e1-9cf8-22d79af13ba0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-25df0620-ce77-47e1-9cf8-22d79af13ba0_0">
											<gml:posList>35.67174401405793 139.74011060361116 20.074 35.67174401405793 139.74011060361116 21.219 35.67174173508324 139.74011253938926 21.219 35.67174173508324 139.74011253938926 20.074 35.67174401405793 139.74011060361116 20.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9c3bfce2-24e9-43ef-a534-829187cac51d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9c3bfce2-24e9-43ef-a534-829187cac51d_0">
											<gml:posList>35.671740167251734 139.7401132592313 20.074 35.67174173508324 139.74011253938926 20.074 35.67174173508324 139.74011253938926 21.219 35.671740167251734 139.7401132592313 21.219 35.671740167251734 139.7401132592313 20.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-873e5986-55ca-4343-97a5-9716d172bfa8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-873e5986-55ca-4343-97a5-9716d172bfa8_0">
											<gml:posList>35.67172968230208 139.7401106976007 20.479 35.67172586493155 139.74011644619065 20.479 35.67172586493155 139.74011644619065 21.219 35.67172968230208 139.7401106976007 21.219 35.67172968230208 139.7401106976007 20.479</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e5558b6-2133-413d-90d8-ab53d864a593">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e5558b6-2133-413d-90d8-ab53d864a593_0">
											<gml:posList>35.67175902539143 139.74010345015023 20.074 35.67174443116002 139.74012543850498 20.074 35.67174443116002 139.74012543850498 21.219 35.67175902539143 139.74010345015023 21.219 35.67175902539143 139.74010345015023 20.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-079fe5b7-0d1f-4c22-9da1-7c4c8231460c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-079fe5b7-0d1f-4c22-9da1-7c4c8231460c_0">
											<gml:posList>35.671728571142836 139.74011914942326 20.074 35.671728571142836 139.74011914942326 20.479 35.671732388513504 139.74011340083322 20.479 35.671732388513504 139.74011340083322 20.074 35.671728571142836 139.74011914942326 20.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-49dde1af-3b6b-4ae3-889a-e3a224814098">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-49dde1af-3b6b-4ae3-889a-e3a224814098_0">
											<gml:posList>35.671732388513504 139.74011340083322 20.479 35.67172968230208 139.7401106976007 20.479 35.67172968230208 139.7401106976007 21.219 35.67174443116002 139.74012543850498 21.219 35.67174443116002 139.74012543850498 20.074 35.671732388513504 139.74011340083322 20.074 35.671732388513504 139.74011340083322 20.479</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-54371c11-193f-4d6a-b745-8a03e06a0c3c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-54371c11-193f-4d6a-b745-8a03e06a0c3c_0">
											<gml:posList>35.67174443116002 139.74012543850498 21.219 35.67172968230208 139.7401106976007 21.219 35.67172586493155 139.74011644619065 21.219 35.67174262540461 139.74013319521018 21.219 35.671745898488126 139.74013461639703 21.219 35.671749133028705 139.74013282311242 21.219 35.67176454605614 139.74010895590914 21.219 35.67175902539143 139.74010345015023 21.219 35.67174443116002 139.74012543850498 21.219</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f83f7556-bdb7-4ce1-b08e-7d843e689e9d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f83f7556-bdb7-4ce1-b08e-7d843e689e9d_0">
											<gml:posList>35.67176454605614 139.74010895590914 20.074 35.67176454605614 139.74010895590914 21.219 35.671749133028705 139.74013282311242 21.219 35.671749133028705 139.74013282311242 20.074 35.67176454605614 139.74010895590914 20.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bcbff334-3dfc-433c-a096-309b1e39b6d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bcbff334-3dfc-433c-a096-309b1e39b6d4_0">
											<gml:posList>35.67174262540461 139.74013319521018 20.074 35.67174262540461 139.74013319521018 21.219 35.67172586493155 139.74011644619065 21.219 35.67172586493155 139.74011644619065 20.479 35.671728571142836 139.74011914942326 20.479 35.671728571142836 139.74011914942326 20.074 35.67174262540461 139.74013319521018 20.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fefbce5b-3033-429d-9478-19acafce4f5b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fefbce5b-3033-429d-9478-19acafce4f5b_0">
											<gml:posList>35.671745898488126 139.74013461639703 20.074 35.671749133028705 139.74013282311242 20.074 35.671749133028705 139.74013282311242 21.219 35.671745898488126 139.74013461639703 21.219 35.671745898488126 139.74013461639703 20.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ee87a64f-f2b1-4ab9-bef3-9915f8f0b479">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ee87a64f-f2b1-4ab9-bef3-9915f8f0b479_0">
											<gml:posList>35.67174262540461 139.74013319521018 20.074 35.671745898488126 139.74013461639703 20.074 35.671745898488126 139.74013461639703 21.219 35.67174262540461 139.74013319521018 21.219 35.67174262540461 139.74013319521018 20.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_95930e6d-930f-4a09-9376-3bd56dcd5069_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44037f06-3eb5-4770-902b-d3a164a241ab">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67176565186861 139.7401634688555 20.074 35.671782622976195 139.74013792078125 20.074 35.67179842723098 139.74015368779396 20.074 35.67178146513382 139.74017923585944 20.074 35.67176565186861 139.7401634688555 20.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a155c92-f18b-4ed4-ad06-3840ba143225">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2a155c92-f18b-4ed4-ad06-3840ba143225_0">
											<gml:posList>35.671782622976195 139.74013792078125 20.074 35.671782622976195 139.74013792078125 22.431 35.67179842723098 139.74015368779396 22.431 35.67179842723098 139.74015368779396 20.074 35.671782622976195 139.74013792078125 20.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-50d5b386-43fe-42ca-a82c-1e53eff28099">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-50d5b386-43fe-42ca-a82c-1e53eff28099_0">
											<gml:posList>35.67176565186861 139.7401634688555 20.074 35.67176565186861 139.7401634688555 22.431 35.671782622976195 139.74013792078125 22.431 35.671782622976195 139.74013792078125 20.074 35.67176565186861 139.7401634688555 20.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4ab14bfa-93cf-4521-be82-19b92488cb13">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4ab14bfa-93cf-4521-be82-19b92488cb13_0">
											<gml:posList>35.67179842723098 139.74015368779396 22.431 35.671782622976195 139.74013792078125 22.431 35.67176565186861 139.7401634688555 22.431 35.67178146513382 139.74017923585944 22.431 35.67179842723098 139.74015368779396 22.431</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d3d9c77-c3fc-4785-8a6e-b49d6a84bed5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d3d9c77-c3fc-4785-8a6e-b49d6a84bed5_0">
											<gml:posList>35.67179842723098 139.74015368779396 20.074 35.67179842723098 139.74015368779396 22.431 35.67178146513382 139.74017923585944 22.431 35.67178146513382 139.74017923585944 20.074 35.67179842723098 139.74015368779396 20.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3aa7786c-0de3-4ed1-b45b-ffd9c37ec630">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3aa7786c-0de3-4ed1-b45b-ffd9c37ec630_0">
											<gml:posList>35.67178146513382 139.74017923585944 20.074 35.67178146513382 139.74017923585944 22.431 35.67176565186861 139.7401634688555 22.431 35.67176565186861 139.7401634688555 20.074 35.67178146513382 139.74017923585944 20.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_95930e6d-930f-4a09-9376-3bd56dcd5069_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b392b32-d803-4d03-bf8b-e010611f371a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671742198907154 139.74015280314953 20.074 35.671732879886015 139.74014267334317 20.074 35.67173751700194 139.7401362720607 20.074 35.67174683601505 139.74014639082043 20.074 35.671742198907154 139.74015280314953 20.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43a631f2-b201-46dc-931e-ff1f25a43204">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-43a631f2-b201-46dc-931e-ff1f25a43204_0">
											<gml:posList>35.671732879886015 139.74014267334317 20.074 35.671732879886015 139.74014267334317 21.238 35.67173751700194 139.7401362720607 21.238 35.67173751700194 139.7401362720607 20.074 35.671732879886015 139.74014267334317 20.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82046815-da45-4bf9-b0b4-e29f2241746b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-82046815-da45-4bf9-b0b4-e29f2241746b_0">
											<gml:posList>35.67173751700194 139.7401362720607 20.074 35.67173751700194 139.7401362720607 21.238 35.67174683601505 139.74014639082043 21.238 35.67174683601505 139.74014639082043 20.074 35.67173751700194 139.7401362720607 20.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e4f8c9dc-0ef2-4a35-9de3-5b2f2e3a3851">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e4f8c9dc-0ef2-4a35-9de3-5b2f2e3a3851_0">
											<gml:posList>35.671742198907154 139.74015280314953 21.238 35.67174683601505 139.74014639082043 21.238 35.67173751700194 139.7401362720607 21.238 35.671732879886015 139.74014267334317 21.238 35.671742198907154 139.74015280314953 21.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-39e7b304-e5bd-430a-bb6f-766116c2e025">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-39e7b304-e5bd-430a-bb6f-766116c2e025_0">
											<gml:posList>35.671742198907154 139.74015280314953 20.074 35.671742198907154 139.74015280314953 21.238 35.671732879886015 139.74014267334317 21.238 35.671732879886015 139.74014267334317 20.074 35.671742198907154 139.74015280314953 20.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a08678dc-6536-4b8f-80cc-03bbf19874ba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a08678dc-6536-4b8f-80cc-03bbf19874ba_0">
											<gml:posList>35.67174683601505 139.74014639082043 20.074 35.67174683601505 139.74014639082043 21.238 35.671742198907154 139.74015280314953 21.238 35.671742198907154 139.74015280314953 20.074 35.67174683601505 139.74014639082043 20.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-f371d909-9bac-42e1-8883-82e39c652bd6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f371d909-9bac-42e1-8883-82e39c652bd6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f371d909-9bac-42e1-8883-82e39c652bd6">
											<gml:posList>35.67192733668533 139.74020562208958 8.136 35.67186656477825 139.7402971574049 8.136 35.67184704401268 139.74027767200653 8.136 35.671861773332274 139.74025549570456 8.136 35.671829011227956 139.74022413970346 8.136 35.67181538140861 139.7402460827499 8.136 35.671709361250855 139.7401403256952 8.136 35.6717701330404 139.74004879044102 8.136 35.67192733668533 139.74020562208958 8.136</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-abc76644-2684-485f-a705-62fa4d03bffa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-abc76644-2684-485f-a705-62fa4d03bffa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-abc76644-2684-485f-a705-62fa4d03bffa">
											<gml:posList>35.671709361250855 139.7401403256952 20.479 35.671714976268724 139.74013963428885 20.479 35.67177071525842 139.74005568274902 20.479 35.6717701330404 139.74004879044102 20.479 35.671709361250855 139.7401403256952 20.479</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-16abed3d-3358-42a5-be1d-4ee499bc5ccc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16abed3d-3358-42a5-be1d-4ee499bc5ccc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16abed3d-3358-42a5-be1d-4ee499bc5ccc">
											<gml:posList>35.671709361250855 139.7401403256952 20.479 35.67178314147379 139.7402139197732 20.479 35.67178566238533 139.74021012791184 20.479 35.67178256829563 139.7402070495454 20.479 35.671714976268724 139.74013963428885 20.479 35.671709361250855 139.7401403256952 20.479</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9c263a33-3f82-4b55-a090-b11479eba1f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c263a33-3f82-4b55-a090-b11479eba1f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c263a33-3f82-4b55-a090-b11479eba1f6">
											<gml:posList>35.6718219644735 139.74021504560574 23.28 35.67179816789282 139.7401913012739 23.28 35.67178314147379 139.7402139197732 23.28 35.67180693805008 139.74023766410735 23.28 35.6718219644735 139.74021504560574 23.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3c51eca9-9ddd-4452-a730-5d0446cdc299">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c51eca9-9ddd-4452-a730-5d0446cdc299">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c51eca9-9ddd-4452-a730-5d0446cdc299">
											<gml:posList>35.67185265902268 139.74027696956216 20.074 35.67186599159629 139.7402902761229 20.074 35.67192173070662 139.74020634662207 20.074 35.67177071525842 139.74005568274902 20.074 35.671714976268724 139.74013963428885 20.074 35.67178256829563 139.7402070495454 20.074 35.67178566238533 139.74021012791184 20.074 35.67179816789282 139.7401913012739 20.074 35.6718219644735 139.74021504560574 20.074 35.67180945896236 139.7402338722456 20.074 35.671814709004494 139.7402391132162 20.074 35.67182828480006 139.74021724755673 20.074 35.671867433350975 139.740254715881 20.074 35.67185265902268 139.74027696956216 20.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7c7a135c-a5b3-4db2-83fc-e86d474b0e84">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c7a135c-a5b3-4db2-83fc-e86d474b0e84">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c7a135c-a5b3-4db2-83fc-e86d474b0e84">
											<gml:posList>35.6717701330404 139.74004879044102 20.479 35.67177071525842 139.74005568274902 20.479 35.67192173070662 139.74020634662207 20.479 35.67192733668533 139.74020562208958 20.479 35.6717701330404 139.74004879044102 20.479</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-29401b49-2065-42eb-97bf-ce23d0fa4cb3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-29401b49-2065-42eb-97bf-ce23d0fa4cb3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-29401b49-2065-42eb-97bf-ce23d0fa4cb3">
											<gml:posList>35.671829011227956 139.74022413970346 20.479 35.67182828480006 139.74021724755673 20.479 35.671814709004494 139.7402391132162 20.479 35.67181538140861 139.7402460827499 20.479 35.671829011227956 139.74022413970346 20.479</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dab8ce1d-f2d4-421f-9c81-8d07898c6c43">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dab8ce1d-f2d4-421f-9c81-8d07898c6c43">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dab8ce1d-f2d4-421f-9c81-8d07898c6c43">
											<gml:posList>35.671861773332274 139.74025549570456 20.479 35.671867433350975 139.740254715881 20.479 35.67182828480006 139.74021724755673 20.479 35.671829011227956 139.74022413970346 20.479 35.671861773332274 139.74025549570456 20.479</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5d24831b-6207-466c-a755-c5b774b69660">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d24831b-6207-466c-a755-c5b774b69660">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d24831b-6207-466c-a755-c5b774b69660">
											<gml:posList>35.671814709004494 139.7402391132162 20.479 35.67180945896236 139.7402338722456 20.479 35.67180693805008 139.74023766410735 20.479 35.67181538140861 139.7402460827499 20.479 35.671814709004494 139.7402391132162 20.479</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b589a214-bf86-4b8b-9a17-8a9ee1cba561">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b589a214-bf86-4b8b-9a17-8a9ee1cba561">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b589a214-bf86-4b8b-9a17-8a9ee1cba561">
											<gml:posList>35.67192733668533 139.74020562208958 20.479 35.67192173070662 139.74020634662207 20.479 35.67186599159629 139.7402902761229 20.479 35.67186656477825 139.7402971574049 20.479 35.67192733668533 139.74020562208958 20.479</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9e66c031-a38a-4fe4-9975-76b5bb14cccf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e66c031-a38a-4fe4-9975-76b5bb14cccf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e66c031-a38a-4fe4-9975-76b5bb14cccf">
											<gml:posList>35.671861773332274 139.74025549570456 20.479 35.67184704401268 139.74027767200653 20.479 35.67185265902268 139.74027696956216 20.479 35.671867433350975 139.740254715881 20.479 35.671861773332274 139.74025549570456 20.479</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-29aa493c-c358-4d23-8654-95c35432f39a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-29aa493c-c358-4d23-8654-95c35432f39a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-29aa493c-c358-4d23-8654-95c35432f39a">
											<gml:posList>35.67186656477825 139.7402971574049 20.479 35.67186599159629 139.7402902761229 20.479 35.67185265902268 139.74027696956216 20.479 35.67184704401268 139.74027767200653 20.479 35.67186656477825 139.7402971574049 20.479</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7d98b951-4844-4369-9096-573bf63c5044">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d98b951-4844-4369-9096-573bf63c5044">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d98b951-4844-4369-9096-573bf63c5044">
											<gml:posList>35.67178256829563 139.7402070495454 20.479 35.67178256829563 139.7402070495454 20.074 35.671714976268724 139.74013963428885 20.074 35.671714976268724 139.74013963428885 20.479 35.67178256829563 139.7402070495454 20.479</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-331c3cfe-3147-4dd0-bc0b-4e35eaaeb7c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-331c3cfe-3147-4dd0-bc0b-4e35eaaeb7c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-331c3cfe-3147-4dd0-bc0b-4e35eaaeb7c1">
											<gml:posList>35.67178566238533 139.74021012791184 20.479 35.67178566238533 139.74021012791184 20.074 35.67178256829563 139.7402070495454 20.074 35.67178256829563 139.7402070495454 20.479 35.67178566238533 139.74021012791184 20.479</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-30c9b296-b319-40c1-af31-52e57fcf541e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-30c9b296-b319-40c1-af31-52e57fcf541e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-30c9b296-b319-40c1-af31-52e57fcf541e">
											<gml:posList>35.67185265902268 139.74027696956216 20.479 35.67185265902268 139.74027696956216 20.074 35.671867433350975 139.740254715881 20.074 35.671867433350975 139.740254715881 20.479 35.67185265902268 139.74027696956216 20.479</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8873b940-f8a3-4c9a-b4f6-bb913520d09a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8873b940-f8a3-4c9a-b4f6-bb913520d09a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8873b940-f8a3-4c9a-b4f6-bb913520d09a">
											<gml:posList>35.6717701330404 139.74004879044102 8.136 35.671709361250855 139.7401403256952 8.136 35.671709361250855 139.7401403256952 20.479 35.6717701330404 139.74004879044102 20.479 35.6717701330404 139.74004879044102 8.136</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7579a0f6-7efd-449a-a0dd-64bc85cb62d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7579a0f6-7efd-449a-a0dd-64bc85cb62d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7579a0f6-7efd-449a-a0dd-64bc85cb62d5">
											<gml:posList>35.671714976268724 139.74013963428885 20.479 35.671714976268724 139.74013963428885 20.074 35.67177071525842 139.74005568274902 20.074 35.67177071525842 139.74005568274902 20.479 35.671714976268724 139.74013963428885 20.479</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dde4b903-d1c5-4c39-afd6-77b613d30923">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dde4b903-d1c5-4c39-afd6-77b613d30923">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dde4b903-d1c5-4c39-afd6-77b613d30923">
											<gml:posList>35.67192733668533 139.74020562208958 8.136 35.6717701330404 139.74004879044102 8.136 35.6717701330404 139.74004879044102 20.479 35.67192733668533 139.74020562208958 20.479 35.67192733668533 139.74020562208958 8.136</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ce6d5357-dc41-4dbc-b6df-7b47adbaa773">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce6d5357-dc41-4dbc-b6df-7b47adbaa773">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce6d5357-dc41-4dbc-b6df-7b47adbaa773">
											<gml:posList>35.67177071525842 139.74005568274902 20.479 35.67177071525842 139.74005568274902 20.074 35.67192173070662 139.74020634662207 20.074 35.67192173070662 139.74020634662207 20.479 35.67177071525842 139.74005568274902 20.479</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-115ca745-3fcc-428c-8faa-478c15410143">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-115ca745-3fcc-428c-8faa-478c15410143">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-115ca745-3fcc-428c-8faa-478c15410143">
											<gml:posList>35.67180693805008 139.74023766410735 20.479 35.67180693805008 139.74023766410735 23.28 35.67178314147379 139.7402139197732 23.28 35.67178314147379 139.7402139197732 20.479 35.671709361250855 139.7401403256952 20.479 35.671709361250855 139.7401403256952 8.136 35.67181538140861 139.7402460827499 8.136 35.67181538140861 139.7402460827499 20.479 35.67180693805008 139.74023766410735 20.479</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-25c5f465-7683-4b29-bec4-6a64a088ea33">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25c5f465-7683-4b29-bec4-6a64a088ea33">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25c5f465-7683-4b29-bec4-6a64a088ea33">
											<gml:posList>35.67178566238533 139.74021012791184 20.479 35.67178314147379 139.7402139197732 20.479 35.67178314147379 139.7402139197732 23.28 35.67179816789282 139.7401913012739 23.28 35.67179816789282 139.7401913012739 20.074 35.67178566238533 139.74021012791184 20.074 35.67178566238533 139.74021012791184 20.479</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d7be5b60-1059-4c22-9e7e-a62268dd9220">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7be5b60-1059-4c22-9e7e-a62268dd9220">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7be5b60-1059-4c22-9e7e-a62268dd9220">
											<gml:posList>35.67179816789282 139.7401913012739 23.28 35.6718219644735 139.74021504560574 23.28 35.6718219644735 139.74021504560574 20.074 35.67179816789282 139.7401913012739 20.074 35.67179816789282 139.7401913012739 23.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9f803c13-fc86-418c-a46c-18e5ffe1f1c3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f803c13-fc86-418c-a46c-18e5ffe1f1c3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f803c13-fc86-418c-a46c-18e5ffe1f1c3">
											<gml:posList>35.67180693805008 139.74023766410735 23.28 35.67180693805008 139.74023766410735 20.479 35.67180945896236 139.7402338722456 20.479 35.67180945896236 139.7402338722456 20.074 35.6718219644735 139.74021504560574 20.074 35.6718219644735 139.74021504560574 23.28 35.67180693805008 139.74023766410735 23.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ccb85046-dd0a-460a-8888-90f359047022">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ccb85046-dd0a-460a-8888-90f359047022">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ccb85046-dd0a-460a-8888-90f359047022">
											<gml:posList>35.67182828480006 139.74021724755673 20.479 35.67182828480006 139.74021724755673 20.074 35.671814709004494 139.7402391132162 20.074 35.671814709004494 139.7402391132162 20.479 35.67182828480006 139.74021724755673 20.479</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2b9af7ac-ddd2-4707-b2bf-e53481942fe2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b9af7ac-ddd2-4707-b2bf-e53481942fe2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b9af7ac-ddd2-4707-b2bf-e53481942fe2">
											<gml:posList>35.67181538140861 139.7402460827499 8.136 35.671829011227956 139.74022413970346 8.136 35.671829011227956 139.74022413970346 20.479 35.67181538140861 139.7402460827499 20.479 35.67181538140861 139.7402460827499 8.136</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2de81598-1e03-44f5-8eb9-f77e72146434">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2de81598-1e03-44f5-8eb9-f77e72146434">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2de81598-1e03-44f5-8eb9-f77e72146434">
											<gml:posList>35.671867433350975 139.740254715881 20.479 35.671867433350975 139.740254715881 20.074 35.67182828480006 139.74021724755673 20.074 35.67182828480006 139.74021724755673 20.479 35.671867433350975 139.740254715881 20.479</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e0e2bf58-f608-416e-9b94-9f48019aa182">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e0e2bf58-f608-416e-9b94-9f48019aa182">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e0e2bf58-f608-416e-9b94-9f48019aa182">
											<gml:posList>35.671814709004494 139.7402391132162 20.479 35.671814709004494 139.7402391132162 20.074 35.67180945896236 139.7402338722456 20.074 35.67180945896236 139.7402338722456 20.479 35.671814709004494 139.7402391132162 20.479</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bff6eda1-c118-4954-98ab-d730ce0c5912">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bff6eda1-c118-4954-98ab-d730ce0c5912">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bff6eda1-c118-4954-98ab-d730ce0c5912">
											<gml:posList>35.671829011227956 139.74022413970346 8.136 35.671861773332274 139.74025549570456 8.136 35.671861773332274 139.74025549570456 20.479 35.671829011227956 139.74022413970346 20.479 35.671829011227956 139.74022413970346 8.136</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cf4dfdcd-5706-4ac4-ba63-26bc7d8ad33a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cf4dfdcd-5706-4ac4-ba63-26bc7d8ad33a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cf4dfdcd-5706-4ac4-ba63-26bc7d8ad33a">
											<gml:posList>35.67192173070662 139.74020634662207 20.479 35.67192173070662 139.74020634662207 20.074 35.67186599159629 139.7402902761229 20.074 35.67186599159629 139.7402902761229 20.479 35.67192173070662 139.74020634662207 20.479</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-effc1bd4-e56e-49d7-9c0c-b71c1af618c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-effc1bd4-e56e-49d7-9c0c-b71c1af618c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-effc1bd4-e56e-49d7-9c0c-b71c1af618c4">
											<gml:posList>35.67186656477825 139.7402971574049 8.136 35.67192733668533 139.74020562208958 8.136 35.67192733668533 139.74020562208958 20.479 35.67186656477825 139.7402971574049 20.479 35.67186656477825 139.7402971574049 8.136</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-56a8370c-c486-44ab-9159-c3f5500613f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56a8370c-c486-44ab-9159-c3f5500613f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56a8370c-c486-44ab-9159-c3f5500613f6">
											<gml:posList>35.671861773332274 139.74025549570456 8.136 35.67184704401268 139.74027767200653 8.136 35.67184704401268 139.74027767200653 20.479 35.671861773332274 139.74025549570456 20.479 35.671861773332274 139.74025549570456 8.136</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-df5bfcbe-602e-43f4-9d5d-187c14cfc060">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df5bfcbe-602e-43f4-9d5d-187c14cfc060">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df5bfcbe-602e-43f4-9d5d-187c14cfc060">
											<gml:posList>35.67186599159629 139.7402902761229 20.479 35.67186599159629 139.7402902761229 20.074 35.67185265902268 139.74027696956216 20.074 35.67185265902268 139.74027696956216 20.479 35.67186599159629 139.7402902761229 20.479</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-061a7429-a882-4819-b616-e7469bd0ead0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-061a7429-a882-4819-b616-e7469bd0ead0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-061a7429-a882-4819-b616-e7469bd0ead0">
											<gml:posList>35.67184704401268 139.74027767200653 8.136 35.67186656477825 139.7402971574049 8.136 35.67186656477825 139.7402971574049 20.479 35.67184704401268 139.74027767200653 20.479 35.67184704401268 139.74027767200653 8.136</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10367</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">252.6849</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>