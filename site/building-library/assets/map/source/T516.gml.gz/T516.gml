<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_95eb99f2-6bec-46f2-b150-c89a21828294">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">26.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>11</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67152235808261 139.74039126358673 0 35.67154501720826 139.7404128220236 0 35.6715743128122 139.74036738726795 0 35.67143189578241 139.74022725202602 0 35.67137391418126 139.74031370217898 0 35.67149623102941 139.7404311603798 0 35.67152235808261 139.74039126358673 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67152235808261 139.74039126358673 9.048 35.67149623102941 139.7404311603798 9.048 35.67137391418126 139.74031370217898 9.048 35.67143189578241 139.74022725202602 9.048 35.6715743128122 139.74036738726795 9.048 35.67154501720826 139.7404128220236 9.048 35.67152235808261 139.74039126358673 9.048</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67152235808261 139.74039126358673 9.048 35.67154501720826 139.7404128220236 9.048 35.67154501720826 139.7404128220236 35.68 35.67152235808261 139.74039126358673 35.68 35.67152235808261 139.74039126358673 9.048</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67154501720826 139.7404128220236 9.048 35.6715743128122 139.74036738726795 9.048 35.6715743128122 139.74036738726795 35.68 35.67154501720826 139.7404128220236 35.68 35.67154501720826 139.7404128220236 9.048</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6715743128122 139.74036738726795 9.048 35.67143189578241 139.74022725202602 9.048 35.67143189578241 139.74022725202602 35.68 35.6715743128122 139.74036738726795 35.68 35.6715743128122 139.74036738726795 9.048</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67143189578241 139.74022725202602 9.048 35.67137391418126 139.74031370217898 9.048 35.67137391418126 139.74031370217898 35.68 35.67143189578241 139.74022725202602 35.68 35.67143189578241 139.74022725202602 9.048</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67137391418126 139.74031370217898 9.048 35.67149623102941 139.7404311603798 9.048 35.67149623102941 139.7404311603798 35.68 35.67137391418126 139.74031370217898 35.68 35.67137391418126 139.74031370217898 9.048</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67149623102941 139.7404311603798 9.048 35.67152235808261 139.74039126358673 9.048 35.67152235808261 139.74039126358673 35.68 35.67149623102941 139.7404311603798 35.68 35.67149623102941 139.7404311603798 9.048</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67152235808261 139.74039126358673 35.68 35.67154501720826 139.7404128220236 35.68 35.6715743128122 139.74036738726795 35.68 35.67143189578241 139.74022725202602 35.68 35.67137391418126 139.74031370217898 35.68 35.67149623102941 139.7404311603798 35.68 35.67152235808261 139.74039126358673 35.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-a4522f86-40e4-4fe9-af9f-61f4ce90d0bb"/>
							<gml:surfaceMember xlink:href="#poly-ca90622d-56e0-4200-9cf3-34f18bdb0ea3"/>
							<gml:surfaceMember xlink:href="#poly-b2f2da9f-f700-4874-af10-599f9514cb18"/>
							<gml:surfaceMember xlink:href="#poly-7e3b608b-c252-4f4b-aee4-420757eef399"/>
							<gml:surfaceMember xlink:href="#poly-b24dcc35-883f-4eb6-b623-1bb8be4fbb0e"/>
							<gml:surfaceMember xlink:href="#poly-3fc528ff-ebc7-4424-9c29-23b37dcb6167"/>
							<gml:surfaceMember xlink:href="#poly-386722b0-f592-4338-99b7-5f81a02d4f56"/>
							<gml:surfaceMember xlink:href="#poly-89fb7a30-008f-491a-9a93-ac4c5683c9c8"/>
							<gml:surfaceMember xlink:href="#poly-62ff6e18-0e3b-4473-883f-037c39b77083"/>
							<gml:surfaceMember xlink:href="#poly-09b11ee9-e42f-4635-b03b-bbe2661b1536"/>
							<gml:surfaceMember xlink:href="#poly-d52df3f8-d573-4bca-837e-3063e8884882"/>
							<gml:surfaceMember xlink:href="#poly-6bc35ac7-5006-46d7-a922-db15aeba02dc"/>
							<gml:surfaceMember xlink:href="#poly-9940877f-e5e0-4585-b396-8cd7542cd3cf"/>
							<gml:surfaceMember xlink:href="#poly-bf6b93df-9665-4e40-ae51-98ceb3feeb45"/>
							<gml:surfaceMember xlink:href="#poly-325f8300-05cb-41ac-8ebc-afb9e6b49962"/>
							<gml:surfaceMember xlink:href="#poly-f3d17439-2092-434a-911f-e7aeeb465018"/>
							<gml:surfaceMember xlink:href="#poly-8777e439-9edf-4909-bb9d-1621b0336119"/>
							<gml:surfaceMember xlink:href="#poly-3a3ffbfd-f0b9-401d-b0e4-2af59609e75b"/>
							<gml:surfaceMember xlink:href="#poly-598451e3-909a-4f29-ad33-6c3895344fe1"/>
							<gml:surfaceMember xlink:href="#poly-691e011b-c370-486a-9653-5dd8372e96fc"/>
							<gml:surfaceMember xlink:href="#poly-9c64348b-7060-4cba-aa8a-b6d3885d3626"/>
							<gml:surfaceMember xlink:href="#poly-55d32fb2-05da-4c75-8645-00f0752a08b0"/>
							<gml:surfaceMember xlink:href="#poly-c9b80324-48fc-44b4-b162-5a637f3f0d95"/>
							<gml:surfaceMember xlink:href="#poly-64ad1de5-150b-44fa-846c-3499f6557486"/>
							<gml:surfaceMember xlink:href="#poly-c5ce1f19-d593-4f22-b593-4665b4986c77"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_95eb99f2-6bec-46f2-b150-c89a21828294_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b7ffc7f2-d466-45c4-8002-c02330bb7c73">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67153714862649 139.74042502638954 9.27 35.671514579401475 139.7404031585475 9.27 35.67152235808259 139.74039126358673 9.27 35.67154501720826 139.7404128220236 9.27 35.67153714862649 139.74042502638954 9.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e6da40f7-9b5e-499b-8b23-6b91731fbb0a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e6da40f7-9b5e-499b-8b23-6b91731fbb0a_0">
											<gml:posList>35.67152235808259 139.74039126358673 39.104 35.67152235808259 139.74039126358673 9.27 35.671514579401475 139.7404031585475 9.27 35.671514579401475 139.7404031585475 39.104 35.67152235808259 139.74039126358673 39.104</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97d19f86-eee3-4b64-810a-b2397e610a58">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-97d19f86-eee3-4b64-810a-b2397e610a58_0">
											<gml:posList>35.67154501720826 139.7404128220236 39.104 35.67154501720826 139.7404128220236 9.27 35.67152235808259 139.74039126358673 9.27 35.67152235808259 139.74039126358673 39.104 35.67154501720826 139.7404128220236 39.104</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e25bf47-30b2-400a-8742-5032d50afb5c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4e25bf47-30b2-400a-8742-5032d50afb5c_0">
											<gml:posList>35.67154501720826 139.7404128220236 39.104 35.67152235808259 139.74039126358673 39.104 35.671514579401475 139.7404031585475 39.104 35.67153714862649 139.74042502638954 39.104 35.67154501720826 139.7404128220236 39.104</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94e352e9-0ac5-4910-b79c-bf33e117f1ad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-94e352e9-0ac5-4910-b79c-bf33e117f1ad_0">
											<gml:posList>35.671514579401475 139.7404031585475 39.104 35.671514579401475 139.7404031585475 9.27 35.67153714862649 139.74042502638954 9.27 35.67153714862649 139.74042502638954 39.104 35.671514579401475 139.7404031585475 39.104</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29731a3b-0fb2-4316-877a-353c5b9071e6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29731a3b-0fb2-4316-877a-353c5b9071e6_0">
											<gml:posList>35.67153714862649 139.74042502638954 39.104 35.67153714862649 139.74042502638954 9.27 35.67154501720826 139.7404128220236 9.27 35.67154501720826 139.7404128220236 39.104 35.67153714862649 139.74042502638954 39.104</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-a4522f86-40e4-4fe9-af9f-61f4ce90d0bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4522f86-40e4-4fe9-af9f-61f4ce90d0bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4522f86-40e4-4fe9-af9f-61f4ce90d0bb">
											<gml:posList>35.67137391418126 139.74031370217895 9.048 35.671431895782405 139.740227252026 9.048 35.67157431281217 139.74036738726792 9.048 35.67154501720826 139.7404128220236 9.048 35.67152235808259 139.74039126358673 9.048 35.67149623102941 139.7404311603798 9.048 35.67137391418126 139.74031370217895 9.048</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ca90622d-56e0-4200-9cf3-34f18bdb0ea3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca90622d-56e0-4200-9cf3-34f18bdb0ea3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca90622d-56e0-4200-9cf3-34f18bdb0ea3">
											<gml:posList>35.671431895782405 139.740227252026 26.843 35.67137391418126 139.74031370217895 26.843 35.67144453504012 139.74038152250168 40.872 35.671431895782405 139.740227252026 26.843</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b2f2da9f-f700-4874-af10-599f9514cb18">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b2f2da9f-f700-4874-af10-599f9514cb18">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b2f2da9f-f700-4874-af10-599f9514cb18">
											<gml:posList>35.671431895782405 139.740227252026 26.843 35.67144453504012 139.74038152250168 40.872 35.671501038601164 139.74029528391853 40.872 35.671431895782405 139.740227252026 26.843</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7e3b608b-c252-4f4b-aee4-420757eef399">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e3b608b-c252-4f4b-aee4-420757eef399">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e3b608b-c252-4f4b-aee4-420757eef399">
											<gml:posList>35.67157431281217 139.74036738726792 40.872 35.671501038601164 139.74029528391853 40.872 35.67150176598901 139.7403034242815 40.872 35.67151194120659 139.74031343157347 40.872 35.67156769744038 139.7403683007455 40.872 35.67157431281217 139.74036738726792 40.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b24dcc35-883f-4eb6-b623-1bb8be4fbb0e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b24dcc35-883f-4eb6-b623-1bb8be4fbb0e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b24dcc35-883f-4eb6-b623-1bb8be4fbb0e">
											<gml:posList>35.67144453504012 139.74038152250168 40.872 35.67145120446037 139.74038056477835 40.872 35.67150176598901 139.7403034242815 40.872 35.671501038601164 139.74029528391853 40.872 35.67144453504012 139.74038152250168 40.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3fc528ff-ebc7-4424-9c29-23b37dcb6167">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3fc528ff-ebc7-4424-9c29-23b37dcb6167">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3fc528ff-ebc7-4424-9c29-23b37dcb6167">
											<gml:posList>35.67150176598901 139.7403034242815 40.872 35.67145120446037 139.74038056477835 40.872 35.67146104573763 139.7403900201405 40.872 35.67151194120659 139.74031343157347 40.872 35.67150176598901 139.7403034242815 40.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-386722b0-f592-4338-99b7-5f81a02d4f56">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-386722b0-f592-4338-99b7-5f81a02d4f56">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-386722b0-f592-4338-99b7-5f81a02d4f56">
											<gml:posList>35.67146104573763 139.7403900201405 40.519 35.67149546764645 139.7404230863364 40.519 35.67152157666952 139.74038318956198 40.519 35.67154420874695 139.7404047369813 40.519 35.67156769744038 139.7403683007455 40.519 35.67151194120659 139.74031343157347 40.519 35.67146104573763 139.7403900201405 40.519</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-89fb7a30-008f-491a-9a93-ac4c5683c9c8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-89fb7a30-008f-491a-9a93-ac4c5683c9c8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-89fb7a30-008f-491a-9a93-ac4c5683c9c8">
											<gml:posList>35.67157431281217 139.74036738726792 40.872 35.67156769744038 139.7403683007455 40.872 35.67154420874695 139.7404047369813 40.872 35.67154501720826 139.7404128220236 40.872 35.67157431281217 139.74036738726792 40.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-62ff6e18-0e3b-4473-883f-037c39b77083">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-62ff6e18-0e3b-4473-883f-037c39b77083">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-62ff6e18-0e3b-4473-883f-037c39b77083">
											<gml:posList>35.67152235808259 139.74039126358673 40.872 35.67154501720826 139.7404128220236 40.872 35.67154420874695 139.7404047369813 40.872 35.67152157666952 139.74038318956198 40.872 35.67152235808259 139.74039126358673 40.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-09b11ee9-e42f-4635-b03b-bbe2661b1536">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-09b11ee9-e42f-4635-b03b-bbe2661b1536">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-09b11ee9-e42f-4635-b03b-bbe2661b1536">
											<gml:posList>35.67144453504012 139.74038152250168 40.872 35.67149623102941 139.7404311603798 40.872 35.67149546764645 139.7404230863364 40.872 35.67146104573763 139.7403900201405 40.872 35.67145120446037 139.74038056477835 40.872 35.67144453504012 139.74038152250168 40.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d52df3f8-d573-4bca-837e-3063e8884882">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d52df3f8-d573-4bca-837e-3063e8884882">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d52df3f8-d573-4bca-837e-3063e8884882">
											<gml:posList>35.67152235808259 139.74039126358673 40.872 35.67152157666952 139.74038318956198 40.872 35.67149546764645 139.7404230863364 40.872 35.67149623102941 139.7404311603798 40.872 35.67152235808259 139.74039126358673 40.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6bc35ac7-5006-46d7-a922-db15aeba02dc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6bc35ac7-5006-46d7-a922-db15aeba02dc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6bc35ac7-5006-46d7-a922-db15aeba02dc">
											<gml:posList>35.671431895782405 139.740227252026 9.048 35.67137391418126 139.74031370217895 9.048 35.67137391418126 139.74031370217895 26.843 35.671431895782405 139.740227252026 26.843 35.671431895782405 139.740227252026 9.048</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9940877f-e5e0-4585-b396-8cd7542cd3cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9940877f-e5e0-4585-b396-8cd7542cd3cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9940877f-e5e0-4585-b396-8cd7542cd3cf">
											<gml:posList>35.67149623102941 139.7404311603798 40.872 35.67144453504012 139.74038152250168 40.872 35.67137391418126 139.74031370217895 26.843 35.67137391418126 139.74031370217895 9.048 35.67149623102941 139.7404311603798 9.048 35.67149623102941 139.7404311603798 40.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bf6b93df-9665-4e40-ae51-98ceb3feeb45">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf6b93df-9665-4e40-ae51-98ceb3feeb45">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf6b93df-9665-4e40-ae51-98ceb3feeb45">
											<gml:posList>35.67149546764645 139.7404230863364 40.872 35.67149546764645 139.7404230863364 40.519 35.67146104573763 139.7403900201405 40.519 35.67146104573763 139.7403900201405 40.872 35.67149546764645 139.7404230863364 40.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-325f8300-05cb-41ac-8ebc-afb9e6b49962">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-325f8300-05cb-41ac-8ebc-afb9e6b49962">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-325f8300-05cb-41ac-8ebc-afb9e6b49962">
											<gml:posList>35.67146104573763 139.7403900201405 40.872 35.67146104573763 139.7403900201405 40.519 35.67151194120659 139.74031343157347 40.519 35.67151194120659 139.74031343157347 40.872 35.67146104573763 139.7403900201405 40.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f3d17439-2092-434a-911f-e7aeeb465018">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f3d17439-2092-434a-911f-e7aeeb465018">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f3d17439-2092-434a-911f-e7aeeb465018">
											<gml:posList>35.671431895782405 139.740227252026 26.843 35.67157431281217 139.74036738726792 9.048 35.671431895782405 139.740227252026 9.048 35.671431895782405 139.740227252026 26.843</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8777e439-9edf-4909-bb9d-1621b0336119">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8777e439-9edf-4909-bb9d-1621b0336119">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8777e439-9edf-4909-bb9d-1621b0336119">
											<gml:posList>35.671431895782405 139.740227252026 26.843 35.671501038601164 139.74029528391853 40.872 35.67157431281217 139.74036738726792 40.872 35.671431895782405 139.740227252026 26.843</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3a3ffbfd-f0b9-401d-b0e4-2af59609e75b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a3ffbfd-f0b9-401d-b0e4-2af59609e75b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a3ffbfd-f0b9-401d-b0e4-2af59609e75b">
											<gml:posList>35.671431895782405 139.740227252026 26.843 35.67157431281217 139.74036738726792 40.872 35.67157431281217 139.74036738726792 9.048 35.671431895782405 139.740227252026 26.843</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-598451e3-909a-4f29-ad33-6c3895344fe1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-598451e3-909a-4f29-ad33-6c3895344fe1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-598451e3-909a-4f29-ad33-6c3895344fe1">
											<gml:posList>35.67152157666952 139.74038318956198 40.872 35.67152157666952 139.74038318956198 40.519 35.67149546764645 139.7404230863364 40.519 35.67149546764645 139.7404230863364 40.872 35.67152157666952 139.74038318956198 40.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-691e011b-c370-486a-9653-5dd8372e96fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-691e011b-c370-486a-9653-5dd8372e96fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-691e011b-c370-486a-9653-5dd8372e96fc">
											<gml:posList>35.67149623102941 139.7404311603798 9.048 35.67152235808259 139.74039126358673 9.048 35.67152235808259 139.74039126358673 40.872 35.67149623102941 139.7404311603798 40.872 35.67149623102941 139.7404311603798 9.048</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9c64348b-7060-4cba-aa8a-b6d3885d3626">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c64348b-7060-4cba-aa8a-b6d3885d3626">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c64348b-7060-4cba-aa8a-b6d3885d3626">
											<gml:posList>35.67154420874695 139.7404047369813 40.872 35.67154420874695 139.7404047369813 40.519 35.67152157666952 139.74038318956198 40.519 35.67152157666952 139.74038318956198 40.872 35.67154420874695 139.7404047369813 40.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-55d32fb2-05da-4c75-8645-00f0752a08b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-55d32fb2-05da-4c75-8645-00f0752a08b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-55d32fb2-05da-4c75-8645-00f0752a08b0">
											<gml:posList>35.67152235808259 139.74039126358673 9.048 35.67154501720826 139.7404128220236 9.048 35.67154501720826 139.7404128220236 40.872 35.67152235808259 139.74039126358673 40.872 35.67152235808259 139.74039126358673 9.048</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c9b80324-48fc-44b4-b162-5a637f3f0d95">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c9b80324-48fc-44b4-b162-5a637f3f0d95">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c9b80324-48fc-44b4-b162-5a637f3f0d95">
											<gml:posList>35.67151194120659 139.74031343157347 40.872 35.67151194120659 139.74031343157347 40.519 35.67156769744038 139.7403683007455 40.519 35.67156769744038 139.7403683007455 40.872 35.67151194120659 139.74031343157347 40.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-64ad1de5-150b-44fa-846c-3499f6557486">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-64ad1de5-150b-44fa-846c-3499f6557486">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-64ad1de5-150b-44fa-846c-3499f6557486">
											<gml:posList>35.67156769744038 139.7403683007455 40.872 35.67156769744038 139.7403683007455 40.519 35.67154420874695 139.7404047369813 40.519 35.67154420874695 139.7404047369813 40.872 35.67156769744038 139.7403683007455 40.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c5ce1f19-d593-4f22-b593-4665b4986c77">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c5ce1f19-d593-4f22-b593-4665b4986c77">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c5ce1f19-d593-4f22-b593-4665b4986c77">
											<gml:posList>35.67154501720826 139.7404128220236 9.048 35.67157431281217 139.74036738726792 9.048 35.67157431281217 139.74036738726792 40.872 35.67154501720826 139.7404128220236 40.872 35.67154501720826 139.7404128220236 9.048</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4292</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">179.5438</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.16</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>