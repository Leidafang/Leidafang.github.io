<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_974b52a4-e00e-47e7-9cef-5bdc1f5a1d0c">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">3.3</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67039679803401 139.74007962776437 0 35.670415631777885 139.74007323216452 0 35.67041081095865 139.74005192952944 0 35.67049343610119 139.7400238531855 0 35.6704890403908 139.74000444999706 0 35.6703875905162 139.74003891091138 0 35.67039679803401 139.74007962776437 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67039679803401 139.74007962776437 15.9 35.6703875905162 139.74003891091138 15.9 35.6704890403908 139.74000444999706 15.9 35.67049343610119 139.7400238531855 15.9 35.67041081095865 139.74005192952944 15.9 35.670415631777885 139.74007323216452 15.9 35.67039679803401 139.74007962776437 15.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67039679803401 139.74007962776437 15.9 35.670415631777885 139.74007323216452 15.9 35.670415631777885 139.74007323216452 19.22 35.67039679803401 139.74007962776437 19.22 35.67039679803401 139.74007962776437 15.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670415631777885 139.74007323216452 15.9 35.67041081095865 139.74005192952944 15.9 35.67041081095865 139.74005192952944 19.22 35.670415631777885 139.74007323216452 19.22 35.670415631777885 139.74007323216452 15.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67041081095865 139.74005192952944 15.9 35.67049343610119 139.7400238531855 15.9 35.67049343610119 139.7400238531855 19.22 35.67041081095865 139.74005192952944 19.22 35.67041081095865 139.74005192952944 15.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67049343610119 139.7400238531855 15.9 35.6704890403908 139.74000444999706 15.9 35.6704890403908 139.74000444999706 19.22 35.67049343610119 139.7400238531855 19.22 35.67049343610119 139.7400238531855 15.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6704890403908 139.74000444999706 15.9 35.6703875905162 139.74003891091138 15.9 35.6703875905162 139.74003891091138 19.22 35.6704890403908 139.74000444999706 19.22 35.6704890403908 139.74000444999706 15.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6703875905162 139.74003891091138 15.9 35.67039679803401 139.74007962776437 15.9 35.67039679803401 139.74007962776437 19.22 35.6703875905162 139.74003891091138 19.22 35.6703875905162 139.74003891091138 15.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67039679803401 139.74007962776437 19.22 35.670415631777885 139.74007323216452 19.22 35.67041081095865 139.74005192952944 19.22 35.67049343610119 139.7400238531855 19.22 35.6704890403908 139.74000444999706 19.22 35.6703875905162 139.74003891091138 19.22 35.67039679803401 139.74007962776437 19.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-7eb954de-c525-4923-a334-688e065a8b02"/>
							<gml:surfaceMember xlink:href="#poly-b7797906-8daf-4c62-8a84-9cb6cb6ed585"/>
							<gml:surfaceMember xlink:href="#poly-52db487d-fba1-461c-8027-a00a483ddd9f"/>
							<gml:surfaceMember xlink:href="#poly-805faf1d-052a-4544-a199-c4f053500c21"/>
							<gml:surfaceMember xlink:href="#poly-9da2faf7-c5aa-4028-862b-59d10d3911b5"/>
							<gml:surfaceMember xlink:href="#poly-ce91ea83-ef8e-42a7-9184-22e724532999"/>
							<gml:surfaceMember xlink:href="#poly-70ed8c6a-dcff-40ad-afff-6ba9a16e2455"/>
							<gml:surfaceMember xlink:href="#poly-ad586e0d-fbe1-405e-bde7-e2d5c9c8d66c"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-7eb954de-c525-4923-a334-688e065a8b02">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7eb954de-c525-4923-a334-688e065a8b02">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7eb954de-c525-4923-a334-688e065a8b02">
											<gml:posList>35.670387590516185 139.74003891091138 15.9 35.6704890403908 139.74000444999706 15.9 35.670493436101175 139.74002385318548 15.9 35.67041081095865 139.74005192952941 15.9 35.67041563177789 139.74007323216452 15.9 35.67039679803401 139.74007962776437 15.9 35.670387590516185 139.74003891091138 15.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b7797906-8daf-4c62-8a84-9cb6cb6ed585">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b7797906-8daf-4c62-8a84-9cb6cb6ed585">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b7797906-8daf-4c62-8a84-9cb6cb6ed585">
											<gml:posList>35.670387590516185 139.74003891091138 19.655 35.67039679803401 139.74007962776437 19.655 35.67041563177789 139.74007323216452 19.655 35.67041081095865 139.74005192952941 19.655 35.670493436101175 139.74002385318548 19.655 35.6704890403908 139.74000444999706 19.655 35.670387590516185 139.74003891091138 19.655</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-52db487d-fba1-461c-8027-a00a483ddd9f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-52db487d-fba1-461c-8027-a00a483ddd9f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-52db487d-fba1-461c-8027-a00a483ddd9f">
											<gml:posList>35.670493436101175 139.74002385318548 15.9 35.6704890403908 139.74000444999706 15.9 35.6704890403908 139.74000444999706 19.655 35.670493436101175 139.74002385318548 19.655 35.670493436101175 139.74002385318548 15.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-805faf1d-052a-4544-a199-c4f053500c21">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-805faf1d-052a-4544-a199-c4f053500c21">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-805faf1d-052a-4544-a199-c4f053500c21">
											<gml:posList>35.6704890403908 139.74000444999706 15.9 35.670387590516185 139.74003891091138 15.9 35.670387590516185 139.74003891091138 19.655 35.6704890403908 139.74000444999706 19.655 35.6704890403908 139.74000444999706 15.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9da2faf7-c5aa-4028-862b-59d10d3911b5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9da2faf7-c5aa-4028-862b-59d10d3911b5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9da2faf7-c5aa-4028-862b-59d10d3911b5">
											<gml:posList>35.67041081095865 139.74005192952941 15.9 35.670493436101175 139.74002385318548 15.9 35.670493436101175 139.74002385318548 19.655 35.67041081095865 139.74005192952941 19.655 35.67041081095865 139.74005192952941 15.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ce91ea83-ef8e-42a7-9184-22e724532999">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce91ea83-ef8e-42a7-9184-22e724532999">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce91ea83-ef8e-42a7-9184-22e724532999">
											<gml:posList>35.670387590516185 139.74003891091138 15.9 35.67039679803401 139.74007962776437 15.9 35.67039679803401 139.74007962776437 19.655 35.670387590516185 139.74003891091138 19.655 35.670387590516185 139.74003891091138 15.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-70ed8c6a-dcff-40ad-afff-6ba9a16e2455">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70ed8c6a-dcff-40ad-afff-6ba9a16e2455">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70ed8c6a-dcff-40ad-afff-6ba9a16e2455">
											<gml:posList>35.67041563177789 139.74007323216452 15.9 35.67041081095865 139.74005192952941 15.9 35.67041081095865 139.74005192952941 19.655 35.67041563177789 139.74007323216452 19.655 35.67041563177789 139.74007323216452 15.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ad586e0d-fbe1-405e-bde7-e2d5c9c8d66c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad586e0d-fbe1-405e-bde7-e2d5c9c8d66c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad586e0d-fbe1-405e-bde7-e2d5c9c8d66c">
											<gml:posList>35.67039679803401 139.74007962776437 15.9 35.67041563177789 139.74007323216452 15.9 35.67041563177789 139.74007323216452 19.655 35.67039679803401 139.74007962776437 19.655 35.67039679803401 139.74007962776437 15.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8483</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>