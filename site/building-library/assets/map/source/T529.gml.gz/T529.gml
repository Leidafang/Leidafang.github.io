<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_99c502d6-51d0-4d1e-9ecc-369d0425cff1">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">403</bldg:usage>
			<bldg:measuredHeight uom="m">42.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>12</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67048439069245 139.73791309755867 0 35.670478689521545 139.73788468228395 0 35.67045096252944 139.73782688807427 0 35.67032841408501 139.73786380702538 0 35.670339843576336 139.7379207699922 0 35.670336824697145 139.73792167937745 0 35.67034483344932 139.7379615689176 0 35.670323935597025 139.73796786804652 0 35.67033021589174 139.73799914356312 0 35.67035110474072 139.73799285549882 0 35.67035796421534 139.73802704655108 0 35.67049926580404 139.7379844719347 0 35.670494858730514 139.73796251718105 0 35.67048439069245 139.73791309755867 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67048439069245 139.73791309755867 15.537 35.670494858730514 139.73796251718105 15.537 35.67049926580404 139.7379844719347 15.537 35.67035796421534 139.73802704655108 15.537 35.67035110474072 139.73799285549882 15.537 35.67033021589174 139.73799914356312 15.537 35.670323935597025 139.73796786804652 15.537 35.67034483344932 139.7379615689176 15.537 35.670336824697145 139.73792167937745 15.537 35.670339843576336 139.7379207699922 15.537 35.67032841408501 139.73786380702538 15.537 35.67045096252944 139.73782688807427 15.537 35.670478689521545 139.73788468228395 15.537 35.67048439069245 139.73791309755867 15.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67048439069245 139.73791309755867 15.537 35.670478689521545 139.73788468228395 15.537 35.670478689521545 139.73788468228395 57.97 35.67048439069245 139.73791309755867 57.97 35.67048439069245 139.73791309755867 15.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670478689521545 139.73788468228395 15.537 35.67045096252944 139.73782688807427 15.537 35.67045096252944 139.73782688807427 57.97 35.670478689521545 139.73788468228395 57.97 35.670478689521545 139.73788468228395 15.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67045096252944 139.73782688807427 15.537 35.67032841408501 139.73786380702538 15.537 35.67032841408501 139.73786380702538 57.97 35.67045096252944 139.73782688807427 57.97 35.67045096252944 139.73782688807427 15.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67032841408501 139.73786380702538 15.537 35.670339843576336 139.7379207699922 15.537 35.670339843576336 139.7379207699922 57.97 35.67032841408501 139.73786380702538 57.97 35.67032841408501 139.73786380702538 15.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670339843576336 139.7379207699922 15.537 35.670336824697145 139.73792167937745 15.537 35.670336824697145 139.73792167937745 57.97 35.670339843576336 139.7379207699922 57.97 35.670339843576336 139.7379207699922 15.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670336824697145 139.73792167937745 15.537 35.67034483344932 139.7379615689176 15.537 35.67034483344932 139.7379615689176 57.97 35.670336824697145 139.73792167937745 57.97 35.670336824697145 139.73792167937745 15.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67034483344932 139.7379615689176 15.537 35.670323935597025 139.73796786804652 15.537 35.670323935597025 139.73796786804652 57.97 35.67034483344932 139.7379615689176 57.97 35.67034483344932 139.7379615689176 15.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670323935597025 139.73796786804652 15.537 35.67033021589174 139.73799914356312 15.537 35.67033021589174 139.73799914356312 57.97 35.670323935597025 139.73796786804652 57.97 35.670323935597025 139.73796786804652 15.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67033021589174 139.73799914356312 15.537 35.67035110474072 139.73799285549882 15.537 35.67035110474072 139.73799285549882 57.97 35.67033021589174 139.73799914356312 57.97 35.67033021589174 139.73799914356312 15.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67035110474072 139.73799285549882 15.537 35.67035796421534 139.73802704655108 15.537 35.67035796421534 139.73802704655108 57.97 35.67035110474072 139.73799285549882 57.97 35.67035110474072 139.73799285549882 15.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67035796421534 139.73802704655108 15.537 35.67049926580404 139.7379844719347 15.537 35.67049926580404 139.7379844719347 57.97 35.67035796421534 139.73802704655108 57.97 35.67035796421534 139.73802704655108 15.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67049926580404 139.7379844719347 15.537 35.670494858730514 139.73796251718105 15.537 35.670494858730514 139.73796251718105 57.97 35.67049926580404 139.7379844719347 57.97 35.67049926580404 139.7379844719347 15.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670494858730514 139.73796251718105 15.537 35.67048439069245 139.73791309755867 15.537 35.67048439069245 139.73791309755867 57.97 35.670494858730514 139.73796251718105 57.97 35.670494858730514 139.73796251718105 15.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67048439069245 139.73791309755867 57.97 35.670478689521545 139.73788468228395 57.97 35.67045096252944 139.73782688807427 57.97 35.67032841408501 139.73786380702538 57.97 35.670339843576336 139.7379207699922 57.97 35.670336824697145 139.73792167937745 57.97 35.67034483344932 139.7379615689176 57.97 35.670323935597025 139.73796786804652 57.97 35.67033021589174 139.73799914356312 57.97 35.67035110474072 139.73799285549882 57.97 35.67035796421534 139.73802704655108 57.97 35.67049926580404 139.7379844719347 57.97 35.670494858730514 139.73796251718105 57.97 35.67048439069245 139.73791309755867 57.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-889aa052-110e-4dc1-b3e8-9a10c7842604"/>
							<gml:surfaceMember xlink:href="#poly-5d69faeb-53c1-4ff1-989b-7650d098f31f"/>
							<gml:surfaceMember xlink:href="#poly-e51c6dac-fd5b-4b54-90ea-81dd3daa5286"/>
							<gml:surfaceMember xlink:href="#poly-1cb57cb9-64b8-437b-9b64-93a331f66cd7"/>
							<gml:surfaceMember xlink:href="#poly-5b7a809f-71b3-43ea-81a6-38f2e6001c78"/>
							<gml:surfaceMember xlink:href="#poly-c709d33a-1832-42c9-9943-f680e2a2cb6c"/>
							<gml:surfaceMember xlink:href="#poly-af8b2814-ad1e-478b-abe9-a2760ae9c84b"/>
							<gml:surfaceMember xlink:href="#poly-65471cf6-3e3d-4aa7-9601-efd75bd097c3"/>
							<gml:surfaceMember xlink:href="#poly-64fc9b61-8a40-4160-9aaf-cb7f223131e6"/>
							<gml:surfaceMember xlink:href="#poly-6721fab1-9e0c-44bf-a8cb-53c3d73e7202"/>
							<gml:surfaceMember xlink:href="#poly-d7cb1fe6-86a2-4e06-b4b0-d18f9ac5ae54"/>
							<gml:surfaceMember xlink:href="#poly-27968367-cbd1-475b-a98b-8957d7722fd5"/>
							<gml:surfaceMember xlink:href="#poly-ae2a12e3-5651-48f1-87b9-64b749d0c73e"/>
							<gml:surfaceMember xlink:href="#poly-425d5710-08bb-4274-bede-c4d693d695ea"/>
							<gml:surfaceMember xlink:href="#poly-27124c1a-6350-46c0-9685-85d4c4ac8680"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_99c502d6-51d0-4d1e-9ecc-369d0425cff1_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5ed8e349-d02e-4b4d-9c75-fa884af02478">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5ed8e349-d02e-4b4d-9c75-fa884af02478_0">
											<gml:posList>35.67041943178697 139.73784871991336 58.715 35.670396740595585 139.73785550724867 61.174 35.67041943178697 139.73784871991336 61.174 35.67041943178697 139.73784871991336 58.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-17e3ed08-3c0e-4850-b0f5-4a63c1bfe5d2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-17e3ed08-3c0e-4850-b0f5-4a63c1bfe5d2_0">
											<gml:posList>35.67041943178697 139.73784871991336 58.715 35.670396740595585 139.73785550724867 58.715 35.670396740595585 139.73785550724867 61.174 35.67041943178697 139.73784871991336 58.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-980bde56-7bfc-48e3-9aa8-49be5f18116b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-980bde56-7bfc-48e3-9aa8-49be5f18116b_0">
											<gml:posList>35.67043892431513 139.7378548273777 58.715 35.67043066066779 139.73785727844322 59.856 35.67043892431513 139.7378548273777 59.856 35.67043892431513 139.7378548273777 58.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2e36c4cb-1dcf-4281-8d93-e8ca8aced7da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2e36c4cb-1dcf-4281-8d93-e8ca8aced7da_0">
											<gml:posList>35.67043892431513 139.7378548273777 58.715 35.67043066066779 139.73785727844322 58.715 35.67043066066779 139.73785727844322 59.856 35.67043892431513 139.7378548273777 58.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f850c52-ee96-4936-b17f-a1c2e205b794">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2f850c52-ee96-4936-b17f-a1c2e205b794_0">
											<gml:posList>35.67039816069549 139.7379868787475 58.715 35.670452599722466 139.73797056494698 60.969 35.67039816069549 139.7379868787475 60.969 35.67039816069549 139.7379868787475 58.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b106171-e527-4cd8-b072-f2bce4c31d50">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2b106171-e527-4cd8-b072-f2bce4c31d50_0">
											<gml:posList>35.67039816069549 139.7379868787475 58.715 35.670452599722466 139.73797056494698 58.715 35.670452599722466 139.73797056494698 60.969 35.67039816069549 139.7379868787475 58.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-56b18737-913e-49bc-94e6-8c7864c75ef1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-56b18737-913e-49bc-94e6-8c7864c75ef1_0">
											<gml:posList>35.67036182363302 139.73796068709967 58.715 35.67037045584955 139.73800250900996 60.689 35.67036182363302 139.73796068709967 60.689 35.67036182363302 139.73796068709967 58.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd4f4bf1-d498-4f5e-8370-e3b75ed0bec4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bd4f4bf1-d498-4f5e-8370-e3b75ed0bec4_0">
											<gml:posList>35.67036182363302 139.73796068709967 58.715 35.67037045584955 139.73800250900996 58.715 35.67037045584955 139.73800250900996 60.689 35.67036182363302 139.73796068709967 58.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b00f4a25-3126-4606-81e9-e142839a0a0f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b00f4a25-3126-4606-81e9-e142839a0a0f_0">
											<gml:posList>35.67037045584955 139.73800250900996 58.715 35.67038057579322 139.73799938193227 60.689 35.67037045584955 139.73800250900996 60.689 35.67037045584955 139.73800250900996 58.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8de1e13b-e51a-4341-8929-a5dc8abeb1ac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8de1e13b-e51a-4341-8929-a5dc8abeb1ac_0">
											<gml:posList>35.67037045584955 139.73800250900996 58.715 35.67038057579322 139.73799938193227 58.715 35.67038057579322 139.73799938193227 60.689 35.67037045584955 139.73800250900996 58.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ceb69eea-bbd1-4f32-b32a-5e9bccdafddd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ceb69eea-bbd1-4f32-b32a-5e9bccdafddd_0">
											<gml:posList>35.67033044456336 139.73786682023453 58.192 35.670448873518765 139.73782963003728 61.502 35.670448873518765 139.73782963003728 58.192 35.67033044456336 139.73786682023453 58.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c708c79-8594-4a73-8842-ef2ee1039b7d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2c708c79-8594-4a73-8842-ef2ee1039b7d_0">
											<gml:posList>35.67033044456336 139.73786682023453 58.192 35.67033044456336 139.73786682023453 61.502 35.670448873518765 139.73782963003728 61.502 35.67033044456336 139.73786682023453 58.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d38139c-f986-467d-9803-29b690e6968b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5d38139c-f986-467d-9803-29b690e6968b_0">
											<gml:posList>35.670446436503426 139.7378368240608 61.502 35.67033660450862 139.73787131977124 58.715 35.670446436503426 139.7378368240608 58.715 35.670446436503426 139.7378368240608 61.502</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b8d9d79-2dec-4a65-85da-0947cbc648f4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7b8d9d79-2dec-4a65-85da-0947cbc648f4_0">
											<gml:posList>35.670446436503426 139.7378368240608 61.502 35.67033660450862 139.73787131977124 61.502 35.67033660450862 139.73787131977124 58.715 35.670446436503426 139.7378368240608 61.502</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9025f88-19ff-4c4b-853c-5eb373494d39">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e9025f88-19ff-4c4b-853c-5eb373494d39_0">
											<gml:posList>35.670448873518765 139.73782963003728 58.192 35.67047790046429 139.73788991915652 61.502 35.67047790046429 139.73788991915652 58.192 35.670448873518765 139.73782963003728 58.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d18e109-f161-443c-9eb9-efaaab243c90">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d18e109-f161-443c-9eb9-efaaab243c90_0">
											<gml:posList>35.670448873518765 139.73782963003728 58.192 35.670448873518765 139.73782963003728 61.502 35.67047790046429 139.73788991915652 61.502 35.670448873518765 139.73782963003728 58.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74eb747c-c3ba-4215-8bfb-2368c86ccafb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-74eb747c-c3ba-4215-8bfb-2368c86ccafb_0">
											<gml:posList>35.67046983859827 139.7378853887358 61.502 35.670446436503426 139.7378368240608 58.715 35.67046983859827 139.7378853887358 58.715 35.67046983859827 139.7378853887358 61.502</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-56a12103-507e-452e-a320-1788dc0e0d5a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-56a12103-507e-452e-a320-1788dc0e0d5a_0">
											<gml:posList>35.67046983859827 139.7378853887358 61.502 35.670446436503426 139.7378368240608 61.502 35.670446436503426 139.7378368240608 58.715 35.67046983859827 139.7378853887358 61.502</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e614d24-74bc-4f7e-b546-af8da45352a7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6e614d24-74bc-4f7e-b546-af8da45352a7_0">
											<gml:posList>35.670444182446 139.7378815088996 58.715 35.67043892431513 139.7378548273777 59.856 35.670444182446 139.7378815088996 59.856 35.670444182446 139.7378815088996 58.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea208221-bc9b-4955-892a-24e587615ffc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea208221-bc9b-4955-892a-24e587615ffc_0">
											<gml:posList>35.670444182446 139.7378815088996 58.715 35.67043892431513 139.7378548273777 58.715 35.67043892431513 139.7378548273777 59.856 35.670444182446 139.7378815088996 58.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb44a102-19e1-4226-872d-e35f59cc326c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb44a102-19e1-4226-872d-e35f59cc326c_0">
											<gml:posList>35.67043066066779 139.73785727844322 59.856 35.670444182446 139.7378815088996 59.856 35.67043892431513 139.7378548273777 59.856 35.67043066066779 139.73785727844322 59.856</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0236b15f-867f-469c-82da-0e5d3c0a4a77">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0236b15f-867f-469c-82da-0e5d3c0a4a77_0">
											<gml:posList>35.67043066066779 139.73785727844322 59.856 35.67043590977565 139.73788394892696 59.856 35.670444182446 139.7378815088996 59.856 35.67043066066779 139.73785727844322 59.856</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dcc4d15e-0172-4880-a699-2df53620085c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dcc4d15e-0172-4880-a699-2df53620085c_0">
											<gml:posList>35.67043066066779 139.73785727844322 58.715 35.67043590977565 139.73788394892696 59.856 35.67043066066779 139.73785727844322 59.856 35.67043066066779 139.73785727844322 58.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-592e9a7a-94b2-4a6d-a661-826ad52f38b5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-592e9a7a-94b2-4a6d-a661-826ad52f38b5_0">
											<gml:posList>35.67043066066779 139.73785727844322 58.715 35.67043590977565 139.73788394892696 58.715 35.67043590977565 139.73788394892696 59.856 35.67043066066779 139.73785727844322 58.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f6b0466-7b34-4995-b658-db5e0843f167">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0f6b0466-7b34-4995-b658-db5e0843f167_0">
											<gml:posList>35.67043590977565 139.73788394892696 58.715 35.670444182446 139.7378815088996 59.856 35.67043590977565 139.73788394892696 59.856 35.67043590977565 139.73788394892696 58.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea57849c-dce7-4c95-964c-cca46bdb857c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea57849c-dce7-4c95-964c-cca46bdb857c_0">
											<gml:posList>35.67043590977565 139.73788394892696 58.715 35.670444182446 139.7378815088996 58.715 35.670444182446 139.7378815088996 59.856 35.67043590977565 139.73788394892696 58.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e3c8542-1a9f-4b2e-8f2b-f3d0ddcd30f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e3c8542-1a9f-4b2e-8f2b-f3d0ddcd30f8_0">
											<gml:posList>35.670434843525264 139.73792612484263 58.715 35.67041943178697 139.73784871991336 61.174 35.670434843525264 139.73792612484263 61.174 35.670434843525264 139.73792612484263 58.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59c56ff4-5279-4e38-9a1d-a6b56afd2854">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-59c56ff4-5279-4e38-9a1d-a6b56afd2854_0">
											<gml:posList>35.670434843525264 139.73792612484263 58.715 35.67041943178697 139.73784871991336 58.715 35.67041943178697 139.73784871991336 61.174 35.670434843525264 139.73792612484263 58.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c33d047-ffb7-4dd3-bd98-fd6c858e158e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2c33d047-ffb7-4dd3-bd98-fd6c858e158e_0">
											<gml:posList>35.67047790046429 139.73788991915652 58.192 35.67047611606256 139.73789031894648 61.502 35.67047611606256 139.73789031894648 58.192 35.67047790046429 139.73788991915652 58.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80324ffa-a04e-4369-a6c7-b8539072392a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-80324ffa-a04e-4369-a6c7-b8539072392a_0">
											<gml:posList>35.67047790046429 139.73788991915652 58.192 35.67047790046429 139.73788991915652 61.502 35.67047611606256 139.73789031894648 61.502 35.67047790046429 139.73788991915652 58.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ad9514b-2476-48c2-821b-55b4850ceb62">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2ad9514b-2476-48c2-821b-55b4850ceb62_0">
											<gml:posList>35.670434843525264 139.73792612484263 61.174 35.67041943178697 139.73784871991336 61.174 35.670396740595585 139.73785550724867 61.174 35.670434843525264 139.73792612484263 61.174</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc3aa332-72df-4ce6-b3bb-c5fc83b61b47">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc3aa332-72df-4ce6-b3bb-c5fc83b61b47_0">
											<gml:posList>35.67041215232956 139.73793291215736 61.174 35.670434843525264 139.73792612484263 61.174 35.670396740595585 139.73785550724867 61.174 35.67041215232956 139.73793291215736 61.174</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-880a516d-5241-481a-9b57-fd7cd6e1c52d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-880a516d-5241-481a-9b57-fd7cd6e1c52d_0">
											<gml:posList>35.67041215232956 139.73793291215736 58.715 35.670396740595585 139.73785550724867 61.174 35.670396740595585 139.73785550724867 58.715 35.67041215232956 139.73793291215736 58.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-56e38df1-686e-42a2-a8e6-8953504c92ee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-56e38df1-686e-42a2-a8e6-8953504c92ee_0">
											<gml:posList>35.67041215232956 139.73793291215736 58.715 35.67041215232956 139.73793291215736 61.174 35.670396740595585 139.73785550724867 61.174 35.67041215232956 139.73793291215736 58.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9c229a3f-5008-40d1-95c1-a27f05a0cdf9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9c229a3f-5008-40d1-95c1-a27f05a0cdf9_0">
											<gml:posList>35.670341945506586 139.73792295464915 61.502 35.67033044456336 139.73786682023453 58.192 35.670341945506586 139.73792295464915 58.192 35.670341945506586 139.73792295464915 61.502</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bafb9de1-a1e1-4fdc-a950-d15288f7e0df">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bafb9de1-a1e1-4fdc-a950-d15288f7e0df_0">
											<gml:posList>35.670341945506586 139.73792295464915 61.502 35.67033044456336 139.73786682023453 61.502 35.67033044456336 139.73786682023453 58.192 35.670341945506586 139.73792295464915 61.502</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84493031-b785-4241-aeaa-b28131d55578">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-84493031-b785-4241-aeaa-b28131d55578_0">
											<gml:posList>35.67033660450862 139.73787131977124 61.502 35.670348150684646 139.73792766401584 58.715 35.67033660450862 139.73787131977124 58.715 35.67033660450862 139.73787131977124 61.502</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80365e7c-742f-4e83-81b8-0d2d223a05a2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-80365e7c-742f-4e83-81b8-0d2d223a05a2_0">
											<gml:posList>35.67033660450862 139.73787131977124 61.502 35.670348150684646 139.73792766401584 61.502 35.670348150684646 139.73792766401584 58.715 35.67033660450862 139.73787131977124 61.502</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e3c191c7-210a-4ecf-aac1-197249c992a0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e3c191c7-210a-4ecf-aac1-197249c992a0_0">
											<gml:posList>35.670338665211936 139.73792384225294 58.192 35.670341945506586 139.73792295464915 61.502 35.670341945506586 139.73792295464915 58.192 35.670338665211936 139.73792384225294 58.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e25fe3f0-29ff-44f5-91da-fa6d6abe9c30">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e25fe3f0-29ff-44f5-91da-fa6d6abe9c30_0">
											<gml:posList>35.670338665211936 139.73792384225294 58.192 35.670338665211936 139.73792384225294 61.502 35.670341945506586 139.73792295464915 61.502 35.670338665211936 139.73792384225294 58.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dbfe1922-95bb-4c7c-8040-f7a813188e7f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dbfe1922-95bb-4c7c-8040-f7a813188e7f_0">
											<gml:posList>35.67034486137625 139.73792855163023 58.715 35.67036287786469 139.7380171322179 58.715 35.670348150684646 139.73792766401584 58.715 35.67034486137625 139.73792855163023 58.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-561821c7-9a04-452a-a07b-881f43de9d1a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-561821c7-9a04-452a-a07b-881f43de9d1a_0">
											<gml:posList>35.670446436503426 139.7378368240608 58.715 35.67033660450862 139.73787131977124 58.715 35.670348150684646 139.73792766401584 58.715 35.670446436503426 139.7378368240608 58.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2dcd9080-b049-4a01-8c71-57bcd515b802">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2dcd9080-b049-4a01-8c71-57bcd515b802_0">
											<gml:posList>35.670446436503426 139.7378368240608 58.715 35.670348150684646 139.73792766401584 58.715 35.67046983859827 139.7378853887358 58.715 35.670446436503426 139.7378368240608 58.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ce42540-5a2f-4b65-b574-540879626690">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6ce42540-5a2f-4b65-b574-540879626690_0">
											<gml:posList>35.670348150684646 139.73792766401584 58.715 35.67036287786469 139.7380171322179 58.715 35.67048893141648 139.7379785965605 58.715 35.670348150684646 139.73792766401584 58.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a8c1aa36-b1f6-4d54-8019-f1acea25428b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a8c1aa36-b1f6-4d54-8019-f1acea25428b_0">
											<gml:posList>35.670348150684646 139.73792766401584 58.715 35.67048893141648 139.7379785965605 58.715 35.67046983859827 139.7378853887358 58.715 35.670348150684646 139.73792766401584 58.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d4d3df0-4686-4135-b712-5ff05100faaa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4d4d3df0-4686-4135-b712-5ff05100faaa_0">
											<gml:posList>35.670338665211936 139.73792384225294 61.502 35.6703591701918 139.73802469226496 61.502 35.67036287786469 139.7380171322179 61.502 35.670338665211936 139.73792384225294 61.502</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-64967559-c74d-47fd-9c98-8ab7bfcfa59c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-64967559-c74d-47fd-9c98-8ab7bfcfa59c_0">
											<gml:posList>35.67034486137625 139.73792855163023 61.502 35.670341945506586 139.73792295464915 61.502 35.670338665211936 139.73792384225294 61.502 35.67034486137625 139.73792855163023 61.502</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a8730948-bf57-4832-90b3-b33fa9bd450f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a8730948-bf57-4832-90b3-b33fa9bd450f_0">
											<gml:posList>35.67033044456336 139.73786682023453 61.502 35.670341945506586 139.73792295464915 61.502 35.67033660450862 139.73787131977124 61.502 35.67033044456336 139.73786682023453 61.502</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b90757d5-e7ac-4dfd-9d39-5cd37e84455a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b90757d5-e7ac-4dfd-9d39-5cd37e84455a_0">
											<gml:posList>35.670448873518765 139.73782963003728 61.502 35.67033044456336 139.73786682023453 61.502 35.67033660450862 139.73787131977124 61.502 35.670448873518765 139.73782963003728 61.502</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-51b8e326-561b-46fd-b70f-2c2d505c3848">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-51b8e326-561b-46fd-b70f-2c2d505c3848_0">
											<gml:posList>35.6703591701918 139.73802469226496 61.502 35.67049510039739 139.7379831292428 61.502 35.67048893141648 139.7379785965605 61.502 35.6703591701918 139.73802469226496 61.502</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1de647c-1851-482e-b7c0-9b3b413a1a93">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a1de647c-1851-482e-b7c0-9b3b413a1a93_0">
											<gml:posList>35.67046983859827 139.7378853887358 61.502 35.67047790046429 139.73788991915652 61.502 35.670448873518765 139.73782963003728 61.502 35.67046983859827 139.7378853887358 61.502</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1aad37c1-24b6-462f-8c94-f2d50cdf7fd5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1aad37c1-24b6-462f-8c94-f2d50cdf7fd5_0">
											<gml:posList>35.67047611606256 139.73789031894648 61.502 35.67047790046429 139.73788991915652 61.502 35.67046983859827 139.7378853887358 61.502 35.67047611606256 139.73789031894648 61.502</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3df97220-f223-40ed-a8a8-13634cddc478">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3df97220-f223-40ed-a8a8-13634cddc478_0">
											<gml:posList>35.67048893141648 139.7379785965605 61.502 35.67049510039739 139.7379831292428 61.502 35.67047611606256 139.73789031894648 61.502 35.67048893141648 139.7379785965605 61.502</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-501025b4-d18f-4eac-97c7-1a13c8374c87">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-501025b4-d18f-4eac-97c7-1a13c8374c87_0">
											<gml:posList>35.67036287786469 139.7380171322179 61.502 35.6703591701918 139.73802469226496 61.502 35.67048893141648 139.7379785965605 61.502 35.67036287786469 139.7380171322179 61.502</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74f4fba3-a5c3-489e-be82-fa9406ae7f70">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-74f4fba3-a5c3-489e-be82-fa9406ae7f70_0">
											<gml:posList>35.67034486137625 139.73792855163023 61.502 35.670338665211936 139.73792384225294 61.502 35.67036287786469 139.7380171322179 61.502 35.67034486137625 139.73792855163023 61.502</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e84fdc6b-1817-4671-b929-2b9d14c7b1f5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e84fdc6b-1817-4671-b929-2b9d14c7b1f5_0">
											<gml:posList>35.67034486137625 139.73792855163023 61.502 35.670348150684646 139.73792766401584 61.502 35.670341945506586 139.73792295464915 61.502 35.67034486137625 139.73792855163023 61.502</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b959074b-4456-4450-816a-ae563e92406f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b959074b-4456-4450-816a-ae563e92406f_0">
											<gml:posList>35.670341945506586 139.73792295464915 61.502 35.670348150684646 139.73792766401584 61.502 35.67033660450862 139.73787131977124 61.502 35.670341945506586 139.73792295464915 61.502</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33febe28-5b46-47c1-a3a8-7800934a0047">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-33febe28-5b46-47c1-a3a8-7800934a0047_0">
											<gml:posList>35.67033660450862 139.73787131977124 61.502 35.670446436503426 139.7378368240608 61.502 35.670448873518765 139.73782963003728 61.502 35.67033660450862 139.73787131977124 61.502</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc1a812b-eb18-4ca0-81f9-d5818b4a29a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cc1a812b-eb18-4ca0-81f9-d5818b4a29a8_0">
											<gml:posList>35.67046983859827 139.7378853887358 61.502 35.670448873518765 139.73782963003728 61.502 35.670446436503426 139.7378368240608 61.502 35.67046983859827 139.7378853887358 61.502</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a514f92f-33ad-4f30-a15e-4f2134acdd5e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a514f92f-33ad-4f30-a15e-4f2134acdd5e_0">
											<gml:posList>35.67048893141648 139.7379785965605 61.502 35.67047611606256 139.73789031894648 61.502 35.67046983859827 139.7378853887358 61.502 35.67048893141648 139.7379785965605 61.502</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad9f5f88-0eea-4039-b554-1ee554d3a274">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ad9f5f88-0eea-4039-b554-1ee554d3a274_0">
											<gml:posList>35.670348150684646 139.73792766401584 61.502 35.67034486137625 139.73792855163023 58.715 35.670348150684646 139.73792766401584 58.715 35.670348150684646 139.73792766401584 61.502</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-755e9ac3-f0e6-4337-a1ad-406d67622306">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-755e9ac3-f0e6-4337-a1ad-406d67622306_0">
											<gml:posList>35.670348150684646 139.73792766401584 61.502 35.67034486137625 139.73792855163023 61.502 35.67034486137625 139.73792855163023 58.715 35.670348150684646 139.73792766401584 61.502</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d624f691-800e-4744-a8a8-f302f5948b55">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d624f691-800e-4744-a8a8-f302f5948b55_0">
											<gml:posList>35.67041215232956 139.73793291215736 58.715 35.670434843525264 139.73792612484263 61.174 35.67041215232956 139.73793291215736 61.174 35.67041215232956 139.73793291215736 58.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a4cb7b3-4d89-4750-8ef4-83f3a5870770">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4a4cb7b3-4d89-4750-8ef4-83f3a5870770_0">
											<gml:posList>35.67041215232956 139.73793291215736 58.715 35.670434843525264 139.73792612484263 58.715 35.670434843525264 139.73792612484263 61.174 35.67041215232956 139.73793291215736 58.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d343ae72-2625-4913-847e-a99acd8a9a97">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d343ae72-2625-4913-847e-a99acd8a9a97_0">
											<gml:posList>35.67048893141648 139.7379785965605 61.502 35.67046983859827 139.7378853887358 58.715 35.67048893141648 139.7379785965605 58.715 35.67048893141648 139.7379785965605 61.502</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc6b6d07-1393-4148-ad82-623274770bc7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dc6b6d07-1393-4148-ad82-623274770bc7_0">
											<gml:posList>35.67048893141648 139.7379785965605 61.502 35.67046983859827 139.7378853887358 61.502 35.67046983859827 139.7378853887358 58.715 35.67048893141648 139.7379785965605 61.502</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-79afbd96-aac2-4556-8c35-0a8627d8c52d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-79afbd96-aac2-4556-8c35-0a8627d8c52d_0">
											<gml:posList>35.67047611606256 139.73789031894648 58.192 35.67049510039739 139.7379831292428 61.502 35.67049510039739 139.7379831292428 58.192 35.67047611606256 139.73789031894648 58.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-79828e5f-b4b3-496a-8394-c4708721f749">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-79828e5f-b4b3-496a-8394-c4708721f749_0">
											<gml:posList>35.67047611606256 139.73789031894648 58.192 35.67047611606256 139.73789031894648 61.502 35.67049510039739 139.7379831292428 61.502 35.67047611606256 139.73789031894648 58.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1ee5ccf7-9724-4514-82ca-29ad7c0ffefe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1ee5ccf7-9724-4514-82ca-29ad7c0ffefe_0">
											<gml:posList>35.670393536321924 139.73796369814488 58.715 35.670447975345766 139.73794738432957 60.969 35.670447975345766 139.73794738432957 58.715 35.670393536321924 139.73796369814488 58.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f37483e2-e792-48f5-8063-f89eddb2801a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f37483e2-e792-48f5-8063-f89eddb2801a_0">
											<gml:posList>35.670393536321924 139.73796369814488 58.715 35.670393536321924 139.73796369814488 60.969 35.670447975345766 139.73794738432957 60.969 35.670393536321924 139.73796369814488 58.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e3801bc-29e9-4a68-b920-9869602f9dfc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7e3801bc-29e9-4a68-b920-9869602f9dfc_0">
											<gml:posList>35.670452599722466 139.73797056494698 58.715 35.670447975345766 139.73794738432957 60.969 35.670452599722466 139.73797056494698 60.969 35.670452599722466 139.73797056494698 58.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-006a64f3-cb5d-4ce9-bc81-e937e136fa81">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-006a64f3-cb5d-4ce9-bc81-e937e136fa81_0">
											<gml:posList>35.670452599722466 139.73797056494698 58.715 35.670447975345766 139.73794738432957 58.715 35.670447975345766 139.73794738432957 60.969 35.670452599722466 139.73797056494698 58.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84448eff-edd8-425b-801c-3d9f6dccd3e3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-84448eff-edd8-425b-801c-3d9f6dccd3e3_0">
											<gml:posList>35.67037194357562 139.73795756001704 58.715 35.67036182363302 139.73796068709967 60.689 35.67037194357562 139.73795756001704 60.689 35.67037194357562 139.73795756001704 58.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a51c3238-04e2-489e-8d23-6fc09a1ddfeb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a51c3238-04e2-489e-8d23-6fc09a1ddfeb_0">
											<gml:posList>35.67037194357562 139.73795756001704 58.715 35.67036182363302 139.73796068709967 58.715 35.67036182363302 139.73796068709967 60.689 35.67037194357562 139.73795756001704 58.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-68d23393-8d49-4833-857c-fc689684d0f7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-68d23393-8d49-4833-857c-fc689684d0f7_0">
											<gml:posList>35.670452599722466 139.73797056494698 60.969 35.670393536321924 139.73796369814488 60.969 35.67039816069549 139.7379868787475 60.969 35.670452599722466 139.73797056494698 60.969</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5d2013c-95c1-4efb-910b-3bdfdf861550">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c5d2013c-95c1-4efb-910b-3bdfdf861550_0">
											<gml:posList>35.670452599722466 139.73797056494698 60.969 35.670447975345766 139.73794738432957 60.969 35.670393536321924 139.73796369814488 60.969 35.670452599722466 139.73797056494698 60.969</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2efe7d54-9ce9-49ad-90e7-ee05733f5e79">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2efe7d54-9ce9-49ad-90e7-ee05733f5e79_0">
											<gml:posList>35.67034486137625 139.73792855163023 61.502 35.67036287786469 139.7380171322179 58.715 35.67034486137625 139.73792855163023 58.715 35.67034486137625 139.73792855163023 61.502</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-08ee1b21-98a1-46a2-ad2c-70d5c79ea8eb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-08ee1b21-98a1-46a2-ad2c-70d5c79ea8eb_0">
											<gml:posList>35.67034486137625 139.73792855163023 61.502 35.67036287786469 139.7380171322179 61.502 35.67036287786469 139.7380171322179 58.715 35.67034486137625 139.73792855163023 61.502</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da2ce769-7675-4f23-8f10-25bf72055af4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da2ce769-7675-4f23-8f10-25bf72055af4_0">
											<gml:posList>35.6703591701918 139.73802469226496 58.192 35.670338665211936 139.73792384225294 61.502 35.670338665211936 139.73792384225294 58.192 35.6703591701918 139.73802469226496 58.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4dd2143f-2638-4684-980e-b115f75c3f2d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4dd2143f-2638-4684-980e-b115f75c3f2d_0">
											<gml:posList>35.6703591701918 139.73802469226496 58.192 35.6703591701918 139.73802469226496 61.502 35.670338665211936 139.73792384225294 61.502 35.6703591701918 139.73802469226496 58.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d2db62d3-480b-4415-9c3f-7c0b61b88cea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d2db62d3-480b-4415-9c3f-7c0b61b88cea_0">
											<gml:posList>35.670393536321924 139.73796369814488 58.715 35.67039816069549 139.7379868787475 60.969 35.670393536321924 139.73796369814488 60.969 35.670393536321924 139.73796369814488 58.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ed5f7a0-ef3f-43a1-9565-98b0340a9b38">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3ed5f7a0-ef3f-43a1-9565-98b0340a9b38_0">
											<gml:posList>35.670393536321924 139.73796369814488 58.715 35.67039816069549 139.7379868787475 58.715 35.67039816069549 139.7379868787475 60.969 35.670393536321924 139.73796369814488 58.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7653660-ac44-49d5-8efd-b86944f4098e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f7653660-ac44-49d5-8efd-b86944f4098e_0">
											<gml:posList>35.67038057579322 139.73799938193227 58.715 35.67037194357562 139.73795756001704 60.689 35.67038057579322 139.73799938193227 60.689 35.67038057579322 139.73799938193227 58.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b97fba7-3d93-4a1b-8aef-c42ab212be7d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5b97fba7-3d93-4a1b-8aef-c42ab212be7d_0">
											<gml:posList>35.67038057579322 139.73799938193227 58.715 35.67037194357562 139.73795756001704 58.715 35.67037194357562 139.73795756001704 60.689 35.67038057579322 139.73799938193227 58.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea54b717-3619-4df7-b573-9c3515f926d9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea54b717-3619-4df7-b573-9c3515f926d9_0">
											<gml:posList>35.67037045584955 139.73800250900996 60.689 35.67037194357562 139.73795756001704 60.689 35.67036182363302 139.73796068709967 60.689 35.67037045584955 139.73800250900996 60.689</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c10423ee-4751-44bd-ad70-7ca26d1d7e60">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c10423ee-4751-44bd-ad70-7ca26d1d7e60_0">
											<gml:posList>35.67037045584955 139.73800250900996 60.689 35.67038057579322 139.73799938193227 60.689 35.67037194357562 139.73795756001704 60.689 35.67037045584955 139.73800250900996 60.689</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01607abc-604e-460d-b4b0-6b83e99ae74b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01607abc-604e-460d-b4b0-6b83e99ae74b_0">
											<gml:posList>35.67036287786469 139.7380171322179 61.502 35.67048893141648 139.7379785965605 58.715 35.67036287786469 139.7380171322179 58.715 35.67036287786469 139.7380171322179 61.502</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77ec0ba0-0e1d-4712-a3fd-60a7376260b5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77ec0ba0-0e1d-4712-a3fd-60a7376260b5_0">
											<gml:posList>35.67036287786469 139.7380171322179 61.502 35.67048893141648 139.7379785965605 61.502 35.67048893141648 139.7379785965605 58.715 35.67036287786469 139.7380171322179 61.502</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b336057-1a45-411f-9418-1d26c706f3ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b336057-1a45-411f-9418-1d26c706f3ce_0">
											<gml:posList>35.67049510039739 139.7379831292428 58.192 35.6703591701918 139.73802469226496 61.502 35.6703591701918 139.73802469226496 58.192 35.67049510039739 139.7379831292428 58.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8343c3d-f732-485c-8005-eef2ddf3e135">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8343c3d-f732-485c-8005-eef2ddf3e135_0">
											<gml:posList>35.67049510039739 139.7379831292428 58.192 35.67049510039739 139.7379831292428 61.502 35.6703591701918 139.73802469226496 61.502 35.67049510039739 139.7379831292428 58.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2b74702-5225-43e4-b578-eb24b2a4587e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670444182446 139.7378815088996 58.715 35.67043066066779 139.73785727844322 58.715 35.67043892431513 139.7378548273777 58.715 35.670444182446 139.7378815088996 58.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4078b08b-0a38-4204-b25a-c135c14d78b6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670444182446 139.7378815088996 58.715 35.67043590977565 139.73788394892696 58.715 35.67043066066779 139.73785727844322 58.715 35.670444182446 139.7378815088996 58.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7957c64-f50a-44b2-af1d-58ebfd9fcbda">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670396740595585 139.73785550724867 58.715 35.67041943178697 139.73784871991336 58.715 35.670434843525264 139.73792612484263 58.715 35.670396740595585 139.73785550724867 58.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-534bfa5a-9a55-4047-bd38-9749f521d3c3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67041215232956 139.73793291215736 58.715 35.670396740595585 139.73785550724867 58.715 35.670434843525264 139.73792612484263 58.715 35.67041215232956 139.73793291215736 58.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-32268af6-a574-435d-b5f2-11dd42d45cfe">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670338665211936 139.73792384225294 58.192 35.670341945506586 139.73792295464915 58.192 35.6703591701918 139.73802469226496 58.192 35.670338665211936 139.73792384225294 58.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8920da9b-152d-4f16-9f53-49a85d9e6699">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67049510039739 139.7379831292428 58.192 35.6703591701918 139.73802469226496 58.192 35.67047611606256 139.73789031894648 58.192 35.67049510039739 139.7379831292428 58.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70c577dd-646f-420b-b87f-aeffe1f0301f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670341945506586 139.73792295464915 58.192 35.67033044456336 139.73786682023453 58.192 35.670448873518765 139.73782963003728 58.192 35.670341945506586 139.73792295464915 58.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f92daa1e-1fdc-4b67-8bdc-fec8232e8feb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67047790046429 139.73788991915652 58.192 35.67047611606256 139.73789031894648 58.192 35.670448873518765 139.73782963003728 58.192 35.67047790046429 139.73788991915652 58.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-65bb3537-5b76-474e-b7a9-a55c6d13f12f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6703591701918 139.73802469226496 58.192 35.670341945506586 139.73792295464915 58.192 35.67047611606256 139.73789031894648 58.192 35.6703591701918 139.73802469226496 58.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-386a2fa0-937d-4c4b-b437-42816fa9a545">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67047611606256 139.73789031894648 58.192 35.670341945506586 139.73792295464915 58.192 35.670448873518765 139.73782963003728 58.192 35.67047611606256 139.73789031894648 58.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-239595e5-e919-417e-bbac-2ab8f157f634">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670452599722466 139.73797056494698 58.715 35.670393536321924 139.73796369814488 58.715 35.670447975345766 139.73794738432957 58.715 35.670452599722466 139.73797056494698 58.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-068378ef-aa47-47fe-af5a-b49a0d56917a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670452599722466 139.73797056494698 58.715 35.67039816069549 139.7379868787475 58.715 35.670393536321924 139.73796369814488 58.715 35.670452599722466 139.73797056494698 58.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e2c4056-2725-4667-ab9f-86889d24da60">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67037045584955 139.73800250900996 58.715 35.67037194357562 139.73795756001704 58.715 35.67038057579322 139.73799938193227 58.715 35.67037045584955 139.73800250900996 58.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa8058af-3a71-4419-bee2-bb77eecb84c5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67037045584955 139.73800250900996 58.715 35.67036182363302 139.73796068709967 58.715 35.67037194357562 139.73795756001704 58.715 35.67037045584955 139.73800250900996 58.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_99c502d6-51d0-4d1e-9ecc-369d0425cff1_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d9ce7e09-ecef-433d-9fa7-44984fbc5b85">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67050481093659 139.7379069536191 15.537 35.67051475629502 139.73795651747662 15.537 35.6704948587305 139.73796251718105 15.537 35.670484390701205 139.73791310860491 15.537 35.67050481093659 139.7379069536191 15.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c42b9691-afef-4883-a7a1-0b9f7b2f6a51">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c42b9691-afef-4883-a7a1-0b9f7b2f6a51_0">
											<gml:posList>35.670484390701205 139.73791310860491 58.192 35.670484390701205 139.73791310860491 15.537 35.6704948587305 139.73796251718105 15.537 35.6704948587305 139.73796251718105 58.192 35.670484390701205 139.73791310860491 58.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c6d52d3-8219-4c22-9de6-fceba6ed73eb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2c6d52d3-8219-4c22-9de6-fceba6ed73eb_0">
											<gml:posList>35.67050481093659 139.7379069536191 58.192 35.67050481093659 139.7379069536191 15.537 35.670484390701205 139.73791310860491 15.537 35.670484390701205 139.73791310860491 58.192 35.67050481093659 139.7379069536191 58.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27eac334-fed6-4c0a-a2f8-17da38037269">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-27eac334-fed6-4c0a-a2f8-17da38037269_0">
											<gml:posList>35.670484390701205 139.73791310860491 58.192 35.6704948587305 139.73796251718105 58.192 35.67051475629502 139.73795651747662 58.192 35.67050481093659 139.7379069536191 58.192 35.670484390701205 139.73791310860491 58.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4095973e-c32e-435b-8a46-bb4049775ec0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4095973e-c32e-435b-8a46-bb4049775ec0_0">
											<gml:posList>35.6704948587305 139.73796251718105 58.192 35.6704948587305 139.73796251718105 15.537 35.67051475629502 139.73795651747662 15.537 35.67051475629502 139.73795651747662 58.192 35.6704948587305 139.73796251718105 58.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-505576c2-5276-4b7d-a0e1-2a6fcb27f26c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-505576c2-5276-4b7d-a0e1-2a6fcb27f26c_0">
											<gml:posList>35.67051475629502 139.73795651747662 58.192 35.67051475629502 139.73795651747662 15.537 35.67050481093659 139.7379069536191 15.537 35.67050481093659 139.7379069536191 58.192 35.67051475629502 139.73795651747662 58.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-889aa052-110e-4dc1-b3e8-9a10c7842604">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-889aa052-110e-4dc1-b3e8-9a10c7842604">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-889aa052-110e-4dc1-b3e8-9a10c7842604">
											<gml:posList>35.67033984357631 139.7379207699922 15.537 35.67032841408499 139.73786380702538 15.537 35.67045096252944 139.73782688807427 15.537 35.670478689521524 139.73788468228392 15.537 35.67048439069246 139.73791309755867 15.537 35.6704948587305 139.73796251718105 15.537 35.67049926580403 139.7379844719347 15.537 35.67035796421533 139.73802704655108 15.537 35.670351104740696 139.73799285549882 15.537 35.670330215891745 139.73799914356312 15.537 35.67032393559702 139.73796786804652 15.537 35.67034483344932 139.7379615689176 15.537 35.670336824697124 139.73792167937745 15.537 35.67033984357631 139.7379207699922 15.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5d69faeb-53c1-4ff1-989b-7650d098f31f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d69faeb-53c1-4ff1-989b-7650d098f31f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d69faeb-53c1-4ff1-989b-7650d098f31f">
											<gml:posList>35.67045096252944 139.73782688807427 58.192 35.67032841408499 139.73786380702538 58.192 35.67033984357631 139.7379207699922 58.192 35.670336824697124 139.73792167937745 58.192 35.67035796421533 139.73802704655108 58.192 35.67049926580403 139.7379844719347 58.192 35.6704948587305 139.73796251718105 58.192 35.67048439069246 139.73791309755867 58.192 35.670478689521524 139.73788468228392 58.192 35.67045096252944 139.73782688807427 58.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e51c6dac-fd5b-4b54-90ea-81dd3daa5286">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e51c6dac-fd5b-4b54-90ea-81dd3daa5286">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e51c6dac-fd5b-4b54-90ea-81dd3daa5286">
											<gml:posList>35.67034483344932 139.7379615689176 21.008 35.67032393559702 139.73796786804652 21.008 35.670330215891745 139.73799914356312 21.008 35.670351104740696 139.73799285549882 21.008 35.67034483344932 139.7379615689176 21.008</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1cb57cb9-64b8-437b-9b64-93a331f66cd7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1cb57cb9-64b8-437b-9b64-93a331f66cd7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1cb57cb9-64b8-437b-9b64-93a331f66cd7">
											<gml:posList>35.67032393559702 139.73796786804652 15.537 35.670330215891745 139.73799914356312 15.537 35.670330215891745 139.73799914356312 21.008 35.67032393559702 139.73796786804652 21.008 35.67032393559702 139.73796786804652 15.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5b7a809f-71b3-43ea-81a6-38f2e6001c78">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b7a809f-71b3-43ea-81a6-38f2e6001c78">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b7a809f-71b3-43ea-81a6-38f2e6001c78">
											<gml:posList>35.67034483344932 139.7379615689176 15.537 35.67032393559702 139.73796786804652 15.537 35.67032393559702 139.73796786804652 21.008 35.67034483344932 139.7379615689176 21.008 35.67034483344932 139.7379615689176 15.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c709d33a-1832-42c9-9943-f680e2a2cb6c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c709d33a-1832-42c9-9943-f680e2a2cb6c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c709d33a-1832-42c9-9943-f680e2a2cb6c">
											<gml:posList>35.67033984357631 139.7379207699922 15.537 35.670336824697124 139.73792167937745 15.537 35.670336824697124 139.73792167937745 58.192 35.67033984357631 139.7379207699922 58.192 35.67033984357631 139.7379207699922 15.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-af8b2814-ad1e-478b-abe9-a2760ae9c84b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af8b2814-ad1e-478b-abe9-a2760ae9c84b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af8b2814-ad1e-478b-abe9-a2760ae9c84b">
											<gml:posList>35.670330215891745 139.73799914356312 15.537 35.670351104740696 139.73799285549882 15.537 35.670351104740696 139.73799285549882 21.008 35.670330215891745 139.73799914356312 21.008 35.670330215891745 139.73799914356312 15.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-65471cf6-3e3d-4aa7-9601-efd75bd097c3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65471cf6-3e3d-4aa7-9601-efd75bd097c3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65471cf6-3e3d-4aa7-9601-efd75bd097c3">
											<gml:posList>35.67035796421533 139.73802704655108 15.537 35.67035796421533 139.73802704655108 58.192 35.670336824697124 139.73792167937745 58.192 35.670336824697124 139.73792167937745 15.537 35.67034483344932 139.7379615689176 15.537 35.67034483344932 139.7379615689176 21.008 35.670351104740696 139.73799285549882 21.008 35.670351104740696 139.73799285549882 15.537 35.67035796421533 139.73802704655108 15.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-64fc9b61-8a40-4160-9aaf-cb7f223131e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-64fc9b61-8a40-4160-9aaf-cb7f223131e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-64fc9b61-8a40-4160-9aaf-cb7f223131e6">
											<gml:posList>35.67035796421533 139.73802704655108 15.537 35.67049926580403 139.7379844719347 15.537 35.67049926580403 139.7379844719347 58.192 35.67035796421533 139.73802704655108 58.192 35.67035796421533 139.73802704655108 15.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6721fab1-9e0c-44bf-a8cb-53c3d73e7202">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6721fab1-9e0c-44bf-a8cb-53c3d73e7202">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6721fab1-9e0c-44bf-a8cb-53c3d73e7202">
											<gml:posList>35.67048439069246 139.73791309755867 15.537 35.670478689521524 139.73788468228392 15.537 35.670478689521524 139.73788468228392 58.192 35.67048439069246 139.73791309755867 58.192 35.67048439069246 139.73791309755867 15.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d7cb1fe6-86a2-4e06-b4b0-d18f9ac5ae54">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7cb1fe6-86a2-4e06-b4b0-d18f9ac5ae54">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7cb1fe6-86a2-4e06-b4b0-d18f9ac5ae54">
											<gml:posList>35.6704948587305 139.73796251718105 15.537 35.67048439069246 139.73791309755867 15.537 35.67048439069246 139.73791309755867 58.192 35.6704948587305 139.73796251718105 58.192 35.6704948587305 139.73796251718105 15.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-27968367-cbd1-475b-a98b-8957d7722fd5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-27968367-cbd1-475b-a98b-8957d7722fd5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-27968367-cbd1-475b-a98b-8957d7722fd5">
											<gml:posList>35.67049926580403 139.7379844719347 15.537 35.6704948587305 139.73796251718105 15.537 35.6704948587305 139.73796251718105 58.192 35.67049926580403 139.7379844719347 58.192 35.67049926580403 139.7379844719347 15.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ae2a12e3-5651-48f1-87b9-64b749d0c73e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ae2a12e3-5651-48f1-87b9-64b749d0c73e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ae2a12e3-5651-48f1-87b9-64b749d0c73e">
											<gml:posList>35.67032841408499 139.73786380702538 15.537 35.67033984357631 139.7379207699922 15.537 35.67033984357631 139.7379207699922 58.192 35.67032841408499 139.73786380702538 58.192 35.67032841408499 139.73786380702538 15.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-425d5710-08bb-4274-bede-c4d693d695ea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-425d5710-08bb-4274-bede-c4d693d695ea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-425d5710-08bb-4274-bede-c4d693d695ea">
											<gml:posList>35.67045096252944 139.73782688807427 15.537 35.67032841408499 139.73786380702538 15.537 35.67032841408499 139.73786380702538 58.192 35.67045096252944 139.73782688807427 58.192 35.67045096252944 139.73782688807427 15.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-27124c1a-6350-46c0-9685-85d4c4ac8680">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-27124c1a-6350-46c0-9685-85d4c4ac8680">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-27124c1a-6350-46c0-9685-85d4c4ac8680">
											<gml:posList>35.670478689521524 139.73788468228392 15.537 35.67045096252944 139.73782688807427 15.537 35.67045096252944 139.73782688807427 58.192 35.670478689521524 139.73788468228392 58.192 35.670478689521524 139.73788468228392 15.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-9201</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">262.29655</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1241</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>