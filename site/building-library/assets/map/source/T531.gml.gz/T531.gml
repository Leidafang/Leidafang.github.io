<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_99dab82f-55cf-48d3-a0a9-c09488d9e270">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="説明注記">
				<gen:value>自動販売機</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">4.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>0</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.668577152822465 139.7481352032142 0 35.66858263908099 139.74811807606534 0 35.668565867841565 139.7481100303017 0 35.66856029191587 139.74812782030335 0 35.668577152822465 139.7481352032142 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668577152822465 139.7481352032142 5.44 35.66856029191587 139.74812782030335 5.44 35.668565867841565 139.7481100303017 5.44 35.66858263908099 139.74811807606534 5.44 35.668577152822465 139.7481352032142 5.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668577152822465 139.7481352032142 5.44 35.66858263908099 139.74811807606534 5.44 35.66858263908099 139.74811807606534 9.96 35.668577152822465 139.7481352032142 9.96 35.668577152822465 139.7481352032142 5.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66858263908099 139.74811807606534 5.44 35.668565867841565 139.7481100303017 5.44 35.668565867841565 139.7481100303017 9.96 35.66858263908099 139.74811807606534 9.96 35.66858263908099 139.74811807606534 5.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668565867841565 139.7481100303017 5.44 35.66856029191587 139.74812782030335 5.44 35.66856029191587 139.74812782030335 9.96 35.668565867841565 139.7481100303017 9.96 35.668565867841565 139.7481100303017 5.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66856029191587 139.74812782030335 5.44 35.668577152822465 139.7481352032142 5.44 35.668577152822465 139.7481352032142 9.96 35.66856029191587 139.74812782030335 9.96 35.66856029191587 139.74812782030335 5.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668577152822465 139.7481352032142 9.96 35.66858263908099 139.74811807606534 9.96 35.668565867841565 139.7481100303017 9.96 35.66856029191587 139.74812782030335 9.96 35.668577152822465 139.7481352032142 9.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-8663f6b1-0a11-448d-828a-d8b17f69f353"/>
							<gml:surfaceMember xlink:href="#poly-edb98ac7-938c-4325-9e9e-fd1aa8a848b2"/>
							<gml:surfaceMember xlink:href="#poly-9813e748-9439-4bab-97d3-4c25fd118d40"/>
							<gml:surfaceMember xlink:href="#poly-bb0f25c8-da41-46b4-aeda-21fd3b32c73d"/>
							<gml:surfaceMember xlink:href="#poly-fe3a59c3-952a-4f01-990b-9316c9f1c4e4"/>
							<gml:surfaceMember xlink:href="#poly-4dbb6748-6f34-4573-aa54-9e6ac05fcdcc"/>
							<gml:surfaceMember xlink:href="#poly-2752e336-a106-45f3-8259-21c704ad10de"/>
							<gml:surfaceMember xlink:href="#poly-7a76964f-60df-4922-ba39-51918a0a7fc2"/>
							<gml:surfaceMember xlink:href="#poly-5d519b02-c3af-46b5-8dc9-2e5fd573fa9f"/>
							<gml:surfaceMember xlink:href="#poly-1f463834-6ffd-4ffe-9d42-8444fd075039"/>
							<gml:surfaceMember xlink:href="#poly-d4067828-978d-41f8-bac9-379baeb86ad2"/>
							<gml:surfaceMember xlink:href="#poly-dbfc736a-2203-48b1-b2a7-564a757bc2e6"/>
							<gml:surfaceMember xlink:href="#poly-cc7c910f-6222-4d16-b9b6-00ffb10f510b"/>
							<gml:surfaceMember xlink:href="#poly-0b265c2d-79ee-4ff4-bd7d-4f5357ef397f"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-8663f6b1-0a11-448d-828a-d8b17f69f353">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8663f6b1-0a11-448d-828a-d8b17f69f353">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8663f6b1-0a11-448d-828a-d8b17f69f353">
											<gml:posList>35.66857715282244 139.7481352032142 5.44 35.668560291915846 139.74812782030335 5.44 35.66856586784155 139.7481100303017 5.44 35.66858263908097 139.74811807606534 5.44 35.66857715282244 139.7481352032142 5.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-edb98ac7-938c-4325-9e9e-fd1aa8a848b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-edb98ac7-938c-4325-9e9e-fd1aa8a848b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-edb98ac7-938c-4325-9e9e-fd1aa8a848b2">
											<gml:posList>35.668560291915846 139.74812782030335 9.3 35.66856193175766 139.74812689069597 9.3 35.668566590362545 139.74811203990762 9.3 35.66856586784155 139.7481100303017 9.3 35.668560291915846 139.74812782030335 9.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9813e748-9439-4bab-97d3-4c25fd118d40">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9813e748-9439-4bab-97d3-4c25fd118d40">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9813e748-9439-4bab-97d3-4c25fd118d40">
											<gml:posList>35.66857715282244 139.7481352032142 9.3 35.66857642131937 139.74813323780134 9.3 35.66856193175766 139.74812689069597 9.3 35.668560291915846 139.74812782030335 9.3 35.66857715282244 139.7481352032142 9.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bb0f25c8-da41-46b4-aeda-21fd3b32c73d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb0f25c8-da41-46b4-aeda-21fd3b32c73d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb0f25c8-da41-46b4-aeda-21fd3b32c73d">
											<gml:posList>35.66857642131937 139.74813323780134 9.039 35.66858099920796 139.7481189614891 9.039 35.668566590362545 139.74811203990762 9.039 35.66856193175766 139.74812689069597 9.039 35.66857642131937 139.74813323780134 9.039</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fe3a59c3-952a-4f01-990b-9316c9f1c4e4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe3a59c3-952a-4f01-990b-9316c9f1c4e4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe3a59c3-952a-4f01-990b-9316c9f1c4e4">
											<gml:posList>35.66856586784155 139.7481100303017 9.3 35.668566590362545 139.74811203990762 9.3 35.66858099920796 139.7481189614891 9.3 35.66858263908097 139.74811807606534 9.3 35.66856586784155 139.7481100303017 9.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4dbb6748-6f34-4573-aa54-9e6ac05fcdcc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4dbb6748-6f34-4573-aa54-9e6ac05fcdcc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4dbb6748-6f34-4573-aa54-9e6ac05fcdcc">
											<gml:posList>35.66858263908097 139.74811807606534 9.3 35.66858099920796 139.7481189614891 9.3 35.66857642131937 139.74813323780134 9.3 35.66857715282244 139.7481352032142 9.3 35.66858263908097 139.74811807606534 9.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2752e336-a106-45f3-8259-21c704ad10de">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2752e336-a106-45f3-8259-21c704ad10de">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2752e336-a106-45f3-8259-21c704ad10de">
											<gml:posList>35.66858263908097 139.74811807606534 5.44 35.66856586784155 139.7481100303017 5.44 35.66856586784155 139.7481100303017 9.3 35.66858263908097 139.74811807606534 9.3 35.66858263908097 139.74811807606534 5.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7a76964f-60df-4922-ba39-51918a0a7fc2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a76964f-60df-4922-ba39-51918a0a7fc2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a76964f-60df-4922-ba39-51918a0a7fc2">
											<gml:posList>35.668566590362545 139.74811203990762 9.3 35.668566590362545 139.74811203990762 9.039 35.66858099920796 139.7481189614891 9.039 35.66858099920796 139.7481189614891 9.3 35.668566590362545 139.74811203990762 9.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5d519b02-c3af-46b5-8dc9-2e5fd573fa9f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d519b02-c3af-46b5-8dc9-2e5fd573fa9f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d519b02-c3af-46b5-8dc9-2e5fd573fa9f">
											<gml:posList>35.66856586784155 139.7481100303017 5.44 35.668560291915846 139.74812782030335 5.44 35.668560291915846 139.74812782030335 9.3 35.66856586784155 139.7481100303017 9.3 35.66856586784155 139.7481100303017 5.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1f463834-6ffd-4ffe-9d42-8444fd075039">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f463834-6ffd-4ffe-9d42-8444fd075039">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f463834-6ffd-4ffe-9d42-8444fd075039">
											<gml:posList>35.66856193175766 139.74812689069597 9.3 35.66856193175766 139.74812689069597 9.039 35.668566590362545 139.74811203990762 9.039 35.668566590362545 139.74811203990762 9.3 35.66856193175766 139.74812689069597 9.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d4067828-978d-41f8-bac9-379baeb86ad2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4067828-978d-41f8-bac9-379baeb86ad2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4067828-978d-41f8-bac9-379baeb86ad2">
											<gml:posList>35.66858099920796 139.7481189614891 9.3 35.66858099920796 139.7481189614891 9.039 35.66857642131937 139.74813323780134 9.039 35.66857642131937 139.74813323780134 9.3 35.66858099920796 139.7481189614891 9.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dbfc736a-2203-48b1-b2a7-564a757bc2e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dbfc736a-2203-48b1-b2a7-564a757bc2e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dbfc736a-2203-48b1-b2a7-564a757bc2e6">
											<gml:posList>35.66857715282244 139.7481352032142 5.44 35.66858263908097 139.74811807606534 5.44 35.66858263908097 139.74811807606534 9.3 35.66857715282244 139.7481352032142 9.3 35.66857715282244 139.7481352032142 5.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cc7c910f-6222-4d16-b9b6-00ffb10f510b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc7c910f-6222-4d16-b9b6-00ffb10f510b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc7c910f-6222-4d16-b9b6-00ffb10f510b">
											<gml:posList>35.66857642131937 139.74813323780134 9.3 35.66857642131937 139.74813323780134 9.039 35.66856193175766 139.74812689069597 9.039 35.66856193175766 139.74812689069597 9.3 35.66857642131937 139.74813323780134 9.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0b265c2d-79ee-4ff4-bd7d-4f5357ef397f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b265c2d-79ee-4ff4-bd7d-4f5357ef397f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b265c2d-79ee-4ff4-bd7d-4f5357ef397f">
											<gml:posList>35.668560291915846 139.74812782030335 5.44 35.66857715282244 139.7481352032142 5.44 35.66857715282244 139.7481352032142 9.3 35.668560291915846 139.74812782030335 9.3 35.668560291915846 139.74812782030335 5.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10958</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">3.3772</uro:buildingRoofEdgeArea>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.35</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">3</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>