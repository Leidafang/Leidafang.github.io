<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_9ae7cf8a-271d-4ab2-8b02-e375833f785c">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">9.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.668606035079506 139.73992223917423 0 35.66864655021345 139.73986210162323 0 35.668582863222284 139.7397976671561 0 35.66854234812008 139.73985780469178 0 35.668606035079506 139.73992223917423 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668606035079506 139.73992223917423 11.22 35.66854234812008 139.73985780469178 11.22 35.668582863222284 139.7397976671561 11.22 35.66864655021345 139.73986210162323 11.22 35.668606035079506 139.73992223917423 11.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668606035079506 139.73992223917423 11.22 35.66864655021345 139.73986210162323 11.22 35.66864655021345 139.73986210162323 20.74 35.668606035079506 139.73992223917423 20.74 35.668606035079506 139.73992223917423 11.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66864655021345 139.73986210162323 11.22 35.668582863222284 139.7397976671561 11.22 35.668582863222284 139.7397976671561 20.74 35.66864655021345 139.73986210162323 20.74 35.66864655021345 139.73986210162323 11.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668582863222284 139.7397976671561 11.22 35.66854234812008 139.73985780469178 11.22 35.66854234812008 139.73985780469178 20.74 35.668582863222284 139.7397976671561 20.74 35.668582863222284 139.7397976671561 11.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66854234812008 139.73985780469178 11.22 35.668606035079506 139.73992223917423 11.22 35.668606035079506 139.73992223917423 20.74 35.66854234812008 139.73985780469178 20.74 35.66854234812008 139.73985780469178 11.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668606035079506 139.73992223917423 20.74 35.66864655021345 139.73986210162323 20.74 35.668582863222284 139.7397976671561 20.74 35.66854234812008 139.73985780469178 20.74 35.668606035079506 139.73992223917423 20.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-9b150076-515f-4ec9-aa88-b1eb78d084fc"/>
							<gml:surfaceMember xlink:href="#poly-52cd52b4-5286-4f26-b6f6-580ac8fe0ba9"/>
							<gml:surfaceMember xlink:href="#poly-f9ad2ef2-df92-45a3-bd8a-b01df24da91c"/>
							<gml:surfaceMember xlink:href="#poly-6280233d-1cdd-405d-8d6d-1fab77795c63"/>
							<gml:surfaceMember xlink:href="#poly-8a49c5a8-f4f8-468b-bf34-d05b3fc20b20"/>
							<gml:surfaceMember xlink:href="#poly-1b092d10-b5e2-4680-8037-3b106e05fd78"/>
							<gml:surfaceMember xlink:href="#poly-828005f4-3570-42d1-a695-c9a6d643d35d"/>
							<gml:surfaceMember xlink:href="#poly-a6731e81-7fe5-4a62-853f-ce832a50d4da"/>
							<gml:surfaceMember xlink:href="#poly-b2879a73-4cf5-4a8f-bae6-50028993ca28"/>
							<gml:surfaceMember xlink:href="#poly-eecf9f78-fd65-4684-8a16-57b0ba0db107"/>
							<gml:surfaceMember xlink:href="#poly-9f32a775-7d9e-48e2-b7cc-b9107c763467"/>
							<gml:surfaceMember xlink:href="#poly-7f0d07bb-e618-4ccd-9168-e0c172140f89"/>
							<gml:surfaceMember xlink:href="#poly-70a3609b-6292-4706-85d0-5c4cc98df896"/>
							<gml:surfaceMember xlink:href="#poly-ace93a74-1861-4b6a-b63b-4944e69c5e97"/>
							<gml:surfaceMember xlink:href="#poly-1e68c9e9-44ae-4c68-be34-d70a9707e500"/>
							<gml:surfaceMember xlink:href="#poly-a99fb42b-941f-46f1-a388-18a5c376b5a1"/>
							<gml:surfaceMember xlink:href="#poly-ef31be4a-8fa1-4ce0-8019-6e6379c001d7"/>
							<gml:surfaceMember xlink:href="#poly-710b0a7a-e80a-41d0-90f6-20c8231ab9cd"/>
							<gml:surfaceMember xlink:href="#poly-d61a4c98-e5f7-4ee7-b313-2ee6b822097f"/>
							<gml:surfaceMember xlink:href="#poly-a0ab94a7-f58c-46dd-a160-19ea4a3db4ce"/>
							<gml:surfaceMember xlink:href="#poly-05cc8582-99fe-49ac-a5e0-19df4788c1f2"/>
							<gml:surfaceMember xlink:href="#poly-cbf45910-7d74-44b0-a1c6-de2498894ac3"/>
							<gml:surfaceMember xlink:href="#poly-30be7a88-3d95-42a3-bb2e-4f840d065197"/>
							<gml:surfaceMember xlink:href="#poly-b064a5c3-e98c-47b1-a45a-cc2404a485ce"/>
							<gml:surfaceMember xlink:href="#poly-5b24f1b5-8a0a-43cf-84b4-68ef57907124"/>
							<gml:surfaceMember xlink:href="#poly-17c00114-d966-4b79-bc3f-e992ae383b74"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-9b150076-515f-4ec9-aa88-b1eb78d084fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b150076-515f-4ec9-aa88-b1eb78d084fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b150076-515f-4ec9-aa88-b1eb78d084fc">
											<gml:posList>35.668606035079485 139.73992223917423 11.22 35.66854234812007 139.73985780469178 11.22 35.66858286322227 139.73979766715613 11.22 35.66864655021343 139.7398621016232 11.22 35.668606035079485 139.73992223917423 11.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-52cd52b4-5286-4f26-b6f6-580ac8fe0ba9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-52cd52b4-5286-4f26-b6f6-580ac8fe0ba9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-52cd52b4-5286-4f26-b6f6-580ac8fe0ba9">
											<gml:posList>35.66855557999217 139.73986904514854 21.103 35.6685682117406 139.73985034057597 21.103 35.668567174321794 139.73984925927653 21.103 35.66855368728991 139.73986927932089 21.103 35.66855557999217 139.73986904514854 21.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f9ad2ef2-df92-45a3-bd8a-b01df24da91c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9ad2ef2-df92-45a3-bd8a-b01df24da91c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9ad2ef2-df92-45a3-bd8a-b01df24da91c">
											<gml:posList>35.66858286322227 139.73979766715613 18.59 35.66854234812007 139.73985780469178 18.59 35.66855368728991 139.73986927932089 21.103 35.66858286322227 139.73979766715613 18.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6280233d-1cdd-405d-8d6d-1fab77795c63">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6280233d-1cdd-405d-8d6d-1fab77795c63">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6280233d-1cdd-405d-8d6d-1fab77795c63">
											<gml:posList>35.66858286322227 139.73979766715613 18.59 35.66855368728991 139.73986927932089 21.103 35.668567174321794 139.73984925927653 21.103 35.66858286322227 139.73979766715613 18.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8a49c5a8-f4f8-468b-bf34-d05b3fc20b20">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a49c5a8-f4f8-468b-bf34-d05b3fc20b20">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a49c5a8-f4f8-468b-bf34-d05b3fc20b20">
											<gml:posList>35.668567174321794 139.73984925927653 21.103 35.66858110312389 139.73986419933675 23.98 35.66858066135032 139.73982923922543 21.103 35.668567174321794 139.73984925927653 21.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1b092d10-b5e2-4680-8037-3b106e05fd78">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b092d10-b5e2-4680-8037-3b106e05fd78">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b092d10-b5e2-4680-8037-3b106e05fd78">
											<gml:posList>35.66858286322227 139.73979766715613 18.59 35.668567174321794 139.73984925927653 21.103 35.66858066135032 139.73982923922543 21.103 35.66858286322227 139.73979766715613 18.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-828005f4-3570-42d1-a695-c9a6d643d35d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-828005f4-3570-42d1-a695-c9a6d643d35d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-828005f4-3570-42d1-a695-c9a6d643d35d">
											<gml:posList>35.668606035079485 139.73992223917423 21.103 35.66860585300551 139.7399199197232 21.103 35.66855557999217 139.73986904514854 21.103 35.66855368728991 139.73986927932089 21.103 35.668606035079485 139.73992223917423 21.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a6731e81-7fe5-4a62-853f-ce832a50d4da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a6731e81-7fe5-4a62-853f-ce832a50d4da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a6731e81-7fe5-4a62-853f-ce832a50d4da">
											<gml:posList>35.66858286322227 139.73979766715613 18.59 35.66858066135032 139.73982923922543 21.103 35.66859420239777 139.73980914178247 21.103 35.66858286322227 139.73979766715613 18.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b2879a73-4cf5-4a8f-bae6-50028993ca28">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b2879a73-4cf5-4a8f-bae6-50028993ca28">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b2879a73-4cf5-4a8f-bae6-50028993ca28">
											<gml:posList>35.66859438446531 139.7398114501869 21.103 35.66859420239777 139.73980914178247 21.103 35.66858066135032 139.73982923922543 21.103 35.668581698743566 139.73983028738678 21.103 35.66859438446531 139.7398114501869 21.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-eecf9f78-fd65-4684-8a16-57b0ba0db107">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eecf9f78-fd65-4684-8a16-57b0ba0db107">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eecf9f78-fd65-4684-8a16-57b0ba0db107">
											<gml:posList>35.66858110312389 139.73986419933675 23.98 35.668594923268195 139.73984367077963 23.98 35.66858066135032 139.73982923922543 21.103 35.66858110312389 139.73986419933675 23.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9f32a775-7d9e-48e2-b7cc-b9107c763467">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f32a775-7d9e-48e2-b7cc-b9107c763467">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f32a775-7d9e-48e2-b7cc-b9107c763467">
											<gml:posList>35.668594923268195 139.73984367077963 23.98 35.66858110312389 139.73986419933675 23.98 35.668597701426975 139.73988099202114 23.98 35.66861152158268 139.73986047450867 23.98 35.668594923268195 139.73984367077963 23.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7f0d07bb-e618-4ccd-9168-e0c172140f89">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f0d07bb-e618-4ccd-9168-e0c172140f89">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f0d07bb-e618-4ccd-9168-e0c172140f89">
											<gml:posList>35.668597701426975 139.73988099202114 20.822 35.6685682117406 139.73985034057597 20.822 35.66855557999217 139.73986904514854 20.822 35.66860585300551 139.7399199197232 20.822 35.66864466650779 139.73986231369346 20.822 35.66859438446531 139.7398114501869 20.822 35.668581698743566 139.73983028738678 20.822 35.66861152158268 139.73986047450867 20.822 35.668597701426975 139.73988099202114 20.822</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-70a3609b-6292-4706-85d0-5c4cc98df896">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70a3609b-6292-4706-85d0-5c4cc98df896">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70a3609b-6292-4706-85d0-5c4cc98df896">
											<gml:posList>35.66859420239777 139.73980914178247 21.103 35.66859438446531 139.7398114501869 21.103 35.66864466650779 139.73986231369346 21.103 35.66864655021343 139.7398621016232 21.103 35.66859420239777 139.73980914178247 21.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ace93a74-1861-4b6a-b63b-4944e69c5e97">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ace93a74-1861-4b6a-b63b-4944e69c5e97">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ace93a74-1861-4b6a-b63b-4944e69c5e97">
											<gml:posList>35.66864655021343 139.7398621016232 21.103 35.66864466650779 139.73986231369346 21.103 35.66860585300551 139.7399199197232 21.103 35.668606035079485 139.73992223917423 21.103 35.66864655021343 139.7398621016232 21.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1e68c9e9-44ae-4c68-be34-d70a9707e500">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e68c9e9-44ae-4c68-be34-d70a9707e500">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e68c9e9-44ae-4c68-be34-d70a9707e500">
											<gml:posList>35.66859438446531 139.7398114501869 21.103 35.66859438446531 139.7398114501869 20.822 35.66864466650779 139.73986231369346 20.822 35.66864466650779 139.73986231369346 21.103 35.66859438446531 139.7398114501869 21.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a99fb42b-941f-46f1-a388-18a5c376b5a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a99fb42b-941f-46f1-a388-18a5c376b5a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a99fb42b-941f-46f1-a388-18a5c376b5a1">
											<gml:posList>35.668581698743566 139.73983028738678 21.103 35.668581698743566 139.73983028738678 20.822 35.66859438446531 139.7398114501869 20.822 35.66859438446531 139.7398114501869 21.103 35.668581698743566 139.73983028738678 21.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ef31be4a-8fa1-4ce0-8019-6e6379c001d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef31be4a-8fa1-4ce0-8019-6e6379c001d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef31be4a-8fa1-4ce0-8019-6e6379c001d7">
											<gml:posList>35.66858286322227 139.73979766715613 11.22 35.66854234812007 139.73985780469178 11.22 35.66854234812007 139.73985780469178 18.59 35.66858286322227 139.73979766715613 18.59 35.66858286322227 139.73979766715613 11.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-710b0a7a-e80a-41d0-90f6-20c8231ab9cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-710b0a7a-e80a-41d0-90f6-20c8231ab9cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-710b0a7a-e80a-41d0-90f6-20c8231ab9cd">
											<gml:posList>35.66858286322227 139.73979766715613 18.59 35.66859420239777 139.73980914178247 21.103 35.66864655021343 139.7398621016232 21.103 35.66864655021343 139.7398621016232 11.22 35.66858286322227 139.73979766715613 11.22 35.66858286322227 139.73979766715613 18.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d61a4c98-e5f7-4ee7-b313-2ee6b822097f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d61a4c98-e5f7-4ee7-b313-2ee6b822097f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d61a4c98-e5f7-4ee7-b313-2ee6b822097f">
											<gml:posList>35.668581698743566 139.73983028738678 21.103 35.66858066135032 139.73982923922543 21.103 35.668594923268195 139.73984367077963 23.98 35.66861152158268 139.73986047450867 23.98 35.66861152158268 139.73986047450867 20.822 35.668581698743566 139.73983028738678 20.822 35.668581698743566 139.73983028738678 21.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a0ab94a7-f58c-46dd-a160-19ea4a3db4ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a0ab94a7-f58c-46dd-a160-19ea4a3db4ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a0ab94a7-f58c-46dd-a160-19ea4a3db4ce">
											<gml:posList>35.66855557999217 139.73986904514854 21.103 35.66855557999217 139.73986904514854 20.822 35.6685682117406 139.73985034057597 20.822 35.6685682117406 139.73985034057597 21.103 35.66855557999217 139.73986904514854 21.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-05cc8582-99fe-49ac-a5e0-19df4788c1f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-05cc8582-99fe-49ac-a5e0-19df4788c1f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-05cc8582-99fe-49ac-a5e0-19df4788c1f2">
											<gml:posList>35.66858110312389 139.73986419933675 23.98 35.668567174321794 139.73984925927653 21.103 35.6685682117406 139.73985034057597 21.103 35.6685682117406 139.73985034057597 20.822 35.668597701426975 139.73988099202114 20.822 35.668597701426975 139.73988099202114 23.98 35.66858110312389 139.73986419933675 23.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cbf45910-7d74-44b0-a1c6-de2498894ac3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cbf45910-7d74-44b0-a1c6-de2498894ac3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cbf45910-7d74-44b0-a1c6-de2498894ac3">
											<gml:posList>35.668597701426975 139.73988099202114 20.822 35.66861152158268 139.73986047450867 20.822 35.66861152158268 139.73986047450867 23.98 35.668597701426975 139.73988099202114 23.98 35.668597701426975 139.73988099202114 20.822</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-30be7a88-3d95-42a3-bb2e-4f840d065197">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-30be7a88-3d95-42a3-bb2e-4f840d065197">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-30be7a88-3d95-42a3-bb2e-4f840d065197">
											<gml:posList>35.668606035079485 139.73992223917423 21.103 35.66855368728991 139.73986927932089 21.103 35.66854234812007 139.73985780469178 18.59 35.66854234812007 139.73985780469178 11.22 35.668606035079485 139.73992223917423 11.22 35.668606035079485 139.73992223917423 21.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b064a5c3-e98c-47b1-a45a-cc2404a485ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b064a5c3-e98c-47b1-a45a-cc2404a485ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b064a5c3-e98c-47b1-a45a-cc2404a485ce">
											<gml:posList>35.66864466650779 139.73986231369346 21.103 35.66864466650779 139.73986231369346 20.822 35.66860585300551 139.7399199197232 20.822 35.66860585300551 139.7399199197232 21.103 35.66864466650779 139.73986231369346 21.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5b24f1b5-8a0a-43cf-84b4-68ef57907124">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b24f1b5-8a0a-43cf-84b4-68ef57907124">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b24f1b5-8a0a-43cf-84b4-68ef57907124">
											<gml:posList>35.668606035079485 139.73992223917423 11.22 35.66864655021343 139.7398621016232 11.22 35.66864655021343 139.7398621016232 21.103 35.668606035079485 139.73992223917423 21.103 35.668606035079485 139.73992223917423 11.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-17c00114-d966-4b79-bc3f-e992ae383b74">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17c00114-d966-4b79-bc3f-e992ae383b74">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17c00114-d966-4b79-bc3f-e992ae383b74">
											<gml:posList>35.66860585300551 139.7399199197232 21.103 35.66860585300551 139.7399199197232 20.822 35.66855557999217 139.73986904514854 20.822 35.66855557999217 139.73986904514854 21.103 35.66860585300551 139.7399199197232 21.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10765</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">64.6864</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.04</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>