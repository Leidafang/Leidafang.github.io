<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_9af70650-ca86-4458-90f2-055543cf4562">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門駅南地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">28.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>7</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66840066577394 139.7492664446321 0 35.66837234429221 139.74925306450106 0 35.66838719325305 139.749206224997 0 35.66833992753115 139.74918371869782 0 35.668296847491405 139.749320844437 0 35.668372227375045 139.7493567753643 0 35.66840066577394 139.7492664446321 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66840066577394 139.7492664446321 5.28 35.668372227375045 139.7493567753643 5.28 35.668296847491405 139.749320844437 5.28 35.66833992753115 139.74918371869782 5.28 35.66838719325305 139.749206224997 5.28 35.66837234429221 139.74925306450106 5.28 35.66840066577394 139.7492664446321 5.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66840066577394 139.7492664446321 5.28 35.66837234429221 139.74925306450106 5.28 35.66837234429221 139.74925306450106 30.89 35.66840066577394 139.7492664446321 30.89 35.66840066577394 139.7492664446321 5.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66837234429221 139.74925306450106 5.28 35.66838719325305 139.749206224997 5.28 35.66838719325305 139.749206224997 30.89 35.66837234429221 139.74925306450106 30.89 35.66837234429221 139.74925306450106 5.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66838719325305 139.749206224997 5.28 35.66833992753115 139.74918371869782 5.28 35.66833992753115 139.74918371869782 30.89 35.66838719325305 139.749206224997 30.89 35.66838719325305 139.749206224997 5.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66833992753115 139.74918371869782 5.28 35.668296847491405 139.749320844437 5.28 35.668296847491405 139.749320844437 30.89 35.66833992753115 139.74918371869782 30.89 35.66833992753115 139.74918371869782 5.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668296847491405 139.749320844437 5.28 35.668372227375045 139.7493567753643 5.28 35.668372227375045 139.7493567753643 30.89 35.668296847491405 139.749320844437 30.89 35.668296847491405 139.749320844437 5.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668372227375045 139.7493567753643 5.28 35.66840066577394 139.7492664446321 5.28 35.66840066577394 139.7492664446321 30.89 35.668372227375045 139.7493567753643 30.89 35.668372227375045 139.7493567753643 5.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66840066577394 139.7492664446321 30.89 35.66837234429221 139.74925306450106 30.89 35.66838719325305 139.749206224997 30.89 35.66833992753115 139.74918371869782 30.89 35.668296847491405 139.749320844437 30.89 35.668372227375045 139.7493567753643 30.89 35.66840066577394 139.7492664446321 30.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-682c202a-6392-4f7f-9bfc-573746ff1a28"/>
							<gml:surfaceMember xlink:href="#poly-7ec0b096-bdf8-41f8-8e34-604305402033"/>
							<gml:surfaceMember xlink:href="#poly-566d6330-0549-43c7-954e-6c279152f983"/>
							<gml:surfaceMember xlink:href="#poly-262f1f07-86ad-4837-a982-7be29361916a"/>
							<gml:surfaceMember xlink:href="#poly-0d255121-0339-46e6-8bfc-3927e0be5b62"/>
							<gml:surfaceMember xlink:href="#poly-e8f3dfce-6282-4539-a5be-80f41f6875b8"/>
							<gml:surfaceMember xlink:href="#poly-871eaa59-8183-41d9-b3f8-eeec78751dba"/>
							<gml:surfaceMember xlink:href="#poly-4de0540d-9db2-4b4b-9f02-7b1d4c097319"/>
							<gml:surfaceMember xlink:href="#poly-8aee6126-b218-4a50-ba74-563cfb31451a"/>
							<gml:surfaceMember xlink:href="#poly-0e9fd296-5b6d-45e0-b685-9edec54f4108"/>
							<gml:surfaceMember xlink:href="#poly-4c7a5057-1f98-4bd4-acac-c275ee5792f9"/>
							<gml:surfaceMember xlink:href="#poly-da9b7555-8d7a-4f73-be45-b3ddbf35ef26"/>
							<gml:surfaceMember xlink:href="#poly-da8a51c2-c773-4d38-8f47-9f10e2e21fe9"/>
							<gml:surfaceMember xlink:href="#poly-a9fd921c-5f9b-4229-b7e8-039f025412ee"/>
							<gml:surfaceMember xlink:href="#poly-c34ac693-1606-482b-bf01-a3bd0817f050"/>
							<gml:surfaceMember xlink:href="#poly-47893cf4-bf1f-46ee-85d3-b99eba1e74b5"/>
							<gml:surfaceMember xlink:href="#poly-1aaa077d-78b0-4e5e-82c9-70fc2ca4f56d"/>
							<gml:surfaceMember xlink:href="#poly-c5606a35-13f8-4ef4-94b7-5019a6c9cdc9"/>
							<gml:surfaceMember xlink:href="#poly-313e3159-0ae2-4052-bc5c-96ffc560cb88"/>
							<gml:surfaceMember xlink:href="#poly-244987c6-7fe8-4fcf-b4e9-73af8ec6d3d7"/>
							<gml:surfaceMember xlink:href="#poly-705a8a68-7cb0-434e-ab2d-0e8feb5495ea"/>
							<gml:surfaceMember xlink:href="#poly-c1452af5-ce62-4a64-a39e-fb03715ed7cb"/>
							<gml:surfaceMember xlink:href="#poly-f814afb5-1eab-46e5-8be7-6a021fa50a90"/>
							<gml:surfaceMember xlink:href="#poly-bc7dbb0c-3f9d-4571-b2dd-9528d5beaab4"/>
							<gml:surfaceMember xlink:href="#poly-4c0328c5-055d-4662-859e-3a1eef4469f8"/>
							<gml:surfaceMember xlink:href="#poly-05ece221-6f7f-4ea5-9cca-0688b8f18aeb"/>
							<gml:surfaceMember xlink:href="#poly-680b6eed-05a7-44a8-bdae-ba3946f8e652"/>
							<gml:surfaceMember xlink:href="#poly-aae21b87-7c52-4390-a425-4c6533e61cfd"/>
							<gml:surfaceMember xlink:href="#poly-f6d521f8-d355-40e6-a782-e5efb1284251"/>
							<gml:surfaceMember xlink:href="#poly-4b68f0f8-e69a-48c1-a50c-1b70673f47f3"/>
							<gml:surfaceMember xlink:href="#poly-f1471b6a-9932-4f9e-bb40-62b74a3a7d98"/>
							<gml:surfaceMember xlink:href="#poly-548dd752-003f-45d6-bff5-f7ba666e3a0a"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_9af70650-ca86-4458-90f2-055543cf4562_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fd4fb8eb-0f01-4c01-943e-6543252ec572">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66837234429218 139.74925306450106 5.28 35.66838719325303 139.74920622499698 5.28 35.6684153975923 139.74921964942078 5.28 35.66840066577394 139.7492664446321 5.28 35.66837234429218 139.74925306450106 5.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94ffa2dc-ebaf-4860-8702-25d7a3e0eac8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-94ffa2dc-ebaf-4860-8702-25d7a3e0eac8_0">
											<gml:posList>35.6684153975923 139.74921964942078 35.1 35.6684153975923 139.74921964942078 5.28 35.66838719325303 139.74920622499698 5.28 35.66838719325303 139.74920622499698 35.1 35.6684153975923 139.74921964942078 35.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-85ccb114-68f5-41de-ac29-61cc13172a12">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-85ccb114-68f5-41de-ac29-61cc13172a12_0">
											<gml:posList>35.66838719325303 139.74920622499698 35.1 35.66838719325303 139.74920622499698 5.28 35.66837234429218 139.74925306450106 5.28 35.66837234429218 139.74925306450106 35.1 35.66838719325303 139.74920622499698 35.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-55e6beb6-6fd2-4dbb-bd94-bc1246fefa05">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-55e6beb6-6fd2-4dbb-bd94-bc1246fefa05_0">
											<gml:posList>35.66840066577394 139.7492664446321 35.1 35.6684153975923 139.74921964942078 35.1 35.66838719325303 139.74920622499698 35.1 35.66837234429218 139.74925306450106 35.1 35.66840066577394 139.7492664446321 35.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5ce3f9ad-b3a4-4f16-8535-832a38fd29c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5ce3f9ad-b3a4-4f16-8535-832a38fd29c1_0">
											<gml:posList>35.66840066577394 139.7492664446321 35.1 35.66840066577394 139.7492664446321 5.28 35.6684153975923 139.74921964942078 5.28 35.6684153975923 139.74921964942078 35.1 35.66840066577394 139.7492664446321 35.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-080e954a-033c-4922-ad15-f2e0e81b9519">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-080e954a-033c-4922-ad15-f2e0e81b9519_0">
											<gml:posList>35.66837234429218 139.74925306450106 35.1 35.66837234429218 139.74925306450106 5.28 35.66840066577394 139.7492664446321 5.28 35.66840066577394 139.7492664446321 35.1 35.66837234429218 139.74925306450106 35.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_9af70650-ca86-4458-90f2-055543cf4562_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af4ad15c-fbe3-4aa7-a3ba-a571422d0b97">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66833441348062 139.74923870031932 34.849 35.66833888439288 139.7492259375245 34.849 35.66835453797982 139.7492341614069 34.849 35.66835006707443 139.74924693524972 34.849 35.66833441348062 139.74923870031932 34.849</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e74dc534-4eb9-4313-8c81-24f66fd9cc38">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66834470978643 139.74920374004049 37.701 35.66834877540911 139.74919145264454 37.701 35.66837624077114 139.7492050877058 37.701 35.66837217515481 139.74921738615123 37.701 35.66834470978643 139.74920374004049 37.701</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1272654-e543-4e10-9ee2-6cc00f575148">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c1272654-e543-4e10-9ee2-6cc00f575148_0">
											<gml:posList>35.66834877540911 139.74919145264454 37.701 35.66834470978643 139.74920374004049 37.701 35.66834470978643 139.74920374004049 38.658 35.66834877540911 139.74919145264454 38.658 35.66834877540911 139.74919145264454 37.701</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6111a68d-5e21-4391-93f3-a13b1c82418c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6111a68d-5e21-4391-93f3-a13b1c82418c_0">
											<gml:posList>35.66834877540911 139.74919145264454 37.701 35.66834877540911 139.74919145264454 38.658 35.66837624077114 139.7492050877058 38.658 35.66837624077114 139.7492050877058 37.701 35.66834877540911 139.74919145264454 37.701</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c02a121-75b0-4a92-b296-d8389777abde">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8c02a121-75b0-4a92-b296-d8389777abde_0">
											<gml:posList>35.66834470978643 139.74920374004049 38.658 35.66837217515481 139.74921738615123 38.658 35.66837624077114 139.7492050877058 38.658 35.66834877540911 139.74919145264454 38.658 35.66834470978643 139.74920374004049 38.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba62db98-7920-4dc1-ba44-c6bd7359a43b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba62db98-7920-4dc1-ba44-c6bd7359a43b_0">
											<gml:posList>35.66837217515481 139.74921738615123 37.701 35.66837217515481 139.74921738615123 38.658 35.66834470978643 139.74920374004049 38.658 35.66834470978643 139.74920374004049 37.701 35.66837217515481 139.74921738615123 37.701</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-05ad6aa6-fc4a-4429-be28-a4a7deadb47d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-05ad6aa6-fc4a-4429-be28-a4a7deadb47d_0">
											<gml:posList>35.66837217515481 139.74921738615123 37.701 35.66837624077114 139.7492050877058 37.701 35.66837624077114 139.7492050877058 38.658 35.66837217515481 139.74921738615123 38.658 35.66837217515481 139.74921738615123 37.701</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-85c0d2a4-5a6c-4189-a4fe-58aeb7d82a5b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-85c0d2a4-5a6c-4189-a4fe-58aeb7d82a5b_0">
											<gml:posList>35.66835453797982 139.7492341614069 34.849 35.66833888439288 139.7492259375245 34.849 35.66833888439288 139.7492259375245 36.283 35.66835453797982 139.7492341614069 36.283 35.66835453797982 139.7492341614069 34.849</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a36d9f5d-6023-47c5-9f90-f77ffe3a6f1f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a36d9f5d-6023-47c5-9f90-f77ffe3a6f1f_0">
											<gml:posList>35.66833888439288 139.7492259375245 34.849 35.66833441348062 139.74923870031932 34.849 35.66833441348062 139.74923870031932 36.283 35.66833888439288 139.7492259375245 36.283 35.66833888439288 139.7492259375245 34.849</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b0e6fce7-c4c2-4d8e-b7a9-187cf2b6555d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b0e6fce7-c4c2-4d8e-b7a9-187cf2b6555d_0">
											<gml:posList>35.66833441348062 139.74923870031932 36.283 35.66835006707443 139.74924693524972 36.283 35.66835453797982 139.7492341614069 36.283 35.66833888439288 139.7492259375245 36.283 35.66833441348062 139.74923870031932 36.283</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f70b6fab-56b2-4b7d-8950-2926232d34d0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f70b6fab-56b2-4b7d-8950-2926232d34d0_0">
											<gml:posList>35.66835453797982 139.7492341614069 34.849 35.66835453797982 139.7492341614069 36.283 35.66835006707443 139.74924693524972 36.283 35.66835006707443 139.74924693524972 34.849 35.66835453797982 139.7492341614069 34.849</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-64899024-1e15-4262-8d2c-4d06169d4c95">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-64899024-1e15-4262-8d2c-4d06169d4c95_0">
											<gml:posList>35.66833441348062 139.74923870031932 34.849 35.66835006707443 139.74924693524972 34.849 35.66835006707443 139.74924693524972 36.283 35.66833441348062 139.74923870031932 36.283 35.66833441348062 139.74923870031932 34.849</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-682c202a-6392-4f7f-9bfc-573746ff1a28">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-682c202a-6392-4f7f-9bfc-573746ff1a28">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-682c202a-6392-4f7f-9bfc-573746ff1a28">
											<gml:posList>35.66833992753115 139.7491837186978 5.28 35.66838719325303 139.74920622499698 5.28 35.66837234429218 139.74925306450106 5.28 35.66840066577394 139.7492664446321 5.28 35.66837222737503 139.7493567753643 5.28 35.6682968474914 139.74932084443697 5.28 35.66833992753115 139.7491837186978 5.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7ec0b096-bdf8-41f8-8e34-604305402033">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ec0b096-bdf8-41f8-8e34-604305402033">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ec0b096-bdf8-41f8-8e34-604305402033">
											<gml:posList>35.66833256165813 139.74920715494775 38.138 35.66833572428047 139.74920543950293 38.138 35.66834133639752 139.74918761644997 38.138 35.66833992753115 139.7491837186978 38.138 35.66833256165813 139.74920715494775 38.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-566d6330-0549-43c7-954e-6c279152f983">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-566d6330-0549-43c7-954e-6c279152f983">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-566d6330-0549-43c7-954e-6c279152f983">
											<gml:posList>35.66833992753115 139.7491837186978 38.138 35.66834133639752 139.74918761644997 38.138 35.6683840216247 139.74920795149833 38.138 35.66838719325303 139.74920622499698 38.138 35.66833992753115 139.7491837186978 38.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-262f1f07-86ad-4837-a982-7be29361916a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-262f1f07-86ad-4837-a982-7be29361916a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-262f1f07-86ad-4837-a982-7be29361916a">
											<gml:posList>35.6683840216247 139.74920795149833 37.701 35.66834133639752 139.74918761644997 37.701 35.66833572428047 139.74920543950293 37.701 35.66837838244036 139.74922574144978 37.701 35.6683840216247 139.74920795149833 37.701</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0d255121-0339-46e6-8bfc-3927e0be5b62">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d255121-0339-46e6-8bfc-3927e0be5b62">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d255121-0339-46e6-8bfc-3927e0be5b62">
											<gml:posList>35.66837977327018 139.7492296281775 38.138 35.66837838244036 139.74922574144978 38.138 35.66833572428047 139.74920543950293 38.138 35.66833256165813 139.74920715494775 38.138 35.66837977327018 139.7492296281775 38.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e8f3dfce-6282-4539-a5be-80f41f6875b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8f3dfce-6282-4539-a5be-80f41f6875b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8f3dfce-6282-4539-a5be-80f41f6875b8">
											<gml:posList>35.66838719325303 139.74920622499698 38.138 35.6683840216247 139.74920795149833 38.138 35.66837838244036 139.74922574144978 38.138 35.66837977327018 139.7492296281775 38.138 35.66838719325303 139.74920622499698 38.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-871eaa59-8183-41d9-b3f8-eeec78751dba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-871eaa59-8183-41d9-b3f8-eeec78751dba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-871eaa59-8183-41d9-b3f8-eeec78751dba">
											<gml:posList>35.66832273505252 139.74924352861328 34.849 35.66836725967243 139.74926472334482 34.849 35.66837856502947 139.7492290550536 34.849 35.6683340404034 139.7492078603389 34.849 35.66832273505252 139.74924352861328 34.849</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4de0540d-9db2-4b4b-9f02-7b1d4c097319">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4de0540d-9db2-4b4b-9f02-7b1d4c097319">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4de0540d-9db2-4b4b-9f02-7b1d4c097319">
											<gml:posList>35.668368162109424 139.74926624674433 35.1 35.66837977327018 139.7492296281775 35.1 35.66837856502947 139.7492290550536 35.1 35.66836725967243 139.74926472334482 35.1 35.66832273505252 139.74924352861328 35.1 35.6683340404034 139.7492078603389 35.1 35.66833256165813 139.74920715494775 35.1 35.66832083383472 139.74924450265303 35.1 35.668368162109424 139.74926624674433 35.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8aee6126-b218-4a50-ba74-563cfb31451a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8aee6126-b218-4a50-ba74-563cfb31451a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8aee6126-b218-4a50-ba74-563cfb31451a">
											<gml:posList>35.668368162109424 139.74926624674433 31.251 35.66836282018443 139.749283771273 31.251 35.668389788871316 139.74929610346246 31.251 35.668398917712246 139.74926730805186 31.251 35.66837190358362 139.74925444571113 31.251 35.668368162109424 139.74926624674433 31.251</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0e9fd296-5b6d-45e0-b685-9edec54f4108">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e9fd296-5b6d-45e0-b685-9edec54f4108">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e9fd296-5b6d-45e0-b685-9edec54f4108">
											<gml:posList>35.66840066577394 139.7492664446321 31.5 35.66837234429218 139.74925306450106 31.5 35.66837190358362 139.74925444571113 31.5 35.668398917712246 139.74926730805186 31.5 35.668389788871316 139.74929610346246 31.5 35.66836282018443 139.749283771273 31.5 35.66836247844919 139.74928489832143 31.5 35.66839072764034 139.74929802448014 31.5 35.66840066577394 139.7492664446321 31.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4c7a5057-1f98-4bd4-acac-c275ee5792f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c7a5057-1f98-4bd4-acac-c275ee5792f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c7a5057-1f98-4bd4-acac-c275ee5792f9">
											<gml:posList>35.6682968474914 139.74932084443697 21.4 35.668368162109424 139.74926624674433 35.1 35.66832083383472 139.74924450265303 35.1 35.6682968474914 139.74932084443697 21.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-da9b7555-8d7a-4f73-be45-b3ddbf35ef26">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da9b7555-8d7a-4f73-be45-b3ddbf35ef26">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da9b7555-8d7a-4f73-be45-b3ddbf35ef26">
											<gml:posList>35.6682968474914 139.74932084443697 21.4 35.66836247844919 139.74928489832143 31.5 35.668368162109424 139.74926624674433 35.1 35.6682968474914 139.74932084443697 21.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-da8a51c2-c773-4d38-8f47-9f10e2e21fe9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da8a51c2-c773-4d38-8f47-9f10e2e21fe9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da8a51c2-c773-4d38-8f47-9f10e2e21fe9">
											<gml:posList>35.6682968474914 139.74932084443697 21.4 35.66839072764034 139.74929802448014 31.5 35.66836247844919 139.74928489832143 31.5 35.6682968474914 139.74932084443697 21.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a9fd921c-5f9b-4229-b7e8-039f025412ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9fd921c-5f9b-4229-b7e8-039f025412ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9fd921c-5f9b-4229-b7e8-039f025412ee">
											<gml:posList>35.6682968474914 139.74932084443697 21.4 35.66837222737503 139.7493567753643 21.4 35.66839072764034 139.74929802448014 31.5 35.6682968474914 139.74932084443697 21.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c34ac693-1606-482b-bf01-a3bd0817f050">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c34ac693-1606-482b-bf01-a3bd0817f050">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c34ac693-1606-482b-bf01-a3bd0817f050">
											<gml:posList>35.66834133639752 139.74918761644997 38.138 35.66834133639752 139.74918761644997 37.701 35.6683840216247 139.74920795149833 37.701 35.6683840216247 139.74920795149833 38.138 35.66834133639752 139.74918761644997 38.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-47893cf4-bf1f-46ee-85d3-b99eba1e74b5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47893cf4-bf1f-46ee-85d3-b99eba1e74b5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47893cf4-bf1f-46ee-85d3-b99eba1e74b5">
											<gml:posList>35.66837838244036 139.74922574144978 38.138 35.66837838244036 139.74922574144978 37.701 35.66833572428047 139.74920543950293 37.701 35.66833572428047 139.74920543950293 38.138 35.66837838244036 139.74922574144978 38.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1aaa077d-78b0-4e5e-82c9-70fc2ca4f56d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1aaa077d-78b0-4e5e-82c9-70fc2ca4f56d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1aaa077d-78b0-4e5e-82c9-70fc2ca4f56d">
											<gml:posList>35.66833992753115 139.7491837186978 38.138 35.66833992753115 139.7491837186978 5.28 35.6682968474914 139.74932084443697 5.28 35.6682968474914 139.74932084443697 21.4 35.66832083383472 139.74924450265303 35.1 35.66833256165813 139.74920715494775 35.1 35.66833256165813 139.74920715494775 38.138 35.66833992753115 139.7491837186978 38.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c5606a35-13f8-4ef4-94b7-5019a6c9cdc9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c5606a35-13f8-4ef4-94b7-5019a6c9cdc9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c5606a35-13f8-4ef4-94b7-5019a6c9cdc9">
											<gml:posList>35.66832273505252 139.74924352861328 35.1 35.66832273505252 139.74924352861328 34.849 35.6683340404034 139.7492078603389 34.849 35.6683340404034 139.7492078603389 35.1 35.66832273505252 139.74924352861328 35.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-313e3159-0ae2-4052-bc5c-96ffc560cb88">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-313e3159-0ae2-4052-bc5c-96ffc560cb88">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-313e3159-0ae2-4052-bc5c-96ffc560cb88">
											<gml:posList>35.6682968474914 139.74932084443697 5.28 35.66837222737503 139.7493567753643 5.28 35.66837222737503 139.7493567753643 21.4 35.6682968474914 139.74932084443697 21.4 35.6682968474914 139.74932084443697 5.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-244987c6-7fe8-4fcf-b4e9-73af8ec6d3d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-244987c6-7fe8-4fcf-b4e9-73af8ec6d3d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-244987c6-7fe8-4fcf-b4e9-73af8ec6d3d7">
											<gml:posList>35.66833572428047 139.74920543950293 38.138 35.66833572428047 139.74920543950293 37.701 35.66834133639752 139.74918761644997 37.701 35.66834133639752 139.74918761644997 38.138 35.66833572428047 139.74920543950293 38.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-705a8a68-7cb0-434e-ab2d-0e8feb5495ea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-705a8a68-7cb0-434e-ab2d-0e8feb5495ea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-705a8a68-7cb0-434e-ab2d-0e8feb5495ea">
											<gml:posList>35.66836725967243 139.74926472334482 35.1 35.66836725967243 139.74926472334482 34.849 35.66832273505252 139.74924352861328 34.849 35.66832273505252 139.74924352861328 35.1 35.66836725967243 139.74926472334482 35.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c1452af5-ce62-4a64-a39e-fb03715ed7cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c1452af5-ce62-4a64-a39e-fb03715ed7cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c1452af5-ce62-4a64-a39e-fb03715ed7cb">
											<gml:posList>35.66837856502947 139.7492290550536 35.1 35.66837977327018 139.7492296281775 35.1 35.66837977327018 139.7492296281775 38.138 35.66833256165813 139.74920715494775 38.138 35.66833256165813 139.74920715494775 35.1 35.6683340404034 139.7492078603389 35.1 35.6683340404034 139.7492078603389 34.849 35.66837856502947 139.7492290550536 34.849 35.66837856502947 139.7492290550536 35.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f814afb5-1eab-46e5-8be7-6a021fa50a90">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f814afb5-1eab-46e5-8be7-6a021fa50a90">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f814afb5-1eab-46e5-8be7-6a021fa50a90">
											<gml:posList>35.66838719325303 139.74920622499698 5.28 35.66833992753115 139.7491837186978 5.28 35.66833992753115 139.7491837186978 38.138 35.66838719325303 139.74920622499698 38.138 35.66838719325303 139.74920622499698 5.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bc7dbb0c-3f9d-4571-b2dd-9528d5beaab4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc7dbb0c-3f9d-4571-b2dd-9528d5beaab4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc7dbb0c-3f9d-4571-b2dd-9528d5beaab4">
											<gml:posList>35.66836282018443 139.749283771273 31.5 35.66836282018443 139.749283771273 31.251 35.668368162109424 139.74926624674433 31.251 35.668368162109424 139.74926624674433 35.1 35.66836247844919 139.74928489832143 31.5 35.66836282018443 139.749283771273 31.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4c0328c5-055d-4662-859e-3a1eef4469f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c0328c5-055d-4662-859e-3a1eef4469f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c0328c5-055d-4662-859e-3a1eef4469f8">
											<gml:posList>35.66837856502947 139.7492290550536 35.1 35.66837856502947 139.7492290550536 34.849 35.66836725967243 139.74926472334482 34.849 35.66836725967243 139.74926472334482 35.1 35.66837856502947 139.7492290550536 35.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-05ece221-6f7f-4ea5-9cca-0688b8f18aeb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-05ece221-6f7f-4ea5-9cca-0688b8f18aeb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-05ece221-6f7f-4ea5-9cca-0688b8f18aeb">
											<gml:posList>35.668389788871316 139.74929610346246 31.5 35.668389788871316 139.74929610346246 31.251 35.66836282018443 139.749283771273 31.251 35.66836282018443 139.749283771273 31.5 35.668389788871316 139.74929610346246 31.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-680b6eed-05a7-44a8-bdae-ba3946f8e652">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-680b6eed-05a7-44a8-bdae-ba3946f8e652">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-680b6eed-05a7-44a8-bdae-ba3946f8e652">
											<gml:posList>35.668368162109424 139.74926624674433 31.251 35.66837190358362 139.74925444571113 31.251 35.66837190358362 139.74925444571113 31.5 35.66837234429218 139.74925306450106 31.5 35.66837234429218 139.74925306450106 5.28 35.66838719325303 139.74920622499698 5.28 35.66838719325303 139.74920622499698 38.138 35.66837977327018 139.7492296281775 38.138 35.66837977327018 139.7492296281775 35.1 35.668368162109424 139.74926624674433 35.1 35.668368162109424 139.74926624674433 31.251</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aae21b87-7c52-4390-a425-4c6533e61cfd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aae21b87-7c52-4390-a425-4c6533e61cfd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aae21b87-7c52-4390-a425-4c6533e61cfd">
											<gml:posList>35.6683840216247 139.74920795149833 38.138 35.6683840216247 139.74920795149833 37.701 35.66837838244036 139.74922574144978 37.701 35.66837838244036 139.74922574144978 38.138 35.6683840216247 139.74920795149833 38.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f6d521f8-d355-40e6-a782-e5efb1284251">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f6d521f8-d355-40e6-a782-e5efb1284251">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f6d521f8-d355-40e6-a782-e5efb1284251">
											<gml:posList>35.66837190358362 139.74925444571113 31.5 35.66837190358362 139.74925444571113 31.251 35.668398917712246 139.74926730805186 31.251 35.668398917712246 139.74926730805186 31.5 35.66837190358362 139.74925444571113 31.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4b68f0f8-e69a-48c1-a50c-1b70673f47f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b68f0f8-e69a-48c1-a50c-1b70673f47f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b68f0f8-e69a-48c1-a50c-1b70673f47f3">
											<gml:posList>35.66837222737503 139.7493567753643 21.4 35.66837222737503 139.7493567753643 5.28 35.66840066577394 139.7492664446321 5.28 35.66840066577394 139.7492664446321 31.5 35.66839072764034 139.74929802448014 31.5 35.66837222737503 139.7493567753643 21.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f1471b6a-9932-4f9e-bb40-62b74a3a7d98">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f1471b6a-9932-4f9e-bb40-62b74a3a7d98">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f1471b6a-9932-4f9e-bb40-62b74a3a7d98">
											<gml:posList>35.66840066577394 139.7492664446321 5.28 35.66837234429218 139.74925306450106 5.28 35.66837234429218 139.74925306450106 31.5 35.66840066577394 139.7492664446321 31.5 35.66840066577394 139.7492664446321 5.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-548dd752-003f-45d6-bff5-f7ba666e3a0a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-548dd752-003f-45d6-bff5-f7ba666e3a0a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-548dd752-003f-45d6-bff5-f7ba666e3a0a">
											<gml:posList>35.668398917712246 139.74926730805186 31.5 35.668398917712246 139.74926730805186 31.251 35.668389788871316 139.74929610346246 31.251 35.668389788871316 139.74929610346246 31.5 35.668398917712246 139.74926730805186 31.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7218</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">119.44135</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.2</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>