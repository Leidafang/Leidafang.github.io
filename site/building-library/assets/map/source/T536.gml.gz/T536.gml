<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_9b6d29ff-1e2a-4768-9255-4e3b231f0fae">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門駅南地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">25.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>7</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.668337759604775 139.7491770933856 0 35.66825958448491 139.74913984006142 0 35.668215155210866 139.74928094364736 0 35.668293330287874 139.74931819708863 0 35.668337759604775 139.7491770933856 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668337759604775 139.7491770933856 5.298 35.668293330287874 139.74931819708863 5.298 35.668215155210866 139.74928094364736 5.298 35.66825958448491 139.74913984006142 5.298 35.668337759604775 139.7491770933856 5.298</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668337759604775 139.7491770933856 5.298 35.66825958448491 139.74913984006142 5.298 35.66825958448491 139.74913984006142 28.22 35.668337759604775 139.7491770933856 28.22 35.668337759604775 139.7491770933856 5.298</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66825958448491 139.74913984006142 5.298 35.668215155210866 139.74928094364736 5.298 35.668215155210866 139.74928094364736 28.22 35.66825958448491 139.74913984006142 28.22 35.66825958448491 139.74913984006142 5.298</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668215155210866 139.74928094364736 5.298 35.668293330287874 139.74931819708863 5.298 35.668293330287874 139.74931819708863 28.22 35.668215155210866 139.74928094364736 28.22 35.668215155210866 139.74928094364736 5.298</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668293330287874 139.74931819708863 5.298 35.668337759604775 139.7491770933856 5.298 35.668337759604775 139.7491770933856 28.22 35.668293330287874 139.74931819708863 28.22 35.668293330287874 139.74931819708863 5.298</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668337759604775 139.7491770933856 28.22 35.66825958448491 139.74913984006142 28.22 35.668215155210866 139.74928094364736 28.22 35.668293330287874 139.74931819708863 28.22 35.668337759604775 139.7491770933856 28.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-fa3e46b7-4f13-4459-ae8a-5eb94a9f5665"/>
							<gml:surfaceMember xlink:href="#poly-2eaa1d08-b724-459d-aacd-e52cb3a5e8a2"/>
							<gml:surfaceMember xlink:href="#poly-ed76f3b9-a52b-4906-8874-fbffa27155b9"/>
							<gml:surfaceMember xlink:href="#poly-3b926cc8-b08e-4201-953a-da69658b07b1"/>
							<gml:surfaceMember xlink:href="#poly-3810d3ee-f0e8-4552-b537-7a9b2595e7d5"/>
							<gml:surfaceMember xlink:href="#poly-511a5c55-ca0a-459b-8e4d-7fd84e7115ed"/>
							<gml:surfaceMember xlink:href="#poly-d5e76b0e-d7e4-47eb-8e2f-2e05b3c9295f"/>
							<gml:surfaceMember xlink:href="#poly-a53ca0b6-8bca-4c97-bdab-b640c0b38855"/>
							<gml:surfaceMember xlink:href="#poly-ea73026a-d087-443f-88c5-23a59026057c"/>
							<gml:surfaceMember xlink:href="#poly-4a646cc1-788c-49d6-85e4-b61e0cdc9579"/>
							<gml:surfaceMember xlink:href="#poly-b8fea06d-e89d-442a-81ec-93e34c3ab58c"/>
							<gml:surfaceMember xlink:href="#poly-b1f76a70-ede5-4c5d-a1f9-9fe8b90e0034"/>
							<gml:surfaceMember xlink:href="#poly-6a0675d7-7762-496c-bc65-bfb42a0267b7"/>
							<gml:surfaceMember xlink:href="#poly-afedc560-c88d-425f-9ecc-1fafa57420cc"/>
							<gml:surfaceMember xlink:href="#poly-b091ae72-7e25-4076-9a2b-f29e19909af8"/>
							<gml:surfaceMember xlink:href="#poly-124eb706-83f4-4a05-92a9-d69d3811a6c3"/>
							<gml:surfaceMember xlink:href="#poly-efa2aece-9821-4cbd-ab4e-88a1797e023b"/>
							<gml:surfaceMember xlink:href="#poly-0d97ebd3-d68b-4405-adf4-c36881a6ad3b"/>
							<gml:surfaceMember xlink:href="#poly-067aa513-42d8-4320-9e67-6ce1c72b6f1c"/>
							<gml:surfaceMember xlink:href="#poly-7cb397e9-0d59-408d-8583-26c6c1d1eeea"/>
							<gml:surfaceMember xlink:href="#poly-ad9158f7-7a0d-4b6c-b01a-cb45d3ba4067"/>
							<gml:surfaceMember xlink:href="#poly-301e8e47-137b-4dd9-a635-9c29b20bed93"/>
							<gml:surfaceMember xlink:href="#poly-dc25b9d3-4bed-465a-af0b-e4268908c13e"/>
							<gml:surfaceMember xlink:href="#poly-54e84b79-6cfb-4d26-9ebc-2b9d4c21ff20"/>
							<gml:surfaceMember xlink:href="#poly-216d36c6-ed80-4f61-8237-9e7a201be34f"/>
							<gml:surfaceMember xlink:href="#poly-0f4ddb02-7fe8-45ee-a822-bcb2c0b89853"/>
							<gml:surfaceMember xlink:href="#poly-0468fe93-e002-4b75-a02e-bb33d8f7cbf3"/>
							<gml:surfaceMember xlink:href="#poly-6e242ec3-1452-4769-8278-afcf8493fe13"/>
							<gml:surfaceMember xlink:href="#poly-7eed215e-bf7e-4340-9360-673086e0cc61"/>
							<gml:surfaceMember xlink:href="#poly-cdb6840c-2569-45ba-abbb-12da80921b7e"/>
							<gml:surfaceMember xlink:href="#poly-544a88bb-1b5b-44a1-8f3e-851b6dcf8bc4"/>
							<gml:surfaceMember xlink:href="#poly-6a914645-a9d2-4823-b7dc-abfd492f46b1"/>
							<gml:surfaceMember xlink:href="#poly-173b00ea-1e93-48ab-a934-343e4860ed32"/>
							<gml:surfaceMember xlink:href="#poly-2c195be0-8574-4ac4-be41-89fc5c0e3890"/>
							<gml:surfaceMember xlink:href="#poly-f4e0de6a-b290-4965-b38a-ffd8b99b0740"/>
							<gml:surfaceMember xlink:href="#poly-ce697fa8-118c-42b1-89cc-03f3409fd7ae"/>
							<gml:surfaceMember xlink:href="#poly-19930d9f-a7fa-4fff-b076-bbb25a84898e"/>
							<gml:surfaceMember xlink:href="#poly-b1aa8798-a903-4690-a393-49680aae2452"/>
							<gml:surfaceMember xlink:href="#poly-697a615f-38f2-4b8c-9497-d7b49d37c176"/>
							<gml:surfaceMember xlink:href="#poly-26838833-277d-459e-8088-67a6a1483074"/>
							<gml:surfaceMember xlink:href="#poly-102fce32-22a8-4a5c-a838-24b09d6c4fdc"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_9b6d29ff-1e2a-4768-9255-4e3b231f0fae_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab4d2e88-5216-4f6a-9cd7-82a147a65be8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66829575170381 139.74923602355742 28.577 35.668288483506196 139.74925736095253 28.577 35.66827326288041 139.74924956741117 28.577 35.66828053108439 139.74922824106537 28.577 35.66829575170381 139.74923602355742 28.577</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb775776-177c-4372-ad0c-f4d2e110bf13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66828072291911 139.74918027925787 33.156 35.66828641731421 139.7491641130248 33.156 35.66829920352092 139.74917088183082 33.156 35.66829350912493 139.749187048066 33.156 35.66828072291911 139.74918027925787 33.156</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d3b89f47-832b-464f-9ea2-3fa614eb9dca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d3b89f47-832b-464f-9ea2-3fa614eb9dca_0">
											<gml:posList>35.66828641731421 139.7491641130248 33.156 35.66828641731421 139.7491641130248 34.15 35.66829920352092 139.74917088183082 34.15 35.66829920352092 139.74917088183082 33.156 35.66828641731421 139.7491641130248 33.156</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc12e93c-3d5e-4400-b544-df70dcf9a59f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc12e93c-3d5e-4400-b544-df70dcf9a59f_0">
											<gml:posList>35.66828641731421 139.7491641130248 33.156 35.66828072291911 139.74918027925787 33.156 35.66828072291911 139.74918027925787 34.15 35.66828641731421 139.7491641130248 34.15 35.66828641731421 139.7491641130248 33.156</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ec508b4-0867-4b98-8bd6-f304b62d11ec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0ec508b4-0867-4b98-8bd6-f304b62d11ec_0">
											<gml:posList>35.66828072291911 139.74918027925787 34.15 35.66829350912493 139.749187048066 34.15 35.66829920352092 139.74917088183082 34.15 35.66828641731421 139.7491641130248 34.15 35.66828072291911 139.74918027925787 34.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f5bc753-5d43-47c7-92b0-e4a7e939c1f9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5f5bc753-5d43-47c7-92b0-e4a7e939c1f9_0">
											<gml:posList>35.66829350912493 139.749187048066 33.156 35.66829920352092 139.74917088183082 33.156 35.66829920352092 139.74917088183082 34.15 35.66829350912493 139.749187048066 34.15 35.66829350912493 139.749187048066 33.156</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-56969bf7-621c-4f96-a887-a3c94100d347">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-56969bf7-621c-4f96-a887-a3c94100d347_0">
											<gml:posList>35.66829350912493 139.749187048066 33.156 35.66829350912493 139.749187048066 34.15 35.66828072291911 139.74918027925787 34.15 35.66828072291911 139.74918027925787 33.156 35.66829350912493 139.749187048066 33.156</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38eab1d7-0f49-4563-86d4-e1753cc8b245">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-38eab1d7-0f49-4563-86d4-e1753cc8b245_0">
											<gml:posList>35.66828053108439 139.74922824106537 28.577 35.66828053108439 139.74922824106537 31.09 35.66829575170381 139.74923602355742 31.09 35.66829575170381 139.74923602355742 28.577 35.66828053108439 139.74922824106537 28.577</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c78a9e56-dc5d-4344-9441-50596503b697">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c78a9e56-dc5d-4344-9441-50596503b697_0">
											<gml:posList>35.66828053108439 139.74922824106537 28.577 35.66827326288041 139.74924956741117 28.577 35.66827326288041 139.74924956741117 31.09 35.66828053108439 139.74922824106537 31.09 35.66828053108439 139.74922824106537 28.577</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0987361f-8dfe-4b14-9fb6-0ee7a4d014c8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0987361f-8dfe-4b14-9fb6-0ee7a4d014c8_0">
											<gml:posList>35.66829575170381 139.74923602355742 31.09 35.66828053108439 139.74922824106537 31.09 35.66827326288041 139.74924956741117 31.09 35.668288483506196 139.74925736095253 31.09 35.66829575170381 139.74923602355742 31.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-488ce524-84e0-4c67-8057-868a2a2e4433">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-488ce524-84e0-4c67-8057-868a2a2e4433_0">
											<gml:posList>35.668288483506196 139.74925736095253 28.577 35.66829575170381 139.74923602355742 28.577 35.66829575170381 139.74923602355742 31.09 35.668288483506196 139.74925736095253 31.09 35.668288483506196 139.74925736095253 28.577</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8daef278-53d8-4208-8529-d9519af186b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8daef278-53d8-4208-8529-d9519af186b4_0">
											<gml:posList>35.66827326288041 139.74924956741117 28.577 35.668288483506196 139.74925736095253 28.577 35.668288483506196 139.74925736095253 31.09 35.66827326288041 139.74924956741117 31.09 35.66827326288041 139.74924956741117 28.577</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-fa3e46b7-4f13-4459-ae8a-5eb94a9f5665">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa3e46b7-4f13-4459-ae8a-5eb94a9f5665">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa3e46b7-4f13-4459-ae8a-5eb94a9f5665">
											<gml:posList>35.66833775960477 139.7491770933856 5.298 35.66829333028787 139.74931819708863 5.298 35.66821515521089 139.74928094364734 5.298 35.66825958448488 139.74913984006142 5.298 35.66833775960477 139.7491770933856 5.298</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2eaa1d08-b724-459d-aacd-e52cb3a5e8a2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2eaa1d08-b724-459d-aacd-e52cb3a5e8a2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2eaa1d08-b724-459d-aacd-e52cb3a5e8a2">
											<gml:posList>35.66825958448488 139.74913984006142 29.1 35.66826177905294 139.7491458909478 29.1 35.66827447462924 139.74915195290194 29.1 35.66827941229112 139.74914928563913 29.1 35.66825958448488 139.74913984006142 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ed76f3b9-a52b-4906-8874-fbffa27155b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed76f3b9-a52b-4906-8874-fbffa27155b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed76f3b9-a52b-4906-8874-fbffa27155b9">
											<gml:posList>35.66827802722725 139.7491536502517 29.1 35.66827941229112 139.74914928563913 29.1 35.66827447462924 139.74915195290194 29.1 35.66827802722725 139.7491536502517 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3b926cc8-b08e-4201-953a-da69658b07b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3b926cc8-b08e-4201-953a-da69658b07b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3b926cc8-b08e-4201-953a-da69658b07b1">
											<gml:posList>35.66827941229112 139.74914928563913 36.173 35.66828262743303 139.74915822950035 36.173 35.668330488282265 139.74918104443128 36.173 35.66833775960477 139.7491770933856 36.173 35.66827941229112 139.74914928563913 36.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3810d3ee-f0e8-4552-b537-7a9b2595e7d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3810d3ee-f0e8-4552-b537-7a9b2595e7d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3810d3ee-f0e8-4552-b537-7a9b2595e7d5">
											<gml:posList>35.66826286348518 139.7492014620772 36.173 35.668270161865074 139.74919753310024 36.173 35.66828262743303 139.74915822950035 36.173 35.66827941229112 139.74914928563913 36.173 35.66826286348518 139.7492014620772 36.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-511a5c55-ca0a-459b-8e4d-7fd84e7115ed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-511a5c55-ca0a-459b-8e4d-7fd84e7115ed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-511a5c55-ca0a-459b-8e4d-7fd84e7115ed">
											<gml:posList>35.668330488282265 139.74918104443128 33.156 35.66828262743303 139.74915822950035 33.156 35.668270161865074 139.74919753310024 33.156 35.668318103853686 139.74922038110395 33.156 35.668330488282265 139.74918104443128 33.156</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d5e76b0e-d7e4-47eb-8e2f-2e05b3c9295f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5e76b0e-d7e4-47eb-8e2f-2e05b3c9295f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5e76b0e-d7e4-47eb-8e2f-2e05b3c9295f">
											<gml:posList>35.66822771055011 139.74924107664904 29.1 35.668232657212315 139.7492383872919 29.1 35.66826177905294 139.7491458909478 29.1 35.66825958448488 139.74913984006142 29.1 35.66822771055011 139.74924107664904 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a53ca0b6-8bca-4c97-bdab-b640c0b38855">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a53ca0b6-8bca-4c97-bdab-b640c0b38855">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a53ca0b6-8bca-4c97-bdab-b640c0b38855">
											<gml:posList>35.66833775960477 139.7491770933856 36.173 35.668330488282265 139.74918104443128 36.173 35.668318103853686 139.74922038110395 36.173 35.668321318982585 139.74922931392638 36.173 35.66833775960477 139.7491770933856 36.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ea73026a-d087-443f-88c5-23a59026057c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea73026a-d087-443f-88c5-23a59026057c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea73026a-d087-443f-88c5-23a59026057c">
											<gml:posList>35.66831639032499 139.74923197013024 28.577 35.668317766393386 139.7492276276183 28.577 35.66826286348518 139.7492014620772 28.577 35.66827802722725 139.7491536502517 28.577 35.66827447462924 139.74915195290194 28.577 35.66826177905294 139.7491458909478 28.577 35.668232657212315 139.7492383872919 28.577 35.66830378103003 139.74927201396622 28.577 35.66831639032499 139.74923197013024 28.577</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4a646cc1-788c-49d6-85e4-b61e0cdc9579">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a646cc1-788c-49d6-85e4-b61e0cdc9579">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a646cc1-788c-49d6-85e4-b61e0cdc9579">
											<gml:posList>35.668321318982585 139.74922931392638 36.173 35.668318103853686 139.74922038110395 36.173 35.668270161865074 139.74919753310024 36.173 35.66826286348518 139.7492014620772 36.173 35.668321318982585 139.74922931392638 36.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b8fea06d-e89d-442a-81ec-93e34c3ab58c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8fea06d-e89d-442a-81ec-93e34c3ab58c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8fea06d-e89d-442a-81ec-93e34c3ab58c">
											<gml:posList>35.66831639032499 139.74923197013024 29.1 35.668321318982585 139.74922931392638 29.1 35.668317766393386 139.7492276276183 29.1 35.66831639032499 139.74923197013024 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b1f76a70-ede5-4c5d-a1f9-9fe8b90e0034">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b1f76a70-ede5-4c5d-a1f9-9fe8b90e0034">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b1f76a70-ede5-4c5d-a1f9-9fe8b90e0034">
											<gml:posList>35.668321318982585 139.74922931392638 29.1 35.66831639032499 139.74923197013024 29.1 35.66830378103003 139.74927201396622 29.1 35.66830596658542 139.749278075915 29.1 35.668321318982585 139.74922931392638 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6a0675d7-7762-496c-bc65-bfb42a0267b7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a0675d7-7762-496c-bc65-bfb42a0267b7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a0675d7-7762-496c-bc65-bfb42a0267b7">
											<gml:posList>35.66830596658542 139.749278075915 29.1 35.66830378103003 139.74927201396622 29.1 35.668232657212315 139.7492383872919 29.1 35.66822771055011 139.74924107664904 29.1 35.66830596658542 139.749278075915 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-afedc560-c88d-425f-9ecc-1fafa57420cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-afedc560-c88d-425f-9ecc-1fafa57420cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-afedc560-c88d-425f-9ecc-1fafa57420cc">
											<gml:posList>35.66822532475353 139.74925805679692 24.749 35.668297169903084 139.74929202515474 24.749 35.66830213447879 139.74927625734642 24.749 35.668230280311136 139.74924228901008 24.749 35.66822532475353 139.74925805679692 24.749</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b091ae72-7e25-4076-9a2b-f29e19909af8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b091ae72-7e25-4076-9a2b-f29e19909af8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b091ae72-7e25-4076-9a2b-f29e19909af8">
											<gml:posList>35.66829970689265 139.7492979431376 25.3 35.66830596658542 139.749278075915 25.3 35.66830213447879 139.74927625734642 25.3 35.668297169903084 139.74929202515474 25.3 35.66822532475353 139.74925805679692 25.3 35.668230280311136 139.74924228901008 25.3 35.66822771055011 139.74924107664904 25.3 35.668221432882156 139.74926101014975 25.3 35.66829970689265 139.7492979431376 25.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-124eb706-83f4-4a05-92a9-d69d3811a6c3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-124eb706-83f4-4a05-92a9-d69d3811a6c3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-124eb706-83f4-4a05-92a9-d69d3811a6c3">
											<gml:posList>35.6682190118837 139.74927921643445 21.249 35.66829212834069 139.7493137247291 21.249 35.66829741665801 139.74929687407842 21.249 35.66822430921 139.74926236578742 21.249 35.6682190118837 139.74927921643445 21.249</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-efa2aece-9821-4cbd-ab4e-88a1797e023b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-efa2aece-9821-4cbd-ab4e-88a1797e023b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-efa2aece-9821-4cbd-ab4e-88a1797e023b">
											<gml:posList>35.66829333028787 139.74931819708863 21.8 35.66829970689265 139.7492979431376 21.8 35.66829741665801 139.74929687407842 21.8 35.66829212834069 139.7493137247291 21.8 35.6682190118837 139.74927921643445 21.8 35.66822430921 139.74926236578742 21.8 35.668221432882156 139.74926101014975 21.8 35.66821515521089 139.74928094364734 21.8 35.66829333028787 139.74931819708863 21.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0d97ebd3-d68b-4405-adf4-c36881a6ad3b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d97ebd3-d68b-4405-adf4-c36881a6ad3b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d97ebd3-d68b-4405-adf4-c36881a6ad3b">
											<gml:posList>35.6682190118837 139.74927921643445 21.8 35.6682190118837 139.74927921643445 21.249 35.66822430921 139.74926236578742 21.249 35.66822430921 139.74926236578742 21.8 35.6682190118837 139.74927921643445 21.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-067aa513-42d8-4320-9e67-6ce1c72b6f1c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-067aa513-42d8-4320-9e67-6ce1c72b6f1c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-067aa513-42d8-4320-9e67-6ce1c72b6f1c">
											<gml:posList>35.66822532475353 139.74925805679692 25.3 35.66822532475353 139.74925805679692 24.749 35.668230280311136 139.74924228901008 24.749 35.668230280311136 139.74924228901008 25.3 35.66822532475353 139.74925805679692 25.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7cb397e9-0d59-408d-8583-26c6c1d1eeea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7cb397e9-0d59-408d-8583-26c6c1d1eeea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7cb397e9-0d59-408d-8583-26c6c1d1eeea">
											<gml:posList>35.66821515521089 139.74928094364734 5.298 35.66821515521089 139.74928094364734 21.8 35.668221432882156 139.74926101014975 21.8 35.668221432882156 139.74926101014975 25.3 35.66822771055011 139.74924107664904 25.3 35.66822771055011 139.74924107664904 29.1 35.66825958448488 139.74913984006142 29.1 35.66825958448488 139.74913984006142 5.298 35.66821515521089 139.74928094364734 5.298</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ad9158f7-7a0d-4b6c-b01a-cb45d3ba4067">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad9158f7-7a0d-4b6c-b01a-cb45d3ba4067">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad9158f7-7a0d-4b6c-b01a-cb45d3ba4067">
											<gml:posList>35.668232657212315 139.7492383872919 29.1 35.668232657212315 139.7492383872919 28.577 35.66826177905294 139.7491458909478 28.577 35.66826177905294 139.7491458909478 29.1 35.668232657212315 139.7492383872919 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-301e8e47-137b-4dd9-a635-9c29b20bed93">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-301e8e47-137b-4dd9-a635-9c29b20bed93">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-301e8e47-137b-4dd9-a635-9c29b20bed93">
											<gml:posList>35.66821515521089 139.74928094364734 5.298 35.66829333028787 139.74931819708863 5.298 35.66829333028787 139.74931819708863 21.8 35.66821515521089 139.74928094364734 21.8 35.66821515521089 139.74928094364734 5.298</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dc25b9d3-4bed-465a-af0b-e4268908c13e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc25b9d3-4bed-465a-af0b-e4268908c13e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc25b9d3-4bed-465a-af0b-e4268908c13e">
											<gml:posList>35.66829212834069 139.7493137247291 21.8 35.66829212834069 139.7493137247291 21.249 35.6682190118837 139.74927921643445 21.249 35.6682190118837 139.74927921643445 21.8 35.66829212834069 139.7493137247291 21.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-54e84b79-6cfb-4d26-9ebc-2b9d4c21ff20">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-54e84b79-6cfb-4d26-9ebc-2b9d4c21ff20">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-54e84b79-6cfb-4d26-9ebc-2b9d4c21ff20">
											<gml:posList>35.66822430921 139.74926236578742 21.8 35.66822430921 139.74926236578742 21.249 35.66829741665801 139.74929687407842 21.249 35.66829741665801 139.74929687407842 21.8 35.66829970689265 139.7492979431376 21.8 35.66829970689265 139.7492979431376 25.3 35.668221432882156 139.74926101014975 25.3 35.668221432882156 139.74926101014975 21.8 35.66822430921 139.74926236578742 21.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-216d36c6-ed80-4f61-8237-9e7a201be34f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-216d36c6-ed80-4f61-8237-9e7a201be34f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-216d36c6-ed80-4f61-8237-9e7a201be34f">
											<gml:posList>35.668297169903084 139.74929202515474 25.3 35.668297169903084 139.74929202515474 24.749 35.66822532475353 139.74925805679692 24.749 35.66822532475353 139.74925805679692 25.3 35.668297169903084 139.74929202515474 25.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0f4ddb02-7fe8-45ee-a822-bcb2c0b89853">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0f4ddb02-7fe8-45ee-a822-bcb2c0b89853">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0f4ddb02-7fe8-45ee-a822-bcb2c0b89853">
											<gml:posList>35.668230280311136 139.74924228901008 25.3 35.668230280311136 139.74924228901008 24.749 35.66830213447879 139.74927625734642 24.749 35.66830213447879 139.74927625734642 25.3 35.66830596658542 139.749278075915 25.3 35.66830596658542 139.749278075915 29.1 35.66822771055011 139.74924107664904 29.1 35.66822771055011 139.74924107664904 25.3 35.668230280311136 139.74924228901008 25.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0468fe93-e002-4b75-a02e-bb33d8f7cbf3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0468fe93-e002-4b75-a02e-bb33d8f7cbf3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0468fe93-e002-4b75-a02e-bb33d8f7cbf3">
											<gml:posList>35.66826177905294 139.7491458909478 29.1 35.66826177905294 139.7491458909478 28.577 35.66827447462924 139.74915195290194 28.577 35.66827447462924 139.74915195290194 29.1 35.66826177905294 139.7491458909478 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6e242ec3-1452-4769-8278-afcf8493fe13">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e242ec3-1452-4769-8278-afcf8493fe13">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e242ec3-1452-4769-8278-afcf8493fe13">
											<gml:posList>35.66830378103003 139.74927201396622 29.1 35.66830378103003 139.74927201396622 28.577 35.668232657212315 139.7492383872919 28.577 35.668232657212315 139.7492383872919 29.1 35.66830378103003 139.74927201396622 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7eed215e-bf7e-4340-9360-673086e0cc61">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7eed215e-bf7e-4340-9360-673086e0cc61">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7eed215e-bf7e-4340-9360-673086e0cc61">
											<gml:posList>35.66826286348518 139.7492014620772 28.577 35.66826286348518 139.7492014620772 36.173 35.66827941229112 139.74914928563913 36.173 35.66827941229112 139.74914928563913 29.1 35.66827802722725 139.7491536502517 29.1 35.66827802722725 139.7491536502517 28.577 35.66826286348518 139.7492014620772 28.577</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cdb6840c-2569-45ba-abbb-12da80921b7e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cdb6840c-2569-45ba-abbb-12da80921b7e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cdb6840c-2569-45ba-abbb-12da80921b7e">
											<gml:posList>35.66827447462924 139.74915195290194 29.1 35.66827447462924 139.74915195290194 28.577 35.66827802722725 139.7491536502517 28.577 35.66827802722725 139.7491536502517 29.1 35.66827447462924 139.74915195290194 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-544a88bb-1b5b-44a1-8f3e-851b6dcf8bc4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-544a88bb-1b5b-44a1-8f3e-851b6dcf8bc4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-544a88bb-1b5b-44a1-8f3e-851b6dcf8bc4">
											<gml:posList>35.668270161865074 139.74919753310024 36.173 35.668270161865074 139.74919753310024 33.156 35.66828262743303 139.74915822950035 33.156 35.66828262743303 139.74915822950035 36.173 35.668270161865074 139.74919753310024 36.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6a914645-a9d2-4823-b7dc-abfd492f46b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a914645-a9d2-4823-b7dc-abfd492f46b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a914645-a9d2-4823-b7dc-abfd492f46b1">
											<gml:posList>35.668321318982585 139.74922931392638 36.173 35.66826286348518 139.7492014620772 36.173 35.66826286348518 139.7492014620772 28.577 35.668317766393386 139.7492276276183 28.577 35.668317766393386 139.7492276276183 29.1 35.668321318982585 139.74922931392638 29.1 35.668321318982585 139.74922931392638 36.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-173b00ea-1e93-48ab-a934-343e4860ed32">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-173b00ea-1e93-48ab-a934-343e4860ed32">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-173b00ea-1e93-48ab-a934-343e4860ed32">
											<gml:posList>35.668318103853686 139.74922038110395 36.173 35.668318103853686 139.74922038110395 33.156 35.668270161865074 139.74919753310024 33.156 35.668270161865074 139.74919753310024 36.173 35.668318103853686 139.74922038110395 36.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2c195be0-8574-4ac4-be41-89fc5c0e3890">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c195be0-8574-4ac4-be41-89fc5c0e3890">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c195be0-8574-4ac4-be41-89fc5c0e3890">
											<gml:posList>35.66829741665801 139.74929687407842 21.8 35.66829741665801 139.74929687407842 21.249 35.66829212834069 139.7493137247291 21.249 35.66829212834069 139.7493137247291 21.8 35.66829741665801 139.74929687407842 21.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f4e0de6a-b290-4965-b38a-ffd8b99b0740">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4e0de6a-b290-4965-b38a-ffd8b99b0740">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4e0de6a-b290-4965-b38a-ffd8b99b0740">
											<gml:posList>35.66825958448488 139.74913984006142 5.298 35.66825958448488 139.74913984006142 29.1 35.66827941229112 139.74914928563913 29.1 35.66827941229112 139.74914928563913 36.173 35.66833775960477 139.7491770933856 36.173 35.66833775960477 139.7491770933856 5.298 35.66825958448488 139.74913984006142 5.298</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ce697fa8-118c-42b1-89cc-03f3409fd7ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce697fa8-118c-42b1-89cc-03f3409fd7ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce697fa8-118c-42b1-89cc-03f3409fd7ae">
											<gml:posList>35.66830213447879 139.74927625734642 25.3 35.66830213447879 139.74927625734642 24.749 35.668297169903084 139.74929202515474 24.749 35.668297169903084 139.74929202515474 25.3 35.66830213447879 139.74927625734642 25.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-19930d9f-a7fa-4fff-b076-bbb25a84898e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-19930d9f-a7fa-4fff-b076-bbb25a84898e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-19930d9f-a7fa-4fff-b076-bbb25a84898e">
											<gml:posList>35.66828262743303 139.74915822950035 36.173 35.66828262743303 139.74915822950035 33.156 35.668330488282265 139.74918104443128 33.156 35.668330488282265 139.74918104443128 36.173 35.66828262743303 139.74915822950035 36.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b1aa8798-a903-4690-a393-49680aae2452">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b1aa8798-a903-4690-a393-49680aae2452">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b1aa8798-a903-4690-a393-49680aae2452">
											<gml:posList>35.66831639032499 139.74923197013024 29.1 35.66831639032499 139.74923197013024 28.577 35.66830378103003 139.74927201396622 28.577 35.66830378103003 139.74927201396622 29.1 35.66831639032499 139.74923197013024 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-697a615f-38f2-4b8c-9497-d7b49d37c176">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-697a615f-38f2-4b8c-9497-d7b49d37c176">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-697a615f-38f2-4b8c-9497-d7b49d37c176">
											<gml:posList>35.66830596658542 139.749278075915 25.3 35.66829970689265 139.7492979431376 25.3 35.66829970689265 139.7492979431376 21.8 35.66829333028787 139.74931819708863 21.8 35.66829333028787 139.74931819708863 5.298 35.66833775960477 139.7491770933856 5.298 35.66833775960477 139.7491770933856 36.173 35.668321318982585 139.74922931392638 36.173 35.668321318982585 139.74922931392638 29.1 35.66830596658542 139.749278075915 29.1 35.66830596658542 139.749278075915 25.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-26838833-277d-459e-8088-67a6a1483074">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26838833-277d-459e-8088-67a6a1483074">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26838833-277d-459e-8088-67a6a1483074">
											<gml:posList>35.668317766393386 139.7492276276183 29.1 35.668317766393386 139.7492276276183 28.577 35.66831639032499 139.74923197013024 28.577 35.66831639032499 139.74923197013024 29.1 35.668317766393386 139.7492276276183 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-102fce32-22a8-4a5c-a838-24b09d6c4fdc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-102fce32-22a8-4a5c-a838-24b09d6c4fdc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-102fce32-22a8-4a5c-a838-24b09d6c4fdc">
											<gml:posList>35.668330488282265 139.74918104443128 36.173 35.668330488282265 139.74918104443128 33.156 35.668318103853686 139.74922038110395 33.156 35.668318103853686 139.74922038110395 36.173 35.668330488282265 139.74918104443128 36.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6434</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">127.4131</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.03</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>