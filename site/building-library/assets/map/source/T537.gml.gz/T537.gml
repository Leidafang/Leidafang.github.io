<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_9b9ccd81-e164-4937-9224-1a4add6831cd">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">9.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66924411452607 139.74755048702437 0 35.669326168778525 139.74759160124574 0 35.669342721777625 139.74754629446414 0 35.66927577796551 139.74745943321898 0 35.66924411452607 139.74755048702437 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66924411452607 139.74755048702437 6.164 35.66927577796551 139.74745943321898 6.164 35.669342721777625 139.74754629446414 6.164 35.669326168778525 139.74759160124574 6.164 35.66924411452607 139.74755048702437 6.164</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66924411452607 139.74755048702437 6.164 35.669326168778525 139.74759160124574 6.164 35.669326168778525 139.74759160124574 15.35 35.66924411452607 139.74755048702437 15.35 35.66924411452607 139.74755048702437 6.164</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669326168778525 139.74759160124574 6.164 35.669342721777625 139.74754629446414 6.164 35.669342721777625 139.74754629446414 15.35 35.669326168778525 139.74759160124574 15.35 35.669326168778525 139.74759160124574 6.164</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669342721777625 139.74754629446414 6.164 35.66927577796551 139.74745943321898 6.164 35.66927577796551 139.74745943321898 15.35 35.669342721777625 139.74754629446414 15.35 35.669342721777625 139.74754629446414 6.164</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66927577796551 139.74745943321898 6.164 35.66924411452607 139.74755048702437 6.164 35.66924411452607 139.74755048702437 15.35 35.66927577796551 139.74745943321898 15.35 35.66927577796551 139.74745943321898 6.164</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66924411452607 139.74755048702437 15.35 35.669326168778525 139.74759160124574 15.35 35.669342721777625 139.74754629446414 15.35 35.66927577796551 139.74745943321898 15.35 35.66924411452607 139.74755048702437 15.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-d4c949d9-f100-4b36-80a2-00d9b9c753d8"/>
							<gml:surfaceMember xlink:href="#poly-f3dce9c9-6853-4449-b894-ba613ee24906"/>
							<gml:surfaceMember xlink:href="#poly-ee953f48-75db-4f58-a6b6-2e47755c0556"/>
							<gml:surfaceMember xlink:href="#poly-064ca0a9-e513-4882-a280-5aa82f049a78"/>
							<gml:surfaceMember xlink:href="#poly-232f425c-74b8-4b3b-8ea8-bc0363502dc2"/>
							<gml:surfaceMember xlink:href="#poly-b6f584cb-81a8-430b-8d49-5fcf7802efdb"/>
							<gml:surfaceMember xlink:href="#poly-d78c81bd-4b8c-445e-b460-d01122f01c16"/>
							<gml:surfaceMember xlink:href="#poly-bd7d8ed4-c425-4f48-a78a-bc7e0b53f10e"/>
							<gml:surfaceMember xlink:href="#poly-25f2dd95-6e9e-4340-912e-ae5e04cfab05"/>
							<gml:surfaceMember xlink:href="#poly-fba58f08-1d92-405a-a4f4-aefb7836741c"/>
							<gml:surfaceMember xlink:href="#poly-4bad9f66-75af-410f-a7c2-522eed18df4d"/>
							<gml:surfaceMember xlink:href="#poly-b8a052f1-a0de-4b71-8827-d43cee2828ed"/>
							<gml:surfaceMember xlink:href="#poly-aee90950-27da-4efe-8302-50fc706c5187"/>
							<gml:surfaceMember xlink:href="#poly-8456e32c-29e2-475e-bec2-c8160c706d2c"/>
							<gml:surfaceMember xlink:href="#poly-f0538758-223e-4e6b-b6a2-a1e3d5b53012"/>
							<gml:surfaceMember xlink:href="#poly-dd652f89-69f5-42a2-b372-253a8c09125b"/>
							<gml:surfaceMember xlink:href="#poly-2ed7ffdb-068a-4628-9d8e-52acd87169a8"/>
							<gml:surfaceMember xlink:href="#poly-1167c00b-818b-4db0-afc6-5243df8e8b6e"/>
							<gml:surfaceMember xlink:href="#poly-c7e48f1e-c028-4d08-8a63-646409afad73"/>
							<gml:surfaceMember xlink:href="#poly-e44ff2cb-fadf-4d79-8031-7083d7e0b29b"/>
							<gml:surfaceMember xlink:href="#poly-6f7b6bad-88f9-4daa-8042-0610fc88add4"/>
							<gml:surfaceMember xlink:href="#poly-1bb9e5b2-2202-43d5-94de-e89a77b00399"/>
							<gml:surfaceMember xlink:href="#poly-60194e25-e3c3-4534-90ed-4d63cf1df1ca"/>
							<gml:surfaceMember xlink:href="#poly-ae67edae-3291-4d66-8f52-9d63b8527575"/>
							<gml:surfaceMember xlink:href="#poly-cb3b6e97-6838-43a0-8f9b-f530e6bf51ef"/>
							<gml:surfaceMember xlink:href="#poly-19280938-cb00-49a9-96ed-f541d3036640"/>
							<gml:surfaceMember xlink:href="#poly-031e2553-e92a-4f14-9ada-fa95ccf7719a"/>
							<gml:surfaceMember xlink:href="#poly-71e30ef6-8eaa-47b5-985e-b2e6174595df"/>
							<gml:surfaceMember xlink:href="#poly-25a00c1b-7d5f-4bb1-8ea0-7f006f5bc1f4"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_9b9ccd81-e164-4937-9224-1a4add6831cd_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4efb5073-8faf-48f8-8511-a30d1ca09d08">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66928629336782 139.7475302164722 15.943 35.669297091198324 139.7475166955236 15.943 35.66930898146728 139.74753096542108 15.943 35.66929818362733 139.74754447532368 15.943 35.66928629336782 139.7475302164722 15.943</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c248fc46-3587-44c4-8611-4174e19dade7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c248fc46-3587-44c4-8611-4174e19dade7_0">
											<gml:posList>35.66928629336782 139.7475302164722 15.943 35.66928629336782 139.7475302164722 17.957 35.669297091198324 139.7475166955236 17.957 35.669297091198324 139.7475166955236 15.943 35.66928629336782 139.7475302164722 15.943</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b0532924-f8b0-4fd8-8438-474ee54607cd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b0532924-f8b0-4fd8-8438-474ee54607cd_0">
											<gml:posList>35.669297091198324 139.7475166955236 15.943 35.669297091198324 139.7475166955236 17.957 35.66930898146728 139.74753096542108 17.957 35.66930898146728 139.74753096542108 15.943 35.669297091198324 139.7475166955236 15.943</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef6c4793-269d-49b4-962b-98069b7a23c5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef6c4793-269d-49b4-962b-98069b7a23c5_0">
											<gml:posList>35.66930898146728 139.74753096542108 17.957 35.669297091198324 139.7475166955236 17.957 35.66928629336782 139.7475302164722 17.957 35.66929818362733 139.74754447532368 17.957 35.66930898146728 139.74753096542108 17.957</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b5f0ce72-41bd-4aa0-aaa4-e3dca9bb119c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b5f0ce72-41bd-4aa0-aaa4-e3dca9bb119c_0">
											<gml:posList>35.66929818362733 139.74754447532368 17.957 35.66928629336782 139.7475302164722 17.957 35.66928629336782 139.7475302164722 15.943 35.66929818362733 139.74754447532368 15.943 35.66929818362733 139.74754447532368 17.957</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-93eea872-1c82-48cd-98fb-4cefe3c2c09f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-93eea872-1c82-48cd-98fb-4cefe3c2c09f_0">
											<gml:posList>35.66930898146728 139.74753096542108 15.943 35.66930898146728 139.74753096542108 17.957 35.66929818362733 139.74754447532368 17.957 35.66929818362733 139.74754447532368 15.943 35.66930898146728 139.74753096542108 15.943</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-d4c949d9-f100-4b36-80a2-00d9b9c753d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4c949d9-f100-4b36-80a2-00d9b9c753d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4c949d9-f100-4b36-80a2-00d9b9c753d8">
											<gml:posList>35.66924411452607 139.74755048702434 6.164 35.66927577796551 139.74745943321898 6.164 35.66934272177761 139.74754629446414 6.164 35.66932616877852 139.74759160124574 6.164 35.66924411452607 139.74755048702434 6.164</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f3dce9c9-6853-4449-b894-ba613ee24906">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f3dce9c9-6853-4449-b894-ba613ee24906">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f3dce9c9-6853-4449-b894-ba613ee24906">
											<gml:posList>35.66924411452607 139.74755048702434 16.1 35.66924624100213 139.74754941327723 16.1 35.66927630328238 139.7474629674109 16.1 35.66927577796551 139.74745943321898 16.1 35.66924411452607 139.74755048702434 16.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ee953f48-75db-4f58-a6b6-2e47755c0556">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee953f48-75db-4f58-a6b6-2e47755c0556">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee953f48-75db-4f58-a6b6-2e47755c0556">
											<gml:posList>35.66930671019641 139.74758184624454 16.1 35.669305834024236 139.74757926239135 16.1 35.66924624100213 139.74754941327723 16.1 35.66924411452607 139.74755048702434 16.1 35.66930671019641 139.74758184624454 16.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-064ca0a9-e513-4882-a280-5aa82f049a78">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-064ca0a9-e513-4882-a280-5aa82f049a78">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-064ca0a9-e513-4882-a280-5aa82f049a78">
											<gml:posList>35.669305834024236 139.74757926239135 15.943 35.66930732182396 139.74758001193578 15.943 35.669318079289454 139.7475477789167 15.943 35.669337005867725 139.74755725832722 15.943 35.6693376174949 139.74755542401755 15.943 35.669340811135264 139.74754667207634 15.943 35.66927630328238 139.7474629674109 15.943 35.66924624100213 139.74754941327723 15.943 35.669305834024236 139.74757926239135 15.943</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-232f425c-74b8-4b3b-8ea8-bc0363502dc2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-232f425c-74b8-4b3b-8ea8-bc0363502dc2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-232f425c-74b8-4b3b-8ea8-bc0363502dc2">
											<gml:posList>35.669305834024236 139.74757926239135 16.1 35.66930671019641 139.74758184624454 16.1 35.66930732182396 139.74758001193578 16.1 35.669305834024236 139.74757926239135 16.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b6f584cb-81a8-430b-8d49-5fcf7802efdb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6f584cb-81a8-430b-8d49-5fcf7802efdb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6f584cb-81a8-430b-8d49-5fcf7802efdb">
											<gml:posList>35.66934272177761 139.74754629446414 16.1 35.66927577796551 139.74745943321898 16.1 35.66927630328238 139.7474629674109 16.1 35.669340811135264 139.74754667207634 16.1 35.66934272177761 139.74754629446414 16.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d78c81bd-4b8c-445e-b460-d01122f01c16">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d78c81bd-4b8c-445e-b460-d01122f01c16">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d78c81bd-4b8c-445e-b460-d01122f01c16">
											<gml:posList>35.66930671019641 139.74758184624454 18.033 35.66930752112497 139.7475814145789 18.033 35.6693184225193 139.7475487726997 18.033 35.669318079289454 139.7475477789167 18.033 35.66930671019641 139.74758184624454 18.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bd7d8ed4-c425-4f48-a78a-bc7e0b53f10e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd7d8ed4-c425-4f48-a78a-bc7e0b53f10e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd7d8ed4-c425-4f48-a78a-bc7e0b53f10e">
											<gml:posList>35.66932616877852 139.74759160124574 18.033 35.66932583456275 139.7475906074528 18.033 35.66930752112497 139.7475814145789 18.033 35.66930671019641 139.74758184624454 18.033 35.66932616877852 139.74759160124574 18.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-25f2dd95-6e9e-4340-912e-ae5e04cfab05">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25f2dd95-6e9e-4340-912e-ae5e04cfab05">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25f2dd95-6e9e-4340-912e-ae5e04cfab05">
											<gml:posList>35.66932583456275 139.7475906074528 17.773 35.66933761059782 139.74755839543027 17.773 35.6693184225193 139.7475487726997 17.773 35.66930752112497 139.7475814145789 17.773 35.66932583456275 139.7475906074528 17.773</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fba58f08-1d92-405a-a4f4-aefb7836741c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fba58f08-1d92-405a-a4f4-aefb7836741c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fba58f08-1d92-405a-a4f4-aefb7836741c">
											<gml:posList>35.669318079289454 139.7475477789167 18.033 35.6693184225193 139.7475487726997 18.033 35.66933761059782 139.74755839543027 18.033 35.66933844858321 139.74755798582748 18.033 35.669318079289454 139.7475477789167 18.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4bad9f66-75af-410f-a7c2-522eed18df4d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4bad9f66-75af-410f-a7c2-522eed18df4d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4bad9f66-75af-410f-a7c2-522eed18df4d">
											<gml:posList>35.66933844858321 139.74755798582748 18.033 35.66933761059782 139.74755839543027 18.033 35.66932583456275 139.7475906074528 18.033 35.66932616877852 139.74759160124574 18.033 35.66933844858321 139.74755798582748 18.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b8a052f1-a0de-4b71-8827-d43cee2828ed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8a052f1-a0de-4b71-8827-d43cee2828ed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8a052f1-a0de-4b71-8827-d43cee2828ed">
											<gml:posList>35.669337005867725 139.74755725832722 16.1 35.66933844858321 139.74755798582748 16.1 35.6693376174949 139.74755542401755 16.1 35.669337005867725 139.74755725832722 16.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-aee90950-27da-4efe-8302-50fc706c5187">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aee90950-27da-4efe-8302-50fc706c5187">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aee90950-27da-4efe-8302-50fc706c5187">
											<gml:posList>35.66934272177761 139.74754629446414 16.1 35.669340811135264 139.74754667207634 16.1 35.6693376174949 139.74755542401755 16.1 35.66933844858321 139.74755798582748 16.1 35.66934272177761 139.74754629446414 16.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8456e32c-29e2-475e-bec2-c8160c706d2c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8456e32c-29e2-475e-bec2-c8160c706d2c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8456e32c-29e2-475e-bec2-c8160c706d2c">
											<gml:posList>35.669305834024236 139.74757926239135 16.1 35.669305834024236 139.74757926239135 15.943 35.66924624100213 139.74754941327723 15.943 35.66924624100213 139.74754941327723 16.1 35.669305834024236 139.74757926239135 16.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f0538758-223e-4e6b-b6a2-a1e3d5b53012">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f0538758-223e-4e6b-b6a2-a1e3d5b53012">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f0538758-223e-4e6b-b6a2-a1e3d5b53012">
											<gml:posList>35.66930732182396 139.74758001193578 16.1 35.66930732182396 139.74758001193578 15.943 35.669305834024236 139.74757926239135 15.943 35.669305834024236 139.74757926239135 16.1 35.66930732182396 139.74758001193578 16.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dd652f89-69f5-42a2-b372-253a8c09125b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd652f89-69f5-42a2-b372-253a8c09125b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd652f89-69f5-42a2-b372-253a8c09125b">
											<gml:posList>35.66927630328238 139.7474629674109 16.1 35.66927630328238 139.7474629674109 15.943 35.669340811135264 139.74754667207634 15.943 35.669340811135264 139.74754667207634 16.1 35.66927630328238 139.7474629674109 16.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2ed7ffdb-068a-4628-9d8e-52acd87169a8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2ed7ffdb-068a-4628-9d8e-52acd87169a8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2ed7ffdb-068a-4628-9d8e-52acd87169a8">
											<gml:posList>35.6693184225193 139.7475487726997 18.033 35.6693184225193 139.7475487726997 17.773 35.66933761059782 139.74755839543027 17.773 35.66933761059782 139.74755839543027 18.033 35.6693184225193 139.7475487726997 18.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1167c00b-818b-4db0-afc6-5243df8e8b6e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1167c00b-818b-4db0-afc6-5243df8e8b6e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1167c00b-818b-4db0-afc6-5243df8e8b6e">
											<gml:posList>35.6693376174949 139.74755542401755 16.1 35.6693376174949 139.74755542401755 15.943 35.669337005867725 139.74755725832722 15.943 35.669337005867725 139.74755725832722 16.1 35.6693376174949 139.74755542401755 16.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c7e48f1e-c028-4d08-8a63-646409afad73">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c7e48f1e-c028-4d08-8a63-646409afad73">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c7e48f1e-c028-4d08-8a63-646409afad73">
											<gml:posList>35.66934272177761 139.74754629446414 6.164 35.66927577796551 139.74745943321898 6.164 35.66927577796551 139.74745943321898 16.1 35.66934272177761 139.74754629446414 16.1 35.66934272177761 139.74754629446414 6.164</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e44ff2cb-fadf-4d79-8031-7083d7e0b29b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e44ff2cb-fadf-4d79-8031-7083d7e0b29b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e44ff2cb-fadf-4d79-8031-7083d7e0b29b">
											<gml:posList>35.66927577796551 139.74745943321898 6.164 35.66924411452607 139.74755048702434 6.164 35.66924411452607 139.74755048702434 16.1 35.66927577796551 139.74745943321898 16.1 35.66927577796551 139.74745943321898 6.164</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6f7b6bad-88f9-4daa-8042-0610fc88add4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f7b6bad-88f9-4daa-8042-0610fc88add4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f7b6bad-88f9-4daa-8042-0610fc88add4">
											<gml:posList>35.66924624100213 139.74754941327723 16.1 35.66924624100213 139.74754941327723 15.943 35.66927630328238 139.7474629674109 15.943 35.66927630328238 139.7474629674109 16.1 35.66924624100213 139.74754941327723 16.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1bb9e5b2-2202-43d5-94de-e89a77b00399">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1bb9e5b2-2202-43d5-94de-e89a77b00399">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1bb9e5b2-2202-43d5-94de-e89a77b00399">
											<gml:posList>35.669340811135264 139.74754667207634 16.1 35.669340811135264 139.74754667207634 15.943 35.6693376174949 139.74755542401755 15.943 35.6693376174949 139.74755542401755 16.1 35.669340811135264 139.74754667207634 16.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-60194e25-e3c3-4534-90ed-4d63cf1df1ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-60194e25-e3c3-4534-90ed-4d63cf1df1ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-60194e25-e3c3-4534-90ed-4d63cf1df1ca">
											<gml:posList>35.669318079289454 139.7475477789167 15.943 35.669318079289454 139.7475477789167 18.033 35.66933844858321 139.74755798582748 18.033 35.66933844858321 139.74755798582748 16.1 35.669337005867725 139.74755725832722 16.1 35.669337005867725 139.74755725832722 15.943 35.669318079289454 139.7475477789167 15.943</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ae67edae-3291-4d66-8f52-9d63b8527575">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ae67edae-3291-4d66-8f52-9d63b8527575">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ae67edae-3291-4d66-8f52-9d63b8527575">
											<gml:posList>35.66930732182396 139.74758001193578 16.1 35.66930671019641 139.74758184624454 16.1 35.66930671019641 139.74758184624454 18.033 35.669318079289454 139.7475477789167 18.033 35.669318079289454 139.7475477789167 15.943 35.66930732182396 139.74758001193578 15.943 35.66930732182396 139.74758001193578 16.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cb3b6e97-6838-43a0-8f9b-f530e6bf51ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb3b6e97-6838-43a0-8f9b-f530e6bf51ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb3b6e97-6838-43a0-8f9b-f530e6bf51ef">
											<gml:posList>35.66930752112497 139.7475814145789 18.033 35.66930752112497 139.7475814145789 17.773 35.6693184225193 139.7475487726997 17.773 35.6693184225193 139.7475487726997 18.033 35.66930752112497 139.7475814145789 18.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-19280938-cb00-49a9-96ed-f541d3036640">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-19280938-cb00-49a9-96ed-f541d3036640">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-19280938-cb00-49a9-96ed-f541d3036640">
											<gml:posList>35.66933844858321 139.74755798582748 16.1 35.66933844858321 139.74755798582748 18.033 35.66932616877852 139.74759160124574 18.033 35.66932616877852 139.74759160124574 6.164 35.66934272177761 139.74754629446414 6.164 35.66934272177761 139.74754629446414 16.1 35.66933844858321 139.74755798582748 16.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-031e2553-e92a-4f14-9ada-fa95ccf7719a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-031e2553-e92a-4f14-9ada-fa95ccf7719a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-031e2553-e92a-4f14-9ada-fa95ccf7719a">
											<gml:posList>35.66932616877852 139.74759160124574 6.164 35.66932616877852 139.74759160124574 18.033 35.66930671019641 139.74758184624454 18.033 35.66930671019641 139.74758184624454 16.1 35.66924411452607 139.74755048702434 16.1 35.66924411452607 139.74755048702434 6.164 35.66932616877852 139.74759160124574 6.164</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-71e30ef6-8eaa-47b5-985e-b2e6174595df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-71e30ef6-8eaa-47b5-985e-b2e6174595df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-71e30ef6-8eaa-47b5-985e-b2e6174595df">
											<gml:posList>35.66933761059782 139.74755839543027 18.033 35.66933761059782 139.74755839543027 17.773 35.66932583456275 139.7475906074528 17.773 35.66932583456275 139.7475906074528 18.033 35.66933761059782 139.74755839543027 18.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-25a00c1b-7d5f-4bb1-8ea0-7f006f5bc1f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25a00c1b-7d5f-4bb1-8ea0-7f006f5bc1f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25a00c1b-7d5f-4bb1-8ea0-7f006f5bc1f4">
											<gml:posList>35.66932583456275 139.7475906074528 18.033 35.66932583456275 139.7475906074528 17.773 35.66930752112497 139.7475814145789 17.773 35.66930752112497 139.7475814145789 18.033 35.66932583456275 139.7475906074528 18.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1851</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">67.57901</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>