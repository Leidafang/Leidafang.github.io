<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_9cfe095f-a06b-4258-9314-9a24042f6141">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>永田町二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67459735078453 139.73998976933515 0 35.67463014545878 139.73999331032704 0 35.67463727057942 139.73989423391632 0 35.67460447589378 139.7398906819178 0 35.674571681216406 139.73988714096907 0 35.67457254615852 139.7398750436743 0 35.674520163011486 139.7398693824858 0 35.674510951183045 139.7399974591092 0 35.67456333432428 139.74000312038075 0 35.67456454709626 139.73998622835666 0 35.67459735078453 139.73998976933515 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67459735078453 139.73998976933515 28.32 35.67456454709626 139.73998622835666 28.32 35.67456333432428 139.74000312038075 28.32 35.674510951183045 139.7399974591092 28.32 35.674520163011486 139.7398693824858 28.32 35.67457254615852 139.7398750436743 28.32 35.674571681216406 139.73988714096907 28.32 35.67460447589378 139.7398906819178 28.32 35.67463727057942 139.73989423391632 28.32 35.67463014545878 139.73999331032704 28.32 35.67459735078453 139.73998976933515 28.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67459735078453 139.73998976933515 28.32 35.67463014545878 139.73999331032704 28.32 35.67463014545878 139.73999331032704 31.32 35.67459735078453 139.73998976933515 31.32 35.67459735078453 139.73998976933515 28.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67463014545878 139.73999331032704 28.32 35.67463727057942 139.73989423391632 28.32 35.67463727057942 139.73989423391632 31.32 35.67463014545878 139.73999331032704 31.32 35.67463014545878 139.73999331032704 28.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67463727057942 139.73989423391632 28.32 35.67460447589378 139.7398906819178 28.32 35.67460447589378 139.7398906819178 31.32 35.67463727057942 139.73989423391632 31.32 35.67463727057942 139.73989423391632 28.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67460447589378 139.7398906819178 28.32 35.674571681216406 139.73988714096907 28.32 35.674571681216406 139.73988714096907 31.32 35.67460447589378 139.7398906819178 31.32 35.67460447589378 139.7398906819178 28.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674571681216406 139.73988714096907 28.32 35.67457254615852 139.7398750436743 28.32 35.67457254615852 139.7398750436743 31.32 35.674571681216406 139.73988714096907 31.32 35.674571681216406 139.73988714096907 28.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67457254615852 139.7398750436743 28.32 35.674520163011486 139.7398693824858 28.32 35.674520163011486 139.7398693824858 31.32 35.67457254615852 139.7398750436743 31.32 35.67457254615852 139.7398750436743 28.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674520163011486 139.7398693824858 28.32 35.674510951183045 139.7399974591092 28.32 35.674510951183045 139.7399974591092 31.32 35.674520163011486 139.7398693824858 31.32 35.674520163011486 139.7398693824858 28.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674510951183045 139.7399974591092 28.32 35.67456333432428 139.74000312038075 28.32 35.67456333432428 139.74000312038075 31.32 35.674510951183045 139.7399974591092 31.32 35.674510951183045 139.7399974591092 28.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67456333432428 139.74000312038075 28.32 35.67456454709626 139.73998622835666 28.32 35.67456454709626 139.73998622835666 31.32 35.67456333432428 139.74000312038075 31.32 35.67456333432428 139.74000312038075 28.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67456454709626 139.73998622835666 28.32 35.67459735078453 139.73998976933515 28.32 35.67459735078453 139.73998976933515 31.32 35.67456454709626 139.73998622835666 31.32 35.67456454709626 139.73998622835666 28.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67459735078453 139.73998976933515 31.32 35.67463014545878 139.73999331032704 31.32 35.67463727057942 139.73989423391632 31.32 35.67460447589378 139.7398906819178 31.32 35.674571681216406 139.73988714096907 31.32 35.67457254615852 139.7398750436743 31.32 35.674520163011486 139.7398693824858 31.32 35.674510951183045 139.7399974591092 31.32 35.67456333432428 139.74000312038075 31.32 35.67456454709626 139.73998622835666 31.32 35.67459735078453 139.73998976933515 31.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-8a833283-5b20-4486-ba5a-cc14df8c4dd2"/>
							<gml:surfaceMember xlink:href="#poly-41f3c3a1-ea40-4858-8db7-9a7e4fbda634"/>
							<gml:surfaceMember xlink:href="#poly-a3e85c38-43e9-4e9a-98a0-497d2f78df75"/>
							<gml:surfaceMember xlink:href="#poly-e3b901af-efdf-46fa-b88a-b9077211b071"/>
							<gml:surfaceMember xlink:href="#poly-d342f101-14e7-4d0c-a167-c11e8aeec181"/>
							<gml:surfaceMember xlink:href="#poly-dab0ec20-42d4-4220-94f8-82287dc2e1b9"/>
							<gml:surfaceMember xlink:href="#poly-b75d61a8-635a-4ece-b4f7-e641b33ec698"/>
							<gml:surfaceMember xlink:href="#poly-450acd79-fc5f-4d37-a86c-bdc225ae4626"/>
							<gml:surfaceMember xlink:href="#poly-f34049bf-0ac8-495d-93b2-2c3ce2919b36"/>
							<gml:surfaceMember xlink:href="#poly-a2e4a16b-9a19-4759-89ae-dc11076543be"/>
							<gml:surfaceMember xlink:href="#poly-e8841677-41f1-46d4-a831-a1902268b3ec"/>
							<gml:surfaceMember xlink:href="#poly-e5cd83f3-a01f-41b3-975a-0657f6f15d0a"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-8a833283-5b20-4486-ba5a-cc14df8c4dd2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a833283-5b20-4486-ba5a-cc14df8c4dd2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a833283-5b20-4486-ba5a-cc14df8c4dd2">
											<gml:posList>35.67452016301149 139.73986938248578 28.32 35.674572546158544 139.73987504367426 28.32 35.6745716812164 139.73988714096905 28.32 35.67463727057941 139.7398942339163 28.32 35.67463014545878 139.73999331032704 28.32 35.67456454709625 139.73998622835666 28.32 35.67456333432427 139.74000312038075 28.32 35.67451095118304 139.7399974591092 28.32 35.67452016301149 139.73986938248578 28.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-41f3c3a1-ea40-4858-8db7-9a7e4fbda634">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41f3c3a1-ea40-4858-8db7-9a7e4fbda634">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41f3c3a1-ea40-4858-8db7-9a7e4fbda634">
											<gml:posList>35.67451095118304 139.7399974591092 30.496 35.67456333432427 139.74000312038075 30.496 35.67456454709625 139.73998622835666 30.496 35.6745716812164 139.73988714096905 30.496 35.674572546158544 139.73987504367426 30.496 35.67452016301149 139.73986938248578 30.496 35.67451095118304 139.7399974591092 30.496</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a3e85c38-43e9-4e9a-98a0-497d2f78df75">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a3e85c38-43e9-4e9a-98a0-497d2f78df75">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a3e85c38-43e9-4e9a-98a0-497d2f78df75">
											<gml:posList>35.67460447589376 139.7398906819178 32.699 35.6745716812164 139.73988714096905 30.496 35.67456454709625 139.73998622835666 30.496 35.67459735078451 139.73998976933515 32.699 35.67460447589376 139.7398906819178 32.699</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e3b901af-efdf-46fa-b88a-b9077211b071">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e3b901af-efdf-46fa-b88a-b9077211b071">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e3b901af-efdf-46fa-b88a-b9077211b071">
											<gml:posList>35.67463014545878 139.73999331032704 30.496 35.67463727057941 139.7398942339163 30.496 35.67460447589376 139.7398906819178 32.699 35.67459735078451 139.73998976933515 32.699 35.67463014545878 139.73999331032704 30.496</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d342f101-14e7-4d0c-a167-c11e8aeec181">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d342f101-14e7-4d0c-a167-c11e8aeec181">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d342f101-14e7-4d0c-a167-c11e8aeec181">
											<gml:posList>35.67452016301149 139.73986938248578 28.32 35.67451095118304 139.7399974591092 28.32 35.67451095118304 139.7399974591092 30.496 35.67452016301149 139.73986938248578 30.496 35.67452016301149 139.73986938248578 28.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dab0ec20-42d4-4220-94f8-82287dc2e1b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dab0ec20-42d4-4220-94f8-82287dc2e1b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dab0ec20-42d4-4220-94f8-82287dc2e1b9">
											<gml:posList>35.67451095118304 139.7399974591092 28.32 35.67456333432427 139.74000312038075 28.32 35.67456333432427 139.74000312038075 30.496 35.67451095118304 139.7399974591092 30.496 35.67451095118304 139.7399974591092 28.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b75d61a8-635a-4ece-b4f7-e641b33ec698">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b75d61a8-635a-4ece-b4f7-e641b33ec698">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b75d61a8-635a-4ece-b4f7-e641b33ec698">
											<gml:posList>35.674572546158544 139.73987504367426 28.32 35.67452016301149 139.73986938248578 28.32 35.67452016301149 139.73986938248578 30.496 35.674572546158544 139.73987504367426 30.496 35.674572546158544 139.73987504367426 28.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-450acd79-fc5f-4d37-a86c-bdc225ae4626">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-450acd79-fc5f-4d37-a86c-bdc225ae4626">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-450acd79-fc5f-4d37-a86c-bdc225ae4626">
											<gml:posList>35.67456333432427 139.74000312038075 30.496 35.67456333432427 139.74000312038075 28.32 35.67456454709625 139.73998622835666 28.32 35.67456454709625 139.73998622835666 30.496 35.67456333432427 139.74000312038075 30.496</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f34049bf-0ac8-495d-93b2-2c3ce2919b36">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f34049bf-0ac8-495d-93b2-2c3ce2919b36">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f34049bf-0ac8-495d-93b2-2c3ce2919b36">
											<gml:posList>35.674572546158544 139.73987504367426 28.32 35.674572546158544 139.73987504367426 30.496 35.6745716812164 139.73988714096905 30.496 35.6745716812164 139.73988714096905 28.32 35.674572546158544 139.73987504367426 28.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a2e4a16b-9a19-4759-89ae-dc11076543be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2e4a16b-9a19-4759-89ae-dc11076543be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2e4a16b-9a19-4759-89ae-dc11076543be">
											<gml:posList>35.67456454709625 139.73998622835666 28.32 35.67463014545878 139.73999331032704 28.32 35.67463014545878 139.73999331032704 30.496 35.67459735078451 139.73998976933515 32.699 35.67456454709625 139.73998622835666 30.496 35.67456454709625 139.73998622835666 28.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e8841677-41f1-46d4-a831-a1902268b3ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8841677-41f1-46d4-a831-a1902268b3ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8841677-41f1-46d4-a831-a1902268b3ec">
											<gml:posList>35.67463727057941 139.7398942339163 28.32 35.6745716812164 139.73988714096905 28.32 35.6745716812164 139.73988714096905 30.496 35.67460447589376 139.7398906819178 32.699 35.67463727057941 139.7398942339163 30.496 35.67463727057941 139.7398942339163 28.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e5cd83f3-a01f-41b3-975a-0657f6f15d0a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5cd83f3-a01f-41b3-975a-0657f6f15d0a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5cd83f3-a01f-41b3-975a-0657f6f15d0a">
											<gml:posList>35.67463014545878 139.73999331032704 30.496 35.67463014545878 139.73999331032704 28.32 35.67463727057941 139.7398942339163 28.32 35.67463727057941 139.7398942339163 30.496 35.67463014545878 139.73999331032704 30.496</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4602</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>