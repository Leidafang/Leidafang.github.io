<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_9d5f369d-8db9-4674-957f-551e64a374ae">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">14.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67228296221034 139.73974949579625 0 35.672359045502084 139.73964313934684 0 35.67229102513424 139.73957009085683 0 35.67221494190619 139.739676447285 0 35.67228296221034 139.73974949579625 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67228296221034 139.73974949579625 8.013 35.67221494190619 139.739676447285 8.013 35.67229102513424 139.73957009085683 8.013 35.672359045502084 139.73964313934684 8.013 35.67228296221034 139.73974949579625 8.013</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67228296221034 139.73974949579625 8.013 35.672359045502084 139.73964313934684 8.013 35.672359045502084 139.73964313934684 22.66 35.67228296221034 139.73974949579625 22.66 35.67228296221034 139.73974949579625 8.013</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672359045502084 139.73964313934684 8.013 35.67229102513424 139.73957009085683 8.013 35.67229102513424 139.73957009085683 22.66 35.672359045502084 139.73964313934684 22.66 35.672359045502084 139.73964313934684 8.013</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67229102513424 139.73957009085683 8.013 35.67221494190619 139.739676447285 8.013 35.67221494190619 139.739676447285 22.66 35.67229102513424 139.73957009085683 22.66 35.67229102513424 139.73957009085683 8.013</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67221494190619 139.739676447285 8.013 35.67228296221034 139.73974949579625 8.013 35.67228296221034 139.73974949579625 22.66 35.67221494190619 139.739676447285 22.66 35.67221494190619 139.739676447285 8.013</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67228296221034 139.73974949579625 22.66 35.672359045502084 139.73964313934684 22.66 35.67229102513424 139.73957009085683 22.66 35.67221494190619 139.739676447285 22.66 35.67228296221034 139.73974949579625 22.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-923766df-eebc-45bf-9615-74e904a1585f"/>
							<gml:surfaceMember xlink:href="#poly-fedd31c6-f80e-4db1-aade-c644386c9057"/>
							<gml:surfaceMember xlink:href="#poly-744558d7-1ac8-4a96-996e-434a6011b19e"/>
							<gml:surfaceMember xlink:href="#poly-aa844f95-2264-4d31-99f3-136870c5b5b4"/>
							<gml:surfaceMember xlink:href="#poly-c5796a22-81f7-4b19-8b6b-6d8816ef996b"/>
							<gml:surfaceMember xlink:href="#poly-0bc2546d-9823-4c09-b022-5da9027b0466"/>
							<gml:surfaceMember xlink:href="#poly-b12ed722-5351-428b-94c7-61a1a7267a0e"/>
							<gml:surfaceMember xlink:href="#poly-3d9e5da7-d948-48f0-9ef7-3fd950a246b8"/>
							<gml:surfaceMember xlink:href="#poly-22ba529d-52b8-4d42-829a-35011c091a50"/>
							<gml:surfaceMember xlink:href="#poly-c57a54cf-03c3-49df-aa5c-8b185a18ecfc"/>
							<gml:surfaceMember xlink:href="#poly-749d5d4d-24f2-485e-b863-28436d39c3f4"/>
							<gml:surfaceMember xlink:href="#poly-d924b736-e5c1-45f5-b19f-1bee709bdf9b"/>
							<gml:surfaceMember xlink:href="#poly-9382ac14-e489-4c88-a15d-d4f74b22a7eb"/>
							<gml:surfaceMember xlink:href="#poly-3e7adf39-bc9a-45a1-86bd-8286cef497e4"/>
							<gml:surfaceMember xlink:href="#poly-37504c14-0bd9-4fea-93f6-e52f0be9e5c3"/>
							<gml:surfaceMember xlink:href="#poly-5100f2e8-afe7-49bd-8f8b-ad546174853d"/>
							<gml:surfaceMember xlink:href="#poly-22ef5e6f-b943-44af-9af6-c2d6adddcb12"/>
							<gml:surfaceMember xlink:href="#poly-d7b4d5a7-88a5-4e7a-a7a4-3bb8ad950a6d"/>
							<gml:surfaceMember xlink:href="#poly-3f1132b7-e9fe-40ce-a712-469ca6e2770a"/>
							<gml:surfaceMember xlink:href="#poly-5de19f76-682e-4a66-aa28-f94fa2c741db"/>
							<gml:surfaceMember xlink:href="#poly-52a7940a-7dbe-47a4-8126-e524b4bd2e99"/>
							<gml:surfaceMember xlink:href="#poly-b6ce9654-90f0-4f83-bd7d-0bbb00a60bd3"/>
							<gml:surfaceMember xlink:href="#poly-ee00e206-7500-465b-8a2f-14bf23b340b2"/>
							<gml:surfaceMember xlink:href="#poly-8b7bf874-c40c-4c67-830d-d16e91ed4e9c"/>
							<gml:surfaceMember xlink:href="#poly-ee002eca-237a-4e0c-8909-3cf6c49aa37d"/>
							<gml:surfaceMember xlink:href="#poly-ef676bb9-ee2d-4cfe-b159-ea59c81e5ea7"/>
							<gml:surfaceMember xlink:href="#poly-9790430d-8e08-4fbb-978d-8fc971e5bf27"/>
							<gml:surfaceMember xlink:href="#poly-e01dc60f-7e89-43fb-9fd5-ff31ef6cd103"/>
							<gml:surfaceMember xlink:href="#poly-59c33640-bac2-4b4b-ab8d-528f28ba049b"/>
							<gml:surfaceMember xlink:href="#poly-f1e66acf-beb8-4df9-b693-2d89a2713d9a"/>
							<gml:surfaceMember xlink:href="#poly-dd1ddaad-3e64-45f0-8403-1c0b932dbbcd"/>
							<gml:surfaceMember xlink:href="#poly-385a540e-8010-4b0a-bde2-8cfb10e73190"/>
							<gml:surfaceMember xlink:href="#poly-773fd82a-3939-43bb-aa86-025d41698002"/>
							<gml:surfaceMember xlink:href="#poly-9d8ca59e-d519-4d47-a0e1-c2871b001539"/>
							<gml:surfaceMember xlink:href="#poly-5b48e52d-1a87-4632-9430-481a0241fdc5"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_9d5f369d-8db9-4674-957f-551e64a374ae_BuildingInstallation_1061">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff6401b8-7151-4857-a9ca-776a7da4b962">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67223707559534 139.73969444934127 23.067 35.67224015185086 139.739697759703 23.067 35.67226122604023 139.73972106533688 23.067 35.67226131608296 139.73972094372004 23.067 35.67226250692452 139.7397222679118 23.067 35.672269367992925 139.7397127598937 23.067 35.67226965668103 139.73971307990567 23.067 35.672261372698706 139.7397242023769 23.067 35.67223900832824 139.73969932964374 23.067 35.67223594106931 139.7396959971785 23.067 35.67223707559534 139.73969444934127 23.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d603e0b9-6ff6-4fe6-ba89-f76f5f62585a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67226131608296 139.73972094372004 22.789 35.67226829442409 139.73971155707673 22.789 35.672269367992925 139.7397127598937 22.789 35.67226250692452 139.7397222679118 22.789 35.67226131608296 139.73972094372004 22.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e94a1cbb-393b-4367-a2a4-1f20a2f1de1c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67227114514035 139.73961033448595 22.789 35.672276773647866 139.73961539825908 22.789 35.67228224010921 139.73960913953786 22.789 35.67231702630054 139.73964673438618 22.789 35.67231147082592 139.73965444030642 22.789 35.67227761469954 139.7397000688578 22.789 35.67227701023915 139.73969937363293 22.789 35.672276613300475 139.7396989432822 22.789 35.67231518767364 139.73964695746528 22.789 35.67228226889579 139.73961138194807 22.789 35.672276874475315 139.73961755221276 22.789 35.672271318120636 139.73961254358773 22.789 35.67224970751899 139.73964125665495 22.789 35.67224868810913 139.73964015319459 22.789 35.67227114514035 139.73961033448595 22.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f054431-0079-4408-9223-5cbc4793572a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67231702630054 139.73964673438618 23.067 35.67231711651509 139.7396468336995 23.067 35.67231147082592 139.73965444030642 23.067 35.67231702630054 139.73964673438618 23.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fd857420-f200-4176-aae6-dce1eee1cb26">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fd857420-f200-4176-aae6-dce1eee1cb26_0">
											<gml:posList>35.67226250692452 139.7397222679118 23.067 35.67226131608296 139.73972094372004 23.067 35.67226131608296 139.73972094372004 22.789 35.67226250692452 139.7397222679118 22.789 35.67226250692452 139.7397222679118 23.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b963fac5-83f2-4c0c-8cf5-8d1e2005f45f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b963fac5-83f2-4c0c-8cf5-8d1e2005f45f_0">
											<gml:posList>35.672276773647866 139.73961539825908 22.789 35.672276773647866 139.73961539825908 24.125 35.67228224010921 139.73960913953786 24.125 35.67228224010921 139.73960913953786 22.789 35.672276773647866 139.73961539825908 22.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-91cc9924-52b6-4b24-879d-4a3ef430d2e9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-91cc9924-52b6-4b24-879d-4a3ef430d2e9_0">
											<gml:posList>35.67227114514035 139.73961033448595 24.125 35.672276773647866 139.73961539825908 24.125 35.672276773647866 139.73961539825908 22.789 35.67227114514035 139.73961033448595 22.789 35.67227114514035 139.73961033448595 24.125</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-925133eb-5337-470a-829c-3d06aceadad8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-925133eb-5337-470a-829c-3d06aceadad8_0">
											<gml:posList>35.672276874475315 139.73961755221276 22.789 35.67228226889579 139.73961138194807 22.789 35.67228226889579 139.73961138194807 24.125 35.672276874475315 139.73961755221276 24.125 35.672276874475315 139.73961755221276 22.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-436d6514-2194-4487-a954-579c84824dc2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-436d6514-2194-4487-a954-579c84824dc2_0">
											<gml:posList>35.672271318120636 139.73961254358773 22.789 35.672276874475315 139.73961755221276 22.789 35.672276874475315 139.73961755221276 24.125 35.672271318120636 139.73961254358773 24.125 35.672271318120636 139.73961254358773 22.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-12aa06b4-7347-4102-b575-286b9ce1552d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-12aa06b4-7347-4102-b575-286b9ce1552d_0">
											<gml:posList>35.67227114514035 139.73961033448595 22.789 35.67224868810913 139.73964015319459 22.789 35.67224868810913 139.73964015319459 24.125 35.67227114514035 139.73961033448595 24.125 35.67227114514035 139.73961033448595 22.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8aebea35-69f2-46b8-b281-b9dc2bf8e6e7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8aebea35-69f2-46b8-b281-b9dc2bf8e6e7_0">
											<gml:posList>35.672271318120636 139.73961254358773 22.789 35.672271318120636 139.73961254358773 24.125 35.67224970751899 139.73964125665495 24.125 35.67224970751899 139.73964125665495 22.789 35.672271318120636 139.73961254358773 22.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a2486b7-79ea-48d2-abbb-9f2ebd22fc00">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4a2486b7-79ea-48d2-abbb-9f2ebd22fc00_0">
											<gml:posList>35.67228224010921 139.73960913953786 22.789 35.67228224010921 139.73960913953786 24.125 35.67231711651509 139.7396468336995 24.125 35.67231711651509 139.7396468336995 23.067 35.67231702630054 139.73964673438618 23.067 35.67231702630054 139.73964673438618 22.789 35.67228224010921 139.73960913953786 22.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8b51540-2b78-4243-8d91-ceacdb8531af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d8b51540-2b78-4243-8d91-ceacdb8531af_0">
											<gml:posList>35.67228226889579 139.73961138194807 22.789 35.67231518767364 139.73964695746528 22.789 35.67231518767364 139.73964695746528 24.125 35.67228226889579 139.73961138194807 24.125 35.67228226889579 139.73961138194807 22.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-45ecd1da-ec13-4ef9-ae30-153aa9df454c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-45ecd1da-ec13-4ef9-ae30-153aa9df454c_0">
											<gml:posList>35.67224868810913 139.73964015319459 22.789 35.67224970751899 139.73964125665495 22.789 35.67224970751899 139.73964125665495 24.125 35.67224868810913 139.73964015319459 24.125 35.67224868810913 139.73964015319459 22.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-630b1490-e8b7-4ff8-b76b-f759000b6c04">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-630b1490-e8b7-4ff8-b76b-f759000b6c04_0">
											<gml:posList>35.67231702630054 139.73964673438618 22.789 35.67231702630054 139.73964673438618 23.067 35.67231147082592 139.73965444030642 23.067 35.67231147082592 139.73965444030642 22.789 35.67231702630054 139.73964673438618 22.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e4a9d729-6bf0-4d93-b9ab-14190e5e318f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e4a9d729-6bf0-4d93-b9ab-14190e5e318f_0">
											<gml:posList>35.67224970751899 139.73964125665495 24.125 35.672271318120636 139.73961254358773 24.125 35.672276874475315 139.73961755221276 24.125 35.67228226889579 139.73961138194807 24.125 35.67231518767364 139.73964695746528 24.125 35.672276613300475 139.7396989432822 24.125 35.67227701023915 139.73969937363293 24.125 35.67227761469954 139.7397000688578 24.125 35.67231711651509 139.7396468336995 24.125 35.67228224010921 139.73960913953786 24.125 35.672276773647866 139.73961539825908 24.125 35.67227114514035 139.73961033448595 24.125 35.67224868810913 139.73964015319459 24.125 35.67224970751899 139.73964125665495 24.125</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dff0b2cb-45b9-4079-bc2c-9374a9c5f8ae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dff0b2cb-45b9-4079-bc2c-9374a9c5f8ae_0">
											<gml:posList>35.67231518767364 139.73964695746528 22.789 35.672276613300475 139.7396989432822 22.789 35.672276613300475 139.7396989432822 24.125 35.67231518767364 139.73964695746528 24.125 35.67231518767364 139.73964695746528 22.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-080ef690-b76d-4b33-b177-e3bcf22a9dff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-080ef690-b76d-4b33-b177-e3bcf22a9dff_0">
											<gml:posList>35.67231711651509 139.7396468336995 24.125 35.67227761469954 139.7397000688578 24.125 35.67227761469954 139.7397000688578 22.789 35.67231147082592 139.73965444030642 22.789 35.67231147082592 139.73965444030642 23.067 35.67231711651509 139.7396468336995 23.067 35.67231711651509 139.7396468336995 24.125</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3b58df1-7773-4861-a0df-c6d5b5895812">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3b58df1-7773-4861-a0df-c6d5b5895812_0">
											<gml:posList>35.67223707559534 139.73969444934127 23.067 35.67223594106931 139.7396959971785 23.067 35.67223594106931 139.7396959971785 24.125 35.67223707559534 139.73969444934127 24.125 35.67223707559534 139.73969444934127 23.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a4d15aa-2483-47ee-9086-986eba803692">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7a4d15aa-2483-47ee-9086-986eba803692_0">
											<gml:posList>35.67224015185086 139.739697759703 23.067 35.67223707559534 139.73969444934127 23.067 35.67223707559534 139.73969444934127 24.125 35.67224015185086 139.739697759703 24.125 35.67224015185086 139.739697759703 23.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1fd106f-e8af-4d3a-8138-b1a9e5b9cac2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c1fd106f-e8af-4d3a-8138-b1a9e5b9cac2_0">
											<gml:posList>35.67223900832824 139.73969932964374 23.067 35.67223900832824 139.73969932964374 24.125 35.67223594106931 139.7396959971785 24.125 35.67223594106931 139.7396959971785 23.067 35.67223900832824 139.73969932964374 23.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73767c25-f572-4b29-ac79-fdaf0a437fd4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73767c25-f572-4b29-ac79-fdaf0a437fd4_0">
											<gml:posList>35.672276613300475 139.7396989432822 22.789 35.67227701023915 139.73969937363293 22.789 35.67227701023915 139.73969937363293 24.125 35.672276613300475 139.7396989432822 24.125 35.672276613300475 139.7396989432822 22.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29a32775-fe67-4ba9-a7c1-db841d81e17f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29a32775-fe67-4ba9-a7c1-db841d81e17f_0">
											<gml:posList>35.67227701023915 139.73969937363293 22.789 35.67227761469954 139.7397000688578 22.789 35.67227761469954 139.7397000688578 24.125 35.67227701023915 139.73969937363293 24.125 35.67227701023915 139.73969937363293 22.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04d975b4-7c64-4358-a8c1-49ef4a5f7963">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-04d975b4-7c64-4358-a8c1-49ef4a5f7963_0">
											<gml:posList>35.67226122604023 139.73972106533688 24.125 35.67224015185086 139.739697759703 24.125 35.67223707559534 139.73969444934127 24.125 35.67223594106931 139.7396959971785 24.125 35.67223900832824 139.73969932964374 24.125 35.672261372698706 139.7397242023769 24.125 35.67226965668103 139.73971307990567 24.125 35.67226829442409 139.73971155707673 24.125 35.67226122604023 139.73972106533688 24.125</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eaaf4681-321e-48a4-9cb2-d3cf24fd49a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eaaf4681-321e-48a4-9cb2-d3cf24fd49a8_0">
											<gml:posList>35.67226122604023 139.73972106533688 23.067 35.67224015185086 139.739697759703 23.067 35.67224015185086 139.739697759703 24.125 35.67226122604023 139.73972106533688 24.125 35.67226122604023 139.73972106533688 23.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7edb2989-a2be-4d1b-b2be-e64ca9e6e9c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7edb2989-a2be-4d1b-b2be-e64ca9e6e9c7_0">
											<gml:posList>35.672261372698706 139.7397242023769 23.067 35.672261372698706 139.7397242023769 24.125 35.67223900832824 139.73969932964374 24.125 35.67223900832824 139.73969932964374 23.067 35.672261372698706 139.7397242023769 23.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3aa0cd31-5580-41b1-8cf3-83cfea06cb03">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3aa0cd31-5580-41b1-8cf3-83cfea06cb03_0">
											<gml:posList>35.67226829442409 139.73971155707673 22.789 35.67226829442409 139.73971155707673 24.125 35.67226965668103 139.73971307990567 24.125 35.67226965668103 139.73971307990567 23.067 35.672269367992925 139.7397127598937 23.067 35.672269367992925 139.7397127598937 22.789 35.67226829442409 139.73971155707673 22.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-165b8f4a-b7b3-4ce3-a710-4996ec839b25">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-165b8f4a-b7b3-4ce3-a710-4996ec839b25_0">
											<gml:posList>35.67226122604023 139.73972106533688 24.125 35.67226829442409 139.73971155707673 24.125 35.67226829442409 139.73971155707673 22.789 35.67226131608296 139.73972094372004 22.789 35.67226131608296 139.73972094372004 23.067 35.67226122604023 139.73972106533688 23.067 35.67226122604023 139.73972106533688 24.125</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b664db36-07d4-44a8-a69c-b08ba3d84eb8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b664db36-07d4-44a8-a69c-b08ba3d84eb8_0">
											<gml:posList>35.67226250692452 139.7397222679118 22.789 35.672269367992925 139.7397127598937 22.789 35.672269367992925 139.7397127598937 23.067 35.67226250692452 139.7397222679118 23.067 35.67226250692452 139.7397222679118 22.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-89b0be76-3c9d-4554-b732-bd788b64c674">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-89b0be76-3c9d-4554-b732-bd788b64c674_0">
											<gml:posList>35.672261372698706 139.7397242023769 23.067 35.67226965668103 139.73971307990567 23.067 35.67226965668103 139.73971307990567 24.125 35.672261372698706 139.7397242023769 24.125 35.672261372698706 139.7397242023769 23.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_9d5f369d-8db9-4674-957f-551e64a374ae_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b7aa807-385c-4a6d-b2f2-8010ca717943">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672270841098666 139.7396366145121 22.789 35.672267248690204 139.73964184371422 22.789 35.67225871485204 139.73963303856564 22.789 35.67226230726012 139.7396278093637 22.789 35.672270841098666 139.7396366145121 22.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a802bb09-c05a-4e75-81b1-f802674ccd53">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6722562059299 139.73969856944174 22.789 35.67226492174365 139.73968638599834 22.789 35.672276613300475 139.7396989432822 22.789 35.67227700122543 139.73969937364345 22.789 35.67226828541038 139.73971155708728 22.789 35.6722562059299 139.73969856944174 22.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8211703b-502e-420a-bbea-6dbc594ea95f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672263266493225 139.73965583326074 22.789 35.672262183935906 139.7396546635947 22.789 35.67226085781046 139.73965324014335 22.789 35.672269015370674 139.7396418306031 22.789 35.6722788395366 139.73965239064282 22.789 35.67226530661937 139.7396713070502 22.789 35.67226179735229 139.73966754428713 22.789 35.67226315694596 139.73966564269745 22.789 35.672259250739884 139.73966144958428 22.789 35.672263266493225 139.73965583326074 22.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf5e4f52-9b5c-4115-9c86-a1245692cfe7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672263644485774 139.7396782572524 22.789 35.67227531359221 139.7396619500031 22.789 35.67228653605149 139.73967401073952 22.789 35.67227486694344 139.73969031798936 22.789 35.672263644485774 139.7396782572524 22.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb2cfb3b-98dc-4cf2-b4d0-7000ac40ed08">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672291459440224 139.73965327066477 22.789 35.67226458597747 139.73962555321043 22.789 35.67226818739034 139.73962031295073 22.789 35.672295060854275 139.73964803040457 22.789 35.672291459440224 139.73965327066477 22.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d517ea3-b676-4bca-93fe-85d73694508b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5d517ea3-b676-4bca-93fe-85d73694508b_0">
											<gml:posList>35.67226230726012 139.7396278093637 22.789 35.67226230726012 139.7396278093637 24.142 35.672270841098666 139.7396366145121 24.142 35.672270841098666 139.7396366145121 22.789 35.67226230726012 139.7396278093637 22.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b2b356b-e173-4f0e-b67e-1fb7f1a940e7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5b2b356b-e173-4f0e-b67e-1fb7f1a940e7_0">
											<gml:posList>35.672269015370674 139.7396418306031 22.789 35.672269015370674 139.7396418306031 23.599 35.6722788395366 139.73965239064282 23.599 35.6722788395366 139.73965239064282 22.789 35.672269015370674 139.7396418306031 22.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-67e286b1-f387-49a1-9c2c-69b2fe87c7eb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-67e286b1-f387-49a1-9c2c-69b2fe87c7eb_0">
											<gml:posList>35.67226230726012 139.7396278093637 22.789 35.67225871485204 139.73963303856564 22.789 35.67225871485204 139.73963303856564 24.142 35.67226230726012 139.7396278093637 24.142 35.67226230726012 139.7396278093637 22.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76575f94-7407-487c-aa91-4d4edb76738b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-76575f94-7407-487c-aa91-4d4edb76738b_0">
											<gml:posList>35.67226492174365 139.73968638599834 22.789 35.6722562059299 139.73969856944174 22.789 35.6722562059299 139.73969856944174 25.204 35.67226492174365 139.73968638599834 25.204 35.67226492174365 139.73968638599834 22.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-febb6147-2b53-4e5e-8e39-83df47cb8fa8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-febb6147-2b53-4e5e-8e39-83df47cb8fa8_0">
											<gml:posList>35.67226315694596 139.73966564269745 23.599 35.672259250739884 139.73966144958428 23.599 35.672259250739884 139.73966144958428 22.789 35.67226315694596 139.73966564269745 22.789 35.67226315694596 139.73966564269745 23.599</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc35c99f-2fcc-4206-8452-5569abaadd0b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cc35c99f-2fcc-4206-8452-5569abaadd0b_0">
											<gml:posList>35.672259250739884 139.73966144958428 22.789 35.672259250739884 139.73966144958428 23.599 35.672263266493225 139.73965583326074 23.599 35.672263266493225 139.73965583326074 22.789 35.672259250739884 139.73966144958428 22.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-daf4dc78-b036-4b3e-addc-c8e668037a1a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-daf4dc78-b036-4b3e-addc-c8e668037a1a_0">
											<gml:posList>35.672262183935906 139.7396546635947 22.789 35.672262183935906 139.7396546635947 23.599 35.67226085781046 139.73965324014335 23.599 35.67226085781046 139.73965324014335 22.789 35.672262183935906 139.7396546635947 22.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-847d4eb6-8da7-4ff0-8be6-169dc3c7c45a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-847d4eb6-8da7-4ff0-8be6-169dc3c7c45a_0">
											<gml:posList>35.67226828541038 139.73971155708728 25.204 35.6722562059299 139.73969856944174 25.204 35.6722562059299 139.73969856944174 22.789 35.67226828541038 139.73971155708728 22.789 35.67226828541038 139.73971155708728 25.204</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37448ddb-3723-4f3b-b987-b30a0ad6cb20">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-37448ddb-3723-4f3b-b987-b30a0ad6cb20_0">
											<gml:posList>35.67226179735229 139.73966754428713 22.789 35.67226179735229 139.73966754428713 23.599 35.67226315694596 139.73966564269745 23.599 35.67226315694596 139.73966564269745 22.789 35.67226179735229 139.73966754428713 22.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5bcab978-60ed-44df-9c49-bb3803455650">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5bcab978-60ed-44df-9c49-bb3803455650_0">
											<gml:posList>35.672262183935906 139.7396546635947 23.599 35.672262183935906 139.7396546635947 22.789 35.672263266493225 139.73965583326074 22.789 35.672263266493225 139.73965583326074 23.599 35.672262183935906 139.7396546635947 23.599</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35e47eba-a766-4caf-9b81-c34cb38ce046">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-35e47eba-a766-4caf-9b81-c34cb38ce046_0">
											<gml:posList>35.67225871485204 139.73963303856564 22.789 35.672267248690204 139.73964184371422 22.789 35.672267248690204 139.73964184371422 24.142 35.67225871485204 139.73963303856564 24.142 35.67225871485204 139.73963303856564 22.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-49d32d53-0e27-4084-af40-cb3a9e59fdc1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-49d32d53-0e27-4084-af40-cb3a9e59fdc1_0">
											<gml:posList>35.67226179735229 139.73966754428713 23.599 35.67226179735229 139.73966754428713 22.789 35.67226530661937 139.7396713070502 22.789 35.67226530661937 139.7396713070502 23.599 35.67226179735229 139.73966754428713 23.599</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-92e8b9ae-b75e-48ee-bc76-bbb31dd493b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-92e8b9ae-b75e-48ee-bc76-bbb31dd493b4_0">
											<gml:posList>35.67225871485204 139.73963303856564 24.142 35.672267248690204 139.73964184371422 24.142 35.672270841098666 139.7396366145121 24.142 35.67226230726012 139.7396278093637 24.142 35.67225871485204 139.73963303856564 24.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e60fdba-15fa-4c14-9fea-3f3d3136dfa1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8e60fdba-15fa-4c14-9fea-3f3d3136dfa1_0">
											<gml:posList>35.67226085781046 139.73965324014335 22.789 35.67226085781046 139.73965324014335 23.599 35.672269015370674 139.7396418306031 23.599 35.672269015370674 139.7396418306031 22.789 35.67226085781046 139.73965324014335 22.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cabbfba4-9a27-4459-9679-749d6eeae3c5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cabbfba4-9a27-4459-9679-749d6eeae3c5_0">
											<gml:posList>35.67226458597747 139.73962555321043 22.789 35.67226458597747 139.73962555321043 24.538 35.67226818739034 139.73962031295073 24.538 35.67226818739034 139.73962031295073 22.789 35.67226458597747 139.73962555321043 22.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f91a8c67-c0ba-4766-9ccb-a4b965367148">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f91a8c67-c0ba-4766-9ccb-a4b965367148_0">
											<gml:posList>35.67227700122543 139.73969937364345 25.204 35.672276613300475 139.7396989432822 25.204 35.67226492174365 139.73968638599834 25.204 35.6722562059299 139.73969856944174 25.204 35.67226828541038 139.73971155708728 25.204 35.67227700122543 139.73969937364345 25.204</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d85fcd17-254d-416c-b348-d396b1f23fd3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d85fcd17-254d-416c-b348-d396b1f23fd3_0">
											<gml:posList>35.67226315694596 139.73966564269745 23.599 35.67226179735229 139.73966754428713 23.599 35.67226530661937 139.7396713070502 23.599 35.6722788395366 139.73965239064282 23.599 35.672269015370674 139.7396418306031 23.599 35.67226085781046 139.73965324014335 23.599 35.672262183935906 139.7396546635947 23.599 35.672263266493225 139.73965583326074 23.599 35.672259250739884 139.73966144958428 23.599 35.67226315694596 139.73966564269745 23.599</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58454cb2-6f9f-4650-8a3d-d2f8cab02e32">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-58454cb2-6f9f-4650-8a3d-d2f8cab02e32_0">
											<gml:posList>35.672267248690204 139.73964184371422 22.789 35.672270841098666 139.7396366145121 22.789 35.672270841098666 139.7396366145121 24.142 35.672267248690204 139.73964184371422 24.142 35.672267248690204 139.73964184371422 22.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ec69777-a9b7-4bca-a45a-820958fc87ef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6ec69777-a9b7-4bca-a45a-820958fc87ef_0">
											<gml:posList>35.672263644485774 139.7396782572524 22.789 35.67227486694344 139.73969031798936 22.789 35.67227486694344 139.73969031798936 25.204 35.672263644485774 139.7396782572524 25.204 35.672263644485774 139.7396782572524 22.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eb74fb6f-5235-49c4-a4fa-d4361cda40d3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eb74fb6f-5235-49c4-a4fa-d4361cda40d3_0">
											<gml:posList>35.672263644485774 139.7396782572524 22.789 35.672263644485774 139.7396782572524 25.204 35.67227531359221 139.7396619500031 25.204 35.67227531359221 139.7396619500031 22.789 35.672263644485774 139.7396782572524 22.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f02bc2f0-2c44-4c61-9db6-4c254af9c451">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f02bc2f0-2c44-4c61-9db6-4c254af9c451_0">
											<gml:posList>35.67226492174365 139.73968638599834 22.789 35.67226492174365 139.73968638599834 25.204 35.672276613300475 139.7396989432822 25.204 35.672276613300475 139.7396989432822 22.789 35.67226492174365 139.73968638599834 22.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7759b97-828e-47a5-a732-980665e0262a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d7759b97-828e-47a5-a732-980665e0262a_0">
											<gml:posList>35.67226530661937 139.7396713070502 22.789 35.6722788395366 139.73965239064282 22.789 35.6722788395366 139.73965239064282 23.599 35.67226530661937 139.7396713070502 23.599 35.67226530661937 139.7396713070502 22.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a789d8c-3e03-4ff1-aaeb-fff3aaa1b50b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7a789d8c-3e03-4ff1-aaeb-fff3aaa1b50b_0">
											<gml:posList>35.67226828541038 139.73971155708728 22.789 35.67227700122543 139.73969937364345 22.789 35.67227700122543 139.73969937364345 25.204 35.67226828541038 139.73971155708728 25.204 35.67226828541038 139.73971155708728 22.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c59e7da-3a03-4136-b328-972a770a3b26">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8c59e7da-3a03-4136-b328-972a770a3b26_0">
											<gml:posList>35.67228653605149 139.73967401073952 25.204 35.67227531359221 139.7396619500031 25.204 35.672263644485774 139.7396782572524 25.204 35.67227486694344 139.73969031798936 25.204 35.67228653605149 139.73967401073952 25.204</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-30890fcc-bdc9-4d97-ac14-0a3d066bec28">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-30890fcc-bdc9-4d97-ac14-0a3d066bec28_0">
											<gml:posList>35.67227700122543 139.73969937364345 22.789 35.672276613300475 139.7396989432822 22.789 35.672276613300475 139.7396989432822 25.204 35.67227700122543 139.73969937364345 25.204 35.67227700122543 139.73969937364345 22.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78921ab4-b5b3-45bb-a537-5edb41cf9170">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78921ab4-b5b3-45bb-a537-5edb41cf9170_0">
											<gml:posList>35.672291459440224 139.73965327066477 22.789 35.672291459440224 139.73965327066477 24.538 35.67226458597747 139.73962555321043 24.538 35.67226458597747 139.73962555321043 22.789 35.672291459440224 139.73965327066477 22.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c037adf6-fa8f-4baa-8618-cdfa8c3b63da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c037adf6-fa8f-4baa-8618-cdfa8c3b63da_0">
											<gml:posList>35.67226818739034 139.73962031295073 24.538 35.67226458597747 139.73962555321043 24.538 35.672291459440224 139.73965327066477 24.538 35.672295060854275 139.73964803040457 24.538 35.67226818739034 139.73962031295073 24.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-230b5bc2-9e8d-434d-b4ae-ac78f22e555e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-230b5bc2-9e8d-434d-b4ae-ac78f22e555e_0">
											<gml:posList>35.67227486694344 139.73969031798936 22.789 35.67228653605149 139.73967401073952 22.789 35.67228653605149 139.73967401073952 25.204 35.67227486694344 139.73969031798936 25.204 35.67227486694344 139.73969031798936 22.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b5245518-5138-4188-a25c-a56acd9be6f1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b5245518-5138-4188-a25c-a56acd9be6f1_0">
											<gml:posList>35.67228653605149 139.73967401073952 22.789 35.67227531359221 139.7396619500031 22.789 35.67227531359221 139.7396619500031 25.204 35.67228653605149 139.73967401073952 25.204 35.67228653605149 139.73967401073952 22.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-98809b33-6d6f-402c-9fd2-08dbd3a89bf5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-98809b33-6d6f-402c-9fd2-08dbd3a89bf5_0">
											<gml:posList>35.67226818739034 139.73962031295073 22.789 35.67226818739034 139.73962031295073 24.538 35.672295060854275 139.73964803040457 24.538 35.672295060854275 139.73964803040457 22.789 35.67226818739034 139.73962031295073 22.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-207a92df-fec9-4aba-a8fa-38696f99bcf2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-207a92df-fec9-4aba-a8fa-38696f99bcf2_0">
											<gml:posList>35.672291459440224 139.73965327066477 22.789 35.672295060854275 139.73964803040457 22.789 35.672295060854275 139.73964803040457 24.538 35.672291459440224 139.73965327066477 24.538 35.672291459440224 139.73965327066477 22.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-923766df-eebc-45bf-9615-74e904a1585f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-923766df-eebc-45bf-9615-74e904a1585f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-923766df-eebc-45bf-9615-74e904a1585f">
											<gml:posList>35.67228296221032 139.73974949579622 8.013 35.67221494190615 139.739676447285 8.013 35.672291025134264 139.73957009085683 8.013 35.67235904550208 139.73964313934684 8.013 35.67228296221032 139.73974949579622 8.013</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fedd31c6-f80e-4db1-aade-c644386c9057">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fedd31c6-f80e-4db1-aade-c644386c9057">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fedd31c6-f80e-4db1-aade-c644386c9057">
											<gml:posList>35.67223632667487 139.73969344498312 25.53 35.67224025092446 139.73969766016864 25.53 35.67226315694596 139.73966564269745 25.53 35.672259250739884 139.73966144958428 25.53 35.672263266493225 139.73965583326074 25.53 35.672244285734976 139.73963543043052 25.53 35.67221494190615 139.739676447285 25.53 35.67223384144817 139.73969673974725 25.53 35.67223632667487 139.73969344498312 25.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-744558d7-1ac8-4a96-996e-434a6011b19e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-744558d7-1ac8-4a96-996e-434a6011b19e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-744558d7-1ac8-4a96-996e-434a6011b19e">
											<gml:posList>35.67224025092446 139.73969766016864 23.067 35.67223632667487 139.73969344498312 23.067 35.67223384144817 139.73969673974725 23.067 35.67226279969173 139.73972783501543 23.067 35.67226250692452 139.7397222679118 23.067 35.67224025092446 139.73969766016864 23.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-aa844f95-2264-4d31-99f3-136870c5b5b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa844f95-2264-4d31-99f3-136870c5b5b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa844f95-2264-4d31-99f3-136870c5b5b4">
											<gml:posList>35.67226967248189 139.7396059396927 23.067 35.67226937969185 139.73960035049606 23.067 35.672244285734976 139.73963543043052 23.067 35.672246712462766 139.73963804561876 23.067 35.67226967248189 139.7396059396927 23.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c5796a22-81f7-4b19-8b6b-6d8816ef996b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c5796a22-81f7-4b19-8b6b-6d8816ef996b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c5796a22-81f7-4b19-8b6b-6d8816ef996b">
											<gml:posList>35.67227711092442 139.73960865948717 23.067 35.67226937969185 139.73960035049606 23.067 35.67226967248189 139.7396059396927 23.067 35.672277557093466 139.73961443629597 23.067 35.67227711092442 139.73960865948717 23.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0bc2546d-9823-4c09-b022-5da9027b0466">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0bc2546d-9823-4c09-b022-5da9027b0466">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0bc2546d-9823-4c09-b022-5da9027b0466">
											<gml:posList>35.672263266493225 139.73965583326074 22.789 35.672259250739884 139.73966144958428 22.789 35.67226315694596 139.73966564269745 22.789 35.67224025092446 139.73969766016864 22.789 35.67226250692452 139.7397222679118 22.789 35.6723181157917 139.73964523078544 22.789 35.67228200435096 139.7396073392305 22.789 35.672277557093466 139.73961443629597 22.789 35.67226967248189 139.7396059396927 22.789 35.672246712462766 139.73963804561876 22.789 35.672263266493225 139.73965583326074 22.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b12ed722-5351-428b-94c7-61a1a7267a0e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b12ed722-5351-428b-94c7-61a1a7267a0e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b12ed722-5351-428b-94c7-61a1a7267a0e">
											<gml:posList>35.67227711092442 139.73960865948717 23.067 35.672277557093466 139.73961443629597 23.067 35.67228200435096 139.7396073392305 23.067 35.6722815311834 139.73960161768562 23.067 35.67227711092442 139.73960865948717 23.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3d9e5da7-d948-48f0-9ef7-3fd950a246b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d9e5da7-d948-48f0-9ef7-3fd950a246b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d9e5da7-d948-48f0-9ef7-3fd950a246b8">
											<gml:posList>35.67227711092442 139.73960865948717 19.334 35.67229840453279 139.7395780136304 19.334 35.67226937969185 139.73960035049606 19.334 35.67227711092442 139.73960865948717 19.334</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-22ba529d-52b8-4d42-829a-35011c091a50">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22ba529d-52b8-4d42-829a-35011c091a50">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22ba529d-52b8-4d42-829a-35011c091a50">
											<gml:posList>35.67229840453279 139.7395780136304 19.334 35.672291025134264 139.73957009085683 19.334 35.67226937969185 139.73960035049606 19.334 35.67229840453279 139.7395780136304 19.334</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c57a54cf-03c3-49df-aa5c-8b185a18ecfc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c57a54cf-03c3-49df-aa5c-8b185a18ecfc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c57a54cf-03c3-49df-aa5c-8b185a18ecfc">
											<gml:posList>35.67226250692452 139.7397222679118 23.067 35.67226279969173 139.73972783501543 23.067 35.67232272149298 139.73964482772828 23.067 35.67226250692452 139.7397222679118 23.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-749d5d4d-24f2-485e-b863-28436d39c3f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-749d5d4d-24f2-485e-b863-28436d39c3f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-749d5d4d-24f2-485e-b863-28436d39c3f4">
											<gml:posList>35.67226250692452 139.7397222679118 23.067 35.67232272149298 139.73964482772828 23.067 35.6723181157917 139.73964523078544 23.067 35.67226250692452 139.7397222679118 23.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d924b736-e5c1-45f5-b19f-1bee709bdf9b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d924b736-e5c1-45f5-b19f-1bee709bdf9b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d924b736-e5c1-45f5-b19f-1bee709bdf9b">
											<gml:posList>35.67232272149298 139.73964482772828 23.067 35.67226279969173 139.73972783501543 23.067 35.67228296221032 139.73974949579622 19.334 35.67232272149298 139.73964482772828 23.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9382ac14-e489-4c88-a15d-d4f74b22a7eb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9382ac14-e489-4c88-a15d-d4f74b22a7eb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9382ac14-e489-4c88-a15d-d4f74b22a7eb">
											<gml:posList>35.67232272149298 139.73964482772828 23.067 35.67229840453279 139.7395780136304 19.334 35.6722815311834 139.73960161768562 23.067 35.67232272149298 139.73964482772828 23.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3e7adf39-bc9a-45a1-86bd-8286cef497e4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e7adf39-bc9a-45a1-86bd-8286cef497e4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e7adf39-bc9a-45a1-86bd-8286cef497e4">
											<gml:posList>35.6722815311834 139.73960161768562 23.067 35.67228200435096 139.7396073392305 23.067 35.6723181157917 139.73964523078544 23.067 35.67232272149298 139.73964482772828 23.067 35.6722815311834 139.73960161768562 23.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-37504c14-0bd9-4fea-93f6-e52f0be9e5c3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37504c14-0bd9-4fea-93f6-e52f0be9e5c3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37504c14-0bd9-4fea-93f6-e52f0be9e5c3">
											<gml:posList>35.67232272149298 139.73964482772828 23.067 35.67228296221032 139.73974949579622 19.334 35.67235904550208 139.73964313934684 19.334 35.67232272149298 139.73964482772828 23.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5100f2e8-afe7-49bd-8f8b-ad546174853d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5100f2e8-afe7-49bd-8f8b-ad546174853d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5100f2e8-afe7-49bd-8f8b-ad546174853d">
											<gml:posList>35.67232272149298 139.73964482772828 23.067 35.67235904550208 139.73964313934684 19.334 35.67229840453279 139.7395780136304 19.334 35.67232272149298 139.73964482772828 23.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-22ef5e6f-b943-44af-9af6-c2d6adddcb12">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22ef5e6f-b943-44af-9af6-c2d6adddcb12">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22ef5e6f-b943-44af-9af6-c2d6adddcb12">
											<gml:posList>35.67229840453279 139.7395780136304 19.334 35.67227711092442 139.73960865948717 19.334 35.67227711092442 139.73960865948717 23.067 35.67229840453279 139.7395780136304 19.334</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d7b4d5a7-88a5-4e7a-a7a4-3bb8ad950a6d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7b4d5a7-88a5-4e7a-a7a4-3bb8ad950a6d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7b4d5a7-88a5-4e7a-a7a4-3bb8ad950a6d">
											<gml:posList>35.67229840453279 139.7395780136304 19.334 35.67227711092442 139.73960865948717 23.067 35.6722815311834 139.73960161768562 23.067 35.67229840453279 139.7395780136304 19.334</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3f1132b7-e9fe-40ce-a712-469ca6e2770a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f1132b7-e9fe-40ce-a712-469ca6e2770a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f1132b7-e9fe-40ce-a712-469ca6e2770a">
											<gml:posList>35.67226937969185 139.73960035049606 19.334 35.67226937969185 139.73960035049606 23.067 35.67227711092442 139.73960865948717 23.067 35.67227711092442 139.73960865948717 19.334 35.67226937969185 139.73960035049606 19.334</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5de19f76-682e-4a66-aa28-f94fa2c741db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5de19f76-682e-4a66-aa28-f94fa2c741db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5de19f76-682e-4a66-aa28-f94fa2c741db">
											<gml:posList>35.67235904550208 139.73964313934684 19.334 35.67235904550208 139.73964313934684 8.013 35.672291025134264 139.73957009085683 8.013 35.672291025134264 139.73957009085683 19.334 35.67229840453279 139.7395780136304 19.334 35.67235904550208 139.73964313934684 19.334</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-52a7940a-7dbe-47a4-8126-e524b4bd2e99">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-52a7940a-7dbe-47a4-8126-e524b4bd2e99">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-52a7940a-7dbe-47a4-8126-e524b4bd2e99">
											<gml:posList>35.67226967248189 139.7396059396927 23.067 35.67226967248189 139.7396059396927 22.789 35.672277557093466 139.73961443629597 22.789 35.672277557093466 139.73961443629597 23.067 35.67226967248189 139.7396059396927 23.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b6ce9654-90f0-4f83-bd7d-0bbb00a60bd3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6ce9654-90f0-4f83-bd7d-0bbb00a60bd3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6ce9654-90f0-4f83-bd7d-0bbb00a60bd3">
											<gml:posList>35.672277557093466 139.73961443629597 23.067 35.672277557093466 139.73961443629597 22.789 35.67228200435096 139.7396073392305 22.789 35.67228200435096 139.7396073392305 23.067 35.672277557093466 139.73961443629597 23.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ee00e206-7500-465b-8a2f-14bf23b340b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee00e206-7500-465b-8a2f-14bf23b340b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee00e206-7500-465b-8a2f-14bf23b340b2">
											<gml:posList>35.672246712462766 139.73963804561876 23.067 35.672246712462766 139.73963804561876 22.789 35.67226967248189 139.7396059396927 22.789 35.67226967248189 139.7396059396927 23.067 35.672246712462766 139.73963804561876 23.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8b7bf874-c40c-4c67-830d-d16e91ed4e9c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b7bf874-c40c-4c67-830d-d16e91ed4e9c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b7bf874-c40c-4c67-830d-d16e91ed4e9c">
											<gml:posList>35.672244285734976 139.73963543043052 23.067 35.67226937969185 139.73960035049606 23.067 35.67226937969185 139.73960035049606 19.334 35.672291025134264 139.73957009085683 19.334 35.672291025134264 139.73957009085683 8.013 35.67221494190615 139.739676447285 8.013 35.67221494190615 139.739676447285 25.53 35.672244285734976 139.73963543043052 25.53 35.672244285734976 139.73963543043052 23.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ee002eca-237a-4e0c-8909-3cf6c49aa37d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee002eca-237a-4e0c-8909-3cf6c49aa37d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee002eca-237a-4e0c-8909-3cf6c49aa37d">
											<gml:posList>35.67228200435096 139.7396073392305 23.067 35.67228200435096 139.7396073392305 22.789 35.6723181157917 139.73964523078544 22.789 35.6723181157917 139.73964523078544 23.067 35.67228200435096 139.7396073392305 23.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ef676bb9-ee2d-4cfe-b159-ea59c81e5ea7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef676bb9-ee2d-4cfe-b159-ea59c81e5ea7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef676bb9-ee2d-4cfe-b159-ea59c81e5ea7">
											<gml:posList>35.672246712462766 139.73963804561876 23.067 35.672244285734976 139.73963543043052 23.067 35.672244285734976 139.73963543043052 25.53 35.672263266493225 139.73965583326074 25.53 35.672263266493225 139.73965583326074 22.789 35.672246712462766 139.73963804561876 22.789 35.672246712462766 139.73963804561876 23.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9790430d-8e08-4fbb-978d-8fc971e5bf27">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9790430d-8e08-4fbb-978d-8fc971e5bf27">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9790430d-8e08-4fbb-978d-8fc971e5bf27">
											<gml:posList>35.672259250739884 139.73966144958428 22.789 35.672263266493225 139.73965583326074 22.789 35.672263266493225 139.73965583326074 25.53 35.672259250739884 139.73966144958428 25.53 35.672259250739884 139.73966144958428 22.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e01dc60f-7e89-43fb-9fd5-ff31ef6cd103">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e01dc60f-7e89-43fb-9fd5-ff31ef6cd103">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e01dc60f-7e89-43fb-9fd5-ff31ef6cd103">
											<gml:posList>35.672259250739884 139.73966144958428 25.53 35.67226315694596 139.73966564269745 25.53 35.67226315694596 139.73966564269745 22.789 35.672259250739884 139.73966144958428 22.789 35.672259250739884 139.73966144958428 25.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-59c33640-bac2-4b4b-ab8d-528f28ba049b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-59c33640-bac2-4b4b-ab8d-528f28ba049b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-59c33640-bac2-4b4b-ab8d-528f28ba049b">
											<gml:posList>35.67226315694596 139.73966564269745 22.789 35.67226315694596 139.73966564269745 25.53 35.67224025092446 139.73969766016864 25.53 35.67224025092446 139.73969766016864 23.067 35.67224025092446 139.73969766016864 22.789 35.67226315694596 139.73966564269745 22.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f1e66acf-beb8-4df9-b693-2d89a2713d9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f1e66acf-beb8-4df9-b693-2d89a2713d9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f1e66acf-beb8-4df9-b693-2d89a2713d9a">
											<gml:posList>35.6723181157917 139.73964523078544 23.067 35.6723181157917 139.73964523078544 22.789 35.67226250692452 139.7397222679118 22.789 35.67226250692452 139.7397222679118 23.067 35.6723181157917 139.73964523078544 23.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dd1ddaad-3e64-45f0-8403-1c0b932dbbcd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd1ddaad-3e64-45f0-8403-1c0b932dbbcd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd1ddaad-3e64-45f0-8403-1c0b932dbbcd">
											<gml:posList>35.67223632667487 139.73969344498312 23.067 35.67223632667487 139.73969344498312 25.53 35.67223384144817 139.73969673974725 25.53 35.67223384144817 139.73969673974725 23.067 35.67223632667487 139.73969344498312 23.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-385a540e-8010-4b0a-bde2-8cfb10e73190">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-385a540e-8010-4b0a-bde2-8cfb10e73190">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-385a540e-8010-4b0a-bde2-8cfb10e73190">
											<gml:posList>35.67224025092446 139.73969766016864 23.067 35.67224025092446 139.73969766016864 25.53 35.67223632667487 139.73969344498312 25.53 35.67223632667487 139.73969344498312 23.067 35.67224025092446 139.73969766016864 23.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-773fd82a-3939-43bb-aa86-025d41698002">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-773fd82a-3939-43bb-aa86-025d41698002">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-773fd82a-3939-43bb-aa86-025d41698002">
											<gml:posList>35.67228296221032 139.73974949579622 8.013 35.67235904550208 139.73964313934684 8.013 35.67235904550208 139.73964313934684 19.334 35.67228296221032 139.73974949579622 19.334 35.67228296221032 139.73974949579622 8.013</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9d8ca59e-d519-4d47-a0e1-c2871b001539">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d8ca59e-d519-4d47-a0e1-c2871b001539">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d8ca59e-d519-4d47-a0e1-c2871b001539">
											<gml:posList>35.67226250692452 139.7397222679118 23.067 35.67226250692452 139.7397222679118 22.789 35.67224025092446 139.73969766016864 22.789 35.67224025092446 139.73969766016864 23.067 35.67226250692452 139.7397222679118 23.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5b48e52d-1a87-4632-9430-481a0241fdc5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b48e52d-1a87-4632-9430-481a0241fdc5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b48e52d-1a87-4632-9430-481a0241fdc5">
											<gml:posList>35.67223384144817 139.73969673974725 23.067 35.67223384144817 139.73969673974725 25.53 35.67221494190615 139.739676447285 25.53 35.67221494190615 139.739676447285 8.013 35.67228296221032 139.73974949579622 8.013 35.67228296221032 139.73974949579622 19.334 35.67226279969173 139.73972783501543 23.067 35.67223384144817 139.73969673974725 23.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6375</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">128.4738</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1002</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1242</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.17</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">12</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>