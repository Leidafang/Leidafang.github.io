<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_9e095a54-0041-49eb-bbf8-5ea6d7aa5aca">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">9.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66911481004772 139.73858882584057 0 35.669198162882275 139.738672677681 0 35.66922238131222 139.73863641788185 0 35.669227974164386 139.73864193432672 0 35.66925597426473 139.73860047836797 0 35.66916558771862 139.73851287918868 0 35.66911481004772 139.73858882584057 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66911481004772 139.73858882584057 16.417 35.66916558771862 139.73851287918868 16.417 35.66925597426473 139.73860047836797 16.417 35.669227974164386 139.73864193432672 16.417 35.66922238131222 139.73863641788185 16.417 35.669198162882275 139.738672677681 16.417 35.66911481004772 139.73858882584057 16.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66911481004772 139.73858882584057 16.417 35.669198162882275 139.738672677681 16.417 35.669198162882275 139.738672677681 25.98 35.66911481004772 139.73858882584057 25.98 35.66911481004772 139.73858882584057 16.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669198162882275 139.738672677681 16.417 35.66922238131222 139.73863641788185 16.417 35.66922238131222 139.73863641788185 25.98 35.669198162882275 139.738672677681 25.98 35.669198162882275 139.738672677681 16.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66922238131222 139.73863641788185 16.417 35.669227974164386 139.73864193432672 16.417 35.669227974164386 139.73864193432672 25.98 35.66922238131222 139.73863641788185 25.98 35.66922238131222 139.73863641788185 16.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669227974164386 139.73864193432672 16.417 35.66925597426473 139.73860047836797 16.417 35.66925597426473 139.73860047836797 25.98 35.669227974164386 139.73864193432672 25.98 35.669227974164386 139.73864193432672 16.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66925597426473 139.73860047836797 16.417 35.66916558771862 139.73851287918868 16.417 35.66916558771862 139.73851287918868 25.98 35.66925597426473 139.73860047836797 25.98 35.66925597426473 139.73860047836797 16.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66916558771862 139.73851287918868 16.417 35.66911481004772 139.73858882584057 16.417 35.66911481004772 139.73858882584057 25.98 35.66916558771862 139.73851287918868 25.98 35.66916558771862 139.73851287918868 16.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66911481004772 139.73858882584057 25.98 35.669198162882275 139.738672677681 25.98 35.66922238131222 139.73863641788185 25.98 35.669227974164386 139.73864193432672 25.98 35.66925597426473 139.73860047836797 25.98 35.66916558771862 139.73851287918868 25.98 35.66911481004772 139.73858882584057 25.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-17b903ec-91ea-4eac-889d-732887c320f1"/>
							<gml:surfaceMember xlink:href="#poly-751487aa-2b65-41fe-8c27-c457bdcc2247"/>
							<gml:surfaceMember xlink:href="#poly-42ee5899-9291-427b-b4ae-22c1e63a8a67"/>
							<gml:surfaceMember xlink:href="#poly-fbce7d9e-1b87-4094-9969-e3192a5f4195"/>
							<gml:surfaceMember xlink:href="#poly-f9bf00ff-60cd-491a-8b9b-2377c413f81d"/>
							<gml:surfaceMember xlink:href="#poly-402f16dd-1b26-4018-a930-845676cd673c"/>
							<gml:surfaceMember xlink:href="#poly-3beaeb9d-63f1-46c5-a050-d17c61330f97"/>
							<gml:surfaceMember xlink:href="#poly-655ef716-0c27-4afc-9688-fd533fa68dc3"/>
							<gml:surfaceMember xlink:href="#poly-4a256513-3298-4a03-8b16-253760122ba5"/>
							<gml:surfaceMember xlink:href="#poly-f850c508-2e0e-4542-8bc2-ed33ba3e0eaa"/>
							<gml:surfaceMember xlink:href="#poly-87b8b19e-1c82-4cac-bcc9-5243f60e0b6c"/>
							<gml:surfaceMember xlink:href="#poly-337ab578-71d0-4ce4-982d-7277b590893f"/>
							<gml:surfaceMember xlink:href="#poly-6d19e320-fc0f-48e6-9674-50f556ad2301"/>
							<gml:surfaceMember xlink:href="#poly-9b397985-4510-4a9f-a06f-fb3ab604e9fa"/>
							<gml:surfaceMember xlink:href="#poly-d4d0710b-47a6-4918-b113-a22110d5bd1d"/>
							<gml:surfaceMember xlink:href="#poly-b7bcd2c4-4e86-4ee5-99ef-4b1e2d493bd7"/>
							<gml:surfaceMember xlink:href="#poly-a2d8a015-6533-430c-af34-5e2cd827b608"/>
							<gml:surfaceMember xlink:href="#poly-856ef4a7-67c5-43f6-8abe-14c149d41b89"/>
							<gml:surfaceMember xlink:href="#poly-faa5dfb0-dd3a-4979-badf-e06f0d2ab8ee"/>
							<gml:surfaceMember xlink:href="#poly-cb9a557a-a21e-4cdf-8d66-ee81b914fda4"/>
							<gml:surfaceMember xlink:href="#poly-1d128a98-5866-44b1-86d0-6be9c4a92dcf"/>
							<gml:surfaceMember xlink:href="#poly-599d66f5-9293-438c-b59a-d6ace8ed4302"/>
							<gml:surfaceMember xlink:href="#poly-38a10b4d-55e8-4490-b197-b772e9f6944f"/>
							<gml:surfaceMember xlink:href="#poly-6e9625d6-ae0b-4e8d-a6d9-9a5ba296cac6"/>
							<gml:surfaceMember xlink:href="#poly-04c67e1d-91c1-472a-8bde-efd744f410f0"/>
							<gml:surfaceMember xlink:href="#poly-12219bff-22de-4616-a08c-b9d74afde9b4"/>
							<gml:surfaceMember xlink:href="#poly-6c71c073-5b9b-4cba-a43c-d922c48820db"/>
							<gml:surfaceMember xlink:href="#poly-f103d85b-dfd5-477d-9819-68774028703b"/>
							<gml:surfaceMember xlink:href="#poly-6fb7d4c1-cc77-4aa0-b081-fc344dd78828"/>
							<gml:surfaceMember xlink:href="#poly-f6311e19-32b0-4818-97ba-20e572131cd7"/>
							<gml:surfaceMember xlink:href="#poly-ed3f474f-7dc2-4916-a008-db14a83178aa"/>
							<gml:surfaceMember xlink:href="#poly-20ba879e-9c02-4813-9951-8c38b5a01fd2"/>
							<gml:surfaceMember xlink:href="#poly-598d8dfb-ea40-442b-9471-48a00493f896"/>
							<gml:surfaceMember xlink:href="#poly-682f28e4-ba81-48fe-8c85-6bb26526ad27"/>
							<gml:surfaceMember xlink:href="#poly-d3acb061-9a11-40de-9bc8-23fe0bc6e0fc"/>
							<gml:surfaceMember xlink:href="#poly-1f964a05-76dc-4c5c-933a-f0ac3a1c90ad"/>
							<gml:surfaceMember xlink:href="#poly-3da101b3-160c-4c0d-97cb-c1d4b859c6ff"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_9e095a54-0041-49eb-bbf8-5ea6d7aa5aca_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8ad17441-e52b-4d45-8e8c-325e0ea42c44">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66920306764326 139.73862846540993 26.24 35.66921323416318 139.73863869313516 26.24 35.669194138454166 139.7386672035686 26.24 35.66918397193664 139.7386569758422 26.24 35.66920306764326 139.73862846540993 26.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f32ab1f-ad27-4590-bf64-f78e1d8a59b0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669193571258226 139.73866805478767 26.501 35.669183395727046 139.73865782707185 26.501 35.66918397193664 139.7386569758422 26.501 35.669194138454166 139.7386672035686 26.501 35.669193571258226 139.73866805478767 26.501</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c932d2a1-ae1f-4d95-a7a9-916efe950fee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c932d2a1-ae1f-4d95-a7a9-916efe950fee_0">
											<gml:posList>35.66920306764326 139.73862846540993 27.765 35.66921323416318 139.73863869313516 27.765 35.66921323416318 139.73863869313516 26.24 35.66920306764326 139.73862846540993 26.24 35.66920306764326 139.73862846540993 27.765</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fdd5a30f-8823-4899-989f-afefe671c36d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fdd5a30f-8823-4899-989f-afefe671c36d_0">
											<gml:posList>35.66918397193664 139.7386569758422 26.501 35.669183395727046 139.73865782707185 26.501 35.669183395727046 139.73865782707185 27.765 35.66920306764326 139.73862846540993 27.765 35.66920306764326 139.73862846540993 26.24 35.66918397193664 139.7386569758422 26.24 35.66918397193664 139.7386569758422 26.501</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-17e839f7-9f5a-4eec-abe1-672de77488b5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-17e839f7-9f5a-4eec-abe1-672de77488b5_0">
											<gml:posList>35.66920306764326 139.73862846540993 27.765 35.669183395727046 139.73865782707185 27.765 35.669193571258226 139.73866805478767 27.765 35.66921323416318 139.73863869313516 27.765 35.66920306764326 139.73862846540993 27.765</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c272f8e-edd1-4cea-8855-050da4acb820">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8c272f8e-edd1-4cea-8855-050da4acb820_0">
											<gml:posList>35.66921323416318 139.73863869313516 26.24 35.66921323416318 139.73863869313516 27.765 35.669193571258226 139.73866805478767 27.765 35.669193571258226 139.73866805478767 26.501 35.669194138454166 139.7386672035686 26.501 35.669194138454166 139.7386672035686 26.24 35.66921323416318 139.73863869313516 26.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-be24618c-1012-4ba1-99e6-ee6eee247d2d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-be24618c-1012-4ba1-99e6-ee6eee247d2d_0">
											<gml:posList>35.669194138454166 139.7386672035686 26.24 35.669194138454166 139.7386672035686 26.501 35.66918397193664 139.7386569758422 26.501 35.66918397193664 139.7386569758422 26.24 35.669194138454166 139.7386672035686 26.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-860608ff-d014-43f9-9d48-fa87c8a07379">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-860608ff-d014-43f9-9d48-fa87c8a07379_0">
											<gml:posList>35.669183395727046 139.73865782707185 26.501 35.669193571258226 139.73866805478767 26.501 35.669193571258226 139.73866805478767 27.765 35.669183395727046 139.73865782707185 27.765 35.669183395727046 139.73865782707185 26.501</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-17b903ec-91ea-4eac-889d-732887c320f1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17b903ec-91ea-4eac-889d-732887c320f1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17b903ec-91ea-4eac-889d-732887c320f1">
											<gml:posList>35.66916558771864 139.73851287918868 16.417 35.66925597426471 139.73860047836797 16.417 35.66922797416439 139.7386419343267 16.417 35.66922238131222 139.73863641788182 16.417 35.669198162882246 139.73867267768097 16.417 35.6691148100477 139.73858882584057 16.417 35.66916558771864 139.73851287918868 16.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-751487aa-2b65-41fe-8c27-c457bdcc2247">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-751487aa-2b65-41fe-8c27-c457bdcc2247">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-751487aa-2b65-41fe-8c27-c457bdcc2247">
											<gml:posList>35.66916558771864 139.73851287918868 24.126 35.669138758475775 139.73855311867746 24.126 35.6691482844453 139.73856260705404 26.087 35.66916558771864 139.73851287918868 24.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-42ee5899-9291-427b-b4ae-22c1e63a8a67">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-42ee5899-9291-427b-b4ae-22c1e63a8a67">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-42ee5899-9291-427b-b4ae-22c1e63a8a67">
											<gml:posList>35.6691482844453 139.73856260705404 26.087 35.6691769085965 139.73852385666385 26.087 35.66916558771864 139.73851287918868 24.126 35.6691482844453 139.73856260705404 26.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fbce7d9e-1b87-4094-9969-e3192a5f4195">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fbce7d9e-1b87-4094-9969-e3192a5f4195">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fbce7d9e-1b87-4094-9969-e3192a5f4195">
											<gml:posList>35.6691482844453 139.73856260705404 26.087 35.66915018620198 139.7385624280688 26.087 35.66917705454681 139.73852605466388 26.087 35.6691769085965 139.73852385666385 26.087 35.6691482844453 139.73856260705404 26.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f9bf00ff-60cd-491a-8b9b-2377c413f81d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9bf00ff-60cd-491a-8b9b-2377c413f81d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9bf00ff-60cd-491a-8b9b-2377c413f81d">
											<gml:posList>35.6691769085965 139.73852385666385 26.087 35.66917705454681 139.73852605466388 26.087 35.66925409960132 139.73860072359716 26.087 35.66925597426471 139.73860047836797 26.087 35.6691769085965 139.73852385666385 26.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-402f16dd-1b26-4018-a930-845676cd673c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-402f16dd-1b26-4018-a930-845676cd673c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-402f16dd-1b26-4018-a930-845676cd673c">
											<gml:posList>35.6691482844453 139.73856260705404 26.501 35.669138758475775 139.73855311867746 24.126 35.6691148100477 139.73858882584057 24.126 35.66912431804783 139.7385983915624 26.501 35.6691482844453 139.73856260705404 26.501</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3beaeb9d-63f1-46c5-a050-d17c61330f97">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3beaeb9d-63f1-46c5-a050-d17c61330f97">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3beaeb9d-63f1-46c5-a050-d17c61330f97">
											<gml:posList>35.66912431804783 139.7385983915624 26.501 35.66912558886126 139.7385982354157 26.501 35.669148411863226 139.73856416440205 26.501 35.6691482844453 139.73856260705404 26.501 35.66912431804783 139.7385983915624 26.501</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-655ef716-0c27-4afc-9688-fd533fa68dc3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-655ef716-0c27-4afc-9688-fd533fa68dc3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-655ef716-0c27-4afc-9688-fd533fa68dc3">
											<gml:posList>35.66922778310415 139.73863968114784 25.929 35.66925409960132 139.73860072359716 25.929 35.66917705454681 139.73852605466388 25.929 35.66915018620198 139.7385624280688 25.929 35.669223200579474 139.73863516870495 25.929 35.66922778310415 139.73863968114784 25.929</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4a256513-3298-4a03-8b16-253760122ba5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a256513-3298-4a03-8b16-253760122ba5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a256513-3298-4a03-8b16-253760122ba5">
											<gml:posList>35.66922238131222 139.73863641788182 26.087 35.669223200579474 139.73863516870495 26.087 35.66915018620198 139.7385624280688 26.087 35.6691482844453 139.73856260705404 26.087 35.66922238131222 139.73863641788182 26.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f850c508-2e0e-4542-8bc2-ed33ba3e0eaa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f850c508-2e0e-4542-8bc2-ed33ba3e0eaa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f850c508-2e0e-4542-8bc2-ed33ba3e0eaa">
											<gml:posList>35.6691482844453 139.73856260705404 26.501 35.669148411863226 139.73856416440205 26.501 35.66922111049007 139.738636562982 26.501 35.66922238131222 139.73863641788182 26.501 35.6691482844453 139.73856260705404 26.501</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-87b8b19e-1c82-4cac-bcc9-5243f60e0b6c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-87b8b19e-1c82-4cac-bcc9-5243f60e0b6c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-87b8b19e-1c82-4cac-bcc9-5243f60e0b6c">
											<gml:posList>35.669157977315756 139.73861238032902 28.475 35.66918699722791 139.73864128681527 28.475 35.669201492148474 139.7386194315636 28.475 35.66917248124487 139.73859052506938 28.475 35.669157977315756 139.73861238032902 28.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-337ab578-71d0-4ce4-982d-7277b590893f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-337ab578-71d0-4ce4-982d-7277b590893f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-337ab578-71d0-4ce4-982d-7277b590893f">
											<gml:posList>35.66917248124487 139.73859052506938 26.24 35.669201492148474 139.7386194315636 26.24 35.66922111049007 139.738636562982 26.24 35.669148411863226 139.73856416440205 26.24 35.66912558886126 139.7385982354157 26.24 35.669198035457036 139.73867110928572 26.24 35.66918699722791 139.73864128681527 26.24 35.669157977315756 139.73861238032902 26.24 35.66917248124487 139.73859052506938 26.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6d19e320-fc0f-48e6-9674-50f556ad2301">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d19e320-fc0f-48e6-9674-50f556ad2301">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d19e320-fc0f-48e6-9674-50f556ad2301">
											<gml:posList>35.66925597426471 139.73860047836797 26.087 35.66925409960132 139.73860072359716 26.087 35.66922778310415 139.73863968114784 26.087 35.66922797416439 139.7386419343267 26.087 35.66925597426471 139.73860047836797 26.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9b397985-4510-4a9f-a06f-fb3ab604e9fa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b397985-4510-4a9f-a06f-fb3ab604e9fa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b397985-4510-4a9f-a06f-fb3ab604e9fa">
											<gml:posList>35.669198162882246 139.73867267768097 26.501 35.669198035457036 139.73867110928572 26.501 35.66912558886126 139.7385982354157 26.501 35.66912431804783 139.7385983915624 26.501 35.669198162882246 139.73867267768097 26.501</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d4d0710b-47a6-4918-b113-a22110d5bd1d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4d0710b-47a6-4918-b113-a22110d5bd1d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4d0710b-47a6-4918-b113-a22110d5bd1d">
											<gml:posList>35.66922238131222 139.73863641788182 26.087 35.66922797416439 139.7386419343267 26.087 35.66922778310415 139.73863968114784 26.087 35.669223200579474 139.73863516870495 26.087 35.66922238131222 139.73863641788182 26.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b7bcd2c4-4e86-4ee5-99ef-4b1e2d493bd7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b7bcd2c4-4e86-4ee5-99ef-4b1e2d493bd7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b7bcd2c4-4e86-4ee5-99ef-4b1e2d493bd7">
											<gml:posList>35.66918699722791 139.73864128681527 26.24 35.669198035457036 139.73867110928572 26.24 35.66922111049007 139.738636562982 26.24 35.669201492148474 139.7386194315636 26.24 35.66918699722791 139.73864128681527 26.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a2d8a015-6533-430c-af34-5e2cd827b608">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2d8a015-6533-430c-af34-5e2cd827b608">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2d8a015-6533-430c-af34-5e2cd827b608">
											<gml:posList>35.66922238131222 139.73863641788182 26.501 35.66922111049007 139.738636562982 26.501 35.669198035457036 139.73867110928572 26.501 35.669198162882246 139.73867267768097 26.501 35.66922238131222 139.73863641788182 26.501</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-856ef4a7-67c5-43f6-8abe-14c149d41b89">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-856ef4a7-67c5-43f6-8abe-14c149d41b89">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-856ef4a7-67c5-43f6-8abe-14c149d41b89">
											<gml:posList>35.669223200579474 139.73863516870495 26.087 35.669223200579474 139.73863516870495 25.929 35.66915018620198 139.7385624280688 25.929 35.66915018620198 139.7385624280688 26.087 35.669223200579474 139.73863516870495 26.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-faa5dfb0-dd3a-4979-badf-e06f0d2ab8ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-faa5dfb0-dd3a-4979-badf-e06f0d2ab8ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-faa5dfb0-dd3a-4979-badf-e06f0d2ab8ee">
											<gml:posList>35.669148411863226 139.73856416440205 26.501 35.669148411863226 139.73856416440205 26.24 35.66922111049007 139.738636562982 26.24 35.66922111049007 139.738636562982 26.501 35.669148411863226 139.73856416440205 26.501</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cb9a557a-a21e-4cdf-8d66-ee81b914fda4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb9a557a-a21e-4cdf-8d66-ee81b914fda4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb9a557a-a21e-4cdf-8d66-ee81b914fda4">
											<gml:posList>35.669198035457036 139.73867110928572 26.501 35.669198035457036 139.73867110928572 26.24 35.66912558886126 139.7385982354157 26.24 35.66912558886126 139.7385982354157 26.501 35.669198035457036 139.73867110928572 26.501</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1d128a98-5866-44b1-86d0-6be9c4a92dcf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d128a98-5866-44b1-86d0-6be9c4a92dcf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d128a98-5866-44b1-86d0-6be9c4a92dcf">
											<gml:posList>35.66915018620198 139.7385624280688 26.087 35.66915018620198 139.7385624280688 25.929 35.66917705454681 139.73852605466388 25.929 35.66917705454681 139.73852605466388 26.087 35.66915018620198 139.7385624280688 26.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-599d66f5-9293-438c-b59a-d6ace8ed4302">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-599d66f5-9293-438c-b59a-d6ace8ed4302">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-599d66f5-9293-438c-b59a-d6ace8ed4302">
											<gml:posList>35.66916558771864 139.73851287918868 16.417 35.6691148100477 139.73858882584057 16.417 35.6691148100477 139.73858882584057 24.126 35.669138758475775 139.73855311867746 24.126 35.66916558771864 139.73851287918868 24.126 35.66916558771864 139.73851287918868 16.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-38a10b4d-55e8-4490-b197-b772e9f6944f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38a10b4d-55e8-4490-b197-b772e9f6944f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38a10b4d-55e8-4490-b197-b772e9f6944f">
											<gml:posList>35.66916558771864 139.73851287918868 24.126 35.6691769085965 139.73852385666385 26.087 35.66925597426471 139.73860047836797 26.087 35.66925597426471 139.73860047836797 16.417 35.66916558771864 139.73851287918868 16.417 35.66916558771864 139.73851287918868 24.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6e9625d6-ae0b-4e8d-a6d9-9a5ba296cac6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e9625d6-ae0b-4e8d-a6d9-9a5ba296cac6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e9625d6-ae0b-4e8d-a6d9-9a5ba296cac6">
											<gml:posList>35.66917705454681 139.73852605466388 26.087 35.66917705454681 139.73852605466388 25.929 35.66925409960132 139.73860072359716 25.929 35.66925409960132 139.73860072359716 26.087 35.66917705454681 139.73852605466388 26.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-04c67e1d-91c1-472a-8bde-efd744f410f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04c67e1d-91c1-472a-8bde-efd744f410f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04c67e1d-91c1-472a-8bde-efd744f410f0">
											<gml:posList>35.66912558886126 139.7385982354157 26.501 35.66912558886126 139.7385982354157 26.24 35.669148411863226 139.73856416440205 26.24 35.669148411863226 139.73856416440205 26.501 35.66912558886126 139.7385982354157 26.501</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-12219bff-22de-4616-a08c-b9d74afde9b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-12219bff-22de-4616-a08c-b9d74afde9b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-12219bff-22de-4616-a08c-b9d74afde9b4">
											<gml:posList>35.6691482844453 139.73856260705404 26.501 35.66922238131222 139.73863641788182 26.501 35.66922238131222 139.73863641788182 26.087 35.6691482844453 139.73856260705404 26.087 35.669138758475775 139.73855311867746 24.126 35.6691482844453 139.73856260705404 26.501</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6c71c073-5b9b-4cba-a43c-d922c48820db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c71c073-5b9b-4cba-a43c-d922c48820db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c71c073-5b9b-4cba-a43c-d922c48820db">
											<gml:posList>35.669157977315756 139.73861238032902 26.24 35.669157977315756 139.73861238032902 28.475 35.66917248124487 139.73859052506938 28.475 35.66917248124487 139.73859052506938 26.24 35.669157977315756 139.73861238032902 26.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f103d85b-dfd5-477d-9819-68774028703b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f103d85b-dfd5-477d-9819-68774028703b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f103d85b-dfd5-477d-9819-68774028703b">
											<gml:posList>35.66917248124487 139.73859052506938 26.24 35.66917248124487 139.73859052506938 28.475 35.669201492148474 139.7386194315636 28.475 35.669201492148474 139.7386194315636 26.24 35.66917248124487 139.73859052506938 26.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6fb7d4c1-cc77-4aa0-b081-fc344dd78828">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6fb7d4c1-cc77-4aa0-b081-fc344dd78828">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6fb7d4c1-cc77-4aa0-b081-fc344dd78828">
											<gml:posList>35.66925409960132 139.73860072359716 26.087 35.66925409960132 139.73860072359716 25.929 35.66922778310415 139.73863968114784 25.929 35.66922778310415 139.73863968114784 26.087 35.66925409960132 139.73860072359716 26.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f6311e19-32b0-4818-97ba-20e572131cd7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f6311e19-32b0-4818-97ba-20e572131cd7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f6311e19-32b0-4818-97ba-20e572131cd7">
											<gml:posList>35.66922797416439 139.7386419343267 16.417 35.66925597426471 139.73860047836797 16.417 35.66925597426471 139.73860047836797 26.087 35.66922797416439 139.7386419343267 26.087 35.66922797416439 139.7386419343267 16.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ed3f474f-7dc2-4916-a008-db14a83178aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed3f474f-7dc2-4916-a008-db14a83178aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed3f474f-7dc2-4916-a008-db14a83178aa">
											<gml:posList>35.66918699722791 139.73864128681527 26.24 35.66918699722791 139.73864128681527 28.475 35.669157977315756 139.73861238032902 28.475 35.669157977315756 139.73861238032902 26.24 35.66918699722791 139.73864128681527 26.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-20ba879e-9c02-4813-9951-8c38b5a01fd2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20ba879e-9c02-4813-9951-8c38b5a01fd2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20ba879e-9c02-4813-9951-8c38b5a01fd2">
											<gml:posList>35.669201492148474 139.7386194315636 26.24 35.669201492148474 139.7386194315636 28.475 35.66918699722791 139.73864128681527 28.475 35.66918699722791 139.73864128681527 26.24 35.669201492148474 139.7386194315636 26.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-598d8dfb-ea40-442b-9471-48a00493f896">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-598d8dfb-ea40-442b-9471-48a00493f896">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-598d8dfb-ea40-442b-9471-48a00493f896">
											<gml:posList>35.6691148100477 139.73858882584057 16.417 35.669198162882246 139.73867267768097 16.417 35.669198162882246 139.73867267768097 26.501 35.66912431804783 139.7385983915624 26.501 35.6691148100477 139.73858882584057 24.126 35.6691148100477 139.73858882584057 16.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-682f28e4-ba81-48fe-8c85-6bb26526ad27">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-682f28e4-ba81-48fe-8c85-6bb26526ad27">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-682f28e4-ba81-48fe-8c85-6bb26526ad27">
											<gml:posList>35.66922778310415 139.73863968114784 26.087 35.66922778310415 139.73863968114784 25.929 35.669223200579474 139.73863516870495 25.929 35.669223200579474 139.73863516870495 26.087 35.66922778310415 139.73863968114784 26.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d3acb061-9a11-40de-9bc8-23fe0bc6e0fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3acb061-9a11-40de-9bc8-23fe0bc6e0fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3acb061-9a11-40de-9bc8-23fe0bc6e0fc">
											<gml:posList>35.66922238131222 139.73863641788182 16.417 35.66922797416439 139.7386419343267 16.417 35.66922797416439 139.7386419343267 26.087 35.66922238131222 139.73863641788182 26.087 35.66922238131222 139.73863641788182 16.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1f964a05-76dc-4c5c-933a-f0ac3a1c90ad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f964a05-76dc-4c5c-933a-f0ac3a1c90ad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f964a05-76dc-4c5c-933a-f0ac3a1c90ad">
											<gml:posList>35.66922111049007 139.738636562982 26.501 35.66922111049007 139.738636562982 26.24 35.669198035457036 139.73867110928572 26.24 35.669198035457036 139.73867110928572 26.501 35.66922111049007 139.738636562982 26.501</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3da101b3-160c-4c0d-97cb-c1d4b859c6ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3da101b3-160c-4c0d-97cb-c1d4b859c6ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3da101b3-160c-4c0d-97cb-c1d4b859c6ff">
											<gml:posList>35.669198162882246 139.73867267768097 26.501 35.669198162882246 139.73867267768097 16.417 35.66922238131222 139.73863641788182 16.417 35.66922238131222 139.73863641788182 26.087 35.66922238131222 139.73863641788182 26.501 35.669198162882246 139.73867267768097 26.501</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6105</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">60.89715</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>