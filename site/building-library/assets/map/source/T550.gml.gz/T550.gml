<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_9fe490ac-5005-4b2d-9db1-96eef4a23689">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:measuredHeight uom="m">10.4</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67017000527514 139.73751012966136 0 35.67017840816423 139.73753541548862 0 35.67025580518524 139.73749655070398 0 35.670247402288055 139.73747126485642 0 35.67017000527514 139.73751012966136 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67017000527514 139.73751012966136 16.899 35.670247402288055 139.73747126485642 16.899 35.67025580518524 139.73749655070398 16.899 35.67017840816423 139.73753541548862 16.899 35.67017000527514 139.73751012966136 16.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67017000527514 139.73751012966136 16.899 35.67017840816423 139.73753541548862 16.899 35.67017840816423 139.73753541548862 27.34 35.67017000527514 139.73751012966136 27.34 35.67017000527514 139.73751012966136 16.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67017840816423 139.73753541548862 16.899 35.67025580518524 139.73749655070398 16.899 35.67025580518524 139.73749655070398 27.34 35.67017840816423 139.73753541548862 27.34 35.67017840816423 139.73753541548862 16.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67025580518524 139.73749655070398 16.899 35.670247402288055 139.73747126485642 16.899 35.670247402288055 139.73747126485642 27.34 35.67025580518524 139.73749655070398 27.34 35.67025580518524 139.73749655070398 16.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670247402288055 139.73747126485642 16.899 35.67017000527514 139.73751012966136 16.899 35.67017000527514 139.73751012966136 27.34 35.670247402288055 139.73747126485642 27.34 35.670247402288055 139.73747126485642 16.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67017000527514 139.73751012966136 27.34 35.67017840816423 139.73753541548862 27.34 35.67025580518524 139.73749655070398 27.34 35.670247402288055 139.73747126485642 27.34 35.67017000527514 139.73751012966136 27.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-52541d7a-a2bc-4d70-88a7-632e7ffa49db"/>
							<gml:surfaceMember xlink:href="#poly-6bc6da8a-2e7c-4037-bafe-c701eb10cd94"/>
							<gml:surfaceMember xlink:href="#poly-a08a8ea2-9dfc-463a-9a53-b63a0420957e"/>
							<gml:surfaceMember xlink:href="#poly-be8bdb00-6d3f-4d99-8586-495534744cf5"/>
							<gml:surfaceMember xlink:href="#poly-e5a48f20-bd22-44a4-a6ea-976a18e31401"/>
							<gml:surfaceMember xlink:href="#poly-f71b2ef1-5918-4c2d-a692-9a9f5daa061b"/>
							<gml:surfaceMember xlink:href="#poly-f51a9117-8fd4-43e6-81ca-edf2673cbc80"/>
							<gml:surfaceMember xlink:href="#poly-4d2dcc62-0d31-4470-bc2f-51901e9f4c13"/>
							<gml:surfaceMember xlink:href="#poly-19455d22-0dbe-47f3-8784-1ee3b3bd6399"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-52541d7a-a2bc-4d70-88a7-632e7ffa49db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-52541d7a-a2bc-4d70-88a7-632e7ffa49db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-52541d7a-a2bc-4d70-88a7-632e7ffa49db">
											<gml:posList>35.670170005275146 139.73751012966136 16.899 35.67024740228805 139.73747126485642 16.899 35.670255805185214 139.73749655070398 16.899 35.670178408164226 139.73753541548862 16.899 35.670170005275146 139.73751012966136 16.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6bc6da8a-2e7c-4037-bafe-c701eb10cd94">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6bc6da8a-2e7c-4037-bafe-c701eb10cd94">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6bc6da8a-2e7c-4037-bafe-c701eb10cd94">
											<gml:posList>35.67018340606555 139.7375181553026 27.555 35.67025160373729 139.73748390777953 27.555 35.67024740228805 139.73747126485642 26.997 35.670179177587485 139.73750552346698 26.997 35.67018340606555 139.7375181553026 27.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a08a8ea2-9dfc-463a-9a53-b63a0420957e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a08a8ea2-9dfc-463a-9a53-b63a0420957e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a08a8ea2-9dfc-463a-9a53-b63a0420957e">
											<gml:posList>35.670187625528555 139.73753078715032 26.997 35.670255805185214 139.73749655070398 26.997 35.67025160373729 139.73748390777953 27.555 35.67018340606555 139.7375181553026 27.555 35.670187625528555 139.73753078715032 26.997</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-be8bdb00-6d3f-4d99-8586-495534744cf5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-be8bdb00-6d3f-4d99-8586-495534744cf5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-be8bdb00-6d3f-4d99-8586-495534744cf5">
											<gml:posList>35.670179177587485 139.73750552346698 26.997 35.670170005275146 139.73751012966136 24.596 35.670178408164226 139.73753541548862 24.596 35.670187625528555 139.73753078715032 26.997 35.670179177587485 139.73750552346698 26.997</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e5a48f20-bd22-44a4-a6ea-976a18e31401">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5a48f20-bd22-44a4-a6ea-976a18e31401">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5a48f20-bd22-44a4-a6ea-976a18e31401">
											<gml:posList>35.670170005275146 139.73751012966136 16.899 35.670178408164226 139.73753541548862 16.899 35.670178408164226 139.73753541548862 24.596 35.670170005275146 139.73751012966136 24.596 35.670170005275146 139.73751012966136 16.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f71b2ef1-5918-4c2d-a692-9a9f5daa061b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f71b2ef1-5918-4c2d-a692-9a9f5daa061b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f71b2ef1-5918-4c2d-a692-9a9f5daa061b">
											<gml:posList>35.670187625528555 139.73753078715032 26.997 35.67018340606555 139.7375181553026 27.555 35.670179177587485 139.73750552346698 26.997 35.670187625528555 139.73753078715032 26.997</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f51a9117-8fd4-43e6-81ca-edf2673cbc80">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f51a9117-8fd4-43e6-81ca-edf2673cbc80">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f51a9117-8fd4-43e6-81ca-edf2673cbc80">
											<gml:posList>35.67024740228805 139.73747126485642 26.997 35.67024740228805 139.73747126485642 16.899 35.670170005275146 139.73751012966136 16.899 35.670170005275146 139.73751012966136 24.596 35.670179177587485 139.73750552346698 26.997 35.67024740228805 139.73747126485642 26.997</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4d2dcc62-0d31-4470-bc2f-51901e9f4c13">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d2dcc62-0d31-4470-bc2f-51901e9f4c13">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d2dcc62-0d31-4470-bc2f-51901e9f4c13">
											<gml:posList>35.670255805185214 139.73749655070398 16.899 35.670255805185214 139.73749655070398 26.997 35.670187625528555 139.73753078715032 26.997 35.670178408164226 139.73753541548862 24.596 35.670178408164226 139.73753541548862 16.899 35.670255805185214 139.73749655070398 16.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-19455d22-0dbe-47f3-8784-1ee3b3bd6399">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-19455d22-0dbe-47f3-8784-1ee3b3bd6399">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-19455d22-0dbe-47f3-8784-1ee3b3bd6399">
											<gml:posList>35.670255805185214 139.73749655070398 16.899 35.67024740228805 139.73747126485642 16.899 35.67024740228805 139.73747126485642 26.997 35.67025160373729 139.73748390777953 27.555 35.670255805185214 139.73749655070398 26.997 35.670255805185214 139.73749655070398 16.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-11683</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">6</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>