<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_a06c1a73-7dff-4415-ad55-d842b6e7655f">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">422</bldg:usage>
			<bldg:measuredHeight uom="m">9.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.668122085738204 139.74263149043315 0 35.668085203037 139.74260955072612 0 35.66807557657261 139.74263375223123 0 35.668043383173156 139.7426146791741 0 35.66800136907702 139.74272098857304 0 35.66792309492534 139.74267457369822 0 35.66789565501452 139.74274364170606 0 35.66804598136776 139.7428332753495 0 35.66805497782486 139.74281028964185 0 35.66806444647281 139.74281591238204 0 35.66808972695204 139.7427519278273 0 35.66807737266215 139.7427446514615 0 35.668122085738204 139.74263149043315 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668122085738204 139.74263149043315 27.19 35.66807737266215 139.7427446514615 27.19 35.66808972695204 139.7427519278273 27.19 35.66806444647281 139.74281591238204 27.19 35.66805497782486 139.74281028964185 27.19 35.66804598136776 139.7428332753495 27.19 35.66789565501452 139.74274364170606 27.19 35.66792309492534 139.74267457369822 27.19 35.66800136907702 139.74272098857304 27.19 35.668043383173156 139.7426146791741 27.19 35.66807557657261 139.74263375223123 27.19 35.668085203037 139.74260955072612 27.19 35.668122085738204 139.74263149043315 27.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668122085738204 139.74263149043315 27.19 35.668085203037 139.74260955072612 27.19 35.668085203037 139.74260955072612 36.7 35.668122085738204 139.74263149043315 36.7 35.668122085738204 139.74263149043315 27.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668085203037 139.74260955072612 27.19 35.66807557657261 139.74263375223123 27.19 35.66807557657261 139.74263375223123 36.7 35.668085203037 139.74260955072612 36.7 35.668085203037 139.74260955072612 27.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66807557657261 139.74263375223123 27.19 35.668043383173156 139.7426146791741 27.19 35.668043383173156 139.7426146791741 36.7 35.66807557657261 139.74263375223123 36.7 35.66807557657261 139.74263375223123 27.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668043383173156 139.7426146791741 27.19 35.66800136907702 139.74272098857304 27.19 35.66800136907702 139.74272098857304 36.7 35.668043383173156 139.7426146791741 36.7 35.668043383173156 139.7426146791741 27.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66800136907702 139.74272098857304 27.19 35.66792309492534 139.74267457369822 27.19 35.66792309492534 139.74267457369822 36.7 35.66800136907702 139.74272098857304 36.7 35.66800136907702 139.74272098857304 27.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66792309492534 139.74267457369822 27.19 35.66789565501452 139.74274364170606 27.19 35.66789565501452 139.74274364170606 36.7 35.66792309492534 139.74267457369822 36.7 35.66792309492534 139.74267457369822 27.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66789565501452 139.74274364170606 27.19 35.66804598136776 139.7428332753495 27.19 35.66804598136776 139.7428332753495 36.7 35.66789565501452 139.74274364170606 36.7 35.66789565501452 139.74274364170606 27.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66804598136776 139.7428332753495 27.19 35.66805497782486 139.74281028964185 27.19 35.66805497782486 139.74281028964185 36.7 35.66804598136776 139.7428332753495 36.7 35.66804598136776 139.7428332753495 27.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66805497782486 139.74281028964185 27.19 35.66806444647281 139.74281591238204 27.19 35.66806444647281 139.74281591238204 36.7 35.66805497782486 139.74281028964185 36.7 35.66805497782486 139.74281028964185 27.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66806444647281 139.74281591238204 27.19 35.66808972695204 139.7427519278273 27.19 35.66808972695204 139.7427519278273 36.7 35.66806444647281 139.74281591238204 36.7 35.66806444647281 139.74281591238204 27.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66808972695204 139.7427519278273 27.19 35.66807737266215 139.7427446514615 27.19 35.66807737266215 139.7427446514615 36.7 35.66808972695204 139.7427519278273 36.7 35.66808972695204 139.7427519278273 27.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66807737266215 139.7427446514615 27.19 35.668122085738204 139.74263149043315 27.19 35.668122085738204 139.74263149043315 36.7 35.66807737266215 139.7427446514615 36.7 35.66807737266215 139.7427446514615 27.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668122085738204 139.74263149043315 36.7 35.668085203037 139.74260955072612 36.7 35.66807557657261 139.74263375223123 36.7 35.668043383173156 139.7426146791741 36.7 35.66800136907702 139.74272098857304 36.7 35.66792309492534 139.74267457369822 36.7 35.66789565501452 139.74274364170606 36.7 35.66804598136776 139.7428332753495 36.7 35.66805497782486 139.74281028964185 36.7 35.66806444647281 139.74281591238204 36.7 35.66808972695204 139.7427519278273 36.7 35.66807737266215 139.7427446514615 36.7 35.668122085738204 139.74263149043315 36.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-193e0176-6c5c-44ca-a9b1-52ab0b08b738"/>
							<gml:surfaceMember xlink:href="#poly-522094da-64b8-4abb-bb87-9c997f36fb7e"/>
							<gml:surfaceMember xlink:href="#poly-9e9e3067-2f0c-4bb0-a606-c8dece36a13d"/>
							<gml:surfaceMember xlink:href="#poly-20015c57-32e4-4ae7-b16b-a535f59affe6"/>
							<gml:surfaceMember xlink:href="#poly-b1ee7d1b-f1e3-4342-a4ab-ba4285c80057"/>
							<gml:surfaceMember xlink:href="#poly-1033c00e-dd47-4070-bf1f-37e03ca7c8c1"/>
							<gml:surfaceMember xlink:href="#poly-486ff259-6731-440f-8894-ab31700cf134"/>
							<gml:surfaceMember xlink:href="#poly-f39628a4-0016-441e-aea9-d3fb93795fef"/>
							<gml:surfaceMember xlink:href="#poly-bdb6918a-5662-437c-af20-35a4bddae17f"/>
							<gml:surfaceMember xlink:href="#poly-a6673295-d2c4-42fc-a648-895412e38821"/>
							<gml:surfaceMember xlink:href="#poly-98cd7bc4-264d-4533-85e2-0f66705d0d78"/>
							<gml:surfaceMember xlink:href="#poly-de79e765-e5cf-4f50-a39a-dd8cb4c2f755"/>
							<gml:surfaceMember xlink:href="#poly-195f1b59-910c-4fe9-a739-469a6e2e6963"/>
							<gml:surfaceMember xlink:href="#poly-555400df-c2ec-4382-8841-e64f8945fca4"/>
							<gml:surfaceMember xlink:href="#poly-7dd15307-edd1-40e3-8cb8-66827ee8fc12"/>
							<gml:surfaceMember xlink:href="#poly-6743b814-450e-478d-9244-509bf9a45b25"/>
							<gml:surfaceMember xlink:href="#poly-9924510a-d901-44c9-8ca2-d003410d7434"/>
							<gml:surfaceMember xlink:href="#poly-a1419500-2315-41bd-8d4a-b5909cbcab0a"/>
							<gml:surfaceMember xlink:href="#poly-1d370927-f94f-4a91-a906-c9a0abfd1459"/>
							<gml:surfaceMember xlink:href="#poly-ef35287f-f1ac-4f3c-aae8-975fca0bd081"/>
							<gml:surfaceMember xlink:href="#poly-618ab26f-dd8a-400b-8a5a-b750dc10314b"/>
							<gml:surfaceMember xlink:href="#poly-ef2de5eb-ec7f-4af9-ad04-4339044efd35"/>
							<gml:surfaceMember xlink:href="#poly-75a9cf99-63e0-4cad-9cb2-e8f2aaaf84da"/>
							<gml:surfaceMember xlink:href="#poly-034bb4d3-5fae-4e58-94b2-6901355e1387"/>
							<gml:surfaceMember xlink:href="#poly-1bb552e8-9ac1-4c41-a376-308cc97afa4f"/>
							<gml:surfaceMember xlink:href="#poly-2283a557-d60c-477f-9f50-dcf2f4497030"/>
							<gml:surfaceMember xlink:href="#poly-9a470d2a-0b47-495b-b4e3-ca4dd7d3e881"/>
							<gml:surfaceMember xlink:href="#poly-eda3ba2d-8499-4156-abe1-1c981de16d34"/>
							<gml:surfaceMember xlink:href="#poly-e3bcc631-2010-4c27-a9d2-d449b782db33"/>
							<gml:surfaceMember xlink:href="#poly-b732e0d0-2d41-4070-9412-050a33a77c74"/>
							<gml:surfaceMember xlink:href="#poly-dcf7f78a-ee3b-4ed0-885c-89c08ab17b9d"/>
							<gml:surfaceMember xlink:href="#poly-d1024ba6-546c-4be2-a662-2281636b5b94"/>
							<gml:surfaceMember xlink:href="#poly-0cc2954b-a417-4cf7-bd8b-4c2106745136"/>
							<gml:surfaceMember xlink:href="#poly-67c1dee9-8eaa-4151-a483-cddb0c8991ed"/>
							<gml:surfaceMember xlink:href="#poly-c2088383-e048-4e77-971b-fa1f9a0091c2"/>
							<gml:surfaceMember xlink:href="#poly-41d4c33a-a6eb-49c0-94ba-988b60e69097"/>
							<gml:surfaceMember xlink:href="#poly-3f17e6a0-f231-4d2d-99b6-efe274b6cdaa"/>
							<gml:surfaceMember xlink:href="#poly-66f164fc-5d4a-40cb-a705-c8fc378bdaa5"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_a06c1a73-7dff-4415-ad55-d842b6e7655f_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a0ca0ea-8ab8-4959-8bfd-047f6b348cac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5a0ca0ea-8ab8-4959-8bfd-047f6b348cac_0">
											<gml:posList>35.66804663904498 139.7426890367463 35.89 35.668034447314334 139.74268217995592 38.585 35.66804663904498 139.7426890367463 38.585 35.66804663904498 139.7426890367463 35.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f1a3de3a-c66c-43fe-8ac8-cb9adac8a4b7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f1a3de3a-c66c-43fe-8ac8-cb9adac8a4b7_0">
											<gml:posList>35.66804663904498 139.7426890367463 35.89 35.668034447314334 139.74268217995592 35.89 35.668034447314334 139.74268217995592 38.585 35.66804663904498 139.7426890367463 35.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1cd7f0f3-9e52-4f45-82ad-8600feb197b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1cd7f0f3-9e52-4f45-82ad-8600feb197b1_0">
											<gml:posList>35.66807473991008 139.74263589609035 38.585 35.66804425078766 139.74261772687134 37.585 35.66807473991008 139.74263589609035 37.585 35.66807473991008 139.74263589609035 38.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8c4aa07-3a70-4a1c-8be5-d81436fe946c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8c4aa07-3a70-4a1c-8be5-d81436fe946c_0">
											<gml:posList>35.66807473991008 139.74263589609035 38.585 35.66804425078766 139.74261772687134 38.585 35.66804425078766 139.74261772687134 37.585 35.66807473991008 139.74263589609035 38.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18f2497f-0e21-4bdf-89d7-7f3bd234ccef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-18f2497f-0e21-4bdf-89d7-7f3bd234ccef_0">
											<gml:posList>35.6680447026806 139.7426193280211 36.9 35.668074335032834 139.74263687963716 35.89 35.6680447026806 139.7426193280211 35.89 35.6680447026806 139.7426193280211 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53e2fbb1-17fa-43f4-afd2-d38901e2270a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-53e2fbb1-17fa-43f4-afd2-d38901e2270a_0">
											<gml:posList>35.6680447026806 139.7426193280211 36.9 35.668074335032834 139.74263687963716 36.9 35.668074335032834 139.74263687963716 35.89 35.6680447026806 139.7426193280211 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e529495-2250-47a8-84ee-63ca0a52259b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1e529495-2250-47a8-84ee-63ca0a52259b_0">
											<gml:posList>35.66804341028921 139.74261477855686 36.9 35.668112396231614 139.74265576933968 38.585 35.668112396231614 139.74265576933968 36.9 35.66804341028921 139.74261477855686 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d2928ffd-243b-477f-9335-37d639edcce5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d2928ffd-243b-477f-9335-37d639edcce5_0">
											<gml:posList>35.66804341028921 139.74261477855686 36.9 35.66804341028921 139.74261477855686 38.585 35.668112396231614 139.74265576933968 38.585 35.66804341028921 139.74261477855686 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4afc128e-d68e-4cc4-a0cd-953306f99311">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4afc128e-d68e-4cc4-a0cd-953306f99311_0">
											<gml:posList>35.668020559031675 139.74267270719926 36.9 35.66804341028921 139.74261477855686 38.585 35.66804341028921 139.74261477855686 36.9 35.668020559031675 139.74267270719926 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ece90dc4-7a66-4e3e-bc6e-4050073374cc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ece90dc4-7a66-4e3e-bc6e-4050073374cc_0">
											<gml:posList>35.668020559031675 139.74267270719926 36.9 35.668020559031675 139.74267270719926 38.585 35.66804341028921 139.74261477855686 38.585 35.668020559031675 139.74267270719926 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-070188bb-b7ad-49af-823d-0fe6193a6e97">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-070188bb-b7ad-49af-823d-0fe6193a6e97_0">
											<gml:posList>35.66804425078766 139.74261772687134 38.585 35.668022991922896 139.74267162194687 37.585 35.66804425078766 139.74261772687134 37.585 35.66804425078766 139.74261772687134 38.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-154ed55b-df2a-4ac1-a93f-67f1947c66ec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-154ed55b-df2a-4ac1-a93f-67f1947c66ec_0">
											<gml:posList>35.66804425078766 139.74261772687134 38.585 35.668022991922896 139.74267162194687 38.585 35.668022991922896 139.74267162194687 37.585 35.66804425078766 139.74261772687134 38.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4be49e4d-aae5-419e-ae60-5d10f5915dd4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4be49e4d-aae5-419e-ae60-5d10f5915dd4_0">
											<gml:posList>35.66807473991008 139.74263589609035 38.585 35.66810999033184 139.74265678828755 37.585 35.66810999033184 139.74265678828755 38.585 35.66807473991008 139.74263589609035 38.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70ac4d64-d98a-4fd9-afe8-ce20efe4e571">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-70ac4d64-d98a-4fd9-afe8-ce20efe4e571_0">
											<gml:posList>35.66807473991008 139.74263589609035 38.585 35.66807473991008 139.74263589609035 37.585 35.66810999033184 139.74265678828755 37.585 35.66807473991008 139.74263589609035 38.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7a474d7-72e9-42c6-8d0c-0672af080275">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d7a474d7-72e9-42c6-8d0c-0672af080275_0">
											<gml:posList>35.6680447026806 139.7426193280211 35.89 35.668023074892666 139.74267407405063 36.9 35.6680447026806 139.7426193280211 36.9 35.6680447026806 139.7426193280211 35.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4991bf1d-a3f7-4c2b-8b30-2dbf730794a2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4991bf1d-a3f7-4c2b-8b30-2dbf730794a2_0">
											<gml:posList>35.6680447026806 139.7426193280211 35.89 35.668023074892666 139.74267407405063 35.89 35.668023074892666 139.74267407405063 36.9 35.6680447026806 139.7426193280211 35.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e7c0852a-10fd-4fc0-8f8e-07e2ffa23e98">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e7c0852a-10fd-4fc0-8f8e-07e2ffa23e98_0">
											<gml:posList>35.668108737806456 139.74265729781752 35.89 35.668074335032834 139.74263687963716 36.9 35.668108737806456 139.74265729781752 36.9 35.668108737806456 139.74265729781752 35.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c78113c4-f149-4628-b65c-f7b4a39e157d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c78113c4-f149-4628-b65c-f7b4a39e157d_0">
											<gml:posList>35.668108737806456 139.74265729781752 35.89 35.668074335032834 139.74263687963716 35.89 35.668074335032834 139.74263687963716 36.9 35.668108737806456 139.74265729781752 35.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f690449-2eb1-43e0-aaac-23b53d0e0a86">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f690449-2eb1-43e0-aaac-23b53d0e0a86_0">
											<gml:posList>35.668020559031675 139.74267270719926 38.585 35.668090597432624 139.74271086906916 38.585 35.668022991922896 139.74267162194687 38.585 35.668020559031675 139.74267270719926 38.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e9b1527-62f0-48f9-9e52-c61509175f39">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7e9b1527-62f0-48f9-9e52-c61509175f39_0">
											<gml:posList>35.668020559031675 139.74267270719926 38.585 35.668022991922896 139.74267162194687 38.585 35.66804341028921 139.74261477855686 38.585 35.668020559031675 139.74267270719926 38.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e59845d6-b518-4400-8e85-379718f827cf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e59845d6-b518-4400-8e85-379718f827cf_0">
											<gml:posList>35.668112396231614 139.74265576933968 38.585 35.66810999033184 139.74265678828755 38.585 35.668090597432624 139.74271086906916 38.585 35.668112396231614 139.74265576933968 38.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca9b528b-b7e1-44b4-a3a1-1d7f1ffb08c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ca9b528b-b7e1-44b4-a3a1-1d7f1ffb08c3_0">
											<gml:posList>35.66804341028921 139.74261477855686 38.585 35.66807473991008 139.74263589609035 38.585 35.668112396231614 139.74265576933968 38.585 35.66804341028921 139.74261477855686 38.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a9f10335-6a91-4fef-960c-a8582483beb2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a9f10335-6a91-4fef-960c-a8582483beb2_0">
											<gml:posList>35.668090597432624 139.74271086906916 38.585 35.66808973895057 139.74270797600204 38.585 35.668022991922896 139.74267162194687 38.585 35.668090597432624 139.74271086906916 38.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2361f776-4d35-405b-b8b6-d1acb415f350">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2361f776-4d35-405b-b8b6-d1acb415f350_0">
											<gml:posList>35.668022991922896 139.74267162194687 38.585 35.66804425078766 139.74261772687134 38.585 35.66804341028921 139.74261477855686 38.585 35.668022991922896 139.74267162194687 38.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8972ee3a-e600-4d70-b47b-2123ff6183ed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8972ee3a-e600-4d70-b47b-2123ff6183ed_0">
											<gml:posList>35.668090597432624 139.74271086906916 38.585 35.66810999033184 139.74265678828755 38.585 35.66808973895057 139.74270797600204 38.585 35.668090597432624 139.74271086906916 38.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa0a4d2f-9aaf-448d-ac33-9c4a62f14dd6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fa0a4d2f-9aaf-448d-ac33-9c4a62f14dd6_0">
											<gml:posList>35.668112396231614 139.74265576933968 38.585 35.66807473991008 139.74263589609035 38.585 35.66810999033184 139.74265678828755 38.585 35.668112396231614 139.74265576933968 38.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-91971bb6-9e5b-4377-bf23-f81e6d04dc4a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-91971bb6-9e5b-4377-bf23-f81e6d04dc4a_0">
											<gml:posList>35.66804425078766 139.74261772687134 38.585 35.66807473991008 139.74263589609035 38.585 35.66804341028921 139.74261477855686 38.585 35.66804425078766 139.74261772687134 38.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dda6e3a3-cf20-4eab-a272-084b12754521">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dda6e3a3-cf20-4eab-a272-084b12754521_0">
											<gml:posList>35.66807473991008 139.74263589609035 37.585 35.668022991922896 139.74267162194687 37.585 35.66808973895057 139.74270797600204 37.585 35.66807473991008 139.74263589609035 37.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2cc0694f-9d05-4eb2-b4dc-d3b4465ef563">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2cc0694f-9d05-4eb2-b4dc-d3b4465ef563_0">
											<gml:posList>35.66808973895057 139.74270797600204 37.585 35.66810999033184 139.74265678828755 37.585 35.66807473991008 139.74263589609035 37.585 35.66808973895057 139.74270797600204 37.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3732cc4d-1c74-40a9-894d-a041520fbd88">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3732cc4d-1c74-40a9-894d-a041520fbd88_0">
											<gml:posList>35.66804425078766 139.74261772687134 37.585 35.668022991922896 139.74267162194687 37.585 35.66807473991008 139.74263589609035 37.585 35.66804425078766 139.74261772687134 37.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58f8fcba-6403-4c99-8654-2d563ed0f7c8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-58f8fcba-6403-4c99-8654-2d563ed0f7c8_0">
											<gml:posList>35.66808973895057 139.74270797600204 38.585 35.66810999033184 139.74265678828755 37.585 35.66808973895057 139.74270797600204 37.585 35.66808973895057 139.74270797600204 38.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-22763305-2cfc-4e10-a6fd-ed93483ba2d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-22763305-2cfc-4e10-a6fd-ed93483ba2d4_0">
											<gml:posList>35.66808973895057 139.74270797600204 38.585 35.66810999033184 139.74265678828755 38.585 35.66810999033184 139.74265678828755 37.585 35.66808973895057 139.74270797600204 38.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc7e790d-5de8-48e2-b150-583967477877">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc7e790d-5de8-48e2-b150-583967477877_0">
											<gml:posList>35.668090597432624 139.74271086906916 36.9 35.668112396231614 139.74265576933968 38.585 35.668090597432624 139.74271086906916 38.585 35.668090597432624 139.74271086906916 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4e45733-77ed-4ed0-9f82-ea741def200c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a4e45733-77ed-4ed0-9f82-ea741def200c_0">
											<gml:posList>35.668090597432624 139.74271086906916 36.9 35.668112396231614 139.74265576933968 36.9 35.668112396231614 139.74265576933968 38.585 35.668090597432624 139.74271086906916 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8be5052-5993-4282-a9ff-01852bf51d21">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8be5052-5993-4282-a9ff-01852bf51d21_0">
											<gml:posList>35.66808810862156 139.74270951323086 36.9 35.668108737806456 139.74265729781752 35.89 35.668108737806456 139.74265729781752 36.9 35.66808810862156 139.74270951323086 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f5ffed70-b4b8-4f9a-b480-0057c561b35a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f5ffed70-b4b8-4f9a-b480-0057c561b35a_0">
											<gml:posList>35.66808810862156 139.74270951323086 36.9 35.66808810862156 139.74270951323086 35.89 35.668108737806456 139.74265729781752 35.89 35.66808810862156 139.74270951323086 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16c9da22-6158-4f35-acd7-d48a8f1571a1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16c9da22-6158-4f35-acd7-d48a8f1571a1_0">
											<gml:posList>35.66802978757481 139.7426946339936 38.585 35.668034447314334 139.74268217995592 35.89 35.66802978757481 139.7426946339936 35.89 35.66802978757481 139.7426946339936 38.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a409b38-b255-48da-800a-6ac9f02013a4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9a409b38-b255-48da-800a-6ac9f02013a4_0">
											<gml:posList>35.66802978757481 139.7426946339936 38.585 35.668034447314334 139.74268217995592 38.585 35.668034447314334 139.74268217995592 35.89 35.66802978757481 139.7426946339936 38.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a10ff6f-1cd0-46cf-ae5d-b4b65cef3bab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0a10ff6f-1cd0-46cf-ae5d-b4b65cef3bab_0">
											<gml:posList>35.66808973895057 139.74270797600204 38.585 35.668022991922896 139.74267162194687 37.585 35.668022991922896 139.74267162194687 38.585 35.66808973895057 139.74270797600204 38.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77b6819a-efe9-478f-88a4-bc67746e93cb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77b6819a-efe9-478f-88a4-bc67746e93cb_0">
											<gml:posList>35.66808973895057 139.74270797600204 38.585 35.66808973895057 139.74270797600204 37.585 35.668022991922896 139.74267162194687 37.585 35.66808973895057 139.74270797600204 38.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3491251-6f9a-4bbc-b52f-5299f787ff39">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3491251-6f9a-4bbc-b52f-5299f787ff39_0">
											<gml:posList>35.668090597432624 139.74271086906916 36.9 35.668090597432624 139.74271086906916 38.585 35.66808810862156 139.74270951323086 36.9 35.668090597432624 139.74271086906916 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab2101b6-18a6-4402-9a4d-d2f7581ebbfa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ab2101b6-18a6-4402-9a4d-d2f7581ebbfa_0">
											<gml:posList>35.66808810862156 139.74270951323086 35.89 35.66808810862156 139.74270951323086 36.9 35.668023074892666 139.74267407405063 36.9 35.66808810862156 139.74270951323086 35.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-051d102a-efe6-48e5-bc4d-57dd6c91d55c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-051d102a-efe6-48e5-bc4d-57dd6c91d55c_0">
											<gml:posList>35.668023074892666 139.74267407405063 35.89 35.66808810862156 139.74270951323086 35.89 35.668023074892666 139.74267407405063 36.9 35.668023074892666 139.74267407405063 35.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-49824e3d-2561-4c2f-a5bd-d6ce83841704">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-49824e3d-2561-4c2f-a5bd-d6ce83841704_0">
											<gml:posList>35.668023074892666 139.74267407405063 36.9 35.668090597432624 139.74271086906916 38.585 35.668020559031675 139.74267270719926 38.585 35.668023074892666 139.74267407405063 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43f97b77-e325-4237-8225-a6bc24e01aaa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-43f97b77-e325-4237-8225-a6bc24e01aaa_0">
											<gml:posList>35.668023074892666 139.74267407405063 36.9 35.668020559031675 139.74267270719926 38.585 35.668020559031675 139.74267270719926 36.9 35.668023074892666 139.74267407405063 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-69a10f80-e277-4771-9ebf-724af1d8a5ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-69a10f80-e277-4771-9ebf-724af1d8a5ce_0">
											<gml:posList>35.66808810862156 139.74270951323086 36.9 35.668090597432624 139.74271086906916 38.585 35.668023074892666 139.74267407405063 36.9 35.66808810862156 139.74270951323086 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7f0e1a9-a281-4105-a66e-57b264671686">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d7f0e1a9-a281-4105-a66e-57b264671686_0">
											<gml:posList>35.66802978757481 139.7426946339936 38.585 35.66804663904498 139.7426890367463 38.585 35.668034447314334 139.74268217995592 38.585 35.66802978757481 139.7426946339936 38.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ca28d31-191b-495a-a5da-44b551252696">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0ca28d31-191b-495a-a5da-44b551252696_0">
											<gml:posList>35.66802978757481 139.7426946339936 38.585 35.66804197930476 139.74270149078552 38.585 35.66804663904498 139.7426890367463 38.585 35.66802978757481 139.7426946339936 38.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3510170c-dedd-433c-88e1-bca9894ecfc3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3510170c-dedd-433c-88e1-bca9894ecfc3_0">
											<gml:posList>35.66804197930476 139.74270149078552 35.89 35.66804663904498 139.7426890367463 38.585 35.66804197930476 139.74270149078552 38.585 35.66804197930476 139.74270149078552 35.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c98023c-df48-447b-a5d1-4fceb0b0c741">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4c98023c-df48-447b-a5d1-4fceb0b0c741_0">
											<gml:posList>35.66804197930476 139.74270149078552 35.89 35.66804663904498 139.7426890367463 35.89 35.66804663904498 139.7426890367463 38.585 35.66804197930476 139.74270149078552 35.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f5a3b79-568a-43bc-8790-bed7538d2e7a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9f5a3b79-568a-43bc-8790-bed7538d2e7a_0">
											<gml:posList>35.66804197930476 139.74270149078552 35.89 35.66802978757481 139.7426946339936 38.585 35.66802978757481 139.7426946339936 35.89 35.66804197930476 139.74270149078552 35.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d963f0e3-3e6e-4cfe-b5e3-b70b0bf164c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d963f0e3-3e6e-4cfe-b5e3-b70b0bf164c7_0">
											<gml:posList>35.66804197930476 139.74270149078552 35.89 35.66804197930476 139.74270149078552 38.585 35.66802978757481 139.7426946339936 38.585 35.66804197930476 139.74270149078552 35.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d78c35f-baeb-41e5-8c96-2acbcb4576ab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d78c35f-baeb-41e5-8c96-2acbcb4576ab_0">
											<gml:posList>35.667994430909296 139.74277211698217 35.89 35.667983997491405 139.7427660976882 37.727 35.667994430909296 139.74277211698217 37.727 35.667994430909296 139.74277211698217 35.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26661aea-2007-49ed-bb1c-0fa7d43f094f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-26661aea-2007-49ed-bb1c-0fa7d43f094f_0">
											<gml:posList>35.667994430909296 139.74277211698217 35.89 35.667983997491405 139.7427660976882 35.89 35.667983997491405 139.7427660976882 37.727 35.667994430909296 139.74277211698217 35.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2729df98-0feb-4ee4-8868-63e27b5f5c57">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2729df98-0feb-4ee4-8868-63e27b5f5c57_0">
											<gml:posList>35.667983997491405 139.7427660976882 35.89 35.66797782614494 139.74278215439307 37.727 35.667983997491405 139.7427660976882 37.727 35.667983997491405 139.7427660976882 35.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-06ed3df8-8694-4661-a567-ea565231f0ef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-06ed3df8-8694-4661-a567-ea565231f0ef_0">
											<gml:posList>35.667983997491405 139.7427660976882 35.89 35.66797782614494 139.74278215439307 35.89 35.66797782614494 139.74278215439307 37.727 35.667983997491405 139.7427660976882 35.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2aaee8fa-7ea0-4375-a78a-93bd7fcdc6f2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2aaee8fa-7ea0-4375-a78a-93bd7fcdc6f2_0">
											<gml:posList>35.667988259562065 139.74278817368864 37.727 35.667983997491405 139.7427660976882 37.727 35.66797782614494 139.74278215439307 37.727 35.667988259562065 139.74278817368864 37.727</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf697778-f665-44c6-a5fe-86051e4c51c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cf697778-f665-44c6-a5fe-86051e4c51c7_0">
											<gml:posList>35.667988259562065 139.74278817368864 37.727 35.667994430909296 139.74277211698217 37.727 35.667983997491405 139.7427660976882 37.727 35.667988259562065 139.74278817368864 37.727</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d361c0bf-c2e7-4833-819d-1585436314b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d361c0bf-c2e7-4833-819d-1585436314b8_0">
											<gml:posList>35.667988259562065 139.74278817368864 35.89 35.667994430909296 139.74277211698217 37.727 35.667988259562065 139.74278817368864 37.727 35.667988259562065 139.74278817368864 35.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a01d45e-b71b-414a-812e-3291708fd309">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6a01d45e-b71b-414a-812e-3291708fd309_0">
											<gml:posList>35.667988259562065 139.74278817368864 35.89 35.667994430909296 139.74277211698217 35.89 35.667994430909296 139.74277211698217 37.727 35.667988259562065 139.74278817368864 35.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7eb078dd-4f45-411c-94a9-9fbec764d208">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7eb078dd-4f45-411c-94a9-9fbec764d208_0">
											<gml:posList>35.66797782614494 139.74278215439307 35.89 35.667988259562065 139.74278817368864 37.727 35.66797782614494 139.74278215439307 37.727 35.66797782614494 139.74278215439307 35.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9e8a036-500b-4d5d-a563-dd61d32e5150">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e9e8a036-500b-4d5d-a563-dd61d32e5150_0">
											<gml:posList>35.66797782614494 139.74278215439307 35.89 35.667988259562065 139.74278817368864 35.89 35.667988259562065 139.74278817368864 37.727 35.66797782614494 139.74278215439307 35.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-68861c78-ba07-40bd-a41c-4d226542e09a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667983997491405 139.7427660976882 35.89 35.667988259562065 139.74278817368864 35.89 35.66797782614494 139.74278215439307 35.89 35.667983997491405 139.7427660976882 35.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94fe397f-d9d4-4ba3-8e8f-4f2c086dddb5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667983997491405 139.7427660976882 35.89 35.667994430909296 139.74277211698217 35.89 35.667988259562065 139.74278817368864 35.89 35.667983997491405 139.7427660976882 35.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f874c9b5-a8a6-4f94-ae23-2c487191706b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66804663904498 139.7426890367463 35.89 35.66802978757481 139.7426946339936 35.89 35.668034447314334 139.74268217995592 35.89 35.66804663904498 139.7426890367463 35.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a29127e4-d70a-4f83-b711-2c764650a53b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66804663904498 139.7426890367463 35.89 35.66804197930476 139.74270149078552 35.89 35.66802978757481 139.7426946339936 35.89 35.66804663904498 139.7426890367463 35.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8715562-2647-4102-b737-a2c9b392e8d5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66808810862156 139.74270951323086 35.89 35.668023074892666 139.74267407405063 35.89 35.668074335032834 139.74263687963716 35.89 35.66808810862156 139.74270951323086 35.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-69f56b37-c2ef-4b0b-a330-2e48c5362fd0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66808810862156 139.74270951323086 35.89 35.668074335032834 139.74263687963716 35.89 35.668108737806456 139.74265729781752 35.89 35.66808810862156 139.74270951323086 35.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e5751ada-5163-47af-93fa-4cff3fbab299">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668023074892666 139.74267407405063 35.89 35.6680447026806 139.7426193280211 35.89 35.668074335032834 139.74263687963716 35.89 35.668023074892666 139.74267407405063 35.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27bf0489-b4f3-4fe3-b8ec-57b73818781a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668023074892666 139.74267407405063 36.9 35.668020559031675 139.74267270719926 36.9 35.6680447026806 139.7426193280211 36.9 35.668023074892666 139.74267407405063 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e1caaeba-89b8-4dc4-8378-f063d66f0cef">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66808810862156 139.74270951323086 36.9 35.668108737806456 139.74265729781752 36.9 35.668090597432624 139.74271086906916 36.9 35.66808810862156 139.74270951323086 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9eb27c41-db65-4438-a5bc-68966c6c96b5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668020559031675 139.74267270719926 36.9 35.66804341028921 139.74261477855686 36.9 35.6680447026806 139.7426193280211 36.9 35.668020559031675 139.74267270719926 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80cfa658-6485-4dc8-bbcb-076a47b73ff2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668090597432624 139.74271086906916 36.9 35.668108737806456 139.74265729781752 36.9 35.668112396231614 139.74265576933968 36.9 35.668090597432624 139.74271086906916 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58e6d04e-bb8b-44bd-b34d-9dbdac0f992f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668074335032834 139.74263687963716 36.9 35.66804341028921 139.74261477855686 36.9 35.668112396231614 139.74265576933968 36.9 35.668074335032834 139.74263687963716 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e76a1d55-b9d2-47d6-be80-286a5eec3ce7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6680447026806 139.7426193280211 36.9 35.66804341028921 139.74261477855686 36.9 35.668074335032834 139.74263687963716 36.9 35.6680447026806 139.7426193280211 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f588ea03-90af-40e4-a376-d0227bc0d712">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668108737806456 139.74265729781752 36.9 35.668074335032834 139.74263687963716 36.9 35.668112396231614 139.74265576933968 36.9 35.668108737806456 139.74265729781752 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-193e0176-6c5c-44ca-a9b1-52ab0b08b738">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-193e0176-6c5c-44ca-a9b1-52ab0b08b738">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-193e0176-6c5c-44ca-a9b1-52ab0b08b738">
											<gml:posList>35.668077372662154 139.74274465146146 27.19 35.66808972695201 139.74275192782727 27.19 35.668064446472776 139.74281591238204 27.19 35.668054977824866 139.74281028964182 27.19 35.66804598136775 139.7428332753495 27.19 35.667895655014505 139.74274364170606 27.19 35.66792309492534 139.74267457369822 27.19 35.668001369077004 139.74272098857304 27.19 35.66804338317314 139.7426146791741 27.19 35.66807557657261 139.74263375223123 27.19 35.668085203036995 139.7426095507261 27.19 35.66812208573819 139.74263149043315 27.19 35.668077372662154 139.74274465146146 27.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-522094da-64b8-4abb-bb87-9c997f36fb7e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-522094da-64b8-4abb-bb87-9c997f36fb7e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-522094da-64b8-4abb-bb87-9c997f36fb7e">
											<gml:posList>35.667895655014505 139.74274364170606 36.9 35.667899457594054 139.74274202470605 36.9 35.66792441442218 139.74267921149334 36.9 35.66792309492534 139.74267457369822 36.9 35.667895655014505 139.74274364170606 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9e9e3067-2f0c-4bb0-a606-c8dece36a13d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e9e3067-2f0c-4bb0-a606-c8dece36a13d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e9e3067-2f0c-4bb0-a606-c8dece36a13d">
											<gml:posList>35.668001369077004 139.74272098857304 36.9 35.66792309492534 139.74267457369822 36.9 35.66792441442218 139.74267921149334 36.9 35.66800269759409 139.7427256374092 36.9 35.668001369077004 139.74272098857304 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-20015c57-32e4-4ae7-b16b-a535f59affe6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20015c57-32e4-4ae7-b16b-a535f59affe6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20015c57-32e4-4ae7-b16b-a535f59affe6">
											<gml:posList>35.66804598136775 139.7428332753495 36.9 35.668044652838205 139.7428286044172 36.9 35.667899457594054 139.74274202470605 36.9 35.667895655014505 139.74274364170606 36.9 35.66804598136775 139.7428332753495 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b1ee7d1b-f1e3-4342-a4ab-ba4285c80057">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b1ee7d1b-f1e3-4342-a4ab-ba4285c80057">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b1ee7d1b-f1e3-4342-a4ab-ba4285c80057">
											<gml:posList>35.66805364929444 139.74280561870938 35.89 35.668063126964604 139.74281125248473 35.89 35.66808593338619 139.7427535448205 35.89 35.66807357909642 139.74274626845477 35.89 35.668108737806456 139.74265729781752 35.89 35.668074335032834 139.74263687963716 35.89 35.6680447026806 139.7426193280211 35.89 35.66800269759409 139.7427256374092 35.89 35.66792441442218 139.74267921149334 35.89 35.667899457594054 139.74274202470605 35.89 35.668044652838205 139.7428286044172 35.89 35.66805364929444 139.74280561870938 35.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1033c00e-dd47-4070-bf1f-37e03ca7c8c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1033c00e-dd47-4070-bf1f-37e03ca7c8c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1033c00e-dd47-4070-bf1f-37e03ca7c8c1">
											<gml:posList>35.668001369077004 139.74272098857304 36.9 35.66800269759409 139.7427256374092 36.9 35.6680447026806 139.7426193280211 36.9 35.66804338317314 139.7426146791741 36.9 35.668001369077004 139.74272098857304 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-486ff259-6731-440f-8894-ab31700cf134">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-486ff259-6731-440f-8894-ab31700cf134">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-486ff259-6731-440f-8894-ab31700cf134">
											<gml:posList>35.668054977824866 139.74281028964182 36.9 35.66805364929444 139.74280561870938 36.9 35.668044652838205 139.7428286044172 36.9 35.66804598136775 139.7428332753495 36.9 35.668054977824866 139.74281028964182 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f39628a4-0016-441e-aea9-d3fb93795fef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f39628a4-0016-441e-aea9-d3fb93795fef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f39628a4-0016-441e-aea9-d3fb93795fef">
											<gml:posList>35.668054977824866 139.74281028964182 36.9 35.668064446472776 139.74281591238204 36.9 35.668063126964604 139.74281125248473 36.9 35.66805364929444 139.74280561870938 36.9 35.668054977824866 139.74281028964182 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bdb6918a-5662-437c-af20-35a4bddae17f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bdb6918a-5662-437c-af20-35a4bddae17f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bdb6918a-5662-437c-af20-35a4bddae17f">
											<gml:posList>35.66807557657261 139.74263375223123 36.9 35.66804338317314 139.7426146791741 36.9 35.6680447026806 139.7426193280211 36.9 35.668074335032834 139.74263687963716 36.9 35.66807557657261 139.74263375223123 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a6673295-d2c4-42fc-a648-895412e38821">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a6673295-d2c4-42fc-a648-895412e38821">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a6673295-d2c4-42fc-a648-895412e38821">
											<gml:posList>35.66808972695201 139.74275192782727 36.9 35.66808593338619 139.7427535448205 36.9 35.668063126964604 139.74281125248473 36.9 35.668064446472776 139.74281591238204 36.9 35.66808972695201 139.74275192782727 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-98cd7bc4-264d-4533-85e2-0f66705d0d78">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-98cd7bc4-264d-4533-85e2-0f66705d0d78">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-98cd7bc4-264d-4533-85e2-0f66705d0d78">
											<gml:posList>35.668077372662154 139.74274465146146 36.9 35.66807357909642 139.74274626845477 36.9 35.66808593338619 139.7427535448205 36.9 35.66808972695201 139.74275192782727 36.9 35.668077372662154 139.74274465146146 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-de79e765-e5cf-4f50-a39a-dd8cb4c2f755">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de79e765-e5cf-4f50-a39a-dd8cb4c2f755">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de79e765-e5cf-4f50-a39a-dd8cb4c2f755">
											<gml:posList>35.668077372662154 139.74274465146146 36.9 35.668112531370966 139.74265568081927 36.9 35.668108737806456 139.74265729781752 36.9 35.66807357909642 139.74274626845477 36.9 35.668077372662154 139.74274465146146 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-195f1b59-910c-4fe9-a739-469a6e2e6963">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-195f1b59-910c-4fe9-a739-469a6e2e6963">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-195f1b59-910c-4fe9-a739-469a6e2e6963">
											<gml:posList>35.66807557657261 139.74263375223123 36.9 35.668074335032834 139.74263687963716 36.9 35.668108737806456 139.74265729781752 36.9 35.668112531370966 139.74265568081927 36.9 35.66807557657261 139.74263375223123 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-555400df-c2ec-4382-8841-e64f8945fca4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-555400df-c2ec-4382-8841-e64f8945fca4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-555400df-c2ec-4382-8841-e64f8945fca4">
											<gml:posList>35.668112531370966 139.74265568081927 40.1 35.66812208573819 139.74263149043315 40.1 35.668085203036995 139.7426095507261 40.1 35.66807557657261 139.74263375223123 40.1 35.668112531370966 139.74265568081927 40.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7dd15307-edd1-40e3-8cb8-66827ee8fc12">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7dd15307-edd1-40e3-8cb8-66827ee8fc12">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7dd15307-edd1-40e3-8cb8-66827ee8fc12">
											<gml:posList>35.66812208573819 139.74263149043315 27.19 35.668085203036995 139.7426095507261 27.19 35.668085203036995 139.7426095507261 40.1 35.66812208573819 139.74263149043315 40.1 35.66812208573819 139.74263149043315 27.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6743b814-450e-478d-9244-509bf9a45b25">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6743b814-450e-478d-9244-509bf9a45b25">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6743b814-450e-478d-9244-509bf9a45b25">
											<gml:posList>35.668085203036995 139.7426095507261 40.1 35.668085203036995 139.7426095507261 27.19 35.66807557657261 139.74263375223123 27.19 35.66807557657261 139.74263375223123 36.9 35.66807557657261 139.74263375223123 40.1 35.668085203036995 139.7426095507261 40.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9924510a-d901-44c9-8ca2-d003410d7434">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9924510a-d901-44c9-8ca2-d003410d7434">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9924510a-d901-44c9-8ca2-d003410d7434">
											<gml:posList>35.66807557657261 139.74263375223123 27.19 35.66804338317314 139.7426146791741 27.19 35.66804338317314 139.7426146791741 36.9 35.66807557657261 139.74263375223123 36.9 35.66807557657261 139.74263375223123 27.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a1419500-2315-41bd-8d4a-b5909cbcab0a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a1419500-2315-41bd-8d4a-b5909cbcab0a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a1419500-2315-41bd-8d4a-b5909cbcab0a">
											<gml:posList>35.6680447026806 139.7426193280211 36.9 35.6680447026806 139.7426193280211 35.89 35.668074335032834 139.74263687963716 35.89 35.668074335032834 139.74263687963716 36.9 35.6680447026806 139.7426193280211 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1d370927-f94f-4a91-a906-c9a0abfd1459">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d370927-f94f-4a91-a906-c9a0abfd1459">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d370927-f94f-4a91-a906-c9a0abfd1459">
											<gml:posList>35.668112531370966 139.74265568081927 36.9 35.668112531370966 139.74265568081927 40.1 35.66807557657261 139.74263375223123 40.1 35.66807557657261 139.74263375223123 36.9 35.668112531370966 139.74265568081927 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ef35287f-f1ac-4f3c-aae8-975fca0bd081">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef35287f-f1ac-4f3c-aae8-975fca0bd081">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef35287f-f1ac-4f3c-aae8-975fca0bd081">
											<gml:posList>35.668074335032834 139.74263687963716 36.9 35.668074335032834 139.74263687963716 35.89 35.668108737806456 139.74265729781752 35.89 35.668108737806456 139.74265729781752 36.9 35.668074335032834 139.74263687963716 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-618ab26f-dd8a-400b-8a5a-b750dc10314b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-618ab26f-dd8a-400b-8a5a-b750dc10314b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-618ab26f-dd8a-400b-8a5a-b750dc10314b">
											<gml:posList>35.668001369077004 139.74272098857304 36.9 35.66804338317314 139.7426146791741 36.9 35.66804338317314 139.7426146791741 27.19 35.668001369077004 139.74272098857304 27.19 35.668001369077004 139.74272098857304 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ef2de5eb-ec7f-4af9-ad04-4339044efd35">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef2de5eb-ec7f-4af9-ad04-4339044efd35">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef2de5eb-ec7f-4af9-ad04-4339044efd35">
											<gml:posList>35.66800269759409 139.7427256374092 36.9 35.66800269759409 139.7427256374092 35.89 35.6680447026806 139.7426193280211 35.89 35.6680447026806 139.7426193280211 36.9 35.66800269759409 139.7427256374092 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-75a9cf99-63e0-4cad-9cb2-e8f2aaaf84da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-75a9cf99-63e0-4cad-9cb2-e8f2aaaf84da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-75a9cf99-63e0-4cad-9cb2-e8f2aaaf84da">
											<gml:posList>35.66812208573819 139.74263149043315 27.19 35.66812208573819 139.74263149043315 40.1 35.668112531370966 139.74265568081927 40.1 35.668112531370966 139.74265568081927 36.9 35.668077372662154 139.74274465146146 36.9 35.668077372662154 139.74274465146146 27.19 35.66812208573819 139.74263149043315 27.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-034bb4d3-5fae-4e58-94b2-6901355e1387">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-034bb4d3-5fae-4e58-94b2-6901355e1387">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-034bb4d3-5fae-4e58-94b2-6901355e1387">
											<gml:posList>35.668001369077004 139.74272098857304 27.19 35.66792309492534 139.74267457369822 27.19 35.66792309492534 139.74267457369822 36.9 35.668001369077004 139.74272098857304 36.9 35.668001369077004 139.74272098857304 27.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1bb552e8-9ac1-4c41-a376-308cc97afa4f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1bb552e8-9ac1-4c41-a376-308cc97afa4f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1bb552e8-9ac1-4c41-a376-308cc97afa4f">
											<gml:posList>35.668108737806456 139.74265729781752 36.9 35.668108737806456 139.74265729781752 35.89 35.66807357909642 139.74274626845477 35.89 35.66807357909642 139.74274626845477 36.9 35.668108737806456 139.74265729781752 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2283a557-d60c-477f-9f50-dcf2f4497030">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2283a557-d60c-477f-9f50-dcf2f4497030">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2283a557-d60c-477f-9f50-dcf2f4497030">
											<gml:posList>35.66792441442218 139.74267921149334 36.9 35.66792441442218 139.74267921149334 35.89 35.66800269759409 139.7427256374092 35.89 35.66800269759409 139.7427256374092 36.9 35.66792441442218 139.74267921149334 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9a470d2a-0b47-495b-b4e3-ca4dd7d3e881">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a470d2a-0b47-495b-b4e3-ca4dd7d3e881">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a470d2a-0b47-495b-b4e3-ca4dd7d3e881">
											<gml:posList>35.66792309492534 139.74267457369822 27.19 35.667895655014505 139.74274364170606 27.19 35.667895655014505 139.74274364170606 36.9 35.66792309492534 139.74267457369822 36.9 35.66792309492534 139.74267457369822 27.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eda3ba2d-8499-4156-abe1-1c981de16d34">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eda3ba2d-8499-4156-abe1-1c981de16d34">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eda3ba2d-8499-4156-abe1-1c981de16d34">
											<gml:posList>35.667899457594054 139.74274202470605 36.9 35.667899457594054 139.74274202470605 35.89 35.66792441442218 139.74267921149334 35.89 35.66792441442218 139.74267921149334 36.9 35.667899457594054 139.74274202470605 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e3bcc631-2010-4c27-a9d2-d449b782db33">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e3bcc631-2010-4c27-a9d2-d449b782db33">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e3bcc631-2010-4c27-a9d2-d449b782db33">
											<gml:posList>35.66808972695201 139.74275192782727 27.19 35.668077372662154 139.74274465146146 27.19 35.668077372662154 139.74274465146146 36.9 35.66808972695201 139.74275192782727 36.9 35.66808972695201 139.74275192782727 27.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b732e0d0-2d41-4070-9412-050a33a77c74">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b732e0d0-2d41-4070-9412-050a33a77c74">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b732e0d0-2d41-4070-9412-050a33a77c74">
											<gml:posList>35.66807357909642 139.74274626845477 36.9 35.66807357909642 139.74274626845477 35.89 35.66808593338619 139.7427535448205 35.89 35.66808593338619 139.7427535448205 36.9 35.66807357909642 139.74274626845477 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dcf7f78a-ee3b-4ed0-885c-89c08ab17b9d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dcf7f78a-ee3b-4ed0-885c-89c08ab17b9d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dcf7f78a-ee3b-4ed0-885c-89c08ab17b9d">
											<gml:posList>35.66808593338619 139.7427535448205 36.9 35.66808593338619 139.7427535448205 35.89 35.668063126964604 139.74281125248473 35.89 35.668063126964604 139.74281125248473 36.9 35.66808593338619 139.7427535448205 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d1024ba6-546c-4be2-a662-2281636b5b94">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1024ba6-546c-4be2-a662-2281636b5b94">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1024ba6-546c-4be2-a662-2281636b5b94">
											<gml:posList>35.668064446472776 139.74281591238204 27.19 35.66808972695201 139.74275192782727 27.19 35.66808972695201 139.74275192782727 36.9 35.668064446472776 139.74281591238204 36.9 35.668064446472776 139.74281591238204 27.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0cc2954b-a417-4cf7-bd8b-4c2106745136">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0cc2954b-a417-4cf7-bd8b-4c2106745136">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0cc2954b-a417-4cf7-bd8b-4c2106745136">
											<gml:posList>35.668044652838205 139.7428286044172 36.9 35.668044652838205 139.7428286044172 35.89 35.667899457594054 139.74274202470605 35.89 35.667899457594054 139.74274202470605 36.9 35.668044652838205 139.7428286044172 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-67c1dee9-8eaa-4151-a483-cddb0c8991ed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67c1dee9-8eaa-4151-a483-cddb0c8991ed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67c1dee9-8eaa-4151-a483-cddb0c8991ed">
											<gml:posList>35.667895655014505 139.74274364170606 27.19 35.66804598136775 139.7428332753495 27.19 35.66804598136775 139.7428332753495 36.9 35.667895655014505 139.74274364170606 36.9 35.667895655014505 139.74274364170606 27.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c2088383-e048-4e77-971b-fa1f9a0091c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c2088383-e048-4e77-971b-fa1f9a0091c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c2088383-e048-4e77-971b-fa1f9a0091c2">
											<gml:posList>35.668063126964604 139.74281125248473 36.9 35.668063126964604 139.74281125248473 35.89 35.66805364929444 139.74280561870938 35.89 35.66805364929444 139.74280561870938 36.9 35.668063126964604 139.74281125248473 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-41d4c33a-a6eb-49c0-94ba-988b60e69097">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41d4c33a-a6eb-49c0-94ba-988b60e69097">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41d4c33a-a6eb-49c0-94ba-988b60e69097">
											<gml:posList>35.668054977824866 139.74281028964182 27.19 35.668064446472776 139.74281591238204 27.19 35.668064446472776 139.74281591238204 36.9 35.668054977824866 139.74281028964182 36.9 35.668054977824866 139.74281028964182 27.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3f17e6a0-f231-4d2d-99b6-efe274b6cdaa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f17e6a0-f231-4d2d-99b6-efe274b6cdaa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f17e6a0-f231-4d2d-99b6-efe274b6cdaa">
											<gml:posList>35.66805364929444 139.74280561870938 36.9 35.66805364929444 139.74280561870938 35.89 35.668044652838205 139.7428286044172 35.89 35.668044652838205 139.7428286044172 36.9 35.66805364929444 139.74280561870938 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-66f164fc-5d4a-40cb-a705-c8fc378bdaa5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66f164fc-5d4a-40cb-a705-c8fc378bdaa5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66f164fc-5d4a-40cb-a705-c8fc378bdaa5">
											<gml:posList>35.66804598136775 139.7428332753495 27.19 35.668054977824866 139.74281028964182 27.19 35.668054977824866 139.74281028964182 36.9 35.66804598136775 139.7428332753495 36.9 35.66804598136775 139.7428332753495 27.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4789</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">271.03224</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1003</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">6</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1123</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">21</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>