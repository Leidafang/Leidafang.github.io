<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_a2ec3107-1b83-4e5d-a935-5d2242aa52f0">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">10.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67357433318922 139.73748243181947 0 35.67351389070703 139.7375095574319 0 35.67352898381504 139.73756006696513 0 35.67353768797296 139.7375561681303 0 35.67355453462287 139.73761283965013 0 35.67360634506145 139.73758959075758 0 35.67357433318922 139.73748243181947 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67357433318922 139.73748243181947 9.27 35.67360634506145 139.73758959075758 9.27 35.67355453462287 139.73761283965013 9.27 35.67353768797296 139.7375561681303 9.27 35.67352898381504 139.73756006696513 9.27 35.67351389070703 139.7375095574319 9.27 35.67357433318922 139.73748243181947 9.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67357433318922 139.73748243181947 9.27 35.67351389070703 139.7375095574319 9.27 35.67351389070703 139.7375095574319 19.53 35.67357433318922 139.73748243181947 19.53 35.67357433318922 139.73748243181947 9.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67351389070703 139.7375095574319 9.27 35.67352898381504 139.73756006696513 9.27 35.67352898381504 139.73756006696513 19.53 35.67351389070703 139.7375095574319 19.53 35.67351389070703 139.7375095574319 9.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67352898381504 139.73756006696513 9.27 35.67353768797296 139.7375561681303 9.27 35.67353768797296 139.7375561681303 19.53 35.67352898381504 139.73756006696513 19.53 35.67352898381504 139.73756006696513 9.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67353768797296 139.7375561681303 9.27 35.67355453462287 139.73761283965013 9.27 35.67355453462287 139.73761283965013 19.53 35.67353768797296 139.7375561681303 19.53 35.67353768797296 139.7375561681303 9.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67355453462287 139.73761283965013 9.27 35.67360634506145 139.73758959075758 9.27 35.67360634506145 139.73758959075758 19.53 35.67355453462287 139.73761283965013 19.53 35.67355453462287 139.73761283965013 9.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67360634506145 139.73758959075758 9.27 35.67357433318922 139.73748243181947 9.27 35.67357433318922 139.73748243181947 19.53 35.67360634506145 139.73758959075758 19.53 35.67360634506145 139.73758959075758 9.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67357433318922 139.73748243181947 19.53 35.67351389070703 139.7375095574319 19.53 35.67352898381504 139.73756006696513 19.53 35.67353768797296 139.7375561681303 19.53 35.67355453462287 139.73761283965013 19.53 35.67360634506145 139.73758959075758 19.53 35.67357433318922 139.73748243181947 19.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-325868d9-ec2d-47b9-9be7-7feeeb946fff"/>
							<gml:surfaceMember xlink:href="#poly-4e210076-8435-4b94-a6a6-06c5be77d22e"/>
							<gml:surfaceMember xlink:href="#poly-5ec526f6-b6a7-43a5-a588-c89bb29fa174"/>
							<gml:surfaceMember xlink:href="#poly-1b206651-7c75-4068-af30-88d9de467cc3"/>
							<gml:surfaceMember xlink:href="#poly-a3f7235f-8d20-438f-b074-72e0dacff6ae"/>
							<gml:surfaceMember xlink:href="#poly-f89a5afa-fdfa-45e7-9b85-237b2b1bb45e"/>
							<gml:surfaceMember xlink:href="#poly-c9c93641-7f1a-4638-bee7-4db05647647c"/>
							<gml:surfaceMember xlink:href="#poly-6a186de7-3482-4816-a2a3-c6d9092a5019"/>
							<gml:surfaceMember xlink:href="#poly-69d4a10b-69a0-49ea-af3f-4c636232785c"/>
							<gml:surfaceMember xlink:href="#poly-45aa3907-a830-4fd5-8693-81c7a3fb021b"/>
							<gml:surfaceMember xlink:href="#poly-033059e6-0f0f-4f5e-b285-8dc220b3ab43"/>
							<gml:surfaceMember xlink:href="#poly-4413e08f-04e1-4b1a-983c-d819512ec800"/>
							<gml:surfaceMember xlink:href="#poly-0a93b47c-0a18-4d50-89a4-85150ccb6714"/>
							<gml:surfaceMember xlink:href="#poly-388d4388-0c0a-414c-8dfb-8e687fb7cde6"/>
							<gml:surfaceMember xlink:href="#poly-0b31506d-e3a2-471d-ada4-7d289b96dec7"/>
							<gml:surfaceMember xlink:href="#poly-2fb4f499-7047-499d-8196-a3bf34f05299"/>
							<gml:surfaceMember xlink:href="#poly-f310d04d-b7e2-4690-8ba3-1dc2bf8e8f93"/>
							<gml:surfaceMember xlink:href="#poly-9423d454-4810-4e71-ac06-9a0996cb10bd"/>
							<gml:surfaceMember xlink:href="#poly-9717a4a7-def3-4f3b-a488-0dd829a2d9b4"/>
							<gml:surfaceMember xlink:href="#poly-8a0b7f96-c06b-4537-84ec-b7e1f8ac77d0"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_a2ec3107-1b83-4e5d-a935-5d2242aa52f0_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-291a2cee-a742-4e30-b669-cce4f42f268a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673523607450235 139.73750949058422 20.642 35.67352268567742 139.73750650907908 20.642 35.67354708612833 139.73749555473086 20.642 35.67354800790141 139.73749853623673 20.642 35.673523607450235 139.73750949058422 20.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c2c27507-6eba-4620-9f83-203e6ee61af5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67353769644186 139.73755548322518 20.642 35.673536720429716 139.73755230294333 20.642 35.67353965786462 139.73755099592387 20.642 35.673540606835644 139.73755417623812 20.642 35.67353769644186 139.73755548322518 20.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3574c1d-aa25-4d25-a00a-3cd58cfa6efd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67353965786462 139.73755099592387 20.15 35.673536720429716 139.73755230294333 20.15 35.673523607450235 139.73750949058422 20.15 35.67354800790141 139.73749853623673 20.15 35.673562168989356 139.7375445067102 20.15 35.673540606835644 139.73755417623812 20.15 35.67353965786462 139.73755099592387 20.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-acaf8dba-147d-4230-9030-83c545976769">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-acaf8dba-147d-4230-9030-83c545976769_0">
											<gml:posList>35.673523607450235 139.73750949058422 20.15 35.673536720429716 139.73755230294333 20.15 35.673536720429716 139.73755230294333 20.642 35.67353769644186 139.73755548322518 20.642 35.67353769644186 139.73755548322518 21.407 35.67352268567742 139.73750650907908 21.407 35.67352268567742 139.73750650907908 20.642 35.673523607450235 139.73750949058422 20.642 35.673523607450235 139.73750949058422 20.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-07526787-5a9e-4513-929b-cca225a86dd4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-07526787-5a9e-4513-929b-cca225a86dd4_0">
											<gml:posList>35.67354708612833 139.73749555473086 21.407 35.67354708612833 139.73749555473086 20.642 35.67352268567742 139.73750650907908 20.642 35.67352268567742 139.73750650907908 21.407 35.67354708612833 139.73749555473086 21.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1ed7b73b-7704-4b2e-b6f6-52450b068d3b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1ed7b73b-7704-4b2e-b6f6-52450b068d3b_0">
											<gml:posList>35.673523607450235 139.73750949058422 20.642 35.67354800790141 139.73749853623673 20.642 35.67354800790141 139.73749853623673 20.15 35.673523607450235 139.73750949058422 20.15 35.673523607450235 139.73750949058422 20.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-674d1883-8662-4820-8b2d-35a360867aca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-674d1883-8662-4820-8b2d-35a360867aca_0">
											<gml:posList>35.673536720429716 139.73755230294333 20.15 35.67353965786462 139.73755099592387 20.15 35.67353965786462 139.73755099592387 20.642 35.673536720429716 139.73755230294333 20.642 35.673536720429716 139.73755230294333 20.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73bf48ba-fb84-4cd1-ae8e-fe6aa25e27ee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73bf48ba-fb84-4cd1-ae8e-fe6aa25e27ee_0">
											<gml:posList>35.673540606835644 139.73755417623812 20.642 35.67353965786462 139.73755099592387 20.642 35.67353965786462 139.73755099592387 20.15 35.673540606835644 139.73755417623812 20.15 35.673540606835644 139.73755417623812 20.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-52adba6f-f045-4582-934d-e4dfe394101d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-52adba6f-f045-4582-934d-e4dfe394101d_0">
											<gml:posList>35.67353769644186 139.73755548322518 21.407 35.673562168989356 139.7375445067102 21.407 35.67354708612833 139.73749555473086 21.407 35.67352268567742 139.73750650907908 21.407 35.67353769644186 139.73755548322518 21.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fd9bad3b-5aa1-4cff-a521-178456f8736b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fd9bad3b-5aa1-4cff-a521-178456f8736b_0">
											<gml:posList>35.67353769644186 139.73755548322518 21.407 35.67353769644186 139.73755548322518 20.642 35.673540606835644 139.73755417623812 20.642 35.673540606835644 139.73755417623812 20.15 35.673562168989356 139.7375445067102 20.15 35.673562168989356 139.7375445067102 21.407 35.67353769644186 139.73755548322518 21.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca4f4428-5d54-4ed9-b2e8-e84f941410fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ca4f4428-5d54-4ed9-b2e8-e84f941410fd_0">
											<gml:posList>35.673562168989356 139.7375445067102 20.15 35.67354800790141 139.73749853623673 20.15 35.67354800790141 139.73749853623673 20.642 35.67354708612833 139.73749555473086 20.642 35.67354708612833 139.73749555473086 21.407 35.673562168989356 139.7375445067102 21.407 35.673562168989356 139.7375445067102 20.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-325868d9-ec2d-47b9-9be7-7feeeb946fff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-325868d9-ec2d-47b9-9be7-7feeeb946fff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-325868d9-ec2d-47b9-9be7-7feeeb946fff">
											<gml:posList>35.67357433318921 139.73748243181947 9.27 35.67360634506143 139.73758959075755 9.27 35.67355453462286 139.7376128396501 9.27 35.67353768797293 139.7375561681303 9.27 35.67352898381504 139.73756006696513 9.27 35.67351389070702 139.73750955743193 9.27 35.67357433318921 139.73748243181947 9.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4e210076-8435-4b94-a6a6-06c5be77d22e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4e210076-8435-4b94-a6a6-06c5be77d22e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4e210076-8435-4b94-a6a6-06c5be77d22e">
											<gml:posList>35.67352898381504 139.73756006696513 20.642 35.67353093567946 139.73755489478089 20.642 35.67351811104314 139.73751196056617 20.642 35.67351389070702 139.73750955743193 20.642 35.67352898381504 139.73756006696513 20.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5ec526f6-b6a7-43a5-a588-c89bb29fa174">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5ec526f6-b6a7-43a5-a588-c89bb29fa174">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5ec526f6-b6a7-43a5-a588-c89bb29fa174">
											<gml:posList>35.67353768797293 139.7375561681303 20.642 35.67353965786462 139.73755099592387 20.642 35.67353093567946 139.73755489478089 20.642 35.67352898381504 139.73756006696513 20.642 35.67353768797293 139.7375561681303 20.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1b206651-7c75-4068-af30-88d9de467cc3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b206651-7c75-4068-af30-88d9de467cc3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b206651-7c75-4068-af30-88d9de467cc3">
											<gml:posList>35.67351389070702 139.73750955743193 20.642 35.67351811104314 139.73751196056617 20.642 35.67357238131913 139.7374875929616 20.642 35.67357433318921 139.73748243181947 20.642 35.67351389070702 139.73750955743193 20.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a3f7235f-8d20-438f-b074-72e0dacff6ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a3f7235f-8d20-438f-b074-72e0dacff6ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a3f7235f-8d20-438f-b074-72e0dacff6ae">
											<gml:posList>35.67353768797293 139.7375561681303 20.642 35.67355453462286 139.7376128396501 20.642 35.673556495512045 139.73760767850143 20.642 35.67353965786462 139.73755099592387 20.642 35.67353768797293 139.7375561681303 20.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f89a5afa-fdfa-45e7-9b85-237b2b1bb45e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f89a5afa-fdfa-45e7-9b85-237b2b1bb45e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f89a5afa-fdfa-45e7-9b85-237b2b1bb45e">
											<gml:posList>35.67353965786462 139.73755099592387 20.15 35.673556495512045 139.73760767850143 20.15 35.67360213374942 139.7375871986525 20.15 35.67357238131913 139.7374875929616 20.15 35.67351811104314 139.73751196056617 20.15 35.67353093567946 139.73755489478089 20.15 35.67353965786462 139.73755099592387 20.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c9c93641-7f1a-4638-bee7-4db05647647c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c9c93641-7f1a-4638-bee7-4db05647647c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c9c93641-7f1a-4638-bee7-4db05647647c">
											<gml:posList>35.67360634506143 139.73758959075755 20.642 35.67360213374942 139.7375871986525 20.642 35.673556495512045 139.73760767850143 20.642 35.67355453462286 139.7376128396501 20.642 35.67360634506143 139.73758959075755 20.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6a186de7-3482-4816-a2a3-c6d9092a5019">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a186de7-3482-4816-a2a3-c6d9092a5019">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a186de7-3482-4816-a2a3-c6d9092a5019">
											<gml:posList>35.67357433318921 139.73748243181947 20.642 35.67357238131913 139.7374875929616 20.642 35.67360213374942 139.7375871986525 20.642 35.67360634506143 139.73758959075755 20.642 35.67357433318921 139.73748243181947 20.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-69d4a10b-69a0-49ea-af3f-4c636232785c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69d4a10b-69a0-49ea-af3f-4c636232785c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69d4a10b-69a0-49ea-af3f-4c636232785c">
											<gml:posList>35.67351389070702 139.73750955743193 9.27 35.67352898381504 139.73756006696513 9.27 35.67352898381504 139.73756006696513 20.642 35.67351389070702 139.73750955743193 20.642 35.67351389070702 139.73750955743193 9.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-45aa3907-a830-4fd5-8693-81c7a3fb021b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45aa3907-a830-4fd5-8693-81c7a3fb021b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45aa3907-a830-4fd5-8693-81c7a3fb021b">
											<gml:posList>35.67357433318921 139.73748243181947 9.27 35.67351389070702 139.73750955743193 9.27 35.67351389070702 139.73750955743193 20.642 35.67357433318921 139.73748243181947 20.642 35.67357433318921 139.73748243181947 9.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-033059e6-0f0f-4f5e-b285-8dc220b3ab43">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-033059e6-0f0f-4f5e-b285-8dc220b3ab43">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-033059e6-0f0f-4f5e-b285-8dc220b3ab43">
											<gml:posList>35.67351811104314 139.73751196056617 20.642 35.67351811104314 139.73751196056617 20.15 35.67357238131913 139.7374875929616 20.15 35.67357238131913 139.7374875929616 20.642 35.67351811104314 139.73751196056617 20.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4413e08f-04e1-4b1a-983c-d819512ec800">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4413e08f-04e1-4b1a-983c-d819512ec800">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4413e08f-04e1-4b1a-983c-d819512ec800">
											<gml:posList>35.67353093567946 139.73755489478089 20.642 35.67353093567946 139.73755489478089 20.15 35.67351811104314 139.73751196056617 20.15 35.67351811104314 139.73751196056617 20.642 35.67353093567946 139.73755489478089 20.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0a93b47c-0a18-4d50-89a4-85150ccb6714">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a93b47c-0a18-4d50-89a4-85150ccb6714">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a93b47c-0a18-4d50-89a4-85150ccb6714">
											<gml:posList>35.67360634506143 139.73758959075755 9.27 35.67357433318921 139.73748243181947 9.27 35.67357433318921 139.73748243181947 20.642 35.67360634506143 139.73758959075755 20.642 35.67360634506143 139.73758959075755 9.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-388d4388-0c0a-414c-8dfb-8e687fb7cde6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-388d4388-0c0a-414c-8dfb-8e687fb7cde6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-388d4388-0c0a-414c-8dfb-8e687fb7cde6">
											<gml:posList>35.67357238131913 139.7374875929616 20.642 35.67357238131913 139.7374875929616 20.15 35.67360213374942 139.7375871986525 20.15 35.67360213374942 139.7375871986525 20.642 35.67357238131913 139.7374875929616 20.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0b31506d-e3a2-471d-ada4-7d289b96dec7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b31506d-e3a2-471d-ada4-7d289b96dec7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b31506d-e3a2-471d-ada4-7d289b96dec7">
											<gml:posList>35.67353965786462 139.73755099592387 20.642 35.67353965786462 139.73755099592387 20.15 35.67353093567946 139.73755489478089 20.15 35.67353093567946 139.73755489478089 20.642 35.67353965786462 139.73755099592387 20.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2fb4f499-7047-499d-8196-a3bf34f05299">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2fb4f499-7047-499d-8196-a3bf34f05299">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2fb4f499-7047-499d-8196-a3bf34f05299">
											<gml:posList>35.67352898381504 139.73756006696513 9.27 35.67353768797293 139.7375561681303 9.27 35.67353768797293 139.7375561681303 20.642 35.67352898381504 139.73756006696513 20.642 35.67352898381504 139.73756006696513 9.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f310d04d-b7e2-4690-8ba3-1dc2bf8e8f93">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f310d04d-b7e2-4690-8ba3-1dc2bf8e8f93">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f310d04d-b7e2-4690-8ba3-1dc2bf8e8f93">
											<gml:posList>35.673556495512045 139.73760767850143 20.642 35.673556495512045 139.73760767850143 20.15 35.67353965786462 139.73755099592387 20.15 35.67353965786462 139.73755099592387 20.642 35.673556495512045 139.73760767850143 20.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9423d454-4810-4e71-ac06-9a0996cb10bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9423d454-4810-4e71-ac06-9a0996cb10bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9423d454-4810-4e71-ac06-9a0996cb10bd">
											<gml:posList>35.67353768797293 139.7375561681303 9.27 35.67355453462286 139.7376128396501 9.27 35.67355453462286 139.7376128396501 20.642 35.67353768797293 139.7375561681303 20.642 35.67353768797293 139.7375561681303 9.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9717a4a7-def3-4f3b-a488-0dd829a2d9b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9717a4a7-def3-4f3b-a488-0dd829a2d9b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9717a4a7-def3-4f3b-a488-0dd829a2d9b4">
											<gml:posList>35.67360213374942 139.7375871986525 20.642 35.67360213374942 139.7375871986525 20.15 35.673556495512045 139.73760767850143 20.15 35.673556495512045 139.73760767850143 20.642 35.67360213374942 139.7375871986525 20.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8a0b7f96-c06b-4537-84ec-b7e1f8ac77d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a0b7f96-c06b-4537-84ec-b7e1f8ac77d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a0b7f96-c06b-4537-84ec-b7e1f8ac77d0">
											<gml:posList>35.67355453462286 139.7376128396501 9.27 35.67360634506143 139.73758959075755 9.27 35.67360634506143 139.73758959075755 20.642 35.67355453462286 139.7376128396501 20.642 35.67355453462286 139.7376128396501 9.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7017</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">87.17806</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.04</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>