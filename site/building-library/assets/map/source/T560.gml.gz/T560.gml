<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_a36fff76-ebcf-42e8-88d7-45d85a68ec9d">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>29</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103029002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">10.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66715937825702 139.7382554539895 0 35.66716831056761 139.7382664892152 0 35.66719730711952 139.73823143958617 0 35.66705899082319 139.73805973095497 0 35.66704485272907 139.73807675828454 0 35.66703989028584 139.73807057853207 0 35.66700432004819 139.73811358892874 0 35.66713875653003 139.73828044197734 0 35.66715937825702 139.7382554539895 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66715937825702 139.7382554539895 13.625 35.66713875653003 139.73828044197734 13.625 35.66700432004819 139.73811358892874 13.625 35.66703989028584 139.73807057853207 13.625 35.66704485272907 139.73807675828454 13.625 35.66705899082319 139.73805973095497 13.625 35.66719730711952 139.73823143958617 13.625 35.66716831056761 139.7382664892152 13.625 35.66715937825702 139.7382554539895 13.625</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66715937825702 139.7382554539895 13.625 35.66716831056761 139.7382664892152 13.625 35.66716831056761 139.7382664892152 24.57 35.66715937825702 139.7382554539895 24.57 35.66715937825702 139.7382554539895 13.625</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66716831056761 139.7382664892152 13.625 35.66719730711952 139.73823143958617 13.625 35.66719730711952 139.73823143958617 24.57 35.66716831056761 139.7382664892152 24.57 35.66716831056761 139.7382664892152 13.625</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66719730711952 139.73823143958617 13.625 35.66705899082319 139.73805973095497 13.625 35.66705899082319 139.73805973095497 24.57 35.66719730711952 139.73823143958617 24.57 35.66719730711952 139.73823143958617 13.625</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66705899082319 139.73805973095497 13.625 35.66704485272907 139.73807675828454 13.625 35.66704485272907 139.73807675828454 24.57 35.66705899082319 139.73805973095497 24.57 35.66705899082319 139.73805973095497 13.625</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66704485272907 139.73807675828454 13.625 35.66703989028584 139.73807057853207 13.625 35.66703989028584 139.73807057853207 24.57 35.66704485272907 139.73807675828454 24.57 35.66704485272907 139.73807675828454 13.625</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66703989028584 139.73807057853207 13.625 35.66700432004819 139.73811358892874 13.625 35.66700432004819 139.73811358892874 24.57 35.66703989028584 139.73807057853207 24.57 35.66703989028584 139.73807057853207 13.625</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66700432004819 139.73811358892874 13.625 35.66713875653003 139.73828044197734 13.625 35.66713875653003 139.73828044197734 24.57 35.66700432004819 139.73811358892874 24.57 35.66700432004819 139.73811358892874 13.625</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66713875653003 139.73828044197734 13.625 35.66715937825702 139.7382554539895 13.625 35.66715937825702 139.7382554539895 24.57 35.66713875653003 139.73828044197734 24.57 35.66713875653003 139.73828044197734 13.625</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66715937825702 139.7382554539895 24.57 35.66716831056761 139.7382664892152 24.57 35.66719730711952 139.73823143958617 24.57 35.66705899082319 139.73805973095497 24.57 35.66704485272907 139.73807675828454 24.57 35.66703989028584 139.73807057853207 24.57 35.66700432004819 139.73811358892874 24.57 35.66713875653003 139.73828044197734 24.57 35.66715937825702 139.7382554539895 24.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-4f779726-efbe-4922-b3f5-86f53db8ce4e"/>
							<gml:surfaceMember xlink:href="#poly-0e1e57b2-740c-48d8-95c8-9e7268310859"/>
							<gml:surfaceMember xlink:href="#poly-0133b2bd-8098-4078-b661-239c8512b24c"/>
							<gml:surfaceMember xlink:href="#poly-180b70e5-7d37-4c00-b3da-81a200dcc03b"/>
							<gml:surfaceMember xlink:href="#poly-9489a935-6d18-41a0-8f8a-a4703b3ee1f8"/>
							<gml:surfaceMember xlink:href="#poly-90f2df24-3de2-483e-8da3-d63da2a7c749"/>
							<gml:surfaceMember xlink:href="#poly-8d5af01b-266f-435f-b661-8ca22f508002"/>
							<gml:surfaceMember xlink:href="#poly-873b27ec-1580-405b-87f9-31c6f4a1950b"/>
							<gml:surfaceMember xlink:href="#poly-14e3300b-1c62-4c76-b7d0-3e34fa9f74f6"/>
							<gml:surfaceMember xlink:href="#poly-60e9b2d8-dc2c-4c8a-9624-e815c0b18b6a"/>
							<gml:surfaceMember xlink:href="#poly-2cd4d557-6c23-4fbe-b2a3-b273f63c2cfa"/>
							<gml:surfaceMember xlink:href="#poly-04c746ed-4315-49ab-98a9-3984d852e509"/>
							<gml:surfaceMember xlink:href="#poly-a6b8d667-85fe-4311-9347-6e1b1c687dd6"/>
							<gml:surfaceMember xlink:href="#poly-554bb9fb-f38e-46c4-919f-e29cbe593ecc"/>
							<gml:surfaceMember xlink:href="#poly-a8930596-edac-4811-a7d9-9d0a3290791d"/>
							<gml:surfaceMember xlink:href="#poly-fc92e572-539a-4ecf-b1bc-34cce25b07fe"/>
							<gml:surfaceMember xlink:href="#poly-07ec3a98-ccb9-4b6b-9857-52b5c1ef2448"/>
							<gml:surfaceMember xlink:href="#poly-42709a06-81b8-48df-84c3-d84836a327a7"/>
							<gml:surfaceMember xlink:href="#poly-1d4dabc7-2462-4aac-b5f5-6300c7965ca1"/>
							<gml:surfaceMember xlink:href="#poly-7cbff5f0-b93a-40c1-b5f6-b959e7a6d867"/>
							<gml:surfaceMember xlink:href="#poly-8cf60638-178a-41a0-ba2a-42f56a26fde5"/>
							<gml:surfaceMember xlink:href="#poly-7888a274-5ac3-4211-b30b-6375c96ed0df"/>
							<gml:surfaceMember xlink:href="#poly-dbc88433-10a8-414f-a032-b13f18663a3e"/>
							<gml:surfaceMember xlink:href="#poly-d9cc5c37-f70a-45b1-865e-ae82b17329a0"/>
							<gml:surfaceMember xlink:href="#poly-cdd04bd2-cfb7-4328-87e8-ff9e6036fac6"/>
							<gml:surfaceMember xlink:href="#poly-438910ab-5590-44d6-95ec-2c0d4107c92e"/>
							<gml:surfaceMember xlink:href="#poly-6f64b5ce-93ab-4ec0-8b5a-78651abd16ae"/>
							<gml:surfaceMember xlink:href="#poly-4f0cbbd2-bdfb-436d-8421-b5bc706c3ca0"/>
							<gml:surfaceMember xlink:href="#poly-afa1b3c3-e718-4c62-bfbd-495d6f0e195e"/>
							<gml:surfaceMember xlink:href="#poly-1065354d-96fb-42cf-8dde-f034a31bf2c5"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_a36fff76-ebcf-42e8-88d7-45d85a68ec9d_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8bb51b00-6c26-45a3-b427-9a18f35348a0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8bb51b00-6c26-45a3-b427-9a18f35348a0_0">
											<gml:posList>35.66712359071573 139.73816035885628 24.305 35.66712192482622 139.73816244849164 24.62 35.66712359071573 139.73816035885628 24.62 35.66712359071573 139.73816035885628 24.305</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab735d51-8347-4553-8b5a-763df995e48f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ab735d51-8347-4553-8b5a-763df995e48f_0">
											<gml:posList>35.667169298783065 139.7382280706925 24.62 35.667174485577384 139.73822159169163 23.847 35.667174485577384 139.73822159169163 24.62 35.667169298783065 139.7382280706925 24.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-552befb7-d652-45d1-b7eb-1b5bf8846252">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-552befb7-d652-45d1-b7eb-1b5bf8846252_0">
											<gml:posList>35.667019664905446 139.73811798902577 24.591 35.667032603297024 139.73813404529875 26.948 35.667019664905446 139.73811798902577 26.948 35.667019664905446 139.73811798902577 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ccca3af3-c6ae-4756-875f-ea6a9abd0ebe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ccca3af3-c6ae-4756-875f-ea6a9abd0ebe_0">
											<gml:posList>35.667019664905446 139.73811798902577 24.591 35.667032603297024 139.73813404529875 24.591 35.667032603297024 139.73813404529875 26.948 35.667019664905446 139.73811798902577 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e28a5eaa-812a-4d14-af1c-d2a0f411b0ec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e28a5eaa-812a-4d14-af1c-d2a0f411b0ec_0">
											<gml:posList>35.66703564899378 139.7380986509446 24.591 35.667019664905446 139.73811798902577 26.948 35.66703564899378 139.7380986509446 26.948 35.66703564899378 139.7380986509446 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-06b85528-7b3d-47af-9f93-a77c33a3f456">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-06b85528-7b3d-47af-9f93-a77c33a3f456_0">
											<gml:posList>35.66703564899378 139.7380986509446 24.591 35.667019664905446 139.73811798902577 24.591 35.667019664905446 139.73811798902577 26.948 35.66703564899378 139.7380986509446 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f13e350-3091-4b80-ba7f-75127039cc00">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9f13e350-3091-4b80-ba7f-75127039cc00_0">
											<gml:posList>35.66703564899378 139.7380986509446 26.948 35.667032603297024 139.73813404529875 26.948 35.667048587387896 139.73811470721765 26.948 35.66703564899378 139.7380986509446 26.948</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e6b0a883-5246-4847-9c57-e2674845c97b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e6b0a883-5246-4847-9c57-e2674845c97b_0">
											<gml:posList>35.66703564899378 139.7380986509446 26.948 35.667019664905446 139.73811798902577 26.948 35.667032603297024 139.73813404529875 26.948 35.66703564899378 139.7380986509446 26.948</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-30594274-4509-4768-85cf-6aadc2a3bc4b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-30594274-4509-4768-85cf-6aadc2a3bc4b_0">
											<gml:posList>35.66705399045326 139.7381081616876 24.591 35.667048587387896 139.73811470721765 24.591 35.667048587387896 139.73811470721765 26.948 35.66705399045326 139.7381081616876 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4209385-07a5-401d-8afa-74299101f7cd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a4209385-07a5-401d-8afa-74299101f7cd_0">
											<gml:posList>35.66705399045326 139.7381081616876 26.974 35.66705399045326 139.7381081616876 24.591 35.667048587387896 139.73811470721765 26.948 35.66705399045326 139.7381081616876 26.974</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a3e7cd65-9268-4ae8-b9ad-018cdac41606">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a3e7cd65-9268-4ae8-b9ad-018cdac41606_0">
											<gml:posList>35.66705399045326 139.7381081616876 26.974 35.667048587387896 139.73811470721765 26.948 35.667028523973244 139.7381389765674 26.974 35.66705399045326 139.7381081616876 26.974</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f0262241-b04f-45a3-a441-93128434f836">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f0262241-b04f-45a3-a441-93128434f836_0">
											<gml:posList>35.667032603297024 139.73813404529875 26.948 35.667032603297024 139.73813404529875 24.591 35.667028523973244 139.7381389765674 24.591 35.667032603297024 139.73813404529875 26.948</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48d0e08a-cc74-4830-bc12-519fdc40b3fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-48d0e08a-cc74-4830-bc12-519fdc40b3fd_0">
											<gml:posList>35.667028523973244 139.7381389765674 26.974 35.667032603297024 139.73813404529875 26.948 35.667028523973244 139.7381389765674 24.591 35.667028523973244 139.7381389765674 26.974</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a08f8dd-bd7d-425d-9d50-e8fb36acf189">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9a08f8dd-bd7d-425d-9d50-e8fb36acf189_0">
											<gml:posList>35.667028523973244 139.7381389765674 26.974 35.667048587387896 139.73811470721765 26.948 35.667032603297024 139.73813404529875 26.948 35.667028523973244 139.7381389765674 26.974</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca994354-4b1a-40d7-a154-7bcf7810a8e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ca994354-4b1a-40d7-a154-7bcf7810a8e4_0">
											<gml:posList>35.667048587387896 139.73811470721765 24.591 35.66703564899378 139.7380986509446 26.948 35.667048587387896 139.73811470721765 26.948 35.667048587387896 139.73811470721765 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-855c829f-54df-43e6-960c-6548bf4c2ad8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-855c829f-54df-43e6-960c-6548bf4c2ad8_0">
											<gml:posList>35.667048587387896 139.73811470721765 24.591 35.66703564899378 139.7380986509446 24.591 35.66703564899378 139.7380986509446 26.948 35.667048587387896 139.73811470721765 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da1f2c95-5ff7-4e34-bc1f-b133529562b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da1f2c95-5ff7-4e34-bc1f-b133529562b8_0">
											<gml:posList>35.667028523973244 139.7381389765674 24.591 35.667056349634045 139.73817351689235 26.974 35.667028523973244 139.7381389765674 26.974 35.667028523973244 139.7381389765674 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-320e86b4-1a3d-435a-9a21-9feb7b546197">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-320e86b4-1a3d-435a-9a21-9feb7b546197_0">
											<gml:posList>35.667028523973244 139.7381389765674 24.591 35.667056349634045 139.73817351689235 24.591 35.667056349634045 139.73817351689235 26.974 35.667028523973244 139.7381389765674 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff2185ce-796a-433c-b8a1-4ed8c72a63a2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ff2185ce-796a-433c-b8a1-4ed8c72a63a2_0">
											<gml:posList>35.667056349634045 139.73817351689235 26.974 35.66708182513652 139.73814270200205 26.974 35.66705399045326 139.7381081616876 26.974 35.667056349634045 139.73817351689235 26.974</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4af5ee93-b714-4651-912c-abf72f780078">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4af5ee93-b714-4651-912c-abf72f780078_0">
											<gml:posList>35.667028523973244 139.7381389765674 26.974 35.667056349634045 139.73817351689235 26.974 35.66705399045326 139.7381081616876 26.974 35.667028523973244 139.7381389765674 26.974</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f4de954-8c1f-4e2c-840e-c78602a24e61">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f4de954-8c1f-4e2c-840e-c78602a24e61_0">
											<gml:posList>35.667058870385304 139.73807839850286 24.038 35.66706650692182 139.7380694091938 24.336 35.66706650692182 139.7380694091938 22.777 35.667058870385304 139.73807839850286 24.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d8fe728-9709-4d09-a9f8-b1ea3aabe960">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8d8fe728-9709-4d09-a9f8-b1ea3aabe960_0">
											<gml:posList>35.667058870385304 139.73807839850286 24.038 35.667058870385304 139.73807839850286 24.336 35.66706650692182 139.7380694091938 24.336 35.667058870385304 139.73807839850286 24.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da5fd895-4098-4460-a357-a5c575f60791">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da5fd895-4098-4460-a357-a5c575f60791_0">
											<gml:posList>35.66705399045326 139.7381081616876 26.974 35.66708182513652 139.73814270200205 24.591 35.66705399045326 139.7381081616876 24.591 35.66705399045326 139.7381081616876 26.974</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-058b4fb8-d924-410e-9437-92b6c0f779bc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-058b4fb8-d924-410e-9437-92b6c0f779bc_0">
											<gml:posList>35.66705399045326 139.7381081616876 26.974 35.66708182513652 139.73814270200205 26.974 35.66708182513652 139.73814270200205 24.591 35.66705399045326 139.7381081616876 26.974</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1a471f5-ebe4-4fb3-96fa-bcca083565d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d1a471f5-ebe4-4fb3-96fa-bcca083565d6_0">
											<gml:posList>35.66708182513652 139.73814270200205 24.591 35.667056349634045 139.73817351689235 26.974 35.667056349634045 139.73817351689235 24.591 35.66708182513652 139.73814270200205 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-defd1858-65f9-4423-be08-2331f32f7703">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-defd1858-65f9-4423-be08-2331f32f7703_0">
											<gml:posList>35.66708182513652 139.73814270200205 24.591 35.66708182513652 139.73814270200205 26.974 35.667056349634045 139.73817351689235 26.974 35.66708182513652 139.73814270200205 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d3852c2-7f2e-4bf7-99cc-47089c0666c4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d3852c2-7f2e-4bf7-99cc-47089c0666c4_0">
											<gml:posList>35.667058870385304 139.73807839850286 24.038 35.66708447653778 139.73811022418732 24.041 35.667058870385304 139.73807839850286 24.336 35.667058870385304 139.73807839850286 24.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa8746b4-fca3-4102-9c32-2c8ead67d2b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aa8746b4-fca3-4102-9c32-2c8ead67d2b4_0">
											<gml:posList>35.667058870385304 139.73807839850286 24.336 35.66708447653778 139.73811022418732 24.041 35.66712170379118 139.7381564950622 24.336 35.667058870385304 139.73807839850286 24.336</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4de6c9b-a79b-493a-8185-df2ca6986fb4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b4de6c9b-a79b-493a-8185-df2ca6986fb4_0">
											<gml:posList>35.66708447653778 139.73811022418732 24.041 35.66712170379118 139.7381564950622 24.181 35.66712170379118 139.7381564950622 24.336 35.66708447653778 139.73811022418732 24.041</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fbcb1e32-ab5f-4417-9c6b-b624ccbe4b9f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fbcb1e32-ab5f-4417-9c6b-b624ccbe4b9f_0">
											<gml:posList>35.66712170379118 139.7381564950622 24.336 35.66706650692182 139.7380694091938 24.336 35.667058870385304 139.73807839850286 24.336 35.66712170379118 139.7381564950622 24.336</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-caf90327-c390-4cce-8a08-2d09dbe7c1ff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-caf90327-c390-4cce-8a08-2d09dbe7c1ff_0">
											<gml:posList>35.66712170379118 139.7381564950622 24.336 35.667129376344704 139.7381474504817 24.336 35.66706650692182 139.7380694091938 24.336 35.66712170379118 139.7381564950622 24.336</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-39f90921-acbb-4316-a0a5-5d415741134c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-39f90921-acbb-4316-a0a5-5d415741134c_0">
											<gml:posList>35.66706650692182 139.7380694091938 22.777 35.667129376344704 139.7381474504817 24.336 35.667129376344704 139.7381474504817 22.777 35.66706650692182 139.7380694091938 22.777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b56c628f-e4ee-4762-9546-bc17e34802ec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b56c628f-e4ee-4762-9546-bc17e34802ec_0">
											<gml:posList>35.66706650692182 139.7380694091938 22.777 35.66706650692182 139.7380694091938 24.336 35.667129376344704 139.7381474504817 24.336 35.66706650692182 139.7380694091938 22.777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c80699e3-d332-4a4e-835d-0c51a5912502">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c80699e3-d332-4a4e-835d-0c51a5912502_0">
											<gml:posList>35.66711869214569 139.73816656136967 24.62 35.66712367191785 139.73816045817216 24.305 35.667123689962764 139.73816048024239 23.919 35.66711869214569 139.73816656136967 24.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a0764015-7b22-4b84-9b3a-0198b6bc7288">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a0764015-7b22-4b84-9b3a-0198b6bc7288_0">
											<gml:posList>35.66711869214569 139.73816656136967 24.62 35.667121978952224 139.73816250365644 24.62 35.66712367191785 139.73816045817216 24.305 35.66711869214569 139.73816656136967 24.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e21925dd-4eb5-431c-9fdd-d623ef4f6680">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e21925dd-4eb5-431c-9fdd-d623ef4f6680_0">
											<gml:posList>35.667129376344704 139.7381474504817 22.777 35.667129376344704 139.7381474504817 24.336 35.667129034146136 139.73814785958294 22.835 35.667129376344704 139.7381474504817 22.777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-964d6eed-0891-4114-ab36-e842f89d3488">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-964d6eed-0891-4114-ab36-e842f89d3488_0">
											<gml:posList>35.667129034146136 139.73814785958294 22.835 35.667129376344704 139.7381474504817 24.336 35.66712170379118 139.7381564950622 24.181 35.667129034146136 139.73814785958294 22.835</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-83e5fb6b-8eed-4585-9579-9700dca0e2b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-83e5fb6b-8eed-4585-9579-9700dca0e2b2_0">
											<gml:posList>35.667129376344704 139.7381474504817 24.336 35.66712170379118 139.7381564950622 24.336 35.66712170379118 139.7381564950622 24.181 35.667129376344704 139.7381474504817 24.336</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf982b1d-9f10-4a7c-9066-5bde0d423377">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cf982b1d-9f10-4a7c-9066-5bde0d423377_0">
											<gml:posList>35.66712359071573 139.73816035885628 24.305 35.66712359071573 139.73816035885628 24.62 35.66712367191785 139.73816045817216 24.305 35.66712359071573 139.73816035885628 24.305</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d71dff5a-6449-470b-87c0-17a8a9b59a89">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d71dff5a-6449-470b-87c0-17a8a9b59a89_0">
											<gml:posList>35.667123689962764 139.73816048024239 23.919 35.66712367191785 139.73816045817216 24.305 35.66715430266512 139.73819730379265 23.852 35.667123689962764 139.73816048024239 23.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e961f886-4eef-42df-abd4-c298dce7a6d0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e961f886-4eef-42df-abd4-c298dce7a6d0_0">
											<gml:posList>35.66715430266512 139.73819730379265 23.852 35.667174485577384 139.73822159169163 24.62 35.667174485577384 139.73822159169163 23.847 35.66715430266512 139.73819730379265 23.852</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-baafd40e-53f3-4f10-b81d-f2c8257a9447">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-baafd40e-53f3-4f10-b81d-f2c8257a9447_0">
											<gml:posList>35.66715430266512 139.73819730379265 23.852 35.66712359071573 139.73816035885628 24.62 35.667174485577384 139.73822159169163 24.62 35.66715430266512 139.73819730379265 23.852</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f190c54-03f2-441c-97a8-80180d270691">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f190c54-03f2-441c-97a8-80180d270691_0">
											<gml:posList>35.66712367191785 139.73816045817216 24.305 35.66712359071573 139.73816035885628 24.62 35.66715430266512 139.73819730379265 23.852 35.66712367191785 139.73816045817216 24.305</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-90079e2a-21cc-4001-aec7-44ac62f22747">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-90079e2a-21cc-4001-aec7-44ac62f22747_0">
											<gml:posList>35.667174485577384 139.73822159169163 24.62 35.66712359071573 139.73816035885628 24.62 35.667130466625174 139.73818118309586 24.62 35.667174485577384 139.73822159169163 24.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-10297082-dced-41f1-9bfd-290b05dc58fb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-10297082-dced-41f1-9bfd-290b05dc58fb_0">
											<gml:posList>35.667169298783065 139.7382280706925 24.62 35.667174485577384 139.73822159169163 24.62 35.667130466625174 139.73818118309586 24.62 35.667169298783065 139.7382280706925 24.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-867e52b6-7abc-40f3-b83c-f4d497782f83">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-867e52b6-7abc-40f3-b83c-f4d497782f83_0">
											<gml:posList>35.66712359071573 139.73816035885628 24.62 35.667121978952224 139.73816250365644 24.62 35.667130466625174 139.73818118309586 24.62 35.66712359071573 139.73816035885628 24.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d20926e5-31c3-4329-9959-2a90b01cd891">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d20926e5-31c3-4329-9959-2a90b01cd891_0">
											<gml:posList>35.667121978952224 139.73816250365644 24.62 35.66711869214569 139.73816656136967 24.62 35.667130466625174 139.73818118309586 24.62 35.667121978952224 139.73816250365644 24.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ffb715e9-eb75-44fe-aa1d-c51cdb12cc9a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66712170379118 139.7381564950622 24.181 35.66708447653778 139.73811022418732 24.041 35.667129034146136 139.73814785958294 22.835 35.66712170379118 139.7381564950622 24.181</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78f2c4c7-aef8-4fb3-819c-94cf7248f241">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667121978952224 139.73816250365644 24.62 35.66712359071573 139.73816035885628 24.305 35.66712367191785 139.73816045817216 24.305 35.667121978952224 139.73816250365644 24.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-90596c31-2b18-48c2-abbc-a1c166ad891d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667028523973244 139.7381389765674 24.591 35.667032603297024 139.73813404529875 24.591 35.667056349634045 139.73817351689235 24.591 35.667028523973244 139.7381389765674 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33cfd772-6aac-41e7-9ec5-9c99ad557ba9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66708182513652 139.73814270200205 24.591 35.667056349634045 139.73817351689235 24.591 35.667048587387896 139.73811470721765 24.591 35.66708182513652 139.73814270200205 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dfbbe944-87df-48fb-a241-a438125725c5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66708182513652 139.73814270200205 24.591 35.667048587387896 139.73811470721765 24.591 35.66705399045326 139.7381081616876 24.591 35.66708182513652 139.73814270200205 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b5602fdf-9eae-4a32-ab29-1dbb536883c4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667032603297024 139.73813404529875 24.591 35.667019664905446 139.73811798902577 24.591 35.66703564899378 139.7380986509446 24.591 35.667032603297024 139.73813404529875 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e6dd14fb-d211-47b9-b1c3-6a8b8c39a38f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667048587387896 139.73811470721765 24.591 35.667032603297024 139.73813404529875 24.591 35.66703564899378 139.7380986509446 24.591 35.667048587387896 139.73811470721765 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5644961f-9c48-41e9-a2e9-f5cae2039266">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667056349634045 139.73817351689235 24.591 35.667032603297024 139.73813404529875 24.591 35.667048587387896 139.73811470721765 24.591 35.667056349634045 139.73817351689235 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e6b7a5a9-560d-471c-8961-2fac5c1e46d4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667058870385304 139.73807839850286 24.038 35.66706650692182 139.7380694091938 22.777 35.66708447653778 139.73811022418732 24.041 35.667058870385304 139.73807839850286 24.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-36eb447f-533b-48fd-83b4-8ce23b2f553f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66708447653778 139.73811022418732 24.041 35.667129376344704 139.7381474504817 22.777 35.667129034146136 139.73814785958294 22.835 35.66708447653778 139.73811022418732 24.041</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c404be77-1401-4364-be8c-ec3ea942734b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66708447653778 139.73811022418732 24.041 35.66706650692182 139.7380694091938 22.777 35.667129376344704 139.7381474504817 22.777 35.66708447653778 139.73811022418732 24.041</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-322e60bf-2552-40b6-820c-bc131e93329f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667130466625174 139.73818118309586 24.62 35.667123689962764 139.73816048024239 23.919 35.66715430266512 139.73819730379265 23.852 35.667130466625174 139.73818118309586 24.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-acc97b25-79e9-4d7c-94c0-b1103266097e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667130466625174 139.73818118309586 24.62 35.66711869214569 139.73816656136967 24.62 35.667123689962764 139.73816048024239 23.919 35.667130466625174 139.73818118309586 24.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ecfad34b-8d20-4581-86c6-4a7429555986">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667169298783065 139.7382280706925 24.62 35.66715430266512 139.73819730379265 23.852 35.667174485577384 139.73822159169163 23.847 35.667169298783065 139.7382280706925 24.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f587a114-59ec-4fdd-b08b-43a891c06595">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667169298783065 139.7382280706925 24.62 35.667130466625174 139.73818118309586 24.62 35.66715430266512 139.73819730379265 23.852 35.667169298783065 139.7382280706925 24.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_a36fff76-ebcf-42e8-88d7-45d85a68ec9d_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4efcb80f-f6b9-40a7-8e1b-051930f8dfa4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667059030775725 139.73806465733506 23.086 35.66706456162581 139.7380715212531 23.086 35.66706079740933 139.73807597718312 23.709 35.66705527557323 139.73806911325437 23.709 35.667059030775725 139.73806465733506 23.086</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-09713696-c339-44fc-b6cc-3aeb0f2dd635">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66707737907506 139.7381170036936 24.591 35.66707190417016 139.73812389173017 24.591 35.66706543520545 139.73811615630342 24.591 35.66707091011865 139.73810927931265 24.591 35.66707737907506 139.7381170036936 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58f6f0af-3582-4f43-b475-d8c0c6f74e6d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667077946372146 139.73811628504268 25.113 35.66707737907506 139.7381170036936 25.113 35.66707091011865 139.73810927931265 25.113 35.66707147741569 139.73810856066174 25.113 35.667077946372146 139.73811628504268 25.113</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ecc2f818-7945-4cd7-988f-b325fe222330">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ecc2f818-7945-4cd7-988f-b325fe222330_0">
											<gml:posList>35.667059030775725 139.73806465733506 23.086 35.66705527557323 139.73806911325437 23.709 35.667059030775725 139.73806465733506 23.709 35.667059030775725 139.73806465733506 23.086</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b95a2d08-1e10-4c3c-adf5-c35d76563570">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b95a2d08-1e10-4c3c-adf5-c35d76563570_0">
											<gml:posList>35.66706456162581 139.7380715212531 23.086 35.667059030775725 139.73806465733506 23.086 35.667059030775725 139.73806465733506 23.709 35.66706456162581 139.7380715212531 23.709 35.66706456162581 139.7380715212531 23.086</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a762262-366a-4842-b182-d04eea2d56ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1a762262-366a-4842-b182-d04eea2d56ce_0">
											<gml:posList>35.66706079740933 139.73807597718312 23.709 35.66706456162581 139.7380715212531 23.709 35.667059030775725 139.73806465733506 23.709 35.66705527557323 139.73806911325437 23.709 35.66706079740933 139.73807597718312 23.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8df925de-2e81-457b-a5dd-12f24d937ffc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8df925de-2e81-457b-a5dd-12f24d937ffc_0">
											<gml:posList>35.66706079740933 139.73807597718312 23.709 35.66706456162581 139.7380715212531 23.086 35.66706456162581 139.7380715212531 23.709 35.66706079740933 139.73807597718312 23.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-176ff493-eae7-4ce7-a9ae-c0fd0fc539cd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-176ff493-eae7-4ce7-a9ae-c0fd0fc539cd_0">
											<gml:posList>35.66706543520545 139.73811615630342 24.591 35.66706543520545 139.73811615630342 25.723 35.66707147741569 139.73810856066174 25.723 35.66707147741569 139.73810856066174 25.113 35.66707091011865 139.73810927931265 25.113 35.66707091011865 139.73810927931265 24.591 35.66706543520545 139.73811615630342 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a317094-b7d2-4e94-856a-547cc5664522">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a317094-b7d2-4e94-856a-547cc5664522_0">
											<gml:posList>35.66707147741569 139.73810856066174 25.113 35.66707147741569 139.73810856066174 25.723 35.667077946372146 139.73811628504268 25.723 35.667077946372146 139.73811628504268 25.113 35.66707147741569 139.73810856066174 25.113</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40190a6c-b917-42d1-bf35-49c034bacabe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40190a6c-b917-42d1-bf35-49c034bacabe_0">
											<gml:posList>35.66707091011865 139.73810927931265 25.113 35.66707737907506 139.7381170036936 25.113 35.66707737907506 139.7381170036936 24.591 35.66707091011865 139.73810927931265 24.591 35.66707091011865 139.73810927931265 25.113</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35c74a33-c261-4e93-b4bb-2124cdd023a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-35c74a33-c261-4e93-b4bb-2124cdd023a6_0">
											<gml:posList>35.66706543520545 139.73811615630342 25.723 35.66707190417016 139.73812389173017 25.723 35.667077946372146 139.73811628504268 25.723 35.66707147741569 139.73810856066174 25.723 35.66706543520545 139.73811615630342 25.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a967498-178e-49ba-8b2f-0b9248c2f861">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0a967498-178e-49ba-8b2f-0b9248c2f861_0">
											<gml:posList>35.66706543520545 139.73811615630342 24.591 35.66707190417016 139.73812389173017 24.591 35.66707190417016 139.73812389173017 25.723 35.66706543520545 139.73811615630342 25.723 35.66706543520545 139.73811615630342 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb68f422-2b5d-46ce-b6d6-2a957c5802dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fb68f422-2b5d-46ce-b6d6-2a957c5802dc_0">
											<gml:posList>35.667077946372146 139.73811628504268 25.723 35.66707190417016 139.73812389173017 25.723 35.66707190417016 139.73812389173017 24.591 35.66707737907506 139.7381170036936 24.591 35.66707737907506 139.7381170036936 25.113 35.667077946372146 139.73811628504268 25.113 35.667077946372146 139.73811628504268 25.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_a36fff76-ebcf-42e8-88d7-45d85a68ec9d_BuildingInstallation_1061">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd2ce862-1e97-427a-904a-bc2b0223307b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66703604851369 139.73809094050276 24.591 35.66701358074444 139.7381181287997 24.591 35.667029460510186 139.73813784878425 24.591 35.667028523973244 139.7381389765674 24.591 35.6670118502311 139.73811828549563 24.591 35.66703620907462 139.73808880847292 24.591 35.66705288283049 139.73810951059065 24.591 35.66705193728882 139.73811064943095 24.591 35.66703604851369 139.73809094050276 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-feb8d36c-4847-4c10-8199-b6c725ec62b8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66705812364486 139.7381713719016 24.591 35.667132196545495 139.73826015859723 24.591 35.66713716722145 139.7382539449572 24.591 35.66714327541887 139.7382614157302 24.591 35.6671417896539 139.7382633173716 24.591 35.66713695383112 139.738257667649 24.591 35.6671322714547 139.738263704214 24.591 35.667056349634045 139.73817351689235 24.591 35.66705812364486 139.7381713719016 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-51072ed8-4491-42d3-94b4-dbb62ca62979">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66715026398142 139.73823086576795 24.591 35.66707968191268 139.73814528926454 24.591 35.66708120377438 139.73814344280856 24.591 35.667153355384436 139.73823047549803 24.591 35.66714425191875 139.73824240472752 24.591 35.66714265517195 139.73824073870324 24.591 35.66715026398142 139.73823086576795 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa979192-efd0-4d71-b772-4c5f0fe2bfb7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fa979192-efd0-4d71-b772-4c5f0fe2bfb7_0">
											<gml:posList>35.66715026398142 139.73823086576795 24.591 35.66715026398142 139.73823086576795 26.061 35.66707968191268 139.73814528926454 26.061 35.66707968191268 139.73814528926454 24.591 35.66715026398142 139.73823086576795 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7fde163a-f2a0-4e0d-833e-f9045b69051d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7fde163a-f2a0-4e0d-833e-f9045b69051d_0">
											<gml:posList>35.66705288283049 139.73810951059065 24.591 35.66703620907462 139.73808880847292 24.591 35.66703620907462 139.73808880847292 26.061 35.66705288283049 139.73810951059065 26.061 35.66705288283049 139.73810951059065 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eb007942-cfa8-4b48-a6c7-7b189f87d924">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eb007942-cfa8-4b48-a6c7-7b189f87d924_0">
											<gml:posList>35.66703604851369 139.73809094050276 24.591 35.66705193728882 139.73811064943095 24.591 35.66705193728882 139.73811064943095 26.061 35.66703604851369 139.73809094050276 26.061 35.66703604851369 139.73809094050276 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ed54f49-ada1-4244-809f-1156e8321359">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0ed54f49-ada1-4244-809f-1156e8321359_0">
											<gml:posList>35.66703620907462 139.73808880847292 24.591 35.6670118502311 139.73811828549563 24.591 35.6670118502311 139.73811828549563 26.061 35.66703620907462 139.73808880847292 26.061 35.66703620907462 139.73808880847292 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d22a546-d2e8-4062-b0fe-644f914525ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5d22a546-d2e8-4062-b0fe-644f914525ce_0">
											<gml:posList>35.66701358074444 139.7381181287997 24.591 35.66703604851369 139.73809094050276 24.591 35.66703604851369 139.73809094050276 26.061 35.66701358074444 139.7381181287997 26.061 35.66701358074444 139.7381181287997 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f6c7e1d0-41d8-4aa7-afbd-31582beaa36f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f6c7e1d0-41d8-4aa7-afbd-31582beaa36f_0">
											<gml:posList>35.66705193728882 139.73811064943095 24.591 35.66705288283049 139.73810951059065 24.591 35.66705288283049 139.73810951059065 26.061 35.66705193728882 139.73811064943095 26.061 35.66705193728882 139.73811064943095 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c58db184-e199-4331-bb84-010d79c0676a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c58db184-e199-4331-bb84-010d79c0676a_0">
											<gml:posList>35.66705288283049 139.73810951059065 26.061 35.66703620907462 139.73808880847292 26.061 35.6670118502311 139.73811828549563 26.061 35.667028523973244 139.7381389765674 26.061 35.667029460510186 139.73813784878425 26.061 35.66701358074444 139.7381181287997 26.061 35.66703604851369 139.73809094050276 26.061 35.66705193728882 139.73811064943095 26.061 35.66705288283049 139.73810951059065 26.061</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a0eb9847-3cb0-4717-89e6-73f978419f89">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a0eb9847-3cb0-4717-89e6-73f978419f89_0">
											<gml:posList>35.667029460510186 139.73813784878425 24.591 35.66701358074444 139.7381181287997 24.591 35.66701358074444 139.7381181287997 26.061 35.667029460510186 139.73813784878425 26.061 35.667029460510186 139.73813784878425 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33259f5e-e692-4b3b-925d-f73a5e647329">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-33259f5e-e692-4b3b-925d-f73a5e647329_0">
											<gml:posList>35.6670118502311 139.73811828549563 24.591 35.667028523973244 139.7381389765674 24.591 35.667028523973244 139.7381389765674 26.061 35.6670118502311 139.73811828549563 26.061 35.6670118502311 139.73811828549563 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4ed7333b-0afb-4523-bbe5-cccb26256c1b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4ed7333b-0afb-4523-bbe5-cccb26256c1b_0">
											<gml:posList>35.667028523973244 139.7381389765674 24.591 35.667029460510186 139.73813784878425 24.591 35.667029460510186 139.73813784878425 26.061 35.667028523973244 139.7381389765674 26.061 35.667028523973244 139.7381389765674 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b53fc99-55ae-4a9f-9f89-7d6f894a097b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4b53fc99-55ae-4a9f-9f89-7d6f894a097b_0">
											<gml:posList>35.66708120377438 139.73814344280856 24.591 35.66707968191268 139.73814528926454 24.591 35.66707968191268 139.73814528926454 26.061 35.66708120377438 139.73814344280856 26.061 35.66708120377438 139.73814344280856 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2182909b-f053-412d-96df-d88357b20152">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2182909b-f053-412d-96df-d88357b20152_0">
											<gml:posList>35.66705812364486 139.7381713719016 24.591 35.667056349634045 139.73817351689235 24.591 35.667056349634045 139.73817351689235 26.061 35.66705812364486 139.7381713719016 26.061 35.66705812364486 139.7381713719016 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad620f7d-ed6d-4881-82da-5ac30080ecac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ad620f7d-ed6d-4881-82da-5ac30080ecac_0">
											<gml:posList>35.66708120377438 139.73814344280856 24.591 35.66708120377438 139.73814344280856 26.061 35.667153355384436 139.73823047549803 26.061 35.667153355384436 139.73823047549803 24.591 35.66708120377438 139.73814344280856 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11d69738-739d-4f9a-a9cc-ed027942b1db">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-11d69738-739d-4f9a-a9cc-ed027942b1db_0">
											<gml:posList>35.66714425191875 139.73824240472752 26.061 35.667153355384436 139.73823047549803 26.061 35.66708120377438 139.73814344280856 26.061 35.66707968191268 139.73814528926454 26.061 35.66715026398142 139.73823086576795 26.061 35.66714265517195 139.73824073870324 26.061 35.66714425191875 139.73824240472752 26.061</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-66dba44a-5861-411b-84d6-e5466dece8da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-66dba44a-5861-411b-84d6-e5466dece8da_0">
											<gml:posList>35.66705812364486 139.7381713719016 24.591 35.66705812364486 139.7381713719016 26.061 35.667132196545495 139.73826015859723 26.061 35.667132196545495 139.73826015859723 24.591 35.66705812364486 139.7381713719016 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18fc9f82-050c-4815-b421-e8421d1eb1f1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-18fc9f82-050c-4815-b421-e8421d1eb1f1_0">
											<gml:posList>35.6671322714547 139.738263704214 26.061 35.66713695383112 139.738257667649 26.061 35.6671417896539 139.7382633173716 26.061 35.66714327541887 139.7382614157302 26.061 35.66713716722145 139.7382539449572 26.061 35.667132196545495 139.73826015859723 26.061 35.66705812364486 139.7381713719016 26.061 35.667056349634045 139.73817351689235 26.061 35.6671322714547 139.738263704214 26.061</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38a6b3e2-9ecb-441c-888d-9e1d5ae90237">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-38a6b3e2-9ecb-441c-888d-9e1d5ae90237_0">
											<gml:posList>35.667056349634045 139.73817351689235 24.591 35.6671322714547 139.738263704214 24.591 35.6671322714547 139.738263704214 26.061 35.667056349634045 139.73817351689235 26.061 35.667056349634045 139.73817351689235 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b9ba0d4-ae0e-4f5d-8963-ee1157bcefab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0b9ba0d4-ae0e-4f5d-8963-ee1157bcefab_0">
											<gml:posList>35.66715026398142 139.73823086576795 24.591 35.66714265517195 139.73824073870324 24.591 35.66714265517195 139.73824073870324 26.061 35.66715026398142 139.73823086576795 26.061 35.66715026398142 139.73823086576795 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e533cc8-2045-4ec9-97e6-553345b7b173">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9e533cc8-2045-4ec9-97e6-553345b7b173_0">
											<gml:posList>35.66714425191875 139.73824240472752 24.591 35.667153355384436 139.73823047549803 24.591 35.667153355384436 139.73823047549803 26.061 35.66714425191875 139.73824240472752 26.061 35.66714425191875 139.73824240472752 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8c96427-bc61-4327-b1c1-3455cc4002dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d8c96427-bc61-4327-b1c1-3455cc4002dd_0">
											<gml:posList>35.66714265517195 139.73824073870324 24.591 35.66714425191875 139.73824240472752 24.591 35.66714425191875 139.73824240472752 26.061 35.66714265517195 139.73824073870324 26.061 35.66714265517195 139.73824073870324 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0253d268-d7fb-445e-81c1-18ab63d930a7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0253d268-d7fb-445e-81c1-18ab63d930a7_0">
											<gml:posList>35.667132196545495 139.73826015859723 24.591 35.667132196545495 139.73826015859723 26.061 35.66713716722145 139.7382539449572 26.061 35.66713716722145 139.7382539449572 24.591 35.667132196545495 139.73826015859723 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa9d35f8-e650-444b-b05c-d029e66f4aa3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aa9d35f8-e650-444b-b05c-d029e66f4aa3_0">
											<gml:posList>35.66714327541887 139.7382614157302 24.591 35.66713716722145 139.7382539449572 24.591 35.66713716722145 139.7382539449572 26.061 35.66714327541887 139.7382614157302 26.061 35.66714327541887 139.7382614157302 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-39d86a7a-a546-472e-af3e-dc34cf5da596">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-39d86a7a-a546-472e-af3e-dc34cf5da596_0">
											<gml:posList>35.66713695383112 139.738257667649 24.591 35.6671417896539 139.7382633173716 24.591 35.6671417896539 139.7382633173716 26.061 35.66713695383112 139.738257667649 26.061 35.66713695383112 139.738257667649 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1a9b0f1-01d6-44fe-aa03-b238c002be6e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c1a9b0f1-01d6-44fe-aa03-b238c002be6e_0">
											<gml:posList>35.6671322714547 139.738263704214 24.591 35.66713695383112 139.738257667649 24.591 35.66713695383112 139.738257667649 26.061 35.6671322714547 139.738263704214 26.061 35.6671322714547 139.738263704214 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f9801cf-a4d1-4037-819f-8836aea4820a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f9801cf-a4d1-4037-819f-8836aea4820a_0">
											<gml:posList>35.6671417896539 139.7382633173716 24.591 35.66714327541887 139.7382614157302 24.591 35.66714327541887 139.7382614157302 26.061 35.6671417896539 139.7382633173716 26.061 35.6671417896539 139.7382633173716 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-4f779726-efbe-4922-b3f5-86f53db8ce4e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f779726-efbe-4922-b3f5-86f53db8ce4e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f779726-efbe-4922-b3f5-86f53db8ce4e">
											<gml:posList>35.66700432004818 139.7381135889287 13.625 35.66703989028584 139.73807057853207 13.625 35.667044852729056 139.73807675828454 13.625 35.66705899082317 139.73805973095497 13.625 35.66719730711951 139.73823143958617 13.625 35.66716831056758 139.7382664892152 13.625 35.667159378257004 139.7382554539895 13.625 35.667138756530015 139.73828044197734 13.625 35.66700432004818 139.7381135889287 13.625</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0e1e57b2-740c-48d8-95c8-9e7268310859">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e1e57b2-740c-48d8-95c8-9e7268310859">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e1e57b2-740c-48d8-95c8-9e7268310859">
											<gml:posList>35.66700549185017 139.73811360962884 25.113 35.66700432004818 139.7381135889287 25.113 35.667138756530015 139.73828044197734 25.113 35.66713876441897 139.73827901705815 25.113 35.66700549185017 139.73811360962884 25.113</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0133b2bd-8098-4078-b661-239c8512b24c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0133b2bd-8098-4078-b661-239c8512b24c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0133b2bd-8098-4078-b661-239c8512b24c">
											<gml:posList>35.66703989142182 139.7380720144846 25.113 35.6670442854322 139.73807747693542 25.113 35.667044852729056 139.73807675828454 25.113 35.66703989028584 139.73807057853207 25.113 35.66703989142182 139.7380720144846 25.113</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-180b70e5-7d37-4c00-b3da-81a200dcc03b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-180b70e5-7d37-4c00-b3da-81a200dcc03b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-180b70e5-7d37-4c00-b3da-81a200dcc03b">
											<gml:posList>35.66703989142182 139.7380720144846 25.113 35.66703989028584 139.73807057853207 25.113 35.66700432004818 139.7381135889287 25.113 35.66700549185017 139.73811360962884 25.113 35.66703989142182 139.7380720144846 25.113</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9489a935-6d18-41a0-8f8a-a4703b3ee1f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9489a935-6d18-41a0-8f8a-a4703b3ee1f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9489a935-6d18-41a0-8f8a-a4703b3ee1f8">
											<gml:posList>35.66713201066674 139.73815037449475 22.754 35.66705899082317 139.73805973095497 22.754 35.667044852729056 139.73807675828454 25.113 35.66713201066674 139.73815037449475 22.754</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-90f2df24-3de2-483e-8da3-d63da2a7c749">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-90f2df24-3de2-483e-8da3-d63da2a7c749">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-90f2df24-3de2-483e-8da3-d63da2a7c749">
											<gml:posList>35.667044852729056 139.73807675828454 25.113 35.667119331448134 139.73816571008356 25.113 35.66713201066674 139.73815037449475 22.754 35.667044852729056 139.73807675828454 25.113</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8d5af01b-266f-435f-b661-8ca22f508002">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d5af01b-266f-435f-b661-8ca22f508002">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d5af01b-266f-435f-b661-8ca22f508002">
											<gml:posList>35.66711815967234 139.73816572252005 25.113 35.667119331448134 139.73816571008356 25.113 35.667044852729056 139.73807675828454 25.113 35.6670442854322 139.73807747693542 25.113 35.66711815967234 139.73816572252005 25.113</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-873b27ec-1580-405b-87f9-31c6f4a1950b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-873b27ec-1580-405b-87f9-31c6f4a1950b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-873b27ec-1580-405b-87f9-31c6f4a1950b">
											<gml:posList>35.66711815967234 139.73816572252005 25.113 35.667114008394634 139.73817085270235 25.113 35.66711517115669 139.73817084027664 25.113 35.667119331448134 139.73816571008356 25.113 35.66711815967234 139.73816572252005 25.113</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-14e3300b-1c62-4c76-b7d0-3e34fa9f74f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-14e3300b-1c62-4c76-b7d0-3e34fa9f74f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-14e3300b-1c62-4c76-b7d0-3e34fa9f74f6">
											<gml:posList>35.66703989142182 139.7380720144846 24.591 35.66700549185017 139.73811360962884 24.591 35.66713876441897 139.73827901705815 24.591 35.66717112883758 139.7382398212714 24.591 35.667114008394634 139.73817085270235 24.591 35.66711815967234 139.73816572252005 24.591 35.6670442854322 139.73807747693542 24.591 35.66703989142182 139.7380720144846 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-60e9b2d8-dc2c-4c8a-9624-e815c0b18b6a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-60e9b2d8-dc2c-4c8a-9624-e815c0b18b6a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-60e9b2d8-dc2c-4c8a-9624-e815c0b18b6a">
											<gml:posList>35.66718838378459 139.73822036016645 22.754 35.66713201066674 139.73815037449475 22.754 35.66711517115669 139.73817084027664 25.113 35.66718838378459 139.73822036016645 22.754</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2cd4d557-6c23-4fbe-b2a3-b273f63c2cfa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2cd4d557-6c23-4fbe-b2a3-b273f63c2cfa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2cd4d557-6c23-4fbe-b2a3-b273f63c2cfa">
											<gml:posList>35.66717112883758 139.7382398212714 25.113 35.667172300622084 139.73823981988178 25.113 35.66711517115669 139.73817084027664 25.113 35.667114008394634 139.73817085270235 25.113 35.66717112883758 139.7382398212714 25.113</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-04c746ed-4315-49ab-98a9-3984d852e509">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04c746ed-4315-49ab-98a9-3984d852e509">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04c746ed-4315-49ab-98a9-3984d852e509">
											<gml:posList>35.66711517115669 139.73817084027664 25.113 35.667172300622084 139.73823981988178 25.113 35.66718838378459 139.73822036016645 22.754 35.66711517115669 139.73817084027664 25.113</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a6b8d667-85fe-4311-9347-6e1b1c687dd6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a6b8d667-85fe-4311-9347-6e1b1c687dd6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a6b8d667-85fe-4311-9347-6e1b1c687dd6">
											<gml:posList>35.66719730711951 139.73823143958617 21.785 35.66718838378459 139.73822036016645 21.785 35.667159378257004 139.7382554539895 21.785 35.66716831056758 139.7382664892152 21.785 35.66719730711951 139.73823143958617 21.785</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-554bb9fb-f38e-46c4-919f-e29cbe593ecc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-554bb9fb-f38e-46c4-919f-e29cbe593ecc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-554bb9fb-f38e-46c4-919f-e29cbe593ecc">
											<gml:posList>35.66713876441897 139.73827901705815 25.113 35.667138756530015 139.73828044197734 25.113 35.667172300622084 139.73823981988178 25.113 35.66717112883758 139.7382398212714 25.113 35.66713876441897 139.73827901705815 25.113</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a8930596-edac-4811-a7d9-9d0a3290791d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a8930596-edac-4811-a7d9-9d0a3290791d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a8930596-edac-4811-a7d9-9d0a3290791d">
											<gml:posList>35.66711815967234 139.73816572252005 24.591 35.66711815967234 139.73816572252005 25.113 35.6670442854322 139.73807747693542 25.113 35.6670442854322 139.73807747693542 24.591 35.66711815967234 139.73816572252005 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fc92e572-539a-4ecf-b1bc-34cce25b07fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc92e572-539a-4ecf-b1bc-34cce25b07fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc92e572-539a-4ecf-b1bc-34cce25b07fe">
											<gml:posList>35.66717112883758 139.7382398212714 24.591 35.66717112883758 139.7382398212714 25.113 35.667114008394634 139.73817085270235 25.113 35.667114008394634 139.73817085270235 24.591 35.66717112883758 139.7382398212714 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-07ec3a98-ccb9-4b6b-9857-52b5c1ef2448">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-07ec3a98-ccb9-4b6b-9857-52b5c1ef2448">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-07ec3a98-ccb9-4b6b-9857-52b5c1ef2448">
											<gml:posList>35.66705899082317 139.73805973095497 22.754 35.66705899082317 139.73805973095497 13.625 35.667044852729056 139.73807675828454 13.625 35.667044852729056 139.73807675828454 25.113 35.66705899082317 139.73805973095497 22.754</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-42709a06-81b8-48df-84c3-d84836a327a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-42709a06-81b8-48df-84c3-d84836a327a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-42709a06-81b8-48df-84c3-d84836a327a7">
											<gml:posList>35.66703989028584 139.73807057853207 13.625 35.66703989028584 139.73807057853207 25.113 35.667044852729056 139.73807675828454 25.113 35.667044852729056 139.73807675828454 13.625 35.66703989028584 139.73807057853207 13.625</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1d4dabc7-2462-4aac-b5f5-6300c7965ca1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d4dabc7-2462-4aac-b5f5-6300c7965ca1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d4dabc7-2462-4aac-b5f5-6300c7965ca1">
											<gml:posList>35.6670442854322 139.73807747693542 24.591 35.6670442854322 139.73807747693542 25.113 35.66703989142182 139.7380720144846 25.113 35.66703989142182 139.7380720144846 24.591 35.6670442854322 139.73807747693542 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7cbff5f0-b93a-40c1-b5f6-b959e7a6d867">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7cbff5f0-b93a-40c1-b5f6-b959e7a6d867">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7cbff5f0-b93a-40c1-b5f6-b959e7a6d867">
											<gml:posList>35.66700432004818 139.7381135889287 25.113 35.66703989028584 139.73807057853207 25.113 35.66703989028584 139.73807057853207 13.625 35.66700432004818 139.7381135889287 13.625 35.66700432004818 139.7381135889287 25.113</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8cf60638-178a-41a0-ba2a-42f56a26fde5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8cf60638-178a-41a0-ba2a-42f56a26fde5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8cf60638-178a-41a0-ba2a-42f56a26fde5">
											<gml:posList>35.66703989142182 139.7380720144846 24.591 35.66703989142182 139.7380720144846 25.113 35.66700549185017 139.73811360962884 25.113 35.66700549185017 139.73811360962884 24.591 35.66703989142182 139.7380720144846 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7888a274-5ac3-4211-b30b-6375c96ed0df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7888a274-5ac3-4211-b30b-6375c96ed0df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7888a274-5ac3-4211-b30b-6375c96ed0df">
											<gml:posList>35.66719730711951 139.73823143958617 21.785 35.66719730711951 139.73823143958617 13.625 35.66705899082317 139.73805973095497 13.625 35.66705899082317 139.73805973095497 22.754 35.66713201066674 139.73815037449475 22.754 35.66718838378459 139.73822036016645 22.754 35.66718838378459 139.73822036016645 21.785 35.66719730711951 139.73823143958617 21.785</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dbc88433-10a8-414f-a032-b13f18663a3e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dbc88433-10a8-414f-a032-b13f18663a3e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dbc88433-10a8-414f-a032-b13f18663a3e">
											<gml:posList>35.66711517115669 139.73817084027664 25.113 35.66713201066674 139.73815037449475 22.754 35.667119331448134 139.73816571008356 25.113 35.66711517115669 139.73817084027664 25.113</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d9cc5c37-f70a-45b1-865e-ae82b17329a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d9cc5c37-f70a-45b1-865e-ae82b17329a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d9cc5c37-f70a-45b1-865e-ae82b17329a0">
											<gml:posList>35.667114008394634 139.73817085270235 24.591 35.667114008394634 139.73817085270235 25.113 35.66711815967234 139.73816572252005 25.113 35.66711815967234 139.73816572252005 24.591 35.667114008394634 139.73817085270235 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cdd04bd2-cfb7-4328-87e8-ff9e6036fac6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cdd04bd2-cfb7-4328-87e8-ff9e6036fac6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cdd04bd2-cfb7-4328-87e8-ff9e6036fac6">
											<gml:posList>35.66700549185017 139.73811360962884 24.591 35.66700549185017 139.73811360962884 25.113 35.66713876441897 139.73827901705815 25.113 35.66713876441897 139.73827901705815 24.591 35.66700549185017 139.73811360962884 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-438910ab-5590-44d6-95ec-2c0d4107c92e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-438910ab-5590-44d6-95ec-2c0d4107c92e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-438910ab-5590-44d6-95ec-2c0d4107c92e">
											<gml:posList>35.66700432004818 139.7381135889287 13.625 35.667138756530015 139.73828044197734 13.625 35.667138756530015 139.73828044197734 25.113 35.66700432004818 139.7381135889287 25.113 35.66700432004818 139.7381135889287 13.625</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6f64b5ce-93ab-4ec0-8b5a-78651abd16ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f64b5ce-93ab-4ec0-8b5a-78651abd16ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f64b5ce-93ab-4ec0-8b5a-78651abd16ae">
											<gml:posList>35.66719730711951 139.73823143958617 21.785 35.66716831056758 139.7382664892152 21.785 35.66716831056758 139.7382664892152 13.625 35.66719730711951 139.73823143958617 13.625 35.66719730711951 139.73823143958617 21.785</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4f0cbbd2-bdfb-436d-8421-b5bc706c3ca0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f0cbbd2-bdfb-436d-8421-b5bc706c3ca0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f0cbbd2-bdfb-436d-8421-b5bc706c3ca0">
											<gml:posList>35.667138756530015 139.73828044197734 13.625 35.667159378257004 139.7382554539895 13.625 35.667159378257004 139.7382554539895 21.785 35.66718838378459 139.73822036016645 21.785 35.66718838378459 139.73822036016645 22.754 35.667172300622084 139.73823981988178 25.113 35.667138756530015 139.73828044197734 25.113 35.667138756530015 139.73828044197734 13.625</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-afa1b3c3-e718-4c62-bfbd-495d6f0e195e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-afa1b3c3-e718-4c62-bfbd-495d6f0e195e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-afa1b3c3-e718-4c62-bfbd-495d6f0e195e">
											<gml:posList>35.66713876441897 139.73827901705815 24.591 35.66713876441897 139.73827901705815 25.113 35.66717112883758 139.7382398212714 25.113 35.66717112883758 139.7382398212714 24.591 35.66713876441897 139.73827901705815 24.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1065354d-96fb-42cf-8dde-f034a31bf2c5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1065354d-96fb-42cf-8dde-f034a31bf2c5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1065354d-96fb-42cf-8dde-f034a31bf2c5">
											<gml:posList>35.66716831056758 139.7382664892152 21.785 35.667159378257004 139.7382554539895 21.785 35.667159378257004 139.7382554539895 13.625 35.66716831056758 139.7382664892152 13.625 35.66716831056758 139.7382664892152 21.785</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区六本木二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-389</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">168.92795</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">5</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>3</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingLandSlideRiskAttribute>
					<uro:description codeSpace="../../codelists/LandSlideRiskAttribute_description.xml">1</uro:description>
					<uro:areaType codeSpace="../../codelists/LandSlideRiskAttribute_areaType.xml">1</uro:areaType>
				</uro:BuildingLandSlideRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">105</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key105.xml">3</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">20</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>