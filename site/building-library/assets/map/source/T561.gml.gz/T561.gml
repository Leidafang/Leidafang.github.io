<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_a38fd418-0e2b-4fc6-a067-da83385efaa8">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">411</bldg:usage>
			<bldg:measuredHeight uom="m">6.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67068574782605 139.74176653693058 0 35.670620891011595 139.74170331574368 0 35.67059549181247 139.74172897216215 0 35.6705898188813 139.74173649011976 0 35.67056083056473 139.74178369087164 0 35.67063173106381 139.74185287017903 0 35.67066180164157 139.74180644141575 0 35.67066062901796 139.74180533812455 0 35.67068574782605 139.74176653693058 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67068574782605 139.74176653693058 8.239 35.67066062901796 139.74180533812455 8.239 35.67066180164157 139.74180644141575 8.239 35.67063173106381 139.74185287017903 8.239 35.67056083056473 139.74178369087164 8.239 35.6705898188813 139.74173649011976 8.239 35.67059549181247 139.74172897216215 8.239 35.670620891011595 139.74170331574368 8.239 35.67068574782605 139.74176653693058 8.239</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67068574782605 139.74176653693058 8.239 35.670620891011595 139.74170331574368 8.239 35.670620891011595 139.74170331574368 15.08 35.67068574782605 139.74176653693058 15.08 35.67068574782605 139.74176653693058 8.239</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670620891011595 139.74170331574368 8.239 35.67059549181247 139.74172897216215 8.239 35.67059549181247 139.74172897216215 15.08 35.670620891011595 139.74170331574368 15.08 35.670620891011595 139.74170331574368 8.239</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67059549181247 139.74172897216215 8.239 35.6705898188813 139.74173649011976 8.239 35.6705898188813 139.74173649011976 15.08 35.67059549181247 139.74172897216215 15.08 35.67059549181247 139.74172897216215 8.239</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6705898188813 139.74173649011976 8.239 35.67056083056473 139.74178369087164 8.239 35.67056083056473 139.74178369087164 15.08 35.6705898188813 139.74173649011976 15.08 35.6705898188813 139.74173649011976 8.239</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67056083056473 139.74178369087164 8.239 35.67063173106381 139.74185287017903 8.239 35.67063173106381 139.74185287017903 15.08 35.67056083056473 139.74178369087164 15.08 35.67056083056473 139.74178369087164 8.239</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67063173106381 139.74185287017903 8.239 35.67066180164157 139.74180644141575 8.239 35.67066180164157 139.74180644141575 15.08 35.67063173106381 139.74185287017903 15.08 35.67063173106381 139.74185287017903 8.239</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67066180164157 139.74180644141575 8.239 35.67066062901796 139.74180533812455 8.239 35.67066062901796 139.74180533812455 15.08 35.67066180164157 139.74180644141575 15.08 35.67066180164157 139.74180644141575 8.239</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67066062901796 139.74180533812455 8.239 35.67068574782605 139.74176653693058 8.239 35.67068574782605 139.74176653693058 15.08 35.67066062901796 139.74180533812455 15.08 35.67066062901796 139.74180533812455 8.239</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67068574782605 139.74176653693058 15.08 35.670620891011595 139.74170331574368 15.08 35.67059549181247 139.74172897216215 15.08 35.6705898188813 139.74173649011976 15.08 35.67056083056473 139.74178369087164 15.08 35.67063173106381 139.74185287017903 15.08 35.67066180164157 139.74180644141575 15.08 35.67066062901796 139.74180533812455 15.08 35.67068574782605 139.74176653693058 15.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-0a9c6a5f-d3ce-4fd7-aac1-8000f87a7e7b"/>
							<gml:surfaceMember xlink:href="#poly-af7bcb77-9136-417f-9979-ff628d244306"/>
							<gml:surfaceMember xlink:href="#poly-1ffb0441-0cf1-4524-a4ba-40ff3008fcdb"/>
							<gml:surfaceMember xlink:href="#poly-38cf4d25-917a-4ed1-a9ca-3b9ab31cb747"/>
							<gml:surfaceMember xlink:href="#poly-db448567-721b-40c1-a654-026b2bffac7a"/>
							<gml:surfaceMember xlink:href="#poly-d3cbbabf-b5d1-46e2-86bd-d836e3162523"/>
							<gml:surfaceMember xlink:href="#poly-7532d668-a751-4913-a6c1-d7eaf23f0129"/>
							<gml:surfaceMember xlink:href="#poly-50b5102e-6d8d-481f-aa2f-dc50a6924c2e"/>
							<gml:surfaceMember xlink:href="#poly-e12ddd48-8bd7-4a21-b66b-26c4bfe0ed39"/>
							<gml:surfaceMember xlink:href="#poly-8f3dca68-55a0-49a1-950d-152b6a61fcc4"/>
							<gml:surfaceMember xlink:href="#poly-e7aa3e8c-fbc2-4543-b88f-502884e2fd5a"/>
							<gml:surfaceMember xlink:href="#poly-d795a90f-6680-49c2-a2d7-3bea54b1ac5b"/>
							<gml:surfaceMember xlink:href="#poly-c6e78432-94dd-4778-b7b1-bd4a8e670e23"/>
							<gml:surfaceMember xlink:href="#poly-01ab2e55-23ab-4ace-9fb5-66286f7e0ac0"/>
							<gml:surfaceMember xlink:href="#poly-f4636f21-3e3a-4084-883e-fd8dcde08072"/>
							<gml:surfaceMember xlink:href="#poly-aa215985-c5d6-497a-80a1-26aefac565f4"/>
							<gml:surfaceMember xlink:href="#poly-b992df39-0d6f-4742-9fa8-4f449700f23e"/>
							<gml:surfaceMember xlink:href="#poly-36743db7-9455-44f5-8e2d-d9cee531c857"/>
							<gml:surfaceMember xlink:href="#poly-b7e8b146-3f6f-4067-98c3-28cef759dbca"/>
							<gml:surfaceMember xlink:href="#poly-b8bdfca0-8b4c-418b-9c28-b7286812840e"/>
							<gml:surfaceMember xlink:href="#poly-0697e3d8-5267-4954-9d56-1059cdee90bb"/>
							<gml:surfaceMember xlink:href="#poly-ab9d484b-da5a-4e88-8ad4-fd1f2d23812f"/>
							<gml:surfaceMember xlink:href="#poly-ec11a230-5a11-46fc-bdf5-d50535ebab98"/>
							<gml:surfaceMember xlink:href="#poly-028c1815-4860-4fdf-adb8-6bbbabeae5d5"/>
							<gml:surfaceMember xlink:href="#poly-47433a4c-5ab7-4aa8-921c-05f42ed158a8"/>
							<gml:surfaceMember xlink:href="#poly-830db6bf-4232-4a96-a003-d02a7bd8e96a"/>
							<gml:surfaceMember xlink:href="#poly-3c0a1dcd-3d88-423e-886c-5e4280552748"/>
							<gml:surfaceMember xlink:href="#poly-73652c9e-8979-4666-907c-8d1b593bfe51"/>
							<gml:surfaceMember xlink:href="#poly-b7ede2ee-5dfa-41b0-a0a2-476c919d32ff"/>
							<gml:surfaceMember xlink:href="#poly-98b320c4-34c3-400b-a13c-a222ebe41824"/>
							<gml:surfaceMember xlink:href="#poly-58a7e10a-26e3-4a79-96d7-ba984cfd77bb"/>
							<gml:surfaceMember xlink:href="#poly-769bcd0a-ca7f-42d2-a170-4b4f50596585"/>
							<gml:surfaceMember xlink:href="#poly-cca773ca-7bb2-49b5-824e-60629fefbdc7"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_a38fd418-0e2b-4fc6-a067-da83385efaa8_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc9d9a22-7a06-43cb-8d2f-3a62f3558a5f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc9d9a22-7a06-43cb-8d2f-3a62f3558a5f_0">
											<gml:posList>35.670636538364114 139.74179748961762 14.433 35.670636538364114 139.74179748961762 14.684 35.67064780483322 139.74180843468108 14.684 35.67064780483322 139.74180843468108 14.433 35.670636538364114 139.74179748961762 14.433</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eb144a10-0c5d-45e8-a898-c32ba93371b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eb144a10-0c5d-45e8-a898-c32ba93371b4_0">
											<gml:posList>35.670641805320415 139.74178949713274 14.684 35.670641805320415 139.74178949713274 16.532 35.67065907036602 139.7418062898855 16.532 35.67065907036602 139.7418062898855 14.684 35.670641805320415 139.74178949713274 14.684</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-900cb3db-6015-4a4f-9f47-be5f9501d766">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-900cb3db-6015-4a4f-9f47-be5f9501d766_0">
											<gml:posList>35.67062660767246 139.74181255705335 14.433 35.67062660767246 139.74181255705335 16.532 35.670641805320415 139.74178949713274 16.532 35.670641805320415 139.74178949713274 14.684 35.670636538364114 139.74179748961762 14.684 35.670636538364114 139.74179748961762 14.433 35.67062660767246 139.74181255705335 14.433</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b1ecd61-14b6-4e4c-93aa-b24838522711">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2b1ecd61-14b6-4e4c-93aa-b24838522711_0">
											<gml:posList>35.670641805320415 139.74178949713274 16.532 35.67062660767246 139.74181255705335 16.532 35.670643872714905 139.7418293498079 16.532 35.67065907036602 139.7418062898855 16.532 35.670641805320415 139.74178949713274 16.532</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b3f008c-f301-4d3e-ac14-92c3fce87a7f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4b3f008c-f301-4d3e-ac14-92c3fce87a7f_0">
											<gml:posList>35.67064780483322 139.74180843468108 14.684 35.67063797337512 139.74182361246721 14.684 35.67063797337512 139.74182361246721 14.433 35.67064780483322 139.74180843468108 14.433 35.67064780483322 139.74180843468108 14.684</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d163df31-bf7a-4689-a6e0-bed8d1706d94">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d163df31-bf7a-4689-a6e0-bed8d1706d94_0">
											<gml:posList>35.67065907036602 139.7418062898855 16.532 35.670643872714905 139.7418293498079 16.532 35.670643872714905 139.7418293498079 14.684 35.67065907036602 139.7418062898855 14.684 35.67065907036602 139.7418062898855 16.532</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a71befd-0a2f-4455-80ff-d0f1c961b7dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a71befd-0a2f-4455-80ff-d0f1c961b7dc_0">
											<gml:posList>35.67063797337512 139.74182361246721 14.684 35.670643872714905 139.7418293498079 14.684 35.670643872714905 139.7418293498079 16.532 35.67062660767246 139.74181255705335 16.532 35.67062660767246 139.74181255705335 14.433 35.67063797337512 139.74182361246721 14.433 35.67063797337512 139.74182361246721 14.684</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16f70d93-d36e-458b-a1ca-71bee6fa397f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670641805320415 139.74178949713274 14.684 35.67065907036602 139.7418062898855 14.684 35.670643872714905 139.7418293498079 14.684 35.67063797337512 139.74182361246721 14.684 35.67064780483322 139.74180843468108 14.684 35.670636538364114 139.74179748961762 14.684 35.670641805320415 139.74178949713274 14.684</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-08080a65-8662-48f1-bba3-12551a6042c3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670636538364114 139.74179748961762 14.433 35.67064780483322 139.74180843468108 14.433 35.67063797337512 139.74182361246721 14.433 35.67062660767246 139.74181255705335 14.433 35.670636538364114 139.74179748961762 14.433</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-0a9c6a5f-d3ce-4fd7-aac1-8000f87a7e7b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a9c6a5f-d3ce-4fd7-aac1-8000f87a7e7b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a9c6a5f-d3ce-4fd7-aac1-8000f87a7e7b">
											<gml:posList>35.67059549181246 139.74172897216212 8.239 35.67062089101159 139.74170331574368 8.239 35.670685747826035 139.74176653693056 8.239 35.670660629017945 139.74180533812455 8.239 35.67066180164153 139.74180644141575 8.239 35.67063173106377 139.74185287017903 8.239 35.67056083056475 139.7417836908716 8.239 35.6705898188813 139.74173649011976 8.239 35.67059549181246 139.74172897216212 8.239</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-af7bcb77-9136-417f-9979-ff628d244306">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af7bcb77-9136-417f-9979-ff628d244306">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af7bcb77-9136-417f-9979-ff628d244306">
											<gml:posList>35.67057461993964 139.74178154319304 14.684 35.67059782899917 139.74174427964917 14.684 35.6705898188813 139.74173649011976 14.684 35.67056083056475 139.7417836908716 14.684 35.67057461993964 139.74178154319304 14.684</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1ffb0441-0cf1-4524-a4ba-40ff3008fcdb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ffb0441-0cf1-4524-a4ba-40ff3008fcdb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ffb0441-0cf1-4524-a4ba-40ff3008fcdb">
											<gml:posList>35.67059549181246 139.74172897216212 17.557 35.6705898188813 139.74173649011976 17.557 35.67059459582662 139.74173605385715 17.557 35.6705977384563 139.741731896862 17.557 35.67059549181246 139.74172897216212 17.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-38cf4d25-917a-4ed1-a9ca-3b9ab31cb747">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38cf4d25-917a-4ed1-a9ca-3b9ab31cb747">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38cf4d25-917a-4ed1-a9ca-3b9ab31cb747">
											<gml:posList>35.670630131614395 139.74183571710938 14.684 35.67057461993964 139.74178154319304 14.684 35.67056083056475 139.7417836908716 14.684 35.67063173106377 139.74185287017903 14.684 35.670630131614395 139.74183571710938 14.684</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-db448567-721b-40c1-a654-026b2bffac7a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db448567-721b-40c1-a654-026b2bffac7a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db448567-721b-40c1-a654-026b2bffac7a">
											<gml:posList>35.67059549181246 139.74172897216212 17.557 35.6705977384563 139.741731896862 17.557 35.67062091296445 139.7417084743373 17.557 35.67062089101159 139.74170331574368 17.557 35.67059549181246 139.74172897216212 17.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d3cbbabf-b5d1-46e2-86bd-d836e3162523">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3cbbabf-b5d1-46e2-86bd-d836e3162523">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3cbbabf-b5d1-46e2-86bd-d836e3162523">
											<gml:posList>35.67057461993964 139.74178154319304 14.433 35.670630131614395 139.74183571710938 14.433 35.67064780483322 139.74180843468108 14.433 35.67062826666701 139.74178945735937 14.433 35.670634460835196 139.7417798841959 14.433 35.67059782899917 139.74174427964917 14.433 35.67057461993964 139.74178154319304 14.433</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7532d668-a751-4913-a6c1-d7eaf23f0129">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7532d668-a751-4913-a6c1-d7eaf23f0129">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7532d668-a751-4913-a6c1-d7eaf23f0129">
											<gml:posList>35.6706353809152 139.74178077789512 17.557 35.670634998181356 139.74177531041633 17.557 35.67059459582662 139.74173605385715 17.557 35.6705898188813 139.74173649011976 17.557 35.6706353809152 139.74178077789512 17.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-50b5102e-6d8d-481f-aa2f-dc50a6924c2e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50b5102e-6d8d-481f-aa2f-dc50a6924c2e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50b5102e-6d8d-481f-aa2f-dc50a6924c2e">
											<gml:posList>35.670634998181356 139.74177531041633 16.878 35.670657725287015 139.74174434378287 16.878 35.67062091296445 139.7417084743373 16.878 35.6705977384563 139.741731896862 16.878 35.67059459582662 139.74173605385715 16.878 35.670634998181356 139.74177531041633 16.878</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e12ddd48-8bd7-4a21-b66b-26c4bfe0ed39">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e12ddd48-8bd7-4a21-b66b-26c4bfe0ed39">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e12ddd48-8bd7-4a21-b66b-26c4bfe0ed39">
											<gml:posList>35.67062089101159 139.74170331574368 17.557 35.67062091296445 139.7417084743373 17.557 35.670657725287015 139.74174434378287 17.557 35.67066247514912 139.7417438523198 17.557 35.67062089101159 139.74170331574368 17.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8f3dca68-55a0-49a1-950d-152b6a61fcc4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f3dca68-55a0-49a1-950d-152b6a61fcc4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f3dca68-55a0-49a1-950d-152b6a61fcc4">
											<gml:posList>35.67064780483322 139.74180843468108 14.684 35.67066180164153 139.74180644141575 14.684 35.6706353809152 139.74178077789512 14.684 35.670634460835196 139.7417798841959 14.684 35.67062826666701 139.74178945735937 14.684 35.67064780483322 139.74180843468108 14.684</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e7aa3e8c-fbc2-4543-b88f-502884e2fd5a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e7aa3e8c-fbc2-4543-b88f-502884e2fd5a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e7aa3e8c-fbc2-4543-b88f-502884e2fd5a">
											<gml:posList>35.67064780483322 139.74180843468108 14.684 35.670630131614395 139.74183571710938 14.684 35.67063173106377 139.74185287017903 14.684 35.67066180164153 139.74180644141575 14.684 35.67064780483322 139.74180843468108 14.684</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d795a90f-6680-49c2-a2d7-3bea54b1ac5b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d795a90f-6680-49c2-a2d7-3bea54b1ac5b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d795a90f-6680-49c2-a2d7-3bea54b1ac5b">
											<gml:posList>35.6706353809152 139.74178077789512 17.557 35.67066247514912 139.7417438523198 17.557 35.670657725287015 139.74174434378287 17.557 35.670634998181356 139.74177531041633 17.557 35.6706353809152 139.74178077789512 17.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c6e78432-94dd-4778-b7b1-bd4a8e670e23">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6e78432-94dd-4778-b7b1-bd4a8e670e23">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6e78432-94dd-4778-b7b1-bd4a8e670e23">
											<gml:posList>35.67066247514912 139.7417438523198 12.5 35.6706353809152 139.74178077789512 12.5 35.670660629017945 139.74180533812455 12.5 35.670685747826035 139.74176653693056 12.5 35.67066247514912 139.7417438523198 12.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-01ab2e55-23ab-4ace-9fb5-66286f7e0ac0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-01ab2e55-23ab-4ace-9fb5-66286f7e0ac0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-01ab2e55-23ab-4ace-9fb5-66286f7e0ac0">
											<gml:posList>35.67062826666701 139.74178945735937 14.433 35.67064780483322 139.74180843468108 14.433 35.67064780483322 139.74180843468108 14.684 35.67062826666701 139.74178945735937 14.684 35.67062826666701 139.74178945735937 14.433</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f4636f21-3e3a-4084-883e-fd8dcde08072">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4636f21-3e3a-4084-883e-fd8dcde08072">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4636f21-3e3a-4084-883e-fd8dcde08072">
											<gml:posList>35.67062091296445 139.7417084743373 16.878 35.670657725287015 139.74174434378287 16.878 35.670657725287015 139.74174434378287 17.557 35.67062091296445 139.7417084743373 17.557 35.67062091296445 139.7417084743373 16.878</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aa215985-c5d6-497a-80a1-26aefac565f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa215985-c5d6-497a-80a1-26aefac565f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa215985-c5d6-497a-80a1-26aefac565f4">
											<gml:posList>35.67059549181246 139.74172897216212 17.557 35.67062089101159 139.74170331574368 17.557 35.67062089101159 139.74170331574368 8.239 35.67059549181246 139.74172897216212 8.239 35.67059549181246 139.74172897216212 17.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b992df39-0d6f-4742-9fa8-4f449700f23e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b992df39-0d6f-4742-9fa8-4f449700f23e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b992df39-0d6f-4742-9fa8-4f449700f23e">
											<gml:posList>35.6705977384563 139.741731896862 16.878 35.67062091296445 139.7417084743373 16.878 35.67062091296445 139.7417084743373 17.557 35.6705977384563 139.741731896862 17.557 35.6705977384563 139.741731896862 16.878</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-36743db7-9455-44f5-8e2d-d9cee531c857">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36743db7-9455-44f5-8e2d-d9cee531c857">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36743db7-9455-44f5-8e2d-d9cee531c857">
											<gml:posList>35.67059549181246 139.74172897216212 17.557 35.67059549181246 139.74172897216212 8.239 35.6705898188813 139.74173649011976 8.239 35.6705898188813 139.74173649011976 14.684 35.6705898188813 139.74173649011976 17.557 35.67059549181246 139.74172897216212 17.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b7e8b146-3f6f-4067-98c3-28cef759dbca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b7e8b146-3f6f-4067-98c3-28cef759dbca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b7e8b146-3f6f-4067-98c3-28cef759dbca">
											<gml:posList>35.67059459582662 139.74173605385715 16.878 35.6705977384563 139.741731896862 16.878 35.6705977384563 139.741731896862 17.557 35.67059459582662 139.74173605385715 17.557 35.67059459582662 139.74173605385715 16.878</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b8bdfca0-8b4c-418b-9c28-b7286812840e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8bdfca0-8b4c-418b-9c28-b7286812840e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8bdfca0-8b4c-418b-9c28-b7286812840e">
											<gml:posList>35.67066247514912 139.7417438523198 12.5 35.670685747826035 139.74176653693056 12.5 35.670685747826035 139.74176653693056 8.239 35.67062089101159 139.74170331574368 8.239 35.67062089101159 139.74170331574368 17.557 35.67066247514912 139.7417438523198 17.557 35.67066247514912 139.7417438523198 12.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0697e3d8-5267-4954-9d56-1059cdee90bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0697e3d8-5267-4954-9d56-1059cdee90bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0697e3d8-5267-4954-9d56-1059cdee90bb">
											<gml:posList>35.670634998181356 139.74177531041633 16.878 35.67059459582662 139.74173605385715 16.878 35.67059459582662 139.74173605385715 17.557 35.670634998181356 139.74177531041633 17.557 35.670634998181356 139.74177531041633 16.878</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ab9d484b-da5a-4e88-8ad4-fd1f2d23812f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab9d484b-da5a-4e88-8ad4-fd1f2d23812f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab9d484b-da5a-4e88-8ad4-fd1f2d23812f">
											<gml:posList>35.6706353809152 139.74178077789512 17.557 35.6705898188813 139.74173649011976 17.557 35.6705898188813 139.74173649011976 14.684 35.67059782899917 139.74174427964917 14.684 35.67059782899917 139.74174427964917 14.433 35.670634460835196 139.7417798841959 14.433 35.670634460835196 139.7417798841959 14.684 35.6706353809152 139.74178077789512 14.684 35.6706353809152 139.74178077789512 17.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ec11a230-5a11-46fc-bdf5-d50535ebab98">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec11a230-5a11-46fc-bdf5-d50535ebab98">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec11a230-5a11-46fc-bdf5-d50535ebab98">
											<gml:posList>35.670657725287015 139.74174434378287 16.878 35.670634998181356 139.74177531041633 16.878 35.670634998181356 139.74177531041633 17.557 35.670657725287015 139.74174434378287 17.557 35.670657725287015 139.74174434378287 16.878</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-028c1815-4860-4fdf-adb8-6bbbabeae5d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-028c1815-4860-4fdf-adb8-6bbbabeae5d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-028c1815-4860-4fdf-adb8-6bbbabeae5d5">
											<gml:posList>35.67056083056475 139.7417836908716 8.239 35.67056083056475 139.7417836908716 14.684 35.6705898188813 139.74173649011976 14.684 35.6705898188813 139.74173649011976 8.239 35.67056083056475 139.7417836908716 8.239</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-47433a4c-5ab7-4aa8-921c-05f42ed158a8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47433a4c-5ab7-4aa8-921c-05f42ed158a8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47433a4c-5ab7-4aa8-921c-05f42ed158a8">
											<gml:posList>35.6706353809152 139.74178077789512 14.684 35.6706353809152 139.74178077789512 12.5 35.67066247514912 139.7417438523198 12.5 35.67066247514912 139.7417438523198 17.557 35.6706353809152 139.74178077789512 17.557 35.6706353809152 139.74178077789512 14.684</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-830db6bf-4232-4a96-a003-d02a7bd8e96a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-830db6bf-4232-4a96-a003-d02a7bd8e96a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-830db6bf-4232-4a96-a003-d02a7bd8e96a">
											<gml:posList>35.67057461993964 139.74178154319304 14.433 35.67059782899917 139.74174427964917 14.433 35.67059782899917 139.74174427964917 14.684 35.67057461993964 139.74178154319304 14.684 35.67057461993964 139.74178154319304 14.433</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3c0a1dcd-3d88-423e-886c-5e4280552748">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c0a1dcd-3d88-423e-886c-5e4280552748">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c0a1dcd-3d88-423e-886c-5e4280552748">
											<gml:posList>35.670634460835196 139.7417798841959 14.433 35.67062826666701 139.74178945735937 14.433 35.67062826666701 139.74178945735937 14.684 35.670634460835196 139.7417798841959 14.684 35.670634460835196 139.7417798841959 14.433</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-73652c9e-8979-4666-907c-8d1b593bfe51">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73652c9e-8979-4666-907c-8d1b593bfe51">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73652c9e-8979-4666-907c-8d1b593bfe51">
											<gml:posList>35.670685747826035 139.74176653693056 8.239 35.670685747826035 139.74176653693056 12.5 35.670660629017945 139.74180533812455 12.5 35.670660629017945 139.74180533812455 8.239 35.670685747826035 139.74176653693056 8.239</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b7ede2ee-5dfa-41b0-a0a2-476c919d32ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b7ede2ee-5dfa-41b0-a0a2-476c919d32ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b7ede2ee-5dfa-41b0-a0a2-476c919d32ff">
											<gml:posList>35.67066180164153 139.74180644141575 14.684 35.67066180164153 139.74180644141575 8.239 35.670660629017945 139.74180533812455 8.239 35.670660629017945 139.74180533812455 12.5 35.6706353809152 139.74178077789512 12.5 35.6706353809152 139.74178077789512 14.684 35.67066180164153 139.74180644141575 14.684</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-98b320c4-34c3-400b-a13c-a222ebe41824">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-98b320c4-34c3-400b-a13c-a222ebe41824">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-98b320c4-34c3-400b-a13c-a222ebe41824">
											<gml:posList>35.670630131614395 139.74183571710938 14.433 35.67057461993964 139.74178154319304 14.433 35.67057461993964 139.74178154319304 14.684 35.670630131614395 139.74183571710938 14.684 35.670630131614395 139.74183571710938 14.433</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-58a7e10a-26e3-4a79-96d7-ba984cfd77bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-58a7e10a-26e3-4a79-96d7-ba984cfd77bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-58a7e10a-26e3-4a79-96d7-ba984cfd77bb">
											<gml:posList>35.67063173106377 139.74185287017903 8.239 35.67063173106377 139.74185287017903 14.684 35.67056083056475 139.7417836908716 14.684 35.67056083056475 139.7417836908716 8.239 35.67063173106377 139.74185287017903 8.239</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-769bcd0a-ca7f-42d2-a170-4b4f50596585">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-769bcd0a-ca7f-42d2-a170-4b4f50596585">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-769bcd0a-ca7f-42d2-a170-4b4f50596585">
											<gml:posList>35.67064780483322 139.74180843468108 14.433 35.670630131614395 139.74183571710938 14.433 35.670630131614395 139.74183571710938 14.684 35.67064780483322 139.74180843468108 14.684 35.67064780483322 139.74180843468108 14.433</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cca773ca-7bb2-49b5-824e-60629fefbdc7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cca773ca-7bb2-49b5-824e-60629fefbdc7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cca773ca-7bb2-49b5-824e-60629fefbdc7">
											<gml:posList>35.67066180164153 139.74180644141575 8.239 35.67066180164153 139.74180644141575 14.684 35.67063173106377 139.74185287017903 14.684 35.67063173106377 139.74185287017903 8.239 35.67066180164153 139.74180644141575 8.239</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5007</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">54.2085</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1003</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1310</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">21</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>