<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_a5115697-0469-4939-8a63-6062fb707952">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">9.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.668508825948166 139.7383716042699 0 35.66842852709927 139.73827449465347 0 35.668376120827496 139.73834248957826 0 35.66845542671972 139.7384378330156 0 35.668508825948166 139.7383716042699 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668508825948166 139.7383716042699 22.93 35.66845542671972 139.7384378330156 22.93 35.668376120827496 139.73834248957826 22.93 35.66842852709927 139.73827449465347 22.93 35.668508825948166 139.7383716042699 22.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668508825948166 139.7383716042699 22.93 35.66842852709927 139.73827449465347 22.93 35.66842852709927 139.73827449465347 32.81 35.668508825948166 139.7383716042699 32.81 35.668508825948166 139.7383716042699 22.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66842852709927 139.73827449465347 22.93 35.668376120827496 139.73834248957826 22.93 35.668376120827496 139.73834248957826 32.81 35.66842852709927 139.73827449465347 32.81 35.66842852709927 139.73827449465347 22.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668376120827496 139.73834248957826 22.93 35.66845542671972 139.7384378330156 22.93 35.66845542671972 139.7384378330156 32.81 35.668376120827496 139.73834248957826 32.81 35.668376120827496 139.73834248957826 22.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66845542671972 139.7384378330156 22.93 35.668508825948166 139.7383716042699 22.93 35.668508825948166 139.7383716042699 32.81 35.66845542671972 139.7384378330156 32.81 35.66845542671972 139.7384378330156 22.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668508825948166 139.7383716042699 32.81 35.66842852709927 139.73827449465347 32.81 35.668376120827496 139.73834248957826 32.81 35.66845542671972 139.7384378330156 32.81 35.668508825948166 139.7383716042699 32.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-c9bc0a68-155a-4080-8746-dd15dab662dd"/>
							<gml:surfaceMember xlink:href="#poly-61b1e9d3-d84e-4870-848e-ca052b270912"/>
							<gml:surfaceMember xlink:href="#poly-47e0aa7f-6505-4a25-a68a-483f1c4e8062"/>
							<gml:surfaceMember xlink:href="#poly-16248e6b-3bb6-4d6b-8c18-4b126b3a53d3"/>
							<gml:surfaceMember xlink:href="#poly-dc3c759f-05bc-40a9-ae23-ab869a6be3a9"/>
							<gml:surfaceMember xlink:href="#poly-0dc41989-72d5-43a8-a34a-149785005d41"/>
							<gml:surfaceMember xlink:href="#poly-d4d7c9a5-5acc-4da9-b448-50acc1d2560c"/>
							<gml:surfaceMember xlink:href="#poly-4b22d903-1bbf-4d9b-b068-818b83b41ae9"/>
							<gml:surfaceMember xlink:href="#poly-34b3ac99-bfd8-4a94-a04c-5b9806b924df"/>
							<gml:surfaceMember xlink:href="#poly-a873924f-3f13-42cc-9b3a-5ef99051cbbb"/>
							<gml:surfaceMember xlink:href="#poly-0de7dba0-f5b5-49e9-a498-f66d7ae693c0"/>
							<gml:surfaceMember xlink:href="#poly-d4cfa16e-0819-4f4e-9317-86c565417f5a"/>
							<gml:surfaceMember xlink:href="#poly-5cdde045-cd5d-4638-ba99-fd7605d0213e"/>
							<gml:surfaceMember xlink:href="#poly-24c10be8-3235-47c1-b705-ecbd6f9752b8"/>
							<gml:surfaceMember xlink:href="#poly-2eadcebe-f72a-4fe4-9707-a47bc1c4c4fe"/>
							<gml:surfaceMember xlink:href="#poly-4828da29-0b09-4774-9e9c-b06570389142"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_a5115697-0469-4939-8a63-6062fb707952_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ce6e857-135a-4c8c-9607-45a1d6ca9022">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668442293744796 139.7383692750383 32.984 35.668433469510134 139.7383809721477 32.984 35.668419792472854 139.73836547977515 32.984 35.66842861670602 139.73835378266605 32.984 35.668442293744796 139.7383692750383 32.984</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa51950f-744c-4757-a171-77e5a966568c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fa51950f-744c-4757-a171-77e5a966568c_0">
											<gml:posList>35.668419792472854 139.73836547977515 32.984 35.668419792472854 139.73836547977515 35.614 35.66842861670602 139.73835378266605 35.614 35.66842861670602 139.73835378266605 32.984 35.668419792472854 139.73836547977515 32.984</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-037a079a-b535-4fe6-85f2-e3072bc99b36">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-037a079a-b535-4fe6-85f2-e3072bc99b36_0">
											<gml:posList>35.66842861670602 139.73835378266605 35.614 35.668442293744796 139.7383692750383 35.614 35.668442293744796 139.7383692750383 32.984 35.66842861670602 139.73835378266605 32.984 35.66842861670602 139.73835378266605 35.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46c84fc0-6f96-4e76-82f6-56726df54262">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46c84fc0-6f96-4e76-82f6-56726df54262_0">
											<gml:posList>35.668419792472854 139.73836547977515 35.614 35.668433469510134 139.7383809721477 35.614 35.668442293744796 139.7383692750383 35.614 35.66842861670602 139.73835378266605 35.614 35.668419792472854 139.73836547977515 35.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af5f26a1-5a68-4080-90a9-74074ccdc406">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-af5f26a1-5a68-4080-90a9-74074ccdc406_0">
											<gml:posList>35.668433469510134 139.7383809721477 35.614 35.668419792472854 139.73836547977515 35.614 35.668419792472854 139.73836547977515 32.984 35.668433469510134 139.7383809721477 32.984 35.668433469510134 139.7383809721477 35.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b64acb19-13ed-4383-9eb6-ca37159f019d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b64acb19-13ed-4383-9eb6-ca37159f019d_0">
											<gml:posList>35.668442293744796 139.7383692750383 32.984 35.668442293744796 139.7383692750383 35.614 35.668433469510134 139.7383809721477 35.614 35.668433469510134 139.7383809721477 32.984 35.668442293744796 139.7383692750383 32.984</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-c9bc0a68-155a-4080-8746-dd15dab662dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c9bc0a68-155a-4080-8746-dd15dab662dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c9bc0a68-155a-4080-8746-dd15dab662dd">
											<gml:posList>35.668508825948145 139.7383716042699 22.93 35.668455426719696 139.73843783301558 22.93 35.668376120827524 139.73834248957826 22.93 35.668428527099294 139.73827449465347 22.93 35.668508825948145 139.7383716042699 22.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-61b1e9d3-d84e-4870-848e-ca052b270912">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61b1e9d3-d84e-4870-848e-ca052b270912">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61b1e9d3-d84e-4870-848e-ca052b270912">
											<gml:posList>35.66844281849394 139.7382917757347 33.664 35.668428527099294 139.73827449465347 28.209 35.668376120827524 139.73834248957826 28.209 35.66844281849394 139.7382917757347 33.664</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-47e0aa7f-6505-4a25-a68a-483f1c4e8062">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47e0aa7f-6505-4a25-a68a-483f1c4e8062">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47e0aa7f-6505-4a25-a68a-483f1c4e8062">
											<gml:posList>35.668376120827524 139.73834248957826 28.209 35.668391612100855 139.73836111684938 33.664 35.66844281849394 139.7382917757347 33.664 35.668376120827524 139.73834248957826 28.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-16248e6b-3bb6-4d6b-8c18-4b126b3a53d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16248e6b-3bb6-4d6b-8c18-4b126b3a53d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16248e6b-3bb6-4d6b-8c18-4b126b3a53d3">
											<gml:posList>35.668391612100855 139.73836111684938 33.664 35.6683949741332 139.7383610024074 33.664 35.66844292102756 139.7382960614582 33.664 35.66844281849394 139.7382917757347 33.664 35.668391612100855 139.73836111684938 33.664</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dc3c759f-05bc-40a9-ae23-ab869a6be3a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc3c759f-05bc-40a9-ae23-ab869a6be3a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc3c759f-05bc-40a9-ae23-ab869a6be3a9">
											<gml:posList>35.668455426719696 139.73843783301558 33.664 35.66845539637056 139.73843363557376 33.664 35.6683949741332 139.7383610024074 33.664 35.668391612100855 139.73836111684938 33.664 35.668455426719696 139.73843783301558 33.664</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0dc41989-72d5-43a8-a34a-149785005d41">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0dc41989-72d5-43a8-a34a-149785005d41">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0dc41989-72d5-43a8-a34a-149785005d41">
											<gml:posList>35.66850540074137 139.7383716193724 32.984 35.66844292102756 139.7382960614582 32.984 35.6683949741332 139.7383610024074 32.984 35.66845539637056 139.73843363557376 32.984 35.66850540074137 139.7383716193724 32.984</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d4d7c9a5-5acc-4da9-b448-50acc1d2560c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4d7c9a5-5acc-4da9-b448-50acc1d2560c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4d7c9a5-5acc-4da9-b448-50acc1d2560c">
											<gml:posList>35.66844281849394 139.7382917757347 33.664 35.66844292102756 139.7382960614582 33.664 35.66850540074137 139.7383716193724 33.664 35.668508825948145 139.7383716042699 33.664 35.66844281849394 139.7382917757347 33.664</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4b22d903-1bbf-4d9b-b068-818b83b41ae9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b22d903-1bbf-4d9b-b068-818b83b41ae9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b22d903-1bbf-4d9b-b068-818b83b41ae9">
											<gml:posList>35.668508825948145 139.7383716042699 33.664 35.66850540074137 139.7383716193724 33.664 35.66845539637056 139.73843363557376 33.664 35.668455426719696 139.73843783301558 33.664 35.668508825948145 139.7383716042699 33.664</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-34b3ac99-bfd8-4a94-a04c-5b9806b924df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-34b3ac99-bfd8-4a94-a04c-5b9806b924df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-34b3ac99-bfd8-4a94-a04c-5b9806b924df">
											<gml:posList>35.66844292102756 139.7382960614582 33.664 35.66844292102756 139.7382960614582 32.984 35.66850540074137 139.7383716193724 32.984 35.66850540074137 139.7383716193724 33.664 35.66844292102756 139.7382960614582 33.664</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a873924f-3f13-42cc-9b3a-5ef99051cbbb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a873924f-3f13-42cc-9b3a-5ef99051cbbb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a873924f-3f13-42cc-9b3a-5ef99051cbbb">
											<gml:posList>35.66845539637056 139.73843363557376 33.664 35.66845539637056 139.73843363557376 32.984 35.6683949741332 139.7383610024074 32.984 35.6683949741332 139.7383610024074 33.664 35.66845539637056 139.73843363557376 33.664</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0de7dba0-f5b5-49e9-a498-f66d7ae693c0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0de7dba0-f5b5-49e9-a498-f66d7ae693c0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0de7dba0-f5b5-49e9-a498-f66d7ae693c0">
											<gml:posList>35.668428527099294 139.73827449465347 22.93 35.668376120827524 139.73834248957826 22.93 35.668376120827524 139.73834248957826 28.209 35.668428527099294 139.73827449465347 28.209 35.668428527099294 139.73827449465347 22.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d4cfa16e-0819-4f4e-9317-86c565417f5a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4cfa16e-0819-4f4e-9317-86c565417f5a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4cfa16e-0819-4f4e-9317-86c565417f5a">
											<gml:posList>35.668376120827524 139.73834248957826 22.93 35.668455426719696 139.73843783301558 22.93 35.668455426719696 139.73843783301558 33.664 35.668391612100855 139.73836111684938 33.664 35.668376120827524 139.73834248957826 28.209 35.668376120827524 139.73834248957826 22.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5cdde045-cd5d-4638-ba99-fd7605d0213e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5cdde045-cd5d-4638-ba99-fd7605d0213e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5cdde045-cd5d-4638-ba99-fd7605d0213e">
											<gml:posList>35.6683949741332 139.7383610024074 33.664 35.6683949741332 139.7383610024074 32.984 35.66844292102756 139.7382960614582 32.984 35.66844292102756 139.7382960614582 33.664 35.6683949741332 139.7383610024074 33.664</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-24c10be8-3235-47c1-b705-ecbd6f9752b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-24c10be8-3235-47c1-b705-ecbd6f9752b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-24c10be8-3235-47c1-b705-ecbd6f9752b8">
											<gml:posList>35.668428527099294 139.73827449465347 28.209 35.66844281849394 139.7382917757347 33.664 35.668508825948145 139.7383716042699 33.664 35.668508825948145 139.7383716042699 22.93 35.668428527099294 139.73827449465347 22.93 35.668428527099294 139.73827449465347 28.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2eadcebe-f72a-4fe4-9707-a47bc1c4c4fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2eadcebe-f72a-4fe4-9707-a47bc1c4c4fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2eadcebe-f72a-4fe4-9707-a47bc1c4c4fe">
											<gml:posList>35.66850540074137 139.7383716193724 33.664 35.66850540074137 139.7383716193724 32.984 35.66845539637056 139.73843363557376 32.984 35.66845539637056 139.73843363557376 33.664 35.66850540074137 139.7383716193724 33.664</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4828da29-0b09-4774-9e9c-b06570389142">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4828da29-0b09-4774-9e9c-b06570389142">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4828da29-0b09-4774-9e9c-b06570389142">
											<gml:posList>35.668455426719696 139.73843783301558 22.93 35.668508825948145 139.7383716042699 22.93 35.668508825948145 139.7383716042699 33.664 35.668455426719696 139.73843783301558 33.664 35.668455426719696 139.73843783301558 22.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6881</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">104.91915</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingLandSlideRiskAttribute>
					<uro:description codeSpace="../../codelists/LandSlideRiskAttribute_description.xml">1</uro:description>
					<uro:areaType codeSpace="../../codelists/LandSlideRiskAttribute_areaType.xml">1</uro:areaType>
				</uro:BuildingLandSlideRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>