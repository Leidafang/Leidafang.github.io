<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_a57db525-e6f9-4bc2-81d5-c0ba7fa00b6f">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>0.85</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">422</bldg:usage>
			<bldg:measuredHeight uom="m">6.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66737217387644 139.74207584901066 0 35.667364703949815 139.74209099031845 0 35.66740979794312 139.74212440793366 0 35.667420867590764 139.7421016408874 0 35.66746226294081 139.7421310862298 0 35.66749988190247 139.74205394332026 0 35.66753817469155 139.74208095106076 0 35.66754438428543 139.74206790986884 0 35.66750654259856 139.7420414539121 0 35.66755181529175 139.741953919079 0 35.66743466122525 139.7418674530929 0 35.6674280913555 139.74188082606898 0 35.66741907259451 139.74187420884385 0 35.66733528889302 139.74205103784786 0 35.66737217387644 139.74207584901066 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66737217387644 139.74207584901066 28.565 35.66733528889302 139.74205103784786 28.565 35.66741907259451 139.74187420884385 28.565 35.6674280913555 139.74188082606898 28.565 35.66743466122525 139.7418674530929 28.565 35.66755181529175 139.741953919079 28.565 35.66750654259856 139.7420414539121 28.565 35.66754438428543 139.74206790986884 28.565 35.66753817469155 139.74208095106076 28.565 35.66749988190247 139.74205394332026 28.565 35.66746226294081 139.7421310862298 28.565 35.667420867590764 139.7421016408874 28.565 35.66740979794312 139.74212440793366 28.565 35.667364703949815 139.74209099031845 28.565 35.66737217387644 139.74207584901066 28.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66737217387644 139.74207584901066 28.565 35.667364703949815 139.74209099031845 28.565 35.667364703949815 139.74209099031845 34.8 35.66737217387644 139.74207584901066 34.8 35.66737217387644 139.74207584901066 28.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667364703949815 139.74209099031845 28.565 35.66740979794312 139.74212440793366 28.565 35.66740979794312 139.74212440793366 34.8 35.667364703949815 139.74209099031845 34.8 35.667364703949815 139.74209099031845 28.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66740979794312 139.74212440793366 28.565 35.667420867590764 139.7421016408874 28.565 35.667420867590764 139.7421016408874 34.8 35.66740979794312 139.74212440793366 34.8 35.66740979794312 139.74212440793366 28.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667420867590764 139.7421016408874 28.565 35.66746226294081 139.7421310862298 28.565 35.66746226294081 139.7421310862298 34.8 35.667420867590764 139.7421016408874 34.8 35.667420867590764 139.7421016408874 28.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66746226294081 139.7421310862298 28.565 35.66749988190247 139.74205394332026 28.565 35.66749988190247 139.74205394332026 34.8 35.66746226294081 139.7421310862298 34.8 35.66746226294081 139.7421310862298 28.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66749988190247 139.74205394332026 28.565 35.66753817469155 139.74208095106076 28.565 35.66753817469155 139.74208095106076 34.8 35.66749988190247 139.74205394332026 34.8 35.66749988190247 139.74205394332026 28.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66753817469155 139.74208095106076 28.565 35.66754438428543 139.74206790986884 28.565 35.66754438428543 139.74206790986884 34.8 35.66753817469155 139.74208095106076 34.8 35.66753817469155 139.74208095106076 28.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66754438428543 139.74206790986884 28.565 35.66750654259856 139.7420414539121 28.565 35.66750654259856 139.7420414539121 34.8 35.66754438428543 139.74206790986884 34.8 35.66754438428543 139.74206790986884 28.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66750654259856 139.7420414539121 28.565 35.66755181529175 139.741953919079 28.565 35.66755181529175 139.741953919079 34.8 35.66750654259856 139.7420414539121 34.8 35.66750654259856 139.7420414539121 28.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66755181529175 139.741953919079 28.565 35.66743466122525 139.7418674530929 28.565 35.66743466122525 139.7418674530929 34.8 35.66755181529175 139.741953919079 34.8 35.66755181529175 139.741953919079 28.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66743466122525 139.7418674530929 28.565 35.6674280913555 139.74188082606898 28.565 35.6674280913555 139.74188082606898 34.8 35.66743466122525 139.7418674530929 34.8 35.66743466122525 139.7418674530929 28.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6674280913555 139.74188082606898 28.565 35.66741907259451 139.74187420884385 28.565 35.66741907259451 139.74187420884385 34.8 35.6674280913555 139.74188082606898 34.8 35.6674280913555 139.74188082606898 28.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66741907259451 139.74187420884385 28.565 35.66733528889302 139.74205103784786 28.565 35.66733528889302 139.74205103784786 34.8 35.66741907259451 139.74187420884385 34.8 35.66741907259451 139.74187420884385 28.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66733528889302 139.74205103784786 28.565 35.66737217387644 139.74207584901066 28.565 35.66737217387644 139.74207584901066 34.8 35.66733528889302 139.74205103784786 34.8 35.66733528889302 139.74205103784786 28.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66737217387644 139.74207584901066 34.8 35.667364703949815 139.74209099031845 34.8 35.66740979794312 139.74212440793366 34.8 35.667420867590764 139.7421016408874 34.8 35.66746226294081 139.7421310862298 34.8 35.66749988190247 139.74205394332026 34.8 35.66753817469155 139.74208095106076 34.8 35.66754438428543 139.74206790986884 34.8 35.66750654259856 139.7420414539121 34.8 35.66755181529175 139.741953919079 34.8 35.66743466122525 139.7418674530929 34.8 35.6674280913555 139.74188082606898 34.8 35.66741907259451 139.74187420884385 34.8 35.66733528889302 139.74205103784786 34.8 35.66737217387644 139.74207584901066 34.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-649a9c47-2608-4e05-a535-18cb6d39b51e"/>
							<gml:surfaceMember xlink:href="#poly-8e953b73-09c6-4432-8ce1-024740c1018c"/>
							<gml:surfaceMember xlink:href="#poly-f7d4b010-6444-45c1-bc05-b437e8829350"/>
							<gml:surfaceMember xlink:href="#poly-acc45b16-602e-4f40-ab90-6d6e6f8c2103"/>
							<gml:surfaceMember xlink:href="#poly-6119c1c9-d669-4d2a-b6fe-2a0dffef9a56"/>
							<gml:surfaceMember xlink:href="#poly-6422e028-f4a1-46e9-9d4a-4fd390c6277a"/>
							<gml:surfaceMember xlink:href="#poly-eca4c1e9-5aa3-4ff9-8304-2a7b4ec99094"/>
							<gml:surfaceMember xlink:href="#poly-2807ae4e-a913-49ad-a0ec-f4126a2094e7"/>
							<gml:surfaceMember xlink:href="#poly-8a5df13f-3e8a-46fc-bf86-cf58ad9ffd36"/>
							<gml:surfaceMember xlink:href="#poly-565dfbc2-6788-432e-8449-b1ea5ad790ed"/>
							<gml:surfaceMember xlink:href="#poly-e44061d8-7a9f-488c-b9af-f5642a8f7f8f"/>
							<gml:surfaceMember xlink:href="#poly-c05780b9-05bb-4dc3-a290-99349b07152b"/>
							<gml:surfaceMember xlink:href="#poly-471c1a57-55a3-4efd-9695-3682233a1c98"/>
							<gml:surfaceMember xlink:href="#poly-eeb487c0-93d2-433b-8c4f-0e3dc1204286"/>
							<gml:surfaceMember xlink:href="#poly-dd0db807-37ef-41d2-a0bb-b462c48e8a0e"/>
							<gml:surfaceMember xlink:href="#poly-d63c152d-f7d7-408d-b7e7-948915b1057d"/>
							<gml:surfaceMember xlink:href="#poly-afc8db10-bb1f-4b3d-8867-8813546ae5ef"/>
							<gml:surfaceMember xlink:href="#poly-2c974920-5069-46c5-b43a-0357175abeef"/>
							<gml:surfaceMember xlink:href="#poly-5759e10a-c627-4932-b32c-3b72ec248744"/>
							<gml:surfaceMember xlink:href="#poly-c853b0e9-ccaa-40fd-b42f-dcf949e520f4"/>
							<gml:surfaceMember xlink:href="#poly-d0783cc1-ba38-41ab-96b5-c73fbd7ec466"/>
							<gml:surfaceMember xlink:href="#poly-df76bfd9-6b04-4032-8a3e-55f19dbec52b"/>
							<gml:surfaceMember xlink:href="#poly-22b13109-2c22-48a3-be16-d8cf2089ca08"/>
							<gml:surfaceMember xlink:href="#poly-e0df8a42-fad3-45bc-b827-13c9c6443ebf"/>
							<gml:surfaceMember xlink:href="#poly-476baad1-92c3-4a42-8f8a-734c7bb66974"/>
							<gml:surfaceMember xlink:href="#poly-9ed0b00a-cf75-4c67-8b34-70d377c6bd4a"/>
							<gml:surfaceMember xlink:href="#poly-a7a6336d-b896-45b5-bf8d-df0604b0f58a"/>
							<gml:surfaceMember xlink:href="#poly-136c4624-6bb0-485b-b71b-4ce4bb11e43a"/>
							<gml:surfaceMember xlink:href="#poly-46c38c44-df4c-4dda-8e98-94d8d52d750a"/>
							<gml:surfaceMember xlink:href="#poly-b9072070-ad29-4ad6-ad4c-655e13b98a80"/>
							<gml:surfaceMember xlink:href="#poly-0daf5e66-92e6-4123-888f-cc5982d660b4"/>
							<gml:surfaceMember xlink:href="#poly-05927a65-17d9-4e2e-9470-383fa89b8820"/>
							<gml:surfaceMember xlink:href="#poly-7cc02904-294e-4592-8ba3-0d2d161d0a94"/>
							<gml:surfaceMember xlink:href="#poly-4e9d9a2e-7376-4c72-bd95-19390a91a4d7"/>
							<gml:surfaceMember xlink:href="#poly-e773950f-a294-4099-b873-8cbb5ef699a1"/>
							<gml:surfaceMember xlink:href="#poly-4a3b66ba-04da-4d28-9611-e2f3b806a79d"/>
							<gml:surfaceMember xlink:href="#poly-e8c43a9d-d8c7-46c0-8a53-364a18e32b3b"/>
							<gml:surfaceMember xlink:href="#poly-b7a429bd-2c3e-4a0f-8682-79709c798fc5"/>
							<gml:surfaceMember xlink:href="#poly-a8f826e6-0eed-4c3b-8eff-68e81aaf3056"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-649a9c47-2608-4e05-a535-18cb6d39b51e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-649a9c47-2608-4e05-a535-18cb6d39b51e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-649a9c47-2608-4e05-a535-18cb6d39b51e">
											<gml:posList>35.66750654259856 139.7420414539121 28.565 35.667544384285435 139.74206790986884 28.565 35.66753817469154 139.74208095106076 28.565 35.66749988190246 139.74205394332026 28.565 35.6674622629408 139.7421310862298 28.565 35.667420867590764 139.7421016408874 28.565 35.66740979794312 139.74212440793366 28.565 35.6673647039498 139.74209099031842 28.565 35.6673721738764 139.74207584901063 28.565 35.66733528889302 139.74205103784783 28.565 35.66741907259448 139.74187420884385 28.565 35.66742809135548 139.74188082606895 28.565 35.66743466122523 139.7418674530929 28.565 35.66755181529176 139.741953919079 28.565 35.66750654259856 139.7420414539121 28.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8e953b73-09c6-4432-8ce1-024740c1018c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8e953b73-09c6-4432-8ce1-024740c1018c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8e953b73-09c6-4432-8ce1-024740c1018c">
											<gml:posList>35.66749988190246 139.74205394332026 34.1 35.66750654259856 139.7420414539121 34.1 35.667544614745 139.74196767939156 34.1 35.66749988190246 139.74205394332026 34.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f7d4b010-6444-45c1-bc05-b437e8829350">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f7d4b010-6444-45c1-bc05-b437e8829350">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f7d4b010-6444-45c1-bc05-b437e8829350">
											<gml:posList>35.66736088102148 139.74204196216846 35.573 35.66733528889302 139.74205103784783 34.1 35.6673721738764 139.74207584901063 34.1 35.66736088102148 139.74204196216846 35.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-acc45b16-602e-4f40-ab90-6d6e6f8c2103">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-acc45b16-602e-4f40-ab90-6d6e6f8c2103">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-acc45b16-602e-4f40-ab90-6d6e6f8c2103">
											<gml:posList>35.667416318806595 139.74188002210255 34.1 35.66733528889302 139.74205103784783 34.1 35.66736088102148 139.74204196216846 35.573 35.667416318806595 139.74188002210255 34.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6119c1c9-d669-4d2a-b6fe-2a0dffef9a56">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6119c1c9-d669-4d2a-b6fe-2a0dffef9a56">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6119c1c9-d669-4d2a-b6fe-2a0dffef9a56">
											<gml:posList>35.66736088102148 139.74204196216846 35.573 35.6673721738764 139.74207584901063 34.1 35.66740979794312 139.74212440793366 34.1 35.66736088102148 139.74204196216846 35.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6422e028-f4a1-46e9-9d4a-4fd390c6277a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6422e028-f4a1-46e9-9d4a-4fd390c6277a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6422e028-f4a1-46e9-9d4a-4fd390c6277a">
											<gml:posList>35.6673721738764 139.74207584901063 34.1 35.6673647039498 139.74209099031842 34.1 35.66740979794312 139.74212440793366 34.1 35.6673721738764 139.74207584901063 34.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-eca4c1e9-5aa3-4ff9-8304-2a7b4ec99094">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eca4c1e9-5aa3-4ff9-8304-2a7b4ec99094">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eca4c1e9-5aa3-4ff9-8304-2a7b4ec99094">
											<gml:posList>35.667416318806595 139.74188002210255 34.1 35.66736088102148 139.74204196216846 35.573 35.66739595600628 139.74197400131365 40.059 35.667416318806595 139.74188002210255 34.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2807ae4e-a913-49ad-a0ec-f4126a2094e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2807ae4e-a913-49ad-a0ec-f4126a2094e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2807ae4e-a913-49ad-a0ec-f4126a2094e7">
											<gml:posList>35.667420867590764 139.7421016408874 34.1 35.66736088102148 139.74204196216846 35.573 35.66740979794312 139.74212440793366 34.1 35.667420867590764 139.7421016408874 34.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8a5df13f-3e8a-46fc-bf86-cf58ad9ffd36">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a5df13f-3e8a-46fc-bf86-cf58ad9ffd36">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a5df13f-3e8a-46fc-bf86-cf58ad9ffd36">
											<gml:posList>35.667420867590764 139.7421016408874 34.1 35.66744476987032 139.74208691165936 35.573 35.66736088102148 139.74204196216846 35.573 35.667420867590764 139.7421016408874 34.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-565dfbc2-6788-432e-8449-b1ea5ad790ed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-565dfbc2-6788-432e-8449-b1ea5ad790ed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-565dfbc2-6788-432e-8449-b1ea5ad790ed">
											<gml:posList>35.66744476987032 139.74208691165936 35.573 35.66739595600628 139.74197400131365 40.059 35.66736088102148 139.74204196216846 35.573 35.66744476987032 139.74208691165936 35.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e44061d8-7a9f-488c-b9af-f5642a8f7f8f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e44061d8-7a9f-488c-b9af-f5642a8f7f8f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e44061d8-7a9f-488c-b9af-f5642a8f7f8f">
											<gml:posList>35.667416318806595 139.74188002210255 34.1 35.66739595600628 139.74197400131365 40.059 35.66742439366371 139.74191372483457 35.573 35.667416318806595 139.74188002210255 34.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c05780b9-05bb-4dc3-a290-99349b07152b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c05780b9-05bb-4dc3-a290-99349b07152b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c05780b9-05bb-4dc3-a290-99349b07152b">
											<gml:posList>35.66744476987032 139.74208691165936 35.573 35.66747281623968 139.74203357242857 40.059 35.66739595600628 139.74197400131365 40.059 35.66744476987032 139.74208691165936 35.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-471c1a57-55a3-4efd-9695-3682233a1c98">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-471c1a57-55a3-4efd-9695-3682233a1c98">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-471c1a57-55a3-4efd-9695-3682233a1c98">
											<gml:posList>35.66742439366371 139.74191372483457 35.573 35.66739595600628 139.74197400131365 40.059 35.66747281623968 139.74203357242857 40.059 35.66742439366371 139.74191372483457 35.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-eeb487c0-93d2-433b-8c4f-0e3dc1204286">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eeb487c0-93d2-433b-8c4f-0e3dc1204286">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eeb487c0-93d2-433b-8c4f-0e3dc1204286">
											<gml:posList>35.667420867590764 139.7421016408874 34.1 35.6674622629408 139.7421310862298 34.1 35.66744476987032 139.74208691165936 35.573 35.667420867590764 139.7421016408874 34.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dd0db807-37ef-41d2-a0bb-b462c48e8a0e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd0db807-37ef-41d2-a0bb-b462c48e8a0e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd0db807-37ef-41d2-a0bb-b462c48e8a0e">
											<gml:posList>35.667416318806595 139.74188002210255 34.1 35.66742439366371 139.74191372483457 35.573 35.66747281623968 139.74203357242857 40.059 35.667416318806595 139.74188002210255 34.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d63c152d-f7d7-408d-b7e7-948915b1057d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d63c152d-f7d7-408d-b7e7-948915b1057d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d63c152d-f7d7-408d-b7e7-948915b1057d">
											<gml:posList>35.66749925219183 139.74197239243267 35.573 35.667416318806595 139.74188002210255 34.1 35.66747281623968 139.74203357242857 40.059 35.66749925219183 139.74197239243267 35.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-afc8db10-bb1f-4b3d-8867-8813546ae5ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-afc8db10-bb1f-4b3d-8867-8813546ae5ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-afc8db10-bb1f-4b3d-8867-8813546ae5ef">
											<gml:posList>35.66749988190246 139.74205394332026 34.1 35.66744476987032 139.74208691165936 35.573 35.6674622629408 139.7421310862298 34.1 35.66749988190246 139.74205394332026 34.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2c974920-5069-46c5-b43a-0357175abeef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c974920-5069-46c5-b43a-0357175abeef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c974920-5069-46c5-b43a-0357175abeef">
											<gml:posList>35.66749925219183 139.74197239243267 35.573 35.667544614745 139.74196767939156 34.1 35.667416318806595 139.74188002210255 34.1 35.66749925219183 139.74197239243267 35.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5759e10a-c627-4932-b32c-3b72ec248744">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5759e10a-c627-4932-b32c-3b72ec248744">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5759e10a-c627-4932-b32c-3b72ec248744">
											<gml:posList>35.667544614745 139.74196767939156 32.5 35.66755181529176 139.741953919079 32.5 35.66743466122523 139.7418674530929 32.5 35.66742809135548 139.74188082606895 32.5 35.66741907259448 139.74187420884385 32.5 35.667416318806595 139.74188002210255 32.5 35.667544614745 139.74196767939156 32.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c853b0e9-ccaa-40fd-b42f-dcf949e520f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c853b0e9-ccaa-40fd-b42f-dcf949e520f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c853b0e9-ccaa-40fd-b42f-dcf949e520f4">
											<gml:posList>35.66749988190246 139.74205394332026 34.1 35.667544614745 139.74196767939156 34.1 35.66744476987032 139.74208691165936 35.573 35.66749988190246 139.74205394332026 34.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d0783cc1-ba38-41ab-96b5-c73fbd7ec466">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d0783cc1-ba38-41ab-96b5-c73fbd7ec466">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d0783cc1-ba38-41ab-96b5-c73fbd7ec466">
											<gml:posList>35.667544614745 139.74196767939156 34.1 35.66749925219183 139.74197239243267 35.573 35.66744476987032 139.74208691165936 35.573 35.667544614745 139.74196767939156 34.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-df76bfd9-6b04-4032-8a3e-55f19dbec52b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df76bfd9-6b04-4032-8a3e-55f19dbec52b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df76bfd9-6b04-4032-8a3e-55f19dbec52b">
											<gml:posList>35.66750654259856 139.7420414539121 32.3 35.66749988190246 139.74205394332026 32.3 35.66753817469154 139.74208095106076 32.3 35.667544384285435 139.74206790986884 32.3 35.66750654259856 139.7420414539121 32.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-22b13109-2c22-48a3-be16-d8cf2089ca08">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22b13109-2c22-48a3-be16-d8cf2089ca08">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22b13109-2c22-48a3-be16-d8cf2089ca08">
											<gml:posList>35.667544384285435 139.74206790986884 32.3 35.66753817469154 139.74208095106076 32.3 35.66753817469154 139.74208095106076 28.565 35.667544384285435 139.74206790986884 28.565 35.667544384285435 139.74206790986884 32.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e0df8a42-fad3-45bc-b827-13c9c6443ebf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e0df8a42-fad3-45bc-b827-13c9c6443ebf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e0df8a42-fad3-45bc-b827-13c9c6443ebf">
											<gml:posList>35.66742809135548 139.74188082606895 32.5 35.66743466122523 139.7418674530929 32.5 35.66743466122523 139.7418674530929 28.565 35.66742809135548 139.74188082606895 28.565 35.66742809135548 139.74188082606895 32.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-476baad1-92c3-4a42-8f8a-734c7bb66974">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-476baad1-92c3-4a42-8f8a-734c7bb66974">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-476baad1-92c3-4a42-8f8a-734c7bb66974">
											<gml:posList>35.66741907259448 139.74187420884385 32.5 35.66742809135548 139.74188082606895 32.5 35.66742809135548 139.74188082606895 28.565 35.66741907259448 139.74187420884385 28.565 35.66741907259448 139.74187420884385 32.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9ed0b00a-cf75-4c67-8b34-70d377c6bd4a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ed0b00a-cf75-4c67-8b34-70d377c6bd4a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ed0b00a-cf75-4c67-8b34-70d377c6bd4a">
											<gml:posList>35.66743466122523 139.7418674530929 32.5 35.66755181529176 139.741953919079 32.5 35.66755181529176 139.741953919079 28.565 35.66743466122523 139.7418674530929 28.565 35.66743466122523 139.7418674530929 32.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a7a6336d-b896-45b5-bf8d-df0604b0f58a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a7a6336d-b896-45b5-bf8d-df0604b0f58a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a7a6336d-b896-45b5-bf8d-df0604b0f58a">
											<gml:posList>35.667544614745 139.74196767939156 34.1 35.667544614745 139.74196767939156 32.5 35.667416318806595 139.74188002210255 32.5 35.667416318806595 139.74188002210255 34.1 35.667544614745 139.74196767939156 34.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-136c4624-6bb0-485b-b71b-4ce4bb11e43a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-136c4624-6bb0-485b-b71b-4ce4bb11e43a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-136c4624-6bb0-485b-b71b-4ce4bb11e43a">
											<gml:posList>35.66741907259448 139.74187420884385 28.565 35.66733528889302 139.74205103784783 28.565 35.66733528889302 139.74205103784783 34.1 35.667416318806595 139.74188002210255 34.1 35.667416318806595 139.74188002210255 32.5 35.66741907259448 139.74187420884385 32.5 35.66741907259448 139.74187420884385 28.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-46c38c44-df4c-4dda-8e98-94d8d52d750a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-46c38c44-df4c-4dda-8e98-94d8d52d750a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-46c38c44-df4c-4dda-8e98-94d8d52d750a">
											<gml:posList>35.66750654259856 139.7420414539121 32.3 35.66750654259856 139.7420414539121 28.565 35.66755181529176 139.741953919079 28.565 35.66755181529176 139.741953919079 32.5 35.667544614745 139.74196767939156 32.5 35.667544614745 139.74196767939156 34.1 35.66750654259856 139.7420414539121 34.1 35.66750654259856 139.7420414539121 32.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b9072070-ad29-4ad6-ad4c-655e13b98a80">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b9072070-ad29-4ad6-ad4c-655e13b98a80">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b9072070-ad29-4ad6-ad4c-655e13b98a80">
											<gml:posList>35.66749925219183 139.74197239243267 35.573 35.66747281623968 139.74203357242857 40.059 35.66744476987032 139.74208691165936 35.573 35.66749925219183 139.74197239243267 35.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0daf5e66-92e6-4123-888f-cc5982d660b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0daf5e66-92e6-4123-888f-cc5982d660b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0daf5e66-92e6-4123-888f-cc5982d660b4">
											<gml:posList>35.66749988190246 139.74205394332026 34.1 35.66749988190246 139.74205394332026 32.3 35.66750654259856 139.7420414539121 32.3 35.66750654259856 139.7420414539121 34.1 35.66749988190246 139.74205394332026 34.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-05927a65-17d9-4e2e-9470-383fa89b8820">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-05927a65-17d9-4e2e-9470-383fa89b8820">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-05927a65-17d9-4e2e-9470-383fa89b8820">
											<gml:posList>35.66750654259856 139.7420414539121 32.3 35.667544384285435 139.74206790986884 32.3 35.667544384285435 139.74206790986884 28.565 35.66750654259856 139.7420414539121 28.565 35.66750654259856 139.7420414539121 32.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7cc02904-294e-4592-8ba3-0d2d161d0a94">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7cc02904-294e-4592-8ba3-0d2d161d0a94">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7cc02904-294e-4592-8ba3-0d2d161d0a94">
											<gml:posList>35.6673721738764 139.74207584901063 34.1 35.66733528889302 139.74205103784783 34.1 35.66733528889302 139.74205103784783 28.565 35.6673721738764 139.74207584901063 28.565 35.6673721738764 139.74207584901063 34.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4e9d9a2e-7376-4c72-bd95-19390a91a4d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4e9d9a2e-7376-4c72-bd95-19390a91a4d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4e9d9a2e-7376-4c72-bd95-19390a91a4d7">
											<gml:posList>35.66753817469154 139.74208095106076 32.3 35.66749988190246 139.74205394332026 32.3 35.66749988190246 139.74205394332026 28.565 35.66753817469154 139.74208095106076 28.565 35.66753817469154 139.74208095106076 32.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e773950f-a294-4099-b873-8cbb5ef699a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e773950f-a294-4099-b873-8cbb5ef699a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e773950f-a294-4099-b873-8cbb5ef699a1">
											<gml:posList>35.6673647039498 139.74209099031842 34.1 35.6673721738764 139.74207584901063 34.1 35.6673721738764 139.74207584901063 28.565 35.6673647039498 139.74209099031842 28.565 35.6673647039498 139.74209099031842 34.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4a3b66ba-04da-4d28-9611-e2f3b806a79d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a3b66ba-04da-4d28-9611-e2f3b806a79d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a3b66ba-04da-4d28-9611-e2f3b806a79d">
											<gml:posList>35.6674622629408 139.7421310862298 34.1 35.6674622629408 139.7421310862298 28.565 35.66749988190246 139.74205394332026 28.565 35.66749988190246 139.74205394332026 32.3 35.66749988190246 139.74205394332026 34.1 35.6674622629408 139.7421310862298 34.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e8c43a9d-d8c7-46c0-8a53-364a18e32b3b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8c43a9d-d8c7-46c0-8a53-364a18e32b3b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8c43a9d-d8c7-46c0-8a53-364a18e32b3b">
											<gml:posList>35.66740979794312 139.74212440793366 34.1 35.6673647039498 139.74209099031842 34.1 35.6673647039498 139.74209099031842 28.565 35.66740979794312 139.74212440793366 28.565 35.66740979794312 139.74212440793366 34.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b7a429bd-2c3e-4a0f-8682-79709c798fc5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b7a429bd-2c3e-4a0f-8682-79709c798fc5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b7a429bd-2c3e-4a0f-8682-79709c798fc5">
											<gml:posList>35.667420867590764 139.7421016408874 34.1 35.66740979794312 139.74212440793366 34.1 35.66740979794312 139.74212440793366 28.565 35.667420867590764 139.7421016408874 28.565 35.667420867590764 139.7421016408874 34.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a8f826e6-0eed-4c3b-8eff-68e81aaf3056">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a8f826e6-0eed-4c3b-8eff-68e81aaf3056">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a8f826e6-0eed-4c3b-8eff-68e81aaf3056">
											<gml:posList>35.6674622629408 139.7421310862298 34.1 35.667420867590764 139.7421016408874 34.1 35.667420867590764 139.7421016408874 28.565 35.6674622629408 139.7421310862298 28.565 35.6674622629408 139.7421310862298 34.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-9025</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">664.74825</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">6</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1123</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.09</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>