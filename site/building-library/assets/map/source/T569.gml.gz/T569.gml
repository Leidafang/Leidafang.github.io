<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_a5fe1f21-e2c6-456a-9e90-d341ce79b7c5">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">15.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.670242390615634 139.74396358822995 0 35.670193221254735 139.7441466791342 0 35.67028509858514 139.7441836923225 0 35.67033336630112 139.74400016038544 0 35.670242390615634 139.74396358822995 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670242390615634 139.74396358822995 7.971 35.67033336630112 139.74400016038544 7.971 35.67028509858514 139.7441836923225 7.971 35.670193221254735 139.7441466791342 7.971 35.670242390615634 139.74396358822995 7.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670242390615634 139.74396358822995 7.971 35.670193221254735 139.7441466791342 7.971 35.670193221254735 139.7441466791342 21.73 35.670242390615634 139.74396358822995 21.73 35.670242390615634 139.74396358822995 7.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670193221254735 139.7441466791342 7.971 35.67028509858514 139.7441836923225 7.971 35.67028509858514 139.7441836923225 21.73 35.670193221254735 139.7441466791342 21.73 35.670193221254735 139.7441466791342 7.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67028509858514 139.7441836923225 7.971 35.67033336630112 139.74400016038544 7.971 35.67033336630112 139.74400016038544 21.73 35.67028509858514 139.7441836923225 21.73 35.67028509858514 139.7441836923225 7.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67033336630112 139.74400016038544 7.971 35.670242390615634 139.74396358822995 7.971 35.670242390615634 139.74396358822995 21.73 35.67033336630112 139.74400016038544 21.73 35.67033336630112 139.74400016038544 7.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670242390615634 139.74396358822995 21.73 35.670193221254735 139.7441466791342 21.73 35.67028509858514 139.7441836923225 21.73 35.67033336630112 139.74400016038544 21.73 35.670242390615634 139.74396358822995 21.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-a0830eb4-3385-4985-9d44-c67033058259"/>
							<gml:surfaceMember xlink:href="#poly-36168ed4-433b-4af1-a7e4-2dd44d2de3bc"/>
							<gml:surfaceMember xlink:href="#poly-f0e223aa-b786-411c-992e-2a7df63f3ac5"/>
							<gml:surfaceMember xlink:href="#poly-1fe02411-510e-4bc1-83da-764c0d7fd5ee"/>
							<gml:surfaceMember xlink:href="#poly-952956b2-b854-4695-baa1-b14df22c9071"/>
							<gml:surfaceMember xlink:href="#poly-76aba8bf-788c-475f-a3d3-325162228057"/>
							<gml:surfaceMember xlink:href="#poly-5a1a1e2a-187b-40c5-a35f-457208774508"/>
							<gml:surfaceMember xlink:href="#poly-50d591b0-d764-423b-8337-a5097374e02c"/>
							<gml:surfaceMember xlink:href="#poly-5b7da8df-eeb0-4fdb-a807-d8a9c83fd164"/>
							<gml:surfaceMember xlink:href="#poly-58fe9551-8b1c-42f9-9d3b-0a82aa17af6f"/>
							<gml:surfaceMember xlink:href="#poly-54291d14-cc74-44b9-896f-3326f6265f27"/>
							<gml:surfaceMember xlink:href="#poly-42a8212f-6388-48a1-bdfe-292a7157efc5"/>
							<gml:surfaceMember xlink:href="#poly-791810f7-b1c0-4258-b022-ffb7dca774cb"/>
							<gml:surfaceMember xlink:href="#poly-dd27c95e-56a5-4b8d-af6b-edbacdab7520"/>
							<gml:surfaceMember xlink:href="#poly-44b586d2-1a66-4515-a4da-40a64722ddac"/>
							<gml:surfaceMember xlink:href="#poly-9fafb949-fdb2-4393-860a-9c74d28825ea"/>
							<gml:surfaceMember xlink:href="#poly-405dc9bd-0fc3-4136-a2bb-d6852c63a5d6"/>
							<gml:surfaceMember xlink:href="#poly-57de2664-6acd-4029-9316-0938ef6e2370"/>
							<gml:surfaceMember xlink:href="#poly-eb9c2d94-9032-46ef-9cf1-ec2fd19f5054"/>
							<gml:surfaceMember xlink:href="#poly-7b48a73b-b2d2-4906-8d02-6af34cd44806"/>
							<gml:surfaceMember xlink:href="#poly-d23dec6a-e29a-4d6c-adbe-dee48a8ab31a"/>
							<gml:surfaceMember xlink:href="#poly-629da98c-2f29-45aa-8e9e-3a387be96e0a"/>
							<gml:surfaceMember xlink:href="#poly-ff154f29-5edc-4317-af70-0574d7f1d518"/>
							<gml:surfaceMember xlink:href="#poly-7a80a56f-a61a-49c0-b9b9-1db4e5b9962b"/>
							<gml:surfaceMember xlink:href="#poly-ac76b409-a751-4758-bd78-bff1aaff60ff"/>
							<gml:surfaceMember xlink:href="#poly-6feddcb9-e785-489b-a6f0-f896a7bbe196"/>
							<gml:surfaceMember xlink:href="#poly-36a48a06-3b9c-47c0-9d2c-6c826971797d"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_a5fe1f21-e2c6-456a-9e90-d341ce79b7c5_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e9485c8-5038-457c-b08e-56729882f362">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67024253496325 139.7440609717282 24.791 35.67023682827237 139.74408394321526 24.791 35.67022146462121 139.7440782052272 24.791 35.67022717131101 139.74405523374415 24.791 35.67024253496325 139.7440609717282 24.791</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7cd7124e-0963-448a-939e-f27af85e85dd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67023006845855 139.7441210881958 30.143 35.67021280293795 139.74411538545613 30.143 35.67021558781226 139.74410272336954 30.143 35.67023285333345 139.74410842610666 30.143 35.67023006845855 139.7441210881958 30.143</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c82d4b4d-dca6-43e3-a7eb-f71568bc1888">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c82d4b4d-dca6-43e3-a7eb-f71568bc1888_0">
											<gml:posList>35.67024253496325 139.7440609717282 24.791 35.67022717131101 139.74405523374415 24.791 35.67022717131101 139.74405523374415 27.735 35.67024253496325 139.7440609717282 27.735 35.67024253496325 139.7440609717282 24.791</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a9a8b84b-d0ed-45be-bc08-8b30ee7a3beb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a9a8b84b-d0ed-45be-bc08-8b30ee7a3beb_0">
											<gml:posList>35.67022146462121 139.7440782052272 24.791 35.67022146462121 139.7440782052272 27.735 35.67022717131101 139.74405523374415 27.735 35.67022717131101 139.74405523374415 24.791 35.67022146462121 139.7440782052272 24.791</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d5fea32-1799-4b55-a801-29864612ccfa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d5fea32-1799-4b55-a801-29864612ccfa_0">
											<gml:posList>35.67022146462121 139.7440782052272 27.735 35.67023682827237 139.74408394321526 27.735 35.67024253496325 139.7440609717282 27.735 35.67022717131101 139.74405523374415 27.735 35.67022146462121 139.7440782052272 27.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a696e7b-a99e-4787-81fe-ebe73039c48e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9a696e7b-a99e-4787-81fe-ebe73039c48e_0">
											<gml:posList>35.67023682827237 139.74408394321526 24.791 35.67024253496325 139.7440609717282 24.791 35.67024253496325 139.7440609717282 27.735 35.67023682827237 139.74408394321526 27.735 35.67023682827237 139.74408394321526 24.791</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ecbba0b3-1845-4bd7-997b-8f160c525bea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ecbba0b3-1845-4bd7-997b-8f160c525bea_0">
											<gml:posList>35.67022146462121 139.7440782052272 24.791 35.67023682827237 139.74408394321526 24.791 35.67023682827237 139.74408394321526 27.735 35.67022146462121 139.7440782052272 27.735 35.67022146462121 139.7440782052272 24.791</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8ce7a128-6870-42b3-843f-b976064bdc54">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8ce7a128-6870-42b3-843f-b976064bdc54_0">
											<gml:posList>35.67023285333345 139.74410842610666 30.143 35.67021558781226 139.74410272336954 30.143 35.67021558781226 139.74410272336954 30.659 35.67023285333345 139.74410842610666 30.659 35.67023285333345 139.74410842610666 30.143</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7cc9bde6-1a0c-439b-b8be-8dd9bc4cdd2b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7cc9bde6-1a0c-439b-b8be-8dd9bc4cdd2b_0">
											<gml:posList>35.67021558781226 139.74410272336954 30.143 35.67021280293795 139.74411538545613 30.143 35.67021280293795 139.74411538545613 30.659 35.67021558781226 139.74410272336954 30.659 35.67021558781226 139.74410272336954 30.143</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1724ad1b-56ef-41b3-a6d7-ea3c28668cfe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1724ad1b-56ef-41b3-a6d7-ea3c28668cfe_0">
											<gml:posList>35.67023006845855 139.7441210881958 30.659 35.67023285333345 139.74410842610666 30.659 35.67021558781226 139.74410272336954 30.659 35.67021280293795 139.74411538545613 30.659 35.67023006845855 139.7441210881958 30.659</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-208aac1f-89b2-46a7-8cac-f0eb5b6408bd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-208aac1f-89b2-46a7-8cac-f0eb5b6408bd_0">
											<gml:posList>35.67023006845855 139.7441210881958 30.143 35.67023285333345 139.74410842610666 30.143 35.67023285333345 139.74410842610666 30.659 35.67023006845855 139.7441210881958 30.659 35.67023006845855 139.7441210881958 30.143</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1a8b242-de00-4722-80a7-c2129b7ed9ab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a1a8b242-de00-4722-80a7-c2129b7ed9ab_0">
											<gml:posList>35.67023006845855 139.7441210881958 30.659 35.67021280293795 139.74411538545613 30.659 35.67021280293795 139.74411538545613 30.143 35.67023006845855 139.7441210881958 30.143 35.67023006845855 139.7441210881958 30.659</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-a0830eb4-3385-4985-9d44-c67033058259">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a0830eb4-3385-4985-9d44-c67033058259">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a0830eb4-3385-4985-9d44-c67033058259">
											<gml:posList>35.67024239061561 139.74396358822995 7.971 35.67033336630112 139.74400016038544 7.971 35.67028509858514 139.7441836923225 7.971 35.670193221254706 139.7441466791342 7.971 35.67024239061561 139.74396358822995 7.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-36168ed4-433b-4af1-a7e4-2dd44d2de3bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36168ed4-433b-4af1-a7e4-2dd44d2de3bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36168ed4-433b-4af1-a7e4-2dd44d2de3bc">
											<gml:posList>35.670193221254706 139.7441466791342 31.572 35.67019659084929 139.7441445986939 31.572 35.67021182708433 139.7440878593204 31.572 35.670210120444885 139.7440837520201 31.572 35.670193221254706 139.7441466791342 31.572</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f0e223aa-b786-411c-992e-2a7df63f3ac5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f0e223aa-b786-411c-992e-2a7df63f3ac5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f0e223aa-b786-411c-992e-2a7df63f3ac5">
											<gml:posList>35.67022984595536 139.74416142930858 31.572 35.67022814832398 139.74415731094953 31.572 35.67019659084929 139.7441445986939 31.572 35.670193221254706 139.7441466791342 31.572 35.67022984595536 139.74416142930858 31.572</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1fe02411-510e-4bc1-83da-764c0d7fd5ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1fe02411-510e-4bc1-83da-764c0d7fd5ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1fe02411-510e-4bc1-83da-764c0d7fd5ee">
											<gml:posList>35.670243384581276 139.74410059364854 30.143 35.67021182708433 139.7440878593204 30.143 35.67019659084929 139.7441445986939 30.143 35.67022814832398 139.74415731094953 30.143 35.670243384581276 139.74410059364854 30.143</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-952956b2-b854-4695-baa1-b14df22c9071">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-952956b2-b854-4695-baa1-b14df22c9071">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-952956b2-b854-4695-baa1-b14df22c9071">
											<gml:posList>35.670210120444885 139.7440837520201 31.572 35.67021182708433 139.7440878593204 31.572 35.670243384581276 139.74410059364854 31.572 35.67024673614757 139.74409851322508 31.572 35.670210120444885 139.7440837520201 31.572</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-76aba8bf-788c-475f-a3d3-325162228057">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-76aba8bf-788c-475f-a3d3-325162228057">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-76aba8bf-788c-475f-a3d3-325162228057">
											<gml:posList>35.67024673614757 139.74409851322508 31.572 35.670243384581276 139.74410059364854 31.572 35.67022814832398 139.74415731094953 31.572 35.67022984595536 139.74416142930858 31.572 35.67024673614757 139.74409851322508 31.572</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5a1a1e2a-187b-40c5-a35f-457208774508">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a1a1e2a-187b-40c5-a35f-457208774508">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a1a1e2a-187b-40c5-a35f-457208774508">
											<gml:posList>35.670273255650784 139.74397845521102 24.791 35.67024405103458 139.74396613806084 24.791 35.670212248322336 139.74408461125793 24.791 35.67024488778573 139.74409777518406 24.791 35.670273255650784 139.74397845521102 24.791</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-50d591b0-d764-423b-8337-a5097374e02c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50d591b0-d764-423b-8337-a5097374e02c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50d591b0-d764-423b-8337-a5097374e02c">
											<gml:posList>35.67024239061561 139.74396358822995 25.63 35.670210120444885 139.7440837520201 25.63 35.670212248322336 139.74408461125793 25.63 35.67024405103458 139.74396613806084 25.63 35.670273255650784 139.74397845521102 25.63 35.67024488778573 139.74409777518406 25.63 35.67024673614757 139.74409851322508 25.63 35.67027610301203 139.74397713753456 25.63 35.67024239061561 139.74396358822995 25.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5b7da8df-eeb0-4fdb-a807-d8a9c83fd164">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b7da8df-eeb0-4fdb-a807-d8a9c83fd164">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b7da8df-eeb0-4fdb-a807-d8a9c83fd164">
											<gml:posList>35.6702746936401 139.74417950631855 17.628 35.67024673614757 139.74409851322508 25.088 35.67022984595536 139.74416142930858 25.088 35.6702746936401 139.74417950631855 17.628</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-58fe9551-8b1c-42f9-9d3b-0a82aa17af6f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-58fe9551-8b1c-42f9-9d3b-0a82aa17af6f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-58fe9551-8b1c-42f9-9d3b-0a82aa17af6f">
											<gml:posList>35.6702746936401 139.74417950631855 17.628 35.67027610301203 139.74397713753456 25.088 35.67024673614757 139.74409851322508 25.088 35.6702746936401 139.74417950631855 17.628</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-54291d14-cc74-44b9-896f-3326f6265f27">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-54291d14-cc74-44b9-896f-3326f6265f27">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-54291d14-cc74-44b9-896f-3326f6265f27">
											<gml:posList>35.6702746936401 139.74417950631855 17.628 35.670319697406576 139.74399466353572 17.628 35.67027610301203 139.74397713753456 25.088 35.6702746936401 139.74417950631855 17.628</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-42a8212f-6388-48a1-bdfe-292a7157efc5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-42a8212f-6388-48a1-bdfe-292a7157efc5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-42a8212f-6388-48a1-bdfe-292a7157efc5">
											<gml:posList>35.670319697406576 139.74399466353572 15.5 35.6702746936401 139.74417950631855 15.5 35.67028509858514 139.7441836923225 15.5 35.67033336630112 139.74400016038544 15.5 35.670319697406576 139.74399466353572 15.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-791810f7-b1c0-4258-b022-ffb7dca774cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-791810f7-b1c0-4258-b022-ffb7dca774cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-791810f7-b1c0-4258-b022-ffb7dca774cb">
											<gml:posList>35.670212248322336 139.74408461125793 25.63 35.670212248322336 139.74408461125793 24.791 35.67024405103458 139.74396613806084 24.791 35.67024405103458 139.74396613806084 25.63 35.670212248322336 139.74408461125793 25.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dd27c95e-56a5-4b8d-af6b-edbacdab7520">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd27c95e-56a5-4b8d-af6b-edbacdab7520">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd27c95e-56a5-4b8d-af6b-edbacdab7520">
											<gml:posList>35.670243384581276 139.74410059364854 31.572 35.670243384581276 139.74410059364854 30.143 35.67022814832398 139.74415731094953 30.143 35.67022814832398 139.74415731094953 31.572 35.670243384581276 139.74410059364854 31.572</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-44b586d2-1a66-4515-a4da-40a64722ddac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44b586d2-1a66-4515-a4da-40a64722ddac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44b586d2-1a66-4515-a4da-40a64722ddac">
											<gml:posList>35.670273255650784 139.74397845521102 25.63 35.670273255650784 139.74397845521102 24.791 35.67024488778573 139.74409777518406 24.791 35.67024488778573 139.74409777518406 25.63 35.670273255650784 139.74397845521102 25.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9fafb949-fdb2-4393-860a-9c74d28825ea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9fafb949-fdb2-4393-860a-9c74d28825ea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9fafb949-fdb2-4393-860a-9c74d28825ea">
											<gml:posList>35.67024405103458 139.74396613806084 25.63 35.67024405103458 139.74396613806084 24.791 35.670273255650784 139.74397845521102 24.791 35.670273255650784 139.74397845521102 25.63 35.67024405103458 139.74396613806084 25.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-405dc9bd-0fc3-4136-a2bb-d6852c63a5d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-405dc9bd-0fc3-4136-a2bb-d6852c63a5d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-405dc9bd-0fc3-4136-a2bb-d6852c63a5d6">
											<gml:posList>35.67027610301203 139.74397713753456 25.088 35.670319697406576 139.74399466353572 17.628 35.670319697406576 139.74399466353572 15.5 35.67033336630112 139.74400016038544 15.5 35.67033336630112 139.74400016038544 7.971 35.67024239061561 139.74396358822995 7.971 35.67024239061561 139.74396358822995 25.63 35.67027610301203 139.74397713753456 25.63 35.67027610301203 139.74397713753456 25.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-57de2664-6acd-4029-9316-0938ef6e2370">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-57de2664-6acd-4029-9316-0938ef6e2370">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-57de2664-6acd-4029-9316-0938ef6e2370">
											<gml:posList>35.67027610301203 139.74397713753456 25.63 35.67024673614757 139.74409851322508 25.63 35.67024673614757 139.74409851322508 25.088 35.67027610301203 139.74397713753456 25.088 35.67027610301203 139.74397713753456 25.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eb9c2d94-9032-46ef-9cf1-ec2fd19f5054">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eb9c2d94-9032-46ef-9cf1-ec2fd19f5054">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eb9c2d94-9032-46ef-9cf1-ec2fd19f5054">
											<gml:posList>35.670193221254706 139.7441466791342 7.971 35.670193221254706 139.7441466791342 31.572 35.670210120444885 139.7440837520201 31.572 35.670210120444885 139.7440837520201 25.63 35.67024239061561 139.74396358822995 25.63 35.67024239061561 139.74396358822995 7.971 35.670193221254706 139.7441466791342 7.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7b48a73b-b2d2-4906-8d02-6af34cd44806">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b48a73b-b2d2-4906-8d02-6af34cd44806">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b48a73b-b2d2-4906-8d02-6af34cd44806">
											<gml:posList>35.670319697406576 139.74399466353572 15.5 35.670319697406576 139.74399466353572 17.628 35.6702746936401 139.74417950631855 17.628 35.6702746936401 139.74417950631855 15.5 35.670319697406576 139.74399466353572 15.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d23dec6a-e29a-4d6c-adbe-dee48a8ab31a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d23dec6a-e29a-4d6c-adbe-dee48a8ab31a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d23dec6a-e29a-4d6c-adbe-dee48a8ab31a">
											<gml:posList>35.67024488778573 139.74409777518406 25.63 35.67024488778573 139.74409777518406 24.791 35.670212248322336 139.74408461125793 24.791 35.670212248322336 139.74408461125793 25.63 35.670210120444885 139.7440837520201 25.63 35.670210120444885 139.7440837520201 31.572 35.67024673614757 139.74409851322508 31.572 35.67024673614757 139.74409851322508 25.63 35.67024488778573 139.74409777518406 25.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-629da98c-2f29-45aa-8e9e-3a387be96e0a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-629da98c-2f29-45aa-8e9e-3a387be96e0a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-629da98c-2f29-45aa-8e9e-3a387be96e0a">
											<gml:posList>35.67028509858514 139.7441836923225 7.971 35.67033336630112 139.74400016038544 7.971 35.67033336630112 139.74400016038544 15.5 35.67028509858514 139.7441836923225 15.5 35.67028509858514 139.7441836923225 7.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ff154f29-5edc-4317-af70-0574d7f1d518">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff154f29-5edc-4317-af70-0574d7f1d518">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff154f29-5edc-4317-af70-0574d7f1d518">
											<gml:posList>35.67021182708433 139.7440878593204 31.572 35.67021182708433 139.7440878593204 30.143 35.670243384581276 139.74410059364854 30.143 35.670243384581276 139.74410059364854 31.572 35.67021182708433 139.7440878593204 31.572</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7a80a56f-a61a-49c0-b9b9-1db4e5b9962b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a80a56f-a61a-49c0-b9b9-1db4e5b9962b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a80a56f-a61a-49c0-b9b9-1db4e5b9962b">
											<gml:posList>35.67019659084929 139.7441445986939 31.572 35.67019659084929 139.7441445986939 30.143 35.67021182708433 139.7440878593204 30.143 35.67021182708433 139.7440878593204 31.572 35.67019659084929 139.7441445986939 31.572</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ac76b409-a751-4758-bd78-bff1aaff60ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ac76b409-a751-4758-bd78-bff1aaff60ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ac76b409-a751-4758-bd78-bff1aaff60ff">
											<gml:posList>35.67022984595536 139.74416142930858 31.572 35.67022984595536 139.74416142930858 25.088 35.67024673614757 139.74409851322508 25.088 35.67024673614757 139.74409851322508 25.63 35.67024673614757 139.74409851322508 31.572 35.67022984595536 139.74416142930858 31.572</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6feddcb9-e785-489b-a6f0-f896a7bbe196">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6feddcb9-e785-489b-a6f0-f896a7bbe196">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6feddcb9-e785-489b-a6f0-f896a7bbe196">
											<gml:posList>35.67022814832398 139.74415731094953 31.572 35.67022814832398 139.74415731094953 30.143 35.67019659084929 139.7441445986939 30.143 35.67019659084929 139.7441445986939 31.572 35.67022814832398 139.74415731094953 31.572</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-36a48a06-3b9c-47c0-9d2c-6c826971797d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36a48a06-3b9c-47c0-9d2c-6c826971797d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36a48a06-3b9c-47c0-9d2c-6c826971797d">
											<gml:posList>35.67028509858514 139.7441836923225 7.971 35.67028509858514 139.7441836923225 15.5 35.6702746936401 139.74417950631855 15.5 35.6702746936401 139.74417950631855 17.628 35.67022984595536 139.74416142930858 25.088 35.67022984595536 139.74416142930858 31.572 35.670193221254706 139.7441466791342 31.572 35.670193221254706 139.7441466791342 7.971 35.67028509858514 139.7441836923225 7.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2824</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">176.21905</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>