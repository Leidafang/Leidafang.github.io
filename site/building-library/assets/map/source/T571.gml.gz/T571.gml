<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_a62d1964-8d41-4718-99a5-9e88b1e61429">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">403</bldg:usage>
			<bldg:measuredHeight uom="m">25.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67182905614235 139.73936529955714 0 35.6718118089341 139.73934869485475 0 35.67179049986291 139.7393825551222 0 35.67178143438536 139.73937399369848 0 35.67174036468376 139.7394392821446 0 35.67178871499647 139.7394863938758 0 35.67183869119403 139.73939915671144 0 35.67182077567371 139.73938088476785 0 35.67182905614235 139.73936529955714 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67182905614235 139.73936529955714 9.703 35.67182077567371 139.73938088476785 9.703 35.67183869119403 139.73939915671144 9.703 35.67178871499647 139.7394863938758 9.703 35.67174036468376 139.7394392821446 9.703 35.67178143438536 139.73937399369848 9.703 35.67179049986291 139.7393825551222 9.703 35.6718118089341 139.73934869485475 9.703 35.67182905614235 139.73936529955714 9.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67182905614235 139.73936529955714 9.703 35.6718118089341 139.73934869485475 9.703 35.6718118089341 139.73934869485475 35.15 35.67182905614235 139.73936529955714 35.15 35.67182905614235 139.73936529955714 9.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6718118089341 139.73934869485475 9.703 35.67179049986291 139.7393825551222 9.703 35.67179049986291 139.7393825551222 35.15 35.6718118089341 139.73934869485475 35.15 35.6718118089341 139.73934869485475 9.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67179049986291 139.7393825551222 9.703 35.67178143438536 139.73937399369848 9.703 35.67178143438536 139.73937399369848 35.15 35.67179049986291 139.7393825551222 35.15 35.67179049986291 139.7393825551222 9.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67178143438536 139.73937399369848 9.703 35.67174036468376 139.7394392821446 9.703 35.67174036468376 139.7394392821446 35.15 35.67178143438536 139.73937399369848 35.15 35.67178143438536 139.73937399369848 9.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67174036468376 139.7394392821446 9.703 35.67178871499647 139.7394863938758 9.703 35.67178871499647 139.7394863938758 35.15 35.67174036468376 139.7394392821446 35.15 35.67174036468376 139.7394392821446 9.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67178871499647 139.7394863938758 9.703 35.67183869119403 139.73939915671144 9.703 35.67183869119403 139.73939915671144 35.15 35.67178871499647 139.7394863938758 35.15 35.67178871499647 139.7394863938758 9.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67183869119403 139.73939915671144 9.703 35.67182077567371 139.73938088476785 9.703 35.67182077567371 139.73938088476785 35.15 35.67183869119403 139.73939915671144 35.15 35.67183869119403 139.73939915671144 9.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67182077567371 139.73938088476785 9.703 35.67182905614235 139.73936529955714 9.703 35.67182905614235 139.73936529955714 35.15 35.67182077567371 139.73938088476785 35.15 35.67182077567371 139.73938088476785 9.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67182905614235 139.73936529955714 35.15 35.6718118089341 139.73934869485475 35.15 35.67179049986291 139.7393825551222 35.15 35.67178143438536 139.73937399369848 35.15 35.67174036468376 139.7394392821446 35.15 35.67178871499647 139.7394863938758 35.15 35.67183869119403 139.73939915671144 35.15 35.67182077567371 139.73938088476785 35.15 35.67182905614235 139.73936529955714 35.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-01ae29f7-02af-4441-ad49-21000fc458c2"/>
							<gml:surfaceMember xlink:href="#poly-11f391c2-882d-49fd-947e-85500977b08b"/>
							<gml:surfaceMember xlink:href="#poly-6929f5ed-b707-44ae-a499-71a830f1b83f"/>
							<gml:surfaceMember xlink:href="#poly-014799b1-3a6c-4a62-ba98-06d4c49683ac"/>
							<gml:surfaceMember xlink:href="#poly-7f45766d-0204-48bb-9ef1-e63d1a52747c"/>
							<gml:surfaceMember xlink:href="#poly-ce4e150c-34e9-4b7e-908c-bfa7beb6aca1"/>
							<gml:surfaceMember xlink:href="#poly-2a873c79-3887-4a80-9667-7c6ea635dec8"/>
							<gml:surfaceMember xlink:href="#poly-949cc23f-a48d-457b-aabf-29473ab2550d"/>
							<gml:surfaceMember xlink:href="#poly-1d2abff0-09e4-4d3b-a6e2-f76f9ba18d94"/>
							<gml:surfaceMember xlink:href="#poly-800441b6-af66-40c3-b7ad-23d18d032298"/>
							<gml:surfaceMember xlink:href="#poly-2c5ad0c9-f280-4a2c-a823-89dcc3ccd628"/>
							<gml:surfaceMember xlink:href="#poly-cdcc534f-17e7-4d86-94d2-5deb23dda407"/>
							<gml:surfaceMember xlink:href="#poly-d06b3d99-cd92-4963-8709-36e24ab30be0"/>
							<gml:surfaceMember xlink:href="#poly-aae05d41-9ad2-4f11-9c29-63435b5c301f"/>
							<gml:surfaceMember xlink:href="#poly-aaa651a9-036d-4725-8206-e984548c65c3"/>
							<gml:surfaceMember xlink:href="#poly-d0e085b3-2bb4-4286-9d1b-38854142670b"/>
							<gml:surfaceMember xlink:href="#poly-43eabe7d-b3e6-4d5c-af65-7ba7bc646fc5"/>
							<gml:surfaceMember xlink:href="#poly-598a63c2-69e6-44bc-aa12-53413c296525"/>
							<gml:surfaceMember xlink:href="#poly-4d3b4706-2426-4db0-a729-99573dc5ca49"/>
							<gml:surfaceMember xlink:href="#poly-a820afca-b01e-4c4e-89be-7c207ea6fa82"/>
							<gml:surfaceMember xlink:href="#poly-02c1fc1a-671f-4231-8b55-930f4848a262"/>
							<gml:surfaceMember xlink:href="#poly-026cd043-650a-499c-8f36-abc07a2ad76f"/>
							<gml:surfaceMember xlink:href="#poly-6f953f25-55ad-4c15-a402-2e3f21ba39a9"/>
							<gml:surfaceMember xlink:href="#poly-a7b134ce-733c-4e37-989a-8bc3ae73d331"/>
							<gml:surfaceMember xlink:href="#poly-47b39458-b6c6-4f30-9fe3-c0543dd94109"/>
							<gml:surfaceMember xlink:href="#poly-d70322a0-ec9e-45cd-bd27-5d4bac11596e"/>
							<gml:surfaceMember xlink:href="#poly-73fa15d3-ca8d-4a2e-8ad2-10b1886b0006"/>
							<gml:surfaceMember xlink:href="#poly-b904bf03-a927-4a66-9485-07445d05ba13"/>
							<gml:surfaceMember xlink:href="#poly-988fe0a9-f7d5-4862-aef2-4cbe53b93b99"/>
							<gml:surfaceMember xlink:href="#poly-a23b8893-ef5c-4423-a39f-9a3dfbeaee08"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_a62d1964-8d41-4718-99a5-9e88b1e61429_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef1a7d79-8631-4223-9802-81e8ae574aa2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671770226781945 139.7394503488551 35.446 35.671777996604476 139.73943877412145 35.446 35.671783318894285 139.73944414751074 35.446 35.671775549071235 139.73945572224463 35.446 35.671770226781945 139.7394503488551 35.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eca2b0fe-506c-4ddd-9c65-27410702446b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67180473923212 139.73941424176343 35.446 35.67179010057512 139.73943689309533 35.446 35.671775812022155 139.73942303548637 35.446 35.67179045066796 139.7394003731096 35.446 35.67180473923212 139.73941424176343 35.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9cebf324-e6d2-4865-83c0-81efdbf4686a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9cebf324-e6d2-4865-83c0-81efdbf4686a_0">
											<gml:posList>35.671770226781945 139.7394503488551 35.446 35.671775549071235 139.73945572224463 35.446 35.671775549071235 139.73945572224463 37.124 35.671770226781945 139.7394503488551 37.124 35.671770226781945 139.7394503488551 35.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d105dc44-a23a-4b7f-9c4c-31c6720a5049">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d105dc44-a23a-4b7f-9c4c-31c6720a5049_0">
											<gml:posList>35.671777996604476 139.73943877412145 35.446 35.671770226781945 139.7394503488551 35.446 35.671770226781945 139.7394503488551 37.124 35.671777996604476 139.73943877412145 37.124 35.671777996604476 139.73943877412145 35.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9c186eeb-6882-41a0-bda0-fc7e3ddefaef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9c186eeb-6882-41a0-bda0-fc7e3ddefaef_0">
											<gml:posList>35.671770226781945 139.7394503488551 37.124 35.671775549071235 139.73945572224463 37.124 35.671783318894285 139.73944414751074 37.124 35.671777996604476 139.73943877412145 37.124 35.671770226781945 139.7394503488551 37.124</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb916c11-14e0-4574-8dae-9f3814187e82">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb916c11-14e0-4574-8dae-9f3814187e82_0">
											<gml:posList>35.671775549071235 139.73945572224463 35.446 35.671783318894285 139.73944414751074 35.446 35.671783318894285 139.73944414751074 37.124 35.671775549071235 139.73945572224463 37.124 35.671775549071235 139.73945572224463 35.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca558949-95d0-43ce-8697-4570ee520e52">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ca558949-95d0-43ce-8697-4570ee520e52_0">
											<gml:posList>35.671783318894285 139.73944414751074 35.446 35.671777996604476 139.73943877412145 35.446 35.671777996604476 139.73943877412145 37.124 35.671783318894285 139.73944414751074 37.124 35.671783318894285 139.73944414751074 35.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c92198bc-7ec5-4cf8-b5e1-8bdf52b608ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c92198bc-7ec5-4cf8-b5e1-8bdf52b608ea_0">
											<gml:posList>35.671775812022155 139.73942303548637 35.446 35.67179010057512 139.73943689309533 35.446 35.67179010057512 139.73943689309533 37.728 35.671775812022155 139.73942303548637 37.728 35.671775812022155 139.73942303548637 35.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cad922f7-1b9f-47d8-8cd6-0c617490691e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cad922f7-1b9f-47d8-8cd6-0c617490691e_0">
											<gml:posList>35.67179045066796 139.7394003731096 35.446 35.671775812022155 139.73942303548637 35.446 35.671775812022155 139.73942303548637 37.728 35.67179045066796 139.7394003731096 37.728 35.67179045066796 139.7394003731096 35.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-41e69dd4-ca9f-41f2-9d8e-2c1eee1adc3c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-41e69dd4-ca9f-41f2-9d8e-2c1eee1adc3c_0">
											<gml:posList>35.671775812022155 139.73942303548637 37.728 35.67179010057512 139.73943689309533 37.728 35.67180473923212 139.73941424176343 37.728 35.67179045066796 139.7394003731096 37.728 35.671775812022155 139.73942303548637 37.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d06461d9-b8ae-414a-9c53-789f17d49541">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d06461d9-b8ae-414a-9c53-789f17d49541_0">
											<gml:posList>35.67179010057512 139.73943689309533 35.446 35.67180473923212 139.73941424176343 35.446 35.67180473923212 139.73941424176343 37.728 35.67179010057512 139.73943689309533 37.728 35.67179010057512 139.73943689309533 35.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b3795b1-a988-4c6d-ab11-35db2009727d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5b3795b1-a988-4c6d-ab11-35db2009727d_0">
											<gml:posList>35.67179045066796 139.7394003731096 35.446 35.67179045066796 139.7394003731096 37.728 35.67180473923212 139.73941424176343 37.728 35.67180473923212 139.73941424176343 35.446 35.67179045066796 139.7394003731096 35.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_a62d1964-8d41-4718-99a5-9e88b1e61429_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f5e6723-9066-44ec-9715-5da1237641ac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f5e6723-9066-44ec-9715-5da1237641ac_0">
											<gml:posList>35.67181875674689 139.73938107492356 35.792 35.671818774748466 139.73938104176307 35.515 35.67181800801338 139.73938031359538 35.792 35.67181875674689 139.73938107492356 35.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de1515a0-7cf7-4706-9908-f53ac9c57d2a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de1515a0-7cf7-4706-9908-f53ac9c57d2a_0">
											<gml:posList>35.67181196258121 139.73934922490457 38.268 35.671828785687616 139.7393652446418 38.268 35.671828785679 139.73936523359535 35.792 35.67181196258121 139.73934922490457 38.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f771e5d-95e9-433c-9411-627762b31539">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2f771e5d-95e9-433c-9411-627762b31539_0">
											<gml:posList>35.67181195355886 139.73934921386868 35.792 35.67181196258121 139.73934922490457 38.268 35.671828785679 139.73936523359535 35.792 35.67181195355886 139.73934921386868 35.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-094d4db7-7de2-4351-9ebb-ef18b65a9f95">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-094d4db7-7de2-4351-9ebb-ef18b65a9f95_0">
											<gml:posList>35.671827217636505 139.73936567729152 35.446 35.67181205414966 139.73935105850902 35.792 35.671827217636505 139.73936567729152 35.792 35.671827217636505 139.73936567729152 35.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9af53c84-4e56-45b5-9d06-558cf41d9e0b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9af53c84-4e56-45b5-9d06-558cf41d9e0b_0">
											<gml:posList>35.671827217636505 139.73936567729152 35.446 35.67181205414966 139.73935105850902 35.446 35.67181205414966 139.73935105850902 35.792 35.671827217636505 139.73936567729152 35.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1c1611b-39ee-4e72-8abb-5f867e46389e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a1c1611b-39ee-4e72-8abb-5f867e46389e_0">
											<gml:posList>35.67179071633872 139.73938274265822 35.792 35.67181196258121 139.73934922490457 38.268 35.67181195355886 139.73934921386868 35.792 35.67179071633872 139.73938274265822 35.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f922b6ba-30f6-446a-b6d6-4c43e6c787bc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f922b6ba-30f6-446a-b6d6-4c43e6c787bc_0">
											<gml:posList>35.67179071633872 139.73938274265822 35.792 35.67179071633872 139.73938274265822 38.268 35.67181196258121 139.73934922490457 38.268 35.67179071633872 139.73938274265822 35.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ed67d800-9d08-4795-a421-d4429d47465a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ed67d800-9d08-4795-a421-d4429d47465a_0">
											<gml:posList>35.67179159132462 139.7393835811634 35.792 35.67181205414966 139.73935105850902 35.446 35.67179159132462 139.7393835811634 35.446 35.67179159132462 139.7393835811634 35.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d1767b4-941b-4628-b275-405d572a7b9c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8d1767b4-941b-4628-b275-405d572a7b9c_0">
											<gml:posList>35.67179159132462 139.7393835811634 35.792 35.67181205414966 139.73935105850902 35.792 35.67181205414966 139.73935105850902 35.446 35.67179159132462 139.7393835811634 35.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ecefb670-8dc6-486a-b386-bfa5c6b79fc5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ecefb670-8dc6-486a-b386-bfa5c6b79fc5_0">
											<gml:posList>35.671827217636505 139.73936567729152 35.446 35.671827217636505 139.73936567729152 35.792 35.67182053926559 139.73937825598793 35.446 35.671827217636505 139.73936567729152 35.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53c289b2-c7c7-42b3-af10-cde00740186c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-53c289b2-c7c7-42b3-af10-cde00740186c_0">
											<gml:posList>35.67182053926559 139.73937825598793 35.446 35.67181800801338 139.73938031359538 35.792 35.671818774748466 139.73938104176307 35.515 35.67182053926559 139.73937825598793 35.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f35ded9-eaf5-458a-938e-6918bd686d0b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f35ded9-eaf5-458a-938e-6918bd686d0b_0">
											<gml:posList>35.67182053926559 139.73937825598793 35.446 35.671827217636505 139.73936567729152 35.792 35.67181800801338 139.73938031359538 35.792 35.67182053926559 139.73937825598793 35.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-34379d62-12ae-4c78-9606-3b179a98102f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-34379d62-12ae-4c78-9606-3b179a98102f_0">
											<gml:posList>35.67179071633872 139.73938274265822 38.268 35.671828785687616 139.7393652446418 38.268 35.67181196258121 139.73934922490457 38.268 35.67179071633872 139.73938274265822 38.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aaf8dc9f-b460-4c06-93ef-ce8b9b5a08ad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aaf8dc9f-b460-4c06-93ef-ce8b9b5a08ad_0">
											<gml:posList>35.67179071633872 139.73938274265822 38.268 35.67180753944073 139.73939876239828 38.268 35.671828785687616 139.7393652446418 38.268 35.67179071633872 139.73938274265822 38.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe415e38-92d2-401f-8fc1-1029484e8d5a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe415e38-92d2-401f-8fc1-1029484e8d5a_0">
											<gml:posList>35.671828785679 139.73936523359535 35.792 35.671828785687616 139.7393652446418 38.268 35.67181875674689 139.73938107492356 35.792 35.671828785679 139.73936523359535 35.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc1d3fb0-3d30-46ff-9d3b-c2eb69224bde">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cc1d3fb0-3d30-46ff-9d3b-c2eb69224bde_0">
											<gml:posList>35.67182053926559 139.73937825598793 35.446 35.671818774748466 139.73938104176307 35.515 35.67180753944073 139.73939876239828 35.446 35.67182053926559 139.73937825598793 35.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7d138f5e-0fe5-404e-8da6-b8418f41c861">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7d138f5e-0fe5-404e-8da6-b8418f41c861_0">
											<gml:posList>35.671818774748466 139.73938104176307 35.515 35.67181875674689 139.73938107492356 35.792 35.67180753944073 139.73939876239828 35.446 35.671818774748466 139.73938104176307 35.515</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-64daae38-afb7-4317-ad86-82944ed594e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-64daae38-afb7-4317-ad86-82944ed594e2_0">
											<gml:posList>35.67180753944073 139.73939876239828 35.446 35.67181875674689 139.73938107492356 35.792 35.67180753944073 139.73939876239828 38.268 35.67180753944073 139.73939876239828 35.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-55281865-c137-4dd0-bf7d-b3389f20e997">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-55281865-c137-4dd0-bf7d-b3389f20e997_0">
											<gml:posList>35.67181875674689 139.73938107492356 35.792 35.671828785687616 139.7393652446418 38.268 35.67180753944073 139.73939876239828 38.268 35.67181875674689 139.73938107492356 35.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b8a9cc9-2148-4723-be64-18e16d83ca5d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4b8a9cc9-2148-4723-be64-18e16d83ca5d_0">
											<gml:posList>35.67179071633872 139.73938274265822 35.792 35.67179159132462 139.7393835811634 35.792 35.67179071633872 139.73938274265822 38.268 35.67179071633872 139.73938274265822 35.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7019ee5a-2c78-45cb-b3ac-80d2b3a50c8e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7019ee5a-2c78-45cb-b3ac-80d2b3a50c8e_0">
											<gml:posList>35.67179071633872 139.73938274265822 38.268 35.67179159132462 139.7393835811634 35.792 35.67180753944073 139.73939876239828 38.268 35.67179071633872 139.73938274265822 38.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a86d3848-9035-441d-9717-01e52b119295">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a86d3848-9035-441d-9717-01e52b119295_0">
											<gml:posList>35.67180753944073 139.73939876239828 38.268 35.67179159132462 139.7393835811634 35.792 35.67180753944073 139.73939876239828 35.446 35.67180753944073 139.73939876239828 38.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2316d479-c3d9-4dcb-b269-fbf33eaa9d5f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2316d479-c3d9-4dcb-b269-fbf33eaa9d5f_0">
											<gml:posList>35.67179159132462 139.7393835811634 35.792 35.67179159132462 139.7393835811634 35.446 35.67180753944073 139.73939876239828 35.446 35.67179159132462 139.7393835811634 35.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de277cfb-3c43-44ff-897a-870318d0c80c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67179159132462 139.7393835811634 35.792 35.67179071633872 139.73938274265822 35.792 35.67181205414966 139.73935105850902 35.792 35.67179159132462 139.7393835811634 35.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73a197c6-1b39-42b8-9cf7-33a27071e07e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671827217636505 139.73936567729152 35.792 35.67181875674689 139.73938107492356 35.792 35.67181800801338 139.73938031359538 35.792 35.671827217636505 139.73936567729152 35.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-216e2d95-0dc8-43dc-93d6-5bd423d83e86">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67181875674689 139.73938107492356 35.792 35.671827217636505 139.73936567729152 35.792 35.671828785679 139.73936523359535 35.792 35.67181875674689 139.73938107492356 35.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0743ace3-f200-4c07-8506-8ed801f9215f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67179071633872 139.73938274265822 35.792 35.67181195355886 139.73934921386868 35.792 35.67181205414966 139.73935105850902 35.792 35.67179071633872 139.73938274265822 35.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb333735-66a4-48d3-8992-932a04e0fa9a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67181195355886 139.73934921386868 35.792 35.671828785679 139.73936523359535 35.792 35.67181205414966 139.73935105850902 35.792 35.67181195355886 139.73934921386868 35.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77fdc294-12f9-485b-bcec-4fd550305b8d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67181205414966 139.73935105850902 35.792 35.671828785679 139.73936523359535 35.792 35.671827217636505 139.73936567729152 35.792 35.67181205414966 139.73935105850902 35.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-83a31c68-c627-44eb-94ac-8de799095763">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67180753944073 139.73939876239828 35.446 35.67179159132462 139.7393835811634 35.446 35.67182053926559 139.73937825598793 35.446 35.67180753944073 139.73939876239828 35.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d2077a25-5e50-4848-9e5f-8eea02d30dc4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67182053926559 139.73937825598793 35.446 35.67181205414966 139.73935105850902 35.446 35.671827217636505 139.73936567729152 35.446 35.67182053926559 139.73937825598793 35.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ebfa137-cc25-4a78-979e-8d15a5cecbdc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67182053926559 139.73937825598793 35.446 35.67179159132462 139.7393835811634 35.446 35.67181205414966 139.73935105850902 35.446 35.67182053926559 139.73937825598793 35.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_a62d1964-8d41-4718-99a5-9e88b1e61429_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf58d781-9f79-4bea-81ec-439ab1c56828">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67185325558772 139.73937375487688 9.74 35.67183870020774 139.7393991567009 9.74 35.67182077568232 139.7393808958143 9.74 35.671834835795295 139.73935612422142 9.74 35.67185325558772 139.73937375487688 9.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-07fbbbe0-57d7-4ff3-992e-ebba6d2003d0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-07fbbbe0-57d7-4ff3-992e-ebba6d2003d0_0">
											<gml:posList>35.67185325558772 139.73937375487688 32.026 35.67185325558772 139.73937375487688 9.74 35.671834835795295 139.73935612422142 9.74 35.671834835795295 139.73935612422142 32.026 35.67185325558772 139.73937375487688 32.026</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd32f096-4f7e-4526-ac2e-162abd915cbe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bd32f096-4f7e-4526-ac2e-162abd915cbe_0">
											<gml:posList>35.671834835795295 139.73935612422142 32.026 35.671834835795295 139.73935612422142 9.74 35.67182077568232 139.7393808958143 9.74 35.67182077568232 139.7393808958143 32.026 35.671834835795295 139.73935612422142 32.026</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d11efc39-c758-4103-9495-3a45b51a817c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d11efc39-c758-4103-9495-3a45b51a817c_0">
											<gml:posList>35.67185325558772 139.73937375487688 32.026 35.671834835795295 139.73935612422142 32.026 35.67182077568232 139.7393808958143 32.026 35.67183870020774 139.7393991567009 32.026 35.67185325558772 139.73937375487688 32.026</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9336cce7-6a4b-4727-a036-8639c5da3465">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9336cce7-6a4b-4727-a036-8639c5da3465_0">
											<gml:posList>35.67183870020774 139.7393991567009 32.026 35.67183870020774 139.7393991567009 9.74 35.67185325558772 139.73937375487688 9.74 35.67185325558772 139.73937375487688 32.026 35.67183870020774 139.7393991567009 32.026</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b91386e5-3f35-4f3e-aac3-bb1307e567fc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b91386e5-3f35-4f3e-aac3-bb1307e567fc_0">
											<gml:posList>35.67183870020774 139.7393991567009 9.74 35.67183870020774 139.7393991567009 32.026 35.67182077568232 139.7393808958143 32.026 35.67182077568232 139.7393808958143 9.74 35.67183870020774 139.7393991567009 9.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-01ae29f7-02af-4441-ad49-21000fc458c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-01ae29f7-02af-4441-ad49-21000fc458c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-01ae29f7-02af-4441-ad49-21000fc458c2">
											<gml:posList>35.67182905614233 139.7393652995571 9.703 35.6718207756737 139.73938088476785 9.703 35.6718118089341 139.73934869485473 9.703 35.67182905614233 139.7393652995571 9.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-11f391c2-882d-49fd-947e-85500977b08b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11f391c2-882d-49fd-947e-85500977b08b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11f391c2-882d-49fd-947e-85500977b08b">
											<gml:posList>35.67178871499646 139.73948639387578 9.703 35.671740364683735 139.7394392821446 9.703 35.67178143438535 139.73937399369848 9.703 35.671790499862915 139.7393825551222 9.703 35.6718118089341 139.73934869485473 9.703 35.6718207756737 139.73938088476785 9.703 35.671838691194026 139.73939915671144 9.703 35.67178871499646 139.73948639387578 9.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6929f5ed-b707-44ae-a499-71a830f1b83f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6929f5ed-b707-44ae-a499-71a830f1b83f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6929f5ed-b707-44ae-a499-71a830f1b83f">
											<gml:posList>35.67178143438535 139.73937399369848 35.792 35.671740364683735 139.7394392821446 35.792 35.671742275368494 139.7394389926993 35.792 35.67178168860551 139.7393763462949 35.792 35.67178143438535 139.73937399369848 35.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-014799b1-3a6c-4a62-ba98-06d4c49683ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-014799b1-3a6c-4a62-ba98-06d4c49683ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-014799b1-3a6c-4a62-ba98-06d4c49683ac">
											<gml:posList>35.671740364683735 139.7394392821446 35.792 35.67178290574378 139.7394807338456 35.792 35.671782687571934 139.73947837016016 35.792 35.671742275368494 139.7394389926993 35.792 35.671740364683735 139.7394392821446 35.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7f45766d-0204-48bb-9ef1-e63d1a52747c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f45766d-0204-48bb-9ef1-e63d1a52747c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f45766d-0204-48bb-9ef1-e63d1a52747c">
											<gml:posList>35.671790499862915 139.7393825551222 35.792 35.67178143438535 139.73937399369848 35.792 35.67178168860551 139.7393763462949 35.792 35.67179075409151 139.73938491876538 35.792 35.671790499862915 139.7393825551222 35.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ce4e150c-34e9-4b7e-908c-bfa7beb6aca1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce4e150c-34e9-4b7e-908c-bfa7beb6aca1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce4e150c-34e9-4b7e-908c-bfa7beb6aca1">
											<gml:posList>35.67179075409151 139.73938491876538 35.446 35.67178168860551 139.7393763462949 35.446 35.671742275368494 139.7394389926993 35.446 35.671782687571934 139.73947837016016 35.446 35.671835057475555 139.7393976365574 35.446 35.67181800801338 139.73938031359538 35.446 35.671827217636505 139.73936567729152 35.446 35.67181205414966 139.73935105850902 35.446 35.67179075409151 139.73938491876538 35.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2a873c79-3887-4a80-9667-7c6ea635dec8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a873c79-3887-4a80-9667-7c6ea635dec8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a873c79-3887-4a80-9667-7c6ea635dec8">
											<gml:posList>35.6718118089341 139.73934869485473 35.792 35.671790499862915 139.7393825551222 35.792 35.67179075409151 139.73938491876538 35.792 35.67181205414966 139.73935105850902 35.792 35.6718118089341 139.73934869485473 35.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-949cc23f-a48d-457b-aabf-29473ab2550d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-949cc23f-a48d-457b-aabf-29473ab2550d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-949cc23f-a48d-457b-aabf-29473ab2550d">
											<gml:posList>35.67178290574378 139.7394807338456 35.792 35.67183696820327 139.73939740234303 35.792 35.67183505748417 139.73939764760385 35.792 35.671782687571934 139.73947837016016 35.792 35.67178290574378 139.7394807338456 35.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1d2abff0-09e4-4d3b-a6e2-f76f9ba18d94">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d2abff0-09e4-4d3b-a6e2-f76f9ba18d94">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d2abff0-09e4-4d3b-a6e2-f76f9ba18d94">
											<gml:posList>35.67178871499646 139.73948639387578 33.358 35.671838691194026 139.73939915671144 33.358 35.67183696820327 139.73939740234303 33.358 35.67178290574378 139.7394807338456 33.358 35.67178871499646 139.73948639387578 33.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-800441b6-af66-40c3-b7ad-23d18d032298">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-800441b6-af66-40c3-b7ad-23d18d032298">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-800441b6-af66-40c3-b7ad-23d18d032298">
											<gml:posList>35.67182905614233 139.7393652995571 35.792 35.6718118089341 139.73934869485473 35.792 35.67181205414966 139.73935105850902 35.792 35.671827217636505 139.73936567729152 35.792 35.67182905614233 139.7393652995571 35.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2c5ad0c9-f280-4a2c-a823-89dcc3ccd628">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c5ad0c9-f280-4a2c-a823-89dcc3ccd628">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c5ad0c9-f280-4a2c-a823-89dcc3ccd628">
											<gml:posList>35.671819819512585 139.7393799800788 35.792 35.67182905614233 139.7393652995571 35.792 35.671827217636505 139.73936567729152 35.792 35.67181800801338 139.73938031359538 35.792 35.671819819512585 139.7393799800788 35.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cdcc534f-17e7-4d86-94d2-5deb23dda407">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cdcc534f-17e7-4d86-94d2-5deb23dda407">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cdcc534f-17e7-4d86-94d2-5deb23dda407">
											<gml:posList>35.67183696820327 139.73939740234303 35.792 35.671819819512585 139.7393799800788 35.792 35.67181800801338 139.73938031359538 35.792 35.67183505748417 139.73939764760385 35.792 35.67183696820327 139.73939740234303 35.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d06b3d99-cd92-4963-8709-36e24ab30be0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d06b3d99-cd92-4963-8709-36e24ab30be0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d06b3d99-cd92-4963-8709-36e24ab30be0">
											<gml:posList>35.67178168860551 139.7393763462949 35.792 35.671742275368494 139.7394389926993 35.792 35.671742275368494 139.7394389926993 35.446 35.67178168860551 139.7393763462949 35.446 35.67178168860551 139.7393763462949 35.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aae05d41-9ad2-4f11-9c29-63435b5c301f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aae05d41-9ad2-4f11-9c29-63435b5c301f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aae05d41-9ad2-4f11-9c29-63435b5c301f">
											<gml:posList>35.67182905614233 139.7393652995571 9.703 35.6718118089341 139.73934869485473 9.703 35.6718118089341 139.73934869485473 35.792 35.67182905614233 139.7393652995571 35.792 35.67182905614233 139.7393652995571 9.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aaa651a9-036d-4725-8206-e984548c65c3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aaa651a9-036d-4725-8206-e984548c65c3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aaa651a9-036d-4725-8206-e984548c65c3">
											<gml:posList>35.671827217636505 139.73936567729152 35.792 35.67181205414966 139.73935105850902 35.792 35.67181205414966 139.73935105850902 35.446 35.671827217636505 139.73936567729152 35.446 35.671827217636505 139.73936567729152 35.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d0e085b3-2bb4-4286-9d1b-38854142670b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d0e085b3-2bb4-4286-9d1b-38854142670b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d0e085b3-2bb4-4286-9d1b-38854142670b">
											<gml:posList>35.6718118089341 139.73934869485473 35.792 35.6718118089341 139.73934869485473 9.703 35.671790499862915 139.7393825551222 9.703 35.671790499862915 139.7393825551222 35.792 35.6718118089341 139.73934869485473 35.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-43eabe7d-b3e6-4d5c-af65-7ba7bc646fc5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-43eabe7d-b3e6-4d5c-af65-7ba7bc646fc5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-43eabe7d-b3e6-4d5c-af65-7ba7bc646fc5">
											<gml:posList>35.67181205414966 139.73935105850902 35.792 35.67179075409151 139.73938491876538 35.792 35.67179075409151 139.73938491876538 35.446 35.67181205414966 139.73935105850902 35.446 35.67181205414966 139.73935105850902 35.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-598a63c2-69e6-44bc-aa12-53413c296525">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-598a63c2-69e6-44bc-aa12-53413c296525">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-598a63c2-69e6-44bc-aa12-53413c296525">
											<gml:posList>35.67181800801338 139.73938031359538 35.792 35.671827217636505 139.73936567729152 35.792 35.671827217636505 139.73936567729152 35.446 35.67181800801338 139.73938031359538 35.446 35.67181800801338 139.73938031359538 35.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4d3b4706-2426-4db0-a729-99573dc5ca49">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d3b4706-2426-4db0-a729-99573dc5ca49">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d3b4706-2426-4db0-a729-99573dc5ca49">
											<gml:posList>35.67182905614233 139.7393652995571 35.792 35.671819819512585 139.7393799800788 35.792 35.6718207756737 139.73938088476785 9.703 35.67182905614233 139.7393652995571 35.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a820afca-b01e-4c4e-89be-7c207ea6fa82">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a820afca-b01e-4c4e-89be-7c207ea6fa82">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a820afca-b01e-4c4e-89be-7c207ea6fa82">
											<gml:posList>35.67182905614233 139.7393652995571 35.792 35.6718207756737 139.73938088476785 9.703 35.67182905614233 139.7393652995571 9.703 35.67182905614233 139.7393652995571 35.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-02c1fc1a-671f-4231-8b55-930f4848a262">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-02c1fc1a-671f-4231-8b55-930f4848a262">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-02c1fc1a-671f-4231-8b55-930f4848a262">
											<gml:posList>35.67178143438535 139.73937399369848 9.703 35.67178143438535 139.73937399369848 35.792 35.671790499862915 139.7393825551222 35.792 35.671790499862915 139.7393825551222 9.703 35.67178143438535 139.73937399369848 9.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-026cd043-650a-499c-8f36-abc07a2ad76f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-026cd043-650a-499c-8f36-abc07a2ad76f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-026cd043-650a-499c-8f36-abc07a2ad76f">
											<gml:posList>35.67179075409151 139.73938491876538 35.792 35.67178168860551 139.7393763462949 35.792 35.67178168860551 139.7393763462949 35.446 35.67179075409151 139.73938491876538 35.446 35.67179075409151 139.73938491876538 35.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6f953f25-55ad-4c15-a402-2e3f21ba39a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f953f25-55ad-4c15-a402-2e3f21ba39a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f953f25-55ad-4c15-a402-2e3f21ba39a9">
											<gml:posList>35.67183505748417 139.73939764760385 35.792 35.67181800801338 139.73938031359538 35.792 35.67181800801338 139.73938031359538 35.446 35.671835057475555 139.7393976365574 35.446 35.67183505748417 139.73939764760385 35.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a7b134ce-733c-4e37-989a-8bc3ae73d331">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a7b134ce-733c-4e37-989a-8bc3ae73d331">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a7b134ce-733c-4e37-989a-8bc3ae73d331">
											<gml:posList>35.671819819512585 139.7393799800788 35.792 35.67183696820327 139.73939740234303 35.792 35.67183696820327 139.73939740234303 33.358 35.671838691194026 139.73939915671144 33.358 35.671838691194026 139.73939915671144 9.703 35.6718207756737 139.73938088476785 9.703 35.671819819512585 139.7393799800788 35.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-47b39458-b6c6-4f30-9fe3-c0543dd94109">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47b39458-b6c6-4f30-9fe3-c0543dd94109">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47b39458-b6c6-4f30-9fe3-c0543dd94109">
											<gml:posList>35.67178143438535 139.73937399369848 35.792 35.67178143438535 139.73937399369848 9.703 35.671740364683735 139.7394392821446 9.703 35.671740364683735 139.7394392821446 35.792 35.67178143438535 139.73937399369848 35.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d70322a0-ec9e-45cd-bd27-5d4bac11596e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d70322a0-ec9e-45cd-bd27-5d4bac11596e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d70322a0-ec9e-45cd-bd27-5d4bac11596e">
											<gml:posList>35.671782687571934 139.73947837016016 35.792 35.67183505748417 139.73939764760385 35.792 35.671835057475555 139.7393976365574 35.446 35.671782687571934 139.73947837016016 35.446 35.671782687571934 139.73947837016016 35.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-73fa15d3-ca8d-4a2e-8ad2-10b1886b0006">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73fa15d3-ca8d-4a2e-8ad2-10b1886b0006">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73fa15d3-ca8d-4a2e-8ad2-10b1886b0006">
											<gml:posList>35.67183696820327 139.73939740234303 33.358 35.67183696820327 139.73939740234303 35.792 35.67178290574378 139.7394807338456 35.792 35.67178290574378 139.7394807338456 33.358 35.67183696820327 139.73939740234303 33.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b904bf03-a927-4a66-9485-07445d05ba13">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b904bf03-a927-4a66-9485-07445d05ba13">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b904bf03-a927-4a66-9485-07445d05ba13">
											<gml:posList>35.67178871499646 139.73948639387578 9.703 35.671838691194026 139.73939915671144 9.703 35.671838691194026 139.73939915671144 33.358 35.67178871499646 139.73948639387578 33.358 35.67178871499646 139.73948639387578 9.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-988fe0a9-f7d5-4862-aef2-4cbe53b93b99">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-988fe0a9-f7d5-4862-aef2-4cbe53b93b99">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-988fe0a9-f7d5-4862-aef2-4cbe53b93b99">
											<gml:posList>35.671742275368494 139.7394389926993 35.792 35.671782687571934 139.73947837016016 35.792 35.671782687571934 139.73947837016016 35.446 35.671742275368494 139.7394389926993 35.446 35.671742275368494 139.7394389926993 35.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a23b8893-ef5c-4423-a39f-9a3dfbeaee08">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a23b8893-ef5c-4423-a39f-9a3dfbeaee08">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a23b8893-ef5c-4423-a39f-9a3dfbeaee08">
											<gml:posList>35.671740364683735 139.7394392821446 35.792 35.671740364683735 139.7394392821446 9.703 35.67178871499646 139.73948639387578 9.703 35.67178871499646 139.73948639387578 33.358 35.67178290574378 139.7394807338456 33.358 35.67178290574378 139.7394807338456 35.792 35.671740364683735 139.7394392821446 35.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7654</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">81.60695</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1241</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>