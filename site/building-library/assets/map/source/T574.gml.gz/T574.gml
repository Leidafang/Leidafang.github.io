<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_a6d57725-d221-4573-bdda-64180ab6cefd">
			<gml:name>山王パークタワー</gml:name>
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>46</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13101046002</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>永田町二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">199.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>44</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>3</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67344539625227 139.74046713423436 0 35.67342893323984 139.74045032921202 0 35.67341525767139 139.74043638205595 0 35.673472141438445 139.74035222877094 0 35.67344604575249 139.74032765807678 0 35.6734763872034 139.74028260763117 0 35.67323785111289 139.7400420674577 0 35.67309080544658 139.74028055862934 0 35.67307560932428 139.7403052102542 0 35.67278444231124 139.74077749161472 0 35.67265231238149 139.74099180405864 0 35.672879890140884 139.74120253206567 0 35.67290410686433 139.74116306784808 0 35.672926568441746 139.74118579804167 0 35.67298449526708 139.74109764572574 0 35.67303037122323 139.7411396143054 0 35.67308664070834 139.74105305446466 0 35.67317071321771 139.7411373540517 0 35.67331845812237 139.74091514618868 0 35.67329639372643 139.74089323295505 0 35.673324484226 139.74085113486385 0 35.67333671661862 139.7408638686062 0 35.673385020334 139.74079237405343 0 35.673412679031095 139.74075143628014 0 35.67348131250428 139.74064983796802 0 35.67339462287135 139.7405618961925 0 35.673453325555215 139.7404752222677 0 35.67344539625227 139.74046713423436 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67344539625227 139.74046713423436 8.194 35.673453325555215 139.7404752222677 8.194 35.67339462287135 139.7405618961925 8.194 35.67348131250428 139.74064983796802 8.194 35.673412679031095 139.74075143628014 8.194 35.673385020334 139.74079237405343 8.194 35.67333671661862 139.7408638686062 8.194 35.673324484226 139.74085113486385 8.194 35.67329639372643 139.74089323295505 8.194 35.67331845812237 139.74091514618868 8.194 35.67317071321771 139.7411373540517 8.194 35.67308664070834 139.74105305446466 8.194 35.67303037122323 139.7411396143054 8.194 35.67298449526708 139.74109764572574 8.194 35.672926568441746 139.74118579804167 8.194 35.67290410686433 139.74116306784808 8.194 35.672879890140884 139.74120253206567 8.194 35.67265231238149 139.74099180405864 8.194 35.67278444231124 139.74077749161472 8.194 35.67307560932428 139.7403052102542 8.194 35.67309080544658 139.74028055862934 8.194 35.67323785111289 139.7400420674577 8.194 35.6734763872034 139.74028260763117 8.194 35.67344604575249 139.74032765807678 8.194 35.673472141438445 139.74035222877094 8.194 35.67341525767139 139.74043638205595 8.194 35.67342893323984 139.74045032921202 8.194 35.67344539625227 139.74046713423436 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67344539625227 139.74046713423436 8.194 35.67342893323984 139.74045032921202 8.194 35.67342893323984 139.74045032921202 191.37 35.67344539625227 139.74046713423436 191.37 35.67344539625227 139.74046713423436 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67342893323984 139.74045032921202 8.194 35.67341525767139 139.74043638205595 8.194 35.67341525767139 139.74043638205595 191.37 35.67342893323984 139.74045032921202 191.37 35.67342893323984 139.74045032921202 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67341525767139 139.74043638205595 8.194 35.673472141438445 139.74035222877094 8.194 35.673472141438445 139.74035222877094 191.37 35.67341525767139 139.74043638205595 191.37 35.67341525767139 139.74043638205595 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673472141438445 139.74035222877094 8.194 35.67344604575249 139.74032765807678 8.194 35.67344604575249 139.74032765807678 191.37 35.673472141438445 139.74035222877094 191.37 35.673472141438445 139.74035222877094 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67344604575249 139.74032765807678 8.194 35.6734763872034 139.74028260763117 8.194 35.6734763872034 139.74028260763117 191.37 35.67344604575249 139.74032765807678 191.37 35.67344604575249 139.74032765807678 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6734763872034 139.74028260763117 8.194 35.67323785111289 139.7400420674577 8.194 35.67323785111289 139.7400420674577 191.37 35.6734763872034 139.74028260763117 191.37 35.6734763872034 139.74028260763117 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67323785111289 139.7400420674577 8.194 35.67309080544658 139.74028055862934 8.194 35.67309080544658 139.74028055862934 191.37 35.67323785111289 139.7400420674577 191.37 35.67323785111289 139.7400420674577 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67309080544658 139.74028055862934 8.194 35.67307560932428 139.7403052102542 8.194 35.67307560932428 139.7403052102542 191.37 35.67309080544658 139.74028055862934 191.37 35.67309080544658 139.74028055862934 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67307560932428 139.7403052102542 8.194 35.67278444231124 139.74077749161472 8.194 35.67278444231124 139.74077749161472 191.37 35.67307560932428 139.7403052102542 191.37 35.67307560932428 139.7403052102542 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67278444231124 139.74077749161472 8.194 35.67265231238149 139.74099180405864 8.194 35.67265231238149 139.74099180405864 191.37 35.67278444231124 139.74077749161472 191.37 35.67278444231124 139.74077749161472 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67265231238149 139.74099180405864 8.194 35.672879890140884 139.74120253206567 8.194 35.672879890140884 139.74120253206567 191.37 35.67265231238149 139.74099180405864 191.37 35.67265231238149 139.74099180405864 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672879890140884 139.74120253206567 8.194 35.67290410686433 139.74116306784808 8.194 35.67290410686433 139.74116306784808 191.37 35.672879890140884 139.74120253206567 191.37 35.672879890140884 139.74120253206567 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67290410686433 139.74116306784808 8.194 35.672926568441746 139.74118579804167 8.194 35.672926568441746 139.74118579804167 191.37 35.67290410686433 139.74116306784808 191.37 35.67290410686433 139.74116306784808 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672926568441746 139.74118579804167 8.194 35.67298449526708 139.74109764572574 8.194 35.67298449526708 139.74109764572574 191.37 35.672926568441746 139.74118579804167 191.37 35.672926568441746 139.74118579804167 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67298449526708 139.74109764572574 8.194 35.67303037122323 139.7411396143054 8.194 35.67303037122323 139.7411396143054 191.37 35.67298449526708 139.74109764572574 191.37 35.67298449526708 139.74109764572574 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67303037122323 139.7411396143054 8.194 35.67308664070834 139.74105305446466 8.194 35.67308664070834 139.74105305446466 191.37 35.67303037122323 139.7411396143054 191.37 35.67303037122323 139.7411396143054 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67308664070834 139.74105305446466 8.194 35.67317071321771 139.7411373540517 8.194 35.67317071321771 139.7411373540517 191.37 35.67308664070834 139.74105305446466 191.37 35.67308664070834 139.74105305446466 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67317071321771 139.7411373540517 8.194 35.67331845812237 139.74091514618868 8.194 35.67331845812237 139.74091514618868 191.37 35.67317071321771 139.7411373540517 191.37 35.67317071321771 139.7411373540517 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67331845812237 139.74091514618868 8.194 35.67329639372643 139.74089323295505 8.194 35.67329639372643 139.74089323295505 191.37 35.67331845812237 139.74091514618868 191.37 35.67331845812237 139.74091514618868 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67329639372643 139.74089323295505 8.194 35.673324484226 139.74085113486385 8.194 35.673324484226 139.74085113486385 191.37 35.67329639372643 139.74089323295505 191.37 35.67329639372643 139.74089323295505 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673324484226 139.74085113486385 8.194 35.67333671661862 139.7408638686062 8.194 35.67333671661862 139.7408638686062 191.37 35.673324484226 139.74085113486385 191.37 35.673324484226 139.74085113486385 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67333671661862 139.7408638686062 8.194 35.673385020334 139.74079237405343 8.194 35.673385020334 139.74079237405343 191.37 35.67333671661862 139.7408638686062 191.37 35.67333671661862 139.7408638686062 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673385020334 139.74079237405343 8.194 35.673412679031095 139.74075143628014 8.194 35.673412679031095 139.74075143628014 191.37 35.673385020334 139.74079237405343 191.37 35.673385020334 139.74079237405343 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673412679031095 139.74075143628014 8.194 35.67348131250428 139.74064983796802 8.194 35.67348131250428 139.74064983796802 191.37 35.673412679031095 139.74075143628014 191.37 35.673412679031095 139.74075143628014 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67348131250428 139.74064983796802 8.194 35.67339462287135 139.7405618961925 8.194 35.67339462287135 139.7405618961925 191.37 35.67348131250428 139.74064983796802 191.37 35.67348131250428 139.74064983796802 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67339462287135 139.7405618961925 8.194 35.673453325555215 139.7404752222677 8.194 35.673453325555215 139.7404752222677 191.37 35.67339462287135 139.7405618961925 191.37 35.67339462287135 139.7405618961925 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673453325555215 139.7404752222677 8.194 35.67344539625227 139.74046713423436 8.194 35.67344539625227 139.74046713423436 191.37 35.673453325555215 139.7404752222677 191.37 35.673453325555215 139.7404752222677 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67344539625227 139.74046713423436 191.37 35.67342893323984 139.74045032921202 191.37 35.67341525767139 139.74043638205595 191.37 35.673472141438445 139.74035222877094 191.37 35.67344604575249 139.74032765807678 191.37 35.6734763872034 139.74028260763117 191.37 35.67323785111289 139.7400420674577 191.37 35.67309080544658 139.74028055862934 191.37 35.67307560932428 139.7403052102542 191.37 35.67278444231124 139.74077749161472 191.37 35.67265231238149 139.74099180405864 191.37 35.672879890140884 139.74120253206567 191.37 35.67290410686433 139.74116306784808 191.37 35.672926568441746 139.74118579804167 191.37 35.67298449526708 139.74109764572574 191.37 35.67303037122323 139.7411396143054 191.37 35.67308664070834 139.74105305446466 191.37 35.67317071321771 139.7411373540517 191.37 35.67331845812237 139.74091514618868 191.37 35.67329639372643 139.74089323295505 191.37 35.673324484226 139.74085113486385 191.37 35.67333671661862 139.7408638686062 191.37 35.673385020334 139.74079237405343 191.37 35.673412679031095 139.74075143628014 191.37 35.67348131250428 139.74064983796802 191.37 35.67339462287135 139.7405618961925 191.37 35.673453325555215 139.7404752222677 191.37 35.67344539625227 139.74046713423436 191.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-d64f183a-49a0-4a2e-88bf-8fcf1acccf49"/>
							<gml:surfaceMember xlink:href="#poly-32b6a1c1-8ec7-4bc5-bc1c-dbd4715476ba"/>
							<gml:surfaceMember xlink:href="#poly-b9a1899c-2ffb-4723-b2a8-6b4344d1d23f"/>
							<gml:surfaceMember xlink:href="#poly-f34ab89b-d46e-4abe-8ce0-8fae06944593"/>
							<gml:surfaceMember xlink:href="#poly-8e56c0ee-bc01-49bc-95c0-5bad095d6a94"/>
							<gml:surfaceMember xlink:href="#poly-1c695736-6d56-4274-a2f6-696cde08b96b"/>
							<gml:surfaceMember xlink:href="#poly-80323748-6db4-4b8f-9e07-ec3f731e1b54"/>
							<gml:surfaceMember xlink:href="#poly-2fc0a788-8194-43f9-a49e-6c0a4cef0e5d"/>
							<gml:surfaceMember xlink:href="#poly-241251e5-7d37-483f-9bbd-92e54159fb29"/>
							<gml:surfaceMember xlink:href="#poly-bd0cbe2a-697c-442d-9651-278effab065f"/>
							<gml:surfaceMember xlink:href="#poly-6ca874bc-955a-4ecf-8da6-c4164bfcff50"/>
							<gml:surfaceMember xlink:href="#poly-d3141e05-e975-4ed0-b081-eee15aace99b"/>
							<gml:surfaceMember xlink:href="#poly-a775aca4-18a5-4d8c-9719-1440ebedb454"/>
							<gml:surfaceMember xlink:href="#poly-45282363-8a58-4205-b012-e8023599b200"/>
							<gml:surfaceMember xlink:href="#poly-c7bcbd67-323f-4aea-911e-b8729fd42879"/>
							<gml:surfaceMember xlink:href="#poly-06150f56-91e1-44e6-8b5e-1f08b50598bf"/>
							<gml:surfaceMember xlink:href="#poly-5c413f45-7175-4873-9f05-69e95ecbbc03"/>
							<gml:surfaceMember xlink:href="#poly-7ec518cb-e276-462f-b44f-e40bc03dd9d2"/>
							<gml:surfaceMember xlink:href="#poly-0ce95b3f-971b-4ecc-94e4-5e361ac5d8ea"/>
							<gml:surfaceMember xlink:href="#poly-1505c2e1-55da-4777-af67-f3ae1fa259a5"/>
							<gml:surfaceMember xlink:href="#poly-24e7baef-8005-401f-9ffd-574b479cc2f8"/>
							<gml:surfaceMember xlink:href="#poly-0aac7fc0-c843-408c-aee3-e50b12275495"/>
							<gml:surfaceMember xlink:href="#poly-7565cb36-3d93-4d80-92b0-e3d9c5d80cd0"/>
							<gml:surfaceMember xlink:href="#poly-5e0dcbe5-6ce6-4d12-a05a-65e37dba96c4"/>
							<gml:surfaceMember xlink:href="#poly-27f0b036-6253-4213-850b-da41e2e70ea3"/>
							<gml:surfaceMember xlink:href="#poly-5158a7fa-6448-4b3b-bcec-cb22171cd80a"/>
							<gml:surfaceMember xlink:href="#poly-67ab140c-2716-4eeb-bed9-8722c0ffc4c5"/>
							<gml:surfaceMember xlink:href="#poly-46b3275e-647b-4054-a73e-e80ec223e0af"/>
							<gml:surfaceMember xlink:href="#poly-4f75c7b6-cb16-4a2b-817a-d6ba049568bc"/>
							<gml:surfaceMember xlink:href="#poly-81c3b5b5-3982-4d2b-9135-8bda56df7435"/>
							<gml:surfaceMember xlink:href="#poly-3adbabd2-363f-4d9f-b0cd-97d63c1a1d2f"/>
							<gml:surfaceMember xlink:href="#poly-65808cf4-c864-433e-96d9-3d21b92966ce"/>
							<gml:surfaceMember xlink:href="#poly-14212328-e347-4c2b-b93b-12d5ab1183ff"/>
							<gml:surfaceMember xlink:href="#poly-83572789-1bd3-45d8-a226-3e5fc3125f97"/>
							<gml:surfaceMember xlink:href="#poly-a2c8fb6d-c03d-43fb-8935-0a442bb4f26f"/>
							<gml:surfaceMember xlink:href="#poly-735dc7ff-001b-4dc0-81e3-65019ed2fa1e"/>
							<gml:surfaceMember xlink:href="#poly-6e7447af-2992-4559-b504-271c5eeb3bdb"/>
							<gml:surfaceMember xlink:href="#poly-9fc111bd-4da9-43e5-a037-f767b79107c7"/>
							<gml:surfaceMember xlink:href="#poly-d8f90932-b28a-4ffd-8aab-e5636de5109c"/>
							<gml:surfaceMember xlink:href="#poly-0dd4427d-0225-4f4a-a4b0-3f8ae68ce44d"/>
							<gml:surfaceMember xlink:href="#poly-471eebb4-0f9a-4377-b6ff-9d6bc26a7dcc"/>
							<gml:surfaceMember xlink:href="#poly-7929f873-d184-4e6b-8422-906cf63a3909"/>
							<gml:surfaceMember xlink:href="#poly-367c0c86-5c0d-4615-8b02-fb1a8f7eb56e"/>
							<gml:surfaceMember xlink:href="#poly-b88a720e-aa66-4806-8c0b-d02aa51e1f75"/>
							<gml:surfaceMember xlink:href="#poly-086006c2-d468-418b-8d52-cdb5f95fa58e"/>
							<gml:surfaceMember xlink:href="#poly-f387bdd0-e5bf-49cc-a390-78ce7bd500b8"/>
							<gml:surfaceMember xlink:href="#poly-4126107c-a9f2-44eb-94aa-4c767852c1e2"/>
							<gml:surfaceMember xlink:href="#poly-83408d58-9ef2-489b-a5a6-9e7a52d7e8c9"/>
							<gml:surfaceMember xlink:href="#poly-5b81227c-e8a6-4c3f-98f2-8cd11496bea8"/>
							<gml:surfaceMember xlink:href="#poly-428090ea-6823-48fb-914e-e66ca50407ff"/>
							<gml:surfaceMember xlink:href="#poly-3cb7585b-d02b-4018-9ec9-6d6042f77f00"/>
							<gml:surfaceMember xlink:href="#poly-f64e201c-aa6e-49a3-b180-f66affbb8236"/>
							<gml:surfaceMember xlink:href="#poly-03602b7f-f735-40c7-8938-c3040c019575"/>
							<gml:surfaceMember xlink:href="#poly-5da21206-6b09-499f-b323-8ec6dc1bdb36"/>
							<gml:surfaceMember xlink:href="#poly-ca23109a-9c14-46da-8a47-a5d50a88df51"/>
							<gml:surfaceMember xlink:href="#poly-ea1ef0ae-cfea-4f5f-9e23-137ba290a275"/>
							<gml:surfaceMember xlink:href="#poly-1a0938e2-1843-4f4c-8835-cea62b6f694f"/>
							<gml:surfaceMember xlink:href="#poly-0044207b-6e4e-4ca3-8194-ccfe19777b60"/>
							<gml:surfaceMember xlink:href="#poly-5d46456b-a34e-4d4c-9443-a3d67a4442c4"/>
							<gml:surfaceMember xlink:href="#poly-7289eea5-05e8-4b86-9a8d-0ab4d92de70e"/>
							<gml:surfaceMember xlink:href="#poly-41f3ec02-7350-4edf-afc9-679e36022e12"/>
							<gml:surfaceMember xlink:href="#poly-dbaec6ad-3368-4978-b91d-4063c65a1ed2"/>
							<gml:surfaceMember xlink:href="#poly-79450154-8ccf-4f53-892d-5d6814c4a730"/>
							<gml:surfaceMember xlink:href="#poly-e8abfc45-2c4d-44fa-94c7-33857bc37956"/>
							<gml:surfaceMember xlink:href="#poly-c70f353a-3d6c-4c06-8dc2-a30f06705c37"/>
							<gml:surfaceMember xlink:href="#poly-92582a45-2465-4de4-8150-5ac811c25b21"/>
							<gml:surfaceMember xlink:href="#poly-6f7d88b9-48ac-4076-980c-356f3d0a6370"/>
							<gml:surfaceMember xlink:href="#poly-0b2968ed-aea4-484a-88b6-a46dfec1d117"/>
							<gml:surfaceMember xlink:href="#poly-94c0d8a4-c982-4e00-9139-c67b727e2e03"/>
							<gml:surfaceMember xlink:href="#poly-d48062ad-6565-4079-824c-90aa87e806e5"/>
							<gml:surfaceMember xlink:href="#poly-c8b38359-002b-4190-91fa-9bb7b0b9f586"/>
							<gml:surfaceMember xlink:href="#poly-373fa929-d8e6-4515-935c-02d4f7aa8b77"/>
							<gml:surfaceMember xlink:href="#poly-fcbc6d20-0313-4e63-b103-cdb77e663839"/>
							<gml:surfaceMember xlink:href="#poly-e04556d6-be20-452e-a3f2-1e62839e9868"/>
							<gml:surfaceMember xlink:href="#poly-45d5c9f6-f298-410b-85a0-0c659ba66a9a"/>
							<gml:surfaceMember xlink:href="#poly-194f2043-9ef5-41dc-90fc-676e381eaeb1"/>
							<gml:surfaceMember xlink:href="#poly-e04ed3eb-0b87-41f0-9e54-3929d31d964c"/>
							<gml:surfaceMember xlink:href="#poly-14e65b5c-2aeb-49b9-a884-169cbbc32c84"/>
							<gml:surfaceMember xlink:href="#poly-badf8299-2d66-4f16-8829-9f77354c69b1"/>
							<gml:surfaceMember xlink:href="#poly-105c985e-de9d-46c6-84a7-4c36d044e451"/>
							<gml:surfaceMember xlink:href="#poly-3254d3d1-9436-47ef-9bb8-c9a5739473d5"/>
							<gml:surfaceMember xlink:href="#poly-1267e915-c2cb-44ec-a9e4-6fcd6ed2d97d"/>
							<gml:surfaceMember xlink:href="#poly-0234e3cc-2130-433b-a02c-be5914e88384"/>
							<gml:surfaceMember xlink:href="#poly-d9745a71-d348-4cc9-98b3-2914864bf9cd"/>
							<gml:surfaceMember xlink:href="#poly-f5398e0b-d986-4f0c-a04c-27225a523a12"/>
							<gml:surfaceMember xlink:href="#poly-09536b8a-5b24-481e-bbe8-19d5e155870d"/>
							<gml:surfaceMember xlink:href="#poly-b6babe89-4364-4a94-a0b3-f6b8d287ef91"/>
							<gml:surfaceMember xlink:href="#poly-002a8813-077b-469d-b110-11c695df0a20"/>
							<gml:surfaceMember xlink:href="#poly-4ca66f86-daae-4f5b-8feb-9ff73c7d90fc"/>
							<gml:surfaceMember xlink:href="#poly-5bcdb46d-5289-4756-a24b-5d5332182d40"/>
							<gml:surfaceMember xlink:href="#poly-8c3f7fe0-4d31-49b2-a0f4-a3b3cd11493e"/>
							<gml:surfaceMember xlink:href="#poly-61f7b489-ab9b-4c08-a816-3468c28db434"/>
							<gml:surfaceMember xlink:href="#poly-70d52f88-7bb8-4d43-9c94-5c7f11bd58b6"/>
							<gml:surfaceMember xlink:href="#poly-2046f64a-579b-4ac5-ab84-4d7723fc5938"/>
							<gml:surfaceMember xlink:href="#poly-5c266bb4-b36c-46cf-8ea5-bf069a49f67a"/>
							<gml:surfaceMember xlink:href="#poly-08e2b227-d347-4e40-9366-915666daafc9"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-d64f183a-49a0-4a2e-88bf-8fcf1acccf49">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d64f183a-49a0-4a2e-88bf-8fcf1acccf49">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d64f183a-49a0-4a2e-88bf-8fcf1acccf49">
											<gml:posList>35.673394622871314 139.7405618961925 8.194 35.67348131250426 139.74064983796802 8.194 35.67345822760065 139.74068399890893 8.194 35.673310396236225 139.7405471138044 8.194 35.67321416910896 139.7404580124312 8.194 35.67306600372782 139.74032080819464 8.194 35.67323785111287 139.7400420674577 8.194 35.67347638720339 139.74028260763117 8.194 35.67344604575248 139.74032765807678 8.194 35.67347214143843 139.74035222877092 8.194 35.673415257671344 139.74043638205595 8.194 35.67345332555522 139.74047522226766 8.194 35.673394622871314 139.7405618961925 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-32b6a1c1-8ec7-4bc5-bc1c-dbd4715476ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-32b6a1c1-8ec7-4bc5-bc1c-dbd4715476ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-32b6a1c1-8ec7-4bc5-bc1c-dbd4715476ba">
											<gml:posList>35.67281490677092 139.7407280781645 8.194 35.67306600372782 139.74032080819464 8.194 35.67321416910896 139.7404580124312 8.194 35.672963080699894 139.7408652716691 8.194 35.67281490677092 139.7407280781645 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-b9a1899c-2ffb-4723-b2a8-6b4344d1d23f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b9a1899c-2ffb-4723-b2a8-6b4344d1d23f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b9a1899c-2ffb-4723-b2a8-6b4344d1d23f">
											<gml:posList>35.673310396236225 139.7405471138044 8.194 35.67345822760065 139.74068399890893 8.194 35.67333671661861 139.7408638686062 8.194 35.673324484225965 139.74085113486385 8.194 35.673296393726424 139.74089323295502 8.194 35.67331845812236 139.74091514618866 8.194 35.67320355746159 139.74108795985464 8.194 35.673059307538594 139.74095438430004 8.194 35.673310396236225 139.7405471138044 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-f34ab89b-d46e-4abe-8ce0-8fae06944593">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f34ab89b-d46e-4abe-8ce0-8fae06944593">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f34ab89b-d46e-4abe-8ce0-8fae06944593">
											<gml:posList>35.67281490677092 139.7407280781645 8.194 35.672963080699894 139.7408652716691 8.194 35.672971523555134 139.7408730939822 8.194 35.67265231238147 139.7409918040586 8.194 35.67281490677092 139.7407280781645 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-8e56c0ee-bc01-49bc-95c0-5bad095d6a94">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8e56c0ee-bc01-49bc-95c0-5bad095d6a94">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8e56c0ee-bc01-49bc-95c0-5bad095d6a94">
											<gml:posList>35.67304463177607 139.74094079176683 8.194 35.673030371223206 139.7411396143054 8.194 35.672984486253355 139.74109764573612 8.194 35.67292656844177 139.74118579804167 8.194 35.67290410686432 139.74116306784808 8.194 35.67287989014089 139.74120253206567 8.194 35.67265231238147 139.7409918040586 8.194 35.672971523555134 139.7408730939822 8.194 35.67304463177607 139.74094079176683 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-1c695736-6d56-4274-a2f6-696cde08b96b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c695736-6d56-4274-a2f6-696cde08b96b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c695736-6d56-4274-a2f6-696cde08b96b">
											<gml:posList>35.673059307538594 139.74095438430004 8.194 35.67320355746159 139.74108795985464 8.194 35.673170713217694 139.74113735405166 8.194 35.67308664070834 139.74105305446466 8.194 35.673030371223206 139.7411396143054 8.194 35.67304463177607 139.74094079176683 8.194 35.673059307538594 139.74095438430004 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-80323748-6db4-4b8f-9e07-ec3f731e1b54">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-80323748-6db4-4b8f-9e07-ec3f731e1b54">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-80323748-6db4-4b8f-9e07-ec3f731e1b54">
											<gml:posList>35.67277743145182 139.74089720055548 122.2 35.67281697773561 139.74083076492144 122.2 35.67278444231122 139.74077749161472 122.2 35.67265231238147 139.7409918040586 122.2 35.67287989014089 139.74120253206567 122.2 35.67290410686432 139.74116306784808 122.2 35.67278363408227 139.7410515142752 122.2 35.672839714430424 139.74096523102236 122.2 35.67281999565169 139.7409459774319 122.2 35.67287318593874 139.7408641491807 122.2 35.672851740519555 139.7408618541301 122.2 35.672812194218864 139.74092828977768 122.2 35.67277743145182 139.74089720055548 122.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2fc0a788-8194-43f9-a49e-6c0a4cef0e5d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2fc0a788-8194-43f9-a49e-6c0a4cef0e5d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2fc0a788-8194-43f9-a49e-6c0a4cef0e5d">
											<gml:posList>35.67277743145182 139.74089720055548 124.771 35.672812194218864 139.74092828977768 124.771 35.672851740519555 139.7408618541301 124.771 35.67281697773561 139.74083076492144 124.771 35.67277743145182 139.74089720055548 124.771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-241251e5-7d37-483f-9bbd-92e54159fb29">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-241251e5-7d37-483f-9bbd-92e54159fb29">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-241251e5-7d37-483f-9bbd-92e54159fb29">
											<gml:posList>35.67287318593874 139.7408641491807 122.2 35.67278444231122 139.74077749161472 122.2 35.67281697773561 139.74083076492144 122.2 35.672851740519555 139.7408618541301 122.2 35.67287318593874 139.7408641491807 122.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bd0cbe2a-697c-442d-9651-278effab065f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd0cbe2a-697c-442d-9651-278effab065f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd0cbe2a-697c-442d-9651-278effab065f">
											<gml:posList>35.67290386450551 139.74103494957612 187.071 35.672878689541456 139.7410119242976 187.071 35.672853626873206 139.74105307965186 187.071 35.672878801829505 139.74107610493616 187.071 35.67290386450551 139.74103494957612 187.071</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6ca874bc-955a-4ecf-8da6-c4164bfcff50">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ca874bc-955a-4ecf-8da6-c4164bfcff50">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ca874bc-955a-4ecf-8da6-c4164bfcff50">
											<gml:posList>35.672984486253355 139.74109764573612 182.5 35.67290386450551 139.74103494957612 182.5 35.672878801829505 139.74107610493616 182.5 35.672853626873206 139.74105307965186 182.5 35.672878689541456 139.7410119242976 182.5 35.672839714430424 139.74096523102236 182.5 35.67278363408227 139.7410515142752 182.5 35.67290410686432 139.74116306784808 182.5 35.67292656844177 139.74118579804167 182.5 35.672984486253355 139.74109764573612 182.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d3141e05-e975-4ed0-b081-eee15aace99b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3141e05-e975-4ed0-b081-eee15aace99b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3141e05-e975-4ed0-b081-eee15aace99b">
											<gml:posList>35.672878589235395 139.74076387292655 202.5 35.67291201950848 139.74079691891774 202.5 35.67293331210083 139.7407645609096 202.5 35.67289988182748 139.74073152596975 202.5 35.672878589235395 139.74076387292655 202.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a775aca4-18a5-4d8c-9719-1440ebedb454">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a775aca4-18a5-4d8c-9719-1440ebedb454">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a775aca4-18a5-4d8c-9719-1440ebedb454">
											<gml:posList>35.67290386450551 139.74103494957612 182.5 35.672984486253355 139.74109764573612 182.5 35.672839714430424 139.74096523102236 182.5 35.672878689541456 139.7410119242976 182.5 35.67290386450551 139.74103494957612 182.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-45282363-8a58-4205-b012-e8023599b200">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45282363-8a58-4205-b012-e8023599b200">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45282363-8a58-4205-b012-e8023599b200">
											<gml:posList>35.67289988182748 139.74073152596975 200.5 35.67307560932427 139.74030521025418 200.5 35.67278444231122 139.74077749161472 200.5 35.672878589235395 139.74076387292655 200.5 35.67289988182748 139.74073152596975 200.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c7bcbd67-323f-4aea-911e-b8729fd42879">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c7bcbd67-323f-4aea-911e-b8729fd42879">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c7bcbd67-323f-4aea-911e-b8729fd42879">
											<gml:posList>35.672916734227854 139.74096197190707 202.5 35.67298983338582 139.74102966973712 202.5 35.67304463177607 139.74094079176683 202.5 35.672971523555134 139.7408730939822 202.5 35.672916734227854 139.74096197190707 202.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-06150f56-91e1-44e6-8b5e-1f08b50598bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-06150f56-91e1-44e6-8b5e-1f08b50598bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-06150f56-91e1-44e6-8b5e-1f08b50598bf">
											<gml:posList>35.673059307538594 139.74095438430004 200.5 35.67304463177607 139.74094079176683 200.5 35.67298983338582 139.74102966973712 200.5 35.672916734227854 139.74096197190707 200.5 35.672971523555134 139.7408730939822 200.5 35.672963080699894 139.7408652716691 200.5 35.67321416910896 139.7404580124312 200.5 35.67329572234472 139.74032572255828 200.5 35.673271945149864 139.7403037010142 200.5 35.67324608380993 139.74027913012506 200.5 35.67318816023163 139.7403707077764 200.5 35.67309080544657 139.74028055862934 200.5 35.67307560932427 139.74030521025418 200.5 35.67289988182748 139.74073152596975 200.5 35.67293331210083 139.7407645609096 200.5 35.67291201950848 139.74079691891774 200.5 35.672878589235395 139.74076387292655 200.5 35.67278444231122 139.74077749161472 200.5 35.67287318593874 139.7408641491807 200.5 35.67281999565169 139.7409459774319 200.5 35.672839714430424 139.74096523102236 200.5 35.673030371223206 139.7411396143054 200.5 35.67308664070834 139.74105305446466 200.5 35.673170713217694 139.74113735405166 200.5 35.67331845812236 139.74091514618866 200.5 35.673296393726424 139.74089323295502 200.5 35.67328698743127 139.74088674836506 200.5 35.67326205799794 139.74084309863233 200.5 35.67329016229064 139.74081897344223 200.5 35.67331509173261 139.74086262318272 200.5 35.673324484225965 139.74085113486385 200.5 35.67333671661861 139.7408638686062 200.5 35.67338502033396 139.74079237405343 200.5 35.67335986143364 139.7407668521473 200.5 35.6733875201222 139.74072591437806 200.5 35.673412670017356 139.74075143629054 200.5 35.67348131250426 139.74064983796802 200.5 35.673394622871314 139.7405618961925 200.5 35.67345332555522 139.74047522226766 200.5 35.673415257671344 139.74043638205595 200.5 35.673391967587385 139.7404148127953 200.5 35.673310396236225 139.7405471138044 200.5 35.673059307538594 139.74095438430004 200.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5c413f45-7175-4873-9f05-69e95ecbbc03">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5c413f45-7175-4873-9f05-69e95ecbbc03">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5c413f45-7175-4873-9f05-69e95ecbbc03">
											<gml:posList>35.673232412575686 139.74027081681768 124.771 35.67319752222812 139.74023814819577 124.771 35.673156218446 139.74030438763742 124.771 35.673191099762136 139.74033705628185 124.771 35.673232412575686 139.74027081681768 124.771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7ec518cb-e276-462f-b44f-e40bc03dd9d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ec518cb-e276-462f-b44f-e40bc03dd9d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ec518cb-e276-462f-b44f-e40bc03dd9d2">
											<gml:posList>35.673191099762136 139.74033705628185 122.2 35.67318816023163 139.7403707077764 122.2 35.67324608380993 139.74027913012506 122.2 35.673232412575686 139.74027081681768 122.2 35.673191099762136 139.74033705628185 122.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0ce95b3f-971b-4ecc-94e4-5e361ac5d8ea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ce95b3f-971b-4ecc-94e4-5e361ac5d8ea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ce95b3f-971b-4ecc-94e4-5e361ac5d8ea">
											<gml:posList>35.67327299308903 139.74024842232149 126.154 35.673250711253644 139.74028353236918 126.154 35.673271945149864 139.7403037010142 126.154 35.67329402815135 139.74026789525396 126.154 35.67327299308903 139.74024842232149 126.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1505c2e1-55da-4777-af67-f3ae1fa259a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1505c2e1-55da-4777-af67-f3ae1fa259a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1505c2e1-55da-4777-af67-f3ae1fa259a5">
											<gml:posList>35.67309080544657 139.74028055862934 122.2 35.67318816023163 139.7403707077764 122.2 35.673191099762136 139.74033705628185 122.2 35.673156218446 139.74030438763742 122.2 35.67319752222812 139.74023814819577 122.2 35.673232412575686 139.74027081681768 122.2 35.67324608380993 139.74027913012506 122.2 35.673250711253644 139.74028353236918 122.2 35.67327299308903 139.74024842232149 122.2 35.67329402815135 139.74026789525396 122.2 35.67332654495495 139.7402151538657 122.2 35.67344604575248 139.74032765807678 122.2 35.67347638720339 139.74028260763117 122.2 35.67323785111287 139.7400420674577 122.2 35.67309080544657 139.74028055862934 122.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-24e7baef-8005-401f-9ffd-574b479cc2f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-24e7baef-8005-401f-9ffd-574b479cc2f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-24e7baef-8005-401f-9ffd-574b479cc2f8">
											<gml:posList>35.67326205799794 139.74084309863233 207.546 35.67328698743127 139.74088674836506 207.546 35.67331509173261 139.74086262318272 207.546 35.67329016229064 139.74081897344223 207.546 35.67326205799794 139.74084309863233 207.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0aac7fc0-c843-408c-aee3-e50b12275495">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0aac7fc0-c843-408c-aee3-e50b12275495">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0aac7fc0-c843-408c-aee3-e50b12275495">
											<gml:posList>35.673310396236225 139.7405471138044 200.5 35.673391967587385 139.7404148127953 200.5 35.67329572234472 139.74032572255828 200.5 35.67321416910896 139.7404580124312 200.5 35.673310396236225 139.7405471138044 200.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7565cb36-3d93-4d80-92b0-e3d9c5d80cd0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7565cb36-3d93-4d80-92b0-e3d9c5d80cd0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7565cb36-3d93-4d80-92b0-e3d9c5d80cd0">
											<gml:posList>35.673296393726424 139.74089323295502 200.5 35.673324484225965 139.74085113486385 200.5 35.67331509173261 139.74086262318272 200.5 35.67328698743127 139.74088674836506 200.5 35.673296393726424 139.74089323295502 200.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5e0dcbe5-6ce6-4d12-a05a-65e37dba96c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e0dcbe5-6ce6-4d12-a05a-65e37dba96c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e0dcbe5-6ce6-4d12-a05a-65e37dba96c4">
											<gml:posList>35.673339656278706 139.7402920565802 186.44 35.67331308063802 139.7403346170776 186.44 35.673338102837626 139.7403580843116 186.44 35.673364678486486 139.74031552380865 186.44 35.673339656278706 139.7402920565802 186.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-27f0b036-6253-4213-850b-da41e2e70ea3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-27f0b036-6253-4213-850b-da41e2e70ea3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-27f0b036-6253-4213-850b-da41e2e70ea3">
											<gml:posList>35.673338102837626 139.7403580843116 182.019 35.67331308063802 139.7403346170776 182.019 35.673271945149864 139.7403037010142 182.019 35.673415257671344 139.74043638205595 182.019 35.673338102837626 139.7403580843116 182.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5158a7fa-6448-4b3b-bcec-cb22171cd80a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5158a7fa-6448-4b3b-bcec-cb22171cd80a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5158a7fa-6448-4b3b-bcec-cb22171cd80a">
											<gml:posList>35.673364678486486 139.74031552380865 182.019 35.673338102837626 139.7403580843116 182.019 35.673415257671344 139.74043638205595 182.019 35.67347214143843 139.74035222877092 182.019 35.67332654495495 139.7402151538657 182.019 35.673271945149864 139.7403037010142 182.019 35.67331308063802 139.7403346170776 182.019 35.673339656278706 139.7402920565802 182.019 35.673364678486486 139.74031552380865 182.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-67ab140c-2716-4eeb-bed9-8722c0ffc4c5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67ab140c-2716-4eeb-bed9-8722c0ffc4c5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67ab140c-2716-4eeb-bed9-8722c0ffc4c5">
											<gml:posList>35.6733875201222 139.74072591437806 207 35.67335986143364 139.7407668521473 207 35.67338502033396 139.74079237405343 207 35.673412670017356 139.74075143629054 207 35.6733875201222 139.74072591437806 207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-46b3275e-647b-4054-a73e-e80ec223e0af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-46b3275e-647b-4054-a73e-e80ec223e0af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-46b3275e-647b-4054-a73e-e80ec223e0af">
											<gml:posList>35.673191099762136 139.74033705628185 124.771 35.673156218446 139.74030438763742 124.771 35.673156218446 139.74030438763742 122.2 35.673191099762136 139.74033705628185 122.2 35.673191099762136 139.74033705628185 124.771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4f75c7b6-cb16-4a2b-817a-d6ba049568bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f75c7b6-cb16-4a2b-817a-d6ba049568bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f75c7b6-cb16-4a2b-817a-d6ba049568bc">
											<gml:posList>35.673338102837626 139.7403580843116 186.44 35.67331308063802 139.7403346170776 186.44 35.67331308063802 139.7403346170776 182.019 35.673338102837626 139.7403580843116 182.019 35.673338102837626 139.7403580843116 186.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-81c3b5b5-3982-4d2b-9135-8bda56df7435">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-81c3b5b5-3982-4d2b-9135-8bda56df7435">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-81c3b5b5-3982-4d2b-9135-8bda56df7435">
											<gml:posList>35.673059307538594 139.74095438430004 8.194 35.673059307538594 139.74095438430004 200.5 35.673310396236225 139.7405471138044 200.5 35.673310396236225 139.7405471138044 8.194 35.673059307538594 139.74095438430004 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3adbabd2-363f-4d9f-b0cd-97d63c1a1d2f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3adbabd2-363f-4d9f-b0cd-97d63c1a1d2f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3adbabd2-363f-4d9f-b0cd-97d63c1a1d2f">
											<gml:posList>35.672851740519555 139.7408618541301 124.771 35.672851740519555 139.7408618541301 122.2 35.67281697773561 139.74083076492144 122.2 35.67281697773561 139.74083076492144 124.771 35.672851740519555 139.7408618541301 124.771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-65808cf4-c864-433e-96d9-3d21b92966ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65808cf4-c864-433e-96d9-3d21b92966ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65808cf4-c864-433e-96d9-3d21b92966ce">
											<gml:posList>35.672851740519555 139.7408618541301 124.771 35.672812194218864 139.74092828977768 124.771 35.672812194218864 139.74092828977768 122.2 35.672851740519555 139.7408618541301 122.2 35.672851740519555 139.7408618541301 124.771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-14212328-e347-4c2b-b93b-12d5ab1183ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-14212328-e347-4c2b-b93b-12d5ab1183ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-14212328-e347-4c2b-b93b-12d5ab1183ff">
											<gml:posList>35.67290386450551 139.74103494957612 182.5 35.672878689541456 139.7410119242976 182.5 35.672878689541456 139.7410119242976 187.071 35.67290386450551 139.74103494957612 187.071 35.67290386450551 139.74103494957612 182.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-83572789-1bd3-45d8-a226-3e5fc3125f97">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83572789-1bd3-45d8-a226-3e5fc3125f97">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83572789-1bd3-45d8-a226-3e5fc3125f97">
											<gml:posList>35.67265231238147 139.7409918040586 122.2 35.67265231238147 139.7409918040586 8.194 35.67287989014089 139.74120253206567 8.194 35.67287989014089 139.74120253206567 122.2 35.67265231238147 139.7409918040586 122.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a2c8fb6d-c03d-43fb-8935-0a442bb4f26f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2c8fb6d-c03d-43fb-8935-0a442bb4f26f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2c8fb6d-c03d-43fb-8935-0a442bb4f26f">
											<gml:posList>35.672812194218864 139.74092828977768 124.771 35.67277743145182 139.74089720055548 124.771 35.67277743145182 139.74089720055548 122.2 35.672812194218864 139.74092828977768 122.2 35.672812194218864 139.74092828977768 124.771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-735dc7ff-001b-4dc0-81e3-65019ed2fa1e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-735dc7ff-001b-4dc0-81e3-65019ed2fa1e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-735dc7ff-001b-4dc0-81e3-65019ed2fa1e">
											<gml:posList>35.67277743145182 139.74089720055548 122.2 35.67277743145182 139.74089720055548 124.771 35.67281697773561 139.74083076492144 124.771 35.67281697773561 139.74083076492144 122.2 35.67277743145182 139.74089720055548 122.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6e7447af-2992-4559-b504-271c5eeb3bdb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e7447af-2992-4559-b504-271c5eeb3bdb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e7447af-2992-4559-b504-271c5eeb3bdb">
											<gml:posList>35.67278363408227 139.7410515142752 122.2 35.67278363408227 139.7410515142752 182.5 35.672839714430424 139.74096523102236 182.5 35.672839714430424 139.74096523102236 122.2 35.67278363408227 139.7410515142752 122.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9fc111bd-4da9-43e5-a037-f767b79107c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9fc111bd-4da9-43e5-a037-f767b79107c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9fc111bd-4da9-43e5-a037-f767b79107c7">
											<gml:posList>35.67287318593874 139.7408641491807 122.2 35.67287318593874 139.7408641491807 200.5 35.67278444231122 139.74077749161472 200.5 35.67278444231122 139.74077749161472 122.2 35.67287318593874 139.7408641491807 122.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d8f90932-b28a-4ffd-8aab-e5636de5109c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d8f90932-b28a-4ffd-8aab-e5636de5109c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d8f90932-b28a-4ffd-8aab-e5636de5109c">
											<gml:posList>35.67281999565169 139.7409459774319 122.2 35.672839714430424 139.74096523102236 122.2 35.672839714430424 139.74096523102236 182.5 35.672839714430424 139.74096523102236 200.5 35.67281999565169 139.7409459774319 200.5 35.67281999565169 139.7409459774319 122.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0dd4427d-0225-4f4a-a4b0-3f8ae68ce44d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0dd4427d-0225-4f4a-a4b0-3f8ae68ce44d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0dd4427d-0225-4f4a-a4b0-3f8ae68ce44d">
											<gml:posList>35.67278363408227 139.7410515142752 182.5 35.67278363408227 139.7410515142752 122.2 35.67290410686432 139.74116306784808 122.2 35.67290410686432 139.74116306784808 182.5 35.67278363408227 139.7410515142752 182.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-471eebb4-0f9a-4377-b6ff-9d6bc26a7dcc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-471eebb4-0f9a-4377-b6ff-9d6bc26a7dcc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-471eebb4-0f9a-4377-b6ff-9d6bc26a7dcc">
											<gml:posList>35.67287318593874 139.7408641491807 200.5 35.67287318593874 139.7408641491807 122.2 35.67281999565169 139.7409459774319 122.2 35.67281999565169 139.7409459774319 200.5 35.67287318593874 139.7408641491807 200.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7929f873-d184-4e6b-8422-906cf63a3909">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7929f873-d184-4e6b-8422-906cf63a3909">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7929f873-d184-4e6b-8422-906cf63a3909">
											<gml:posList>35.672878689541456 139.7410119242976 182.5 35.672853626873206 139.74105307965186 182.5 35.672853626873206 139.74105307965186 187.071 35.672878689541456 139.7410119242976 187.071 35.672878689541456 139.7410119242976 182.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-367c0c86-5c0d-4615-8b02-fb1a8f7eb56e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-367c0c86-5c0d-4615-8b02-fb1a8f7eb56e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-367c0c86-5c0d-4615-8b02-fb1a8f7eb56e">
											<gml:posList>35.672878801829505 139.74107610493616 187.071 35.672853626873206 139.74105307965186 187.071 35.672853626873206 139.74105307965186 182.5 35.672878801829505 139.74107610493616 182.5 35.672878801829505 139.74107610493616 187.071</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b88a720e-aa66-4806-8c0b-d02aa51e1f75">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b88a720e-aa66-4806-8c0b-d02aa51e1f75">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b88a720e-aa66-4806-8c0b-d02aa51e1f75">
											<gml:posList>35.67289988182748 139.74073152596975 200.5 35.672878589235395 139.74076387292655 200.5 35.672878589235395 139.74076387292655 202.5 35.67289988182748 139.74073152596975 202.5 35.67289988182748 139.74073152596975 200.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-086006c2-d468-418b-8d52-cdb5f95fa58e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-086006c2-d468-418b-8d52-cdb5f95fa58e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-086006c2-d468-418b-8d52-cdb5f95fa58e">
											<gml:posList>35.67290386450551 139.74103494957612 187.071 35.672878801829505 139.74107610493616 187.071 35.672878801829505 139.74107610493616 182.5 35.67290386450551 139.74103494957612 182.5 35.67290386450551 139.74103494957612 187.071</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f387bdd0-e5bf-49cc-a390-78ce7bd500b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f387bdd0-e5bf-49cc-a390-78ce7bd500b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f387bdd0-e5bf-49cc-a390-78ce7bd500b8">
											<gml:posList>35.67290410686432 139.74116306784808 122.2 35.67287989014089 139.74120253206567 122.2 35.67287989014089 139.74120253206567 8.194 35.67290410686432 139.74116306784808 8.194 35.67290410686432 139.74116306784808 122.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4126107c-a9f2-44eb-94aa-4c767852c1e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4126107c-a9f2-44eb-94aa-4c767852c1e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4126107c-a9f2-44eb-94aa-4c767852c1e2">
											<gml:posList>35.67291201950848 139.74079691891774 200.5 35.67291201950848 139.74079691891774 202.5 35.672878589235395 139.74076387292655 202.5 35.672878589235395 139.74076387292655 200.5 35.67291201950848 139.74079691891774 200.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-83408d58-9ef2-489b-a5a6-9e7a52d7e8c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83408d58-9ef2-489b-a5a6-9e7a52d7e8c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83408d58-9ef2-489b-a5a6-9e7a52d7e8c9">
											<gml:posList>35.67292656844177 139.74118579804167 8.194 35.67292656844177 139.74118579804167 182.5 35.67290410686432 139.74116306784808 182.5 35.67290410686432 139.74116306784808 122.2 35.67290410686432 139.74116306784808 8.194 35.67292656844177 139.74118579804167 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5b81227c-e8a6-4c3f-98f2-8cd11496bea8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b81227c-e8a6-4c3f-98f2-8cd11496bea8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b81227c-e8a6-4c3f-98f2-8cd11496bea8">
											<gml:posList>35.67293331210083 139.7407645609096 200.5 35.67289988182748 139.74073152596975 200.5 35.67289988182748 139.74073152596975 202.5 35.67293331210083 139.7407645609096 202.5 35.67293331210083 139.7407645609096 200.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-428090ea-6823-48fb-914e-e66ca50407ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-428090ea-6823-48fb-914e-e66ca50407ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-428090ea-6823-48fb-914e-e66ca50407ff">
											<gml:posList>35.67291201950848 139.74079691891774 200.5 35.67293331210083 139.7407645609096 200.5 35.67293331210083 139.7407645609096 202.5 35.67291201950848 139.74079691891774 202.5 35.67291201950848 139.74079691891774 200.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3cb7585b-d02b-4018-9ec9-6d6042f77f00">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3cb7585b-d02b-4018-9ec9-6d6042f77f00">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3cb7585b-d02b-4018-9ec9-6d6042f77f00">
											<gml:posList>35.672984486253355 139.74109764573612 182.5 35.672984486253355 139.74109764573612 8.194 35.673030371223206 139.7411396143054 8.194 35.673030371223206 139.7411396143054 200.5 35.672839714430424 139.74096523102236 200.5 35.672839714430424 139.74096523102236 182.5 35.672984486253355 139.74109764573612 182.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f64e201c-aa6e-49a3-b180-f66affbb8236">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f64e201c-aa6e-49a3-b180-f66affbb8236">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f64e201c-aa6e-49a3-b180-f66affbb8236">
											<gml:posList>35.672971523555134 139.7408730939822 202.5 35.672971523555134 139.7408730939822 200.5 35.672916734227854 139.74096197190707 200.5 35.672916734227854 139.74096197190707 202.5 35.672971523555134 139.7408730939822 202.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-03602b7f-f735-40c7-8938-c3040c019575">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03602b7f-f735-40c7-8938-c3040c019575">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03602b7f-f735-40c7-8938-c3040c019575">
											<gml:posList>35.67309080544657 139.74028055862934 122.2 35.67323785111287 139.7400420674577 122.2 35.67323785111287 139.7400420674577 8.194 35.67306600372782 139.74032080819464 8.194 35.67281490677092 139.7407280781645 8.194 35.67265231238147 139.7409918040586 8.194 35.67265231238147 139.7409918040586 122.2 35.67278444231122 139.74077749161472 122.2 35.67278444231122 139.74077749161472 200.5 35.67307560932427 139.74030521025418 200.5 35.67309080544657 139.74028055862934 200.5 35.67309080544657 139.74028055862934 122.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5da21206-6b09-499f-b323-8ec6dc1bdb36">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5da21206-6b09-499f-b323-8ec6dc1bdb36">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5da21206-6b09-499f-b323-8ec6dc1bdb36">
											<gml:posList>35.67298983338582 139.74102966973712 200.5 35.67298983338582 139.74102966973712 202.5 35.672916734227854 139.74096197190707 202.5 35.672916734227854 139.74096197190707 200.5 35.67298983338582 139.74102966973712 200.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ca23109a-9c14-46da-8a47-a5d50a88df51">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca23109a-9c14-46da-8a47-a5d50a88df51">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca23109a-9c14-46da-8a47-a5d50a88df51">
											<gml:posList>35.67292656844177 139.74118579804167 8.194 35.672984486253355 139.74109764573612 8.194 35.672984486253355 139.74109764573612 182.5 35.67292656844177 139.74118579804167 182.5 35.67292656844177 139.74118579804167 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ea1ef0ae-cfea-4f5f-9e23-137ba290a275">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea1ef0ae-cfea-4f5f-9e23-137ba290a275">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea1ef0ae-cfea-4f5f-9e23-137ba290a275">
											<gml:posList>35.672963080699894 139.7408652716691 200.5 35.672971523555134 139.7408730939822 200.5 35.672971523555134 139.7408730939822 8.194 35.672963080699894 139.7408652716691 8.194 35.672963080699894 139.7408652716691 200.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1a0938e2-1843-4f4c-8835-cea62b6f694f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a0938e2-1843-4f4c-8835-cea62b6f694f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a0938e2-1843-4f4c-8835-cea62b6f694f">
											<gml:posList>35.67304463177607 139.74094079176683 202.5 35.67304463177607 139.74094079176683 200.5 35.672971523555134 139.7408730939822 200.5 35.672971523555134 139.7408730939822 202.5 35.67304463177607 139.74094079176683 202.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0044207b-6e4e-4ca3-8194-ccfe19777b60">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0044207b-6e4e-4ca3-8194-ccfe19777b60">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0044207b-6e4e-4ca3-8194-ccfe19777b60">
											<gml:posList>35.67304463177607 139.74094079176683 8.194 35.672971523555134 139.7408730939822 8.194 35.672971523555134 139.7408730939822 200.5 35.67304463177607 139.74094079176683 200.5 35.67304463177607 139.74094079176683 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5d46456b-a34e-4d4c-9443-a3d67a4442c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d46456b-a34e-4d4c-9443-a3d67a4442c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d46456b-a34e-4d4c-9443-a3d67a4442c4">
											<gml:posList>35.67304463177607 139.74094079176683 202.5 35.67298983338582 139.74102966973712 202.5 35.67298983338582 139.74102966973712 200.5 35.67304463177607 139.74094079176683 200.5 35.67304463177607 139.74094079176683 202.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7289eea5-05e8-4b86-9a8d-0ab4d92de70e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7289eea5-05e8-4b86-9a8d-0ab4d92de70e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7289eea5-05e8-4b86-9a8d-0ab4d92de70e">
											<gml:posList>35.67304463177607 139.74094079176683 200.5 35.673059307538594 139.74095438430004 200.5 35.673059307538594 139.74095438430004 8.194 35.67304463177607 139.74094079176683 8.194 35.67304463177607 139.74094079176683 200.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-41f3ec02-7350-4edf-afc9-679e36022e12">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41f3ec02-7350-4edf-afc9-679e36022e12">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41f3ec02-7350-4edf-afc9-679e36022e12">
											<gml:posList>35.67308664070834 139.74105305446466 8.194 35.67308664070834 139.74105305446466 200.5 35.673030371223206 139.7411396143054 200.5 35.673030371223206 139.7411396143054 8.194 35.67308664070834 139.74105305446466 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dbaec6ad-3368-4978-b91d-4063c65a1ed2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dbaec6ad-3368-4978-b91d-4063c65a1ed2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dbaec6ad-3368-4978-b91d-4063c65a1ed2">
											<gml:posList>35.672963080699894 139.7408652716691 200.5 35.672963080699894 139.7408652716691 8.194 35.67321416910896 139.7404580124312 8.194 35.67321416910896 139.7404580124312 200.5 35.672963080699894 139.7408652716691 200.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-79450154-8ccf-4f53-892d-5d6814c4a730">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79450154-8ccf-4f53-892d-5d6814c4a730">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79450154-8ccf-4f53-892d-5d6814c4a730">
											<gml:posList>35.673170713217694 139.74113735405166 8.194 35.673170713217694 139.74113735405166 200.5 35.67308664070834 139.74105305446466 200.5 35.67308664070834 139.74105305446466 8.194 35.673170713217694 139.74113735405166 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e8abfc45-2c4d-44fa-94c7-33857bc37956">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8abfc45-2c4d-44fa-94c7-33857bc37956">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8abfc45-2c4d-44fa-94c7-33857bc37956">
											<gml:posList>35.67318816023163 139.7403707077764 200.5 35.67318816023163 139.7403707077764 122.2 35.67309080544657 139.74028055862934 122.2 35.67309080544657 139.74028055862934 200.5 35.67318816023163 139.7403707077764 200.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c70f353a-3d6c-4c06-8dc2-a30f06705c37">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c70f353a-3d6c-4c06-8dc2-a30f06705c37">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c70f353a-3d6c-4c06-8dc2-a30f06705c37">
											<gml:posList>35.673156218446 139.74030438763742 124.771 35.67319752222812 139.74023814819577 124.771 35.67319752222812 139.74023814819577 122.2 35.673156218446 139.74030438763742 122.2 35.673156218446 139.74030438763742 124.771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-92582a45-2465-4de4-8150-5ac811c25b21">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-92582a45-2465-4de4-8150-5ac811c25b21">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-92582a45-2465-4de4-8150-5ac811c25b21">
											<gml:posList>35.673232412575686 139.74027081681768 124.771 35.673191099762136 139.74033705628185 124.771 35.673191099762136 139.74033705628185 122.2 35.673232412575686 139.74027081681768 122.2 35.673232412575686 139.74027081681768 124.771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6f7d88b9-48ac-4076-980c-356f3d0a6370">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f7d88b9-48ac-4076-980c-356f3d0a6370">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f7d88b9-48ac-4076-980c-356f3d0a6370">
											<gml:posList>35.67319752222812 139.74023814819577 124.771 35.673232412575686 139.74027081681768 124.771 35.673232412575686 139.74027081681768 122.2 35.67319752222812 139.74023814819577 122.2 35.67319752222812 139.74023814819577 124.771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0b2968ed-aea4-484a-88b6-a46dfec1d117">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b2968ed-aea4-484a-88b6-a46dfec1d117">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b2968ed-aea4-484a-88b6-a46dfec1d117">
											<gml:posList>35.67318816023163 139.7403707077764 200.5 35.67324608380993 139.74027913012506 200.5 35.67324608380993 139.74027913012506 122.2 35.67318816023163 139.7403707077764 122.2 35.67318816023163 139.7403707077764 200.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-94c0d8a4-c982-4e00-9139-c67b727e2e03">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-94c0d8a4-c982-4e00-9139-c67b727e2e03">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-94c0d8a4-c982-4e00-9139-c67b727e2e03">
											<gml:posList>35.67331845812236 139.74091514618866 200.5 35.673170713217694 139.74113735405166 200.5 35.673170713217694 139.74113735405166 8.194 35.67320355746159 139.74108795985464 8.194 35.67331845812236 139.74091514618866 8.194 35.67331845812236 139.74091514618866 200.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d48062ad-6565-4079-824c-90aa87e806e5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d48062ad-6565-4079-824c-90aa87e806e5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d48062ad-6565-4079-824c-90aa87e806e5">
											<gml:posList>35.673250711253644 139.74028353236918 126.154 35.673250711253644 139.74028353236918 122.2 35.67324608380993 139.74027913012506 122.2 35.67324608380993 139.74027913012506 200.5 35.673271945149864 139.7403037010142 200.5 35.673271945149864 139.7403037010142 182.019 35.673271945149864 139.7403037010142 126.154 35.673250711253644 139.74028353236918 126.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c8b38359-002b-4190-91fa-9bb7b0b9f586">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8b38359-002b-4190-91fa-9bb7b0b9f586">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8b38359-002b-4190-91fa-9bb7b0b9f586">
											<gml:posList>35.673250711253644 139.74028353236918 122.2 35.673250711253644 139.74028353236918 126.154 35.67327299308903 139.74024842232149 126.154 35.67327299308903 139.74024842232149 122.2 35.673250711253644 139.74028353236918 122.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-373fa929-d8e6-4515-935c-02d4f7aa8b77">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-373fa929-d8e6-4515-935c-02d4f7aa8b77">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-373fa929-d8e6-4515-935c-02d4f7aa8b77">
											<gml:posList>35.673310396236225 139.7405471138044 8.194 35.673310396236225 139.7405471138044 200.5 35.67321416910896 139.7404580124312 200.5 35.67321416910896 139.7404580124312 8.194 35.673310396236225 139.7405471138044 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fcbc6d20-0313-4e63-b103-cdb77e663839">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fcbc6d20-0313-4e63-b103-cdb77e663839">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fcbc6d20-0313-4e63-b103-cdb77e663839">
											<gml:posList>35.67326205799794 139.74084309863233 200.5 35.67328698743127 139.74088674836506 200.5 35.67328698743127 139.74088674836506 207.546 35.67326205799794 139.74084309863233 207.546 35.67326205799794 139.74084309863233 200.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e04556d6-be20-452e-a3f2-1e62839e9868">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e04556d6-be20-452e-a3f2-1e62839e9868">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e04556d6-be20-452e-a3f2-1e62839e9868">
											<gml:posList>35.67329016229064 139.74081897344223 207.546 35.67329016229064 139.74081897344223 200.5 35.67326205799794 139.74084309863233 200.5 35.67326205799794 139.74084309863233 207.546 35.67329016229064 139.74081897344223 207.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-45d5c9f6-f298-410b-85a0-0c659ba66a9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45d5c9f6-f298-410b-85a0-0c659ba66a9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45d5c9f6-f298-410b-85a0-0c659ba66a9a">
											<gml:posList>35.67329402815135 139.74026789525396 126.154 35.67329402815135 139.74026789525396 122.2 35.67327299308903 139.74024842232149 122.2 35.67327299308903 139.74024842232149 126.154 35.67329402815135 139.74026789525396 126.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-194f2043-9ef5-41dc-90fc-676e381eaeb1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-194f2043-9ef5-41dc-90fc-676e381eaeb1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-194f2043-9ef5-41dc-90fc-676e381eaeb1">
											<gml:posList>35.673271945149864 139.7403037010142 182.019 35.67332654495495 139.7402151538657 182.019 35.67332654495495 139.7402151538657 122.2 35.67329402815135 139.74026789525396 122.2 35.67329402815135 139.74026789525396 126.154 35.673271945149864 139.7403037010142 126.154 35.673271945149864 139.7403037010142 182.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e04ed3eb-0b87-41f0-9e54-3929d31d964c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e04ed3eb-0b87-41f0-9e54-3929d31d964c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e04ed3eb-0b87-41f0-9e54-3929d31d964c">
											<gml:posList>35.67331509173261 139.74086262318272 207.546 35.67328698743127 139.74088674836506 207.546 35.67328698743127 139.74088674836506 200.5 35.67331509173261 139.74086262318272 200.5 35.67331509173261 139.74086262318272 207.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-14e65b5c-2aeb-49b9-a884-169cbbc32c84">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-14e65b5c-2aeb-49b9-a884-169cbbc32c84">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-14e65b5c-2aeb-49b9-a884-169cbbc32c84">
											<gml:posList>35.67331509173261 139.74086262318272 200.5 35.67329016229064 139.74081897344223 200.5 35.67329016229064 139.74081897344223 207.546 35.67331509173261 139.74086262318272 207.546 35.67331509173261 139.74086262318272 200.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-badf8299-2d66-4f16-8829-9f77354c69b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-badf8299-2d66-4f16-8829-9f77354c69b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-badf8299-2d66-4f16-8829-9f77354c69b1">
											<gml:posList>35.67331845812236 139.74091514618866 8.194 35.673296393726424 139.74089323295502 8.194 35.673296393726424 139.74089323295502 200.5 35.67331845812236 139.74091514618866 200.5 35.67331845812236 139.74091514618866 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-105c985e-de9d-46c6-84a7-4c36d044e451">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-105c985e-de9d-46c6-84a7-4c36d044e451">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-105c985e-de9d-46c6-84a7-4c36d044e451">
											<gml:posList>35.673296393726424 139.74089323295502 8.194 35.673324484225965 139.74085113486385 8.194 35.673324484225965 139.74085113486385 200.5 35.673296393726424 139.74089323295502 200.5 35.673296393726424 139.74089323295502 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3254d3d1-9436-47ef-9bb8-c9a5739473d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3254d3d1-9436-47ef-9bb8-c9a5739473d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3254d3d1-9436-47ef-9bb8-c9a5739473d5">
											<gml:posList>35.67331308063802 139.7403346170776 182.019 35.67331308063802 139.7403346170776 186.44 35.673339656278706 139.7402920565802 186.44 35.673339656278706 139.7402920565802 182.019 35.67331308063802 139.7403346170776 182.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1267e915-c2cb-44ec-a9e4-6fcd6ed2d97d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1267e915-c2cb-44ec-a9e4-6fcd6ed2d97d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1267e915-c2cb-44ec-a9e4-6fcd6ed2d97d">
											<gml:posList>35.673324484225965 139.74085113486385 200.5 35.673324484225965 139.74085113486385 8.194 35.67333671661861 139.7408638686062 8.194 35.67333671661861 139.7408638686062 200.5 35.673324484225965 139.74085113486385 200.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0234e3cc-2130-433b-a02c-be5914e88384">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0234e3cc-2130-433b-a02c-be5914e88384">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0234e3cc-2130-433b-a02c-be5914e88384">
											<gml:posList>35.673271945149864 139.7403037010142 182.019 35.673271945149864 139.7403037010142 200.5 35.67329572234472 139.74032572255828 200.5 35.673391967587385 139.7404148127953 200.5 35.673415257671344 139.74043638205595 200.5 35.673415257671344 139.74043638205595 182.019 35.673271945149864 139.7403037010142 182.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d9745a71-d348-4cc9-98b3-2914864bf9cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d9745a71-d348-4cc9-98b3-2914864bf9cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d9745a71-d348-4cc9-98b3-2914864bf9cd">
											<gml:posList>35.673338102837626 139.7403580843116 186.44 35.673338102837626 139.7403580843116 182.019 35.673364678486486 139.74031552380865 182.019 35.673364678486486 139.74031552380865 186.44 35.673338102837626 139.7403580843116 186.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f5398e0b-d986-4f0c-a04c-27225a523a12">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f5398e0b-d986-4f0c-a04c-27225a523a12">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f5398e0b-d986-4f0c-a04c-27225a523a12">
											<gml:posList>35.673339656278706 139.7402920565802 182.019 35.673339656278706 139.7402920565802 186.44 35.673364678486486 139.74031552380865 186.44 35.673364678486486 139.74031552380865 182.019 35.673339656278706 139.7402920565802 182.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-09536b8a-5b24-481e-bbe8-19d5e155870d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-09536b8a-5b24-481e-bbe8-19d5e155870d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-09536b8a-5b24-481e-bbe8-19d5e155870d">
											<gml:posList>35.67323785111287 139.7400420674577 8.194 35.67323785111287 139.7400420674577 122.2 35.67347638720339 139.74028260763117 122.2 35.67347638720339 139.74028260763117 8.194 35.67323785111287 139.7400420674577 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b6babe89-4364-4a94-a0b3-f6b8d287ef91">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6babe89-4364-4a94-a0b3-f6b8d287ef91">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6babe89-4364-4a94-a0b3-f6b8d287ef91">
											<gml:posList>35.67335986143364 139.7407668521473 200.5 35.67338502033396 139.74079237405343 200.5 35.67338502033396 139.74079237405343 207 35.67335986143364 139.7407668521473 207 35.67335986143364 139.7407668521473 200.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-002a8813-077b-469d-b110-11c695df0a20">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-002a8813-077b-469d-b110-11c695df0a20">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-002a8813-077b-469d-b110-11c695df0a20">
											<gml:posList>35.6733875201222 139.74072591437806 207 35.6733875201222 139.74072591437806 200.5 35.67335986143364 139.7407668521473 200.5 35.67335986143364 139.7407668521473 207 35.6733875201222 139.74072591437806 207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4ca66f86-daae-4f5b-8feb-9ff73c7d90fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ca66f86-daae-4f5b-8feb-9ff73c7d90fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ca66f86-daae-4f5b-8feb-9ff73c7d90fc">
											<gml:posList>35.67344604575248 139.74032765807678 122.2 35.67332654495495 139.7402151538657 122.2 35.67332654495495 139.7402151538657 182.019 35.67347214143843 139.74035222877092 182.019 35.67347214143843 139.74035222877092 8.194 35.67344604575248 139.74032765807678 8.194 35.67344604575248 139.74032765807678 122.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5bcdb46d-5289-4756-a24b-5d5332182d40">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5bcdb46d-5289-4756-a24b-5d5332182d40">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5bcdb46d-5289-4756-a24b-5d5332182d40">
											<gml:posList>35.673412670017356 139.74075143629054 207 35.673412670017356 139.74075143629054 200.5 35.6733875201222 139.74072591437806 200.5 35.6733875201222 139.74072591437806 207 35.673412670017356 139.74075143629054 207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8c3f7fe0-4d31-49b2-a0f4-a3b3cd11493e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c3f7fe0-4d31-49b2-a0f4-a3b3cd11493e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c3f7fe0-4d31-49b2-a0f4-a3b3cd11493e">
											<gml:posList>35.673412670017356 139.74075143629054 200.5 35.673412670017356 139.74075143629054 207 35.67338502033396 139.74079237405343 207 35.67338502033396 139.74079237405343 200.5 35.67333671661861 139.7408638686062 200.5 35.67333671661861 139.7408638686062 8.194 35.67345822760065 139.74068399890893 8.194 35.67348131250426 139.74064983796802 8.194 35.67348131250426 139.74064983796802 200.5 35.673412670017356 139.74075143629054 200.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-61f7b489-ab9b-4c08-a816-3468c28db434">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61f7b489-ab9b-4c08-a816-3468c28db434">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61f7b489-ab9b-4c08-a816-3468c28db434">
											<gml:posList>35.673394622871314 139.7405618961925 200.5 35.673394622871314 139.7405618961925 8.194 35.67345332555522 139.74047522226766 8.194 35.67345332555522 139.74047522226766 200.5 35.673394622871314 139.7405618961925 200.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-70d52f88-7bb8-4d43-9c94-5c7f11bd58b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70d52f88-7bb8-4d43-9c94-5c7f11bd58b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70d52f88-7bb8-4d43-9c94-5c7f11bd58b6">
											<gml:posList>35.67345332555522 139.74047522226766 8.194 35.673415257671344 139.74043638205595 8.194 35.673415257671344 139.74043638205595 182.019 35.673415257671344 139.74043638205595 200.5 35.67345332555522 139.74047522226766 200.5 35.67345332555522 139.74047522226766 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2046f64a-579b-4ac5-ab84-4d7723fc5938">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2046f64a-579b-4ac5-ab84-4d7723fc5938">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2046f64a-579b-4ac5-ab84-4d7723fc5938">
											<gml:posList>35.673394622871314 139.7405618961925 200.5 35.67348131250426 139.74064983796802 200.5 35.67348131250426 139.74064983796802 8.194 35.673394622871314 139.7405618961925 8.194 35.673394622871314 139.7405618961925 200.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5c266bb4-b36c-46cf-8ea5-bf069a49f67a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5c266bb4-b36c-46cf-8ea5-bf069a49f67a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5c266bb4-b36c-46cf-8ea5-bf069a49f67a">
											<gml:posList>35.673415257671344 139.74043638205595 8.194 35.67347214143843 139.74035222877092 8.194 35.67347214143843 139.74035222877092 182.019 35.673415257671344 139.74043638205595 182.019 35.673415257671344 139.74043638205595 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-08e2b227-d347-4e40-9366-915666daafc9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-08e2b227-d347-4e40-9366-915666daafc9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-08e2b227-d347-4e40-9366-915666daafc9">
											<gml:posList>35.67347638720339 139.74028260763117 122.2 35.67344604575248 139.74032765807678 122.2 35.67344604575248 139.74032765807678 8.194 35.67347638720339 139.74028260763117 8.194 35.67347638720339 139.74028260763117 122.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都千代田区永田町二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4512</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">4848.9228</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>