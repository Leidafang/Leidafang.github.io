<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_a85645fd-91b2-4261-92fb-8c8d7ec45a58">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:measuredHeight uom="m">4.7</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67140748198271 139.73910889856487 0 35.67136091469949 139.73911740378438 0 35.671365922557435 139.73915866723164 0 35.67141249886593 139.73915017307135 0 35.67140748198271 139.73910889856487 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67140748198271 139.73910889856487 16.03 35.67141249886593 139.73915017307135 16.03 35.671365922557435 139.73915866723164 16.03 35.67136091469949 139.73911740378438 16.03 35.67140748198271 139.73910889856487 16.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67140748198271 139.73910889856487 16.03 35.67136091469949 139.73911740378438 16.03 35.67136091469949 139.73911740378438 20.72 35.67140748198271 139.73910889856487 20.72 35.67140748198271 139.73910889856487 16.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67136091469949 139.73911740378438 16.03 35.671365922557435 139.73915866723164 16.03 35.671365922557435 139.73915866723164 20.72 35.67136091469949 139.73911740378438 20.72 35.67136091469949 139.73911740378438 16.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671365922557435 139.73915866723164 16.03 35.67141249886593 139.73915017307135 16.03 35.67141249886593 139.73915017307135 20.72 35.671365922557435 139.73915866723164 20.72 35.671365922557435 139.73915866723164 16.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67141249886593 139.73915017307135 16.03 35.67140748198271 139.73910889856487 16.03 35.67140748198271 139.73910889856487 20.72 35.67141249886593 139.73915017307135 20.72 35.67141249886593 139.73915017307135 16.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67140748198271 139.73910889856487 20.72 35.67136091469949 139.73911740378438 20.72 35.671365922557435 139.73915866723164 20.72 35.67141249886593 139.73915017307135 20.72 35.67140748198271 139.73910889856487 20.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-028f9d9b-dcc7-4e89-90f7-8ff720ecebab"/>
							<gml:surfaceMember xlink:href="#poly-f6955289-dc53-4c8a-bbf5-c0193f14af82"/>
							<gml:surfaceMember xlink:href="#poly-4c774ad2-e652-4b4b-95d3-a0816f9dd5e8"/>
							<gml:surfaceMember xlink:href="#poly-7931a897-feb4-4288-8541-bc8889a8c2b3"/>
							<gml:surfaceMember xlink:href="#poly-bda88d0a-94be-48e3-9236-e8d73460c526"/>
							<gml:surfaceMember xlink:href="#poly-b09b268e-73da-47c3-a8b3-67cd8fe019f2"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-028f9d9b-dcc7-4e89-90f7-8ff720ecebab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-028f9d9b-dcc7-4e89-90f7-8ff720ecebab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-028f9d9b-dcc7-4e89-90f7-8ff720ecebab">
											<gml:posList>35.67140748198272 139.73910889856487 16.03 35.67141249886591 139.73915017307135 16.03 35.671365922557406 139.73915866723164 16.03 35.67136091469949 139.73911740378438 16.03 35.67140748198272 139.73910889856487 16.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f6955289-dc53-4c8a-bbf5-c0193f14af82">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f6955289-dc53-4c8a-bbf5-c0193f14af82">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f6955289-dc53-4c8a-bbf5-c0193f14af82">
											<gml:posList>35.67141249886591 139.73915017307135 21.133 35.67140748198272 139.73910889856487 21.133 35.67136091469949 139.73911740378438 21.133 35.671365922557406 139.73915866723164 21.133 35.67141249886591 139.73915017307135 21.133</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4c774ad2-e652-4b4b-95d3-a0816f9dd5e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c774ad2-e652-4b4b-95d3-a0816f9dd5e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c774ad2-e652-4b4b-95d3-a0816f9dd5e8">
											<gml:posList>35.67136091469949 139.73911740378438 16.03 35.671365922557406 139.73915866723164 16.03 35.671365922557406 139.73915866723164 21.133 35.67136091469949 139.73911740378438 21.133 35.67136091469949 139.73911740378438 16.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7931a897-feb4-4288-8541-bc8889a8c2b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7931a897-feb4-4288-8541-bc8889a8c2b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7931a897-feb4-4288-8541-bc8889a8c2b3">
											<gml:posList>35.67140748198272 139.73910889856487 16.03 35.67136091469949 139.73911740378438 16.03 35.67136091469949 139.73911740378438 21.133 35.67140748198272 139.73910889856487 21.133 35.67140748198272 139.73910889856487 16.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bda88d0a-94be-48e3-9236-e8d73460c526">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bda88d0a-94be-48e3-9236-e8d73460c526">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bda88d0a-94be-48e3-9236-e8d73460c526">
											<gml:posList>35.671365922557406 139.73915866723164 16.03 35.67141249886591 139.73915017307135 16.03 35.67141249886591 139.73915017307135 21.133 35.671365922557406 139.73915866723164 21.133 35.671365922557406 139.73915866723164 16.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b09b268e-73da-47c3-a8b3-67cd8fe019f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b09b268e-73da-47c3-a8b3-67cd8fe019f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b09b268e-73da-47c3-a8b3-67cd8fe019f2">
											<gml:posList>35.67141249886591 139.73915017307135 16.03 35.67140748198272 139.73910889856487 16.03 35.67140748198272 139.73910889856487 21.133 35.67141249886591 139.73915017307135 21.133 35.67141249886591 139.73915017307135 16.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5580</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>