<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_a8aaaa15-9f3b-4234-b6b7-15b4b4a5aa47">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.670725652610884 139.7492315307552 0 35.67073533109909 139.7492024909022 0 35.67071450210205 139.74919207399904 0 35.67070483262233 139.7492211027899 0 35.670725652610884 139.7492315307552 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670725652610884 139.7492315307552 6.691 35.67070483262233 139.7492211027899 6.691 35.67071450210205 139.74919207399904 6.691 35.67073533109909 139.7492024909022 6.691 35.670725652610884 139.7492315307552 6.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670725652610884 139.7492315307552 6.691 35.67073533109909 139.7492024909022 6.691 35.67073533109909 139.7492024909022 9.690999999999999 35.670725652610884 139.7492315307552 9.690999999999999 35.670725652610884 139.7492315307552 6.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67073533109909 139.7492024909022 6.691 35.67071450210205 139.74919207399904 6.691 35.67071450210205 139.74919207399904 9.690999999999999 35.67073533109909 139.7492024909022 9.690999999999999 35.67073533109909 139.7492024909022 6.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67071450210205 139.74919207399904 6.691 35.67070483262233 139.7492211027899 6.691 35.67070483262233 139.7492211027899 9.690999999999999 35.67071450210205 139.74919207399904 9.690999999999999 35.67071450210205 139.74919207399904 6.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67070483262233 139.7492211027899 6.691 35.670725652610884 139.7492315307552 6.691 35.670725652610884 139.7492315307552 9.690999999999999 35.67070483262233 139.7492211027899 9.690999999999999 35.67070483262233 139.7492211027899 6.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670725652610884 139.7492315307552 9.690999999999999 35.67073533109909 139.7492024909022 9.690999999999999 35.67071450210205 139.74919207399904 9.690999999999999 35.67070483262233 139.7492211027899 9.690999999999999 35.670725652610884 139.7492315307552 9.690999999999999</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-083b4517-8f3d-4c81-99d7-d267578cec1d"/>
							<gml:surfaceMember xlink:href="#poly-1ae3a47e-a19d-47d4-af9d-e223c602fc2c"/>
							<gml:surfaceMember xlink:href="#poly-0884ce1b-3600-417c-8703-4cd347dc8384"/>
							<gml:surfaceMember xlink:href="#poly-c75d639c-d3c5-48da-b4dc-387756cdc87e"/>
							<gml:surfaceMember xlink:href="#poly-3bb48c43-d8d3-49b8-a1d5-6be06c6998b4"/>
							<gml:surfaceMember xlink:href="#poly-6696139c-753d-4a9d-9c3a-e998cb500343"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-083b4517-8f3d-4c81-99d7-d267578cec1d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-083b4517-8f3d-4c81-99d7-d267578cec1d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-083b4517-8f3d-4c81-99d7-d267578cec1d">
											<gml:posList>35.670725652610884 139.74923153075517 6.691 35.670704832622334 139.7492211027899 6.691 35.67071450210203 139.749192073999 6.691 35.67073533109906 139.7492024909022 6.691 35.670725652610884 139.74923153075517 6.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1ae3a47e-a19d-47d4-af9d-e223c602fc2c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ae3a47e-a19d-47d4-af9d-e223c602fc2c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ae3a47e-a19d-47d4-af9d-e223c602fc2c">
											<gml:posList>35.670704832622334 139.7492211027899 7.5 35.670725652610884 139.74923153075517 7.5 35.67073533109906 139.7492024909022 7.5 35.67071450210203 139.749192073999 7.5 35.670704832622334 139.7492211027899 7.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0884ce1b-3600-417c-8703-4cd347dc8384">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0884ce1b-3600-417c-8703-4cd347dc8384">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0884ce1b-3600-417c-8703-4cd347dc8384">
											<gml:posList>35.67071450210203 139.749192073999 6.691 35.670704832622334 139.7492211027899 6.691 35.670704832622334 139.7492211027899 7.5 35.67071450210203 139.749192073999 7.5 35.67071450210203 139.749192073999 6.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c75d639c-d3c5-48da-b4dc-387756cdc87e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c75d639c-d3c5-48da-b4dc-387756cdc87e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c75d639c-d3c5-48da-b4dc-387756cdc87e">
											<gml:posList>35.670704832622334 139.7492211027899 6.691 35.670725652610884 139.74923153075517 6.691 35.670725652610884 139.74923153075517 7.5 35.670704832622334 139.7492211027899 7.5 35.670704832622334 139.7492211027899 6.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3bb48c43-d8d3-49b8-a1d5-6be06c6998b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3bb48c43-d8d3-49b8-a1d5-6be06c6998b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3bb48c43-d8d3-49b8-a1d5-6be06c6998b4">
											<gml:posList>35.67073533109906 139.7492024909022 6.691 35.67071450210203 139.749192073999 6.691 35.67071450210203 139.749192073999 7.5 35.67073533109906 139.7492024909022 7.5 35.67073533109906 139.7492024909022 6.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6696139c-753d-4a9d-9c3a-e998cb500343">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6696139c-753d-4a9d-9c3a-e998cb500343">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6696139c-753d-4a9d-9c3a-e998cb500343">
											<gml:posList>35.670725652610884 139.74923153075517 6.691 35.67073533109906 139.7492024909022 6.691 35.67073533109906 139.7492024909022 7.5 35.670725652610884 139.74923153075517 7.5 35.670725652610884 139.74923153075517 6.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10946</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">215</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>8</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>