<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_a8cc1c82-ead2-412d-869a-d79647b25390">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">17.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67055921258205 139.73834494030365 0 35.67054552931169 139.7382872838763 0 35.670555324480766 139.73828379268537 0 35.67053244360441 139.73818738578444 0 35.67041178372552 139.73823038847345 0 35.67044832076939 139.7383844405819 0 35.67055921258205 139.73834494030365 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67055921258205 139.73834494030365 19.673 35.67044832076939 139.7383844405819 19.673 35.67041178372552 139.73823038847345 19.673 35.67053244360441 139.73818738578444 19.673 35.670555324480766 139.73828379268537 19.673 35.67054552931169 139.7382872838763 19.673 35.67055921258205 139.73834494030365 19.673</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67055921258205 139.73834494030365 19.673 35.67054552931169 139.7382872838763 19.673 35.67054552931169 139.7382872838763 36.78 35.67055921258205 139.73834494030365 36.78 35.67055921258205 139.73834494030365 19.673</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67054552931169 139.7382872838763 19.673 35.670555324480766 139.73828379268537 19.673 35.670555324480766 139.73828379268537 36.78 35.67054552931169 139.7382872838763 36.78 35.67054552931169 139.7382872838763 19.673</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670555324480766 139.73828379268537 19.673 35.67053244360441 139.73818738578444 19.673 35.67053244360441 139.73818738578444 36.78 35.670555324480766 139.73828379268537 36.78 35.670555324480766 139.73828379268537 19.673</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67053244360441 139.73818738578444 19.673 35.67041178372552 139.73823038847345 19.673 35.67041178372552 139.73823038847345 36.78 35.67053244360441 139.73818738578444 36.78 35.67053244360441 139.73818738578444 19.673</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67041178372552 139.73823038847345 19.673 35.67044832076939 139.7383844405819 19.673 35.67044832076939 139.7383844405819 36.78 35.67041178372552 139.73823038847345 36.78 35.67041178372552 139.73823038847345 19.673</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67044832076939 139.7383844405819 19.673 35.67055921258205 139.73834494030365 19.673 35.67055921258205 139.73834494030365 36.78 35.67044832076939 139.7383844405819 36.78 35.67044832076939 139.7383844405819 19.673</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67055921258205 139.73834494030365 36.78 35.67054552931169 139.7382872838763 36.78 35.670555324480766 139.73828379268537 36.78 35.67053244360441 139.73818738578444 36.78 35.67041178372552 139.73823038847345 36.78 35.67044832076939 139.7383844405819 36.78 35.67055921258205 139.73834494030365 36.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-fb24847a-23af-48e1-9dbd-8e083c228135"/>
							<gml:surfaceMember xlink:href="#poly-8a5134df-96dd-404f-9b0d-fe7d6b88d007"/>
							<gml:surfaceMember xlink:href="#poly-ab498e28-a6ca-4cb1-b072-868934a5a60f"/>
							<gml:surfaceMember xlink:href="#poly-221cc756-7033-4ba8-9df3-bed37129b6c1"/>
							<gml:surfaceMember xlink:href="#poly-0e799c9a-fed0-4051-adb6-1199cb28f6d4"/>
							<gml:surfaceMember xlink:href="#poly-5f00e247-a04d-4784-99e3-f459f21109fd"/>
							<gml:surfaceMember xlink:href="#poly-5e3a4008-217f-4a62-88f6-9358630c3ac3"/>
							<gml:surfaceMember xlink:href="#poly-bc8216e3-70c4-497b-a831-980cfb9b7925"/>
							<gml:surfaceMember xlink:href="#poly-4606e387-2dc7-40e3-a5de-2ac8224dd6cc"/>
							<gml:surfaceMember xlink:href="#poly-f14491ec-b10c-4c91-b03e-8ed02433a67b"/>
							<gml:surfaceMember xlink:href="#poly-4d8b4a6a-e9c2-4917-af65-47e99ee3921a"/>
							<gml:surfaceMember xlink:href="#poly-b99eca8d-ae17-42a4-b7a0-a5e7770a6155"/>
							<gml:surfaceMember xlink:href="#poly-b619bc69-f8be-4384-b31d-8aeedcce5df8"/>
							<gml:surfaceMember xlink:href="#poly-3a29d948-8819-4ecd-8a5a-b23344e59f84"/>
							<gml:surfaceMember xlink:href="#poly-739792cd-7732-400b-a878-e75f20987617"/>
							<gml:surfaceMember xlink:href="#poly-5dc8e1e0-3f84-4d40-9c58-0f5a7de1d735"/>
							<gml:surfaceMember xlink:href="#poly-c225069d-f56a-4dd4-bb1c-9d24a8ba80d2"/>
							<gml:surfaceMember xlink:href="#poly-bd4545bb-ef8d-4861-bfb2-e60cdf2a9974"/>
							<gml:surfaceMember xlink:href="#poly-e420593a-839c-47ba-9840-ef2ddf197097"/>
							<gml:surfaceMember xlink:href="#poly-d7178933-2abb-4a47-b685-25f1d63fcc55"/>
							<gml:surfaceMember xlink:href="#poly-1b2ebac6-5aa4-486d-baa3-e1d2d7b1f811"/>
							<gml:surfaceMember xlink:href="#poly-91f81b94-6384-4103-b56f-28b62919feb9"/>
							<gml:surfaceMember xlink:href="#poly-aa4a910f-41d4-4ba7-a121-e74826cc68bd"/>
							<gml:surfaceMember xlink:href="#poly-7e2ec6db-42ed-4ec4-bf20-37e87520c4b4"/>
							<gml:surfaceMember xlink:href="#poly-0b14d299-d2ad-4b72-982f-3c0668a1ac46"/>
							<gml:surfaceMember xlink:href="#poly-494aa26e-13cd-4cd8-9cea-cdf9b587cb04"/>
							<gml:surfaceMember xlink:href="#poly-e014f978-ed56-475d-a81a-4dcd6cd10cfe"/>
							<gml:surfaceMember xlink:href="#poly-488eed0d-f3de-48ae-8c17-a086b0374ff8"/>
							<gml:surfaceMember xlink:href="#poly-175c6fba-6f42-430a-b009-ac221466f0a7"/>
							<gml:surfaceMember xlink:href="#poly-9df94924-d3ba-4b62-af06-9b01f06d299f"/>
							<gml:surfaceMember xlink:href="#poly-dc733241-5fb1-4856-b08f-4fef6d253930"/>
							<gml:surfaceMember xlink:href="#poly-cf913e6e-341e-4c12-bff2-4e4e35fc195d"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_a8cc1c82-ead2-412d-869a-d79647b25390_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-93269855-447f-4dad-afb9-de2f9a74ee56">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67055920356832 139.73834494031433 19.673 35.670545529311674 139.7382872838763 19.673 35.670565957707865 139.73828002434288 19.673 35.670579613931785 139.73833766976938 19.673 35.67055920356832 139.73834494031433 19.673</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b23950b5-43c9-4c45-8039-3ea4cb8b2f14">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b23950b5-43c9-4c45-8039-3ea4cb8b2f14_0">
											<gml:posList>35.670545529311674 139.7382872838763 39.729 35.670545529311674 139.7382872838763 19.673 35.67055920356832 139.73834494031433 19.673 35.67055920356832 139.73834494031433 39.729 35.670545529311674 139.7382872838763 39.729</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c5805e7-2966-46c0-b8d0-57573500518d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c5805e7-2966-46c0-b8d0-57573500518d_0">
											<gml:posList>35.670565957707865 139.73828002434288 39.729 35.670565957707865 139.73828002434288 19.673 35.670545529311674 139.7382872838763 19.673 35.670545529311674 139.7382872838763 39.729 35.670565957707865 139.73828002434288 39.729</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0bf9e36d-2ec5-48d4-b63f-a2f1daa19f87">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0bf9e36d-2ec5-48d4-b63f-a2f1daa19f87_0">
											<gml:posList>35.67055920356832 139.73834494031433 39.729 35.670579613931785 139.73833766976938 39.729 35.670565957707865 139.73828002434288 39.729 35.670545529311674 139.7382872838763 39.729 35.67055920356832 139.73834494031433 39.729</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-126939fd-7daf-488f-8ed3-560b6060f690">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-126939fd-7daf-488f-8ed3-560b6060f690_0">
											<gml:posList>35.67055920356832 139.73834494031433 39.729 35.67055920356832 139.73834494031433 19.673 35.670579613931785 139.73833766976938 19.673 35.670579613931785 139.73833766976938 39.729 35.67055920356832 139.73834494031433 39.729</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-006e862c-d049-4ff3-993e-17f185e599ba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-006e862c-d049-4ff3-993e-17f185e599ba_0">
											<gml:posList>35.670579613931785 139.73833766976938 39.729 35.670579613931785 139.73833766976938 19.673 35.670565957707865 139.73828002434288 19.673 35.670565957707865 139.73828002434288 39.729 35.670579613931785 139.73833766976938 39.729</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_a8cc1c82-ead2-412d-869a-d79647b25390_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dee82ee1-e728-4ff5-a462-5c232193ce2f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670514230457634 139.73827183409827 39.384 35.670529152995115 139.73826651419117 39.384 35.67053342170334 139.73828453665922 39.384 35.670518508178795 139.73828985655257 39.384 35.670514230457634 139.73827183409827 39.384</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-227d9fe0-99a0-467f-a62b-579545ce8d21">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-227d9fe0-99a0-467f-a62b-579545ce8d21_0">
											<gml:posList>35.670514230457634 139.73827183409827 41.889 35.670529152995115 139.73826651419117 41.889 35.670529152995115 139.73826651419117 39.384 35.670514230457634 139.73827183409827 39.384 35.670514230457634 139.73827183409827 41.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1cce89d6-a73b-4789-b2ff-fcf58b825afb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1cce89d6-a73b-4789-b2ff-fcf58b825afb_0">
											<gml:posList>35.670529152995115 139.73826651419117 39.384 35.670529152995115 139.73826651419117 41.889 35.67053342170334 139.73828453665922 41.889 35.67053342170334 139.73828453665922 39.384 35.670529152995115 139.73826651419117 39.384</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-66640a61-f842-4084-9365-b79dce7e3f29">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-66640a61-f842-4084-9365-b79dce7e3f29_0">
											<gml:posList>35.670514230457634 139.73827183409827 41.889 35.670518508178795 139.73828985655257 41.889 35.67053342170334 139.73828453665922 41.889 35.670529152995115 139.73826651419117 41.889 35.670514230457634 139.73827183409827 41.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-136f6539-8413-4e4d-99b7-6ca99951f68b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-136f6539-8413-4e4d-99b7-6ca99951f68b_0">
											<gml:posList>35.670518508178795 139.73828985655257 39.384 35.670518508178795 139.73828985655257 41.889 35.670514230457634 139.73827183409827 41.889 35.670514230457634 139.73827183409827 39.384 35.670518508178795 139.73828985655257 39.384</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6bde8cdc-a460-476e-9b40-a378881777ae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6bde8cdc-a460-476e-9b40-a378881777ae_0">
											<gml:posList>35.67053342170334 139.73828453665922 39.384 35.67053342170334 139.73828453665922 41.889 35.670518508178795 139.73828985655257 41.889 35.670518508178795 139.73828985655257 39.384 35.67053342170334 139.73828453665922 39.384</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-fb24847a-23af-48e1-9dbd-8e083c228135">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb24847a-23af-48e1-9dbd-8e083c228135">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb24847a-23af-48e1-9dbd-8e083c228135">
											<gml:posList>35.670532443604394 139.73818738578444 19.673 35.67055532448076 139.73828379268537 19.673 35.670545529311674 139.7382872838763 19.673 35.67055921258204 139.73834494030365 19.673 35.670448320769374 139.73838444058188 19.673 35.6704117837255 139.73823038847345 19.673 35.670532443604394 139.73818738578444 19.673</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8a5134df-96dd-404f-9b0d-fe7d6b88d007">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a5134df-96dd-404f-9b0d-fe7d6b88d007">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a5134df-96dd-404f-9b0d-fe7d6b88d007">
											<gml:posList>35.670454460742235 139.7382151823701 39.73 35.6704590872597 139.73821831402216 39.73 35.67052011105459 139.7381965577843 39.73 35.67052266646554 139.73819087696478 39.73 35.670454460742235 139.7382151823701 39.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ab498e28-a6ca-4cb1-b072-868934a5a60f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab498e28-a6ca-4cb1-b072-868934a5a60f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab498e28-a6ca-4cb1-b072-868934a5a60f">
											<gml:posList>35.670545529311674 139.7382872838763 36.525 35.67055532448076 139.73828379268537 36.525 35.670532443604394 139.73818738578444 36.525 35.67052266646554 139.73819087696478 36.525 35.670545529311674 139.7382872838763 36.525</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-221cc756-7033-4ba8-9df3-bed37129b6c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-221cc756-7033-4ba8-9df3-bed37129b6c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-221cc756-7033-4ba8-9df3-bed37129b6c1">
											<gml:posList>35.67054722954123 139.73829443985167 39.73 35.67052266646554 139.73819087696478 39.73 35.67052011105459 139.7381965577843 39.73 35.67054364308254 139.7382957144253 39.73 35.67054722954123 139.73829443985167 39.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0e799c9a-fed0-4051-adb6-1199cb28f6d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e799c9a-fed0-4051-adb6-1199cb28f6d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e799c9a-fed0-4051-adb6-1199cb28f6d4">
											<gml:posList>35.67051348261168 139.7383064650652 39.384 35.67054364308254 139.7382957144253 39.384 35.67052011105459 139.7381965577843 39.384 35.6704590872597 139.73821831402216 39.384 35.67049354421953 139.7383635647985 39.384 35.67055457706291 139.73834181969733 39.384 35.670550037080005 139.73832269291466 39.384 35.67051987660676 139.73833344354526 39.384 35.67051348261168 139.7383064650652 39.384</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5f00e247-a04d-4784-99e3-f459f21109fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f00e247-a04d-4784-99e3-f459f21109fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f00e247-a04d-4784-99e3-f459f21109fd">
											<gml:posList>35.67049099780542 139.73836923455355 39.73 35.67049354421953 139.7383635647985 39.73 35.6704590872597 139.73821831402216 39.73 35.670454460742235 139.7382151823701 39.73 35.67049099780542 139.73836923455355 39.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5e3a4008-217f-4a62-88f6-9358630c3ac3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e3a4008-217f-4a62-88f6-9358630c3ac3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e3a4008-217f-4a62-88f6-9358630c3ac3">
											<gml:posList>35.670448320769374 139.73838444058188 32.831 35.67049099780542 139.73836923455355 39.73 35.670454460742235 139.7382151823701 39.73 35.6704117837255 139.73823038847345 32.831 35.670448320769374 139.73838444058188 32.831</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bc8216e3-70c4-497b-a831-980cfb9b7925">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc8216e3-70c4-497b-a831-980cfb9b7925">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc8216e3-70c4-497b-a831-980cfb9b7925">
											<gml:posList>35.67051348261168 139.7383064650652 44.169 35.670517342550674 139.73830907845826 44.169 35.67054509702058 139.73829917018816 44.169 35.67054722954123 139.73829443985167 44.169 35.67051348261168 139.7383064650652 44.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4606e387-2dc7-40e3-a5de-2ac8224dd6cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4606e387-2dc7-40e3-a5de-2ac8224dd6cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4606e387-2dc7-40e3-a5de-2ac8224dd6cc">
											<gml:posList>35.67054722954123 139.73829443985167 44.169 35.67054509702058 139.73829917018816 44.169 35.67054976360027 139.73831880494728 44.169 35.6705536325527 139.73832141833142 44.169 35.67054722954123 139.73829443985167 44.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f14491ec-b10c-4c91-b03e-8ed02433a67b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f14491ec-b10c-4c91-b03e-8ed02433a67b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f14491ec-b10c-4c91-b03e-8ed02433a67b">
											<gml:posList>35.67054976360027 139.73831880494728 43.766 35.67054509702058 139.73829917018816 43.766 35.670517342550674 139.73830907845826 43.766 35.67052200011504 139.73832871322185 43.766 35.67054976360027 139.73831880494728 43.766</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4d8b4a6a-e9c2-4917-af65-47e99ee3921a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d8b4a6a-e9c2-4917-af65-47e99ee3921a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d8b4a6a-e9c2-4917-af65-47e99ee3921a">
											<gml:posList>35.67051987660676 139.73833344354526 44.169 35.67052200011504 139.73832871322185 44.169 35.670517342550674 139.73830907845826 44.169 35.67051348261168 139.7383064650652 44.169 35.67051987660676 139.73833344354526 44.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b99eca8d-ae17-42a4-b7a0-a5e7770a6155">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b99eca8d-ae17-42a4-b7a0-a5e7770a6155">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b99eca8d-ae17-42a4-b7a0-a5e7770a6155">
											<gml:posList>35.6705536325527 139.73832141833142 44.169 35.67054976360027 139.73831880494728 44.169 35.67052200011504 139.73832871322185 44.169 35.67051987660676 139.73833344354526 44.169 35.6705536325527 139.73832141833142 44.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b619bc69-f8be-4384-b31d-8aeedcce5df8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b619bc69-f8be-4384-b31d-8aeedcce5df8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b619bc69-f8be-4384-b31d-8aeedcce5df8">
											<gml:posList>35.6705536325527 139.73832141833142 39.73 35.670550037080005 139.73832269291466 39.73 35.67055457706291 139.73834181969733 39.73 35.67055921258204 139.73834494030365 39.73 35.6705536325527 139.73832141833142 39.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3a29d948-8819-4ecd-8a5a-b23344e59f84">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a29d948-8819-4ecd-8a5a-b23344e59f84">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a29d948-8819-4ecd-8a5a-b23344e59f84">
											<gml:posList>35.67055921258204 139.73834494030365 39.73 35.67055457706291 139.73834181969733 39.73 35.67049354421953 139.7383635647985 39.73 35.67049099780542 139.73836923455355 39.73 35.67055921258204 139.73834494030365 39.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-739792cd-7732-400b-a878-e75f20987617">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-739792cd-7732-400b-a878-e75f20987617">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-739792cd-7732-400b-a878-e75f20987617">
											<gml:posList>35.67052200011504 139.73832871322185 44.169 35.67052200011504 139.73832871322185 43.766 35.670517342550674 139.73830907845826 43.766 35.670517342550674 139.73830907845826 44.169 35.67052200011504 139.73832871322185 44.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5dc8e1e0-3f84-4d40-9c58-0f5a7de1d735">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5dc8e1e0-3f84-4d40-9c58-0f5a7de1d735">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5dc8e1e0-3f84-4d40-9c58-0f5a7de1d735">
											<gml:posList>35.6704117837255 139.73823038847345 19.673 35.670448320769374 139.73838444058188 19.673 35.670448320769374 139.73838444058188 32.831 35.6704117837255 139.73823038847345 32.831 35.6704117837255 139.73823038847345 19.673</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c225069d-f56a-4dd4-bb1c-9d24a8ba80d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c225069d-f56a-4dd4-bb1c-9d24a8ba80d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c225069d-f56a-4dd4-bb1c-9d24a8ba80d2">
											<gml:posList>35.670532443604394 139.73818738578444 19.673 35.6704117837255 139.73823038847345 19.673 35.6704117837255 139.73823038847345 32.831 35.670454460742235 139.7382151823701 39.73 35.67052266646554 139.73819087696478 39.73 35.67052266646554 139.73819087696478 36.525 35.670532443604394 139.73818738578444 36.525 35.670532443604394 139.73818738578444 19.673</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bd4545bb-ef8d-4861-bfb2-e60cdf2a9974">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd4545bb-ef8d-4861-bfb2-e60cdf2a9974">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd4545bb-ef8d-4861-bfb2-e60cdf2a9974">
											<gml:posList>35.67049354421953 139.7383635647985 39.73 35.67049354421953 139.7383635647985 39.384 35.6704590872597 139.73821831402216 39.384 35.6704590872597 139.73821831402216 39.73 35.67049354421953 139.7383635647985 39.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e420593a-839c-47ba-9840-ef2ddf197097">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e420593a-839c-47ba-9840-ef2ddf197097">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e420593a-839c-47ba-9840-ef2ddf197097">
											<gml:posList>35.6704590872597 139.73821831402216 39.73 35.6704590872597 139.73821831402216 39.384 35.67052011105459 139.7381965577843 39.384 35.67052011105459 139.7381965577843 39.73 35.6704590872597 139.73821831402216 39.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d7178933-2abb-4a47-b685-25f1d63fcc55">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7178933-2abb-4a47-b685-25f1d63fcc55">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7178933-2abb-4a47-b685-25f1d63fcc55">
											<gml:posList>35.67055921258204 139.73834494030365 39.73 35.67049099780542 139.73836923455355 39.73 35.670448320769374 139.73838444058188 32.831 35.670448320769374 139.73838444058188 19.673 35.67055921258204 139.73834494030365 19.673 35.67055921258204 139.73834494030365 39.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b2ebac6-5aa4-486d-baa3-e1d2d7b1f811">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b2ebac6-5aa4-486d-baa3-e1d2d7b1f811">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b2ebac6-5aa4-486d-baa3-e1d2d7b1f811">
											<gml:posList>35.67051348261168 139.7383064650652 39.384 35.67051987660676 139.73833344354526 39.384 35.67051987660676 139.73833344354526 44.169 35.67051348261168 139.7383064650652 44.169 35.67051348261168 139.7383064650652 39.384</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-91f81b94-6384-4103-b56f-28b62919feb9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-91f81b94-6384-4103-b56f-28b62919feb9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-91f81b94-6384-4103-b56f-28b62919feb9">
											<gml:posList>35.67055457706291 139.73834181969733 39.73 35.67055457706291 139.73834181969733 39.384 35.67049354421953 139.7383635647985 39.384 35.67049354421953 139.7383635647985 39.73 35.67055457706291 139.73834181969733 39.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aa4a910f-41d4-4ba7-a121-e74826cc68bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa4a910f-41d4-4ba7-a121-e74826cc68bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa4a910f-41d4-4ba7-a121-e74826cc68bd">
											<gml:posList>35.67051348261168 139.7383064650652 39.384 35.67051348261168 139.7383064650652 44.169 35.67054722954123 139.73829443985167 44.169 35.67054722954123 139.73829443985167 39.73 35.67054364308254 139.7382957144253 39.73 35.67054364308254 139.7382957144253 39.384 35.67051348261168 139.7383064650652 39.384</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7e2ec6db-42ed-4ec4-bf20-37e87520c4b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e2ec6db-42ed-4ec4-bf20-37e87520c4b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e2ec6db-42ed-4ec4-bf20-37e87520c4b4">
											<gml:posList>35.670517342550674 139.73830907845826 44.169 35.670517342550674 139.73830907845826 43.766 35.67054509702058 139.73829917018816 43.766 35.67054509702058 139.73829917018816 44.169 35.670517342550674 139.73830907845826 44.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0b14d299-d2ad-4b72-982f-3c0668a1ac46">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b14d299-d2ad-4b72-982f-3c0668a1ac46">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b14d299-d2ad-4b72-982f-3c0668a1ac46">
											<gml:posList>35.67052011105459 139.7381965577843 39.73 35.67052011105459 139.7381965577843 39.384 35.67054364308254 139.7382957144253 39.384 35.67054364308254 139.7382957144253 39.73 35.67052011105459 139.7381965577843 39.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-494aa26e-13cd-4cd8-9cea-cdf9b587cb04">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-494aa26e-13cd-4cd8-9cea-cdf9b587cb04">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-494aa26e-13cd-4cd8-9cea-cdf9b587cb04">
											<gml:posList>35.67054976360027 139.73831880494728 44.169 35.67054976360027 139.73831880494728 43.766 35.67052200011504 139.73832871322185 43.766 35.67052200011504 139.73832871322185 44.169 35.67054976360027 139.73831880494728 44.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e014f978-ed56-475d-a81a-4dcd6cd10cfe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e014f978-ed56-475d-a81a-4dcd6cd10cfe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e014f978-ed56-475d-a81a-4dcd6cd10cfe">
											<gml:posList>35.6705536325527 139.73832141833142 44.169 35.67051987660676 139.73833344354526 44.169 35.67051987660676 139.73833344354526 39.384 35.670550037080005 139.73832269291466 39.384 35.670550037080005 139.73832269291466 39.73 35.6705536325527 139.73832141833142 39.73 35.6705536325527 139.73832141833142 44.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-488eed0d-f3de-48ae-8c17-a086b0374ff8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-488eed0d-f3de-48ae-8c17-a086b0374ff8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-488eed0d-f3de-48ae-8c17-a086b0374ff8">
											<gml:posList>35.670545529311674 139.7382872838763 36.525 35.67052266646554 139.73819087696478 36.525 35.67052266646554 139.73819087696478 39.73 35.67054722954123 139.73829443985167 39.73 35.67054722954123 139.73829443985167 44.169 35.6705536325527 139.73832141833142 44.169 35.6705536325527 139.73832141833142 39.73 35.67055921258204 139.73834494030365 39.73 35.67055921258204 139.73834494030365 19.673 35.670545529311674 139.7382872838763 19.673 35.670545529311674 139.7382872838763 36.525</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-175c6fba-6f42-430a-b009-ac221466f0a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-175c6fba-6f42-430a-b009-ac221466f0a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-175c6fba-6f42-430a-b009-ac221466f0a7">
											<gml:posList>35.67055532448076 139.73828379268537 19.673 35.670532443604394 139.73818738578444 19.673 35.670532443604394 139.73818738578444 36.525 35.67055532448076 139.73828379268537 36.525 35.67055532448076 139.73828379268537 19.673</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9df94924-d3ba-4b62-af06-9b01f06d299f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9df94924-d3ba-4b62-af06-9b01f06d299f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9df94924-d3ba-4b62-af06-9b01f06d299f">
											<gml:posList>35.67054509702058 139.73829917018816 44.169 35.67054509702058 139.73829917018816 43.766 35.67054976360027 139.73831880494728 43.766 35.67054976360027 139.73831880494728 44.169 35.67054509702058 139.73829917018816 44.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dc733241-5fb1-4856-b08f-4fef6d253930">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc733241-5fb1-4856-b08f-4fef6d253930">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc733241-5fb1-4856-b08f-4fef6d253930">
											<gml:posList>35.670545529311674 139.7382872838763 19.673 35.67055532448076 139.73828379268537 19.673 35.67055532448076 139.73828379268537 36.525 35.670545529311674 139.7382872838763 36.525 35.670545529311674 139.7382872838763 19.673</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cf913e6e-341e-4c12-bff2-4e4e35fc195d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cf913e6e-341e-4c12-bff2-4e4e35fc195d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cf913e6e-341e-4c12-bff2-4e4e35fc195d">
											<gml:posList>35.670550037080005 139.73832269291466 39.73 35.670550037080005 139.73832269291466 39.384 35.67055457706291 139.73834181969733 39.384 35.67055457706291 139.73834181969733 39.73 35.670550037080005 139.73832269291466 39.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6790</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">209.16375</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>