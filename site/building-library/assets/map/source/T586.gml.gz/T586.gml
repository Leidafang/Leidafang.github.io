<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_aa05fe7d-2c72-419a-b041-0b80bbfe02fe">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">12.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67070093928958 139.74194889405626 0 35.67073947718328 139.74189505460586 0 35.67066685730231 139.74181692962853 0 35.67062822930586 139.7418707691704 0 35.67070093928958 139.74194889405626 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67070093928958 139.74194889405626 8.099 35.67062822930586 139.7418707691704 8.099 35.67066685730231 139.74181692962853 8.099 35.67073947718328 139.74189505460586 8.099 35.67070093928958 139.74194889405626 8.099</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67070093928958 139.74194889405626 8.099 35.67073947718328 139.74189505460586 8.099 35.67073947718328 139.74189505460586 20.52 35.67070093928958 139.74194889405626 20.52 35.67070093928958 139.74194889405626 8.099</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67073947718328 139.74189505460586 8.099 35.67066685730231 139.74181692962853 8.099 35.67066685730231 139.74181692962853 20.52 35.67073947718328 139.74189505460586 20.52 35.67073947718328 139.74189505460586 8.099</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67066685730231 139.74181692962853 8.099 35.67062822930586 139.7418707691704 8.099 35.67062822930586 139.7418707691704 20.52 35.67066685730231 139.74181692962853 20.52 35.67066685730231 139.74181692962853 8.099</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67062822930586 139.7418707691704 8.099 35.67070093928958 139.74194889405626 8.099 35.67070093928958 139.74194889405626 20.52 35.67062822930586 139.7418707691704 20.52 35.67062822930586 139.7418707691704 8.099</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67070093928958 139.74194889405626 20.52 35.67073947718328 139.74189505460586 20.52 35.67066685730231 139.74181692962853 20.52 35.67062822930586 139.7418707691704 20.52 35.67070093928958 139.74194889405626 20.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-7e48ea9f-af75-4800-9da2-7e6a1fdadc19"/>
							<gml:surfaceMember xlink:href="#poly-68a3c4d1-10a5-41dd-bb9a-a382204873ae"/>
							<gml:surfaceMember xlink:href="#poly-d689a704-8c43-4583-9a93-64ea50ea84d6"/>
							<gml:surfaceMember xlink:href="#poly-4ed7399f-76c1-4e87-bcf6-71157e8e98f5"/>
							<gml:surfaceMember xlink:href="#poly-08771823-133b-4cb4-8789-36839bfb0244"/>
							<gml:surfaceMember xlink:href="#poly-8bda4b83-bc4a-40fe-941a-bb02cebac81d"/>
							<gml:surfaceMember xlink:href="#poly-6535869e-a455-4af0-838b-08789112c4bd"/>
							<gml:surfaceMember xlink:href="#poly-6f17af7e-bf8b-455e-87e5-590667982e03"/>
							<gml:surfaceMember xlink:href="#poly-f2634e05-e7c9-4936-857f-f2187ffd1696"/>
							<gml:surfaceMember xlink:href="#poly-da10ebef-edcf-4160-99b0-314b50d70ca6"/>
							<gml:surfaceMember xlink:href="#poly-971efd1e-bb45-4b99-b45c-2c069f9c18c5"/>
							<gml:surfaceMember xlink:href="#poly-0ae1dba8-655c-4cda-ab90-41d00a901b78"/>
							<gml:surfaceMember xlink:href="#poly-80312151-1af0-4d72-8fa6-9273e2edecee"/>
							<gml:surfaceMember xlink:href="#poly-3c0f2a80-62fc-4c7d-b914-281eac752996"/>
							<gml:surfaceMember xlink:href="#poly-374cb76a-2ef6-4462-affe-b3aee3ade541"/>
							<gml:surfaceMember xlink:href="#poly-bc2c3fe6-ac30-4e20-8322-0fe5d711c951"/>
							<gml:surfaceMember xlink:href="#poly-2f24dc56-7306-492e-87da-37c22697fb91"/>
							<gml:surfaceMember xlink:href="#poly-0e26464b-25a1-4cf7-b5f2-ff0f662971d1"/>
							<gml:surfaceMember xlink:href="#poly-15283f33-ba68-45df-bd09-8c52b1be5dbc"/>
							<gml:surfaceMember xlink:href="#poly-d80936f5-79f8-48a4-be80-bc564c8056b2"/>
							<gml:surfaceMember xlink:href="#poly-5752f492-f0de-4bee-909f-3c2738a1f0e1"/>
							<gml:surfaceMember xlink:href="#poly-b74cdc23-51ac-4b77-a463-f19968c97706"/>
							<gml:surfaceMember xlink:href="#poly-e83a7057-333d-462f-80c1-e7a6a1923e44"/>
							<gml:surfaceMember xlink:href="#poly-8f98c99b-8d07-4a5f-845d-d235ef1783d1"/>
							<gml:surfaceMember xlink:href="#poly-619a59ec-0b07-474b-a298-b92d6243adc3"/>
							<gml:surfaceMember xlink:href="#poly-382cd8da-5af8-4349-8b03-470895bc1187"/>
							<gml:surfaceMember xlink:href="#poly-d46bfd50-eaee-4700-9fd2-c81c6cb9d605"/>
							<gml:surfaceMember xlink:href="#poly-cb2f4d13-8953-44b0-8275-b4ac5347aa8c"/>
							<gml:surfaceMember xlink:href="#poly-be2f41ac-c41b-4e91-92d0-60fc1b5696fa"/>
							<gml:surfaceMember xlink:href="#poly-03e70a85-d4c5-45e3-885f-3425dd42bfd4"/>
							<gml:surfaceMember xlink:href="#poly-196a918b-aa70-4443-8bef-0ca17fd67d52"/>
							<gml:surfaceMember xlink:href="#poly-fe0f7fae-f1ed-493c-b3ac-bc2d4c13d239"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_aa05fe7d-2c72-419a-b041-0b80bbfe02fe_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-169f35c1-341e-40d8-87d2-2f4df6460a16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6706732296375 139.7418638912223 21.154 35.67065561141978 139.74184493378286 21.154 35.670668127223855 139.74182745530217 21.154 35.67068574544429 139.74184641274073 21.154 35.6706732296375 139.7418638912223 21.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-001f53f3-19f3-49b0-b1fa-11eed3f8323b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67069613718994 139.7419399409778 18.798 35.67068767540927 139.7419308484706 18.798 35.67072457451738 139.7418792753827 18.798 35.67073311750929 139.74188847825914 18.798 35.67069613718994 139.7419399409778 18.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4fde21a-5b59-4789-a24f-d4883472084a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a4fde21a-5b59-4789-a24f-d4883472084a_0">
											<gml:posList>35.67065561141978 139.74184493378286 21.154 35.67065561141978 139.74184493378286 23.216 35.670668127223855 139.74182745530217 23.216 35.670668127223855 139.74182745530217 21.154 35.67065561141978 139.74184493378286 21.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-826d2a8a-22dd-4459-8c17-7c241b94fcad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-826d2a8a-22dd-4459-8c17-7c241b94fcad_0">
											<gml:posList>35.67068574544429 139.74184641274073 21.154 35.670668127223855 139.74182745530217 21.154 35.670668127223855 139.74182745530217 23.216 35.67068574544429 139.74184641274073 23.216 35.67068574544429 139.74184641274073 21.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a4cf722-c5e4-4551-96a0-1c9c63d780d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3a4cf722-c5e4-4551-96a0-1c9c63d780d4_0">
											<gml:posList>35.670668127223855 139.74182745530217 23.216 35.67065561141978 139.74184493378286 23.216 35.6706732296375 139.7418638912223 23.216 35.67068574544429 139.74184641274073 23.216 35.670668127223855 139.74182745530217 23.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dfbd7a6e-bfa7-4154-85e9-ad204c4fc448">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dfbd7a6e-bfa7-4154-85e9-ad204c4fc448_0">
											<gml:posList>35.67065561141978 139.74184493378286 21.154 35.6706732296375 139.7418638912223 21.154 35.6706732296375 139.7418638912223 23.216 35.67065561141978 139.74184493378286 23.216 35.67065561141978 139.74184493378286 21.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-febe0a59-4a23-4e27-b07a-03d235ca6131">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-febe0a59-4a23-4e27-b07a-03d235ca6131_0">
											<gml:posList>35.6706732296375 139.7418638912223 21.154 35.67068574544429 139.74184641274073 21.154 35.67068574544429 139.74184641274073 23.216 35.6706732296375 139.7418638912223 23.216 35.6706732296375 139.7418638912223 21.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81dc1b9e-041c-42b7-8596-5e90a54e3734">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81dc1b9e-041c-42b7-8596-5e90a54e3734_0">
											<gml:posList>35.67073311750929 139.74188847825914 18.798 35.67072457451738 139.7418792753827 18.798 35.67072457451738 139.7418792753827 20.929 35.67073311750929 139.74188847825914 20.929 35.67073311750929 139.74188847825914 18.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb508d26-82e1-40d2-bbf7-252839c1e500">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb508d26-82e1-40d2-bbf7-252839c1e500_0">
											<gml:posList>35.67068767540927 139.7419308484706 20.929 35.67072457451738 139.7418792753827 20.929 35.67072457451738 139.7418792753827 18.798 35.67068767540927 139.7419308484706 18.798 35.67068767540927 139.7419308484706 20.929</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ee7ffd30-c151-48e4-be1b-58543d17cb67">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ee7ffd30-c151-48e4-be1b-58543d17cb67_0">
											<gml:posList>35.67069613718994 139.7419399409778 20.929 35.67073311750929 139.74188847825914 20.929 35.67072457451738 139.7418792753827 20.929 35.67068767540927 139.7419308484706 20.929 35.67069613718994 139.7419399409778 20.929</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-69bb9bd3-3348-459c-9989-34cf1a625fe3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-69bb9bd3-3348-459c-9989-34cf1a625fe3_0">
											<gml:posList>35.67073311750929 139.74188847825914 18.798 35.67073311750929 139.74188847825914 20.929 35.67069613718994 139.7419399409778 20.929 35.67069613718994 139.7419399409778 18.798 35.67073311750929 139.74188847825914 18.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7eff3a45-819d-43b6-a756-c0381ba38cb8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7eff3a45-819d-43b6-a756-c0381ba38cb8_0">
											<gml:posList>35.67068767540927 139.7419308484706 20.929 35.67068767540927 139.7419308484706 18.798 35.67069613718994 139.7419399409778 18.798 35.67069613718994 139.7419399409778 20.929 35.67068767540927 139.7419308484706 20.929</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-7e48ea9f-af75-4800-9da2-7e6a1fdadc19">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e48ea9f-af75-4800-9da2-7e6a1fdadc19">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e48ea9f-af75-4800-9da2-7e6a1fdadc19">
											<gml:posList>35.67070093928958 139.74194889405626 8.099 35.67062822930584 139.74187076917036 8.099 35.6706668573023 139.7418169296285 8.099 35.670739477183275 139.74189505460583 8.099 35.67070093928958 139.74194889405626 8.099</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-68a3c4d1-10a5-41dd-bb9a-a382204873ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-68a3c4d1-10a5-41dd-bb9a-a382204873ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-68a3c4d1-10a5-41dd-bb9a-a382204873ae">
											<gml:posList>35.67062822930584 139.74187076917036 21.989 35.6706314650393 139.7418705114144 21.989 35.67066706764021 139.7418209060561 21.989 35.6706668573023 139.7418169296285 21.989 35.67062822930584 139.74187076917036 21.989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d689a704-8c43-4583-9a93-64ea50ea84d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d689a704-8c43-4583-9a93-64ea50ea84d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d689a704-8c43-4583-9a93-64ea50ea84d6">
											<gml:posList>35.670673238651226 139.74186389121203 21.154 35.670687942476164 139.74184336145439 21.154 35.67066706764021 139.7418209060561 21.154 35.6706314650393 139.7418705114144 21.154 35.670673238651226 139.74186389121203 21.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4ed7399f-76c1-4e87-bcf6-71157e8e98f5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ed7399f-76c1-4e87-bcf6-71157e8e98f5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ed7399f-76c1-4e87-bcf6-71157e8e98f5">
											<gml:posList>35.670707508295855 139.74186315619832 21.989 35.670707004056034 139.74186385269078 21.989 35.67072143781744 139.7418793783774 21.989 35.67072468257298 139.74187913165747 21.989 35.6706668573023 139.7418169296285 21.989 35.67066706764021 139.7418209060561 21.989 35.670687942476164 139.74184336145439 21.989 35.67068844670748 139.74184265391568 21.989 35.670707508295855 139.74186315619832 21.989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-08771823-133b-4cb4-8789-36839bfb0244">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-08771823-133b-4cb4-8789-36839bfb0244">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-08771823-133b-4cb4-8789-36839bfb0244">
											<gml:posList>35.67068862037698 139.7418458240062 23.481 35.67070492151691 139.74186336902926 23.481 35.670707508295855 139.74186315619832 23.481 35.67068844670748 139.74184265391568 23.481 35.67068862037698 139.7418458240062 23.481</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8bda4b83-bc4a-40fe-941a-bb02cebac81d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8bda4b83-bc4a-40fe-941a-bb02cebac81d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8bda4b83-bc4a-40fe-941a-bb02cebac81d">
											<gml:posList>35.670673238651226 139.74186389121203 23.481 35.67067581642485 139.74186368943776 23.481 35.67068862037698 139.7418458240062 23.481 35.67068844670748 139.74184265391568 23.481 35.670673238651226 139.74186389121203 23.481</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6535869e-a455-4af0-838b-08789112c4bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6535869e-a455-4af0-838b-08789112c4bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6535869e-a455-4af0-838b-08789112c4bd">
											<gml:posList>35.67068862037698 139.7418458240062 23.275 35.67067581642485 139.74186368943776 23.275 35.670692126575936 139.74188123445137 23.275 35.67070492151691 139.74186336902926 23.275 35.67068862037698 139.7418458240062 23.275</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6f17af7e-bf8b-455e-87e5-590667982e03">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f17af7e-bf8b-455e-87e5-590667982e03">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f17af7e-bf8b-455e-87e5-590667982e03">
											<gml:posList>35.670692126575936 139.74188123445137 23.481 35.670692300236034 139.74188439349584 23.481 35.670707508295855 139.74186315619832 23.481 35.67070492151691 139.74186336902926 23.481 35.670692126575936 139.74188123445137 23.481</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f2634e05-e7c9-4936-857f-f2187ffd1696">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f2634e05-e7c9-4936-857f-f2187ffd1696">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f2634e05-e7c9-4936-857f-f2187ffd1696">
											<gml:posList>35.67067581642485 139.74186368943776 23.481 35.670673238651226 139.74186389121203 23.481 35.670692300236034 139.74188439349584 23.481 35.670692126575936 139.74188123445137 23.481 35.67067581642485 139.74186368943776 23.481</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-da10ebef-edcf-4160-99b0-314b50d70ca6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da10ebef-edcf-4160-99b0-314b50d70ca6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da10ebef-edcf-4160-99b0-314b50d70ca6">
											<gml:posList>35.670685925363536 139.74192902782588 21.154 35.67072143781744 139.7418793783774 21.154 35.670707004056034 139.74186385269078 21.154 35.670692300236034 139.74188439349584 21.154 35.670685925363536 139.74192902782588 21.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-971efd1e-bb45-4b99-b45c-2c069f9c18c5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-971efd1e-bb45-4b99-b45c-2c069f9c18c5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-971efd1e-bb45-4b99-b45c-2c069f9c18c5">
											<gml:posList>35.670692300236034 139.74188439349584 21.154 35.670673238651226 139.74186389121203 21.154 35.6706314650393 139.7418705114144 21.154 35.670685925363536 139.74192902782588 21.154 35.670692300236034 139.74188439349584 21.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0ae1dba8-655c-4cda-ab90-41d00a901b78">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ae1dba8-655c-4cda-ab90-41d00a901b78">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ae1dba8-655c-4cda-ab90-41d00a901b78">
											<gml:posList>35.67068614470308 139.74193299319816 21.989 35.670685925363536 139.74192902782588 21.989 35.6706314650393 139.7418705114144 21.989 35.67062822930584 139.74187076917036 21.989 35.67068614470308 139.74193299319816 21.989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-80312151-1af0-4d72-8fa6-9273e2edecee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-80312151-1af0-4d72-8fa6-9273e2edecee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-80312151-1af0-4d72-8fa6-9273e2edecee">
											<gml:posList>35.67072143781744 139.7418793783774 21.989 35.670685925363536 139.74192902782588 21.989 35.67068614470308 139.74193299319816 21.989 35.67072468257298 139.74187913165747 21.989 35.67072143781744 139.7418793783774 21.989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3c0f2a80-62fc-4c7d-b914-281eac752996">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c0f2a80-62fc-4c7d-b914-281eac752996">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c0f2a80-62fc-4c7d-b914-281eac752996">
											<gml:posList>35.670739477183275 139.74189505460583 18.798 35.67072468257298 139.74187913165747 18.798 35.67068614470308 139.74193299319816 18.798 35.67070093928958 139.74194889405626 18.798 35.670739477183275 139.74189505460583 18.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-374cb76a-2ef6-4462-affe-b3aee3ade541">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-374cb76a-2ef6-4462-affe-b3aee3ade541">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-374cb76a-2ef6-4462-affe-b3aee3ade541">
											<gml:posList>35.67068862037698 139.7418458240062 23.275 35.67070492151691 139.74186336902926 23.275 35.67070492151691 139.74186336902926 23.481 35.67068862037698 139.7418458240062 23.481 35.67068862037698 139.7418458240062 23.275</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bc2c3fe6-ac30-4e20-8322-0fe5d711c951">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc2c3fe6-ac30-4e20-8322-0fe5d711c951">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc2c3fe6-ac30-4e20-8322-0fe5d711c951">
											<gml:posList>35.67072468257298 139.74187913165747 18.798 35.670739477183275 139.74189505460583 18.798 35.670739477183275 139.74189505460583 8.099 35.6706668573023 139.7418169296285 8.099 35.6706668573023 139.7418169296285 21.989 35.67072468257298 139.74187913165747 21.989 35.67072468257298 139.74187913165747 18.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2f24dc56-7306-492e-87da-37c22697fb91">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f24dc56-7306-492e-87da-37c22697fb91">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f24dc56-7306-492e-87da-37c22697fb91">
											<gml:posList>35.670692126575936 139.74188123445137 23.275 35.67067581642485 139.74186368943776 23.275 35.67067581642485 139.74186368943776 23.481 35.670692126575936 139.74188123445137 23.481 35.670692126575936 139.74188123445137 23.275</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0e26464b-25a1-4cf7-b5f2-ff0f662971d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e26464b-25a1-4cf7-b5f2-ff0f662971d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e26464b-25a1-4cf7-b5f2-ff0f662971d1">
											<gml:posList>35.67062822930584 139.74187076917036 8.099 35.67062822930584 139.74187076917036 21.989 35.6706668573023 139.7418169296285 21.989 35.6706668573023 139.7418169296285 8.099 35.67062822930584 139.74187076917036 8.099</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-15283f33-ba68-45df-bd09-8c52b1be5dbc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15283f33-ba68-45df-bd09-8c52b1be5dbc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15283f33-ba68-45df-bd09-8c52b1be5dbc">
											<gml:posList>35.67066706764021 139.7418209060561 21.989 35.6706314650393 139.7418705114144 21.989 35.6706314650393 139.7418705114144 21.154 35.67066706764021 139.7418209060561 21.154 35.67066706764021 139.7418209060561 21.989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d80936f5-79f8-48a4-be80-bc564c8056b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d80936f5-79f8-48a4-be80-bc564c8056b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d80936f5-79f8-48a4-be80-bc564c8056b2">
											<gml:posList>35.67062822930584 139.74187076917036 21.989 35.67062822930584 139.74187076917036 8.099 35.67070093928958 139.74194889405626 8.099 35.67070093928958 139.74194889405626 18.798 35.67068614470308 139.74193299319816 18.798 35.67068614470308 139.74193299319816 21.989 35.67062822930584 139.74187076917036 21.989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5752f492-f0de-4bee-909f-3c2738a1f0e1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5752f492-f0de-4bee-909f-3c2738a1f0e1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5752f492-f0de-4bee-909f-3c2738a1f0e1">
											<gml:posList>35.67066706764021 139.7418209060561 21.154 35.670687942476164 139.74184336145439 21.154 35.670687942476164 139.74184336145439 21.989 35.67066706764021 139.7418209060561 21.989 35.67066706764021 139.7418209060561 21.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b74cdc23-51ac-4b77-a463-f19968c97706">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b74cdc23-51ac-4b77-a463-f19968c97706">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b74cdc23-51ac-4b77-a463-f19968c97706">
											<gml:posList>35.670673238651226 139.74186389121203 21.154 35.670673238651226 139.74186389121203 23.481 35.67068844670748 139.74184265391568 23.481 35.67068844670748 139.74184265391568 21.989 35.670687942476164 139.74184336145439 21.989 35.670687942476164 139.74184336145439 21.154 35.670673238651226 139.74186389121203 21.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e83a7057-333d-462f-80c1-e7a6a1923e44">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e83a7057-333d-462f-80c1-e7a6a1923e44">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e83a7057-333d-462f-80c1-e7a6a1923e44">
											<gml:posList>35.67067581642485 139.74186368943776 23.275 35.67068862037698 139.7418458240062 23.275 35.67068862037698 139.7418458240062 23.481 35.67067581642485 139.74186368943776 23.481 35.67067581642485 139.74186368943776 23.275</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8f98c99b-8d07-4a5f-845d-d235ef1783d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f98c99b-8d07-4a5f-845d-d235ef1783d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f98c99b-8d07-4a5f-845d-d235ef1783d1">
											<gml:posList>35.670673238651226 139.74186389121203 23.481 35.670673238651226 139.74186389121203 21.154 35.670692300236034 139.74188439349584 21.154 35.670692300236034 139.74188439349584 23.481 35.670673238651226 139.74186389121203 23.481</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-619a59ec-0b07-474b-a298-b92d6243adc3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-619a59ec-0b07-474b-a298-b92d6243adc3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-619a59ec-0b07-474b-a298-b92d6243adc3">
											<gml:posList>35.67068844670748 139.74184265391568 23.481 35.670707508295855 139.74186315619832 23.481 35.670707508295855 139.74186315619832 21.989 35.67068844670748 139.74184265391568 21.989 35.67068844670748 139.74184265391568 23.481</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-382cd8da-5af8-4349-8b03-470895bc1187">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-382cd8da-5af8-4349-8b03-470895bc1187">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-382cd8da-5af8-4349-8b03-470895bc1187">
											<gml:posList>35.67070492151691 139.74186336902926 23.275 35.670692126575936 139.74188123445137 23.275 35.670692126575936 139.74188123445137 23.481 35.67070492151691 139.74186336902926 23.481 35.67070492151691 139.74186336902926 23.275</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d46bfd50-eaee-4700-9fd2-c81c6cb9d605">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d46bfd50-eaee-4700-9fd2-c81c6cb9d605">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d46bfd50-eaee-4700-9fd2-c81c6cb9d605">
											<gml:posList>35.670707004056034 139.74186385269078 21.989 35.670707508295855 139.74186315619832 21.989 35.670707508295855 139.74186315619832 23.481 35.670692300236034 139.74188439349584 23.481 35.670692300236034 139.74188439349584 21.154 35.670707004056034 139.74186385269078 21.154 35.670707004056034 139.74186385269078 21.989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cb2f4d13-8953-44b0-8275-b4ac5347aa8c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb2f4d13-8953-44b0-8275-b4ac5347aa8c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb2f4d13-8953-44b0-8275-b4ac5347aa8c">
											<gml:posList>35.670685925363536 139.74192902782588 21.989 35.67072143781744 139.7418793783774 21.989 35.67072143781744 139.7418793783774 21.154 35.670685925363536 139.74192902782588 21.154 35.670685925363536 139.74192902782588 21.989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-be2f41ac-c41b-4e91-92d0-60fc1b5696fa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-be2f41ac-c41b-4e91-92d0-60fc1b5696fa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-be2f41ac-c41b-4e91-92d0-60fc1b5696fa">
											<gml:posList>35.67068614470308 139.74193299319816 21.989 35.67068614470308 139.74193299319816 18.798 35.67072468257298 139.74187913165747 18.798 35.67072468257298 139.74187913165747 21.989 35.67068614470308 139.74193299319816 21.989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-03e70a85-d4c5-45e3-885f-3425dd42bfd4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03e70a85-d4c5-45e3-885f-3425dd42bfd4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03e70a85-d4c5-45e3-885f-3425dd42bfd4">
											<gml:posList>35.67072143781744 139.7418793783774 21.989 35.670707004056034 139.74186385269078 21.989 35.670707004056034 139.74186385269078 21.154 35.67072143781744 139.7418793783774 21.154 35.67072143781744 139.7418793783774 21.989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-196a918b-aa70-4443-8bef-0ca17fd67d52">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-196a918b-aa70-4443-8bef-0ca17fd67d52">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-196a918b-aa70-4443-8bef-0ca17fd67d52">
											<gml:posList>35.67070093928958 139.74194889405626 18.798 35.67070093928958 139.74194889405626 8.099 35.670739477183275 139.74189505460583 8.099 35.670739477183275 139.74189505460583 18.798 35.67070093928958 139.74194889405626 18.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fe0f7fae-f1ed-493c-b3ac-bc2d4c13d239">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe0f7fae-f1ed-493c-b3ac-bc2d4c13d239">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe0f7fae-f1ed-493c-b3ac-bc2d4c13d239">
											<gml:posList>35.6706314650393 139.7418705114144 21.989 35.670685925363536 139.74192902782588 21.989 35.670685925363536 139.74192902782588 21.154 35.6706314650393 139.7418705114144 21.154 35.6706314650393 139.7418705114144 21.989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-11643</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">73.2982</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1003</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">21</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>