<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_aa352db3-fdec-4021-9bd2-3e276b212869">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:measuredHeight uom="m">43.1</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67480574633831 139.7377812354585 0 35.67482575847968 139.7377719874671 0 35.67480592214699 139.73770748635164 0 35.674625326333995 139.73779095079536 0 35.674642803945595 139.73784776599044 0 35.67463233383622 139.73785260593286 0 35.67463724094086 139.73786856278033 0 35.67464843189411 139.73786340162266 0 35.67465942993345 139.73789914717446 0 35.67481930185543 139.73782526317495 0 35.67480574633831 139.7377812354585 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67480574633831 139.7377812354585 8.22 35.67481930185543 139.73782526317495 8.22 35.67465942993345 139.73789914717446 8.22 35.67464843189411 139.73786340162266 8.22 35.67463724094086 139.73786856278033 8.22 35.67463233383622 139.73785260593286 8.22 35.674642803945595 139.73784776599044 8.22 35.674625326333995 139.73779095079536 8.22 35.67480592214699 139.73770748635164 8.22 35.67482575847968 139.7377719874671 8.22 35.67480574633831 139.7377812354585 8.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67480574633831 139.7377812354585 8.22 35.67482575847968 139.7377719874671 8.22 35.67482575847968 139.7377719874671 46.07 35.67480574633831 139.7377812354585 46.07 35.67480574633831 139.7377812354585 8.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67482575847968 139.7377719874671 8.22 35.67480592214699 139.73770748635164 8.22 35.67480592214699 139.73770748635164 46.07 35.67482575847968 139.7377719874671 46.07 35.67482575847968 139.7377719874671 8.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67480592214699 139.73770748635164 8.22 35.674625326333995 139.73779095079536 8.22 35.674625326333995 139.73779095079536 46.07 35.67480592214699 139.73770748635164 46.07 35.67480592214699 139.73770748635164 8.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674625326333995 139.73779095079536 8.22 35.674642803945595 139.73784776599044 8.22 35.674642803945595 139.73784776599044 46.07 35.674625326333995 139.73779095079536 46.07 35.674625326333995 139.73779095079536 8.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674642803945595 139.73784776599044 8.22 35.67463233383622 139.73785260593286 8.22 35.67463233383622 139.73785260593286 46.07 35.674642803945595 139.73784776599044 46.07 35.674642803945595 139.73784776599044 8.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67463233383622 139.73785260593286 8.22 35.67463724094086 139.73786856278033 8.22 35.67463724094086 139.73786856278033 46.07 35.67463233383622 139.73785260593286 46.07 35.67463233383622 139.73785260593286 8.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67463724094086 139.73786856278033 8.22 35.67464843189411 139.73786340162266 8.22 35.67464843189411 139.73786340162266 46.07 35.67463724094086 139.73786856278033 46.07 35.67463724094086 139.73786856278033 8.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67464843189411 139.73786340162266 8.22 35.67465942993345 139.73789914717446 8.22 35.67465942993345 139.73789914717446 46.07 35.67464843189411 139.73786340162266 46.07 35.67464843189411 139.73786340162266 8.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67465942993345 139.73789914717446 8.22 35.67481930185543 139.73782526317495 8.22 35.67481930185543 139.73782526317495 46.07 35.67465942993345 139.73789914717446 46.07 35.67465942993345 139.73789914717446 8.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67481930185543 139.73782526317495 8.22 35.67480574633831 139.7377812354585 8.22 35.67480574633831 139.7377812354585 46.07 35.67481930185543 139.73782526317495 46.07 35.67481930185543 139.73782526317495 8.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67480574633831 139.7377812354585 46.07 35.67482575847968 139.7377719874671 46.07 35.67480592214699 139.73770748635164 46.07 35.674625326333995 139.73779095079536 46.07 35.674642803945595 139.73784776599044 46.07 35.67463233383622 139.73785260593286 46.07 35.67463724094086 139.73786856278033 46.07 35.67464843189411 139.73786340162266 46.07 35.67465942993345 139.73789914717446 46.07 35.67481930185543 139.73782526317495 46.07 35.67480574633831 139.7377812354585 46.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-ea1782d0-c4a6-4c7f-8aad-39014bafe240"/>
							<gml:surfaceMember xlink:href="#poly-aa1741ce-4aad-4af7-8ee5-c75dde7bcd83"/>
							<gml:surfaceMember xlink:href="#poly-f4dcdf92-8f3e-4c50-96b2-73032427d749"/>
							<gml:surfaceMember xlink:href="#poly-bfbc2110-355c-40ca-8fa1-a29bea824a4a"/>
							<gml:surfaceMember xlink:href="#poly-d556a559-0f8f-44c0-8d16-0136f1a94ec4"/>
							<gml:surfaceMember xlink:href="#poly-7dde33dd-9430-47cf-a732-24c60e9ed376"/>
							<gml:surfaceMember xlink:href="#poly-b81b5f64-e592-424a-9df7-be3d42b84973"/>
							<gml:surfaceMember xlink:href="#poly-2e180548-0c4f-46ca-930f-38386557056f"/>
							<gml:surfaceMember xlink:href="#poly-69c5febe-83bc-48aa-91c3-c79111843d13"/>
							<gml:surfaceMember xlink:href="#poly-54ee75d4-73fd-40f0-9b41-c20157c89833"/>
							<gml:surfaceMember xlink:href="#poly-45c496ba-cf28-441b-ba3d-b7a758d0c6c4"/>
							<gml:surfaceMember xlink:href="#poly-3a7bdd0d-1089-402c-8733-96ec88e3bca3"/>
							<gml:surfaceMember xlink:href="#poly-8f43b87e-0208-4bb5-926b-f27bd560b5e7"/>
							<gml:surfaceMember xlink:href="#poly-035ef84c-35b5-4842-b608-4572baecb0cd"/>
							<gml:surfaceMember xlink:href="#poly-2870863f-8c3f-4baa-99d6-eb26f4ec32cb"/>
							<gml:surfaceMember xlink:href="#poly-201b4e75-a424-490a-9021-23ade9bc1487"/>
							<gml:surfaceMember xlink:href="#poly-8965d9ce-94c5-4afe-b14c-0d07e1423db4"/>
							<gml:surfaceMember xlink:href="#poly-af1ef5ff-d65f-4e57-9ead-328f1ddd2d4a"/>
							<gml:surfaceMember xlink:href="#poly-b0b553fe-4ae3-4ee6-a60e-2e998f76bbd5"/>
							<gml:surfaceMember xlink:href="#poly-b85a6ac9-ac22-4ebc-a594-e6c321833ca0"/>
							<gml:surfaceMember xlink:href="#poly-5252f442-95d7-4e49-bb84-325237cb0cb6"/>
							<gml:surfaceMember xlink:href="#poly-89e9eb2e-d6ff-493f-995b-db95dddf8e46"/>
							<gml:surfaceMember xlink:href="#poly-50843277-9a1e-4a11-a4a3-83607bcf1065"/>
							<gml:surfaceMember xlink:href="#poly-da63d7ab-91c8-486f-bd48-9ca99fb771a3"/>
							<gml:surfaceMember xlink:href="#poly-7209b079-ad3f-4c6f-a085-164950d98a21"/>
							<gml:surfaceMember xlink:href="#poly-5e144521-1e87-4f82-9862-3fcca3ad38e1"/>
							<gml:surfaceMember xlink:href="#poly-d41f9e64-6776-49ec-bc3f-980bece42ecb"/>
							<gml:surfaceMember xlink:href="#poly-7dd94f8e-f568-4d0d-89dc-d46232040c6f"/>
							<gml:surfaceMember xlink:href="#poly-2d9032ea-b91d-41ef-9c03-75453fc81cec"/>
							<gml:surfaceMember xlink:href="#poly-28359b70-d6ca-43c0-a243-6e80d8d81ab3"/>
							<gml:surfaceMember xlink:href="#poly-7ee07ca9-6aec-4f36-92e9-fec6bb8f8337"/>
							<gml:surfaceMember xlink:href="#poly-72a69997-2395-41d7-a9a7-284c0d0c629a"/>
							<gml:surfaceMember xlink:href="#poly-e8f9bc65-c37c-4747-8176-3ac4427eb2c6"/>
							<gml:surfaceMember xlink:href="#poly-fab312da-9a7a-4196-8b5d-54231da44d45"/>
							<gml:surfaceMember xlink:href="#poly-8391013e-04b8-4f90-91a0-a8b3f6b182e0"/>
							<gml:surfaceMember xlink:href="#poly-15547406-6959-471d-b673-aab95dc4f75b"/>
							<gml:surfaceMember xlink:href="#poly-13f7d625-918f-47e4-b66a-a2ab46504e65"/>
							<gml:surfaceMember xlink:href="#poly-5ceda92e-8abd-4885-9089-fe28e108a88c"/>
							<gml:surfaceMember xlink:href="#poly-8387bdfa-3c5f-4e7d-8e1b-8608aea6c7e7"/>
							<gml:surfaceMember xlink:href="#poly-8165fa54-19de-4691-ac44-81d854672ed6"/>
							<gml:surfaceMember xlink:href="#poly-3620f74f-d6ad-4923-aeb6-49cf43e3bec3"/>
							<gml:surfaceMember xlink:href="#poly-1a02f3d2-21ca-4d5c-a0ab-e03b179f2786"/>
							<gml:surfaceMember xlink:href="#poly-08aec75b-0ccc-4bc1-a8e1-769885355240"/>
							<gml:surfaceMember xlink:href="#poly-d51fd8d0-befd-49a4-bf32-afeb0884bae9"/>
							<gml:surfaceMember xlink:href="#poly-6de98fd1-3633-480c-82c8-345526dca61b"/>
							<gml:surfaceMember xlink:href="#poly-981b9753-6036-4d8a-b391-3447d9e7a4d8"/>
							<gml:surfaceMember xlink:href="#poly-27b2fa89-7ffe-43b5-b3b4-cda6272fb76a"/>
							<gml:surfaceMember xlink:href="#poly-356844af-f34e-4732-a30d-7c1a0090eeda"/>
							<gml:surfaceMember xlink:href="#poly-ebfe7511-aacc-4d70-b612-08949cf77414"/>
							<gml:surfaceMember xlink:href="#poly-a68113d8-acde-459a-854c-38342ca13b85"/>
							<gml:surfaceMember xlink:href="#poly-5eae7c2d-f7a1-4635-908b-75b41e53aa00"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_aa352db3-fdec-4021-9bd2-3e276b212869_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b1b84e5b-893c-4ea0-90e7-b7ceea3dac17">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b1b84e5b-893c-4ea0-90e7-b7ceea3dac17_0">
											<gml:posList>35.674695882856575 139.73779864368947 59.536 35.67472060743725 139.7377872028209 58.025 35.674695882856575 139.73779864368947 58.025 35.674695882856575 139.73779864368947 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a06fde5f-215b-4c93-90d6-3b615f824110">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a06fde5f-215b-4c93-90d6-3b615f824110_0">
											<gml:posList>35.674695882856575 139.73779864368947 59.536 35.67472060743725 139.7377872028209 59.536 35.67472060743725 139.7377872028209 58.025 35.674695882856575 139.73779864368947 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a32d5df5-b6b8-435d-8785-bdece731ccbc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a32d5df5-b6b8-435d-8785-bdece731ccbc_0">
											<gml:posList>35.674721755906766 139.7377805401971 59.536 35.674719062893644 139.73777181639 58.025 35.674721755906766 139.7377805401971 58.025 35.674721755906766 139.7377805401971 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac2d4880-4874-4cbf-9842-4da2ba9526ef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ac2d4880-4874-4cbf-9842-4da2ba9526ef_0">
											<gml:posList>35.674721755906766 139.7377805401971 59.536 35.674719062893644 139.73777181639 59.536 35.674719062893644 139.73777181639 58.025 35.674721755906766 139.7377805401971 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-222e22c5-52ac-4132-9960-b09db5f050d0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-222e22c5-52ac-4132-9960-b09db5f050d0_0">
											<gml:posList>35.67476751740047 139.73777904955904 59.536 35.67469245095818 139.7378129424076 58.025 35.67469245095818 139.7378129424076 59.536 35.67476751740047 139.73777904955904 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-778ed548-32c7-42e2-8315-d45979cbf3fc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-778ed548-32c7-42e2-8315-d45979cbf3fc_0">
											<gml:posList>35.67476751740047 139.73777904955904 59.536 35.67476751740047 139.73777904955904 58.025 35.67469245095818 139.7378129424076 58.025 35.67476751740047 139.73777904955904 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a0906a68-6cb9-4226-8890-15cc6c79a0e5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a0906a68-6cb9-4226-8890-15cc6c79a0e5_0">
											<gml:posList>35.67476443824445 139.73776079276433 59.536 35.674721755906766 139.7377805401971 58.025 35.67476443824445 139.73776079276433 58.025 35.67476443824445 139.73776079276433 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3d9e57b-e8e7-4a32-a411-65a73fd5c422">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3d9e57b-e8e7-4a32-a411-65a73fd5c422_0">
											<gml:posList>35.67476443824445 139.73776079276433 59.536 35.674721755906766 139.7377805401971 59.536 35.674721755906766 139.7377805401971 58.025 35.67476443824445 139.73776079276433 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f998fa07-ade2-4254-ac77-aa86588bb9b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f998fa07-ade2-4254-ac77-aa86588bb9b2_0">
											<gml:posList>35.67476610102941 139.73776615955762 59.536 35.67472340967714 139.73778590699865 58.025 35.67472340967714 139.73778590699865 59.536 35.67476610102941 139.73776615955762 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2e2aeb8-2c66-464a-8f8c-820a381c423a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b2e2aeb8-2c66-464a-8f8c-820a381c423a_0">
											<gml:posList>35.67476610102941 139.73776615955762 59.536 35.67476610102941 139.73776615955762 58.025 35.67472340967714 139.73778590699865 58.025 35.67476610102941 139.73776615955762 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bbe5a891-5a7f-4af3-a053-c37adafce4dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bbe5a891-5a7f-4af3-a053-c37adafce4dc_0">
											<gml:posList>35.67479866195988 139.7378158316464 53.338 35.67479042021489 139.73778907490822 56.502 35.67479866195988 139.7378158316464 56.502 35.67479866195988 139.7378158316464 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cec466f9-3c38-41b9-b702-045d8b6f3ce2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cec466f9-3c38-41b9-b702-045d8b6f3ce2_0">
											<gml:posList>35.67479866195988 139.7378158316464 53.338 35.67479042021489 139.73778907490822 53.338 35.67479042021489 139.73778907490822 56.502 35.67479866195988 139.7378158316464 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2c55974-fb36-4a3e-8a7d-dc0376967f1e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b2c55974-fb36-4a3e-8a7d-dc0376967f1e_0">
											<gml:posList>35.67479179402738 139.73778241201 53.338 35.67481277026821 139.73777269890272 59.483 35.67481277026821 139.73777269890272 53.338 35.67479179402738 139.73778241201 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6380629a-97da-4503-a1d2-13a10b753659">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6380629a-97da-4503-a1d2-13a10b753659_0">
											<gml:posList>35.67479179402738 139.73778241201 53.338 35.67479179402738 139.73778241201 59.483 35.67481277026821 139.73777269890272 59.483 35.67479179402738 139.73778241201 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c474ef6a-02e3-4ba1-8ac3-71e203963675">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c474ef6a-02e3-4ba1-8ac3-71e203963675_0">
											<gml:posList>35.674676951207815 139.73778371986117 53.338 35.674701857158595 139.73786456419825 59.483 35.674676951207815 139.73778371986117 59.483 35.674676951207815 139.73778371986117 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43ab2d89-3fa4-49db-9526-06cd1fc4764e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-43ab2d89-3fa4-49db-9526-06cd1fc4764e_0">
											<gml:posList>35.674676951207815 139.73778371986117 53.338 35.674701857158595 139.73786456419825 53.338 35.674701857158595 139.73786456419825 59.483 35.674676951207815 139.73778371986117 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0074ee40-3bf2-4a55-ac4e-77d35b197ec6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0074ee40-3bf2-4a55-ac4e-77d35b197ec6_0">
											<gml:posList>35.674680846851096 139.73778588040085 59.483 35.67470361105796 139.73785980091506 53.338 35.674680846851096 139.73778588040085 53.338 35.674680846851096 139.73778588040085 59.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8cab40d1-4e29-4aee-8dfa-66491ebf73a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8cab40d1-4e29-4aee-8dfa-66491ebf73a6_0">
											<gml:posList>35.674680846851096 139.73778588040085 59.483 35.67470361105796 139.73785980091506 59.483 35.67470361105796 139.73785980091506 53.338 35.674680846851096 139.73778588040085 59.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f2119ed0-e9bc-4589-b641-666d861c6953">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f2119ed0-e9bc-4589-b641-666d861c6953_0">
											<gml:posList>35.6746915360658 139.7377845420381 59.536 35.674694229086775 139.73779327688945 58.025 35.674694229086775 139.73779327688945 59.536 35.6746915360658 139.7377845420381 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0210940f-d8cd-438a-92dd-9d60ae33d243">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0210940f-d8cd-438a-92dd-9d60ae33d243_0">
											<gml:posList>35.6746915360658 139.7377845420381 59.536 35.6746915360658 139.7377845420381 58.025 35.674694229086775 139.73779327688945 58.025 35.6746915360658 139.7377845420381 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d175b5ba-4614-43fc-a31a-7ef7f60e4594">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d175b5ba-4614-43fc-a31a-7ef7f60e4594_0">
											<gml:posList>35.67469563218987 139.73782353254975 59.536 35.67469245095818 139.7378129424076 58.025 35.67469563218987 139.73782353254975 58.025 35.67469563218987 139.73782353254975 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6fea68bb-84ee-4e93-9944-d9db82ef9822">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6fea68bb-84ee-4e93-9944-d9db82ef9822_0">
											<gml:posList>35.67469563218987 139.73782353254975 59.536 35.67469245095818 139.7378129424076 59.536 35.67469245095818 139.7378129424076 58.025 35.67469563218987 139.73782353254975 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-68ee3cbb-3503-4cb9-b489-99c23627bbf0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-68ee3cbb-3503-4cb9-b489-99c23627bbf0_0">
											<gml:posList>35.67469855781404 139.73780733437587 59.536 35.674695882856575 139.73779864368947 58.025 35.67469855781404 139.73780733437587 58.025 35.67469855781404 139.73780733437587 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-08484b9b-971a-4ee8-9562-313fc3c30f16">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-08484b9b-971a-4ee8-9562-313fc3c30f16_0">
											<gml:posList>35.67469855781404 139.73780733437587 59.536 35.674695882856575 139.73779864368947 59.536 35.674695882856575 139.73779864368947 58.025 35.67469855781404 139.73780733437587 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4873ed64-d967-4bee-8190-9dc2c85f7119">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4873ed64-d967-4bee-8190-9dc2c85f7119_0">
											<gml:posList>35.6746915360658 139.7377845420381 59.536 35.67471626965886 139.73777310115508 58.025 35.6746915360658 139.7377845420381 58.025 35.6746915360658 139.7377845420381 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f670bc18-bde7-443b-bdab-a8dbcff883f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f670bc18-bde7-443b-bdab-a8dbcff883f8_0">
											<gml:posList>35.6746915360658 139.7377845420381 59.536 35.67471626965886 139.73777310115508 59.536 35.67471626965886 139.73777310115508 58.025 35.6746915360658 139.7377845420381 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e79826f6-7f51-4d2d-8c58-e642728f3bb2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e79826f6-7f51-4d2d-8c58-e642728f3bb2_0">
											<gml:posList>35.67471895366694 139.7377818360195 59.536 35.6746915360658 139.7377845420381 59.536 35.674694229086775 139.73779327688945 59.536 35.67471895366694 139.7377818360195 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-96d9c245-91fd-4ee9-8d78-daa741050571">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-96d9c245-91fd-4ee9-8d78-daa741050571_0">
											<gml:posList>35.67471895366694 139.7377818360195 59.536 35.67471626965886 139.73777310115508 59.536 35.6746915360658 139.7377845420381 59.536 35.67471895366694 139.7377818360195 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ae246711-ff88-48d8-b041-234b0ec1a89d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ae246711-ff88-48d8-b041-234b0ec1a89d_0">
											<gml:posList>35.67472060743725 139.7377872028209 59.536 35.674695882856575 139.73779864368947 59.536 35.67469855781404 139.73780733437587 59.536 35.67472060743725 139.7377872028209 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1041391e-c30c-414c-96be-ce5e61507dfe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1041391e-c30c-414c-96be-ce5e61507dfe_0">
											<gml:posList>35.67472329140924 139.73779589349888 59.536 35.67472060743725 139.7377872028209 59.536 35.67469855781404 139.73780733437587 59.536 35.67472329140924 139.73779589349888 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-837424fe-057f-4e0e-a435-d4b465897fb7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-837424fe-057f-4e0e-a435-d4b465897fb7_0">
											<gml:posList>35.67471626965886 139.73777310115508 59.536 35.67471895366694 139.7377818360195 58.025 35.67471626965886 139.73777310115508 58.025 35.67471626965886 139.73777310115508 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cbc2fb33-854e-45c1-955b-ea17c0bbe8d2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cbc2fb33-854e-45c1-955b-ea17c0bbe8d2_0">
											<gml:posList>35.67471626965886 139.73777310115508 59.536 35.67471895366694 139.7377818360195 59.536 35.67471895366694 139.7377818360195 58.025 35.67471626965886 139.73777310115508 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f8781a8e-b9f2-46a7-8070-78fe1be810ba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f8781a8e-b9f2-46a7-8070-78fe1be810ba_0">
											<gml:posList>35.67472060743725 139.7377872028209 59.536 35.67472329140924 139.73779589349888 58.025 35.67472060743725 139.7377872028209 58.025 35.67472060743725 139.7377872028209 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ac3d456-9d22-4b02-9a2e-c4da5d3f8a45">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0ac3d456-9d22-4b02-9a2e-c4da5d3f8a45_0">
											<gml:posList>35.67472060743725 139.7377872028209 59.536 35.67472329140924 139.73779589349888 59.536 35.67472329140924 139.73779589349888 58.025 35.67472060743725 139.7377872028209 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b75db484-65b8-42ff-b695-d96e532bb0ed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b75db484-65b8-42ff-b695-d96e532bb0ed_0">
											<gml:posList>35.67472600331048 139.73779434370684 59.536 35.67472340967714 139.73778590699865 58.025 35.67472600331048 139.73779434370684 58.025 35.67472600331048 139.73779434370684 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e6239ae-2927-4ab8-b5b7-640b06fb79a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9e6239ae-2927-4ab8-b5b7-640b06fb79a6_0">
											<gml:posList>35.67472600331048 139.73779434370684 59.536 35.67472340967714 139.73778590699865 59.536 35.67472340967714 139.73778590699865 58.025 35.67472600331048 139.73779434370684 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c066cdb-850e-4a37-8fa2-d4a38e0359be">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8c066cdb-850e-4a37-8fa2-d4a38e0359be_0">
											<gml:posList>35.67469563218987 139.73782353254975 59.536 35.67476751740047 139.73777904955904 59.536 35.67469245095818 139.7378129424076 59.536 35.67469563218987 139.73782353254975 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9c188447-3820-491a-8b71-2cdec28c80c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9c188447-3820-491a-8b71-2cdec28c80c3_0">
											<gml:posList>35.67469563218987 139.73782353254975 59.536 35.67477070764006 139.73778962865217 59.536 35.67476751740047 139.73777904955904 59.536 35.67469563218987 139.73782353254975 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75475944-3b3a-4968-81d9-37d8ddd3b5e1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-75475944-3b3a-4968-81d9-37d8ddd3b5e1_0">
											<gml:posList>35.67469563218987 139.73782353254975 59.536 35.67477070764006 139.73778962865217 58.025 35.67477070764006 139.73778962865217 59.536 35.67469563218987 139.73782353254975 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44bfb325-9adb-4a60-b4ae-a66938f76bf2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-44bfb325-9adb-4a60-b4ae-a66938f76bf2_0">
											<gml:posList>35.67469563218987 139.73782353254975 59.536 35.67469563218987 139.73782353254975 58.025 35.67477070764006 139.73778962865217 58.025 35.67469563218987 139.73782353254975 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e24cd2bf-6ad5-4a42-93a0-623e1e2b8d72">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e24cd2bf-6ad5-4a42-93a0-623e1e2b8d72_0">
											<gml:posList>35.674676951207815 139.73778371986117 53.338 35.674801628328744 139.7377260502125 59.483 35.674801628328744 139.7377260502125 53.338 35.674676951207815 139.73778371986117 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c149d45b-4785-4c64-9896-01e78d7566eb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c149d45b-4785-4c64-9896-01e78d7566eb_0">
											<gml:posList>35.674676951207815 139.73778371986117 53.338 35.674676951207815 139.73778371986117 59.483 35.674801628328744 139.7377260502125 59.483 35.674676951207815 139.73778371986117 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4013f93-a1c6-43e9-96f7-25351a5f54a3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b4013f93-a1c6-43e9-96f7-25351a5f54a3_0">
											<gml:posList>35.674680846851096 139.73778588040085 53.338 35.67479987443471 139.73773081350444 59.483 35.674680846851096 139.73778588040085 59.483 35.674680846851096 139.73778588040085 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6aaa6d6d-6a28-4389-846e-9209046605b9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6aaa6d6d-6a28-4389-846e-9209046605b9_0">
											<gml:posList>35.674680846851096 139.73778588040085 53.338 35.67479987443471 139.73773081350444 53.338 35.67479987443471 139.73773081350444 59.483 35.674680846851096 139.73778588040085 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-87bd2742-06b5-4fc3-86ca-b22dbfd987f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-87bd2742-06b5-4fc3-86ca-b22dbfd987f0_0">
											<gml:posList>35.674719062893644 139.73777181639 59.536 35.674761754234865 139.73775205789568 58.025 35.674719062893644 139.73777181639 58.025 35.674719062893644 139.73777181639 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4ebf98ff-5660-4d1e-bb02-b90de0517a5d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4ebf98ff-5660-4d1e-bb02-b90de0517a5d_0">
											<gml:posList>35.674719062893644 139.73777181639 59.536 35.674761754234865 139.73775205789568 59.536 35.674761754234865 139.73775205789568 58.025 35.674719062893644 139.73777181639 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b7a0d77d-6120-4dd8-8b1d-7c6a891964c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b7a0d77d-6120-4dd8-8b1d-7c6a891964c6_0">
											<gml:posList>35.67476443824445 139.73776079276433 59.536 35.674719062893644 139.73777181639 59.536 35.674721755906766 139.7377805401971 59.536 35.67476443824445 139.73776079276433 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5532d166-eef9-4d2f-afeb-10c71b4c574b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5532d166-eef9-4d2f-afeb-10c71b4c574b_0">
											<gml:posList>35.67476443824445 139.73776079276433 59.536 35.674761754234865 139.73775205789568 59.536 35.674719062893644 139.73777181639 59.536 35.67476443824445 139.73776079276433 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84dc5a73-bde6-49e9-85e8-99314e0c4803">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-84dc5a73-bde6-49e9-85e8-99314e0c4803_0">
											<gml:posList>35.674768694664124 139.73777459626962 59.536 35.67472340967714 139.73778590699865 59.536 35.67472600331048 139.73779434370684 59.536 35.674768694664124 139.73777459626962 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-93b82062-831e-44f1-b79e-c21802cc11bd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-93b82062-831e-44f1-b79e-c21802cc11bd_0">
											<gml:posList>35.674768694664124 139.73777459626962 59.536 35.67476610102941 139.73776615955762 59.536 35.67472340967714 139.73778590699865 59.536 35.674768694664124 139.73777459626962 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f197779e-36eb-428d-a466-7f1df57d1193">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f197779e-36eb-428d-a466-7f1df57d1193_0">
											<gml:posList>35.674801628328744 139.7377260502125 59.483 35.67479987443471 139.73773081350444 59.483 35.674816665911614 139.7377748594455 59.483 35.674801628328744 139.7377260502125 59.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc315b73-736f-4f25-8acf-698ec441bf6c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bc315b73-736f-4f25-8acf-698ec441bf6c_0">
											<gml:posList>35.674680846851096 139.73778588040085 59.483 35.674801628328744 139.7377260502125 59.483 35.674676951207815 139.73778371986117 59.483 35.674680846851096 139.73778588040085 59.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24a48ed0-967a-48be-81fd-4267c6ec9435">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-24a48ed0-967a-48be-81fd-4267c6ec9435_0">
											<gml:posList>35.67470361105796 139.73785980091506 59.483 35.674676951207815 139.73778371986117 59.483 35.674701857158595 139.73786456419825 59.483 35.67470361105796 139.73785980091506 59.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7a26edb-a707-4f2b-b219-f1f5d6cad53b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c7a26edb-a707-4f2b-b219-f1f5d6cad53b_0">
											<gml:posList>35.67479568064814 139.73778456151658 59.483 35.674816665911614 139.7377748594455 59.483 35.67481277026821 139.73777269890272 59.483 35.67479568064814 139.73778456151658 59.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-535d9157-e4ea-48c8-80e9-6e94fce628c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-535d9157-e4ea-48c8-80e9-6e94fce628c9_0">
											<gml:posList>35.67480554905186 139.7378165967211 59.483 35.67479568064814 139.73778456151658 59.483 35.674801653417965 139.73781444722346 59.483 35.67480554905186 139.7378165967211 59.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e6f4c56f-c97e-40b3-8b71-909b88f25043">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e6f4c56f-c97e-40b3-8b71-909b88f25043_0">
											<gml:posList>35.674701857158595 139.73786456419825 59.483 35.67480554905186 139.7378165967211 59.483 35.674801653417965 139.73781444722346 59.483 35.674701857158595 139.73786456419825 59.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1be9612d-17ee-49e6-b7da-34fa09bf3f91">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1be9612d-17ee-49e6-b7da-34fa09bf3f91_0">
											<gml:posList>35.67479987443471 139.73773081350444 59.483 35.67481277026821 139.73777269890272 59.483 35.674816665911614 139.7377748594455 59.483 35.67479987443471 139.73773081350444 59.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad635645-d868-4e9f-9886-1b147cf7c890">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ad635645-d868-4e9f-9886-1b147cf7c890_0">
											<gml:posList>35.674680846851096 139.73778588040085 59.483 35.674676951207815 139.73778371986117 59.483 35.67470361105796 139.73785980091506 59.483 35.674680846851096 139.73778588040085 59.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a7f6251-35d5-4df4-944a-ff4e08238348">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9a7f6251-35d5-4df4-944a-ff4e08238348_0">
											<gml:posList>35.674680846851096 139.73778588040085 59.483 35.67479987443471 139.73773081350444 59.483 35.674801628328744 139.7377260502125 59.483 35.674680846851096 139.73778588040085 59.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c0c1279-c9ba-4749-9cf4-a804729653bb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2c0c1279-c9ba-4749-9cf4-a804729653bb_0">
											<gml:posList>35.67470361105796 139.73785980091506 59.483 35.674701857158595 139.73786456419825 59.483 35.674801653417965 139.73781444722346 59.483 35.67470361105796 139.73785980091506 59.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-237e6a72-594f-4d2c-9be7-3b4403a5cc37">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-237e6a72-594f-4d2c-9be7-3b4403a5cc37_0">
											<gml:posList>35.67481277026821 139.73777269890272 59.483 35.67479179402738 139.73778241201 59.483 35.67479568064814 139.73778456151658 59.483 35.67481277026821 139.73777269890272 59.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ec7b693-a916-440a-b802-6ed52465311f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9ec7b693-a916-440a-b802-6ed52465311f_0">
											<gml:posList>35.67479568064814 139.73778456151658 59.483 35.67479179402738 139.73778241201 59.483 35.674801653417965 139.73781444722346 59.483 35.67479568064814 139.73778456151658 59.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1de39da9-1a75-4f81-bc09-e28f9a97e6e0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1de39da9-1a75-4f81-bc09-e28f9a97e6e0_0">
											<gml:posList>35.674768694664124 139.73777459626962 59.536 35.67472600331048 139.73779434370684 58.025 35.674768694664124 139.73777459626962 58.025 35.674768694664124 139.73777459626962 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4380744e-4c9b-4a95-bdeb-19ef81020860">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4380744e-4c9b-4a95-bdeb-19ef81020860_0">
											<gml:posList>35.674768694664124 139.73777459626962 59.536 35.67472600331048 139.73779434370684 59.536 35.67472600331048 139.73779434370684 58.025 35.674768694664124 139.73777459626962 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f49e1b09-d930-4334-8ee6-2657266133ff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f49e1b09-d930-4334-8ee6-2657266133ff_0">
											<gml:posList>35.674801653417965 139.73781444722346 59.483 35.674801653417965 139.73781444722346 53.338 35.67479866195988 139.7378158316464 56.502 35.674801653417965 139.73781444722346 59.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0986622b-d51d-4f31-ae72-48fe9fc131c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0986622b-d51d-4f31-ae72-48fe9fc131c7_0">
											<gml:posList>35.67478980471127 139.7378199184938 56.502 35.67470361105796 139.73785980091506 59.483 35.674801653417965 139.73781444722346 59.483 35.67478980471127 139.7378199184938 56.502</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c40182df-d228-4ab0-b1c8-104f52bc0baf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c40182df-d228-4ab0-b1c8-104f52bc0baf_0">
											<gml:posList>35.67478980471127 139.7378199184938 53.338 35.67470361105796 139.73785980091506 53.338 35.67478980471127 139.7378199184938 56.502 35.67478980471127 139.7378199184938 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-acfeb075-8df2-42bf-97d1-000512067c12">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-acfeb075-8df2-42bf-97d1-000512067c12_0">
											<gml:posList>35.674801653417965 139.73781444722346 53.338 35.67479866195988 139.7378158316464 53.338 35.67479866195988 139.7378158316464 56.502 35.674801653417965 139.73781444722346 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b1250481-85ab-404f-998a-57cb6b4228d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b1250481-85ab-404f-998a-57cb6b4228d6_0">
											<gml:posList>35.67470361105796 139.73785980091506 53.338 35.67470361105796 139.73785980091506 59.483 35.67478980471127 139.7378199184938 56.502 35.67470361105796 139.73785980091506 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9c22724-a1ab-4e36-b8a0-3ab439d47457">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e9c22724-a1ab-4e36-b8a0-3ab439d47457_0">
											<gml:posList>35.67478980471127 139.7378199184938 56.502 35.674801653417965 139.73781444722346 59.483 35.67479866195988 139.7378158316464 56.502 35.67478980471127 139.7378199184938 56.502</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b389e7a-4710-469d-b27e-6762fcafbc08">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0b389e7a-4710-469d-b27e-6762fcafbc08_0">
											<gml:posList>35.67480554905186 139.7378165967211 53.338 35.674701857158595 139.73786456419825 59.483 35.674701857158595 139.73786456419825 53.338 35.67480554905186 139.7378165967211 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94be65ce-0b82-4e94-bead-4fe57ee60072">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-94be65ce-0b82-4e94-bead-4fe57ee60072_0">
											<gml:posList>35.67480554905186 139.7378165967211 53.338 35.67480554905186 139.7378165967211 59.483 35.674701857158595 139.73786456419825 59.483 35.67480554905186 139.7378165967211 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-71573f23-2760-4f19-8617-9904226b9588">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-71573f23-2760-4f19-8617-9904226b9588_0">
											<gml:posList>35.674761754234865 139.73775205789568 59.536 35.67476443824445 139.73776079276433 58.025 35.674761754234865 139.73775205789568 58.025 35.674761754234865 139.73775205789568 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2e2d30d7-bb7f-4ac1-8d98-08a15fcea76e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2e2d30d7-bb7f-4ac1-8d98-08a15fcea76e_0">
											<gml:posList>35.674761754234865 139.73775205789568 59.536 35.67476443824445 139.73776079276433 59.536 35.67476443824445 139.73776079276433 58.025 35.674761754234865 139.73775205789568 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11ccc13e-24f3-4bf2-bf9a-99ad110b9336">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-11ccc13e-24f3-4bf2-bf9a-99ad110b9336_0">
											<gml:posList>35.67476610102941 139.73776615955762 59.536 35.674768694664124 139.73777459626962 58.025 35.67476610102941 139.73776615955762 58.025 35.67476610102941 139.73776615955762 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5dbbe0b4-bfa1-4f97-b9df-d9170a844ee8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5dbbe0b4-bfa1-4f97-b9df-d9170a844ee8_0">
											<gml:posList>35.67476610102941 139.73776615955762 59.536 35.674768694664124 139.73777459626962 59.536 35.674768694664124 139.73777459626962 58.025 35.67476610102941 139.73776615955762 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8791e909-03e8-47f9-9100-fb10a101a96d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8791e909-03e8-47f9-9100-fb10a101a96d_0">
											<gml:posList>35.67477070764006 139.73778962865217 59.536 35.67476751740047 139.73777904955904 58.025 35.67476751740047 139.73777904955904 59.536 35.67477070764006 139.73778962865217 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f84fe56-2adf-4010-b6e9-9290605b5235">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f84fe56-2adf-4010-b6e9-9290605b5235_0">
											<gml:posList>35.67477070764006 139.73778962865217 59.536 35.67477070764006 139.73778962865217 58.025 35.67476751740047 139.73777904955904 58.025 35.67477070764006 139.73778962865217 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-83841849-f19e-41af-ae3f-abbe739c0cdf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-83841849-f19e-41af-ae3f-abbe739c0cdf_0">
											<gml:posList>35.67478980471127 139.7378199184938 53.338 35.67478157198964 139.73779317279428 56.502 35.67478157198964 139.73779317279428 53.338 35.67478980471127 139.7378199184938 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f947d569-997d-4580-a57e-832b7e3525fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f947d569-997d-4580-a57e-832b7e3525fd_0">
											<gml:posList>35.67478980471127 139.7378199184938 53.338 35.67478980471127 139.7378199184938 56.502 35.67478157198964 139.73779317279428 56.502 35.67478980471127 139.7378199184938 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-476cd68d-0582-48d6-95f3-61518eaf964f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-476cd68d-0582-48d6-95f3-61518eaf964f_0">
											<gml:posList>35.67478157198964 139.73779317279428 53.338 35.67479042021489 139.73778907490822 56.502 35.67479042021489 139.73778907490822 53.338 35.67478157198964 139.73779317279428 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25ea6e7a-d9ba-4373-b9ce-d4ded8b4a2f9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-25ea6e7a-d9ba-4373-b9ce-d4ded8b4a2f9_0">
											<gml:posList>35.67478157198964 139.73779317279428 53.338 35.67478157198964 139.73779317279428 56.502 35.67479042021489 139.73778907490822 56.502 35.67478157198964 139.73779317279428 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f72b72e8-8c3c-4e45-a51c-b9c822513a69">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f72b72e8-8c3c-4e45-a51c-b9c822513a69_0">
											<gml:posList>35.67479042021489 139.73778907490822 56.502 35.67478980471127 139.7378199184938 56.502 35.67479866195988 139.7378158316464 56.502 35.67479042021489 139.73778907490822 56.502</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4737c13b-d5c7-4e9c-9172-2136bd4fe444">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4737c13b-d5c7-4e9c-9172-2136bd4fe444_0">
											<gml:posList>35.67479042021489 139.73778907490822 56.502 35.67478157198964 139.73779317279428 56.502 35.67478980471127 139.7378199184938 56.502 35.67479042021489 139.73778907490822 56.502</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7cfbd38c-9e01-4e22-b293-4464718f9e34">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7cfbd38c-9e01-4e22-b293-4464718f9e34_0">
											<gml:posList>35.67479179402738 139.73778241201 53.338 35.674801653417965 139.73781444722346 59.483 35.67479179402738 139.73778241201 59.483 35.67479179402738 139.73778241201 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f5d61ce7-5373-46c8-9851-c495ceb18951">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f5d61ce7-5373-46c8-9851-c495ceb18951_0">
											<gml:posList>35.67479179402738 139.73778241201 53.338 35.674801653417965 139.73781444722346 53.338 35.674801653417965 139.73781444722346 59.483 35.67479179402738 139.73778241201 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d47d14a-674a-43df-8cf1-694fa662c401">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8d47d14a-674a-43df-8cf1-694fa662c401_0">
											<gml:posList>35.67480554905186 139.7378165967211 53.338 35.67479568064814 139.73778456151658 59.483 35.67480554905186 139.7378165967211 59.483 35.67480554905186 139.7378165967211 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48b31d20-fb90-4fce-a8b9-2c1b7feb9d05">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-48b31d20-fb90-4fce-a8b9-2c1b7feb9d05_0">
											<gml:posList>35.67480554905186 139.7378165967211 53.338 35.67479568064814 139.73778456151658 53.338 35.67479568064814 139.73778456151658 59.483 35.67480554905186 139.7378165967211 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4526353a-491a-47b5-97f2-a98e896302df">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4526353a-491a-47b5-97f2-a98e896302df_0">
											<gml:posList>35.674800651353614 139.73777842458006 54.229 35.6748016906047 139.73778179263616 53.338 35.674800651353614 139.73777842458006 53.338 35.674800651353614 139.73777842458006 54.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a5f78d48-1e93-4bcf-858b-143cf90ec043">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a5f78d48-1e93-4bcf-858b-143cf90ec043_0">
											<gml:posList>35.674800651353614 139.73777842458006 54.229 35.6748016906047 139.73778179263616 54.229 35.6748016906047 139.73778179263616 53.338 35.674800651353614 139.73777842458006 54.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a963a4e6-8234-4588-88ae-1516f8654703">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a963a4e6-8234-4588-88ae-1516f8654703_0">
											<gml:posList>35.6748016906047 139.73778179263616 53.338 35.6748016906047 139.73778179263616 54.229 35.67479568064814 139.73778456151658 53.338 35.6748016906047 139.73778179263616 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd2efa6f-4654-4389-b3e8-523afe472df6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dd2efa6f-4654-4389-b3e8-523afe472df6_0">
											<gml:posList>35.67479568064814 139.73778456151658 53.338 35.6748016906047 139.73778179263616 54.229 35.67479568064814 139.73778456151658 59.483 35.67479568064814 139.73778456151658 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7eae6c5e-1360-42f9-80a9-5ed3954ba27c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7eae6c5e-1360-42f9-80a9-5ed3954ba27c_0">
											<gml:posList>35.67479568064814 139.73778456151658 59.483 35.6748016906047 139.73778179263616 54.229 35.674816665911614 139.7377748594455 59.483 35.67479568064814 139.73778456151658 59.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b523304c-0627-469d-8e2d-42de18d4ae1e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b523304c-0627-469d-8e2d-42de18d4ae1e_0">
											<gml:posList>35.6748016906047 139.73778179263616 54.229 35.674816665911614 139.7377748594455 54.229 35.674816665911614 139.7377748594455 59.483 35.6748016906047 139.73778179263616 54.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d368f888-112c-49a7-8ced-99132ff64774">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d368f888-112c-49a7-8ced-99132ff64774_0">
											<gml:posList>35.67479987443471 139.73773081350444 53.338 35.67481277026821 139.73777269890272 59.483 35.67479987443471 139.73773081350444 59.483 35.67479987443471 139.73773081350444 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6db7edf2-c6c9-4689-b36b-970b46a5ba98">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6db7edf2-c6c9-4689-b36b-970b46a5ba98_0">
											<gml:posList>35.67479987443471 139.73773081350444 53.338 35.67481277026821 139.73777269890272 53.338 35.67481277026821 139.73777269890272 59.483 35.67479987443471 139.73773081350444 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-febcb064-fa54-4646-9a31-f3b5c3a06288">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-febcb064-fa54-4646-9a31-f3b5c3a06288_0">
											<gml:posList>35.6748156266691 139.73777150243575 54.229 35.674800651353614 139.73777842458006 53.338 35.6748156266691 139.73777150243575 53.338 35.6748156266691 139.73777150243575 54.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0ebbae6-28b1-42a7-8bca-66c5db0a975b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d0ebbae6-28b1-42a7-8bca-66c5db0a975b_0">
											<gml:posList>35.6748156266691 139.73777150243575 54.229 35.674800651353614 139.73777842458006 54.229 35.674800651353614 139.73777842458006 53.338 35.6748156266691 139.73777150243575 54.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f9843ebb-a9de-467c-bcc8-81eebb5a8d5a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f9843ebb-a9de-467c-bcc8-81eebb5a8d5a_0">
											<gml:posList>35.674816665911614 139.7377748594455 59.483 35.674816665911614 139.7377748594455 54.229 35.6748156266691 139.73777150243575 54.229 35.674816665911614 139.7377748594455 59.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-faab6c63-24f9-4797-99e4-c79699700456">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-faab6c63-24f9-4797-99e4-c79699700456_0">
											<gml:posList>35.674816665911614 139.7377748594455 59.483 35.6748156266691 139.73777150243575 54.229 35.674801628328744 139.7377260502125 59.483 35.674816665911614 139.7377748594455 59.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9db25969-df3e-46b2-88e5-8918493fea11">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9db25969-df3e-46b2-88e5-8918493fea11_0">
											<gml:posList>35.6748156266691 139.73777150243575 54.229 35.674801628328744 139.7377260502125 53.338 35.674801628328744 139.7377260502125 59.483 35.6748156266691 139.73777150243575 54.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5da66830-f582-4092-bd59-3760a7b66959">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5da66830-f582-4092-bd59-3760a7b66959_0">
											<gml:posList>35.6748156266691 139.73777150243575 54.229 35.6748156266691 139.73777150243575 53.338 35.674801628328744 139.7377260502125 53.338 35.6748156266691 139.73777150243575 54.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f26c1c1-a02a-497c-b212-6335c8091eb4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67471895366694 139.7377818360195 58.025 35.6746915360658 139.7377845420381 58.025 35.67471626965886 139.73777310115508 58.025 35.67471895366694 139.7377818360195 58.025</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-592b4e14-5576-4f36-9508-9cfcba88ed83">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67471895366694 139.7377818360195 58.025 35.674694229086775 139.73779327688945 58.025 35.6746915360658 139.7377845420381 58.025 35.67471895366694 139.7377818360195 58.025</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f8d68175-a954-490f-a302-139f2a1a214e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67471895366694 139.7377818360195 59.536 35.674694229086775 139.73779327688945 58.025 35.67471895366694 139.7377818360195 58.025 35.67471895366694 139.7377818360195 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-12c49f61-2f35-4fd1-a0d8-6e0f65e0ee84">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67471895366694 139.7377818360195 59.536 35.674694229086775 139.73779327688945 59.536 35.674694229086775 139.73779327688945 58.025 35.67471895366694 139.7377818360195 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a42df93e-fa88-4d27-bcc1-5f0ce9d4b725">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67472060743725 139.7377872028209 58.025 35.67472329140924 139.73779589349888 58.025 35.67469855781404 139.73780733437587 58.025 35.67472060743725 139.7377872028209 58.025</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ffe1a5ad-d4d7-46a1-bc5a-a1d140577d3c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674695882856575 139.73779864368947 58.025 35.67472060743725 139.7377872028209 58.025 35.67469855781404 139.73780733437587 58.025 35.674695882856575 139.73779864368947 58.025</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35648676-1ecf-4abf-bac7-abfc9445ad05">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67469855781404 139.73780733437587 59.536 35.67472329140924 139.73779589349888 58.025 35.67472329140924 139.73779589349888 59.536 35.67469855781404 139.73780733437587 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d2ac189a-f52b-46ca-89f2-2c633a631b9a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67469855781404 139.73780733437587 59.536 35.67469855781404 139.73780733437587 58.025 35.67472329140924 139.73779589349888 58.025 35.67469855781404 139.73780733437587 59.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1ea285bd-ce9d-497e-955b-9177214db6ab">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67469563218987 139.73782353254975 58.025 35.67476751740047 139.73777904955904 58.025 35.67477070764006 139.73778962865217 58.025 35.67469563218987 139.73782353254975 58.025</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1021aad0-1467-497e-a516-d9c2999193f8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67469563218987 139.73782353254975 58.025 35.67469245095818 139.7378129424076 58.025 35.67476751740047 139.73777904955904 58.025 35.67469563218987 139.73782353254975 58.025</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-143e360f-2ebf-4363-8aff-151b0e8d04e3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67476443824445 139.73776079276433 58.025 35.674719062893644 139.73777181639 58.025 35.674761754234865 139.73775205789568 58.025 35.67476443824445 139.73776079276433 58.025</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e57fe9c7-f0dd-4045-b34c-770246a2f59a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67476443824445 139.73776079276433 58.025 35.674721755906766 139.7377805401971 58.025 35.674719062893644 139.73777181639 58.025 35.67476443824445 139.73776079276433 58.025</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e43a1ebb-5284-4bda-a72b-a350259f06ad">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67472340967714 139.73778590699865 58.025 35.674768694664124 139.73777459626962 58.025 35.67472600331048 139.73779434370684 58.025 35.67472340967714 139.73778590699865 58.025</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c73310f1-de54-46de-be36-7e14d90b9c32">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67472340967714 139.73778590699865 58.025 35.67476610102941 139.73776615955762 58.025 35.674768694664124 139.73777459626962 58.025 35.67472340967714 139.73778590699865 58.025</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29101315-e000-436e-894c-2568ddb0e98b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6748156266691 139.73777150243575 53.338 35.67479987443471 139.73773081350444 53.338 35.674801628328744 139.7377260502125 53.338 35.6748156266691 139.73777150243575 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb461a57-19e4-415b-9050-f92776b36bea">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674676951207815 139.73778371986117 53.338 35.674801628328744 139.7377260502125 53.338 35.674680846851096 139.73778588040085 53.338 35.674676951207815 139.73778371986117 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bded752d-8843-4068-8578-d7cf3716d6c9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67480554905186 139.7378165967211 53.338 35.674701857158595 139.73786456419825 53.338 35.67478980471127 139.7378199184938 53.338 35.67480554905186 139.7378165967211 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5fb7babb-27fd-4806-8b56-22f893446380">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674676951207815 139.73778371986117 53.338 35.67470361105796 139.73785980091506 53.338 35.674701857158595 139.73786456419825 53.338 35.674676951207815 139.73778371986117 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8e0a26d-61d4-43c0-9868-9028d3a85bb1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67479568064814 139.73778456151658 53.338 35.674800651353614 139.73777842458006 53.338 35.6748016906047 139.73778179263616 53.338 35.67479568064814 139.73778456151658 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-935e85fd-8a93-4217-a776-9aaef8f62e17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67479568064814 139.73778456151658 53.338 35.67480554905186 139.7378165967211 53.338 35.674801653417965 139.73781444722346 53.338 35.67479568064814 139.73778456151658 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b9ce932-8b2c-404c-b1a8-1c01df4313c2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6748156266691 139.73777150243575 53.338 35.674800651353614 139.73777842458006 53.338 35.67481277026821 139.73777269890272 53.338 35.6748156266691 139.73777150243575 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a5181dc7-ca82-4ca5-9477-f3d5e76b7338">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67479987443471 139.73773081350444 53.338 35.674680846851096 139.73778588040085 53.338 35.674801628328744 139.7377260502125 53.338 35.67479987443471 139.73773081350444 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f9fbed11-4795-4268-b666-095b6af7ec0f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67481277026821 139.73777269890272 53.338 35.67479987443471 139.73773081350444 53.338 35.6748156266691 139.73777150243575 53.338 35.67481277026821 139.73777269890272 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c7c94b1-0645-46c3-bd45-22816ae2b959">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674676951207815 139.73778371986117 53.338 35.674680846851096 139.73778588040085 53.338 35.67470361105796 139.73785980091506 53.338 35.674676951207815 139.73778371986117 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d79e07b-541c-43b0-a104-47972c89c65d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674701857158595 139.73786456419825 53.338 35.67470361105796 139.73785980091506 53.338 35.67478980471127 139.7378199184938 53.338 35.674701857158595 139.73786456419825 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df6d56e7-a0ba-48ee-9365-3f8e51b64ea2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67480554905186 139.7378165967211 53.338 35.67478980471127 139.7378199184938 53.338 35.67479866195988 139.7378158316464 53.338 35.67480554905186 139.7378165967211 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82993d86-9413-49a0-8517-040a73de2281">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67479179402738 139.73778241201 53.338 35.674800651353614 139.73777842458006 53.338 35.67479568064814 139.73778456151658 53.338 35.67479179402738 139.73778241201 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b0b2613f-b947-45ee-93bb-512b85d851a8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674801653417965 139.73781444722346 53.338 35.67480554905186 139.7378165967211 53.338 35.67479866195988 139.7378158316464 53.338 35.674801653417965 139.73781444722346 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4becadba-414b-4d6e-a79e-d5f723a2cd01">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67479179402738 139.73778241201 53.338 35.67479568064814 139.73778456151658 53.338 35.674801653417965 139.73781444722346 53.338 35.67479179402738 139.73778241201 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7601c9bc-251c-4f77-bc30-0d40784f6f52">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67479179402738 139.73778241201 53.338 35.67481277026821 139.73777269890272 53.338 35.674800651353614 139.73777842458006 53.338 35.67479179402738 139.73778241201 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a7d5f1ad-82e0-472a-a689-96faef832c29">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67478980471127 139.7378199184938 53.338 35.67479042021489 139.73778907490822 53.338 35.67479866195988 139.7378158316464 53.338 35.67478980471127 139.7378199184938 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-95a2f1ea-7b02-44c7-87aa-901600aa8b13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67478980471127 139.7378199184938 53.338 35.67478157198964 139.73779317279428 53.338 35.67479042021489 139.73778907490822 53.338 35.67478980471127 139.7378199184938 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bdf5c3d7-bc63-4ddf-8ed5-2079c8c76815">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6748016906047 139.73778179263616 54.229 35.6748156266691 139.73777150243575 54.229 35.674816665911614 139.7377748594455 54.229 35.6748016906047 139.73778179263616 54.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48cfbaef-6553-4902-8f6f-2761e59e1a4b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6748016906047 139.73778179263616 54.229 35.674800651353614 139.73777842458006 54.229 35.6748156266691 139.73777150243575 54.229 35.6748016906047 139.73778179263616 54.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_aa352db3-fdec-4021-9bd2-3e276b212869_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd1e60d3-4809-4339-a028-ca7d0770ce6f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67482575847968 139.73777198746708 8.58 35.674839304995196 139.73781602625058 8.58 35.674819292841704 139.7378252631857 8.58 35.67480574633829 139.7377812354585 8.58 35.67482575847968 139.73777198746708 8.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c2a9bf22-8460-46ff-a6a4-1ba2135d6117">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c2a9bf22-8460-46ff-a6a4-1ba2135d6117_0">
											<gml:posList>35.674819292841704 139.7378252631857 54.229 35.67480574633829 139.7377812354585 54.229 35.67480574633829 139.7377812354585 8.58 35.674819292841704 139.7378252631857 8.58 35.674819292841704 139.7378252631857 54.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-536a2690-777c-429f-82b0-ecbdd5f47a0f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-536a2690-777c-429f-82b0-ecbdd5f47a0f_0">
											<gml:posList>35.67480574633829 139.7377812354585 54.229 35.67482575847968 139.73777198746708 54.229 35.67482575847968 139.73777198746708 8.58 35.67480574633829 139.7377812354585 8.58 35.67480574633829 139.7377812354585 54.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-05e5c4ca-f692-4bbe-834b-6555fc7cd2d2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-05e5c4ca-f692-4bbe-834b-6555fc7cd2d2_0">
											<gml:posList>35.674839304995196 139.73781602625058 54.229 35.67482575847968 139.73777198746708 54.229 35.67480574633829 139.7377812354585 54.229 35.674819292841704 139.7378252631857 54.229 35.674839304995196 139.73781602625058 54.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e270f7f3-2542-4ad2-ab06-a6c0d71f9d09">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e270f7f3-2542-4ad2-ab06-a6c0d71f9d09_0">
											<gml:posList>35.674839304995196 139.73781602625058 54.229 35.674819292841704 139.7378252631857 54.229 35.674819292841704 139.7378252631857 8.58 35.674839304995196 139.73781602625058 8.58 35.674839304995196 139.73781602625058 54.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-92020329-eea6-4f44-8d35-88b4b252eb55">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-92020329-eea6-4f44-8d35-88b4b252eb55_0">
											<gml:posList>35.67482575847968 139.73777198746708 54.229 35.674839304995196 139.73781602625058 54.229 35.674839304995196 139.73781602625058 8.58 35.67482575847968 139.73777198746708 8.58 35.67482575847968 139.73777198746708 54.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_aa352db3-fdec-4021-9bd2-3e276b212869_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fdd94858-bde3-4502-b804-13c80792c583">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67479266692883 139.73778061033022 53.338 35.67469452543062 139.73782596417618 53.338 35.674682298339825 139.7377862321701 53.338 35.67478043982321 139.73774087828247 53.338 35.67479266692883 139.73778061033022 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d65198b1-7985-42bd-8433-5445c6f3b380">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67477966099525 139.7378157880052 53.338 35.67471807476852 139.73784425180847 53.338 35.67471096261848 139.73782111711708 53.338 35.67477253983483 139.73779266435616 53.338 35.67477966099525 139.7378157880052 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9bdfffe3-ea65-4314-aa41-1c000ce71af4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9bdfffe3-ea65-4314-aa41-1c000ce71af4_0">
											<gml:posList>35.67477253983483 139.73779266435616 53.338 35.67471096261848 139.73782111711708 53.338 35.67471096261848 139.73782111711708 56.834 35.67477253983483 139.73779266435616 56.834 35.67477253983483 139.73779266435616 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4f5c3be5-4858-49cd-ab79-2eee2ba53e6b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4f5c3be5-4858-49cd-ab79-2eee2ba53e6b_0">
											<gml:posList>35.674682298339825 139.7377862321701 58.025 35.674682298339825 139.7377862321701 53.338 35.67469452543062 139.73782596417618 53.338 35.67469452543062 139.73782596417618 58.025 35.674682298339825 139.7377862321701 58.025</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b1d7fafb-5276-42fb-b677-0a4f2dc1d256">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b1d7fafb-5276-42fb-b677-0a4f2dc1d256_0">
											<gml:posList>35.67471807476852 139.73784425180847 56.834 35.67471096261848 139.73782111711708 56.834 35.67471096261848 139.73782111711708 53.338 35.67471807476852 139.73784425180847 53.338 35.67471807476852 139.73784425180847 56.834</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e4758604-cd21-4455-94ad-274e48678381">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e4758604-cd21-4455-94ad-274e48678381_0">
											<gml:posList>35.67478043982321 139.73774087828247 53.338 35.674682298339825 139.7377862321701 53.338 35.674682298339825 139.7377862321701 58.025 35.67478043982321 139.73774087828247 58.025 35.67478043982321 139.73774087828247 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4f11e0e9-fd17-46df-87c9-ed9abc30c26c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4f11e0e9-fd17-46df-87c9-ed9abc30c26c_0">
											<gml:posList>35.67479266692883 139.73778061033022 58.025 35.67478043982321 139.73774087828247 58.025 35.674682298339825 139.7377862321701 58.025 35.67469452543062 139.73782596417618 58.025 35.67479266692883 139.73778061033022 58.025</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c16703e1-9efd-480d-9f5c-81cf1baaebaf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c16703e1-9efd-480d-9f5c-81cf1baaebaf_0">
											<gml:posList>35.67479266692883 139.73778061033022 58.025 35.67469452543062 139.73782596417618 58.025 35.67469452543062 139.73782596417618 53.338 35.67479266692883 139.73778061033022 53.338 35.67479266692883 139.73778061033022 58.025</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-feff9229-7558-4003-85af-35b9cd7f7bec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-feff9229-7558-4003-85af-35b9cd7f7bec_0">
											<gml:posList>35.67477966099525 139.7378157880052 56.834 35.67477253983483 139.73779266435616 56.834 35.67471096261848 139.73782111711708 56.834 35.67471807476852 139.73784425180847 56.834 35.67477966099525 139.7378157880052 56.834</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-65ae95ec-5fc0-401f-8847-c5aba80680aa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-65ae95ec-5fc0-401f-8847-c5aba80680aa_0">
											<gml:posList>35.67477966099525 139.7378157880052 56.834 35.67471807476852 139.73784425180847 56.834 35.67471807476852 139.73784425180847 53.338 35.67477966099525 139.7378157880052 53.338 35.67477966099525 139.7378157880052 56.834</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-768daa20-79c1-4c4a-81ae-5b81c680fbc6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-768daa20-79c1-4c4a-81ae-5b81c680fbc6_0">
											<gml:posList>35.67477966099525 139.7378157880052 56.834 35.67477966099525 139.7378157880052 53.338 35.67477253983483 139.73779266435616 53.338 35.67477253983483 139.73779266435616 56.834 35.67477966099525 139.7378157880052 56.834</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca92f9f6-5741-4d30-8a37-2032285f862a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ca92f9f6-5741-4d30-8a37-2032285f862a_0">
											<gml:posList>35.67479266692883 139.73778061033022 53.338 35.67478043982321 139.73774087828247 53.338 35.67478043982321 139.73774087828247 58.025 35.67479266692883 139.73778061033022 58.025 35.67479266692883 139.73778061033022 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-ea1782d0-c4a6-4c7f-8aad-39014bafe240">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea1782d0-c4a6-4c7f-8aad-39014bafe240">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea1782d0-c4a6-4c7f-8aad-39014bafe240">
											<gml:posList>35.67480574633829 139.7377812354585 8.22 35.67481930185542 139.73782526317495 8.22 35.67465942993345 139.73789914717446 8.22 35.67464843189411 139.73786340162266 8.22 35.67463724094086 139.7378685627803 8.22 35.67463233383622 139.73785260593283 8.22 35.67464280394559 139.73784776599044 8.22 35.674625326333974 139.73779095079536 8.22 35.67480592214699 139.73770748635164 8.22 35.67482575847968 139.73777198746708 8.22 35.67480574633829 139.7377812354585 8.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-aa1741ce-4aad-4af7-8ee5-c75dde7bcd83">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa1741ce-4aad-4af7-8ee5-c75dde7bcd83">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa1741ce-4aad-4af7-8ee5-c75dde7bcd83">
											<gml:posList>35.67480592214699 139.73770748635164 54.229 35.67480361960138 139.73771374162595 54.229 35.67482066349479 139.73776917658856 54.229 35.67482575847968 139.73777198746708 54.229 35.67480592214699 139.73770748635164 54.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f4dcdf92-8f3e-4c50-96b2-73032427d749">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4dcdf92-8f3e-4c50-96b2-73032427d749">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4dcdf92-8f3e-4c50-96b2-73032427d749">
											<gml:posList>35.67466131394703 139.7377743155372 54.229 35.67466641796317 139.73777714849342 54.229 35.67480361960138 139.73771374162595 54.229 35.67480592214699 139.73770748635164 54.229 35.67466131394703 139.7377743155372 54.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bfbc2110-355c-40ca-8fa1-a29bea824a4a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bfbc2110-355c-40ca-8fa1-a29bea824a4a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bfbc2110-355c-40ca-8fa1-a29bea824a4a">
											<gml:posList>35.67480574633829 139.7377812354585 54.229 35.67482575847968 139.73777198746708 54.229 35.67482066349479 139.73776917658856 54.229 35.674800651353614 139.73777842458006 54.229 35.67480574633829 139.7377812354585 54.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d556a559-0f8f-44c0-8d16-0136f1a94ec4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d556a559-0f8f-44c0-8d16-0136f1a94ec4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d556a559-0f8f-44c0-8d16-0136f1a94ec4">
											<gml:posList>35.674631314088316 139.7377942798062 18.297 35.674662949655186 139.73777963816875 18.297 35.67466131394703 139.7377743155372 18.297 35.674625326333974 139.73779095079536 18.297 35.674631314088316 139.7377942798062 18.297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7dde33dd-9430-47cf-a732-24c60e9ed376">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7dde33dd-9430-47cf-a732-24c60e9ed376">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7dde33dd-9430-47cf-a732-24c60e9ed376">
											<gml:posList>35.67467086609355 139.73780536789397 54.229 35.67467457841218 139.73780368434888 54.229 35.67466641796317 139.73777714849342 54.229 35.67466131394703 139.7377743155372 54.229 35.67467086609355 139.73780536789397 54.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b81b5f64-e592-424a-9df7-be3d42b84973">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b81b5f64-e592-424a-9df7-be3d42b84973">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b81b5f64-e592-424a-9df7-be3d42b84973">
											<gml:posList>35.674800651353614 139.73777842458006 53.338 35.67482066349479 139.73776917658856 53.338 35.67480361960138 139.73771374162595 53.338 35.67466641796317 139.73777714849342 53.338 35.67467457841218 139.73780368434888 53.338 35.6746869781683 139.73784519469143 53.338 35.67469668393255 139.737876755039 53.338 35.67481420686301 139.73782244124638 53.338 35.674800651353614 139.73777842458006 53.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2e180548-0c4f-46ca-930f-38386557056f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2e180548-0c4f-46ca-930f-38386557056f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2e180548-0c4f-46ca-930f-38386557056f">
											<gml:posList>35.67480574633829 139.7377812354585 54.229 35.674800651353614 139.73777842458006 54.229 35.67481420686301 139.73782244124638 54.229 35.67481930185542 139.73782526317495 54.229 35.67480574633829 139.7377812354585 54.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-69c5febe-83bc-48aa-91c3-c79111843d13">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69c5febe-83bc-48aa-91c3-c79111843d13">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69c5febe-83bc-48aa-91c3-c79111843d13">
											<gml:posList>35.67464280394559 139.73784776599044 18.297 35.674648782675874 139.73785108397013 18.297 35.674631314088316 139.7377942798062 18.297 35.674625326333974 139.73779095079536 18.297 35.67464280394559 139.73784776599044 18.297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-54ee75d4-73fd-40f0-9b41-c20157c89833">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-54ee75d4-73fd-40f0-9b41-c20157c89833">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-54ee75d4-73fd-40f0-9b41-c20157c89833">
											<gml:posList>35.67468326586662 139.73784690032855 54.229 35.6746869781683 139.73784519469143 54.229 35.67467457841218 139.73780368434888 54.229 35.67467086609355 139.73780536789397 54.229 35.67468326586662 139.73784690032855 54.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-45c496ba-cf28-441b-ba3d-b7a758d0c6c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45c496ba-cf28-441b-ba3d-b7a758d0c6c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45c496ba-cf28-441b-ba3d-b7a758d0c6c4">
											<gml:posList>35.67467481409379 139.73785080993406 54.229 35.67468326586662 139.73784690032855 54.229 35.67467086609355 139.73780536789397 54.229 35.674665036358036 139.73780807027225 54.229 35.674670738708414 139.73782658904534 54.229 35.67466778328747 139.73782795132888 54.229 35.67467481409379 139.73785080993406 54.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3a7bdd0d-1089-402c-8733-96ec88e3bca3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a7bdd0d-1089-402c-8733-96ec88e3bca3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a7bdd0d-1089-402c-8733-96ec88e3bca3">
											<gml:posList>35.674692727629555 139.73787766559195 17.976 35.67468326586662 139.73784690032855 17.976 35.67467481409379 139.73785080993406 17.976 35.67466778328747 139.73782795132888 17.976 35.674670738708414 139.73782658904534 17.976 35.674665036358036 139.73780807027225 17.976 35.67467086609355 139.73780536789397 17.976 35.674662949655186 139.73777963816875 17.976 35.674631314088316 139.7377942798062 17.976 35.674648782675874 139.73785108397013 17.976 35.6746383215801 139.73785592390172 17.976 35.67463994826218 139.7378612354973 17.976 35.67465113921511 139.73785607433845 17.976 35.67466213725661 139.73789181989045 17.976 35.674692727629555 139.73787766559195 17.976</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8f43b87e-0208-4bb5-926b-f27bd560b5e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f43b87e-0208-4bb5-926b-f27bd560b5e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f43b87e-0208-4bb5-926b-f27bd560b5e7">
											<gml:posList>35.67464280394559 139.73784776599044 18.297 35.67463233383622 139.73785260593283 18.297 35.6746383215801 139.73785592390172 18.297 35.674648782675874 139.73785108397013 18.297 35.67464280394559 139.73784776599044 18.297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-035ef84c-35b5-4842-b608-4572baecb0cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-035ef84c-35b5-4842-b608-4572baecb0cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-035ef84c-35b5-4842-b608-4572baecb0cd">
											<gml:posList>35.67481930185542 139.73782526317495 54.229 35.67481420686301 139.73782244124638 54.229 35.67469668393255 139.737876755039 54.229 35.674694372355624 139.7378829992638 54.229 35.67481930185542 139.73782526317495 54.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2870863f-8c3f-4baa-99d6-eb26f4ec32cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2870863f-8c3f-4baa-99d6-eb26f4ec32cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2870863f-8c3f-4baa-99d6-eb26f4ec32cb">
											<gml:posList>35.67463724094086 139.7378685627803 18.297 35.67463994826218 139.7378612354973 18.297 35.6746383215801 139.73785592390172 18.297 35.67463233383622 139.73785260593283 18.297 35.67463724094086 139.7378685627803 18.297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-201b4e75-a424-490a-9021-23ade9bc1487">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-201b4e75-a424-490a-9021-23ade9bc1487">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-201b4e75-a424-490a-9021-23ade9bc1487">
											<gml:posList>35.67464843189411 139.73786340162266 18.297 35.67465113921511 139.73785607433845 18.297 35.67463994826218 139.7378612354973 18.297 35.67463724094086 139.7378685627803 18.297 35.67464843189411 139.73786340162266 18.297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8965d9ce-94c5-4afe-b14c-0d07e1423db4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8965d9ce-94c5-4afe-b14c-0d07e1423db4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8965d9ce-94c5-4afe-b14c-0d07e1423db4">
											<gml:posList>35.67468326586662 139.73784690032855 54.229 35.674694372355624 139.7378829992638 54.229 35.67469668393255 139.737876755039 54.229 35.6746869781683 139.73784519469143 54.229 35.67468326586662 139.73784690032855 54.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-af1ef5ff-d65f-4e57-9ead-328f1ddd2d4a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af1ef5ff-d65f-4e57-9ead-328f1ddd2d4a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af1ef5ff-d65f-4e57-9ead-328f1ddd2d4a">
											<gml:posList>35.67464843189411 139.73786340162266 18.297 35.67465942993345 139.73789914717446 18.297 35.67466213725661 139.73789181989045 18.297 35.67465113921511 139.73785607433845 18.297 35.67464843189411 139.73786340162266 18.297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b0b553fe-4ae3-4ee6-a60e-2e998f76bbd5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b0b553fe-4ae3-4ee6-a60e-2e998f76bbd5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b0b553fe-4ae3-4ee6-a60e-2e998f76bbd5">
											<gml:posList>35.67466213725661 139.73789181989045 18.297 35.67465942993345 139.73789914717446 18.297 35.674694372355624 139.7378829992638 18.297 35.674692727629555 139.73787766559195 18.297 35.67466213725661 139.73789181989045 18.297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b85a6ac9-ac22-4ebc-a594-e6c321833ca0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b85a6ac9-ac22-4ebc-a594-e6c321833ca0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b85a6ac9-ac22-4ebc-a594-e6c321833ca0">
											<gml:posList>35.67482066349479 139.73776917658856 54.229 35.67482066349479 139.73776917658856 53.338 35.674800651353614 139.73777842458006 53.338 35.674800651353614 139.73777842458006 54.229 35.67482066349479 139.73776917658856 54.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5252f442-95d7-4e49-bb84-325237cb0cb6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5252f442-95d7-4e49-bb84-325237cb0cb6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5252f442-95d7-4e49-bb84-325237cb0cb6">
											<gml:posList>35.67482575847968 139.73777198746708 8.22 35.67480592214699 139.73770748635164 8.22 35.67480592214699 139.73770748635164 54.229 35.67482575847968 139.73777198746708 54.229 35.67482575847968 139.73777198746708 8.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-89e9eb2e-d6ff-493f-995b-db95dddf8e46">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-89e9eb2e-d6ff-493f-995b-db95dddf8e46">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-89e9eb2e-d6ff-493f-995b-db95dddf8e46">
											<gml:posList>35.67480361960138 139.73771374162595 54.229 35.67480361960138 139.73771374162595 53.338 35.67482066349479 139.73776917658856 53.338 35.67482066349479 139.73776917658856 54.229 35.67480361960138 139.73771374162595 54.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-50843277-9a1e-4a11-a4a3-83607bcf1065">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50843277-9a1e-4a11-a4a3-83607bcf1065">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50843277-9a1e-4a11-a4a3-83607bcf1065">
											<gml:posList>35.67466641796317 139.73777714849342 54.229 35.67466641796317 139.73777714849342 53.338 35.67480361960138 139.73771374162595 53.338 35.67480361960138 139.73771374162595 54.229 35.67466641796317 139.73777714849342 54.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-da63d7ab-91c8-486f-bd48-9ca99fb771a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da63d7ab-91c8-486f-bd48-9ca99fb771a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da63d7ab-91c8-486f-bd48-9ca99fb771a3">
											<gml:posList>35.674625326333974 139.73779095079536 8.22 35.674625326333974 139.73779095079536 18.297 35.67466131394703 139.7377743155372 18.297 35.67466131394703 139.7377743155372 54.229 35.67480592214699 139.73770748635164 54.229 35.67480592214699 139.73770748635164 8.22 35.674625326333974 139.73779095079536 8.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7209b079-ad3f-4c6f-a085-164950d98a21">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7209b079-ad3f-4c6f-a085-164950d98a21">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7209b079-ad3f-4c6f-a085-164950d98a21">
											<gml:posList>35.67480574633829 139.7377812354585 8.22 35.67482575847968 139.73777198746708 8.22 35.67482575847968 139.73777198746708 54.229 35.67480574633829 139.7377812354585 54.229 35.67480574633829 139.7377812354585 8.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5e144521-1e87-4f82-9862-3fcca3ad38e1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e144521-1e87-4f82-9862-3fcca3ad38e1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e144521-1e87-4f82-9862-3fcca3ad38e1">
											<gml:posList>35.674631314088316 139.7377942798062 18.297 35.674631314088316 139.7377942798062 17.976 35.674662949655186 139.73777963816875 17.976 35.674662949655186 139.73777963816875 18.297 35.674631314088316 139.7377942798062 18.297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d41f9e64-6776-49ec-bc3f-980bece42ecb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d41f9e64-6776-49ec-bc3f-980bece42ecb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d41f9e64-6776-49ec-bc3f-980bece42ecb">
											<gml:posList>35.67467086609355 139.73780536789397 17.976 35.67467086609355 139.73780536789397 54.229 35.67466131394703 139.7377743155372 54.229 35.67466131394703 139.7377743155372 18.297 35.674662949655186 139.73777963816875 18.297 35.674662949655186 139.73777963816875 17.976 35.67467086609355 139.73780536789397 17.976</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7dd94f8e-f568-4d0d-89dc-d46232040c6f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7dd94f8e-f568-4d0d-89dc-d46232040c6f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7dd94f8e-f568-4d0d-89dc-d46232040c6f">
											<gml:posList>35.67467457841218 139.73780368434888 54.229 35.67467457841218 139.73780368434888 53.338 35.67466641796317 139.73777714849342 53.338 35.67466641796317 139.73777714849342 54.229 35.67467457841218 139.73780368434888 54.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2d9032ea-b91d-41ef-9c03-75453fc81cec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d9032ea-b91d-41ef-9c03-75453fc81cec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d9032ea-b91d-41ef-9c03-75453fc81cec">
											<gml:posList>35.674800651353614 139.73777842458006 54.229 35.674800651353614 139.73777842458006 53.338 35.67481420686301 139.73782244124638 53.338 35.67481420686301 139.73782244124638 54.229 35.674800651353614 139.73777842458006 54.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-28359b70-d6ca-43c0-a243-6e80d8d81ab3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28359b70-d6ca-43c0-a243-6e80d8d81ab3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28359b70-d6ca-43c0-a243-6e80d8d81ab3">
											<gml:posList>35.67481930185542 139.73782526317495 8.22 35.67480574633829 139.7377812354585 8.22 35.67480574633829 139.7377812354585 54.229 35.67481930185542 139.73782526317495 54.229 35.67481930185542 139.73782526317495 8.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7ee07ca9-6aec-4f36-92e9-fec6bb8f8337">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ee07ca9-6aec-4f36-92e9-fec6bb8f8337">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ee07ca9-6aec-4f36-92e9-fec6bb8f8337">
											<gml:posList>35.674665036358036 139.73780807027225 54.229 35.67467086609355 139.73780536789397 54.229 35.67467086609355 139.73780536789397 17.976 35.674665036358036 139.73780807027225 17.976 35.674665036358036 139.73780807027225 54.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-72a69997-2395-41d7-a9a7-284c0d0c629a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-72a69997-2395-41d7-a9a7-284c0d0c629a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-72a69997-2395-41d7-a9a7-284c0d0c629a">
											<gml:posList>35.674665036358036 139.73780807027225 17.976 35.674670738708414 139.73782658904534 17.976 35.674670738708414 139.73782658904534 54.229 35.674665036358036 139.73780807027225 54.229 35.674665036358036 139.73780807027225 17.976</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e8f9bc65-c37c-4747-8176-3ac4427eb2c6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8f9bc65-c37c-4747-8176-3ac4427eb2c6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8f9bc65-c37c-4747-8176-3ac4427eb2c6">
											<gml:posList>35.674625326333974 139.73779095079536 8.22 35.67464280394559 139.73784776599044 8.22 35.67464280394559 139.73784776599044 18.297 35.674625326333974 139.73779095079536 18.297 35.674625326333974 139.73779095079536 8.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fab312da-9a7a-4196-8b5d-54231da44d45">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fab312da-9a7a-4196-8b5d-54231da44d45">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fab312da-9a7a-4196-8b5d-54231da44d45">
											<gml:posList>35.674648782675874 139.73785108397013 18.297 35.674648782675874 139.73785108397013 17.976 35.674631314088316 139.7377942798062 17.976 35.674631314088316 139.7377942798062 18.297 35.674648782675874 139.73785108397013 18.297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8391013e-04b8-4f90-91a0-a8b3f6b182e0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8391013e-04b8-4f90-91a0-a8b3f6b182e0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8391013e-04b8-4f90-91a0-a8b3f6b182e0">
											<gml:posList>35.6746869781683 139.73784519469143 54.229 35.6746869781683 139.73784519469143 53.338 35.67467457841218 139.73780368434888 53.338 35.67467457841218 139.73780368434888 54.229 35.6746869781683 139.73784519469143 54.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-15547406-6959-471d-b673-aab95dc4f75b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15547406-6959-471d-b673-aab95dc4f75b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15547406-6959-471d-b673-aab95dc4f75b">
											<gml:posList>35.67466778328747 139.73782795132888 54.229 35.674670738708414 139.73782658904534 54.229 35.674670738708414 139.73782658904534 17.976 35.67466778328747 139.73782795132888 17.976 35.67466778328747 139.73782795132888 54.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-13f7d625-918f-47e4-b66a-a2ab46504e65">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13f7d625-918f-47e4-b66a-a2ab46504e65">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13f7d625-918f-47e4-b66a-a2ab46504e65">
											<gml:posList>35.67466778328747 139.73782795132888 17.976 35.67467481409379 139.73785080993406 17.976 35.67467481409379 139.73785080993406 54.229 35.67466778328747 139.73782795132888 54.229 35.67466778328747 139.73782795132888 17.976</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5ceda92e-8abd-4885-9089-fe28e108a88c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5ceda92e-8abd-4885-9089-fe28e108a88c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5ceda92e-8abd-4885-9089-fe28e108a88c">
											<gml:posList>35.67467481409379 139.73785080993406 17.976 35.67468326586662 139.73784690032855 17.976 35.67468326586662 139.73784690032855 54.229 35.67467481409379 139.73785080993406 54.229 35.67467481409379 139.73785080993406 17.976</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8387bdfa-3c5f-4e7d-8e1b-8608aea6c7e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8387bdfa-3c5f-4e7d-8e1b-8608aea6c7e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8387bdfa-3c5f-4e7d-8e1b-8608aea6c7e7">
											<gml:posList>35.67481420686301 139.73782244124638 54.229 35.67481420686301 139.73782244124638 53.338 35.67469668393255 139.737876755039 53.338 35.67469668393255 139.737876755039 54.229 35.67481420686301 139.73782244124638 54.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8165fa54-19de-4691-ac44-81d854672ed6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8165fa54-19de-4691-ac44-81d854672ed6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8165fa54-19de-4691-ac44-81d854672ed6">
											<gml:posList>35.67464280394559 139.73784776599044 8.22 35.67463233383622 139.73785260593283 8.22 35.67463233383622 139.73785260593283 18.297 35.67464280394559 139.73784776599044 18.297 35.67464280394559 139.73784776599044 8.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3620f74f-d6ad-4923-aeb6-49cf43e3bec3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3620f74f-d6ad-4923-aeb6-49cf43e3bec3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3620f74f-d6ad-4923-aeb6-49cf43e3bec3">
											<gml:posList>35.6746383215801 139.73785592390172 18.297 35.6746383215801 139.73785592390172 17.976 35.674648782675874 139.73785108397013 17.976 35.674648782675874 139.73785108397013 18.297 35.6746383215801 139.73785592390172 18.297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1a02f3d2-21ca-4d5c-a0ab-e03b179f2786">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a02f3d2-21ca-4d5c-a0ab-e03b179f2786">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a02f3d2-21ca-4d5c-a0ab-e03b179f2786">
											<gml:posList>35.67463994826218 139.7378612354973 18.297 35.67463994826218 139.7378612354973 17.976 35.6746383215801 139.73785592390172 17.976 35.6746383215801 139.73785592390172 18.297 35.67463994826218 139.7378612354973 18.297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-08aec75b-0ccc-4bc1-a8e1-769885355240">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-08aec75b-0ccc-4bc1-a8e1-769885355240">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-08aec75b-0ccc-4bc1-a8e1-769885355240">
											<gml:posList>35.67465113921511 139.73785607433845 18.297 35.67465113921511 139.73785607433845 17.976 35.67463994826218 139.7378612354973 17.976 35.67463994826218 139.7378612354973 18.297 35.67465113921511 139.73785607433845 18.297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d51fd8d0-befd-49a4-bf32-afeb0884bae9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d51fd8d0-befd-49a4-bf32-afeb0884bae9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d51fd8d0-befd-49a4-bf32-afeb0884bae9">
											<gml:posList>35.67463233383622 139.73785260593283 8.22 35.67463724094086 139.7378685627803 8.22 35.67463724094086 139.7378685627803 18.297 35.67463233383622 139.73785260593283 18.297 35.67463233383622 139.73785260593283 8.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6de98fd1-3633-480c-82c8-345526dca61b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6de98fd1-3633-480c-82c8-345526dca61b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6de98fd1-3633-480c-82c8-345526dca61b">
											<gml:posList>35.67469668393255 139.737876755039 54.229 35.67469668393255 139.737876755039 53.338 35.6746869781683 139.73784519469143 53.338 35.6746869781683 139.73784519469143 54.229 35.67469668393255 139.737876755039 54.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-981b9753-6036-4d8a-b391-3447d9e7a4d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-981b9753-6036-4d8a-b391-3447d9e7a4d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-981b9753-6036-4d8a-b391-3447d9e7a4d8">
											<gml:posList>35.67481930185542 139.73782526317495 8.22 35.67481930185542 139.73782526317495 54.229 35.674694372355624 139.7378829992638 54.229 35.674694372355624 139.7378829992638 18.297 35.67465942993345 139.73789914717446 18.297 35.67465942993345 139.73789914717446 8.22 35.67481930185542 139.73782526317495 8.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-27b2fa89-7ffe-43b5-b3b4-cda6272fb76a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-27b2fa89-7ffe-43b5-b3b4-cda6272fb76a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-27b2fa89-7ffe-43b5-b3b4-cda6272fb76a">
											<gml:posList>35.674692727629555 139.73787766559195 18.297 35.674694372355624 139.7378829992638 18.297 35.674694372355624 139.7378829992638 54.229 35.67468326586662 139.73784690032855 54.229 35.67468326586662 139.73784690032855 17.976 35.674692727629555 139.73787766559195 17.976 35.674692727629555 139.73787766559195 18.297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-356844af-f34e-4732-a30d-7c1a0090eeda">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-356844af-f34e-4732-a30d-7c1a0090eeda">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-356844af-f34e-4732-a30d-7c1a0090eeda">
											<gml:posList>35.67463724094086 139.7378685627803 8.22 35.67464843189411 139.73786340162266 8.22 35.67464843189411 139.73786340162266 18.297 35.67463724094086 139.7378685627803 18.297 35.67463724094086 139.7378685627803 8.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ebfe7511-aacc-4d70-b612-08949cf77414">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ebfe7511-aacc-4d70-b612-08949cf77414">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ebfe7511-aacc-4d70-b612-08949cf77414">
											<gml:posList>35.67466213725661 139.73789181989045 18.297 35.67466213725661 139.73789181989045 17.976 35.67465113921511 139.73785607433845 17.976 35.67465113921511 139.73785607433845 18.297 35.67466213725661 139.73789181989045 18.297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a68113d8-acde-459a-854c-38342ca13b85">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a68113d8-acde-459a-854c-38342ca13b85">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a68113d8-acde-459a-854c-38342ca13b85">
											<gml:posList>35.67464843189411 139.73786340162266 8.22 35.67465942993345 139.73789914717446 8.22 35.67465942993345 139.73789914717446 18.297 35.67464843189411 139.73786340162266 18.297 35.67464843189411 139.73786340162266 8.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5eae7c2d-f7a1-4635-908b-75b41e53aa00">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5eae7c2d-f7a1-4635-908b-75b41e53aa00">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5eae7c2d-f7a1-4635-908b-75b41e53aa00">
											<gml:posList>35.674692727629555 139.73787766559195 18.297 35.674692727629555 139.73787766559195 17.976 35.67466213725661 139.73789181989045 17.976 35.67466213725661 139.73789181989045 18.297 35.674692727629555 139.73787766559195 18.297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1897</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.24</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>