<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_aa8c696e-0ded-4477-99df-a1604d497fb2">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">23.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67036763027777 139.74161788621993 0 35.67037263554385 139.74144401238544 0 35.67031034852618 139.74144121174578 0 35.67030639798109 139.7415797362408 0 35.670305957815515 139.7415935445562 0 35.670345709764916 139.74159537693507 0 35.67034509521298 139.7416169178349 0 35.67036763027777 139.74161788621993 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67036763027777 139.74161788621993 8.499 35.67034509521298 139.7416169178349 8.499 35.670345709764916 139.74159537693507 8.499 35.670305957815515 139.7415935445562 8.499 35.67030639798109 139.7415797362408 8.499 35.67031034852618 139.74144121174578 8.499 35.67037263554385 139.74144401238544 8.499 35.67036763027777 139.74161788621993 8.499</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67036763027777 139.74161788621993 8.499 35.67037263554385 139.74144401238544 8.499 35.67037263554385 139.74144401238544 31.15 35.67036763027777 139.74161788621993 31.15 35.67036763027777 139.74161788621993 8.499</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67037263554385 139.74144401238544 8.499 35.67031034852618 139.74144121174578 8.499 35.67031034852618 139.74144121174578 31.15 35.67037263554385 139.74144401238544 31.15 35.67037263554385 139.74144401238544 8.499</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67031034852618 139.74144121174578 8.499 35.67030639798109 139.7415797362408 8.499 35.67030639798109 139.7415797362408 31.15 35.67031034852618 139.74144121174578 31.15 35.67031034852618 139.74144121174578 8.499</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67030639798109 139.7415797362408 8.499 35.670305957815515 139.7415935445562 8.499 35.670305957815515 139.7415935445562 31.15 35.67030639798109 139.7415797362408 31.15 35.67030639798109 139.7415797362408 8.499</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670305957815515 139.7415935445562 8.499 35.670345709764916 139.74159537693507 8.499 35.670345709764916 139.74159537693507 31.15 35.670305957815515 139.7415935445562 31.15 35.670305957815515 139.7415935445562 8.499</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670345709764916 139.74159537693507 8.499 35.67034509521298 139.7416169178349 8.499 35.67034509521298 139.7416169178349 31.15 35.670345709764916 139.74159537693507 31.15 35.670345709764916 139.74159537693507 8.499</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67034509521298 139.7416169178349 8.499 35.67036763027777 139.74161788621993 8.499 35.67036763027777 139.74161788621993 31.15 35.67034509521298 139.7416169178349 31.15 35.67034509521298 139.7416169178349 8.499</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67036763027777 139.74161788621993 31.15 35.67037263554385 139.74144401238544 31.15 35.67031034852618 139.74144121174578 31.15 35.67030639798109 139.7415797362408 31.15 35.670305957815515 139.7415935445562 31.15 35.670345709764916 139.74159537693507 31.15 35.67034509521298 139.7416169178349 31.15 35.67036763027777 139.74161788621993 31.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-7762335b-aea4-4e36-965f-5585a4bf5e7f"/>
							<gml:surfaceMember xlink:href="#poly-351c98ea-7543-4b2e-8f14-518ddc7d727e"/>
							<gml:surfaceMember xlink:href="#poly-ba9672c8-289e-4d39-a335-9a53206c9b13"/>
							<gml:surfaceMember xlink:href="#poly-0e95fe28-5080-4918-870e-417aa79ed462"/>
							<gml:surfaceMember xlink:href="#poly-55e424e4-c650-4963-9340-c1cd50d910fb"/>
							<gml:surfaceMember xlink:href="#poly-b87c1bc9-8c65-414e-8020-2871a7d54d45"/>
							<gml:surfaceMember xlink:href="#poly-c86fff53-c5b2-4a5a-8dba-d85bf61fbd67"/>
							<gml:surfaceMember xlink:href="#poly-c2ab36aa-81de-4849-b21c-9317259d2f73"/>
							<gml:surfaceMember xlink:href="#poly-295a69fc-2fb7-451f-9da9-7a2bee8204ea"/>
							<gml:surfaceMember xlink:href="#poly-5f1ec6a3-655d-44a9-947e-c8f64d212536"/>
							<gml:surfaceMember xlink:href="#poly-a446c188-c223-47f2-bda1-ef215975d050"/>
							<gml:surfaceMember xlink:href="#poly-dac07d92-c345-4b20-a2f3-4385e0afb916"/>
							<gml:surfaceMember xlink:href="#poly-96ac749e-6beb-4fb7-b754-28fca538254a"/>
							<gml:surfaceMember xlink:href="#poly-beac103f-0d83-477d-a6ac-be094d4d9575"/>
							<gml:surfaceMember xlink:href="#poly-a17e621e-9dd1-4e11-94db-eb7ddd68e6ff"/>
							<gml:surfaceMember xlink:href="#poly-e11d87f8-c8ae-4126-a861-cd836b4b6648"/>
							<gml:surfaceMember xlink:href="#poly-46c72e1e-c4a3-4fea-b584-c72f052cefa2"/>
							<gml:surfaceMember xlink:href="#poly-e942036f-0eee-4cdb-bf6b-73070a985068"/>
							<gml:surfaceMember xlink:href="#poly-77cd5d33-636f-4b0f-80d3-0a1ea62bde60"/>
							<gml:surfaceMember xlink:href="#poly-a9049475-84f6-45dd-b3c2-308cd5c9963b"/>
							<gml:surfaceMember xlink:href="#poly-497b7bcc-1161-45a6-be8c-2eb733fc0970"/>
							<gml:surfaceMember xlink:href="#poly-de64d39d-aec2-4e9a-8b0f-7f14fee9583d"/>
							<gml:surfaceMember xlink:href="#poly-280faf3a-3d6a-4664-89a4-cd6a3176b62c"/>
							<gml:surfaceMember xlink:href="#poly-bcf801fc-2b85-4d63-b501-e7039963352d"/>
							<gml:surfaceMember xlink:href="#poly-1e6bba54-a870-4c9a-bc64-98a67f2ecec4"/>
							<gml:surfaceMember xlink:href="#poly-f1019fde-928f-4fc9-af8e-ca5ab6662125"/>
							<gml:surfaceMember xlink:href="#poly-baa59f7c-af58-4eb1-ad91-7c70516f2778"/>
							<gml:surfaceMember xlink:href="#poly-6543e8bf-d91a-483a-93ad-a3be69e15f31"/>
							<gml:surfaceMember xlink:href="#poly-670ef77f-be1a-4663-9b6d-dc6c43ddcd14"/>
							<gml:surfaceMember xlink:href="#poly-334ac17d-8885-49c9-b4d9-03a476ca5744"/>
							<gml:surfaceMember xlink:href="#poly-9dd32751-aafa-459d-bab9-2902e95f5829"/>
							<gml:surfaceMember xlink:href="#poly-33816684-c8f3-4afb-943c-bfad46bbd502"/>
							<gml:surfaceMember xlink:href="#poly-77bcd7e9-b624-4895-84a3-6e715e09752a"/>
							<gml:surfaceMember xlink:href="#poly-d1bd0d04-4e74-4ada-8030-5804d44e3f9c"/>
							<gml:surfaceMember xlink:href="#poly-97910a8d-ce9f-468c-93e5-23972eafc35b"/>
							<gml:surfaceMember xlink:href="#poly-b44faa67-7425-44a0-8b08-82123106f208"/>
							<gml:surfaceMember xlink:href="#poly-0004ea98-4bba-4b95-91bf-f46dcad23477"/>
							<gml:surfaceMember xlink:href="#poly-a936ca43-8b88-4b1e-b8da-eef51dcd94a6"/>
							<gml:surfaceMember xlink:href="#poly-0e8fce13-2f45-460f-bc45-b252588bb889"/>
							<gml:surfaceMember xlink:href="#poly-eff8e849-33a2-46fa-9a01-878c19ac1c3f"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_aa8c696e-0ded-4477-99df-a1604d497fb2_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e514ee5-c174-409d-a450-91b27960a995">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670338045102234 139.74156779216295 33.33 35.67032053084907 139.7415670389709 33.33 35.670321136639416 139.7415458405211 33.33 35.6703386508927 139.74154659370853 33.33 35.670338045102234 139.74156779216295 33.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-79d8d7e0-3084-433d-9a95-cc41a83068fc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-79d8d7e0-3084-433d-9a95-cc41a83068fc_0">
											<gml:posList>35.670321136639416 139.7415458405211 33.33 35.670321136639416 139.7415458405211 36.18 35.6703386508927 139.74154659370853 36.18 35.6703386508927 139.74154659370853 33.33 35.670321136639416 139.7415458405211 33.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00ca421b-2fe1-436b-b9b3-a9e1972c14e0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-00ca421b-2fe1-436b-b9b3-a9e1972c14e0_0">
											<gml:posList>35.67032053084907 139.7415670389709 36.18 35.670321136639416 139.7415458405211 36.18 35.670321136639416 139.7415458405211 33.33 35.67032053084907 139.7415670389709 33.33 35.67032053084907 139.7415670389709 36.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0107166-511a-4347-abcd-ecbd4323f16c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d0107166-511a-4347-abcd-ecbd4323f16c_0">
											<gml:posList>35.670321136639416 139.7415458405211 36.18 35.67032053084907 139.7415670389709 36.18 35.670338045102234 139.74156779216295 36.18 35.6703386508927 139.74154659370853 36.18 35.670321136639416 139.7415458405211 36.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-91bbcdc5-b018-4b1e-8650-abb000543322">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-91bbcdc5-b018-4b1e-8650-abb000543322_0">
											<gml:posList>35.6703386508927 139.74154659370853 33.33 35.6703386508927 139.74154659370853 36.18 35.670338045102234 139.74156779216295 36.18 35.670338045102234 139.74156779216295 33.33 35.6703386508927 139.74154659370853 33.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-08944a78-1b53-4575-885e-63f10bd05d36">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-08944a78-1b53-4575-885e-63f10bd05d36_0">
											<gml:posList>35.670338045102234 139.74156779216295 36.18 35.67032053084907 139.7415670389709 36.18 35.67032053084907 139.7415670389709 33.33 35.670338045102234 139.74156779216295 33.33 35.670338045102234 139.74156779216295 36.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_aa8c696e-0ded-4477-99df-a1604d497fb2_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1fcacdb5-679c-4294-98a7-649a60419a99">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67036634938879 139.74160481996233 37.55 35.67035107962869 139.74160416361036 37.55 35.67035158888377 139.74158638960245 37.55 35.67036685864396 139.74158704595104 37.55 35.67036634938879 139.74160481996233 37.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59a85607-1295-4c66-839d-c37a9df69217">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-59a85607-1295-4c66-839d-c37a9df69217_0">
											<gml:posList>35.6703479536846 139.7414883030168 32.577 35.67037098453883 139.74148931498277 32.577 35.67037098453883 139.74148931498277 30.87 35.6703479536846 139.7414883030168 30.873 35.6703479536846 139.7414883030168 32.577</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b45dc67-3c57-4fe0-b7e1-7217649cd920">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5b45dc67-3c57-4fe0-b7e1-7217649cd920_0">
											<gml:posList>35.6703479536846 139.7414883030168 30.873 35.670347558471796 139.7415019455945 32.577 35.6703479536846 139.7414883030168 32.577 35.6703479536846 139.7414883030168 30.873</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ae448958-992f-45d0-bd05-ccdd7dc90d16">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ae448958-992f-45d0-bd05-ccdd7dc90d16_0">
											<gml:posList>35.67037098453883 139.74148931498277 32.577 35.6703479536846 139.7414883030168 32.577 35.670347558471796 139.7415019455945 32.577 35.67037058932591 139.7415029575644 32.577 35.67037098453883 139.74148931498277 32.577</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0c3bec64-731d-45e8-a52d-338d6dcbaec5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0c3bec64-731d-45e8-a52d-338d6dcbaec5_0">
											<gml:posList>35.670347558471796 139.7415019455945 32.577 35.6703479536846 139.7414883030168 30.873 35.67037098453883 139.74148931498277 30.87 35.67037058932591 139.7415029575644 32.577 35.670347558471796 139.7415019455945 32.577</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-354f44c6-424a-4ae8-9a44-3a3ddd1cf405">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-354f44c6-424a-4ae8-9a44-3a3ddd1cf405_0">
											<gml:posList>35.67037058932591 139.7415029575644 32.577 35.67037098453883 139.74148931498277 30.87 35.67037098453883 139.74148931498277 32.577 35.67037058932591 139.7415029575644 32.577</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd13805c-edb3-46b0-9793-778404c850a2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cd13805c-edb3-46b0-9793-778404c850a2_0">
											<gml:posList>35.67036685864396 139.74158704595104 37.55 35.67035158888377 139.74158638960245 37.55 35.67035158888377 139.74158638960245 40.807 35.67036685864396 139.74158704595104 40.807 35.67036685864396 139.74158704595104 37.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bfc5840f-12a4-4fc6-891e-e210db23455c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bfc5840f-12a4-4fc6-891e-e210db23455c_0">
											<gml:posList>35.67035107962869 139.74160416361036 37.55 35.67035107962869 139.74160416361036 40.807 35.67035158888377 139.74158638960245 40.807 35.67035158888377 139.74158638960245 37.55 35.67035107962869 139.74160416361036 37.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-36d3e41c-441f-4e5f-b9cd-d943da6164ef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-36d3e41c-441f-4e5f-b9cd-d943da6164ef_0">
											<gml:posList>35.67035158888377 139.74158638960245 40.807 35.67035107962869 139.74160416361036 40.807 35.67036634938879 139.74160481996233 40.807 35.67036685864396 139.74158704595104 40.807 35.67035158888377 139.74158638960245 40.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a8e9c7ed-068d-4c3b-b576-0edf1a161f69">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a8e9c7ed-068d-4c3b-b576-0edf1a161f69_0">
											<gml:posList>35.67036685864396 139.74158704595104 37.55 35.67036685864396 139.74158704595104 40.807 35.67036634938879 139.74160481996233 40.807 35.67036634938879 139.74160481996233 37.55 35.67036685864396 139.74158704595104 37.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9522abb1-97be-4d5a-b61e-b9fb51957c23">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9522abb1-97be-4d5a-b61e-b9fb51957c23_0">
											<gml:posList>35.67036634938879 139.74160481996233 37.55 35.67036634938879 139.74160481996233 40.807 35.67035107962869 139.74160416361036 40.807 35.67035107962869 139.74160416361036 37.55 35.67036634938879 139.74160481996233 37.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-7762335b-aea4-4e36-965f-5585a4bf5e7f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7762335b-aea4-4e36-965f-5585a4bf5e7f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7762335b-aea4-4e36-965f-5585a4bf5e7f">
											<gml:posList>35.67034570976492 139.74159537693504 8.499 35.670305957815515 139.74159354455617 8.499 35.67030639798107 139.7415797362408 8.499 35.670310348526165 139.74144121174578 8.499 35.67037263554385 139.74144401238541 8.499 35.67036763027776 139.74161788621993 8.499 35.670345095212966 139.7416169178349 8.499 35.67034570976492 139.74159537693504 8.499</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-351c98ea-7543-4b2e-8f14-518ddc7d727e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-351c98ea-7543-4b2e-8f14-518ddc7d727e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-351c98ea-7543-4b2e-8f14-518ddc7d727e">
											<gml:posList>35.67037064207695 139.74151303169148 33.837 35.67037263554385 139.74144401238541 25.196 35.670310348526165 139.74144121174578 25.196 35.67030837317246 139.7415103414401 33.837 35.67037064207695 139.74151303169148 33.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ba9672c8-289e-4d39-a335-9a53206c9b13">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba9672c8-289e-4d39-a335-9a53206c9b13">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba9672c8-289e-4d39-a335-9a53206c9b13">
											<gml:posList>35.67030837317246 139.7415103414401 33.837 35.670310610824814 139.74151328822614 33.837 35.670368237510274 139.74151578496347 33.837 35.67037064207695 139.74151303169148 33.837 35.67030837317246 139.7415103414401 33.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0e95fe28-5080-4918-870e-417aa79ed462">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e95fe28-5080-4918-870e-417aa79ed462">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e95fe28-5080-4918-870e-417aa79ed462">
											<gml:posList>35.670368237510274 139.74151578496347 33.837 35.67036705432957 139.74154812976107 33.837 35.67036963233855 139.7415482372724 33.837 35.67037064207695 139.74151303169148 33.837 35.670368237510274 139.74151578496347 33.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-55e424e4-c650-4963-9340-c1cd50d910fb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-55e424e4-c650-4963-9340-c1cd50d910fb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-55e424e4-c650-4963-9340-c1cd50d910fb">
											<gml:posList>35.67030639798107 139.7415797362408 33.837 35.670308714592075 139.7415798440522 33.837 35.670310610824814 139.74151328822614 33.837 35.67030837317246 139.7415103414401 33.837 35.67030639798107 139.7415797362408 33.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b87c1bc9-8c65-414e-8020-2871a7d54d45">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b87c1bc9-8c65-414e-8020-2871a7d54d45">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b87c1bc9-8c65-414e-8020-2871a7d54d45">
											<gml:posList>35.67034899021401 139.74154734406375 37.213 35.67035056018477 139.7415494189625 37.213 35.67036794823742 139.7415501612492 37.213 35.67036963233855 139.7415482372724 37.213 35.67034899021401 139.74154734406375 37.213</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c86fff53-c5b2-4a5a-8dba-d85bf61fbd67">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c86fff53-c5b2-4a5a-8dba-d85bf61fbd67">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c86fff53-c5b2-4a5a-8dba-d85bf61fbd67">
											<gml:posList>35.67034899021401 139.74154734406375 33.33 35.67036705432957 139.74154812976107 33.33 35.670368237510274 139.74151578496347 33.33 35.670310610824814 139.74151328822614 33.33 35.670308714592075 139.7415798440522 33.33 35.67030836240084 139.74159081338115 33.33 35.67034769067161 139.74159260205852 33.33 35.67034899021401 139.74154734406375 33.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c2ab36aa-81de-4849-b21c-9317259d2f73">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c2ab36aa-81de-4849-b21c-9317259d2f73">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c2ab36aa-81de-4849-b21c-9317259d2f73">
											<gml:posList>35.67035056018477 139.7415494189625 37.213 35.67034899021401 139.74154734406375 37.213 35.670348155942236 139.74157625306853 37.213 35.67034978747661 139.74157631747892 37.213 35.67035056018477 139.7415494189625 37.213</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-295a69fc-2fb7-451f-9da9-7a2bee8204ea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-295a69fc-2fb7-451f-9da9-7a2bee8204ea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-295a69fc-2fb7-451f-9da9-7a2bee8204ea">
											<gml:posList>35.67036794823742 139.7415501612492 37.213 35.67036717553751 139.74157707081767 37.213 35.670368798058156 139.74157713523837 37.213 35.67036963233855 139.7415482372724 37.213 35.67036794823742 139.7415501612492 37.213</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5f1ec6a3-655d-44a9-947e-c8f64d212536">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f1ec6a3-655d-44a9-947e-c8f64d212536">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f1ec6a3-655d-44a9-947e-c8f64d212536">
											<gml:posList>35.67034978747661 139.74157631747892 36.893 35.67036717553751 139.74157707081767 36.893 35.67036794823742 139.7415501612492 36.893 35.67035056018477 139.7415494189625 36.893 35.67034978747661 139.74157631747892 36.893</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a446c188-c223-47f2-bda1-ef215975d050">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a446c188-c223-47f2-bda1-ef215975d050">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a446c188-c223-47f2-bda1-ef215975d050">
											<gml:posList>35.670348155942236 139.74157625306853 38.022 35.67034918454199 139.74157761058078 38.022 35.67036769935194 139.7415784068154 38.022 35.670368798058156 139.74157713523837 38.022 35.670348155942236 139.74157625306853 38.022</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dac07d92-c345-4b20-a2f3-4385e0afb916">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dac07d92-c345-4b20-a2f3-4385e0afb916">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dac07d92-c345-4b20-a2f3-4385e0afb916">
											<gml:posList>35.67030639798107 139.7415797362408 33.837 35.670305957815515 139.74159354455617 33.837 35.67030836240084 139.74159081338115 33.837 35.670308714592075 139.7415798440522 33.837 35.67030639798107 139.7415797362408 33.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-96ac749e-6beb-4fb7-b754-28fca538254a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96ac749e-6beb-4fb7-b754-28fca538254a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96ac749e-6beb-4fb7-b754-28fca538254a">
											<gml:posList>35.670347049524935 139.74161472844088 38.022 35.67034815725367 139.7416134679006 38.022 35.67034918454199 139.74157761058078 38.022 35.670348155942236 139.74157625306853 38.022 35.670347049524935 139.74161472844088 38.022</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-beac103f-0d83-477d-a6ac-be094d4d9575">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-beac103f-0d83-477d-a6ac-be094d4d9575">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-beac103f-0d83-477d-a6ac-be094d4d9575">
											<gml:posList>35.67036769935194 139.7415784068154 37.55 35.67034918454199 139.74157761058078 37.55 35.67034815725367 139.7416134679006 37.55 35.670366654044365 139.74161427521037 37.55 35.67036769935194 139.7415784068154 37.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a17e621e-9dd1-4e11-94db-eb7ddd68e6ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a17e621e-9dd1-4e11-94db-eb7ddd68e6ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a17e621e-9dd1-4e11-94db-eb7ddd68e6ff">
											<gml:posList>35.670368798058156 139.74157713523837 38.022 35.67036769935194 139.7415784068154 38.022 35.670366654044365 139.74161427521037 38.022 35.670367691649005 139.74161562166685 38.022 35.670368798058156 139.74157713523837 38.022</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e11d87f8-c8ae-4126-a861-cd836b4b6648">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e11d87f8-c8ae-4126-a861-cd836b4b6648">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e11d87f8-c8ae-4126-a861-cd836b4b6648">
											<gml:posList>35.670345095212966 139.7416169178349 33.837 35.67036763027776 139.74161788621993 33.837 35.670367691649005 139.74161562166685 33.837 35.670347049524935 139.74161472844088 33.837 35.67034769067161 139.74159260205852 33.837 35.67030836240084 139.74159081338115 33.837 35.670305957815515 139.74159354455617 33.837 35.67034570976492 139.74159537693504 33.837 35.670345095212966 139.7416169178349 33.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-46c72e1e-c4a3-4fea-b584-c72f052cefa2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-46c72e1e-c4a3-4fea-b584-c72f052cefa2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-46c72e1e-c4a3-4fea-b584-c72f052cefa2">
											<gml:posList>35.670367691649005 139.74161562166685 38.022 35.670366654044365 139.74161427521037 38.022 35.67034815725367 139.7416134679006 38.022 35.670347049524935 139.74161472844088 38.022 35.670367691649005 139.74161562166685 38.022</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e942036f-0eee-4cdb-bf6b-73070a985068">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e942036f-0eee-4cdb-bf6b-73070a985068">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e942036f-0eee-4cdb-bf6b-73070a985068">
											<gml:posList>35.67030639798107 139.7415797362408 8.499 35.67030639798107 139.7415797362408 33.837 35.67030837317246 139.7415103414401 33.837 35.670310348526165 139.74144121174578 25.196 35.670310348526165 139.74144121174578 8.499 35.67030639798107 139.7415797362408 8.499</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-77cd5d33-636f-4b0f-80d3-0a1ea62bde60">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-77cd5d33-636f-4b0f-80d3-0a1ea62bde60">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-77cd5d33-636f-4b0f-80d3-0a1ea62bde60">
											<gml:posList>35.67030639798107 139.7415797362408 8.499 35.670305957815515 139.74159354455617 8.499 35.670305957815515 139.74159354455617 33.837 35.67030639798107 139.7415797362408 33.837 35.67030639798107 139.7415797362408 8.499</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a9049475-84f6-45dd-b3c2-308cd5c9963b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9049475-84f6-45dd-b3c2-308cd5c9963b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9049475-84f6-45dd-b3c2-308cd5c9963b">
											<gml:posList>35.67030836240084 139.74159081338115 33.837 35.67030836240084 139.74159081338115 33.33 35.670308714592075 139.7415798440522 33.33 35.670308714592075 139.7415798440522 33.837 35.67030836240084 139.74159081338115 33.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-497b7bcc-1161-45a6-be8c-2eb733fc0970">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-497b7bcc-1161-45a6-be8c-2eb733fc0970">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-497b7bcc-1161-45a6-be8c-2eb733fc0970">
											<gml:posList>35.670308714592075 139.7415798440522 33.837 35.670308714592075 139.7415798440522 33.33 35.670310610824814 139.74151328822614 33.33 35.670310610824814 139.74151328822614 33.837 35.670308714592075 139.7415798440522 33.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-de64d39d-aec2-4e9a-8b0f-7f14fee9583d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de64d39d-aec2-4e9a-8b0f-7f14fee9583d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de64d39d-aec2-4e9a-8b0f-7f14fee9583d">
											<gml:posList>35.670305957815515 139.74159354455617 8.499 35.67034570976492 139.74159537693504 8.499 35.67034570976492 139.74159537693504 33.837 35.670305957815515 139.74159354455617 33.837 35.670305957815515 139.74159354455617 8.499</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-280faf3a-3d6a-4664-89a4-cd6a3176b62c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-280faf3a-3d6a-4664-89a4-cd6a3176b62c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-280faf3a-3d6a-4664-89a4-cd6a3176b62c">
											<gml:posList>35.67034769067161 139.74159260205852 33.837 35.67034769067161 139.74159260205852 33.33 35.67030836240084 139.74159081338115 33.33 35.67030836240084 139.74159081338115 33.837 35.67034769067161 139.74159260205852 33.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bcf801fc-2b85-4d63-b501-e7039963352d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bcf801fc-2b85-4d63-b501-e7039963352d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bcf801fc-2b85-4d63-b501-e7039963352d">
											<gml:posList>35.670310610824814 139.74151328822614 33.837 35.670310610824814 139.74151328822614 33.33 35.670368237510274 139.74151578496347 33.33 35.670368237510274 139.74151578496347 33.837 35.670310610824814 139.74151328822614 33.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1e6bba54-a870-4c9a-bc64-98a67f2ecec4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e6bba54-a870-4c9a-bc64-98a67f2ecec4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e6bba54-a870-4c9a-bc64-98a67f2ecec4">
											<gml:posList>35.67037263554385 139.74144401238541 8.499 35.670310348526165 139.74144121174578 8.499 35.670310348526165 139.74144121174578 25.196 35.67037263554385 139.74144401238541 25.196 35.67037263554385 139.74144401238541 8.499</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f1019fde-928f-4fc9-af8e-ca5ab6662125">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f1019fde-928f-4fc9-af8e-ca5ab6662125">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f1019fde-928f-4fc9-af8e-ca5ab6662125">
											<gml:posList>35.67034570976492 139.74159537693504 8.499 35.670345095212966 139.7416169178349 8.499 35.670345095212966 139.7416169178349 33.837 35.67034570976492 139.74159537693504 33.837 35.67034570976492 139.74159537693504 8.499</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-baa59f7c-af58-4eb1-ad91-7c70516f2778">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-baa59f7c-af58-4eb1-ad91-7c70516f2778">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-baa59f7c-af58-4eb1-ad91-7c70516f2778">
											<gml:posList>35.670347049524935 139.74161472844088 38.022 35.670348155942236 139.74157625306853 38.022 35.670348155942236 139.74157625306853 37.213 35.67034899021401 139.74154734406375 37.213 35.67034899021401 139.74154734406375 33.33 35.67034769067161 139.74159260205852 33.33 35.67034769067161 139.74159260205852 33.837 35.670347049524935 139.74161472844088 33.837 35.670347049524935 139.74161472844088 38.022</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6543e8bf-d91a-483a-93ad-a3be69e15f31">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6543e8bf-d91a-483a-93ad-a3be69e15f31">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6543e8bf-d91a-483a-93ad-a3be69e15f31">
											<gml:posList>35.67034815725367 139.7416134679006 38.022 35.67034815725367 139.7416134679006 37.55 35.67034918454199 139.74157761058078 37.55 35.67034918454199 139.74157761058078 38.022 35.67034815725367 139.7416134679006 38.022</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-670ef77f-be1a-4663-9b6d-dc6c43ddcd14">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-670ef77f-be1a-4663-9b6d-dc6c43ddcd14">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-670ef77f-be1a-4663-9b6d-dc6c43ddcd14">
											<gml:posList>35.67034978747661 139.74157631747892 37.213 35.67034978747661 139.74157631747892 36.893 35.67035056018477 139.7415494189625 36.893 35.67035056018477 139.7415494189625 37.213 35.67034978747661 139.74157631747892 37.213</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-334ac17d-8885-49c9-b4d9-03a476ca5744">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-334ac17d-8885-49c9-b4d9-03a476ca5744">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-334ac17d-8885-49c9-b4d9-03a476ca5744">
											<gml:posList>35.670345095212966 139.7416169178349 8.499 35.67036763027776 139.74161788621993 8.499 35.67036763027776 139.74161788621993 33.837 35.670345095212966 139.7416169178349 33.837 35.670345095212966 139.7416169178349 8.499</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9dd32751-aafa-459d-bab9-2902e95f5829">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9dd32751-aafa-459d-bab9-2902e95f5829">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9dd32751-aafa-459d-bab9-2902e95f5829">
											<gml:posList>35.670367691649005 139.74161562166685 33.837 35.670367691649005 139.74161562166685 38.022 35.670347049524935 139.74161472844088 38.022 35.670347049524935 139.74161472844088 33.837 35.670367691649005 139.74161562166685 33.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-33816684-c8f3-4afb-943c-bfad46bbd502">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-33816684-c8f3-4afb-943c-bfad46bbd502">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-33816684-c8f3-4afb-943c-bfad46bbd502">
											<gml:posList>35.670366654044365 139.74161427521037 38.022 35.670366654044365 139.74161427521037 37.55 35.67034815725367 139.7416134679006 37.55 35.67034815725367 139.7416134679006 38.022 35.670366654044365 139.74161427521037 38.022</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-77bcd7e9-b624-4895-84a3-6e715e09752a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-77bcd7e9-b624-4895-84a3-6e715e09752a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-77bcd7e9-b624-4895-84a3-6e715e09752a">
											<gml:posList>35.67034918454199 139.74157761058078 38.022 35.67034918454199 139.74157761058078 37.55 35.67036769935194 139.7415784068154 37.55 35.67036769935194 139.7415784068154 38.022 35.67034918454199 139.74157761058078 38.022</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d1bd0d04-4e74-4ada-8030-5804d44e3f9c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1bd0d04-4e74-4ada-8030-5804d44e3f9c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1bd0d04-4e74-4ada-8030-5804d44e3f9c">
											<gml:posList>35.670348155942236 139.74157625306853 38.022 35.670368798058156 139.74157713523837 38.022 35.670368798058156 139.74157713523837 37.213 35.67036717553751 139.74157707081767 37.213 35.67036717553751 139.74157707081767 36.893 35.67034978747661 139.74157631747892 36.893 35.67034978747661 139.74157631747892 37.213 35.670348155942236 139.74157625306853 37.213 35.670348155942236 139.74157625306853 38.022</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-97910a8d-ce9f-468c-93e5-23972eafc35b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-97910a8d-ce9f-468c-93e5-23972eafc35b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-97910a8d-ce9f-468c-93e5-23972eafc35b">
											<gml:posList>35.67035056018477 139.7415494189625 37.213 35.67035056018477 139.7415494189625 36.893 35.67036794823742 139.7415501612492 36.893 35.67036794823742 139.7415501612492 37.213 35.67035056018477 139.7415494189625 37.213</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b44faa67-7425-44a0-8b08-82123106f208">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b44faa67-7425-44a0-8b08-82123106f208">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b44faa67-7425-44a0-8b08-82123106f208">
											<gml:posList>35.67034899021401 139.74154734406375 33.33 35.67034899021401 139.74154734406375 37.213 35.67036963233855 139.7415482372724 37.213 35.67036963233855 139.7415482372724 33.837 35.67036705432957 139.74154812976107 33.837 35.67036705432957 139.74154812976107 33.33 35.67034899021401 139.74154734406375 33.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0004ea98-4bba-4b95-91bf-f46dcad23477">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0004ea98-4bba-4b95-91bf-f46dcad23477">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0004ea98-4bba-4b95-91bf-f46dcad23477">
											<gml:posList>35.67036769935194 139.7415784068154 38.022 35.67036769935194 139.7415784068154 37.55 35.670366654044365 139.74161427521037 37.55 35.670366654044365 139.74161427521037 38.022 35.67036769935194 139.7415784068154 38.022</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a936ca43-8b88-4b1e-b8da-eef51dcd94a6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a936ca43-8b88-4b1e-b8da-eef51dcd94a6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a936ca43-8b88-4b1e-b8da-eef51dcd94a6">
											<gml:posList>35.67036794823742 139.7415501612492 37.213 35.67036794823742 139.7415501612492 36.893 35.67036717553751 139.74157707081767 36.893 35.67036717553751 139.74157707081767 37.213 35.67036794823742 139.7415501612492 37.213</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0e8fce13-2f45-460f-bc45-b252588bb889">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e8fce13-2f45-460f-bc45-b252588bb889">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e8fce13-2f45-460f-bc45-b252588bb889">
											<gml:posList>35.670368237510274 139.74151578496347 33.837 35.670368237510274 139.74151578496347 33.33 35.67036705432957 139.74154812976107 33.33 35.67036705432957 139.74154812976107 33.837 35.670368237510274 139.74151578496347 33.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eff8e849-33a2-46fa-9a01-878c19ac1c3f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eff8e849-33a2-46fa-9a01-878c19ac1c3f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eff8e849-33a2-46fa-9a01-878c19ac1c3f">
											<gml:posList>35.67037263554385 139.74144401238541 25.196 35.67037064207695 139.74151303169148 33.837 35.67036963233855 139.7415482372724 33.837 35.67036963233855 139.7415482372724 37.213 35.670368798058156 139.74157713523837 37.213 35.670368798058156 139.74157713523837 38.022 35.670367691649005 139.74161562166685 38.022 35.670367691649005 139.74161562166685 33.837 35.67036763027776 139.74161788621993 33.837 35.67036763027776 139.74161788621993 8.499 35.67037263554385 139.74144401238541 8.499 35.67037263554385 139.74144401238541 25.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2132</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">100.31959</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.05</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>