<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_ab0fff4f-5ec7-40b6-af47-304a7f4e8695">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>0.80</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">30.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67243068302765 139.73865902968367 0 35.67245376392851 139.7386434267991 0 35.672401976806306 139.73852473768292 0 35.6723588263107 139.73855682365388 0 35.672417190453395 139.73872908068014 0 35.672450494894434 139.7387045070047 0 35.67243068302765 139.73865902968367 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67243068302765 139.73865902968367 9.51 35.672450494894434 139.7387045070047 9.51 35.672417190453395 139.73872908068014 9.51 35.6723588263107 139.73855682365388 9.51 35.672401976806306 139.73852473768292 9.51 35.67245376392851 139.7386434267991 9.51 35.67243068302765 139.73865902968367 9.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67243068302765 139.73865902968367 9.51 35.67245376392851 139.7386434267991 9.51 35.67245376392851 139.7386434267991 39.74 35.67243068302765 139.73865902968367 39.74 35.67243068302765 139.73865902968367 9.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67245376392851 139.7386434267991 9.51 35.672401976806306 139.73852473768292 9.51 35.672401976806306 139.73852473768292 39.74 35.67245376392851 139.7386434267991 39.74 35.67245376392851 139.7386434267991 9.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672401976806306 139.73852473768292 9.51 35.6723588263107 139.73855682365388 9.51 35.6723588263107 139.73855682365388 39.74 35.672401976806306 139.73852473768292 39.74 35.672401976806306 139.73852473768292 9.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6723588263107 139.73855682365388 9.51 35.672417190453395 139.73872908068014 9.51 35.672417190453395 139.73872908068014 39.74 35.6723588263107 139.73855682365388 39.74 35.6723588263107 139.73855682365388 9.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672417190453395 139.73872908068014 9.51 35.672450494894434 139.7387045070047 9.51 35.672450494894434 139.7387045070047 39.74 35.672417190453395 139.73872908068014 39.74 35.672417190453395 139.73872908068014 9.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672450494894434 139.7387045070047 9.51 35.67243068302765 139.73865902968367 9.51 35.67243068302765 139.73865902968367 39.74 35.672450494894434 139.7387045070047 39.74 35.672450494894434 139.7387045070047 9.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67243068302765 139.73865902968367 39.74 35.67245376392851 139.7386434267991 39.74 35.672401976806306 139.73852473768292 39.74 35.6723588263107 139.73855682365388 39.74 35.672417190453395 139.73872908068014 39.74 35.672450494894434 139.7387045070047 39.74 35.67243068302765 139.73865902968367 39.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-96c0601c-3f82-4d60-ba7e-b07065618817"/>
							<gml:surfaceMember xlink:href="#poly-0959cb41-d1c3-44b3-a1a3-90c6c3fa1a80"/>
							<gml:surfaceMember xlink:href="#poly-5a7435d8-33f1-4a6a-bd28-4c54352bae79"/>
							<gml:surfaceMember xlink:href="#poly-19c1805f-093b-4878-9a5e-57cd6f1253a7"/>
							<gml:surfaceMember xlink:href="#poly-065b62c4-17b7-475c-9480-55fd83bc6765"/>
							<gml:surfaceMember xlink:href="#poly-df5ba5b6-bb44-49aa-a3a8-677fe184c500"/>
							<gml:surfaceMember xlink:href="#poly-9f8ac1c3-a7b5-4603-bedc-551557107a3d"/>
							<gml:surfaceMember xlink:href="#poly-2df41f0b-19c1-43cd-90c4-d28c1e719d9a"/>
							<gml:surfaceMember xlink:href="#poly-53e45e72-00ce-402a-a8e9-9ed08b65d840"/>
							<gml:surfaceMember xlink:href="#poly-60186054-7021-4313-8dbd-b417f36451b3"/>
							<gml:surfaceMember xlink:href="#poly-fc3b7096-7b93-4d31-bc07-a6a3530a51e9"/>
							<gml:surfaceMember xlink:href="#poly-2e3799f7-fc2d-4133-aed5-4d14833cfb5c"/>
							<gml:surfaceMember xlink:href="#poly-3544bb36-9d66-466e-b49d-d646309f55b6"/>
							<gml:surfaceMember xlink:href="#poly-b8f7c45c-e094-49df-8cdd-c1a2394f5814"/>
							<gml:surfaceMember xlink:href="#poly-70f53eeb-90d8-4a29-ac46-2bf0b8e41a30"/>
							<gml:surfaceMember xlink:href="#poly-18cb3ee4-6fa3-4b14-a6e5-423933800977"/>
							<gml:surfaceMember xlink:href="#poly-ca4ff1a1-0357-45d2-871c-bd9f4da86da6"/>
							<gml:surfaceMember xlink:href="#poly-61eca8b7-5278-4040-a16d-b3c97f8ae1ec"/>
							<gml:surfaceMember xlink:href="#poly-87056460-64d3-4712-a9a3-c29622d6d8d5"/>
							<gml:surfaceMember xlink:href="#poly-d6920b9b-db72-45c8-9199-f2bf376784c9"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_ab0fff4f-5ec7-40b6-af47-304a7f4e8695_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-85968bf7-005e-4e83-9e45-a5c1d82bff78">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672378758663726 139.7385835437507 40.615 35.672376871362836 139.73857918260015 40.615 35.6724026284674 139.7385624829323 40.615 35.672404515768896 139.73856684408392 40.615 35.672378758663726 139.7385835437507 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70f545f8-ddd6-4e23-96d3-edd5cc324d53">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67240988616481 139.7385760284562 40.615 35.67241212546157 139.7385809746591 40.615 35.67238598163365 139.7385987794335 40.615 35.67238373333259 139.73859384428889 40.615 35.67240988616481 139.7385760284562 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e4be5d97-301a-4ba5-b3fa-a9aacd78433c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67243016972493 139.73861379470156 40.615 35.67243407952983 139.73862251685065 40.615 35.67242464714442 139.73862885766158 40.615 35.67242073733998 139.7386201355132 40.615 35.67243016972493 139.73861379470156 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6f97d98-5383-491f-b6f0-cb3d174b4b1c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672417438376165 139.7386775261856 40.615 35.672429645660934 139.73866949198364 40.615 35.67243528032979 139.7386823435058 40.615 35.67242307304417 139.73869037770635 40.615 35.672417438376165 139.7386775261856 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e4cf0748-c9d3-4ff9-a6ac-025965ddd818">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e4cf0748-c9d3-4ff9-a6ac-025965ddd818_0">
											<gml:posList>35.672376871362836 139.73857918260015 40.615 35.672378758663726 139.7385835437507 40.615 35.672378758663726 139.7385835437507 41.757 35.672376871362836 139.73857918260015 41.757 35.672376871362836 139.73857918260015 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7d9e674-c7d4-4846-9174-df50746bc74e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c7d9e674-c7d4-4846-9174-df50746bc74e_0">
											<gml:posList>35.67238373333259 139.73859384428889 40.615 35.67238598163365 139.7385987794335 40.615 35.67238598163365 139.7385987794335 41.757 35.67238373333259 139.73859384428889 41.757 35.67238373333259 139.73859384428889 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe7e22c2-7c7e-4baf-b304-b6cd1e5c533a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe7e22c2-7c7e-4baf-b304-b6cd1e5c533a_0">
											<gml:posList>35.6724026284674 139.7385624829323 40.615 35.672376871362836 139.73857918260015 40.615 35.672376871362836 139.73857918260015 41.757 35.6724026284674 139.7385624829323 41.757 35.6724026284674 139.7385624829323 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e039cf82-2d9c-41e2-83d2-39d4ec8fab7a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e039cf82-2d9c-41e2-83d2-39d4ec8fab7a_0">
											<gml:posList>35.6724026284674 139.7385624829323 41.757 35.672376871362836 139.73857918260015 41.757 35.672378758663726 139.7385835437507 41.757 35.672404515768896 139.73856684408392 41.757 35.6724026284674 139.7385624829323 41.757</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f4bc6c4f-157e-4a96-82a2-390a489111ac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f4bc6c4f-157e-4a96-82a2-390a489111ac_0">
											<gml:posList>35.672378758663726 139.7385835437507 40.615 35.672404515768896 139.73856684408392 40.615 35.672404515768896 139.73856684408392 41.757 35.672378758663726 139.7385835437507 41.757 35.672378758663726 139.7385835437507 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-648de1d9-00f8-41ab-823c-7deca1a76391">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-648de1d9-00f8-41ab-823c-7deca1a76391_0">
											<gml:posList>35.67238373333259 139.73859384428889 41.757 35.67240988616481 139.7385760284562 41.757 35.67240988616481 139.7385760284562 40.615 35.67238373333259 139.73859384428889 40.615 35.67238373333259 139.73859384428889 41.757</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-83859a3f-e1ac-4e3a-8ff9-be211bedfe57">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-83859a3f-e1ac-4e3a-8ff9-be211bedfe57_0">
											<gml:posList>35.67238598163365 139.7385987794335 41.757 35.67241212546157 139.7385809746591 41.757 35.67240988616481 139.7385760284562 41.757 35.67238373333259 139.73859384428889 41.757 35.67238598163365 139.7385987794335 41.757</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-05f9d6c5-f7e8-407c-ad4d-d0ee67186068">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-05f9d6c5-f7e8-407c-ad4d-d0ee67186068_0">
											<gml:posList>35.67241212546157 139.7385809746591 40.615 35.67241212546157 139.7385809746591 41.757 35.67238598163365 139.7385987794335 41.757 35.67238598163365 139.7385987794335 40.615 35.67241212546157 139.7385809746591 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-540d3716-a963-4bbf-9299-5020d38527bb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-540d3716-a963-4bbf-9299-5020d38527bb_0">
											<gml:posList>35.6724026284674 139.7385624829323 41.757 35.672404515768896 139.73856684408392 41.757 35.672404515768896 139.73856684408392 40.615 35.6724026284674 139.7385624829323 40.615 35.6724026284674 139.7385624829323 41.757</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ccc7533e-41f9-4184-9eeb-4d57dd46a1f6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ccc7533e-41f9-4184-9eeb-4d57dd46a1f6_0">
											<gml:posList>35.67241212546157 139.7385809746591 40.615 35.67240988616481 139.7385760284562 40.615 35.67240988616481 139.7385760284562 41.757 35.67241212546157 139.7385809746591 41.757 35.67241212546157 139.7385809746591 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b022f8d-04b2-4a87-b749-a0fefac9fac2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b022f8d-04b2-4a87-b749-a0fefac9fac2_0">
											<gml:posList>35.672417438376165 139.7386775261856 40.615 35.67242307304417 139.73869037770635 40.615 35.67242307304417 139.73869037770635 41.011 35.672417438376165 139.7386775261856 41.011 35.672417438376165 139.7386775261856 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e91e057-47e2-4c73-aa6d-a3f33e36861a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e91e057-47e2-4c73-aa6d-a3f33e36861a_0">
											<gml:posList>35.67242073733998 139.7386201355132 40.615 35.67242464714442 139.73862885766158 40.615 35.67242464714442 139.73862885766158 41.095 35.67242073733998 139.7386201355132 41.095 35.67242073733998 139.7386201355132 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-260f6f08-d5c6-4bea-8cb2-a4d9944c0bfb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-260f6f08-d5c6-4bea-8cb2-a4d9944c0bfb_0">
											<gml:posList>35.672417438376165 139.7386775261856 40.615 35.672417438376165 139.7386775261856 41.011 35.672429645660934 139.73866949198364 41.011 35.672429645660934 139.73866949198364 40.615 35.672417438376165 139.7386775261856 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8843b189-b67a-4441-b882-11f43bb9fe1e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8843b189-b67a-4441-b882-11f43bb9fe1e_0">
											<gml:posList>35.67243016972493 139.73861379470156 40.615 35.67242073733998 139.7386201355132 40.615 35.67242073733998 139.7386201355132 41.095 35.67243016972493 139.73861379470156 41.095 35.67243016972493 139.73861379470156 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7bdedd9f-8fd3-45a6-9053-31f191e53e02">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7bdedd9f-8fd3-45a6-9053-31f191e53e02_0">
											<gml:posList>35.672417438376165 139.7386775261856 41.011 35.67242307304417 139.73869037770635 41.011 35.67243528032979 139.7386823435058 41.011 35.672429645660934 139.73866949198364 41.011 35.672417438376165 139.7386775261856 41.011</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9d78271-d35a-4893-8735-304f827485d0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e9d78271-d35a-4893-8735-304f827485d0_0">
											<gml:posList>35.67243016972493 139.73861379470156 41.095 35.67242073733998 139.7386201355132 41.095 35.67242464714442 139.73862885766158 41.095 35.67243407952983 139.73862251685065 41.095 35.67243016972493 139.73861379470156 41.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-039aa3de-561b-4001-8153-dc5cc3e08920">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-039aa3de-561b-4001-8153-dc5cc3e08920_0">
											<gml:posList>35.67242307304417 139.73869037770635 40.615 35.67243528032979 139.7386823435058 40.615 35.67243528032979 139.7386823435058 41.011 35.67242307304417 139.73869037770635 41.011 35.67242307304417 139.73869037770635 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d423fe20-4032-44e9-864a-d1c8f3f46b4a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d423fe20-4032-44e9-864a-d1c8f3f46b4a_0">
											<gml:posList>35.67242464714442 139.73862885766158 40.615 35.67243407952983 139.73862251685065 40.615 35.67243407952983 139.73862251685065 41.095 35.67242464714442 139.73862885766158 41.095 35.67242464714442 139.73862885766158 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f23114b-a1d8-4bcf-9ea5-dcf8e79077a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5f23114b-a1d8-4bcf-9ea5-dcf8e79077a6_0">
											<gml:posList>35.67243407952983 139.73862251685065 40.615 35.67243016972493 139.73861379470156 40.615 35.67243016972493 139.73861379470156 41.095 35.67243407952983 139.73862251685065 41.095 35.67243407952983 139.73862251685065 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b8154fc-363c-4aac-bfe9-85c4dbd49e6b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b8154fc-363c-4aac-bfe9-85c4dbd49e6b_0">
											<gml:posList>35.672429645660934 139.73866949198364 40.615 35.672429645660934 139.73866949198364 41.011 35.67243528032979 139.7386823435058 41.011 35.67243528032979 139.7386823435058 40.615 35.672429645660934 139.73866949198364 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_ab0fff4f-5ec7-40b6-af47-304a7f4e8695_BuildingInstallation_1061">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e38dd50d-1c26-4cf1-94d8-0aa851fe9577">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e38dd50d-1c26-4cf1-94d8-0aa851fe9577_0">
											<gml:posList>35.67239433769515 139.73853049091585 41.096 35.6723625648565 139.73855409074076 41.932 35.67239433769515 139.73853049091585 41.932 35.67239433769515 139.73853049091585 41.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00d8cd48-8bbc-4e81-9e23-1b68b139dd5e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-00d8cd48-8bbc-4e81-9e23-1b68b139dd5e_0">
											<gml:posList>35.6723625648565 139.73855409074076 41.932 35.67239433769515 139.73853049091585 41.096 35.6723625648565 139.73855409074076 41.096 35.6723625648565 139.73855409074076 41.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab4fcd87-1440-442b-9bf7-94e0c9bfd9d5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ab4fcd87-1440-442b-9bf7-94e0c9bfd9d5_0">
											<gml:posList>35.67239493614033 139.73853498614866 40.615 35.672443911620775 139.73864304076002 40.615 35.67239493614033 139.73853498614866 41.096 35.67239493614033 139.73853498614866 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9649b024-9b32-4c61-a29f-3bc3ff68760e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9649b024-9b32-4c61-a29f-3bc3ff68760e_0">
											<gml:posList>35.672393798437504 139.73853247993014 41.096 35.67239493614033 139.73853498614866 41.096 35.672393798437504 139.73853247993014 41.932 35.672393798437504 139.73853247993014 41.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a183a013-58ab-4622-8ae7-6ca4edc06218">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a183a013-58ab-4622-8ae7-6ca4edc06218_0">
											<gml:posList>35.672393798437504 139.73853247993014 41.932 35.67239493614033 139.73853498614866 41.096 35.672443911620775 139.73864304076002 41.932 35.672393798437504 139.73853247993014 41.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4ee99d95-1670-4231-be9c-dac9505e2947">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4ee99d95-1670-4231-be9c-dac9505e2947_0">
											<gml:posList>35.67239493614033 139.73853498614866 41.096 35.672443911620775 139.73864304076002 40.615 35.672443911620775 139.73864304076002 41.932 35.67239493614033 139.73853498614866 41.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e82df7fa-5e84-4d04-92a7-ff172d24d3cf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e82df7fa-5e84-4d04-92a7-ff172d24d3cf_0">
											<gml:posList>35.6724265350492 139.7386569136461 41.096 35.672425958475166 139.73865730095594 40.615 35.6724265350492 139.7386569136461 40.615 35.6724265350492 139.7386569136461 41.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58d7d955-6ffa-4cfa-873f-f744ad6b0523">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-58d7d955-6ffa-4cfa-873f-f744ad6b0523_0">
											<gml:posList>35.6724265350492 139.7386569136461 41.096 35.672425958475166 139.73865730095594 41.096 35.672425958475166 139.73865730095594 40.615 35.6724265350492 139.7386569136461 41.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c23857d5-77e3-41e2-bc3f-4bc351bdbeb7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c23857d5-77e3-41e2-bc3f-4bc351bdbeb7_0">
											<gml:posList>35.67239493614033 139.73853498614866 41.096 35.67239599914171 139.73853420058762 40.615 35.67239493614033 139.73853498614866 40.615 35.67239493614033 139.73853498614866 41.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5b596bd-6dbd-458e-bbfc-d91f0aa09bab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c5b596bd-6dbd-458e-bbfc-d91f0aa09bab_0">
											<gml:posList>35.67239493614033 139.73853498614866 41.096 35.67239599914171 139.73853420058762 41.096 35.67239599914171 139.73853420058762 40.615 35.67239493614033 139.73853498614866 41.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-568ff66d-9fbb-4dea-b63f-376f284821d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-568ff66d-9fbb-4dea-b63f-376f284821d8_0">
											<gml:posList>35.67236398042779 139.73855461930083 41.096 35.672393798437504 139.73853247993014 41.932 35.67236398042779 139.73855461930083 41.932 35.67236398042779 139.73855461930083 41.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af83bf92-9543-4176-aff1-9e58f4c853da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-af83bf92-9543-4176-aff1-9e58f4c853da_0">
											<gml:posList>35.67236398042779 139.73855461930083 41.096 35.672393798437504 139.73853247993014 41.096 35.672393798437504 139.73853247993014 41.932 35.67236398042779 139.73855461930083 41.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e139956-79c0-4b35-a5d5-d7fb89512f4e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e139956-79c0-4b35-a5d5-d7fb89512f4e_0">
											<gml:posList>35.67236487493364 139.7385573467369 41.096 35.67236388400707 139.73855808802602 40.615 35.67236388400707 139.73855808802602 41.096 35.67236487493364 139.7385573467369 41.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5411026-babe-4567-91d4-63835f51fa12">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c5411026-babe-4567-91d4-63835f51fa12_0">
											<gml:posList>35.67236487493364 139.7385573467369 41.096 35.67236487493364 139.7385573467369 40.615 35.67236388400707 139.73855808802602 40.615 35.67236487493364 139.7385573467369 41.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2e5b3b87-cd45-4d3f-981d-8dba6ca99092">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2e5b3b87-cd45-4d3f-981d-8dba6ca99092_0">
											<gml:posList>35.67239433769515 139.73853049091585 41.096 35.67239433769515 139.73853049091585 41.932 35.67239599914171 139.73853420058762 41.096 35.67239433769515 139.73853049091585 41.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e0b0f5e8-9ec4-400a-8448-23ff9a4dc781">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e0b0f5e8-9ec4-400a-8448-23ff9a4dc781_0">
											<gml:posList>35.67239599914171 139.73853420058762 40.615 35.67239599914171 139.73853420058762 41.096 35.672445462466946 139.73864365753477 40.615 35.67239599914171 139.73853420058762 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3461f556-c55c-4ffd-bf41-01fbfb6cbf24">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3461f556-c55c-4ffd-bf41-01fbfb6cbf24_0">
											<gml:posList>35.672445462466946 139.73864365753477 40.615 35.67239599914171 139.73853420058762 41.096 35.672445462466946 139.73864365753477 41.932 35.672445462466946 139.73864365753477 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d15196e7-4c4b-44e5-bbce-05c99ca41d8e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d15196e7-4c4b-44e5-bbce-05c99ca41d8e_0">
											<gml:posList>35.67239599914171 139.73853420058762 41.096 35.67239433769515 139.73853049091585 41.932 35.672445462466946 139.73864365753477 41.932 35.67239599914171 139.73853420058762 41.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d1bf851-5cdb-434b-b5e2-bb04f33d7757">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8d1bf851-5cdb-434b-b5e2-bb04f33d7757_0">
											<gml:posList>35.672443911620775 139.73864304076002 41.932 35.672445462466946 139.73864365753477 41.932 35.67239433769515 139.73853049091585 41.932 35.672443911620775 139.73864304076002 41.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe43b62d-ff81-4195-94c8-2f5336c0943d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe43b62d-ff81-4195-94c8-2f5336c0943d_0">
											<gml:posList>35.672434777790194 139.7386507841276 41.932 35.672445462466946 139.73864365753477 41.932 35.672443911620775 139.73864304076002 41.932 35.672434777790194 139.7386507841276 41.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7bb4215c-b495-4af5-aafb-bb6851791b23">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7bb4215c-b495-4af5-aafb-bb6851791b23_0">
											<gml:posList>35.67240204639966 139.73867047457418 41.932 35.67240148030696 139.7386727287363 41.932 35.67242675183011 139.73865748781023 41.932 35.67240204639966 139.73867047457418 41.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70f65626-982b-4661-96f3-2af1f173d3b9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-70f65626-982b-4661-96f3-2af1f173d3b9_0">
											<gml:posList>35.67239433769515 139.73853049091585 41.932 35.6723625648565 139.73855409074076 41.932 35.672393798437504 139.73853247993014 41.932 35.67239433769515 139.73853049091585 41.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-efd44b15-f9ac-4146-9aa3-222d47ce9922">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-efd44b15-f9ac-4146-9aa3-222d47ce9922_0">
											<gml:posList>35.672426227931325 139.73865608551822 41.932 35.67240204639966 139.73867047457418 41.932 35.67242675183011 139.73865748781023 41.932 35.672426227931325 139.73865608551822 41.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1bdef41e-fd27-4bfa-b3a0-f2b47c09c9e5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1bdef41e-fd27-4bfa-b3a0-f2b47c09c9e5_0">
											<gml:posList>35.6723625648565 139.73855409074076 41.932 35.67240148030696 139.7386727287363 41.932 35.67240204639966 139.73867047457418 41.932 35.6723625648565 139.73855409074076 41.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d849d99-64f8-4346-9511-ce3b2269425e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d849d99-64f8-4346-9511-ce3b2269425e_0">
											<gml:posList>35.67243420892696 139.73864951444708 41.932 35.672434777790194 139.7386507841276 41.932 35.672443911620775 139.73864304076002 41.932 35.67243420892696 139.73864951444708 41.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-acf4e37d-1f2e-4bf9-b9e9-d4b462d90ddc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-acf4e37d-1f2e-4bf9-b9e9-d4b462d90ddc_0">
											<gml:posList>35.67240204639966 139.73867047457418 41.932 35.67236398042779 139.73855461930083 41.932 35.6723625648565 139.73855409074076 41.932 35.67240204639966 139.73867047457418 41.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b668a75f-27ab-4548-b694-d9525fde3642">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b668a75f-27ab-4548-b694-d9525fde3642_0">
											<gml:posList>35.672393798437504 139.73853247993014 41.932 35.6723625648565 139.73855409074076 41.932 35.67236398042779 139.73855461930083 41.932 35.672393798437504 139.73853247993014 41.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01571804-37cb-4a98-b64d-b0a15f1caf36">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01571804-37cb-4a98-b64d-b0a15f1caf36_0">
											<gml:posList>35.672443911620775 139.73864304076002 41.932 35.67239433769515 139.73853049091585 41.932 35.672393798437504 139.73853247993014 41.932 35.672443911620775 139.73864304076002 41.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d99d5cb7-ead9-4bb1-a771-1dec2737c763">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d99d5cb7-ead9-4bb1-a771-1dec2737c763_0">
											<gml:posList>35.67236487493364 139.7385573467369 40.615 35.67236487493364 139.7385573467369 41.096 35.67240204639966 139.73867047457418 40.615 35.67236487493364 139.7385573467369 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b6fc3b91-0bf5-4058-a63d-1359fbf1ee1b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b6fc3b91-0bf5-4058-a63d-1359fbf1ee1b_0">
											<gml:posList>35.67240204639966 139.73867047457418 40.615 35.67236487493364 139.7385573467369 41.096 35.67240204639966 139.73867047457418 41.932 35.67240204639966 139.73867047457418 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a846b90-1c12-4558-8609-724a89cb8087">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0a846b90-1c12-4558-8609-724a89cb8087_0">
											<gml:posList>35.67240204639966 139.73867047457418 41.932 35.67236487493364 139.7385573467369 41.096 35.67236398042779 139.73855461930083 41.932 35.67240204639966 139.73867047457418 41.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e03a33f7-ee1d-41ad-86ab-bd231df8de82">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e03a33f7-ee1d-41ad-86ab-bd231df8de82_0">
											<gml:posList>35.67236487493364 139.7385573467369 41.096 35.67236398042779 139.73855461930083 41.096 35.67236398042779 139.73855461930083 41.932 35.67236487493364 139.7385573467369 41.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7916d236-d577-46ff-a339-3b50cb5657b5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7916d236-d577-46ff-a339-3b50cb5657b5_0">
											<gml:posList>35.67236388400707 139.73855808802602 40.615 35.672388866910325 139.73863427959083 40.615 35.67236388400707 139.73855808802602 41.096 35.67236388400707 139.73855808802602 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b14250de-6904-4eed-a0ae-780564e90c94">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b14250de-6904-4eed-a0ae-780564e90c94_0">
											<gml:posList>35.6723625648565 139.73855409074076 41.096 35.67236388400707 139.73855808802602 41.096 35.6723625648565 139.73855409074076 41.932 35.6723625648565 139.73855409074076 41.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-246669b0-adfd-4f84-9584-eded86bd8a4f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-246669b0-adfd-4f84-9584-eded86bd8a4f_0">
											<gml:posList>35.6723625648565 139.73855409074076 41.932 35.672388866910325 139.73863427959083 41.096 35.67240148030696 139.7386727287363 41.932 35.6723625648565 139.73855409074076 41.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e4ba50c-7a80-4fad-8df1-8fb4bf672959">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e4ba50c-7a80-4fad-8df1-8fb4bf672959_0">
											<gml:posList>35.67240148030696 139.7386727287363 41.932 35.672388866910325 139.73863427959083 41.096 35.67240148030696 139.7386727287363 41.096 35.67240148030696 139.7386727287363 41.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2299ec99-ded9-488c-8fa7-bf48d9dea531">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2299ec99-ded9-488c-8fa7-bf48d9dea531_0">
											<gml:posList>35.67236388400707 139.73855808802602 41.096 35.672388866910325 139.73863427959083 40.615 35.672388866910325 139.73863427959083 41.096 35.67236388400707 139.73855808802602 41.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f836930c-3d36-4085-af4a-4ae0869e68e3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f836930c-3d36-4085-af4a-4ae0869e68e3_0">
											<gml:posList>35.6723625648565 139.73855409074076 41.932 35.67236388400707 139.73855808802602 41.096 35.672388866910325 139.73863427959083 41.096 35.6723625648565 139.73855409074076 41.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-778f7426-5a15-49c7-9a05-96c065d1b6f1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-778f7426-5a15-49c7-9a05-96c065d1b6f1_0">
											<gml:posList>35.672443911620775 139.73864304076002 41.932 35.67243420892696 139.73864951444708 40.615 35.67243420892696 139.73864951444708 41.932 35.672443911620775 139.73864304076002 41.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-65091256-ebfa-4657-8319-71a76c6f859c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-65091256-ebfa-4657-8319-71a76c6f859c_0">
											<gml:posList>35.672443911620775 139.73864304076002 41.932 35.672443911620775 139.73864304076002 40.615 35.67243420892696 139.73864951444708 40.615 35.672443911620775 139.73864304076002 41.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-acaa5cea-96b8-4c10-9055-697f4d0f8bc5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-acaa5cea-96b8-4c10-9055-697f4d0f8bc5_0">
											<gml:posList>35.672445462466946 139.73864365753477 40.615 35.672434777790194 139.7386507841276 41.932 35.672434777790194 139.7386507841276 40.615 35.672445462466946 139.73864365753477 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-095bcbfe-e186-4d17-8d88-cb593aaba480">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-095bcbfe-e186-4d17-8d88-cb593aaba480_0">
											<gml:posList>35.672445462466946 139.73864365753477 40.615 35.672445462466946 139.73864365753477 41.932 35.672434777790194 139.7386507841276 41.932 35.672445462466946 139.73864365753477 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46ad9ca3-b422-4d72-b1c6-30f447551fb1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46ad9ca3-b422-4d72-b1c6-30f447551fb1_0">
											<gml:posList>35.67243420892696 139.73864951444708 41.932 35.672434777790194 139.7386507841276 40.615 35.672434777790194 139.7386507841276 41.932 35.67243420892696 139.73864951444708 41.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1710b59a-b3ab-4a4c-ac36-d8784537468b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1710b59a-b3ab-4a4c-ac36-d8784537468b_0">
											<gml:posList>35.67243420892696 139.73864951444708 41.932 35.67243420892696 139.73864951444708 40.615 35.672434777790194 139.7386507841276 40.615 35.67243420892696 139.73864951444708 41.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1401982-d8f4-4d7a-a26c-a548825fbe8b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d1401982-d8f4-4d7a-a26c-a548825fbe8b_0">
											<gml:posList>35.672388866910325 139.73863427959083 40.615 35.672401831677 139.7386725184372 41.096 35.672388866910325 139.73863427959083 41.096 35.672388866910325 139.73863427959083 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6380c96-5d39-4e7a-aed2-e76cd4de0d66">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d6380c96-5d39-4e7a-aed2-e76cd4de0d66_0">
											<gml:posList>35.672388866910325 139.73863427959083 40.615 35.672401831677 139.7386725184372 40.615 35.672401831677 139.7386725184372 41.096 35.672388866910325 139.73863427959083 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-03decba2-f195-442a-a013-c1ac7621120d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-03decba2-f195-442a-a013-c1ac7621120d_0">
											<gml:posList>35.67242619324878 139.73865783091264 40.615 35.672425958475166 139.73865730095594 41.096 35.67242619324878 139.73865783091264 41.096 35.67242619324878 139.73865783091264 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2083ec8e-392b-40bc-8c01-a918b5d82d08">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2083ec8e-392b-40bc-8c01-a918b5d82d08_0">
											<gml:posList>35.67242619324878 139.73865783091264 40.615 35.672425958475166 139.73865730095594 40.615 35.672425958475166 139.73865730095594 41.096 35.67242619324878 139.73865783091264 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-998c8202-6649-40a7-a367-bc7f4c05aec9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-998c8202-6649-40a7-a367-bc7f4c05aec9_0">
											<gml:posList>35.672426227931325 139.73865608551822 40.615 35.67242576844011 139.73865635117784 40.615 35.672426227931325 139.73865608551822 41.932 35.672426227931325 139.73865608551822 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f6896afc-6fe8-46e3-9bd1-ae2e33edf1d3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f6896afc-6fe8-46e3-9bd1-ae2e33edf1d3_0">
											<gml:posList>35.672426227931325 139.73865608551822 41.932 35.67242576844011 139.73865635117784 40.615 35.67240204639966 139.73867047457418 41.932 35.672426227931325 139.73865608551822 41.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4ced3843-5c82-490d-b0a8-886a97107e13">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4ced3843-5c82-490d-b0a8-886a97107e13_0">
											<gml:posList>35.67242576844011 139.73865635117784 40.615 35.67240204639966 139.73867047457418 40.615 35.67240204639966 139.73867047457418 41.932 35.67242576844011 139.73865635117784 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a682096-92d1-4e22-b074-49245272d884">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a682096-92d1-4e22-b074-49245272d884_0">
											<gml:posList>35.672401831677 139.7386725184372 40.615 35.67242619324878 139.73865783091264 40.615 35.67242619324878 139.73865783091264 41.096 35.672401831677 139.7386725184372 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b6a6e2f4-dcc8-45fd-ab6c-c7543d242d58">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b6a6e2f4-dcc8-45fd-ab6c-c7543d242d58_0">
											<gml:posList>35.67240148030696 139.7386727287363 41.096 35.672401831677 139.7386725184372 41.096 35.67240148030696 139.7386727287363 41.932 35.67240148030696 139.7386727287363 41.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-69f77204-4cbe-495a-9e40-f43b3c660cfa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-69f77204-4cbe-495a-9e40-f43b3c660cfa_0">
											<gml:posList>35.672401831677 139.7386725184372 41.096 35.672401831677 139.7386725184372 40.615 35.67242619324878 139.73865783091264 41.096 35.672401831677 139.7386725184372 41.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b570abaa-e582-4dca-bfca-ef82a15f19c4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b570abaa-e582-4dca-bfca-ef82a15f19c4_0">
											<gml:posList>35.67242675183011 139.73865748781023 41.932 35.67242665273132 139.73865755420653 41.096 35.67242675183011 139.73865748781023 41.096 35.67242675183011 139.73865748781023 41.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-980a9ccf-3da2-4a2c-bf8a-8c349eab1c5b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-980a9ccf-3da2-4a2c-bf8a-8c349eab1c5b_0">
											<gml:posList>35.67240148030696 139.7386727287363 41.932 35.67242619324878 139.73865783091264 41.096 35.67242675183011 139.73865748781023 41.932 35.67240148030696 139.7386727287363 41.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a8772e5-d90f-4889-8673-9cfdba11075a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6a8772e5-d90f-4889-8673-9cfdba11075a_0">
											<gml:posList>35.67242675183011 139.73865748781023 41.932 35.67242619324878 139.73865783091264 41.096 35.67242665273132 139.73865755420653 41.096 35.67242675183011 139.73865748781023 41.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-507df29f-270b-44f5-b0ce-40367e357450">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-507df29f-270b-44f5-b0ce-40367e357450_0">
											<gml:posList>35.672401831677 139.7386725184372 41.096 35.67242619324878 139.73865783091264 41.096 35.67240148030696 139.7386727287363 41.932 35.672401831677 139.7386725184372 41.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-95b1f811-f519-4aa9-be15-b4208397925f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-95b1f811-f519-4aa9-be15-b4208397925f_0">
											<gml:posList>35.6724265350492 139.7386569136461 40.615 35.672426227931325 139.73865608551822 40.615 35.6724265350492 139.7386569136461 41.096 35.6724265350492 139.7386569136461 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8eb5f35d-1f27-478f-87b9-fd27653dad29">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8eb5f35d-1f27-478f-87b9-fd27653dad29_0">
											<gml:posList>35.67242675183011 139.73865748781023 41.096 35.6724265350492 139.7386569136461 41.096 35.67242675183011 139.73865748781023 41.932 35.67242675183011 139.73865748781023 41.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f767b31a-1810-4605-9221-36f597a12f9b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f767b31a-1810-4605-9221-36f597a12f9b_0">
											<gml:posList>35.67242675183011 139.73865748781023 41.932 35.6724265350492 139.7386569136461 41.096 35.672426227931325 139.73865608551822 41.932 35.67242675183011 139.73865748781023 41.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd0272f8-891c-484e-9282-2c6913f81a6a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bd0272f8-891c-484e-9282-2c6913f81a6a_0">
											<gml:posList>35.6724265350492 139.7386569136461 41.096 35.672426227931325 139.73865608551822 40.615 35.672426227931325 139.73865608551822 41.932 35.6724265350492 139.7386569136461 41.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-135a794f-6c8e-420c-98cc-4180e3ced49d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67239433769515 139.73853049091585 41.096 35.67236398042779 139.73855461930083 41.096 35.6723625648565 139.73855409074076 41.096 35.67239433769515 139.73853049091585 41.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-961a5a99-e67a-41fc-8e04-86ce27b8bb9c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672388866910325 139.73863427959083 41.096 35.672401831677 139.7386725184372 41.096 35.67240148030696 139.7386727287363 41.096 35.672388866910325 139.73863427959083 41.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6b34524-c8e5-4315-8fb2-0c0c8d0b7cbb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67242576844011 139.73865635117784 40.615 35.6724265350492 139.7386569136461 40.615 35.672425958475166 139.73865730095594 40.615 35.67242576844011 139.73865635117784 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e94885f6-e809-4817-a044-477da843613c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6724265350492 139.7386569136461 40.615 35.67242576844011 139.73865635117784 40.615 35.672426227931325 139.73865608551822 40.615 35.6724265350492 139.7386569136461 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70a53d47-1a4c-4beb-9415-643732a6b3ac">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672425958475166 139.73865730095594 41.096 35.67242665273132 139.73865755420653 41.096 35.67242619324878 139.73865783091264 41.096 35.672425958475166 139.73865730095594 41.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4157f25b-fec2-406e-a941-c07c8e4d0978">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6724265350492 139.7386569136461 41.096 35.67242665273132 139.73865755420653 41.096 35.672425958475166 139.73865730095594 41.096 35.6724265350492 139.7386569136461 41.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da66907f-e99b-442d-b7fe-061baca0d8da">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67242665273132 139.73865755420653 41.096 35.6724265350492 139.7386569136461 41.096 35.67242675183011 139.73865748781023 41.096 35.67242665273132 139.73865755420653 41.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5fe5116e-e40c-4f83-be52-4628ff124914">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67236398042779 139.73855461930083 41.096 35.67236487493364 139.7385573467369 41.096 35.67236388400707 139.73855808802602 41.096 35.67236398042779 139.73855461930083 41.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-72577f12-56ee-485c-975a-dac2e828d28b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6723625648565 139.73855409074076 41.096 35.67236398042779 139.73855461930083 41.096 35.67236388400707 139.73855808802602 41.096 35.6723625648565 139.73855409074076 41.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d44f94c5-764f-4733-80b3-b2ef39c30044">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672393798437504 139.73853247993014 41.096 35.67239599914171 139.73853420058762 41.096 35.67239493614033 139.73853498614866 41.096 35.672393798437504 139.73853247993014 41.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-83b48ea0-7c43-42d8-a4d4-6474650c0495">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67236398042779 139.73855461930083 41.096 35.67239433769515 139.73853049091585 41.096 35.672393798437504 139.73853247993014 41.096 35.67236398042779 139.73855461930083 41.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16506fd8-f6ad-49bd-8c26-2fc1111af9b6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672393798437504 139.73853247993014 41.096 35.67239433769515 139.73853049091585 41.096 35.67239599914171 139.73853420058762 41.096 35.672393798437504 139.73853247993014 41.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f9c9db00-1d66-4aaa-adc1-5e269bcb44a7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67240204639966 139.73867047457418 40.615 35.67242576844011 139.73865635117784 40.615 35.672425958475166 139.73865730095594 40.615 35.67240204639966 139.73867047457418 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-962696f3-4812-44c1-8304-04b4975d6207">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67236487493364 139.7385573467369 40.615 35.67240204639966 139.73867047457418 40.615 35.672388866910325 139.73863427959083 40.615 35.67236487493364 139.7385573467369 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad680c97-f7f4-4245-ac51-4b0c1f195b65">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672388866910325 139.73863427959083 40.615 35.67236388400707 139.73855808802602 40.615 35.67236487493364 139.7385573467369 40.615 35.672388866910325 139.73863427959083 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13b7c520-d5f8-4b08-8e6b-5283afd984ad">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67242619324878 139.73865783091264 40.615 35.672401831677 139.7386725184372 40.615 35.67240204639966 139.73867047457418 40.615 35.67242619324878 139.73865783091264 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2131e544-0c25-4370-8628-2552151423ad">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67242619324878 139.73865783091264 40.615 35.67240204639966 139.73867047457418 40.615 35.672425958475166 139.73865730095594 40.615 35.67242619324878 139.73865783091264 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ef96307-eb67-4978-9f66-a42dac8dfd28">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672401831677 139.7386725184372 40.615 35.672388866910325 139.73863427959083 40.615 35.67240204639966 139.73867047457418 40.615 35.672401831677 139.7386725184372 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-398e3f8c-29bf-49df-8c4e-6010589a17b3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67239493614033 139.73853498614866 40.615 35.67239599914171 139.73853420058762 40.615 35.672443911620775 139.73864304076002 40.615 35.67239493614033 139.73853498614866 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f20faedd-6e6e-4697-89f2-db723d39c2fb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67239599914171 139.73853420058762 40.615 35.672445462466946 139.73864365753477 40.615 35.672443911620775 139.73864304076002 40.615 35.67239599914171 139.73853420058762 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fbd22cbc-405a-4ac8-8b0e-f3b9ff92e085">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672443911620775 139.73864304076002 40.615 35.672434777790194 139.7386507841276 40.615 35.67243420892696 139.73864951444708 40.615 35.672443911620775 139.73864304076002 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d3b6e1ee-9517-4008-82ae-e5ae583f2dd9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672443911620775 139.73864304076002 40.615 35.672445462466946 139.73864365753477 40.615 35.672434777790194 139.7386507841276 40.615 35.672443911620775 139.73864304076002 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e7eaffe8-71d5-4521-9c4d-b16c7c49919b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6724265350492 139.7386569136461 40.615 35.67242576844011 139.73865635117784 40.615 35.672426227931325 139.73865608551822 40.615 35.6724265350492 139.7386569136461 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c8b74f08-bc97-45b5-bc98-1b2ae2f99f03">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6724265350492 139.7386569136461 40.615 35.672425958475166 139.73865730095594 40.615 35.67242576844011 139.73865635117784 40.615 35.6724265350492 139.7386569136461 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c6e6de43-7af2-4227-9287-13277d6d2a2d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67242665273132 139.73865755420653 41.096 35.6724265350492 139.7386569136461 41.096 35.67242675183011 139.73865748781023 41.096 35.67242665273132 139.73865755420653 41.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e57a154-9085-4fe7-b870-2a73117c77c2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67242665273132 139.73865755420653 41.096 35.672425958475166 139.73865730095594 41.096 35.6724265350492 139.7386569136461 41.096 35.67242665273132 139.73865755420653 41.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_ab0fff4f-5ec7-40b6-af47-304a7f4e8695_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c794397-6269-44ba-9aa0-8ee5c6d67576">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67241273530354 139.7386228734619 40.615 35.6724217287624 139.7386429454482 40.615 35.67240248562997 139.73865590367205 40.615 35.67239349216456 139.7386358206426 40.615 35.67241273530354 139.7386228734619 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5eca9b0c-e97b-43fb-b83a-6f7bb8130d98">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5eca9b0c-e97b-43fb-b83a-6f7bb8130d98_0">
											<gml:posList>35.67239349216456 139.7386358206426 40.615 35.67239349216456 139.7386358206426 42.822 35.67241273530354 139.7386228734619 42.822 35.67241273530354 139.7386228734619 40.615 35.67239349216456 139.7386358206426 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-72ffcd3a-7b9f-4d88-b16a-6879dac3acb4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-72ffcd3a-7b9f-4d88-b16a-6879dac3acb4_0">
											<gml:posList>35.67241273530354 139.7386228734619 40.615 35.67241273530354 139.7386228734619 42.822 35.6724217287624 139.7386429454482 42.822 35.6724217287624 139.7386429454482 40.615 35.67241273530354 139.7386228734619 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-acaf02cd-03b5-48c5-b3db-c063eda76bcc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-acaf02cd-03b5-48c5-b3db-c063eda76bcc_0">
											<gml:posList>35.67241273530354 139.7386228734619 42.822 35.67239349216456 139.7386358206426 42.822 35.67240248562997 139.73865590367205 42.822 35.6724217287624 139.7386429454482 42.822 35.67241273530354 139.7386228734619 42.822</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14d62d14-4398-4650-b9da-2fe89b51ecdb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-14d62d14-4398-4650-b9da-2fe89b51ecdb_0">
											<gml:posList>35.67240248562997 139.73865590367205 42.822 35.67239349216456 139.7386358206426 42.822 35.67239349216456 139.7386358206426 40.615 35.67240248562997 139.73865590367205 40.615 35.67240248562997 139.73865590367205 42.822</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c01a21b5-d13b-4f93-a532-73915109ce38">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c01a21b5-d13b-4f93-a532-73915109ce38_0">
											<gml:posList>35.6724217287624 139.7386429454482 40.615 35.6724217287624 139.7386429454482 42.822 35.67240248562997 139.73865590367205 42.822 35.67240248562997 139.73865590367205 40.615 35.6724217287624 139.7386429454482 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_ab0fff4f-5ec7-40b6-af47-304a7f4e8695_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-66c36e0e-4140-49ca-969f-7cfcc8855843">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67247313326928 139.73868781104355 9.56 35.67245049489441 139.7387045070047 9.56 35.672430683018966 139.73865901863715 9.56 35.672453763928516 139.7386434267991 9.56 35.67247313326928 139.73868781104355 9.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2eb45236-e0a1-4fc6-aa1f-987f7ca75408">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2eb45236-e0a1-4fc6-aa1f-987f7ca75408_0">
											<gml:posList>35.672430683018966 139.73865901863715 40.388 35.672430683018966 139.73865901863715 9.56 35.67245049489441 139.7387045070047 9.56 35.67245049489441 139.7387045070047 40.388 35.672430683018966 139.73865901863715 40.388</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f98fe78c-0c16-446e-b1e0-d98d4b05a4a1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f98fe78c-0c16-446e-b1e0-d98d4b05a4a1_0">
											<gml:posList>35.672453763928516 139.7386434267991 40.388 35.672453763928516 139.7386434267991 9.56 35.672430683018966 139.73865901863715 9.56 35.672430683018966 139.73865901863715 40.388 35.672453763928516 139.7386434267991 40.388</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4f0abd55-41ad-493f-aa4f-88b91ebcfe33">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4f0abd55-41ad-493f-aa4f-88b91ebcfe33_0">
											<gml:posList>35.672453763928516 139.7386434267991 40.388 35.672430683018966 139.73865901863715 40.388 35.67245049489441 139.7387045070047 40.388 35.67247313326928 139.73868781104355 40.388 35.672453763928516 139.7386434267991 40.388</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16156a21-0121-4035-b26a-4024456bb288">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16156a21-0121-4035-b26a-4024456bb288_0">
											<gml:posList>35.67245049489441 139.7387045070047 40.388 35.67245049489441 139.7387045070047 9.56 35.67247313326928 139.73868781104355 9.56 35.67247313326928 139.73868781104355 40.388 35.67245049489441 139.7387045070047 40.388</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd5c5cc8-53b1-4f73-9756-bb2acfed364c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cd5c5cc8-53b1-4f73-9756-bb2acfed364c_0">
											<gml:posList>35.67247313326928 139.73868781104355 40.388 35.67247313326928 139.73868781104355 9.56 35.672453763928516 139.7386434267991 9.56 35.672453763928516 139.7386434267991 40.388 35.67247313326928 139.73868781104355 40.388</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-96c0601c-3f82-4d60-ba7e-b07065618817">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96c0601c-3f82-4d60-ba7e-b07065618817">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96c0601c-3f82-4d60-ba7e-b07065618817">
											<gml:posList>35.67243068302765 139.73865902968367 9.51 35.67245049489441 139.7387045070047 9.51 35.67241719045337 139.73872908068014 9.51 35.672358826310685 139.73855682365385 9.51 35.6724019768063 139.73852473768295 9.51 35.672453763928516 139.7386434267991 9.51 35.67243068302765 139.73865902968367 9.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0959cb41-d1c3-44b3-a1a3-90c6c3fa1a80">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0959cb41-d1c3-44b3-a1a3-90c6c3fa1a80">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0959cb41-d1c3-44b3-a1a3-90c6c3fa1a80">
											<gml:posList>35.672358826310685 139.73855682365385 41.096 35.67236321737442 139.73855857486151 41.096 35.67240062948857 139.73853075963925 41.096 35.6724019768063 139.73852473768295 41.096 35.672358826310685 139.73855682365385 41.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5a7435d8-33f1-4a6a-bd28-4c54352bae79">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a7435d8-33f1-4a6a-bd28-4c54352bae79">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a7435d8-33f1-4a6a-bd28-4c54352bae79">
											<gml:posList>35.672358826310685 139.73855682365385 41.096 35.67241719045337 139.73872908068014 41.096 35.672418871106345 139.7387228263552 41.096 35.67236321737442 139.73855857486151 41.096 35.672358826310685 139.73855682365385 41.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-19c1805f-093b-4878-9a5e-57cd6f1253a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-19c1805f-093b-4878-9a5e-57cd6f1253a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-19c1805f-093b-4878-9a5e-57cd6f1253a7">
											<gml:posList>35.672418871106345 139.7387228263552 40.615 35.67244582453778 139.73870292181496 40.615 35.672425958475166 139.73865730095594 40.615 35.672449039384524 139.7386417091183 40.615 35.67240062948857 139.73853075963925 40.615 35.67236321737442 139.73855857486151 40.615 35.672418871106345 139.7387228263552 40.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-065b62c4-17b7-475c-9480-55fd83bc6765">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-065b62c4-17b7-475c-9480-55fd83bc6765">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-065b62c4-17b7-475c-9480-55fd83bc6765">
											<gml:posList>35.6724019768063 139.73852473768295 41.096 35.67240062948857 139.73853075963925 41.096 35.672449039384524 139.7386417091183 41.096 35.672453763928516 139.7386434267991 41.096 35.6724019768063 139.73852473768295 41.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-df5ba5b6-bb44-49aa-a3a8-677fe184c500">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df5ba5b6-bb44-49aa-a3a8-677fe184c500">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df5ba5b6-bb44-49aa-a3a8-677fe184c500">
											<gml:posList>35.67243068302765 139.73865902968367 41.096 35.672453763928516 139.7386434267991 41.096 35.672449039384524 139.7386417091183 41.096 35.672425958475166 139.73865730095594 41.096 35.67243068302765 139.73865902968367 41.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9f8ac1c3-a7b5-4603-bedc-551557107a3d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f8ac1c3-a7b5-4603-bedc-551557107a3d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f8ac1c3-a7b5-4603-bedc-551557107a3d">
											<gml:posList>35.67245049489441 139.7387045070047 41.096 35.67244582453778 139.73870292181496 41.096 35.672418871106345 139.7387228263552 41.096 35.67241719045337 139.73872908068014 41.096 35.67245049489441 139.7387045070047 41.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2df41f0b-19c1-43cd-90c4-d28c1e719d9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2df41f0b-19c1-43cd-90c4-d28c1e719d9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2df41f0b-19c1-43cd-90c4-d28c1e719d9a">
											<gml:posList>35.67243068302765 139.73865902968367 41.096 35.672425958475166 139.73865730095594 41.096 35.67244582453778 139.73870292181496 41.096 35.67245049489441 139.7387045070047 41.096 35.67243068302765 139.73865902968367 41.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-53e45e72-00ce-402a-a8e9-9ed08b65d840">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-53e45e72-00ce-402a-a8e9-9ed08b65d840">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-53e45e72-00ce-402a-a8e9-9ed08b65d840">
											<gml:posList>35.67240062948857 139.73853075963925 41.096 35.67240062948857 139.73853075963925 40.615 35.672449039384524 139.7386417091183 40.615 35.672449039384524 139.7386417091183 41.096 35.67240062948857 139.73853075963925 41.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-60186054-7021-4313-8dbd-b417f36451b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-60186054-7021-4313-8dbd-b417f36451b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-60186054-7021-4313-8dbd-b417f36451b3">
											<gml:posList>35.6724019768063 139.73852473768295 9.51 35.672358826310685 139.73855682365385 9.51 35.672358826310685 139.73855682365385 41.096 35.6724019768063 139.73852473768295 41.096 35.6724019768063 139.73852473768295 9.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fc3b7096-7b93-4d31-bc07-a6a3530a51e9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc3b7096-7b93-4d31-bc07-a6a3530a51e9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc3b7096-7b93-4d31-bc07-a6a3530a51e9">
											<gml:posList>35.67236321737442 139.73855857486151 41.096 35.67236321737442 139.73855857486151 40.615 35.67240062948857 139.73853075963925 40.615 35.67240062948857 139.73853075963925 41.096 35.67236321737442 139.73855857486151 41.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2e3799f7-fc2d-4133-aed5-4d14833cfb5c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2e3799f7-fc2d-4133-aed5-4d14833cfb5c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2e3799f7-fc2d-4133-aed5-4d14833cfb5c">
											<gml:posList>35.672358826310685 139.73855682365385 9.51 35.67241719045337 139.73872908068014 9.51 35.67241719045337 139.73872908068014 41.096 35.672358826310685 139.73855682365385 41.096 35.672358826310685 139.73855682365385 9.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3544bb36-9d66-466e-b49d-d646309f55b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3544bb36-9d66-466e-b49d-d646309f55b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3544bb36-9d66-466e-b49d-d646309f55b6">
											<gml:posList>35.672418871106345 139.7387228263552 41.096 35.672418871106345 139.7387228263552 40.615 35.67236321737442 139.73855857486151 40.615 35.67236321737442 139.73855857486151 41.096 35.672418871106345 139.7387228263552 41.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b8f7c45c-e094-49df-8cdd-c1a2394f5814">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8f7c45c-e094-49df-8cdd-c1a2394f5814">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8f7c45c-e094-49df-8cdd-c1a2394f5814">
											<gml:posList>35.672453763928516 139.7386434267991 9.51 35.6724019768063 139.73852473768295 9.51 35.6724019768063 139.73852473768295 41.096 35.672453763928516 139.7386434267991 41.096 35.672453763928516 139.7386434267991 9.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-70f53eeb-90d8-4a29-ac46-2bf0b8e41a30">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70f53eeb-90d8-4a29-ac46-2bf0b8e41a30">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70f53eeb-90d8-4a29-ac46-2bf0b8e41a30">
											<gml:posList>35.67244582453778 139.73870292181496 41.096 35.67244582453778 139.73870292181496 40.615 35.672418871106345 139.7387228263552 40.615 35.672418871106345 139.7387228263552 41.096 35.67244582453778 139.73870292181496 41.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-18cb3ee4-6fa3-4b14-a6e5-423933800977">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18cb3ee4-6fa3-4b14-a6e5-423933800977">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18cb3ee4-6fa3-4b14-a6e5-423933800977">
											<gml:posList>35.67241719045337 139.73872908068014 9.51 35.67245049489441 139.7387045070047 9.51 35.67245049489441 139.7387045070047 41.096 35.67241719045337 139.73872908068014 41.096 35.67241719045337 139.73872908068014 9.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ca4ff1a1-0357-45d2-871c-bd9f4da86da6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca4ff1a1-0357-45d2-871c-bd9f4da86da6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca4ff1a1-0357-45d2-871c-bd9f4da86da6">
											<gml:posList>35.672425958475166 139.73865730095594 41.096 35.672425958475166 139.73865730095594 40.615 35.67244582453778 139.73870292181496 40.615 35.67244582453778 139.73870292181496 41.096 35.672425958475166 139.73865730095594 41.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-61eca8b7-5278-4040-a16d-b3c97f8ae1ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61eca8b7-5278-4040-a16d-b3c97f8ae1ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61eca8b7-5278-4040-a16d-b3c97f8ae1ec">
											<gml:posList>35.672449039384524 139.7386417091183 41.096 35.672449039384524 139.7386417091183 40.615 35.672425958475166 139.73865730095594 40.615 35.672425958475166 139.73865730095594 41.096 35.672449039384524 139.7386417091183 41.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-87056460-64d3-4712-a9a3-c29622d6d8d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-87056460-64d3-4712-a9a3-c29622d6d8d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-87056460-64d3-4712-a9a3-c29622d6d8d5">
											<gml:posList>35.67245049489441 139.7387045070047 9.51 35.67243068302765 139.73865902968367 9.51 35.67243068302765 139.73865902968367 41.096 35.67245049489441 139.7387045070047 41.096 35.67245049489441 139.7387045070047 9.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d6920b9b-db72-45c8-9199-f2bf376784c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d6920b9b-db72-45c8-9199-f2bf376784c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d6920b9b-db72-45c8-9199-f2bf376784c9">
											<gml:posList>35.67243068302765 139.73865902968367 9.51 35.672453763928516 139.7386434267991 9.51 35.672453763928516 139.7386434267991 41.096 35.67243068302765 139.73865902968367 41.096 35.67243068302765 139.73865902968367 9.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-215</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">107.28605</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>