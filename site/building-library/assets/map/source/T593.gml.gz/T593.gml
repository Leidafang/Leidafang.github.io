<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_abb28e91-3907-490c-9df9-ac85de62a3c0">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">18.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>2</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67206378935951 139.73853441666316 0 35.67204163117711 139.7384397744603 0 35.67196161145451 139.7384679272246 0 35.67198376961492 139.7385625693409 0 35.67206378935951 139.73853441666316 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67206378935951 139.73853441666316 9.866 35.67198376961492 139.7385625693409 9.866 35.67196161145451 139.7384679272246 9.866 35.67204163117711 139.7384397744603 9.866 35.67206378935951 139.73853441666316 9.866</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67206378935951 139.73853441666316 9.866 35.67204163117711 139.7384397744603 9.866 35.67204163117711 139.7384397744603 28.63 35.67206378935951 139.73853441666316 28.63 35.67206378935951 139.73853441666316 9.866</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67204163117711 139.7384397744603 9.866 35.67196161145451 139.7384679272246 9.866 35.67196161145451 139.7384679272246 28.63 35.67204163117711 139.7384397744603 28.63 35.67204163117711 139.7384397744603 9.866</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67196161145451 139.7384679272246 9.866 35.67198376961492 139.7385625693409 9.866 35.67198376961492 139.7385625693409 28.63 35.67196161145451 139.7384679272246 28.63 35.67196161145451 139.7384679272246 9.866</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67198376961492 139.7385625693409 9.866 35.67206378935951 139.73853441666316 9.866 35.67206378935951 139.73853441666316 28.63 35.67198376961492 139.7385625693409 28.63 35.67198376961492 139.7385625693409 9.866</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67206378935951 139.73853441666316 28.63 35.67204163117711 139.7384397744603 28.63 35.67196161145451 139.7384679272246 28.63 35.67198376961492 139.7385625693409 28.63 35.67206378935951 139.73853441666316 28.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-81948835-084e-4c66-914e-7e5f84b8d519"/>
							<gml:surfaceMember xlink:href="#poly-40ae307d-9bc2-41f8-801a-09a03c87af0d"/>
							<gml:surfaceMember xlink:href="#poly-3b30e796-e257-4e03-97c3-23b834fca023"/>
							<gml:surfaceMember xlink:href="#poly-1424e98c-ed1c-4773-bc60-7c41af74b9fa"/>
							<gml:surfaceMember xlink:href="#poly-182aa406-9693-48a5-bda6-10f344f2b43c"/>
							<gml:surfaceMember xlink:href="#poly-8c8f5313-2c88-49c6-8166-a9b2443e62fe"/>
							<gml:surfaceMember xlink:href="#poly-89058da0-eda8-482f-abf9-6a2da68be7f5"/>
							<gml:surfaceMember xlink:href="#poly-f0e1da35-5122-4e13-ad14-6a5a3ee95ba4"/>
							<gml:surfaceMember xlink:href="#poly-34dd364e-51ab-4e35-945c-40ee0bec004f"/>
							<gml:surfaceMember xlink:href="#poly-1ac99495-8015-48c6-898f-8a311acf07a1"/>
							<gml:surfaceMember xlink:href="#poly-9fd91045-e0aa-4a1a-83d4-a1b3466b5955"/>
							<gml:surfaceMember xlink:href="#poly-1c102818-f15d-405f-9f91-150951e7df4e"/>
							<gml:surfaceMember xlink:href="#poly-e867a09f-8337-4f11-ad23-6e4ecc20cfba"/>
							<gml:surfaceMember xlink:href="#poly-97e32a42-5d1d-4f9c-8bf2-c77b10beb5da"/>
							<gml:surfaceMember xlink:href="#poly-ea5f9752-18fd-444a-a4f4-bfc37441204f"/>
							<gml:surfaceMember xlink:href="#poly-26092504-7184-48d5-9577-2888689aaaaa"/>
							<gml:surfaceMember xlink:href="#poly-1e1f9c36-2bdb-4a85-ac44-7a63d5493132"/>
							<gml:surfaceMember xlink:href="#poly-a4d4b42f-134c-4879-a1d3-8f2777b8435c"/>
							<gml:surfaceMember xlink:href="#poly-c389034d-e6f3-4e2c-bad1-10eb3f0894b4"/>
							<gml:surfaceMember xlink:href="#poly-fe7c8242-24af-47bc-a70d-785c734464e8"/>
							<gml:surfaceMember xlink:href="#poly-9e193b1d-84a6-4bea-bca3-c2e6eec5034f"/>
							<gml:surfaceMember xlink:href="#poly-1095e7f0-41c0-4bf1-b281-d78c0a4e3990"/>
							<gml:surfaceMember xlink:href="#poly-6015c8d3-e743-453c-8439-4b5ba1a02779"/>
							<gml:surfaceMember xlink:href="#poly-6ea73879-ffc1-49c0-b5be-7af464796f83"/>
							<gml:surfaceMember xlink:href="#poly-57d969c1-e317-445f-aab4-4e2c5bf8ecbe"/>
							<gml:surfaceMember xlink:href="#poly-d5d50a58-cce7-4273-880a-c3d5acb2a4b4"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-81948835-084e-4c66-914e-7e5f84b8d519">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-81948835-084e-4c66-914e-7e5f84b8d519">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-81948835-084e-4c66-914e-7e5f84b8d519">
											<gml:posList>35.672063789359484 139.73853441666313 9.866 35.671983769614926 139.7385625693409 9.866 35.671961611454506 139.7384679272246 9.866 35.67204163117711 139.7384397744603 9.866 35.672063789359484 139.73853441666313 9.866</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-40ae307d-9bc2-41f8-801a-09a03c87af0d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-40ae307d-9bc2-41f8-801a-09a03c87af0d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-40ae307d-9bc2-41f8-801a-09a03c87af0d">
											<gml:posList>35.671961611454506 139.7384679272246 22.712 35.67197084555153 139.73850738536558 28.009 35.6719719629483 139.7385069974172 28.009 35.671961611454506 139.7384679272246 22.712</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3b30e796-e257-4e03-97c3-23b834fca023">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3b30e796-e257-4e03-97c3-23b834fca023">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3b30e796-e257-4e03-97c3-23b834fca023">
											<gml:posList>35.6719719629483 139.7385069974172 36.251 35.67198502719713 139.73855705566064 36.251 35.671987438204816 139.73855112085033 36.251 35.67197667036313 139.73850985288752 36.251 35.6719719629483 139.7385069974172 36.251</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1424e98c-ed1c-4773-bc60-7c41af74b9fa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1424e98c-ed1c-4773-bc60-7c41af74b9fa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1424e98c-ed1c-4773-bc60-7c41af74b9fa">
											<gml:posList>35.67204163117711 139.7384397744603 22.712 35.671961611454506 139.7384679272246 22.712 35.6719719629483 139.7385069974172 28.009 35.67204163117711 139.7384397744603 22.712</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-182aa406-9693-48a5-bda6-10f344f2b43c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-182aa406-9693-48a5-bda6-10f344f2b43c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-182aa406-9693-48a5-bda6-10f344f2b43c">
											<gml:posList>35.6719719629483 139.7385069974172 36.251 35.67197667036313 139.73850985288752 36.251 35.67204522348662 139.73848024454279 36.251 35.67204760746673 139.73847433185065 36.251 35.6719719629483 139.7385069974172 36.251</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8c8f5313-2c88-49c6-8166-a9b2443e62fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c8f5313-2c88-49c6-8166-a9b2443e62fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c8f5313-2c88-49c6-8166-a9b2443e62fe">
											<gml:posList>35.67204760746673 139.73847433185065 28.009 35.67204163117711 139.7384397744603 22.712 35.6719719629483 139.7385069974172 28.009 35.67204760746673 139.73847433185065 28.009</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-89058da0-eda8-482f-abf9-6a2da68be7f5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-89058da0-eda8-482f-abf9-6a2da68be7f5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-89058da0-eda8-482f-abf9-6a2da68be7f5">
											<gml:posList>35.67205621660309 139.738521412852 35.814 35.67204522348662 139.73848024454279 35.814 35.67197667036313 139.73850985288752 35.814 35.671987438204816 139.73855112085033 35.814 35.67205621660309 139.738521412852 35.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f0e1da35-5122-4e13-ad14-6a5a3ee95ba4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f0e1da35-5122-4e13-ad14-6a5a3ee95ba4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f0e1da35-5122-4e13-ad14-6a5a3ee95ba4">
											<gml:posList>35.67198502719713 139.73855705566064 22.686 35.6719719629483 139.7385069974172 22.686 35.67197084555153 139.73850738536558 22.686 35.671983769614926 139.7385625693409 22.686 35.672063789359484 139.73853441666313 22.686 35.67198502719713 139.73855705566064 22.686</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-34dd364e-51ab-4e35-945c-40ee0bec004f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-34dd364e-51ab-4e35-945c-40ee0bec004f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-34dd364e-51ab-4e35-945c-40ee0bec004f">
											<gml:posList>35.67206094204496 139.73852426830484 36.251 35.67205621660309 139.738521412852 36.251 35.671987438204816 139.73855112085033 36.251 35.67198502719713 139.73855705566064 36.251 35.67206094204496 139.73852426830484 36.251</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1ac99495-8015-48c6-898f-8a311acf07a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ac99495-8015-48c6-898f-8a311acf07a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ac99495-8015-48c6-898f-8a311acf07a1">
											<gml:posList>35.672063789359484 139.73853441666313 22.686 35.67204956290435 139.73847364465468 22.686 35.67204760746673 139.73847433185065 22.686 35.67206094204496 139.73852426830484 22.686 35.67198502719713 139.73855705566064 22.686 35.672063789359484 139.73853441666313 22.686</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9fd91045-e0aa-4a1a-83d4-a1b3466b5955">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9fd91045-e0aa-4a1a-83d4-a1b3466b5955">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9fd91045-e0aa-4a1a-83d4-a1b3466b5955">
											<gml:posList>35.67204760746673 139.73847433185065 28.009 35.67204956290435 139.73847364465468 28.009 35.67204163117711 139.7384397744603 22.712 35.67204760746673 139.73847433185065 28.009</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1c102818-f15d-405f-9f91-150951e7df4e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c102818-f15d-405f-9f91-150951e7df4e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c102818-f15d-405f-9f91-150951e7df4e">
											<gml:posList>35.67204760746673 139.73847433185065 36.251 35.67204522348662 139.73848024454279 36.251 35.67205621660309 139.738521412852 36.251 35.67206094204496 139.73852426830484 36.251 35.67204760746673 139.73847433185065 36.251</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e867a09f-8337-4f11-ad23-6e4ecc20cfba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e867a09f-8337-4f11-ad23-6e4ecc20cfba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e867a09f-8337-4f11-ad23-6e4ecc20cfba">
											<gml:posList>35.6719719629483 139.7385069974172 22.686 35.6719719629483 139.7385069974172 28.009 35.67197084555153 139.73850738536558 28.009 35.67197084555153 139.73850738536558 22.686 35.6719719629483 139.7385069974172 22.686</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-97e32a42-5d1d-4f9c-8bf2-c77b10beb5da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-97e32a42-5d1d-4f9c-8bf2-c77b10beb5da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-97e32a42-5d1d-4f9c-8bf2-c77b10beb5da">
											<gml:posList>35.671961611454506 139.7384679272246 22.712 35.671961611454506 139.7384679272246 9.866 35.671983769614926 139.7385625693409 9.866 35.671983769614926 139.7385625693409 22.686 35.67197084555153 139.73850738536558 22.686 35.67197084555153 139.73850738536558 28.009 35.671961611454506 139.7384679272246 22.712</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ea5f9752-18fd-444a-a4f4-bfc37441204f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea5f9752-18fd-444a-a4f4-bfc37441204f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea5f9752-18fd-444a-a4f4-bfc37441204f">
											<gml:posList>35.67198502719713 139.73855705566064 22.686 35.67198502719713 139.73855705566064 36.251 35.6719719629483 139.7385069974172 36.251 35.6719719629483 139.7385069974172 28.009 35.6719719629483 139.7385069974172 22.686 35.67198502719713 139.73855705566064 22.686</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-26092504-7184-48d5-9577-2888689aaaaa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26092504-7184-48d5-9577-2888689aaaaa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26092504-7184-48d5-9577-2888689aaaaa">
											<gml:posList>35.671987438204816 139.73855112085033 36.251 35.671987438204816 139.73855112085033 35.814 35.67197667036313 139.73850985288752 35.814 35.67197667036313 139.73850985288752 36.251 35.671987438204816 139.73855112085033 36.251</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1e1f9c36-2bdb-4a85-ac44-7a63d5493132">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e1f9c36-2bdb-4a85-ac44-7a63d5493132">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e1f9c36-2bdb-4a85-ac44-7a63d5493132">
											<gml:posList>35.671961611454506 139.7384679272246 22.712 35.67204163117711 139.7384397744603 22.712 35.67204163117711 139.7384397744603 9.866 35.671961611454506 139.7384679272246 9.866 35.671961611454506 139.7384679272246 22.712</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a4d4b42f-134c-4879-a1d3-8f2777b8435c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4d4b42f-134c-4879-a1d3-8f2777b8435c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4d4b42f-134c-4879-a1d3-8f2777b8435c">
											<gml:posList>35.67204760746673 139.73847433185065 36.251 35.67204760746673 139.73847433185065 28.009 35.6719719629483 139.7385069974172 28.009 35.6719719629483 139.7385069974172 36.251 35.67204760746673 139.73847433185065 36.251</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c389034d-e6f3-4e2c-bad1-10eb3f0894b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c389034d-e6f3-4e2c-bad1-10eb3f0894b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c389034d-e6f3-4e2c-bad1-10eb3f0894b4">
											<gml:posList>35.67197667036313 139.73850985288752 36.251 35.67197667036313 139.73850985288752 35.814 35.67204522348662 139.73848024454279 35.814 35.67204522348662 139.73848024454279 36.251 35.67197667036313 139.73850985288752 36.251</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fe7c8242-24af-47bc-a70d-785c734464e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe7c8242-24af-47bc-a70d-785c734464e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe7c8242-24af-47bc-a70d-785c734464e8">
											<gml:posList>35.67205621660309 139.738521412852 36.251 35.67205621660309 139.738521412852 35.814 35.671987438204816 139.73855112085033 35.814 35.671987438204816 139.73855112085033 36.251 35.67205621660309 139.738521412852 36.251</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9e193b1d-84a6-4bea-bca3-c2e6eec5034f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e193b1d-84a6-4bea-bca3-c2e6eec5034f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e193b1d-84a6-4bea-bca3-c2e6eec5034f">
											<gml:posList>35.67206094204496 139.73852426830484 22.686 35.67206094204496 139.73852426830484 36.251 35.67198502719713 139.73855705566064 36.251 35.67198502719713 139.73855705566064 22.686 35.67206094204496 139.73852426830484 22.686</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1095e7f0-41c0-4bf1-b281-d78c0a4e3990">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1095e7f0-41c0-4bf1-b281-d78c0a4e3990">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1095e7f0-41c0-4bf1-b281-d78c0a4e3990">
											<gml:posList>35.671983769614926 139.7385625693409 9.866 35.672063789359484 139.73853441666313 9.866 35.672063789359484 139.73853441666313 22.686 35.671983769614926 139.7385625693409 22.686 35.671983769614926 139.7385625693409 9.866</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6015c8d3-e743-453c-8439-4b5ba1a02779">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6015c8d3-e743-453c-8439-4b5ba1a02779">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6015c8d3-e743-453c-8439-4b5ba1a02779">
											<gml:posList>35.67204956290435 139.73847364465468 22.686 35.67204956290435 139.73847364465468 28.009 35.67204760746673 139.73847433185065 28.009 35.67204760746673 139.73847433185065 22.686 35.67204956290435 139.73847364465468 22.686</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6ea73879-ffc1-49c0-b5be-7af464796f83">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ea73879-ffc1-49c0-b5be-7af464796f83">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ea73879-ffc1-49c0-b5be-7af464796f83">
											<gml:posList>35.67204522348662 139.73848024454279 36.251 35.67204522348662 139.73848024454279 35.814 35.67205621660309 139.738521412852 35.814 35.67205621660309 139.738521412852 36.251 35.67204522348662 139.73848024454279 36.251</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-57d969c1-e317-445f-aab4-4e2c5bf8ecbe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-57d969c1-e317-445f-aab4-4e2c5bf8ecbe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-57d969c1-e317-445f-aab4-4e2c5bf8ecbe">
											<gml:posList>35.672063789359484 139.73853441666313 9.866 35.67204163117711 139.7384397744603 9.866 35.67204163117711 139.7384397744603 22.712 35.67204956290435 139.73847364465468 28.009 35.67204956290435 139.73847364465468 22.686 35.672063789359484 139.73853441666313 22.686 35.672063789359484 139.73853441666313 9.866</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d5d50a58-cce7-4273-880a-c3d5acb2a4b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5d50a58-cce7-4273-880a-c3d5acb2a4b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5d50a58-cce7-4273-880a-c3d5acb2a4b4">
											<gml:posList>35.67206094204496 139.73852426830484 22.686 35.67204760746673 139.73847433185065 22.686 35.67204760746673 139.73847433185065 28.009 35.67204760746673 139.73847433185065 36.251 35.67206094204496 139.73852426830484 36.251 35.67206094204496 139.73852426830484 22.686</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4033</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">82.3246</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1242</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>