<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_ac555124-7f3c-4e87-8a24-3df03cfd610a">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">6.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66890371509848 139.73975001575045 0 35.66883849923876 139.73969011183112 0 35.668791417392306 139.73976726817972 0 35.668797460879375 139.73977278414813 0 35.668768923838094 139.7398197631055 0 35.668825934315514 139.73987603144704 0 35.66890371509848 139.73975001575045 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66890371509848 139.73975001575045 11.29 35.668825934315514 139.73987603144704 11.29 35.668768923838094 139.7398197631055 11.29 35.668797460879375 139.73977278414813 11.29 35.668791417392306 139.73976726817972 11.29 35.66883849923876 139.73969011183112 11.29 35.66890371509848 139.73975001575045 11.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66890371509848 139.73975001575045 11.29 35.66883849923876 139.73969011183112 11.29 35.66883849923876 139.73969011183112 17.76 35.66890371509848 139.73975001575045 17.76 35.66890371509848 139.73975001575045 11.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66883849923876 139.73969011183112 11.29 35.668791417392306 139.73976726817972 11.29 35.668791417392306 139.73976726817972 17.76 35.66883849923876 139.73969011183112 17.76 35.66883849923876 139.73969011183112 11.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668791417392306 139.73976726817972 11.29 35.668797460879375 139.73977278414813 11.29 35.668797460879375 139.73977278414813 17.76 35.668791417392306 139.73976726817972 17.76 35.668791417392306 139.73976726817972 11.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668797460879375 139.73977278414813 11.29 35.668768923838094 139.7398197631055 11.29 35.668768923838094 139.7398197631055 17.76 35.668797460879375 139.73977278414813 17.76 35.668797460879375 139.73977278414813 11.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668768923838094 139.7398197631055 11.29 35.668825934315514 139.73987603144704 11.29 35.668825934315514 139.73987603144704 17.76 35.668768923838094 139.7398197631055 17.76 35.668768923838094 139.7398197631055 11.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668825934315514 139.73987603144704 11.29 35.66890371509848 139.73975001575045 11.29 35.66890371509848 139.73975001575045 17.76 35.668825934315514 139.73987603144704 17.76 35.668825934315514 139.73987603144704 11.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66890371509848 139.73975001575045 17.76 35.66883849923876 139.73969011183112 17.76 35.668791417392306 139.73976726817972 17.76 35.668797460879375 139.73977278414813 17.76 35.668768923838094 139.7398197631055 17.76 35.668825934315514 139.73987603144704 17.76 35.66890371509848 139.73975001575045 17.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-6c836df5-a334-4ccf-9518-13338de2546e"/>
							<gml:surfaceMember xlink:href="#poly-501063f6-2d72-4e7d-967b-7a35fb22c372"/>
							<gml:surfaceMember xlink:href="#poly-929c5029-ba34-4429-b2ed-65119416f4e7"/>
							<gml:surfaceMember xlink:href="#poly-f1c66a62-393b-4986-92da-c2eecc8f4761"/>
							<gml:surfaceMember xlink:href="#poly-72273337-3c6f-498a-91aa-0e3a5a05f7d2"/>
							<gml:surfaceMember xlink:href="#poly-6738a000-a224-4ff8-b5e5-1c9648ef19b8"/>
							<gml:surfaceMember xlink:href="#poly-f21dfa2e-3a40-4caf-beb2-a7e0aec255ec"/>
							<gml:surfaceMember xlink:href="#poly-b23c86b5-0829-4dd8-8bc8-b2928b485977"/>
							<gml:surfaceMember xlink:href="#poly-04633f22-e4b8-4d5c-ba21-3823b011d6f6"/>
							<gml:surfaceMember xlink:href="#poly-583ef2be-0a9b-42a4-8d85-339ecb1b19fa"/>
							<gml:surfaceMember xlink:href="#poly-2069d813-aabf-48b6-95f8-26c3e4cceb29"/>
							<gml:surfaceMember xlink:href="#poly-5b1a7b92-e367-4b8e-b435-2be66e585c7d"/>
							<gml:surfaceMember xlink:href="#poly-0ea15b9d-c7e2-4aa2-a71b-69190ba5a371"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-6c836df5-a334-4ccf-9518-13338de2546e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c836df5-a334-4ccf-9518-13338de2546e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c836df5-a334-4ccf-9518-13338de2546e">
											<gml:posList>35.66879746087938 139.73977278414813 11.29 35.6687914173923 139.73976726817972 11.29 35.66883849923874 139.73969011183112 11.29 35.66890371509849 139.73975001575045 11.29 35.66882593431549 139.739876031447 11.29 35.66876892383811 139.73981976310546 11.29 35.66879746087938 139.73977278414813 11.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-501063f6-2d72-4e7d-967b-7a35fb22c372">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-501063f6-2d72-4e7d-967b-7a35fb22c372">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-501063f6-2d72-4e7d-967b-7a35fb22c372">
											<gml:posList>35.66883849923874 139.73969011183112 17.846 35.6687914173923 139.73976726817972 17.846 35.66882376390045 139.73979720939997 18.511 35.668871107172414 139.7397200637786 18.511 35.66883849923874 139.73969011183112 17.846</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-929c5029-ba34-4429-b2ed-65119416f4e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-929c5029-ba34-4429-b2ed-65119416f4e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-929c5029-ba34-4429-b2ed-65119416f4e7">
											<gml:posList>35.668856110401016 139.73982715064437 17.846 35.66890371509849 139.73975001575045 17.846 35.668871107172414 139.7397200637786 18.511 35.66882376390045 139.73979720939997 18.511 35.668856110401016 139.73982715064437 17.846</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f1c66a62-393b-4986-92da-c2eecc8f4761">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f1c66a62-393b-4986-92da-c2eecc8f4761">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f1c66a62-393b-4986-92da-c2eecc8f4761">
											<gml:posList>35.66879746087938 139.73977278414813 14.408 35.66876892383811 139.73981976310546 14.408 35.66879114169418 139.73984169672204 14.408 35.66882168019411 139.7397952345887 14.408 35.66879746087938 139.73977278414813 14.408</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-72273337-3c6f-498a-91aa-0e3a5a05f7d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-72273337-3c6f-498a-91aa-0e3a5a05f7d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-72273337-3c6f-498a-91aa-0e3a5a05f7d2">
											<gml:posList>35.668836978505155 139.7398094219583 15.606 35.66882168019411 139.7397952345887 14.408 35.66879114169418 139.73984169672204 14.408 35.668836978505155 139.7398094219583 15.606</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6738a000-a224-4ff8-b5e5-1c9648ef19b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6738a000-a224-4ff8-b5e5-1c9648ef19b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6738a000-a224-4ff8-b5e5-1c9648ef19b8">
											<gml:posList>35.668807216535015 139.73985762846456 15.606 35.668836978505155 139.7398094219583 15.606 35.66879114169418 139.73984169672204 14.408 35.668807216535015 139.73985762846456 15.606</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f21dfa2e-3a40-4caf-beb2-a7e0aec255ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f21dfa2e-3a40-4caf-beb2-a7e0aec255ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f21dfa2e-3a40-4caf-beb2-a7e0aec255ec">
											<gml:posList>35.668856110401016 139.73982715064437 14.408 35.668836978505155 139.7398094219583 15.606 35.668807216535015 139.73985762846456 15.606 35.66882593431549 139.739876031447 14.408 35.668856110401016 139.73982715064437 14.408</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b23c86b5-0829-4dd8-8bc8-b2928b485977">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b23c86b5-0829-4dd8-8bc8-b2928b485977">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b23c86b5-0829-4dd8-8bc8-b2928b485977">
											<gml:posList>35.668871107172414 139.7397200637786 18.511 35.66890371509849 139.73975001575045 17.846 35.66890371509849 139.73975001575045 11.29 35.66883849923874 139.73969011183112 11.29 35.66883849923874 139.73969011183112 17.846 35.668871107172414 139.7397200637786 18.511</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-04633f22-e4b8-4d5c-ba21-3823b011d6f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04633f22-e4b8-4d5c-ba21-3823b011d6f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04633f22-e4b8-4d5c-ba21-3823b011d6f6">
											<gml:posList>35.66883849923874 139.73969011183112 11.29 35.6687914173923 139.73976726817972 11.29 35.6687914173923 139.73976726817972 17.846 35.66883849923874 139.73969011183112 17.846 35.66883849923874 139.73969011183112 11.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-583ef2be-0a9b-42a4-8d85-339ecb1b19fa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-583ef2be-0a9b-42a4-8d85-339ecb1b19fa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-583ef2be-0a9b-42a4-8d85-339ecb1b19fa">
											<gml:posList>35.66879746087938 139.73977278414813 11.29 35.66876892383811 139.73981976310546 11.29 35.66876892383811 139.73981976310546 14.408 35.66879746087938 139.73977278414813 14.408 35.66879746087938 139.73977278414813 11.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2069d813-aabf-48b6-95f8-26c3e4cceb29">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2069d813-aabf-48b6-95f8-26c3e4cceb29">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2069d813-aabf-48b6-95f8-26c3e4cceb29">
											<gml:posList>35.6687914173923 139.73976726817972 17.846 35.6687914173923 139.73976726817972 11.29 35.66879746087938 139.73977278414813 11.29 35.66879746087938 139.73977278414813 14.408 35.66882168019411 139.7397952345887 14.408 35.668836978505155 139.7398094219583 15.606 35.668856110401016 139.73982715064437 14.408 35.668856110401016 139.73982715064437 17.846 35.66882376390045 139.73979720939997 18.511 35.6687914173923 139.73976726817972 17.846</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5b1a7b92-e367-4b8e-b435-2be66e585c7d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b1a7b92-e367-4b8e-b435-2be66e585c7d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b1a7b92-e367-4b8e-b435-2be66e585c7d">
											<gml:posList>35.66890371509849 139.73975001575045 11.29 35.66890371509849 139.73975001575045 17.846 35.668856110401016 139.73982715064437 17.846 35.668856110401016 139.73982715064437 14.408 35.66882593431549 139.739876031447 14.408 35.66882593431549 139.739876031447 11.29 35.66890371509849 139.73975001575045 11.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0ea15b9d-c7e2-4aa2-a71b-69190ba5a371">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ea15b9d-c7e2-4aa2-a71b-69190ba5a371">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ea15b9d-c7e2-4aa2-a71b-69190ba5a371">
											<gml:posList>35.66882593431549 139.739876031447 11.29 35.66882593431549 139.739876031447 14.408 35.668807216535015 139.73985762846456 15.606 35.66879114169418 139.73984169672204 14.408 35.66876892383811 139.73981976310546 14.408 35.66876892383811 139.73981976310546 11.29 35.66882593431549 139.739876031447 11.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7924</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">122.9269</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1003</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">21</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>