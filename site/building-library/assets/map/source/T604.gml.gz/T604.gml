<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_ae97bb5b-d42a-4387-9d89-b064e8d8e29d">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">15.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67323974387 139.737766167466 0 35.673183990841075 139.73759202832838 0 35.673139209614014 139.73761340182168 0 35.6731632460579 139.73768882169188 0 35.673122970005544 139.73770809089092 0 35.673154596319485 139.73780669967533 0 35.67323974387 139.737766167466 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67323974387 139.737766167466 8.62 35.673154596319485 139.73780669967533 8.62 35.673122970005544 139.73770809089092 8.62 35.6731632460579 139.73768882169188 8.62 35.673139209614014 139.73761340182168 8.62 35.673183990841075 139.73759202832838 8.62 35.67323974387 139.737766167466 8.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67323974387 139.737766167466 8.62 35.673183990841075 139.73759202832838 8.62 35.673183990841075 139.73759202832838 23.91 35.67323974387 139.737766167466 23.91 35.67323974387 139.737766167466 8.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673183990841075 139.73759202832838 8.62 35.673139209614014 139.73761340182168 8.62 35.673139209614014 139.73761340182168 23.91 35.673183990841075 139.73759202832838 23.91 35.673183990841075 139.73759202832838 8.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673139209614014 139.73761340182168 8.62 35.6731632460579 139.73768882169188 8.62 35.6731632460579 139.73768882169188 23.91 35.673139209614014 139.73761340182168 23.91 35.673139209614014 139.73761340182168 8.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6731632460579 139.73768882169188 8.62 35.673122970005544 139.73770809089092 8.62 35.673122970005544 139.73770809089092 23.91 35.6731632460579 139.73768882169188 23.91 35.6731632460579 139.73768882169188 8.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673122970005544 139.73770809089092 8.62 35.673154596319485 139.73780669967533 8.62 35.673154596319485 139.73780669967533 23.91 35.673122970005544 139.73770809089092 23.91 35.673122970005544 139.73770809089092 8.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673154596319485 139.73780669967533 8.62 35.67323974387 139.737766167466 8.62 35.67323974387 139.737766167466 23.91 35.673154596319485 139.73780669967533 23.91 35.673154596319485 139.73780669967533 8.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67323974387 139.737766167466 23.91 35.673183990841075 139.73759202832838 23.91 35.673139209614014 139.73761340182168 23.91 35.6731632460579 139.73768882169188 23.91 35.673122970005544 139.73770809089092 23.91 35.673154596319485 139.73780669967533 23.91 35.67323974387 139.737766167466 23.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-a4aa4ef3-e679-4e8d-9583-0245c5dc928c"/>
							<gml:surfaceMember xlink:href="#poly-bb1b5447-ab07-476b-bc1b-4d3bf96d5f35"/>
							<gml:surfaceMember xlink:href="#poly-2977b8b8-13d8-4e77-98c7-82d3220a5651"/>
							<gml:surfaceMember xlink:href="#poly-e128b149-b412-43dd-ac64-ec61ae0ed084"/>
							<gml:surfaceMember xlink:href="#poly-e6988cac-ca7c-4199-8ec8-69f38d090281"/>
							<gml:surfaceMember xlink:href="#poly-80cce247-e858-4057-b8cd-cbdfe29d0455"/>
							<gml:surfaceMember xlink:href="#poly-5cb7f02b-8cca-40df-81fa-2e8daa0d7465"/>
							<gml:surfaceMember xlink:href="#poly-927c651b-a09d-4fe8-b858-5bfff6ea938c"/>
							<gml:surfaceMember xlink:href="#poly-730fe078-5e7c-4da9-98c8-b4722313b586"/>
							<gml:surfaceMember xlink:href="#poly-d94963ca-bcbd-47c3-be6b-d91d6ce683a7"/>
							<gml:surfaceMember xlink:href="#poly-3e0e6a6d-c42e-4b7a-b0a9-119fba7d7ffd"/>
							<gml:surfaceMember xlink:href="#poly-0083e99f-ae9e-4bff-8982-72b6560439e8"/>
							<gml:surfaceMember xlink:href="#poly-3f318d47-cd99-40ea-84e9-0a48ef47947b"/>
							<gml:surfaceMember xlink:href="#poly-27f83c56-b993-42ed-9139-702670ff0204"/>
							<gml:surfaceMember xlink:href="#poly-1cdc8ef7-338a-40a9-acea-58a95128310b"/>
							<gml:surfaceMember xlink:href="#poly-b8d38bb8-e24a-4103-8e11-52de2f2f36c4"/>
							<gml:surfaceMember xlink:href="#poly-d2ebdc8a-adda-4988-bde0-4e4a155c1478"/>
							<gml:surfaceMember xlink:href="#poly-26bd10ff-2368-44a0-a38a-e1b0698604c3"/>
							<gml:surfaceMember xlink:href="#poly-be46925e-edf1-41ee-992b-2668e5fe5a13"/>
							<gml:surfaceMember xlink:href="#poly-1eb08961-1b5c-450c-a858-5bd33cc46e6c"/>
							<gml:surfaceMember xlink:href="#poly-d9e0a1a5-57a3-4913-b0bb-87eff0aee164"/>
							<gml:surfaceMember xlink:href="#poly-a4d014bf-e540-4db2-978e-07abd091faff"/>
							<gml:surfaceMember xlink:href="#poly-6f2e4e36-db16-4df8-b99b-9a2bf80e3a65"/>
							<gml:surfaceMember xlink:href="#poly-3f3d9cbd-9cb8-4447-8e65-c3d7061fe1ed"/>
							<gml:surfaceMember xlink:href="#poly-a4d3e479-45cf-4ac4-9e21-b8eb6294c3b0"/>
							<gml:surfaceMember xlink:href="#poly-2da5ffd5-6361-45cb-a674-45f8b3d17ad1"/>
							<gml:surfaceMember xlink:href="#poly-58642573-2192-4ee2-b1a5-1059a918f60a"/>
							<gml:surfaceMember xlink:href="#poly-5e3c884f-d628-47ea-af82-1719c8e5b3cd"/>
							<gml:surfaceMember xlink:href="#poly-1a2f13a1-c7d5-498d-ae78-da8862c7f84a"/>
							<gml:surfaceMember xlink:href="#poly-b31576b6-b61e-453e-8549-c1784c5227c2"/>
							<gml:surfaceMember xlink:href="#poly-6aacd6ac-2453-48e2-b296-610212314ecf"/>
							<gml:surfaceMember xlink:href="#poly-c4335401-ff43-4b95-b360-f8b1aa31426d"/>
							<gml:surfaceMember xlink:href="#poly-20bf0b55-a328-42e4-8f15-250b1e661d04"/>
							<gml:surfaceMember xlink:href="#poly-3ba73d0a-836a-457e-8a08-78e054f08ac5"/>
							<gml:surfaceMember xlink:href="#poly-08d157f2-45e5-41f2-83d8-029472e3a069"/>
							<gml:surfaceMember xlink:href="#poly-6333b3a6-ceb8-4435-9ec7-f4060626415b"/>
							<gml:surfaceMember xlink:href="#poly-33418f33-27a1-4a56-9668-9673cf3a5d7a"/>
							<gml:surfaceMember xlink:href="#poly-1bd94778-5093-469d-b73d-62709836acaf"/>
							<gml:surfaceMember xlink:href="#poly-bb86a929-5d72-4fd6-8051-762b3f2013a8"/>
							<gml:surfaceMember xlink:href="#poly-e0fad7a5-d146-48f3-982a-8f639990f62c"/>
							<gml:surfaceMember xlink:href="#poly-f6fee32d-7bed-474f-9745-0a5706f268a0"/>
							<gml:surfaceMember xlink:href="#poly-10c39ce4-7a59-4ac1-b836-93f73c0b13fa"/>
							<gml:surfaceMember xlink:href="#poly-4465cceb-10a8-448e-a0a3-394c1fbefabf"/>
							<gml:surfaceMember xlink:href="#poly-5cdde15a-98df-45aa-86f9-fa1f93acbac0"/>
							<gml:surfaceMember xlink:href="#poly-66ebe857-9e05-409d-b32a-8a5fa8444dc4"/>
							<gml:surfaceMember xlink:href="#poly-5f7b73c2-45c7-4c28-b1a8-0a3ed0b007ef"/>
							<gml:surfaceMember xlink:href="#poly-7ed6ec68-5dd5-4aaf-ad9e-b1bbcbd9359a"/>
							<gml:surfaceMember xlink:href="#poly-df8c131f-6599-4674-98d3-f0b8e9555dff"/>
							<gml:surfaceMember xlink:href="#poly-ab0bbadc-8fa6-418d-bfe9-53aeda12e617"/>
							<gml:surfaceMember xlink:href="#poly-a41c3bb0-ac97-4c1c-bfec-49349c81f260"/>
							<gml:surfaceMember xlink:href="#poly-d2b2a572-3074-4393-adf0-874a93b32a45"/>
							<gml:surfaceMember xlink:href="#poly-75b3b42d-17f7-4276-bab4-844180748a85"/>
							<gml:surfaceMember xlink:href="#poly-799d0323-f9e7-4469-a7eb-8063b52d19bc"/>
							<gml:surfaceMember xlink:href="#poly-c012b349-3873-49a3-b3fd-4e4144c3f911"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_ae97bb5b-d42a-4387-9d89-b064e8d8e29d_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-712a4b3a-88d1-42db-a93d-40582fe4b003">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67320170883128 139.73766764356705 30.464 35.67319215793267 139.73767223932242 30.464 35.6731864651683 139.73765447206216 30.464 35.673196016066235 139.73764987630497 30.464 35.67320170883128 139.73766764356705 30.464</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f88e56b-52c4-4dcc-a985-391777e396f7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673203299605035 139.7377185225301 26.446 35.67319175141919 139.73768245795554 26.446 35.673202897140705 139.73767709807979 26.446 35.673214445328135 139.73771316265857 26.446 35.673203299605035 139.7377185225301 26.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de569e94-d5be-49a7-9e3e-1a343cee9eb8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de569e94-d5be-49a7-9e3e-1a343cee9eb8_0">
											<gml:posList>35.6731864651683 139.73765447206216 30.464 35.67319215793267 139.73767223932242 30.464 35.67319215793267 139.73767223932242 31.869 35.6731864651683 139.73765447206216 31.869 35.6731864651683 139.73765447206216 30.464</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b844756-6dec-45fb-822a-ff78b13efbda">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b844756-6dec-45fb-822a-ff78b13efbda_0">
											<gml:posList>35.6731864651683 139.73765447206216 31.869 35.673196016066235 139.73764987630497 31.869 35.673196016066235 139.73764987630497 30.464 35.6731864651683 139.73765447206216 30.464 35.6731864651683 139.73765447206216 31.869</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc8f0556-6aac-4515-bba9-9031ac45ccf4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc8f0556-6aac-4515-bba9-9031ac45ccf4_0">
											<gml:posList>35.6731864651683 139.73765447206216 31.869 35.67319215793267 139.73767223932242 31.869 35.67320170883128 139.73766764356705 31.869 35.673196016066235 139.73764987630497 31.869 35.6731864651683 139.73765447206216 31.869</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14c5bef0-7749-4313-af8d-24e26d8aa0e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-14c5bef0-7749-4313-af8d-24e26d8aa0e2_0">
											<gml:posList>35.67320170883128 139.73766764356705 31.869 35.67319215793267 139.73767223932242 31.869 35.67319215793267 139.73767223932242 30.464 35.67320170883128 139.73766764356705 30.464 35.67320170883128 139.73766764356705 31.869</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d2943bb8-e67c-42b7-bc91-b02dfcf7fc0f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d2943bb8-e67c-42b7-bc91-b02dfcf7fc0f_0">
											<gml:posList>35.673202897140705 139.73767709807979 27.075 35.673202897140705 139.73767709807979 26.446 35.67319175141919 139.73768245795554 26.446 35.67319175141919 139.73768245795554 27.075 35.673202897140705 139.73767709807979 27.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-31a29e94-e14e-47bb-9bef-bc99c2ddc44b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-31a29e94-e14e-47bb-9bef-bc99c2ddc44b_0">
											<gml:posList>35.67319175141919 139.73768245795554 27.075 35.67319175141919 139.73768245795554 26.446 35.673203299605035 139.7377185225301 26.446 35.673203299605035 139.7377185225301 27.075 35.67319175141919 139.73768245795554 27.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ab33959-9d9b-49c2-a35d-af643d820b23">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3ab33959-9d9b-49c2-a35d-af643d820b23_0">
											<gml:posList>35.673196016066235 139.73764987630497 31.869 35.67320170883128 139.73766764356705 31.869 35.67320170883128 139.73766764356705 30.464 35.673196016066235 139.73764987630497 30.464 35.673196016066235 139.73764987630497 31.869</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de3395d4-64af-4ba0-b2fb-4fa4356f4339">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de3395d4-64af-4ba0-b2fb-4fa4356f4339_0">
											<gml:posList>35.673202897140705 139.73767709807979 27.075 35.67319175141919 139.73768245795554 27.075 35.673203299605035 139.7377185225301 27.075 35.673214445328135 139.73771316265857 27.075 35.673202897140705 139.73767709807979 27.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e7fc7804-8e6f-46a7-b7cd-c359741cae52">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e7fc7804-8e6f-46a7-b7cd-c359741cae52_0">
											<gml:posList>35.673214445328135 139.73771316265857 27.075 35.673214445328135 139.73771316265857 26.446 35.673202897140705 139.73767709807979 26.446 35.673202897140705 139.73767709807979 27.075 35.673214445328135 139.73771316265857 27.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b3b1b01-8cfb-47ea-9417-95f25a906903">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7b3b1b01-8cfb-47ea-9417-95f25a906903_0">
											<gml:posList>35.673214445328135 139.73771316265857 27.075 35.673203299605035 139.7377185225301 27.075 35.673203299605035 139.7377185225301 26.446 35.673214445328135 139.73771316265857 26.446 35.673214445328135 139.73771316265857 27.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_ae97bb5b-d42a-4387-9d89-b064e8d8e29d_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-be4954f8-2b0a-4ca7-90b9-abaacf3c16d5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6731750025429 139.73761267419394 26.446 35.67318141829855 139.73763281561432 26.446 35.67316520876588 139.73764056761416 26.446 35.673158793020306 139.73762043724386 26.446 35.6731750025429 139.73761267419394 26.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-52473478-7bb5-42e4-84bc-bfac0150de68">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67317757159012 139.73770359605814 26.446 35.67319470917124 139.73769537900355 26.446 35.673202950192824 139.73772119623564 26.446 35.673185812609944 139.73772941328556 26.446 35.67317757159012 139.73770359605814 26.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f4c1ac4-d361-4718-b798-e2a498dbfa91">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f4c1ac4-d361-4718-b798-e2a498dbfa91_0">
											<gml:posList>35.673158793020306 139.73762043724386 28.42 35.673158793020306 139.73762043724386 26.446 35.67316520876588 139.73764056761416 26.446 35.67316520876588 139.73764056761416 28.42 35.673158793020306 139.73762043724386 28.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b268a98-76d9-4101-81b3-3e2983ad34a1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7b268a98-76d9-4101-81b3-3e2983ad34a1_0">
											<gml:posList>35.673158793020306 139.73762043724386 28.42 35.6731750025429 139.73761267419394 28.42 35.6731750025429 139.73761267419394 26.446 35.673158793020306 139.73762043724386 26.446 35.673158793020306 139.73762043724386 28.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dbc1ede7-c8d9-49b0-b857-77265cddb1ad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dbc1ede7-c8d9-49b0-b857-77265cddb1ad_0">
											<gml:posList>35.67316520876588 139.73764056761416 28.42 35.67318141829855 139.73763281561432 28.42 35.6731750025429 139.73761267419394 28.42 35.673158793020306 139.73762043724386 28.42 35.67316520876588 139.73764056761416 28.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48c21de8-dad6-4009-a336-76ec0c892ed6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-48c21de8-dad6-4009-a336-76ec0c892ed6_0">
											<gml:posList>35.67318141829855 139.73763281561432 28.42 35.67316520876588 139.73764056761416 28.42 35.67316520876588 139.73764056761416 26.446 35.67318141829855 139.73763281561432 26.446 35.67318141829855 139.73763281561432 28.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9b50b850-1e87-4a66-aba4-0f1c3d2c33c8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9b50b850-1e87-4a66-aba4-0f1c3d2c33c8_0">
											<gml:posList>35.67318141829855 139.73763281561432 28.42 35.67318141829855 139.73763281561432 26.446 35.6731750025429 139.73761267419394 26.446 35.6731750025429 139.73761267419394 28.42 35.67318141829855 139.73763281561432 28.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16523a52-82b6-4412-b64c-02e9551e70a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16523a52-82b6-4412-b64c-02e9551e70a5_0">
											<gml:posList>35.673185812609944 139.73772941328556 27.94 35.67317757159012 139.73770359605814 27.94 35.67317757159012 139.73770359605814 26.446 35.673185812609944 139.73772941328556 26.446 35.673185812609944 139.73772941328556 27.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bbaa5b30-b614-4df2-99bd-95ae96793f37">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bbaa5b30-b614-4df2-99bd-95ae96793f37_0">
											<gml:posList>35.67319470917124 139.73769537900355 27.94 35.67319470917124 139.73769537900355 26.446 35.67317757159012 139.73770359605814 26.446 35.67317757159012 139.73770359605814 27.94 35.67319470917124 139.73769537900355 27.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-67f6f468-8d0c-47f8-ab58-59f4a8aa03cf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-67f6f468-8d0c-47f8-ab58-59f4a8aa03cf_0">
											<gml:posList>35.67317757159012 139.73770359605814 27.94 35.673185812609944 139.73772941328556 27.94 35.673202950192824 139.73772119623564 27.94 35.67319470917124 139.73769537900355 27.94 35.67317757159012 139.73770359605814 27.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-183fb97a-3330-433a-ad75-62e852be9028">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-183fb97a-3330-433a-ad75-62e852be9028_0">
											<gml:posList>35.673202950192824 139.73772119623564 27.94 35.673185812609944 139.73772941328556 27.94 35.673185812609944 139.73772941328556 26.446 35.673202950192824 139.73772119623564 26.446 35.673202950192824 139.73772119623564 27.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c4a5f9ac-ec00-405a-a585-df8f45f989bf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c4a5f9ac-ec00-405a-a585-df8f45f989bf_0">
											<gml:posList>35.673202950192824 139.73772119623564 27.94 35.673202950192824 139.73772119623564 26.446 35.67319470917124 139.73769537900355 26.446 35.67319470917124 139.73769537900355 27.94 35.673202950192824 139.73772119623564 27.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-a4aa4ef3-e679-4e8d-9583-0245c5dc928c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4aa4ef3-e679-4e8d-9583-0245c5dc928c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4aa4ef3-e679-4e8d-9583-0245c5dc928c">
											<gml:posList>35.67315459631948 139.73780669967533 8.62 35.67312297000554 139.73770809089092 8.62 35.673163246057904 139.73768882169185 8.62 35.673139209614014 139.73761340182168 8.62 35.67318399084105 139.73759202832835 8.62 35.673239743869985 139.737766167466 8.62 35.67315459631948 139.73780669967533 8.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bb1b5447-ab07-476b-bc1b-4d3bf96d5f35">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb1b5447-ab07-476b-bc1b-4d3bf96d5f35">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb1b5447-ab07-476b-bc1b-4d3bf96d5f35">
											<gml:posList>35.67312611713531 139.73770977727258 21.91 35.67312297000554 139.73770809089092 21.91 35.67312579830844 139.73771691378067 21.91 35.67312805989195 139.73771582851285 21.91 35.67312611713531 139.73770977727258 21.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2977b8b8-13d8-4e77-98c7-82d3220a5651">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2977b8b8-13d8-4e77-98c7-82d3220a5651">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2977b8b8-13d8-4e77-98c7-82d3220a5651">
											<gml:posList>35.67313243080565 139.73773759622392 23.646 35.673133429109456 139.73773480023397 23.646 35.673128088775236 139.7377181482723 23.646 35.67312579830844 139.73771691378067 23.646 35.67313243080565 139.73773759622392 23.646</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e128b149-b412-43dd-ac64-ec61ae0ed084">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e128b149-b412-43dd-ac64-ec61ae0ed084">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e128b149-b412-43dd-ac64-ec61ae0ed084">
											<gml:posList>35.67312579830844 139.73771691378067 23.646 35.673128088775236 139.7377181482723 23.646 35.67315590348985 139.73770472656906 23.646 35.67315690179287 139.73770193057788 23.646 35.67312579830844 139.73771691378067 23.646</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e6988cac-ca7c-4199-8ec8-69f38d090281">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e6988cac-ca7c-4199-8ec8-69f38d090281">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e6988cac-ca7c-4199-8ec8-69f38d090281">
											<gml:posList>35.67312297000554 139.73770809089092 21.91 35.67312611713531 139.73770977727258 21.91 35.67316186100765 139.73769267862247 21.91 35.673163246057904 139.73768882169185 21.91 35.67312297000554 139.73770809089092 21.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-80cce247-e858-4057-b8cd-cbdfe29d0455">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-80cce247-e858-4057-b8cd-cbdfe29d0455">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-80cce247-e858-4057-b8cd-cbdfe29d0455">
											<gml:posList>35.67315597235967 139.7378028427578 21.91 35.67313469238936 139.73773651095655 21.91 35.67313243080565 139.73773759622392 21.91 35.67315459631948 139.73780669967533 21.91 35.67315597235967 139.7378028427578 21.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5cb7f02b-8cca-40df-81fa-2e8daa0d7465">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5cb7f02b-8cca-40df-81fa-2e8daa0d7465">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5cb7f02b-8cca-40df-81fa-2e8daa0d7465">
											<gml:posList>35.6731612438259 139.73772137853558 23.452 35.67315590348985 139.73770472656906 23.452 35.673128088775236 139.7377181482723 23.452 35.673133429109456 139.73773480023397 23.452 35.6731612438259 139.73772137853558 23.452</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-927c651b-a09d-4fe8-b858-5bfff6ea938c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-927c651b-a09d-4fe8-b858-5bfff6ea938c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-927c651b-a09d-4fe8-b858-5bfff6ea938c">
											<gml:posList>35.67316353429265 139.73772261302787 23.646 35.6731612438259 139.73772137853558 23.646 35.673133429109456 139.73773480023397 23.646 35.67313243080565 139.73773759622392 23.646 35.67316353429265 139.73772261302787 23.646</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-730fe078-5e7c-4da9-98c8-b4722313b586">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-730fe078-5e7c-4da9-98c8-b4722313b586">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-730fe078-5e7c-4da9-98c8-b4722313b586">
											<gml:posList>35.67316353429265 139.73772261302787 21.182 35.67313469238936 139.73773651095655 21.182 35.67315597235967 139.7378028427578 21.182 35.67319162626571 139.7377859430896 21.182 35.67316186100765 139.73769267862247 21.182 35.67312611713531 139.73770977727258 21.182 35.67312805989195 139.73771582851285 21.182 35.67315690179287 139.73770193057788 21.182 35.67316353429265 139.73772261302787 21.182</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d94963ca-bcbd-47c3-be6b-d91d6ce683a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d94963ca-bcbd-47c3-be6b-d91d6ce683a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d94963ca-bcbd-47c3-be6b-d91d6ce683a7">
											<gml:posList>35.67315690179287 139.73770193057788 23.646 35.67315590348985 139.73770472656906 23.646 35.6731612438259 139.73772137853558 23.646 35.67316353429265 139.73772261302787 23.646 35.67315690179287 139.73770193057788 23.646</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3e0e6a6d-c42e-4b7a-b0a9-119fba7d7ffd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e0e6a6d-c42e-4b7a-b0a9-119fba7d7ffd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e0e6a6d-c42e-4b7a-b0a9-119fba7d7ffd">
											<gml:posList>35.67318132751665 139.73774548045617 26.898 35.67318290144448 139.73774110410795 26.898 35.673142789596746 139.73761533070925 26.898 35.673139209614014 139.73761340182168 26.898 35.67318132751665 139.73774548045617 26.898</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0083e99f-ae9e-4bff-8982-72b6560439e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0083e99f-ae9e-4bff-8982-72b6560439e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0083e99f-ae9e-4bff-8982-72b6560439e8">
											<gml:posList>35.673139209614014 139.73761340182168 26.898 35.673142789596746 139.73761533070925 26.898 35.67318243495488 139.73759641570462 26.898 35.67318399084105 139.73759202832835 26.898 35.673139209614014 139.73761340182168 26.898</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3f318d47-cd99-40ea-84e9-0a48ef47947b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f318d47-cd99-40ea-84e9-0a48ef47947b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f318d47-cd99-40ea-84e9-0a48ef47947b">
											<gml:posList>35.67319478242562 139.73778765155828 21.91 35.67319162626571 139.7377859430896 21.91 35.67315597235967 139.7378028427578 21.91 35.67315459631948 139.73780669967533 21.91 35.67319478242562 139.73778765155828 21.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-27f83c56-b993-42ed-9139-702670ff0204">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-27f83c56-b993-42ed-9139-702670ff0204">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-27f83c56-b993-42ed-9139-702670ff0204">
											<gml:posList>35.67319478242562 139.73778765155828 21.91 35.673163246057904 139.73768882169185 21.91 35.67316186100765 139.73769267862247 21.91 35.67319162626571 139.7377859430896 21.91 35.67319478242562 139.73778765155828 21.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1cdc8ef7-338a-40a9-acea-58a95128310b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1cdc8ef7-338a-40a9-acea-58a95128310b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1cdc8ef7-338a-40a9-acea-58a95128310b">
											<gml:posList>35.67318290144448 139.73774110410795 26.446 35.67322264581517 139.73772199019822 26.446 35.67320754644634 139.73767486110927 26.446 35.67318889515879 139.7376838311475 26.446 35.673177464413 139.7376481088903 26.446 35.673196115706695 139.73763914989166 26.446 35.67318243495488 139.73759641570462 26.446 35.673142789596746 139.73761533070925 26.446 35.67318290144448 139.73774110410795 26.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b8d38bb8-e24a-4103-8e11-52de2f2f36c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8d38bb8-e24a-4103-8e11-52de2f2f36c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8d38bb8-e24a-4103-8e11-52de2f2f36c4">
											<gml:posList>35.67318889515879 139.7376838311475 30.857 35.67319032515447 139.7376798195088 30.857 35.673180728765814 139.73764985036408 30.857 35.673177464413 139.7376481088903 30.857 35.67318889515879 139.7376838311475 30.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d2ebdc8a-adda-4988-bde0-4e4a155c1478">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d2ebdc8a-adda-4988-bde0-4e4a155c1478">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d2ebdc8a-adda-4988-bde0-4e4a155c1478">
											<gml:posList>35.673177464413 139.7376481088903 30.857 35.673180728765814 139.73764985036408 30.857 35.67319725363869 139.73764192124185 30.857 35.67319868363297 139.73763790960194 30.857 35.673177464413 139.7376481088903 30.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-26bd10ff-2368-44a0-a38a-e1b0698604c3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26bd10ff-2368-44a0-a38a-e1b0698604c3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26bd10ff-2368-44a0-a38a-e1b0698604c3">
											<gml:posList>35.67318243495488 139.73759641570462 26.898 35.673196115706695 139.73763914989166 26.898 35.67319868363297 139.73763790960194 26.898 35.67318399084105 139.73759202832835 26.898 35.67318243495488 139.73759641570462 26.898</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-be46925e-edf1-41ee-992b-2668e5fe5a13">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-be46925e-edf1-41ee-992b-2668e5fe5a13">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-be46925e-edf1-41ee-992b-2668e5fe5a13">
											<gml:posList>35.67320685002931 139.73767189039177 30.464 35.67319725363869 139.73764192124185 30.464 35.673180728765814 139.73764985036408 30.464 35.67319032515447 139.7376798195088 30.464 35.67320685002931 139.73767189039177 30.464</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1eb08961-1b5c-450c-a858-5bd33cc46e6c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1eb08961-1b5c-450c-a858-5bd33cc46e6c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1eb08961-1b5c-450c-a858-5bd33cc46e6c">
											<gml:posList>35.67321011438176 139.73767363186715 30.857 35.67320685002931 139.73767189039177 30.857 35.67319032515447 139.7376798195088 30.857 35.67318889515879 139.7376838311475 30.857 35.67321011438176 139.73767363186715 30.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d9e0a1a5-57a3-4913-b0bb-87eff0aee164">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d9e0a1a5-57a3-4913-b0bb-87eff0aee164">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d9e0a1a5-57a3-4913-b0bb-87eff0aee164">
											<gml:posList>35.67319868363297 139.73763790960194 30.857 35.67319725363869 139.73764192124185 30.857 35.67320685002931 139.73767189039177 30.857 35.67321011438176 139.73767363186715 30.857 35.67319868363297 139.73763790960194 30.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a4d014bf-e540-4db2-978e-07abd091faff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4d014bf-e540-4db2-978e-07abd091faff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4d014bf-e540-4db2-978e-07abd091faff">
											<gml:posList>35.67322621676486 139.73772389701008 26.898 35.67322264581517 139.73772199019822 26.898 35.67318290144448 139.73774110410795 26.898 35.67318132751665 139.73774548045617 26.898 35.67322621676486 139.73772389701008 26.898</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6f2e4e36-db16-4df8-b99b-9a2bf80e3a65">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f2e4e36-db16-4df8-b99b-9a2bf80e3a65">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f2e4e36-db16-4df8-b99b-9a2bf80e3a65">
											<gml:posList>35.673239743869985 139.737766167466 21.91 35.67322621676486 139.73772389701008 26.898 35.67318132751665 139.73774548045617 26.898 35.67319478242562 139.73778765155828 21.91 35.673239743869985 139.737766167466 21.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3f3d9cbd-9cb8-4447-8e65-c3d7061fe1ed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f3d9cbd-9cb8-4447-8e65-c3d7061fe1ed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f3d9cbd-9cb8-4447-8e65-c3d7061fe1ed">
											<gml:posList>35.67322264581517 139.73772199019822 26.898 35.67322621676486 139.73772389701008 26.898 35.67321011438176 139.73767363186715 26.898 35.67320754644634 139.73767486110927 26.898 35.67322264581517 139.73772199019822 26.898</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a4d3e479-45cf-4ac4-9e21-b8eb6294c3b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4d3e479-45cf-4ac4-9e21-b8eb6294c3b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4d3e479-45cf-4ac4-9e21-b8eb6294c3b0">
											<gml:posList>35.673128088775236 139.7377181482723 23.646 35.673128088775236 139.7377181482723 23.452 35.67315590348985 139.73770472656906 23.452 35.67315590348985 139.73770472656906 23.646 35.673128088775236 139.7377181482723 23.646</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2da5ffd5-6361-45cb-a674-45f8b3d17ad1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2da5ffd5-6361-45cb-a674-45f8b3d17ad1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2da5ffd5-6361-45cb-a674-45f8b3d17ad1">
											<gml:posList>35.6731612438259 139.73772137853558 23.646 35.6731612438259 139.73772137853558 23.452 35.673133429109456 139.73773480023397 23.452 35.673133429109456 139.73773480023397 23.646 35.6731612438259 139.73772137853558 23.646</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-58642573-2192-4ee2-b1a5-1059a918f60a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-58642573-2192-4ee2-b1a5-1059a918f60a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-58642573-2192-4ee2-b1a5-1059a918f60a">
											<gml:posList>35.67315590348985 139.73770472656906 23.646 35.67315590348985 139.73770472656906 23.452 35.6731612438259 139.73772137853558 23.452 35.6731612438259 139.73772137853558 23.646 35.67315590348985 139.73770472656906 23.646</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5e3c884f-d628-47ea-af82-1719c8e5b3cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e3c884f-d628-47ea-af82-1719c8e5b3cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e3c884f-d628-47ea-af82-1719c8e5b3cd">
											<gml:posList>35.67318290144448 139.73774110410795 26.898 35.67318290144448 139.73774110410795 26.446 35.673142789596746 139.73761533070925 26.446 35.673142789596746 139.73761533070925 26.898 35.67318290144448 139.73774110410795 26.898</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1a2f13a1-c7d5-498d-ae78-da8862c7f84a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a2f13a1-c7d5-498d-ae78-da8862c7f84a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a2f13a1-c7d5-498d-ae78-da8862c7f84a">
											<gml:posList>35.67319032515447 139.7376798195088 30.857 35.67319032515447 139.7376798195088 30.464 35.673180728765814 139.73764985036408 30.464 35.673180728765814 139.73764985036408 30.857 35.67319032515447 139.7376798195088 30.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b31576b6-b61e-453e-8549-c1784c5227c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b31576b6-b61e-453e-8549-c1784c5227c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b31576b6-b61e-453e-8549-c1784c5227c2">
											<gml:posList>35.67318243495488 139.73759641570462 26.898 35.67318243495488 139.73759641570462 26.446 35.673196115706695 139.73763914989166 26.446 35.673196115706695 139.73763914989166 26.898 35.67318243495488 139.73759641570462 26.898</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6aacd6ac-2453-48e2-b296-610212314ecf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6aacd6ac-2453-48e2-b296-610212314ecf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6aacd6ac-2453-48e2-b296-610212314ecf">
											<gml:posList>35.67318399084105 139.73759202832835 8.62 35.673139209614014 139.73761340182168 8.62 35.673139209614014 139.73761340182168 26.898 35.67318399084105 139.73759202832835 26.898 35.67318399084105 139.73759202832835 8.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c4335401-ff43-4b95-b360-f8b1aa31426d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4335401-ff43-4b95-b360-f8b1aa31426d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4335401-ff43-4b95-b360-f8b1aa31426d">
											<gml:posList>35.673142789596746 139.73761533070925 26.898 35.673142789596746 139.73761533070925 26.446 35.67318243495488 139.73759641570462 26.446 35.67318243495488 139.73759641570462 26.898 35.673142789596746 139.73761533070925 26.898</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-20bf0b55-a328-42e4-8f15-250b1e661d04">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20bf0b55-a328-42e4-8f15-250b1e661d04">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20bf0b55-a328-42e4-8f15-250b1e661d04">
											<gml:posList>35.673196115706695 139.73763914989166 26.898 35.673196115706695 139.73763914989166 26.446 35.673177464413 139.7376481088903 26.446 35.673177464413 139.7376481088903 30.857 35.67319868363297 139.73763790960194 30.857 35.67319868363297 139.73763790960194 26.898 35.673196115706695 139.73763914989166 26.898</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3ba73d0a-836a-457e-8a08-78e054f08ac5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ba73d0a-836a-457e-8a08-78e054f08ac5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ba73d0a-836a-457e-8a08-78e054f08ac5">
											<gml:posList>35.673180728765814 139.73764985036408 30.857 35.673180728765814 139.73764985036408 30.464 35.67319725363869 139.73764192124185 30.464 35.67319725363869 139.73764192124185 30.857 35.673180728765814 139.73764985036408 30.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-08d157f2-45e5-41f2-83d8-029472e3a069">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-08d157f2-45e5-41f2-83d8-029472e3a069">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-08d157f2-45e5-41f2-83d8-029472e3a069">
											<gml:posList>35.67319725363869 139.73764192124185 30.857 35.67319725363869 139.73764192124185 30.464 35.67320685002931 139.73767189039177 30.464 35.67320685002931 139.73767189039177 30.857 35.67319725363869 139.73764192124185 30.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6333b3a6-ceb8-4435-9ec7-f4060626415b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6333b3a6-ceb8-4435-9ec7-f4060626415b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6333b3a6-ceb8-4435-9ec7-f4060626415b">
											<gml:posList>35.673177464413 139.7376481088903 26.446 35.67318889515879 139.7376838311475 26.446 35.67318889515879 139.7376838311475 30.857 35.673177464413 139.7376481088903 30.857 35.673177464413 139.7376481088903 26.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-33418f33-27a1-4a56-9668-9673cf3a5d7a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-33418f33-27a1-4a56-9668-9673cf3a5d7a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-33418f33-27a1-4a56-9668-9673cf3a5d7a">
											<gml:posList>35.67320685002931 139.73767189039177 30.857 35.67320685002931 139.73767189039177 30.464 35.67319032515447 139.7376798195088 30.464 35.67319032515447 139.7376798195088 30.857 35.67320685002931 139.73767189039177 30.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1bd94778-5093-469d-b73d-62709836acaf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1bd94778-5093-469d-b73d-62709836acaf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1bd94778-5093-469d-b73d-62709836acaf">
											<gml:posList>35.67320754644634 139.73767486110927 26.898 35.67321011438176 139.73767363186715 26.898 35.67321011438176 139.73767363186715 30.857 35.67318889515879 139.7376838311475 30.857 35.67318889515879 139.7376838311475 26.446 35.67320754644634 139.73767486110927 26.446 35.67320754644634 139.73767486110927 26.898</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bb86a929-5d72-4fd6-8051-762b3f2013a8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb86a929-5d72-4fd6-8051-762b3f2013a8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb86a929-5d72-4fd6-8051-762b3f2013a8">
											<gml:posList>35.67318399084105 139.73759202832835 8.62 35.67318399084105 139.73759202832835 26.898 35.67319868363297 139.73763790960194 26.898 35.67319868363297 139.73763790960194 30.857 35.67321011438176 139.73767363186715 30.857 35.67321011438176 139.73767363186715 26.898 35.67322621676486 139.73772389701008 26.898 35.673239743869985 139.737766167466 21.91 35.673239743869985 139.737766167466 8.62 35.67318399084105 139.73759202832835 8.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e0fad7a5-d146-48f3-982a-8f639990f62c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e0fad7a5-d146-48f3-982a-8f639990f62c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e0fad7a5-d146-48f3-982a-8f639990f62c">
											<gml:posList>35.673163246057904 139.73768882169185 8.62 35.67312297000554 139.73770809089092 8.62 35.67312297000554 139.73770809089092 21.91 35.673163246057904 139.73768882169185 21.91 35.673163246057904 139.73768882169185 8.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f6fee32d-7bed-474f-9745-0a5706f268a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f6fee32d-7bed-474f-9745-0a5706f268a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f6fee32d-7bed-474f-9745-0a5706f268a0">
											<gml:posList>35.67320754644634 139.73767486110927 26.898 35.67320754644634 139.73767486110927 26.446 35.67322264581517 139.73772199019822 26.446 35.67322264581517 139.73772199019822 26.898 35.67320754644634 139.73767486110927 26.898</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-10c39ce4-7a59-4ac1-b836-93f73c0b13fa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-10c39ce4-7a59-4ac1-b836-93f73c0b13fa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-10c39ce4-7a59-4ac1-b836-93f73c0b13fa">
											<gml:posList>35.673163246057904 139.73768882169185 21.91 35.67319478242562 139.73778765155828 21.91 35.67318132751665 139.73774548045617 26.898 35.673139209614014 139.73761340182168 26.898 35.673139209614014 139.73761340182168 8.62 35.673163246057904 139.73768882169185 8.62 35.673163246057904 139.73768882169185 21.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4465cceb-10a8-448e-a0a3-394c1fbefabf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4465cceb-10a8-448e-a0a3-394c1fbefabf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4465cceb-10a8-448e-a0a3-394c1fbefabf">
											<gml:posList>35.67312611713531 139.73770977727258 21.91 35.67312611713531 139.73770977727258 21.182 35.67316186100765 139.73769267862247 21.182 35.67316186100765 139.73769267862247 21.91 35.67312611713531 139.73770977727258 21.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5cdde15a-98df-45aa-86f9-fa1f93acbac0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5cdde15a-98df-45aa-86f9-fa1f93acbac0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5cdde15a-98df-45aa-86f9-fa1f93acbac0">
											<gml:posList>35.67312805989195 139.73771582851285 21.91 35.67312579830844 139.73771691378067 21.91 35.67312579830844 139.73771691378067 23.646 35.67315690179287 139.73770193057788 23.646 35.67315690179287 139.73770193057788 21.182 35.67312805989195 139.73771582851285 21.182 35.67312805989195 139.73771582851285 21.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-66ebe857-9e05-409d-b32a-8a5fa8444dc4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66ebe857-9e05-409d-b32a-8a5fa8444dc4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66ebe857-9e05-409d-b32a-8a5fa8444dc4">
											<gml:posList>35.67315690179287 139.73770193057788 23.646 35.67316353429265 139.73772261302787 23.646 35.67316353429265 139.73772261302787 21.182 35.67315690179287 139.73770193057788 21.182 35.67315690179287 139.73770193057788 23.646</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5f7b73c2-45c7-4c28-b1a8-0a3ed0b007ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f7b73c2-45c7-4c28-b1a8-0a3ed0b007ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f7b73c2-45c7-4c28-b1a8-0a3ed0b007ef">
											<gml:posList>35.67312805989195 139.73771582851285 21.91 35.67312805989195 139.73771582851285 21.182 35.67312611713531 139.73770977727258 21.182 35.67312611713531 139.73770977727258 21.91 35.67312805989195 139.73771582851285 21.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7ed6ec68-5dd5-4aaf-ad9e-b1bbcbd9359a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ed6ec68-5dd5-4aaf-ad9e-b1bbcbd9359a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ed6ec68-5dd5-4aaf-ad9e-b1bbcbd9359a">
											<gml:posList>35.673133429109456 139.73773480023397 23.646 35.673133429109456 139.73773480023397 23.452 35.673128088775236 139.7377181482723 23.452 35.673128088775236 139.7377181482723 23.646 35.673133429109456 139.73773480023397 23.646</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-df8c131f-6599-4674-98d3-f0b8e9555dff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df8c131f-6599-4674-98d3-f0b8e9555dff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df8c131f-6599-4674-98d3-f0b8e9555dff">
											<gml:posList>35.67316353429265 139.73772261302787 21.182 35.67316353429265 139.73772261302787 23.646 35.67313243080565 139.73773759622392 23.646 35.67313243080565 139.73773759622392 21.91 35.67313469238936 139.73773651095655 21.91 35.67313469238936 139.73773651095655 21.182 35.67316353429265 139.73772261302787 21.182</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ab0bbadc-8fa6-418d-bfe9-53aeda12e617">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab0bbadc-8fa6-418d-bfe9-53aeda12e617">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab0bbadc-8fa6-418d-bfe9-53aeda12e617">
											<gml:posList>35.67322264581517 139.73772199019822 26.898 35.67322264581517 139.73772199019822 26.446 35.67318290144448 139.73774110410795 26.446 35.67318290144448 139.73774110410795 26.898 35.67322264581517 139.73772199019822 26.898</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a41c3bb0-ac97-4c1c-bfec-49349c81f260">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a41c3bb0-ac97-4c1c-bfec-49349c81f260">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a41c3bb0-ac97-4c1c-bfec-49349c81f260">
											<gml:posList>35.67319162626571 139.7377859430896 21.182 35.67319162626571 139.7377859430896 21.91 35.67316186100765 139.73769267862247 21.91 35.67316186100765 139.73769267862247 21.182 35.67319162626571 139.7377859430896 21.182</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d2b2a572-3074-4393-adf0-874a93b32a45">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d2b2a572-3074-4393-adf0-874a93b32a45">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d2b2a572-3074-4393-adf0-874a93b32a45">
											<gml:posList>35.67313243080565 139.73773759622392 21.91 35.67313243080565 139.73773759622392 23.646 35.67312579830844 139.73771691378067 23.646 35.67312579830844 139.73771691378067 21.91 35.67312297000554 139.73770809089092 21.91 35.67312297000554 139.73770809089092 8.62 35.67315459631948 139.73780669967533 8.62 35.67315459631948 139.73780669967533 21.91 35.67313243080565 139.73773759622392 21.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-75b3b42d-17f7-4276-bab4-844180748a85">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-75b3b42d-17f7-4276-bab4-844180748a85">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-75b3b42d-17f7-4276-bab4-844180748a85">
											<gml:posList>35.67315597235967 139.7378028427578 21.91 35.67315597235967 139.7378028427578 21.182 35.67313469238936 139.73773651095655 21.182 35.67313469238936 139.73773651095655 21.91 35.67315597235967 139.7378028427578 21.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-799d0323-f9e7-4469-a7eb-8063b52d19bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-799d0323-f9e7-4469-a7eb-8063b52d19bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-799d0323-f9e7-4469-a7eb-8063b52d19bc">
											<gml:posList>35.673239743869985 139.737766167466 8.62 35.673239743869985 139.737766167466 21.91 35.67319478242562 139.73778765155828 21.91 35.67315459631948 139.73780669967533 21.91 35.67315459631948 139.73780669967533 8.62 35.673239743869985 139.737766167466 8.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c012b349-3873-49a3-b3fd-4e4144c3f911">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c012b349-3873-49a3-b3fd-4e4144c3f911">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c012b349-3873-49a3-b3fd-4e4144c3f911">
											<gml:posList>35.67319162626571 139.7377859430896 21.91 35.67319162626571 139.7377859430896 21.182 35.67315597235967 139.7378028427578 21.182 35.67315597235967 139.7378028427578 21.91 35.67319162626571 139.7377859430896 21.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1657</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">90.49395</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.12</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>