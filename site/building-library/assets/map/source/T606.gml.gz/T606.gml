<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_afd8feed-6ff3-49c2-85a4-9fc5d403899a">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>46</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13101046002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">33.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67172752703745 139.74340425297717 0 35.671730964990566 139.7433971683491 0 35.67173405499731 139.74339488931489 0 35.67173772165119 139.7433923003331 0 35.67174115540048 139.74339165578706 0 35.6717451395231 139.74339172864268 0 35.67175487646273 139.74339455665682 0 35.67175944941219 139.74306128013794 0 35.67153053094215 139.74310163638745 0 35.67152983392838 139.74313378224858 0 35.67172752703745 139.74340425297717 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67172752703745 139.74340425297717 8.1 35.67152983392838 139.74313378224858 8.1 35.67153053094215 139.74310163638745 8.1 35.67175944941219 139.74306128013794 8.1 35.67175487646273 139.74339455665682 8.1 35.6717451395231 139.74339172864268 8.1 35.67174115540048 139.74339165578706 8.1 35.67173772165119 139.7433923003331 8.1 35.67173405499731 139.74339488931489 8.1 35.671730964990566 139.7433971683491 8.1 35.67172752703745 139.74340425297717 8.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67172752703745 139.74340425297717 8.1 35.671730964990566 139.7433971683491 8.1 35.671730964990566 139.7433971683491 36.71 35.67172752703745 139.74340425297717 36.71 35.67172752703745 139.74340425297717 8.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671730964990566 139.7433971683491 8.1 35.67173405499731 139.74339488931489 8.1 35.67173405499731 139.74339488931489 36.71 35.671730964990566 139.7433971683491 36.71 35.671730964990566 139.7433971683491 8.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67173405499731 139.74339488931489 8.1 35.67173772165119 139.7433923003331 8.1 35.67173772165119 139.7433923003331 36.71 35.67173405499731 139.74339488931489 36.71 35.67173405499731 139.74339488931489 8.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67173772165119 139.7433923003331 8.1 35.67174115540048 139.74339165578706 8.1 35.67174115540048 139.74339165578706 36.71 35.67173772165119 139.7433923003331 36.71 35.67173772165119 139.7433923003331 8.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67174115540048 139.74339165578706 8.1 35.6717451395231 139.74339172864268 8.1 35.6717451395231 139.74339172864268 36.71 35.67174115540048 139.74339165578706 36.71 35.67174115540048 139.74339165578706 8.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6717451395231 139.74339172864268 8.1 35.67175487646273 139.74339455665682 8.1 35.67175487646273 139.74339455665682 36.71 35.6717451395231 139.74339172864268 36.71 35.6717451395231 139.74339172864268 8.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67175487646273 139.74339455665682 8.1 35.67175944941219 139.74306128013794 8.1 35.67175944941219 139.74306128013794 36.71 35.67175487646273 139.74339455665682 36.71 35.67175487646273 139.74339455665682 8.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67175944941219 139.74306128013794 8.1 35.67153053094215 139.74310163638745 8.1 35.67153053094215 139.74310163638745 36.71 35.67175944941219 139.74306128013794 36.71 35.67175944941219 139.74306128013794 8.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67153053094215 139.74310163638745 8.1 35.67152983392838 139.74313378224858 8.1 35.67152983392838 139.74313378224858 36.71 35.67153053094215 139.74310163638745 36.71 35.67153053094215 139.74310163638745 8.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67152983392838 139.74313378224858 8.1 35.67172752703745 139.74340425297717 8.1 35.67172752703745 139.74340425297717 36.71 35.67152983392838 139.74313378224858 36.71 35.67152983392838 139.74313378224858 8.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67172752703745 139.74340425297717 36.71 35.671730964990566 139.7433971683491 36.71 35.67173405499731 139.74339488931489 36.71 35.67173772165119 139.7433923003331 36.71 35.67174115540048 139.74339165578706 36.71 35.6717451395231 139.74339172864268 36.71 35.67175487646273 139.74339455665682 36.71 35.67175944941219 139.74306128013794 36.71 35.67153053094215 139.74310163638745 36.71 35.67152983392838 139.74313378224858 36.71 35.67172752703745 139.74340425297717 36.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-11343a3b-5445-437a-8575-db494e83b6ce"/>
							<gml:surfaceMember xlink:href="#poly-6a8291df-d6c1-4f23-ad87-5b3729499a03"/>
							<gml:surfaceMember xlink:href="#poly-61cc08c8-61e5-4fce-80c8-37fc43b4f6aa"/>
							<gml:surfaceMember xlink:href="#poly-3b317aec-a6c0-4d14-a540-f19131ff2a42"/>
							<gml:surfaceMember xlink:href="#poly-f403bdd2-1a66-4122-bc29-287d6facfb75"/>
							<gml:surfaceMember xlink:href="#poly-702556ba-80ba-4b72-ad0b-3b76a38295f1"/>
							<gml:surfaceMember xlink:href="#poly-87fa50ac-20d4-4649-bff1-5450957e65c0"/>
							<gml:surfaceMember xlink:href="#poly-a4eb41f5-9089-4a2c-b58a-e5f13cc31fed"/>
							<gml:surfaceMember xlink:href="#poly-97981d59-8eb4-4e70-914b-802ed15a4103"/>
							<gml:surfaceMember xlink:href="#poly-bf901497-de8e-4327-9c5f-4d2edbadc5e3"/>
							<gml:surfaceMember xlink:href="#poly-001ce4c1-3597-4999-b5a2-9e2034c0ff76"/>
							<gml:surfaceMember xlink:href="#poly-e9502e34-8798-46b9-a3e0-e22eee12136c"/>
							<gml:surfaceMember xlink:href="#poly-8b4b135a-a5e1-4f90-b12f-c5e03495d642"/>
							<gml:surfaceMember xlink:href="#poly-ab231aa8-91a4-42d6-b0ce-9e14c2a2a24d"/>
							<gml:surfaceMember xlink:href="#poly-b6c6dcd9-2603-459f-bd41-91663cb3460d"/>
							<gml:surfaceMember xlink:href="#poly-45d89c6c-2d47-4ba9-bcb5-d7e05957d683"/>
							<gml:surfaceMember xlink:href="#poly-4df51afd-5db9-463b-8aac-8becd4b64e77"/>
							<gml:surfaceMember xlink:href="#poly-5cb733da-8490-4919-a86a-cc92da4e3a28"/>
							<gml:surfaceMember xlink:href="#poly-e667e195-e90c-4f53-9af7-eade33b49601"/>
							<gml:surfaceMember xlink:href="#poly-054578d3-d67c-49ef-8948-debb4e133d60"/>
							<gml:surfaceMember xlink:href="#poly-83b00173-395a-4a81-8b1d-1d205fdf6982"/>
							<gml:surfaceMember xlink:href="#poly-c6607901-8416-4ac7-83d4-c45d16645f83"/>
							<gml:surfaceMember xlink:href="#poly-f0040413-82c7-40ec-a286-057a5d00e995"/>
							<gml:surfaceMember xlink:href="#poly-df88fb3e-0b7a-43d0-8111-18a85771c659"/>
							<gml:surfaceMember xlink:href="#poly-b796cce5-3301-480c-806e-d2d4836044e6"/>
							<gml:surfaceMember xlink:href="#poly-fee70d56-1aea-423c-a0dc-8b51204fa8d2"/>
							<gml:surfaceMember xlink:href="#poly-4f2501f7-db26-48a2-9dd5-4d07d342e11f"/>
							<gml:surfaceMember xlink:href="#poly-59483719-76a6-4bea-92ea-4d2060ac29d7"/>
							<gml:surfaceMember xlink:href="#poly-823848c7-d15a-4ac3-83c9-6de568af9d53"/>
							<gml:surfaceMember xlink:href="#poly-e6807a9f-44cd-42fd-b8dd-a47df5bda0bb"/>
							<gml:surfaceMember xlink:href="#poly-2a64fbbe-1152-4d0c-a426-847f9380a22a"/>
							<gml:surfaceMember xlink:href="#poly-dda80869-a623-476e-8851-b9fe773d84be"/>
							<gml:surfaceMember xlink:href="#poly-b60c493f-5fe1-4194-b0b1-a609a1912fb6"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-11343a3b-5445-437a-8575-db494e83b6ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11343a3b-5445-437a-8575-db494e83b6ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11343a3b-5445-437a-8575-db494e83b6ce">
											<gml:posList>35.67175944941219 139.74306128013794 8.1 35.671754885476425 139.74339455664673 8.1 35.6717451395231 139.74339172864268 8.1 35.6717411644142 139.74339165577695 8.1 35.67173772165119 139.7433923003331 8.1 35.67173405499731 139.74339488931489 8.1 35.671730964990545 139.74339716834908 8.1 35.67172752703744 139.74340425297714 8.1 35.67152983392835 139.74313378224858 8.1 35.671530530942135 139.74310163638745 8.1 35.67175944941219 139.74306128013794 8.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6a8291df-d6c1-4f23-ad87-5b3729499a03">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a8291df-d6c1-4f23-ad87-5b3729499a03">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a8291df-d6c1-4f23-ad87-5b3729499a03">
											<gml:posList>35.67168016204393 139.74308184950968 40.2 35.67167992124837 139.7431334035105 40.2 35.671730712385035 139.7431317667258 40.2 35.67173387485585 139.74306982574385 40.2 35.67168016204393 139.74308184950968 40.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-61cc08c8-61e5-4fce-80c8-37fc43b4f6aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61cc08c8-61e5-4fce-80c8-37fc43b4f6aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61cc08c8-61e5-4fce-80c8-37fc43b4f6aa">
											<gml:posList>35.67164103000425 139.7430892836245 41.45 35.67164201042135 139.74313462813072 41.45 35.67167992124837 139.7431334035105 41.45 35.67168016204393 139.74308184950968 41.45 35.67164103000425 139.7430892836245 41.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3b317aec-a6c0-4d14-a540-f19131ff2a42">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3b317aec-a6c0-4d14-a540-f19131ff2a42">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3b317aec-a6c0-4d14-a540-f19131ff2a42">
											<gml:posList>35.67164201042135 139.74313462813072 37.7 35.67164103000425 139.7430892836245 37.7 35.671530530942135 139.74310163638745 37.7 35.67152983392835 139.74313378224858 37.7 35.67164201042135 139.74313462813072 37.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f403bdd2-1a66-4122-bc29-287d6facfb75">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f403bdd2-1a66-4122-bc29-287d6facfb75">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f403bdd2-1a66-4122-bc29-287d6facfb75">
											<gml:posList>35.67174618341763 139.74317251071247 38.576 35.671721621026954 139.74317253833462 38.576 35.6717216546248 139.743217420001 38.576 35.67174622602922 139.74321739238246 38.576 35.67174618341763 139.74317251071247 38.576</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-702556ba-80ba-4b72-ad0b-3b76a38295f1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-702556ba-80ba-4b72-ad0b-3b76a38295f1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-702556ba-80ba-4b72-ad0b-3b76a38295f1">
											<gml:posList>35.6717216546248 139.743217420001 37.7 35.671721621026954 139.74317253833462 37.7 35.67170965746277 139.7432055254205 37.7 35.67170873291114 139.743270921401 37.7 35.6717216546248 139.743217420001 37.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-87fa50ac-20d4-4649-bff1-5450957e65c0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-87fa50ac-20d4-4649-bff1-5450957e65c0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-87fa50ac-20d4-4649-bff1-5450957e65c0">
											<gml:posList>35.67175944941219 139.74306128013794 37.7 35.67174618341763 139.74317251071247 37.7 35.67174622602922 139.74321739238246 37.7 35.671754885476425 139.74339455664673 37.7 35.67175944941219 139.74306128013794 37.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a4eb41f5-9089-4a2c-b58a-e5f13cc31fed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4eb41f5-9089-4a2c-b58a-e5f13cc31fed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4eb41f5-9089-4a2c-b58a-e5f13cc31fed">
											<gml:posList>35.67175944941219 139.74306128013794 37.7 35.671530530942135 139.74310163638745 37.7 35.67164103000425 139.7430892836245 37.7 35.67168016204393 139.74308184950968 37.7 35.67173387485585 139.74306982574385 37.7 35.671730712385035 139.7431317667258 37.7 35.67164201042135 139.74313462813072 37.7 35.67152983392835 139.74313378224858 37.7 35.67172752703744 139.74340425297714 37.7 35.671730964990545 139.74339716834908 37.7 35.67173405499731 139.74339488931489 37.7 35.67173772165119 139.7433923003331 37.7 35.6717411644142 139.74339165577695 37.7 35.6717451395231 139.74339172864268 37.7 35.671754885476425 139.74339455664673 37.7 35.67174622602922 139.74321739238246 37.7 35.6717216546248 139.743217420001 37.7 35.67170873291114 139.743270921401 37.7 35.6716906420748 139.74327054405134 37.7 35.67169156661797 139.74320513703918 37.7 35.67170965746277 139.7432055254205 37.7 35.671721621026954 139.74317253833462 37.7 35.67174618341763 139.74317251071247 37.7 35.67175944941219 139.74306128013794 37.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-97981d59-8eb4-4e70-914b-802ed15a4103">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-97981d59-8eb4-4e70-914b-802ed15a4103">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-97981d59-8eb4-4e70-914b-802ed15a4103">
											<gml:posList>35.67169156661797 139.74320513703918 39.326 35.6716906420748 139.74327054405134 39.326 35.67170873291114 139.743270921401 39.326 35.67170965746277 139.7432055254205 39.326 35.67169156661797 139.74320513703918 39.326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bf901497-de8e-4327-9c5f-4d2edbadc5e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf901497-de8e-4327-9c5f-4d2edbadc5e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf901497-de8e-4327-9c5f-4d2edbadc5e3">
											<gml:posList>35.6717451395231 139.74339172864268 37.7 35.6717411644142 139.74339165577695 37.7 35.6717411644142 139.74339165577695 8.1 35.6717451395231 139.74339172864268 8.1 35.6717451395231 139.74339172864268 37.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-001ce4c1-3597-4999-b5a2-9e2034c0ff76">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-001ce4c1-3597-4999-b5a2-9e2034c0ff76">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-001ce4c1-3597-4999-b5a2-9e2034c0ff76">
											<gml:posList>35.6717411644142 139.74339165577695 37.7 35.67173772165119 139.7433923003331 37.7 35.67173772165119 139.7433923003331 8.1 35.6717411644142 139.74339165577695 8.1 35.6717411644142 139.74339165577695 37.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e9502e34-8798-46b9-a3e0-e22eee12136c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e9502e34-8798-46b9-a3e0-e22eee12136c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e9502e34-8798-46b9-a3e0-e22eee12136c">
											<gml:posList>35.67173772165119 139.7433923003331 37.7 35.67173405499731 139.74339488931489 37.7 35.67173405499731 139.74339488931489 8.1 35.67173772165119 139.7433923003331 8.1 35.67173772165119 139.7433923003331 37.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8b4b135a-a5e1-4f90-b12f-c5e03495d642">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b4b135a-a5e1-4f90-b12f-c5e03495d642">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b4b135a-a5e1-4f90-b12f-c5e03495d642">
											<gml:posList>35.67173405499731 139.74339488931489 37.7 35.671730964990545 139.74339716834908 37.7 35.671730964990545 139.74339716834908 8.1 35.67173405499731 139.74339488931489 8.1 35.67173405499731 139.74339488931489 37.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ab231aa8-91a4-42d6-b0ce-9e14c2a2a24d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab231aa8-91a4-42d6-b0ce-9e14c2a2a24d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab231aa8-91a4-42d6-b0ce-9e14c2a2a24d">
											<gml:posList>35.671730964990545 139.74339716834908 37.7 35.67172752703744 139.74340425297714 37.7 35.67172752703744 139.74340425297714 8.1 35.671730964990545 139.74339716834908 8.1 35.671730964990545 139.74339716834908 37.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b6c6dcd9-2603-459f-bd41-91663cb3460d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6c6dcd9-2603-459f-bd41-91663cb3460d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6c6dcd9-2603-459f-bd41-91663cb3460d">
											<gml:posList>35.67173387485585 139.74306982574385 37.7 35.67168016204393 139.74308184950968 37.7 35.67168016204393 139.74308184950968 40.2 35.67173387485585 139.74306982574385 40.2 35.67173387485585 139.74306982574385 37.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-45d89c6c-2d47-4ba9-bcb5-d7e05957d683">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45d89c6c-2d47-4ba9-bcb5-d7e05957d683">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45d89c6c-2d47-4ba9-bcb5-d7e05957d683">
											<gml:posList>35.671530530942135 139.74310163638745 37.7 35.67175944941219 139.74306128013794 37.7 35.67175944941219 139.74306128013794 8.1 35.671530530942135 139.74310163638745 8.1 35.671530530942135 139.74310163638745 37.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4df51afd-5db9-463b-8aac-8becd4b64e77">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4df51afd-5db9-463b-8aac-8becd4b64e77">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4df51afd-5db9-463b-8aac-8becd4b64e77">
											<gml:posList>35.67164103000425 139.7430892836245 41.45 35.67168016204393 139.74308184950968 41.45 35.67168016204393 139.74308184950968 40.2 35.67168016204393 139.74308184950968 37.7 35.67164103000425 139.7430892836245 37.7 35.67164103000425 139.7430892836245 41.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5cb733da-8490-4919-a86a-cc92da4e3a28">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5cb733da-8490-4919-a86a-cc92da4e3a28">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5cb733da-8490-4919-a86a-cc92da4e3a28">
											<gml:posList>35.671730712385035 139.7431317667258 37.7 35.67173387485585 139.74306982574385 37.7 35.67173387485585 139.74306982574385 40.2 35.671730712385035 139.7431317667258 40.2 35.671730712385035 139.7431317667258 37.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e667e195-e90c-4f53-9af7-eade33b49601">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e667e195-e90c-4f53-9af7-eade33b49601">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e667e195-e90c-4f53-9af7-eade33b49601">
											<gml:posList>35.67167992124837 139.7431334035105 41.45 35.67167992124837 139.7431334035105 40.2 35.67168016204393 139.74308184950968 40.2 35.67168016204393 139.74308184950968 41.45 35.67167992124837 139.7431334035105 41.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-054578d3-d67c-49ef-8948-debb4e133d60">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-054578d3-d67c-49ef-8948-debb4e133d60">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-054578d3-d67c-49ef-8948-debb4e133d60">
											<gml:posList>35.67164103000425 139.7430892836245 37.7 35.67164201042135 139.74313462813072 37.7 35.67164201042135 139.74313462813072 41.45 35.67164103000425 139.7430892836245 41.45 35.67164103000425 139.7430892836245 37.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-83b00173-395a-4a81-8b1d-1d205fdf6982">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83b00173-395a-4a81-8b1d-1d205fdf6982">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83b00173-395a-4a81-8b1d-1d205fdf6982">
											<gml:posList>35.67152983392835 139.74313378224858 37.7 35.671530530942135 139.74310163638745 37.7 35.671530530942135 139.74310163638745 8.1 35.67152983392835 139.74313378224858 8.1 35.67152983392835 139.74313378224858 37.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c6607901-8416-4ac7-83d4-c45d16645f83">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6607901-8416-4ac7-83d4-c45d16645f83">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6607901-8416-4ac7-83d4-c45d16645f83">
											<gml:posList>35.67167992124837 139.7431334035105 41.45 35.67164201042135 139.74313462813072 41.45 35.67164201042135 139.74313462813072 37.7 35.671730712385035 139.7431317667258 37.7 35.671730712385035 139.7431317667258 40.2 35.67167992124837 139.7431334035105 40.2 35.67167992124837 139.7431334035105 41.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f0040413-82c7-40ec-a286-057a5d00e995">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f0040413-82c7-40ec-a286-057a5d00e995">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f0040413-82c7-40ec-a286-057a5d00e995">
											<gml:posList>35.67174618341763 139.74317251071247 37.7 35.671721621026954 139.74317253833462 37.7 35.671721621026954 139.74317253833462 38.576 35.67174618341763 139.74317251071247 38.576 35.67174618341763 139.74317251071247 37.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-df88fb3e-0b7a-43d0-8111-18a85771c659">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df88fb3e-0b7a-43d0-8111-18a85771c659">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df88fb3e-0b7a-43d0-8111-18a85771c659">
											<gml:posList>35.671721621026954 139.74317253833462 37.7 35.6717216546248 139.743217420001 37.7 35.6717216546248 139.743217420001 38.576 35.671721621026954 139.74317253833462 38.576 35.671721621026954 139.74317253833462 37.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b796cce5-3301-480c-806e-d2d4836044e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b796cce5-3301-480c-806e-d2d4836044e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b796cce5-3301-480c-806e-d2d4836044e6">
											<gml:posList>35.67174622602922 139.74321739238246 37.7 35.67174618341763 139.74317251071247 37.7 35.67174618341763 139.74317251071247 38.576 35.67174622602922 139.74321739238246 38.576 35.67174622602922 139.74321739238246 37.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fee70d56-1aea-423c-a0dc-8b51204fa8d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fee70d56-1aea-423c-a0dc-8b51204fa8d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fee70d56-1aea-423c-a0dc-8b51204fa8d2">
											<gml:posList>35.67170965746277 139.7432055254205 37.7 35.67169156661797 139.74320513703918 37.7 35.67169156661797 139.74320513703918 39.326 35.67170965746277 139.7432055254205 39.326 35.67170965746277 139.7432055254205 37.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4f2501f7-db26-48a2-9dd5-4d07d342e11f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f2501f7-db26-48a2-9dd5-4d07d342e11f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f2501f7-db26-48a2-9dd5-4d07d342e11f">
											<gml:posList>35.6717216546248 139.743217420001 37.7 35.67174622602922 139.74321739238246 37.7 35.67174622602922 139.74321739238246 38.576 35.6717216546248 139.743217420001 38.576 35.6717216546248 139.743217420001 37.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-59483719-76a6-4bea-92ea-4d2060ac29d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-59483719-76a6-4bea-92ea-4d2060ac29d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-59483719-76a6-4bea-92ea-4d2060ac29d7">
											<gml:posList>35.67175944941219 139.74306128013794 37.7 35.671754885476425 139.74339455664673 37.7 35.671754885476425 139.74339455664673 8.1 35.67175944941219 139.74306128013794 8.1 35.67175944941219 139.74306128013794 37.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-823848c7-d15a-4ac3-83c9-6de568af9d53">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-823848c7-d15a-4ac3-83c9-6de568af9d53">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-823848c7-d15a-4ac3-83c9-6de568af9d53">
											<gml:posList>35.67169156661797 139.74320513703918 37.7 35.6716906420748 139.74327054405134 37.7 35.6716906420748 139.74327054405134 39.326 35.67169156661797 139.74320513703918 39.326 35.67169156661797 139.74320513703918 37.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e6807a9f-44cd-42fd-b8dd-a47df5bda0bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e6807a9f-44cd-42fd-b8dd-a47df5bda0bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e6807a9f-44cd-42fd-b8dd-a47df5bda0bb">
											<gml:posList>35.67170873291114 139.743270921401 37.7 35.67170965746277 139.7432055254205 37.7 35.67170965746277 139.7432055254205 39.326 35.67170873291114 139.743270921401 39.326 35.67170873291114 139.743270921401 37.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2a64fbbe-1152-4d0c-a426-847f9380a22a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a64fbbe-1152-4d0c-a426-847f9380a22a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a64fbbe-1152-4d0c-a426-847f9380a22a">
											<gml:posList>35.67172752703744 139.74340425297714 37.7 35.67152983392835 139.74313378224858 37.7 35.67152983392835 139.74313378224858 8.1 35.67172752703744 139.74340425297714 8.1 35.67172752703744 139.74340425297714 37.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dda80869-a623-476e-8851-b9fe773d84be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dda80869-a623-476e-8851-b9fe773d84be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dda80869-a623-476e-8851-b9fe773d84be">
											<gml:posList>35.6716906420748 139.74327054405134 37.7 35.67170873291114 139.743270921401 37.7 35.67170873291114 139.743270921401 39.326 35.6716906420748 139.74327054405134 39.326 35.6716906420748 139.74327054405134 37.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b60c493f-5fe1-4194-b0b1-a609a1912fb6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b60c493f-5fe1-4194-b0b1-a609a1912fb6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b60c493f-5fe1-4194-b0b1-a609a1912fb6">
											<gml:posList>35.671754885476425 139.74339455664673 37.7 35.6717451395231 139.74339172864268 37.7 35.6717451395231 139.74339172864268 8.1 35.671754885476425 139.74339455664673 8.1 35.671754885476425 139.74339455664673 37.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都千代田区永田町二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4484</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">476.118</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.14</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>