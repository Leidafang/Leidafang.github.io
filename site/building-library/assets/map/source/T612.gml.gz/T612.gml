<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_b1c0bae6-cebe-4ee7-9a39-0b825d0b40bc">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門駅南地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">16.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.668195835721505 139.74910886785213 0 35.66815122620864 139.74924997153192 0 35.66820550697503 139.7492758726191 0 35.668250116517704 139.7491347688581 0 35.668195835721505 139.74910886785213 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668195835721505 139.74910886785213 5.268 35.668250116517704 139.7491347688581 5.268 35.66820550697503 139.7492758726191 5.268 35.66815122620864 139.74924997153192 5.268 35.668195835721505 139.74910886785213 5.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668195835721505 139.74910886785213 5.268 35.66815122620864 139.74924997153192 5.268 35.66815122620864 139.74924997153192 21.97 35.668195835721505 139.74910886785213 21.97 35.668195835721505 139.74910886785213 5.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66815122620864 139.74924997153192 5.268 35.66820550697503 139.7492758726191 5.268 35.66820550697503 139.7492758726191 21.97 35.66815122620864 139.74924997153192 21.97 35.66815122620864 139.74924997153192 5.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66820550697503 139.7492758726191 5.268 35.668250116517704 139.7491347688581 5.268 35.668250116517704 139.7491347688581 21.97 35.66820550697503 139.7492758726191 21.97 35.66820550697503 139.7492758726191 5.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668250116517704 139.7491347688581 5.268 35.668195835721505 139.74910886785213 5.268 35.668195835721505 139.74910886785213 21.97 35.668250116517704 139.7491347688581 21.97 35.668250116517704 139.7491347688581 5.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668195835721505 139.74910886785213 21.97 35.66815122620864 139.74924997153192 21.97 35.66820550697503 139.7492758726191 21.97 35.668250116517704 139.7491347688581 21.97 35.668195835721505 139.74910886785213 21.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-63014a16-af76-4c8c-b431-d8d25b5d3800"/>
							<gml:surfaceMember xlink:href="#poly-229ad181-15fd-45fa-ab6c-eecd45910721"/>
							<gml:surfaceMember xlink:href="#poly-8d7bfc11-9ea0-478d-9ecb-ca7b0da3426f"/>
							<gml:surfaceMember xlink:href="#poly-cfe42887-478e-43b7-882e-c6ddc1df8c10"/>
							<gml:surfaceMember xlink:href="#poly-d95224b7-3170-4532-973c-be353d0fd784"/>
							<gml:surfaceMember xlink:href="#poly-e4c6638b-6cc4-4766-a7b2-245e578a9a03"/>
							<gml:surfaceMember xlink:href="#poly-73554ae0-1553-4a11-9a4f-aca6742dfe93"/>
							<gml:surfaceMember xlink:href="#poly-c3c7ac13-67bc-4a58-a33d-354701307b82"/>
							<gml:surfaceMember xlink:href="#poly-18bd985f-5866-4adc-aaf6-872730bf116f"/>
							<gml:surfaceMember xlink:href="#poly-92466d9d-1328-4536-bf57-8d2371241f82"/>
							<gml:surfaceMember xlink:href="#poly-f8c86230-c447-4c9e-9d64-1c60f1906fac"/>
							<gml:surfaceMember xlink:href="#poly-70b23e45-55d4-40e0-8860-2c06839eba63"/>
							<gml:surfaceMember xlink:href="#poly-bc7fa823-985a-4ffc-8cb9-ee65332cfb50"/>
							<gml:surfaceMember xlink:href="#poly-d9a55c7f-8799-4e0b-8f54-75c5cb42964b"/>
							<gml:surfaceMember xlink:href="#poly-d9227edf-03ce-43f7-8adf-f90f3aca24b1"/>
							<gml:surfaceMember xlink:href="#poly-cd86a9a4-1ef5-4e2e-ba5c-2fb106bfbabe"/>
							<gml:surfaceMember xlink:href="#poly-53cb0c8e-1f0f-46a5-ba6a-ebb94aefb698"/>
							<gml:surfaceMember xlink:href="#poly-ce557961-1e38-49c9-a47d-c9b503a66855"/>
							<gml:surfaceMember xlink:href="#poly-c830538d-74ab-4ab3-a672-d68070650767"/>
							<gml:surfaceMember xlink:href="#poly-ed3c30f8-fd8d-4098-8a65-496326587c21"/>
							<gml:surfaceMember xlink:href="#poly-bcc0eef5-60e0-45e9-84e0-b963d54b67d0"/>
							<gml:surfaceMember xlink:href="#poly-3f2927a3-a4b6-459a-b889-97663132794b"/>
							<gml:surfaceMember xlink:href="#poly-558162c9-ea8e-4f09-8638-1815f1b9dc6d"/>
							<gml:surfaceMember xlink:href="#poly-3f6d4e19-d4dc-4658-b307-0c36b6556b69"/>
							<gml:surfaceMember xlink:href="#poly-4260380e-67a5-4880-b94c-112e21bc6a26"/>
							<gml:surfaceMember xlink:href="#poly-8ddf6cc3-9693-4d00-a098-f9f192b9f8ee"/>
							<gml:surfaceMember xlink:href="#poly-ed26921c-c367-4fcb-870f-9e3c51058401"/>
							<gml:surfaceMember xlink:href="#poly-cbad4197-550d-43c5-9d48-169a09fbc2aa"/>
							<gml:surfaceMember xlink:href="#poly-ab4ccfdc-0455-4f69-b872-2b9554b7e8dd"/>
							<gml:surfaceMember xlink:href="#poly-2c36fea4-a324-4332-93ac-9a847cafbe7f"/>
							<gml:surfaceMember xlink:href="#poly-e7056b70-e949-4911-bdcf-56c476973f11"/>
							<gml:surfaceMember xlink:href="#poly-c69267fc-27e8-4449-a4c3-06e2e4f7d670"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-63014a16-af76-4c8c-b431-d8d25b5d3800">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-63014a16-af76-4c8c-b431-d8d25b5d3800">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-63014a16-af76-4c8c-b431-d8d25b5d3800">
											<gml:posList>35.668195835721484 139.74910886785213 5.268 35.668250116517704 139.74913476885808 5.268 35.668205506975006 139.7492758726191 5.268 35.66815122620863 139.74924997153192 5.268 35.668195835721484 139.74910886785213 5.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-229ad181-15fd-45fa-ab6c-eecd45910721">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-229ad181-15fd-45fa-ab6c-eecd45910721">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-229ad181-15fd-45fa-ab6c-eecd45910721">
											<gml:posList>35.668195835721484 139.74910886785213 22.8 35.668196928507214 139.74911190434312 22.8 35.66824764769078 139.7491361080125 22.8 35.668250116517704 139.74913476885808 22.8 35.668195835721484 139.74910886785213 22.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8d7bfc11-9ea0-478d-9ecb-ca7b0da3426f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d7bfc11-9ea0-478d-9ecb-ca7b0da3426f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d7bfc11-9ea0-478d-9ecb-ca7b0da3426f">
											<gml:posList>35.668250116517704 139.74913476885808 22.8 35.66824764769078 139.7491361080125 22.8 35.668233869113195 139.74917968776504 22.8 35.66823496188168 139.74918270216654 22.8 35.668250116517704 139.74913476885808 22.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cfe42887-478e-43b7-882e-c6ddc1df8c10">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cfe42887-478e-43b7-882e-c6ddc1df8c10">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cfe42887-478e-43b7-882e-c6ddc1df8c10">
											<gml:posList>35.66819863348943 139.7491654533651 24.699 35.66819964499577 139.7491682690231 24.699 35.66823265523186 139.74918394173534 24.699 35.66823496188168 139.74918270216654 24.699 35.66819863348943 139.7491654533651 24.699</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d95224b7-3170-4532-973c-be353d0fd784">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d95224b7-3170-4532-973c-be353d0fd784">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d95224b7-3170-4532-973c-be353d0fd784">
											<gml:posList>35.66815122620863 139.74924997153192 22.8 35.668153704058305 139.74924864341915 22.8 35.668196928507214 139.74911190434312 22.8 35.668195835721484 139.74910886785213 22.8 35.66815122620863 139.74924997153192 22.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e4c6638b-6cc4-4766-a7b2-245e578a9a03">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e4c6638b-6cc4-4766-a7b2-245e578a9a03">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e4c6638b-6cc4-4766-a7b2-245e578a9a03">
											<gml:posList>35.668233176569146 139.74918185350091 22.8 35.66823496188168 139.74918270216654 22.8 35.668233869113195 139.74917968776504 22.8 35.668233176569146 139.74918185350091 22.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-73554ae0-1553-4a11-9a4f-aca6742dfe93">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73554ae0-1553-4a11-9a4f-aca6742dfe93">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73554ae0-1553-4a11-9a4f-aca6742dfe93">
											<gml:posList>35.66820646482003 139.74926638313465 22.525 35.668207148336464 139.74926419531778 22.525 35.66817259625405 139.7492477951612 22.525 35.66819863348943 139.7491654533651 22.525 35.668233176569146 139.74918185350091 22.525 35.668233869113195 139.74917968776504 22.525 35.66824764769078 139.7491361080125 22.525 35.668196928507214 139.74911190434312 22.525 35.668153704058305 139.74924864341915 22.525 35.66820442321486 139.74927284716205 22.525 35.66820646482003 139.74926638313465 22.525</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c3c7ac13-67bc-4a58-a33d-354701307b82">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3c7ac13-67bc-4a58-a33d-354701307b82">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3c7ac13-67bc-4a58-a33d-354701307b82">
											<gml:posList>35.66817259625405 139.7492477951612 24.699 35.66817489388311 139.7492465445587 24.699 35.66819964499577 139.7491682690231 24.699 35.66819863348943 139.7491654533651 24.699 35.66817259625405 139.7492477951612 24.699</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-18bd985f-5866-4adc-aaf6-872730bf116f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18bd985f-5866-4adc-aaf6-872730bf116f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18bd985f-5866-4adc-aaf6-872730bf116f">
											<gml:posList>35.66823265523186 139.74918394173534 24.374 35.66819964499577 139.7491682690231 24.374 35.66817489388311 139.7492465445587 24.374 35.66820791312292 139.74926221728893 24.374 35.66823265523186 139.74918394173534 24.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-92466d9d-1328-4536-bf57-8d2371241f82">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-92466d9d-1328-4536-bf57-8d2371241f82">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-92466d9d-1328-4536-bf57-8d2371241f82">
											<gml:posList>35.66823496188168 139.74918270216654 24.699 35.66823265523186 139.74918394173534 24.699 35.66820791312292 139.74926221728893 24.699 35.66820893364843 139.74926504398496 24.699 35.66823496188168 139.74918270216654 24.699</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f8c86230-c447-4c9e-9d64-1c60f1906fac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f8c86230-c447-4c9e-9d64-1c60f1906fac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f8c86230-c447-4c9e-9d64-1c60f1906fac">
											<gml:posList>35.66820893364843 139.74926504398496 24.699 35.66820791312292 139.74926221728893 24.699 35.66817489388311 139.7492465445587 24.699 35.66817259625405 139.7492477951612 24.699 35.66820893364843 139.74926504398496 24.699</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-70b23e45-55d4-40e0-8860-2c06839eba63">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70b23e45-55d4-40e0-8860-2c06839eba63">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70b23e45-55d4-40e0-8860-2c06839eba63">
											<gml:posList>35.668205506975006 139.7492758726191 22.8 35.66820442321486 139.74927284716205 22.8 35.668153704058305 139.74924864341915 22.8 35.66815122620863 139.74924997153192 22.8 35.668205506975006 139.7492758726191 22.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bc7fa823-985a-4ffc-8cb9-ee65332cfb50">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc7fa823-985a-4ffc-8cb9-ee65332cfb50">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc7fa823-985a-4ffc-8cb9-ee65332cfb50">
											<gml:posList>35.66820646482003 139.74926638313465 22.8 35.66820893364843 139.74926504398496 22.8 35.668207148336464 139.74926419531778 22.8 35.66820646482003 139.74926638313465 22.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d9a55c7f-8799-4e0b-8f54-75c5cb42964b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d9a55c7f-8799-4e0b-8f54-75c5cb42964b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d9a55c7f-8799-4e0b-8f54-75c5cb42964b">
											<gml:posList>35.66820893364843 139.74926504398496 22.8 35.66820646482003 139.74926638313465 22.8 35.66820442321486 139.74927284716205 22.8 35.668205506975006 139.7492758726191 22.8 35.66820893364843 139.74926504398496 22.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d9227edf-03ce-43f7-8adf-f90f3aca24b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d9227edf-03ce-43f7-8adf-f90f3aca24b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d9227edf-03ce-43f7-8adf-f90f3aca24b1">
											<gml:posList>35.668195835721484 139.74910886785213 5.268 35.66815122620863 139.74924997153192 5.268 35.66815122620863 139.74924997153192 22.8 35.668195835721484 139.74910886785213 22.8 35.668195835721484 139.74910886785213 5.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cd86a9a4-1ef5-4e2e-ba5c-2fb106bfbabe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd86a9a4-1ef5-4e2e-ba5c-2fb106bfbabe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd86a9a4-1ef5-4e2e-ba5c-2fb106bfbabe">
											<gml:posList>35.668153704058305 139.74924864341915 22.8 35.668153704058305 139.74924864341915 22.525 35.668196928507214 139.74911190434312 22.525 35.668196928507214 139.74911190434312 22.8 35.668153704058305 139.74924864341915 22.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-53cb0c8e-1f0f-46a5-ba6a-ebb94aefb698">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-53cb0c8e-1f0f-46a5-ba6a-ebb94aefb698">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-53cb0c8e-1f0f-46a5-ba6a-ebb94aefb698">
											<gml:posList>35.66815122620863 139.74924997153192 5.268 35.668205506975006 139.7492758726191 5.268 35.668205506975006 139.7492758726191 22.8 35.66815122620863 139.74924997153192 22.8 35.66815122620863 139.74924997153192 5.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ce557961-1e38-49c9-a47d-c9b503a66855">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce557961-1e38-49c9-a47d-c9b503a66855">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce557961-1e38-49c9-a47d-c9b503a66855">
											<gml:posList>35.66820442321486 139.74927284716205 22.8 35.66820442321486 139.74927284716205 22.525 35.668153704058305 139.74924864341915 22.525 35.668153704058305 139.74924864341915 22.8 35.66820442321486 139.74927284716205 22.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c830538d-74ab-4ab3-a672-d68070650767">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c830538d-74ab-4ab3-a672-d68070650767">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c830538d-74ab-4ab3-a672-d68070650767">
											<gml:posList>35.66817259625405 139.7492477951612 24.699 35.66819863348943 139.7491654533651 24.699 35.66819863348943 139.7491654533651 22.525 35.66817259625405 139.7492477951612 22.525 35.66817259625405 139.7492477951612 24.699</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ed3c30f8-fd8d-4098-8a65-496326587c21">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed3c30f8-fd8d-4098-8a65-496326587c21">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed3c30f8-fd8d-4098-8a65-496326587c21">
											<gml:posList>35.66817489388311 139.7492465445587 24.699 35.66817489388311 139.7492465445587 24.374 35.66819964499577 139.7491682690231 24.374 35.66819964499577 139.7491682690231 24.699 35.66817489388311 139.7492465445587 24.699</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bcc0eef5-60e0-45e9-84e0-b963d54b67d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bcc0eef5-60e0-45e9-84e0-b963d54b67d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bcc0eef5-60e0-45e9-84e0-b963d54b67d0">
											<gml:posList>35.66820893364843 139.74926504398496 24.699 35.66817259625405 139.7492477951612 24.699 35.66817259625405 139.7492477951612 22.525 35.668207148336464 139.74926419531778 22.525 35.668207148336464 139.74926419531778 22.8 35.66820893364843 139.74926504398496 22.8 35.66820893364843 139.74926504398496 24.699</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3f2927a3-a4b6-459a-b889-97663132794b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f2927a3-a4b6-459a-b889-97663132794b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f2927a3-a4b6-459a-b889-97663132794b">
											<gml:posList>35.66820791312292 139.74926221728893 24.699 35.66820791312292 139.74926221728893 24.374 35.66817489388311 139.7492465445587 24.374 35.66817489388311 139.7492465445587 24.699 35.66820791312292 139.74926221728893 24.699</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-558162c9-ea8e-4f09-8638-1815f1b9dc6d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-558162c9-ea8e-4f09-8638-1815f1b9dc6d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-558162c9-ea8e-4f09-8638-1815f1b9dc6d">
											<gml:posList>35.66820646482003 139.74926638313465 22.8 35.66820646482003 139.74926638313465 22.525 35.66820442321486 139.74927284716205 22.525 35.66820442321486 139.74927284716205 22.8 35.66820646482003 139.74926638313465 22.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3f6d4e19-d4dc-4658-b307-0c36b6556b69">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f6d4e19-d4dc-4658-b307-0c36b6556b69">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f6d4e19-d4dc-4658-b307-0c36b6556b69">
											<gml:posList>35.668207148336464 139.74926419531778 22.8 35.668207148336464 139.74926419531778 22.525 35.66820646482003 139.74926638313465 22.525 35.66820646482003 139.74926638313465 22.8 35.668207148336464 139.74926419531778 22.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4260380e-67a5-4880-b94c-112e21bc6a26">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4260380e-67a5-4880-b94c-112e21bc6a26">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4260380e-67a5-4880-b94c-112e21bc6a26">
											<gml:posList>35.66819964499577 139.7491682690231 24.699 35.66819964499577 139.7491682690231 24.374 35.66823265523186 139.74918394173534 24.374 35.66823265523186 139.74918394173534 24.699 35.66819964499577 139.7491682690231 24.699</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8ddf6cc3-9693-4d00-a098-f9f192b9f8ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ddf6cc3-9693-4d00-a098-f9f192b9f8ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ddf6cc3-9693-4d00-a098-f9f192b9f8ee">
											<gml:posList>35.66819863348943 139.7491654533651 22.525 35.66819863348943 139.7491654533651 24.699 35.66823496188168 139.74918270216654 24.699 35.66823496188168 139.74918270216654 22.8 35.668233176569146 139.74918185350091 22.8 35.668233176569146 139.74918185350091 22.525 35.66819863348943 139.7491654533651 22.525</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ed26921c-c367-4fcb-870f-9e3c51058401">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed26921c-c367-4fcb-870f-9e3c51058401">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed26921c-c367-4fcb-870f-9e3c51058401">
											<gml:posList>35.66823265523186 139.74918394173534 24.699 35.66823265523186 139.74918394173534 24.374 35.66820791312292 139.74926221728893 24.374 35.66820791312292 139.74926221728893 24.699 35.66823265523186 139.74918394173534 24.699</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cbad4197-550d-43c5-9d48-169a09fbc2aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cbad4197-550d-43c5-9d48-169a09fbc2aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cbad4197-550d-43c5-9d48-169a09fbc2aa">
											<gml:posList>35.668196928507214 139.74911190434312 22.8 35.668196928507214 139.74911190434312 22.525 35.66824764769078 139.7491361080125 22.525 35.66824764769078 139.7491361080125 22.8 35.668196928507214 139.74911190434312 22.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ab4ccfdc-0455-4f69-b872-2b9554b7e8dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab4ccfdc-0455-4f69-b872-2b9554b7e8dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab4ccfdc-0455-4f69-b872-2b9554b7e8dd">
											<gml:posList>35.668250116517704 139.74913476885808 5.268 35.668195835721484 139.74910886785213 5.268 35.668195835721484 139.74910886785213 22.8 35.668250116517704 139.74913476885808 22.8 35.668250116517704 139.74913476885808 5.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2c36fea4-a324-4332-93ac-9a847cafbe7f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c36fea4-a324-4332-93ac-9a847cafbe7f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c36fea4-a324-4332-93ac-9a847cafbe7f">
											<gml:posList>35.66823496188168 139.74918270216654 22.8 35.66823496188168 139.74918270216654 24.699 35.66820893364843 139.74926504398496 24.699 35.66820893364843 139.74926504398496 22.8 35.668205506975006 139.7492758726191 22.8 35.668205506975006 139.7492758726191 5.268 35.668250116517704 139.74913476885808 5.268 35.668250116517704 139.74913476885808 22.8 35.66823496188168 139.74918270216654 22.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e7056b70-e949-4911-bdcf-56c476973f11">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e7056b70-e949-4911-bdcf-56c476973f11">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e7056b70-e949-4911-bdcf-56c476973f11">
											<gml:posList>35.668233869113195 139.74917968776504 22.8 35.668233869113195 139.74917968776504 22.525 35.668233176569146 139.74918185350091 22.525 35.668233176569146 139.74918185350091 22.8 35.668233869113195 139.74917968776504 22.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c69267fc-27e8-4449-a4c3-06e2e4f7d670">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c69267fc-27e8-4449-a4c3-06e2e4f7d670">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c69267fc-27e8-4449-a4c3-06e2e4f7d670">
											<gml:posList>35.66824764769078 139.7491361080125 22.8 35.66824764769078 139.7491361080125 22.525 35.668233869113195 139.74917968776504 22.525 35.668233869113195 139.74917968776504 22.8 35.66824764769078 139.7491361080125 22.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1362</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">88.5314</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.1</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>