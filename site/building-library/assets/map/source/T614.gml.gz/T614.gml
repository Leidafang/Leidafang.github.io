<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_b23b4990-b8de-4c5a-941b-9722be60be4d">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">411</bldg:usage>
			<bldg:measuredHeight uom="m">7.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67121853459903 139.7400329068593 0 35.671274255917304 139.74008907914956 0 35.67132211767301 139.74001778532195 0 35.67132670925243 139.74002241946152 0 35.67133813448071 139.7400053947216 0 35.67127781252803 139.73994458832263 0 35.67121853459903 139.7400329068593 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67121853459903 139.7400329068593 14.06 35.67127781252803 139.73994458832263 14.06 35.67133813448071 139.7400053947216 14.06 35.67132670925243 139.74002241946152 14.06 35.67132211767301 139.74001778532195 14.06 35.671274255917304 139.74008907914956 14.06 35.67121853459903 139.7400329068593 14.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67121853459903 139.7400329068593 14.06 35.671274255917304 139.74008907914956 14.06 35.671274255917304 139.74008907914956 21.27 35.67121853459903 139.7400329068593 21.27 35.67121853459903 139.7400329068593 14.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671274255917304 139.74008907914956 14.06 35.67132211767301 139.74001778532195 14.06 35.67132211767301 139.74001778532195 21.27 35.671274255917304 139.74008907914956 21.27 35.671274255917304 139.74008907914956 14.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67132211767301 139.74001778532195 14.06 35.67132670925243 139.74002241946152 14.06 35.67132670925243 139.74002241946152 21.27 35.67132211767301 139.74001778532195 21.27 35.67132211767301 139.74001778532195 14.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67132670925243 139.74002241946152 14.06 35.67133813448071 139.7400053947216 14.06 35.67133813448071 139.7400053947216 21.27 35.67132670925243 139.74002241946152 21.27 35.67132670925243 139.74002241946152 14.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67133813448071 139.7400053947216 14.06 35.67127781252803 139.73994458832263 14.06 35.67127781252803 139.73994458832263 21.27 35.67133813448071 139.7400053947216 21.27 35.67133813448071 139.7400053947216 14.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67127781252803 139.73994458832263 14.06 35.67121853459903 139.7400329068593 14.06 35.67121853459903 139.7400329068593 21.27 35.67127781252803 139.73994458832263 21.27 35.67127781252803 139.73994458832263 14.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67121853459903 139.7400329068593 21.27 35.671274255917304 139.74008907914956 21.27 35.67132211767301 139.74001778532195 21.27 35.67132670925243 139.74002241946152 21.27 35.67133813448071 139.7400053947216 21.27 35.67127781252803 139.73994458832263 21.27 35.67121853459903 139.7400329068593 21.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-8dbbd8c6-e3b9-408a-9f5e-93624d940423"/>
							<gml:surfaceMember xlink:href="#poly-271de142-9517-4292-835e-8dcf59ea9f7c"/>
							<gml:surfaceMember xlink:href="#poly-690a30a4-4021-437c-8766-9451ee318598"/>
							<gml:surfaceMember xlink:href="#poly-9fd06a1b-db58-4c67-906b-585dadcc704f"/>
							<gml:surfaceMember xlink:href="#poly-cd114b4b-3450-47ef-815e-190cc96e45a0"/>
							<gml:surfaceMember xlink:href="#poly-d9362ec2-96aa-4377-8ac5-a9988f221030"/>
							<gml:surfaceMember xlink:href="#poly-82fdea13-2ea6-4b51-bcc5-da1718b7847d"/>
							<gml:surfaceMember xlink:href="#poly-1c11dd1a-e029-4e18-af82-4aacd826e603"/>
							<gml:surfaceMember xlink:href="#poly-6d40cde9-8ae5-4fbc-871a-f8bd3b7958f4"/>
							<gml:surfaceMember xlink:href="#poly-68e15340-a6c9-43c5-8008-75e81439a63e"/>
							<gml:surfaceMember xlink:href="#poly-3285e7c2-1cc9-4bce-bc40-7a8890edc257"/>
							<gml:surfaceMember xlink:href="#poly-08c86753-746c-4547-9bea-48bca179ae7b"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-8dbbd8c6-e3b9-408a-9f5e-93624d940423">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8dbbd8c6-e3b9-408a-9f5e-93624d940423">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8dbbd8c6-e3b9-408a-9f5e-93624d940423">
											<gml:posList>35.67127781252802 139.73994458832263 14.06 35.67133813448069 139.7400053947216 14.06 35.67132670925243 139.74002241946152 14.06 35.671322117673 139.74001778532195 14.06 35.671274255917275 139.74008907914956 14.06 35.67121853459903 139.74003290685934 14.06 35.67127781252802 139.73994458832263 14.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-271de142-9517-4292-835e-8dcf59ea9f7c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-271de142-9517-4292-835e-8dcf59ea9f7c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-271de142-9517-4292-835e-8dcf59ea9f7c">
											<gml:posList>35.671278168906824 139.7399740817504 21.197 35.67123112760497 139.74004560658423 21.197 35.67125268725626 139.7400673428663 23.014 35.67130014328764 139.73999592800703 23.014 35.671278168906824 139.7399740817504 21.197</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-690a30a4-4021-437c-8766-9451ee318598">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-690a30a4-4021-437c-8766-9451ee318598">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-690a30a4-4021-437c-8766-9451ee318598">
											<gml:posList>35.67127781252802 139.73994458832263 18.639 35.67121853459903 139.74003290685934 18.639 35.67123112760497 139.74004560658423 18.639 35.671278168906824 139.7399740817504 18.639 35.671322117673 139.74001778532195 18.639 35.67132670925243 139.74002241946152 18.639 35.67133813448069 139.7400053947216 18.639 35.67127781252802 139.73994458832263 18.639</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9fd06a1b-db58-4c67-906b-585dadcc704f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9fd06a1b-db58-4c67-906b-585dadcc704f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9fd06a1b-db58-4c67-906b-585dadcc704f">
											<gml:posList>35.671274255917275 139.74008907914956 21.197 35.671322117673 139.74001778532195 21.197 35.67130014328764 139.73999592800703 23.014 35.67125268725626 139.7400673428663 23.014 35.671274255917275 139.74008907914956 21.197</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cd114b4b-3450-47ef-815e-190cc96e45a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd114b4b-3450-47ef-815e-190cc96e45a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd114b4b-3450-47ef-815e-190cc96e45a0">
											<gml:posList>35.67133813448069 139.7400053947216 14.06 35.67127781252802 139.73994458832263 14.06 35.67127781252802 139.73994458832263 18.639 35.67133813448069 139.7400053947216 18.639 35.67133813448069 139.7400053947216 14.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d9362ec2-96aa-4377-8ac5-a9988f221030">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d9362ec2-96aa-4377-8ac5-a9988f221030">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d9362ec2-96aa-4377-8ac5-a9988f221030">
											<gml:posList>35.67127781252802 139.73994458832263 14.06 35.67121853459903 139.74003290685934 14.06 35.67121853459903 139.74003290685934 18.639 35.67127781252802 139.73994458832263 18.639 35.67127781252802 139.73994458832263 14.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-82fdea13-2ea6-4b51-bcc5-da1718b7847d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-82fdea13-2ea6-4b51-bcc5-da1718b7847d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-82fdea13-2ea6-4b51-bcc5-da1718b7847d">
											<gml:posList>35.671278168906824 139.7399740817504 18.639 35.671278168906824 139.7399740817504 21.197 35.67130014328764 139.73999592800703 23.014 35.671322117673 139.74001778532195 21.197 35.671322117673 139.74001778532195 18.639 35.671278168906824 139.7399740817504 18.639</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1c11dd1a-e029-4e18-af82-4aacd826e603">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c11dd1a-e029-4e18-af82-4aacd826e603">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c11dd1a-e029-4e18-af82-4aacd826e603">
											<gml:posList>35.67123112760497 139.74004560658423 18.639 35.67123112760497 139.74004560658423 21.197 35.671278168906824 139.7399740817504 21.197 35.671278168906824 139.7399740817504 18.639 35.67123112760497 139.74004560658423 18.639</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6d40cde9-8ae5-4fbc-871a-f8bd3b7958f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d40cde9-8ae5-4fbc-871a-f8bd3b7958f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d40cde9-8ae5-4fbc-871a-f8bd3b7958f4">
											<gml:posList>35.67132670925243 139.74002241946152 14.06 35.67133813448069 139.7400053947216 14.06 35.67133813448069 139.7400053947216 18.639 35.67132670925243 139.74002241946152 18.639 35.67132670925243 139.74002241946152 14.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-68e15340-a6c9-43c5-8008-75e81439a63e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-68e15340-a6c9-43c5-8008-75e81439a63e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-68e15340-a6c9-43c5-8008-75e81439a63e">
											<gml:posList>35.671322117673 139.74001778532195 14.06 35.67132670925243 139.74002241946152 14.06 35.67132670925243 139.74002241946152 18.639 35.671322117673 139.74001778532195 18.639 35.671322117673 139.74001778532195 14.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3285e7c2-1cc9-4bce-bc40-7a8890edc257">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3285e7c2-1cc9-4bce-bc40-7a8890edc257">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3285e7c2-1cc9-4bce-bc40-7a8890edc257">
											<gml:posList>35.671274255917275 139.74008907914956 21.197 35.671274255917275 139.74008907914956 14.06 35.671322117673 139.74001778532195 14.06 35.671322117673 139.74001778532195 18.639 35.671322117673 139.74001778532195 21.197 35.671274255917275 139.74008907914956 21.197</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-08c86753-746c-4547-9bea-48bca179ae7b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-08c86753-746c-4547-9bea-48bca179ae7b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-08c86753-746c-4547-9bea-48bca179ae7b">
											<gml:posList>35.67125268725626 139.7400673428663 23.014 35.67123112760497 139.74004560658423 21.197 35.67123112760497 139.74004560658423 18.639 35.67121853459903 139.74003290685934 18.639 35.67121853459903 139.74003290685934 14.06 35.671274255917275 139.74008907914956 14.06 35.671274255917275 139.74008907914956 21.197 35.67125268725626 139.7400673428663 23.014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10905</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">59.7901</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1310</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.05</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>