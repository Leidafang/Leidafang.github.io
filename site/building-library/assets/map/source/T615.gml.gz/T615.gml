<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_b25b9395-d129-43c7-8f49-ae99bacb002a">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3003</bldg:class>
			<bldg:measuredHeight uom="m">4.2</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.6708576611538 139.74616774901858 0 35.670955841547745 139.74619658368792 0 35.67096778573893 139.74613570536806 0 35.670869605330694 139.74610687076904 0 35.6708576611538 139.74616774901858 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6708576611538 139.74616774901858 8.82 35.670869605330694 139.74610687076904 8.82 35.67096778573893 139.74613570536806 8.82 35.670955841547745 139.74619658368792 8.82 35.6708576611538 139.74616774901858 8.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6708576611538 139.74616774901858 8.82 35.670955841547745 139.74619658368792 8.82 35.670955841547745 139.74619658368792 13.01 35.6708576611538 139.74616774901858 13.01 35.6708576611538 139.74616774901858 8.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670955841547745 139.74619658368792 8.82 35.67096778573893 139.74613570536806 8.82 35.67096778573893 139.74613570536806 13.01 35.670955841547745 139.74619658368792 13.01 35.670955841547745 139.74619658368792 8.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67096778573893 139.74613570536806 8.82 35.670869605330694 139.74610687076904 8.82 35.670869605330694 139.74610687076904 13.01 35.67096778573893 139.74613570536806 13.01 35.67096778573893 139.74613570536806 8.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670869605330694 139.74610687076904 8.82 35.6708576611538 139.74616774901858 8.82 35.6708576611538 139.74616774901858 13.01 35.670869605330694 139.74610687076904 13.01 35.670869605330694 139.74610687076904 8.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6708576611538 139.74616774901858 13.01 35.670955841547745 139.74619658368792 13.01 35.67096778573893 139.74613570536806 13.01 35.670869605330694 139.74610687076904 13.01 35.6708576611538 139.74616774901858 13.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-92f17b54-6873-46f1-b697-ea1fa9637274"/>
							<gml:surfaceMember xlink:href="#poly-f72fcee3-7f5f-44d2-955b-29a251805e6f"/>
							<gml:surfaceMember xlink:href="#poly-d9950108-d1f3-4bea-a03a-2ede4cf06cf2"/>
							<gml:surfaceMember xlink:href="#poly-979a25b6-8a0a-4cce-8c0a-e4a42e15decb"/>
							<gml:surfaceMember xlink:href="#poly-85c218b9-2c17-44f2-a753-b7a5e012ee81"/>
							<gml:surfaceMember xlink:href="#poly-5db84b12-287d-4a48-8a69-1dd97977f3e0"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-92f17b54-6873-46f1-b697-ea1fa9637274">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-92f17b54-6873-46f1-b697-ea1fa9637274">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-92f17b54-6873-46f1-b697-ea1fa9637274">
											<gml:posList>35.67085766115379 139.74616774901858 8.82 35.67086960533068 139.746106870769 8.82 35.670967785738924 139.74613570536803 8.82 35.670955841547745 139.74619658368792 8.82 35.67085766115379 139.74616774901858 8.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f72fcee3-7f5f-44d2-955b-29a251805e6f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f72fcee3-7f5f-44d2-955b-29a251805e6f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f72fcee3-7f5f-44d2-955b-29a251805e6f">
											<gml:posList>35.67086960533068 139.746106870769 13.1 35.67085766115379 139.74616774901858 13.1 35.670955841547745 139.74619658368792 13.1 35.670967785738924 139.74613570536803 13.1 35.67086960533068 139.746106870769 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d9950108-d1f3-4bea-a03a-2ede4cf06cf2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d9950108-d1f3-4bea-a03a-2ede4cf06cf2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d9950108-d1f3-4bea-a03a-2ede4cf06cf2">
											<gml:posList>35.670967785738924 139.74613570536803 8.82 35.67086960533068 139.746106870769 8.82 35.67086960533068 139.746106870769 13.1 35.670967785738924 139.74613570536803 13.1 35.670967785738924 139.74613570536803 8.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-979a25b6-8a0a-4cce-8c0a-e4a42e15decb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-979a25b6-8a0a-4cce-8c0a-e4a42e15decb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-979a25b6-8a0a-4cce-8c0a-e4a42e15decb">
											<gml:posList>35.67086960533068 139.746106870769 8.82 35.67085766115379 139.74616774901858 8.82 35.67085766115379 139.74616774901858 13.1 35.67086960533068 139.746106870769 13.1 35.67086960533068 139.746106870769 8.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-85c218b9-2c17-44f2-a753-b7a5e012ee81">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85c218b9-2c17-44f2-a753-b7a5e012ee81">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85c218b9-2c17-44f2-a753-b7a5e012ee81">
											<gml:posList>35.670955841547745 139.74619658368792 8.82 35.670967785738924 139.74613570536803 8.82 35.670967785738924 139.74613570536803 13.1 35.670955841547745 139.74619658368792 13.1 35.670955841547745 139.74619658368792 8.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5db84b12-287d-4a48-8a69-1dd97977f3e0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5db84b12-287d-4a48-8a69-1dd97977f3e0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5db84b12-287d-4a48-8a69-1dd97977f3e0">
											<gml:posList>35.67085766115379 139.74616774901858 8.82 35.670955841547745 139.74619658368792 8.82 35.670955841547745 139.74619658368792 13.1 35.67085766115379 139.74616774901858 13.1 35.67085766115379 139.74616774901858 8.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4387</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>