<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_b2a39124-13f1-43cb-9e50-536a12737e8f">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">4.9</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66898821543004 139.74112429095857 0 35.66897472118589 139.74114693986598 0 35.66903357609277 139.7411995951105 0 35.66904707033821 139.74117693514918 0 35.66898821543004 139.74112429095857 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66898821543004 139.74112429095857 10.29 35.66904707033821 139.74117693514918 10.29 35.66903357609277 139.7411995951105 10.29 35.66897472118589 139.74114693986598 10.29 35.66898821543004 139.74112429095857 10.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66898821543004 139.74112429095857 10.29 35.66897472118589 139.74114693986598 10.29 35.66897472118589 139.74114693986598 15.15 35.66898821543004 139.74112429095857 15.15 35.66898821543004 139.74112429095857 10.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66897472118589 139.74114693986598 10.29 35.66903357609277 139.7411995951105 10.29 35.66903357609277 139.7411995951105 15.15 35.66897472118589 139.74114693986598 15.15 35.66897472118589 139.74114693986598 10.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66903357609277 139.7411995951105 10.29 35.66904707033821 139.74117693514918 10.29 35.66904707033821 139.74117693514918 15.15 35.66903357609277 139.7411995951105 15.15 35.66903357609277 139.7411995951105 10.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66904707033821 139.74117693514918 10.29 35.66898821543004 139.74112429095857 10.29 35.66898821543004 139.74112429095857 15.15 35.66904707033821 139.74117693514918 15.15 35.66904707033821 139.74117693514918 10.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66898821543004 139.74112429095857 15.15 35.66897472118589 139.74114693986598 15.15 35.66903357609277 139.7411995951105 15.15 35.66904707033821 139.74117693514918 15.15 35.66898821543004 139.74112429095857 15.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-298e9672-2e40-4f53-89c8-96cb53ba8b6f"/>
							<gml:surfaceMember xlink:href="#poly-8c7e57ff-2fc4-4895-8953-6db8f5ad7142"/>
							<gml:surfaceMember xlink:href="#poly-65143ee2-5047-42be-a3fd-12600e6ef854"/>
							<gml:surfaceMember xlink:href="#poly-eb960996-3f76-4a6c-8486-8a20fc7dccc4"/>
							<gml:surfaceMember xlink:href="#poly-de470759-c970-4063-8ae0-7d6cd821f3e9"/>
							<gml:surfaceMember xlink:href="#poly-76e15357-d06a-4a08-a3eb-a22ba58bd5b0"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-298e9672-2e40-4f53-89c8-96cb53ba8b6f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-298e9672-2e40-4f53-89c8-96cb53ba8b6f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-298e9672-2e40-4f53-89c8-96cb53ba8b6f">
											<gml:posList>35.66898821543003 139.74112429095857 10.29 35.66904707033818 139.74117693514918 10.29 35.66903357609274 139.74119959511046 10.29 35.668974721185904 139.74114693986596 10.29 35.66898821543003 139.74112429095857 10.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8c7e57ff-2fc4-4895-8953-6db8f5ad7142">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c7e57ff-2fc4-4895-8953-6db8f5ad7142">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c7e57ff-2fc4-4895-8953-6db8f5ad7142">
											<gml:posList>35.66904707033818 139.74117693514918 14.916 35.66898821543003 139.74112429095857 14.916 35.668974721185904 139.74114693986596 14.916 35.66903357609274 139.74119959511046 14.916 35.66904707033818 139.74117693514918 14.916</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-65143ee2-5047-42be-a3fd-12600e6ef854">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65143ee2-5047-42be-a3fd-12600e6ef854">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65143ee2-5047-42be-a3fd-12600e6ef854">
											<gml:posList>35.668974721185904 139.74114693986596 10.29 35.66903357609274 139.74119959511046 10.29 35.66903357609274 139.74119959511046 14.916 35.668974721185904 139.74114693986596 14.916 35.668974721185904 139.74114693986596 10.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eb960996-3f76-4a6c-8486-8a20fc7dccc4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eb960996-3f76-4a6c-8486-8a20fc7dccc4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eb960996-3f76-4a6c-8486-8a20fc7dccc4">
											<gml:posList>35.66898821543003 139.74112429095857 10.29 35.668974721185904 139.74114693986596 10.29 35.668974721185904 139.74114693986596 14.916 35.66898821543003 139.74112429095857 14.916 35.66898821543003 139.74112429095857 10.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-de470759-c970-4063-8ae0-7d6cd821f3e9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de470759-c970-4063-8ae0-7d6cd821f3e9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de470759-c970-4063-8ae0-7d6cd821f3e9">
											<gml:posList>35.66904707033818 139.74117693514918 10.29 35.66898821543003 139.74112429095857 10.29 35.66898821543003 139.74112429095857 14.916 35.66904707033818 139.74117693514918 14.916 35.66904707033818 139.74117693514918 10.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-76e15357-d06a-4a08-a3eb-a22ba58bd5b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-76e15357-d06a-4a08-a3eb-a22ba58bd5b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-76e15357-d06a-4a08-a3eb-a22ba58bd5b0">
											<gml:posList>35.66903357609274 139.74119959511046 10.29 35.66904707033818 139.74117693514918 10.29 35.66904707033818 139.74117693514918 14.916 35.66903357609274 139.74119959511046 14.916 35.66903357609274 139.74119959511046 10.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8633</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>