<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_b341af2c-9cbc-4e89-83f7-18a2fdc705e7">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>永田町二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3003</bldg:class>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67455922171212 139.740361263567 0 35.67456332800588 139.74030944914472 0 35.674519877796094 139.74030419708612 0 35.67451568136735 139.7403560115851 0 35.67455922171212 139.740361263567 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67455922171212 139.740361263567 26.524 35.67451568136735 139.7403560115851 26.524 35.674519877796094 139.74030419708612 26.524 35.67456332800588 139.74030944914472 26.524 35.67455922171212 139.740361263567 26.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67455922171212 139.740361263567 26.524 35.67456332800588 139.74030944914472 26.524 35.67456332800588 139.74030944914472 29.524 35.67455922171212 139.740361263567 29.524 35.67455922171212 139.740361263567 26.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67456332800588 139.74030944914472 26.524 35.674519877796094 139.74030419708612 26.524 35.674519877796094 139.74030419708612 29.524 35.67456332800588 139.74030944914472 29.524 35.67456332800588 139.74030944914472 26.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674519877796094 139.74030419708612 26.524 35.67451568136735 139.7403560115851 26.524 35.67451568136735 139.7403560115851 29.524 35.674519877796094 139.74030419708612 29.524 35.674519877796094 139.74030419708612 26.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67451568136735 139.7403560115851 26.524 35.67455922171212 139.740361263567 26.524 35.67455922171212 139.740361263567 29.524 35.67451568136735 139.7403560115851 29.524 35.67451568136735 139.7403560115851 26.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67455922171212 139.740361263567 29.524 35.67456332800588 139.74030944914472 29.524 35.674519877796094 139.74030419708612 29.524 35.67451568136735 139.7403560115851 29.524 35.67455922171212 139.740361263567 29.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-2d1ca4d6-9af8-4352-8234-715c815ae3c6"/>
							<gml:surfaceMember xlink:href="#poly-d96abe53-51de-4471-be3d-b885fedc8364"/>
							<gml:surfaceMember xlink:href="#poly-03f3070c-6783-4bf4-9892-0129f3f4a4e3"/>
							<gml:surfaceMember xlink:href="#poly-8378ee8f-c77b-4990-aaa9-3f9a774d1f34"/>
							<gml:surfaceMember xlink:href="#poly-06e4fbbb-3365-42e0-b63f-088e503d7ea6"/>
							<gml:surfaceMember xlink:href="#poly-f31ec8fb-26dc-4e1b-8098-f46ee7e2a0cb"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-2d1ca4d6-9af8-4352-8234-715c815ae3c6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d1ca4d6-9af8-4352-8234-715c815ae3c6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d1ca4d6-9af8-4352-8234-715c815ae3c6">
											<gml:posList>35.674519877796094 139.74030419708612 26.524 35.67456332800589 139.74030944914472 26.524 35.67455922171211 139.74036126356697 26.524 35.67451568136733 139.7403560115851 26.524 35.674519877796094 139.74030419708612 26.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d96abe53-51de-4471-be3d-b885fedc8364">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d96abe53-51de-4471-be3d-b885fedc8364">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d96abe53-51de-4471-be3d-b885fedc8364">
											<gml:posList>35.67456332800589 139.74030944914472 33 35.674519877796094 139.74030419708612 33 35.67451568136733 139.7403560115851 33 35.67455922171211 139.74036126356697 33 35.67456332800589 139.74030944914472 33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-03f3070c-6783-4bf4-9892-0129f3f4a4e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03f3070c-6783-4bf4-9892-0129f3f4a4e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03f3070c-6783-4bf4-9892-0129f3f4a4e3">
											<gml:posList>35.674519877796094 139.74030419708612 26.524 35.67451568136733 139.7403560115851 26.524 35.67451568136733 139.7403560115851 33 35.674519877796094 139.74030419708612 33 35.674519877796094 139.74030419708612 26.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8378ee8f-c77b-4990-aaa9-3f9a774d1f34">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8378ee8f-c77b-4990-aaa9-3f9a774d1f34">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8378ee8f-c77b-4990-aaa9-3f9a774d1f34">
											<gml:posList>35.67451568136733 139.7403560115851 26.524 35.67455922171211 139.74036126356697 26.524 35.67455922171211 139.74036126356697 33 35.67451568136733 139.7403560115851 33 35.67451568136733 139.7403560115851 26.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-06e4fbbb-3365-42e0-b63f-088e503d7ea6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-06e4fbbb-3365-42e0-b63f-088e503d7ea6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-06e4fbbb-3365-42e0-b63f-088e503d7ea6">
											<gml:posList>35.67456332800589 139.74030944914472 26.524 35.674519877796094 139.74030419708612 26.524 35.674519877796094 139.74030419708612 33 35.67456332800589 139.74030944914472 33 35.67456332800589 139.74030944914472 26.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f31ec8fb-26dc-4e1b-8098-f46ee7e2a0cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f31ec8fb-26dc-4e1b-8098-f46ee7e2a0cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f31ec8fb-26dc-4e1b-8098-f46ee7e2a0cb">
											<gml:posList>35.67455922171211 139.74036126356697 26.524 35.67456332800589 139.74030944914472 26.524 35.67456332800589 139.74030944914472 33 35.67455922171211 139.74036126356697 33 35.67455922171211 139.74036126356697 26.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4603</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>