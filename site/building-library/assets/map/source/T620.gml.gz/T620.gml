<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_b4088c88-baed-440d-ae18-862d7bbfc40f">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>8</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13101008003</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>霞が関三丁目南地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">10.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>14</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67076356373567 139.7464378452971 0 35.67076105766708 139.7464624812901 0 35.67090079508475 139.7464840801118 0 35.670862816414676 139.74685448248783 0 35.67088258558095 139.7468573442565 0 35.67092797125061 139.74642129644167 0 35.67073245897589 139.74639014790927 0 35.6707280728713 139.7464325704881 0 35.67076356373567 139.7464378452971 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67076356373567 139.7464378452971 8.58 35.6707280728713 139.7464325704881 8.58 35.67073245897589 139.74639014790927 8.58 35.67092797125061 139.74642129644167 8.58 35.67088258558095 139.7468573442565 8.58 35.670862816414676 139.74685448248783 8.58 35.67090079508475 139.7464840801118 8.58 35.67076105766708 139.7464624812901 8.58 35.67076356373567 139.7464378452971 8.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67076356373567 139.7464378452971 8.58 35.67076105766708 139.7464624812901 8.58 35.67076105766708 139.7464624812901 19.07 35.67076356373567 139.7464378452971 19.07 35.67076356373567 139.7464378452971 8.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67076105766708 139.7464624812901 8.58 35.67090079508475 139.7464840801118 8.58 35.67090079508475 139.7464840801118 19.07 35.67076105766708 139.7464624812901 19.07 35.67076105766708 139.7464624812901 8.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67090079508475 139.7464840801118 8.58 35.670862816414676 139.74685448248783 8.58 35.670862816414676 139.74685448248783 19.07 35.67090079508475 139.7464840801118 19.07 35.67090079508475 139.7464840801118 8.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670862816414676 139.74685448248783 8.58 35.67088258558095 139.7468573442565 8.58 35.67088258558095 139.7468573442565 19.07 35.670862816414676 139.74685448248783 19.07 35.670862816414676 139.74685448248783 8.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67088258558095 139.7468573442565 8.58 35.67092797125061 139.74642129644167 8.58 35.67092797125061 139.74642129644167 19.07 35.67088258558095 139.7468573442565 19.07 35.67088258558095 139.7468573442565 8.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67092797125061 139.74642129644167 8.58 35.67073245897589 139.74639014790927 8.58 35.67073245897589 139.74639014790927 19.07 35.67092797125061 139.74642129644167 19.07 35.67092797125061 139.74642129644167 8.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67073245897589 139.74639014790927 8.58 35.6707280728713 139.7464325704881 8.58 35.6707280728713 139.7464325704881 19.07 35.67073245897589 139.74639014790927 19.07 35.67073245897589 139.74639014790927 8.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6707280728713 139.7464325704881 8.58 35.67076356373567 139.7464378452971 8.58 35.67076356373567 139.7464378452971 19.07 35.6707280728713 139.7464325704881 19.07 35.6707280728713 139.7464325704881 8.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67076356373567 139.7464378452971 19.07 35.67076105766708 139.7464624812901 19.07 35.67090079508475 139.7464840801118 19.07 35.670862816414676 139.74685448248783 19.07 35.67088258558095 139.7468573442565 19.07 35.67092797125061 139.74642129644167 19.07 35.67073245897589 139.74639014790927 19.07 35.6707280728713 139.7464325704881 19.07 35.67076356373567 139.7464378452971 19.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-8dabd36f-c4b5-484d-b0a2-11d3174a8467"/>
							<gml:surfaceMember xlink:href="#poly-7b2d28c1-ca7c-498c-8f1a-bb2f950e374d"/>
							<gml:surfaceMember xlink:href="#poly-4506d922-8b1a-4001-b607-4a759ec011a6"/>
							<gml:surfaceMember xlink:href="#poly-0f941a1a-8667-4bec-9f73-44a0b0d0633c"/>
							<gml:surfaceMember xlink:href="#poly-e6dbcb68-f8cd-40ce-84ce-bda4891e16b1"/>
							<gml:surfaceMember xlink:href="#poly-6062c3bc-0102-4bf0-936c-bdb2733ef3e4"/>
							<gml:surfaceMember xlink:href="#poly-22fd0a96-50fb-4dee-8c97-665f44886293"/>
							<gml:surfaceMember xlink:href="#poly-7fc0b1df-9b77-4578-8699-46f4e461b9bb"/>
							<gml:surfaceMember xlink:href="#poly-8069e5c6-b6c9-4e26-9770-035f4578853f"/>
							<gml:surfaceMember xlink:href="#poly-d216de61-0dab-4cfd-b0d0-84a27c864d0c"/>
							<gml:surfaceMember xlink:href="#poly-82a82f44-d0b2-4375-9cf2-2f315ba27764"/>
							<gml:surfaceMember xlink:href="#poly-3ea9c8ec-4f46-4a2c-b11a-90d1e1f1bd5a"/>
							<gml:surfaceMember xlink:href="#poly-9a9a5736-9b70-4e73-8b9d-19d044e1f135"/>
							<gml:surfaceMember xlink:href="#poly-728c74c3-9077-4649-8b60-9e3f844eea3c"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-8dabd36f-c4b5-484d-b0a2-11d3174a8467">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8dabd36f-c4b5-484d-b0a2-11d3174a8467">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8dabd36f-c4b5-484d-b0a2-11d3174a8467">
											<gml:posList>35.67076356373565 139.7464378452971 8.58 35.6707280728713 139.74643257048808 8.58 35.67073245897588 139.74639014790927 8.58 35.67092797125059 139.7464212964417 8.58 35.67088258558094 139.7468573442565 8.58 35.67086281641466 139.7468544824878 8.58 35.670900795084734 139.7464840801118 8.58 35.670761057667036 139.74646248129008 8.58 35.67076356373565 139.7464378452971 8.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7b2d28c1-ca7c-498c-8f1a-bb2f950e374d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b2d28c1-ca7c-498c-8f1a-bb2f950e374d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b2d28c1-ca7c-498c-8f1a-bb2f950e374d">
											<gml:posList>35.67092797125059 139.7464212964417 18.8 35.67073245897588 139.74639014790927 18.8 35.6707280728713 139.74643257048808 18.8 35.67076356373565 139.7464378452971 18.8 35.670761057667036 139.74646248129008 18.8 35.670900795084734 139.7464840801118 18.8 35.67089169122129 139.74657161005 18.8 35.670903050319545 139.74657410527524 18.8 35.67090414139743 139.74656217405578 18.8 35.67091316515346 139.74656357822042 18.8 35.67092797125059 139.7464212964417 18.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4506d922-8b1a-4001-b607-4a759ec011a6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4506d922-8b1a-4001-b607-4a759ec011a6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4506d922-8b1a-4001-b607-4a759ec011a6">
											<gml:posList>35.67088258558094 139.7468573442565 14.4 35.67091316515346 139.74656357822042 14.4 35.67090414139743 139.74656217405578 14.4 35.670903050319545 139.74657410527524 14.4 35.67089169122129 139.74657161005 14.4 35.67086281641466 139.7468544824878 14.4 35.67088258558094 139.7468573442565 14.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0f941a1a-8667-4bec-9f73-44a0b0d0633c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0f941a1a-8667-4bec-9f73-44a0b0d0633c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0f941a1a-8667-4bec-9f73-44a0b0d0633c">
											<gml:posList>35.67092797125059 139.7464212964417 8.58 35.67073245897588 139.74639014790927 8.58 35.67073245897588 139.74639014790927 18.8 35.67092797125059 139.7464212964417 18.8 35.67092797125059 139.7464212964417 8.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e6dbcb68-f8cd-40ce-84ce-bda4891e16b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e6dbcb68-f8cd-40ce-84ce-bda4891e16b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e6dbcb68-f8cd-40ce-84ce-bda4891e16b1">
											<gml:posList>35.67073245897588 139.74639014790927 8.58 35.6707280728713 139.74643257048808 8.58 35.6707280728713 139.74643257048808 18.8 35.67073245897588 139.74639014790927 18.8 35.67073245897588 139.74639014790927 8.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6062c3bc-0102-4bf0-936c-bdb2733ef3e4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6062c3bc-0102-4bf0-936c-bdb2733ef3e4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6062c3bc-0102-4bf0-936c-bdb2733ef3e4">
											<gml:posList>35.6707280728713 139.74643257048808 8.58 35.67076356373565 139.7464378452971 8.58 35.67076356373565 139.7464378452971 18.8 35.6707280728713 139.74643257048808 18.8 35.6707280728713 139.74643257048808 8.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-22fd0a96-50fb-4dee-8c97-665f44886293">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22fd0a96-50fb-4dee-8c97-665f44886293">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22fd0a96-50fb-4dee-8c97-665f44886293">
											<gml:posList>35.67076356373565 139.7464378452971 8.58 35.670761057667036 139.74646248129008 8.58 35.670761057667036 139.74646248129008 18.8 35.67076356373565 139.7464378452971 18.8 35.67076356373565 139.7464378452971 8.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7fc0b1df-9b77-4578-8699-46f4e461b9bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7fc0b1df-9b77-4578-8699-46f4e461b9bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7fc0b1df-9b77-4578-8699-46f4e461b9bb">
											<gml:posList>35.670761057667036 139.74646248129008 8.58 35.670900795084734 139.7464840801118 8.58 35.670900795084734 139.7464840801118 18.8 35.670761057667036 139.74646248129008 18.8 35.670761057667036 139.74646248129008 8.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8069e5c6-b6c9-4e26-9770-035f4578853f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8069e5c6-b6c9-4e26-9770-035f4578853f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8069e5c6-b6c9-4e26-9770-035f4578853f">
											<gml:posList>35.67091316515346 139.74656357822042 18.8 35.67090414139743 139.74656217405578 18.8 35.67090414139743 139.74656217405578 14.4 35.67091316515346 139.74656357822042 14.4 35.67091316515346 139.74656357822042 18.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d216de61-0dab-4cfd-b0d0-84a27c864d0c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d216de61-0dab-4cfd-b0d0-84a27c864d0c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d216de61-0dab-4cfd-b0d0-84a27c864d0c">
											<gml:posList>35.67090414139743 139.74656217405578 18.8 35.670903050319545 139.74657410527524 18.8 35.670903050319545 139.74657410527524 14.4 35.67090414139743 139.74656217405578 14.4 35.67090414139743 139.74656217405578 18.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-82a82f44-d0b2-4375-9cf2-2f315ba27764">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-82a82f44-d0b2-4375-9cf2-2f315ba27764">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-82a82f44-d0b2-4375-9cf2-2f315ba27764">
											<gml:posList>35.670903050319545 139.74657410527524 18.8 35.67089169122129 139.74657161005 18.8 35.67089169122129 139.74657161005 14.4 35.670903050319545 139.74657410527524 14.4 35.670903050319545 139.74657410527524 18.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3ea9c8ec-4f46-4a2c-b11a-90d1e1f1bd5a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ea9c8ec-4f46-4a2c-b11a-90d1e1f1bd5a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ea9c8ec-4f46-4a2c-b11a-90d1e1f1bd5a">
											<gml:posList>35.67092797125059 139.7464212964417 8.58 35.67092797125059 139.7464212964417 18.8 35.67091316515346 139.74656357822042 18.8 35.67091316515346 139.74656357822042 14.4 35.67088258558094 139.7468573442565 14.4 35.67088258558094 139.7468573442565 8.58 35.67092797125059 139.7464212964417 8.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9a9a5736-9b70-4e73-8b9d-19d044e1f135">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a9a5736-9b70-4e73-8b9d-19d044e1f135">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a9a5736-9b70-4e73-8b9d-19d044e1f135">
											<gml:posList>35.67089169122129 139.74657161005 14.4 35.67089169122129 139.74657161005 18.8 35.670900795084734 139.7464840801118 18.8 35.670900795084734 139.7464840801118 8.58 35.67086281641466 139.7468544824878 8.58 35.67086281641466 139.7468544824878 14.4 35.67089169122129 139.74657161005 14.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-728c74c3-9077-4649-8b60-9e3f844eea3c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-728c74c3-9077-4649-8b60-9e3f844eea3c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-728c74c3-9077-4649-8b60-9e3f844eea3c">
											<gml:posList>35.67086281641466 139.7468544824878 8.58 35.67088258558094 139.7468573442565 8.58 35.67088258558094 139.7468573442565 14.4 35.67086281641466 139.7468544824878 14.4 35.67086281641466 139.7468544824878 8.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都千代田区霞が関三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-1418</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">2211.11442</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>